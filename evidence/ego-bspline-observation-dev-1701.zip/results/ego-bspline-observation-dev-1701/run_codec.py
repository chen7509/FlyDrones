import base64
import hashlib
import json
import subprocess
import time
from pathlib import Path

import numpy as np

from tools.benchmark import ego_bspline_observation as bs

root = Path(__file__).resolve().parent
out = root / 'codec-v1'
out.mkdir(exist_ok=False)
image = 'sha256:a4dae62b38bc01a01d084be7b68db83ec804fef7673604e1a9c986a4baa88a6a'
name = 'fly-ego-bspline-codec-1701-v1'
def command(args):
    return subprocess.run(args, capture_output=True, text=True, timeout=40, check=True).stdout.strip()
store = bs.typestore()
point = store.types['geometry_msgs/msg/Point']
stamp = store.types['builtin_interfaces/msg/Time']
cases = []
for i, label in enumerate(['straight', 'curved', 'padded']):
    msg = store.types[bs.TYPE](0, 3, i+1, stamp(2, i), np.arange(8,dtype=np.float64)*.1,
        [point(float(j), .2 if i == 1 and j == 1 else 0., 1.) for j in range(4)], np.array([],dtype=np.float64),0.)
    raw = bytes(store.serialize_cdr(msg, bs.TYPE)) + (b'\0\0\0' if i == 2 else b'')
    cases.append({'name': label, 'raw_b64': base64.b64encode(raw).decode(), **bs.decode(raw)})
cases_path = root / 'codec-cases-v1.json'
with cases_path.open('x') as stream:
    json.dump(cases, stream, indent=2)
probe = root / 'codec_probe.py'
counter = float(command(['pwsh','-NoProfile','-Command',"(Get-Counter '\\Memory\\Available MBytes').CounterSamples[0].CookedValue"]))
actual = command(['docker','image','inspect','fly-ego-benchmark:humble','--format','{{.Id}}'])
running = command(['docker','ps','--format','{{.ID}} {{.Names}}'])
owned = command(['docker','ps','-a','--filter',f'name=^/{name}$','--format','{{.ID}}'])
inputs = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in [probe,cases_path,
    Path(bs.__file__), Path('evidence/ego-causal-provenance-dev-1701.zip')]}
profile = {'study':'bspline-humble-codec-v1','host_available_mib':counter,'minimum_host_mib':1024,
           'image':actual,'expected_image':image,'running':running,'existing_owned':owned,'inputs_before':inputs,
           'memory_mib':256,'cpu':1,'network':'none','inner_seconds':20,'outer_seconds':40}
(out/'preflight.json').write_text(json.dumps(profile,indent=2))
assert counter >= 1024 and actual == image and not running and not owned
args = ['docker','create','--name',name,'--pull','never','--network','none','--memory','256m',
        '--memory-swap','256m','--cpus','1','--pids-limit','64','--cap-drop','ALL',
        '--security-opt','no-new-privileges','--mount',f'type=bind,source={probe},target=/probe.py,readonly',
        '--mount',f'type=bind,source={cases_path},target=/cases.json,readonly',
        '--mount',f'type=bind,source={out},target=/out','--entrypoint','/bin/bash',image,'-c',
        'source /opt/ros/humble/setup.bash && source /ego_ws/install/setup.bash && exec timeout --signal=TERM --kill-after=2s 20s python3 -B /probe.py']
(out/'command.json').write_text(json.dumps(args,indent=2))
identity = command(args)
(out/'container-id.txt').write_text(identity)
start = time.monotonic()
run = None
try:
    run = subprocess.run(['docker','start','-a',identity],capture_output=True,text=True,timeout=40)
    (out/'stdout.txt').write_text(run.stdout)
    (out/'stderr.txt').write_text(run.stderr)
    (out/'inspect.json').write_text(command(['docker','inspect',identity]))
finally:
    # Only the exact newly created container is removed, including timeout.
    cleanup = subprocess.run(['docker','rm','-f',identity],capture_output=True,text=True,timeout=10)
    after = {key: hashlib.sha256(Path(key).read_bytes()).hexdigest() for key in inputs}
    (out/'completion.json').write_text(json.dumps({'docker_exit':None if run is None else run.returncode,
        'elapsed_seconds':time.monotonic()-start,'cleanup_exit':cleanup.returncode,'cleanup_stdout':cleanup.stdout,
        'cleanup_stderr':cleanup.stderr,'inputs_after':after,'inputs_stable':after==inputs},indent=2))
assert run is not None and run.returncode == 0 and cleanup.returncode == 0 and after == inputs
print((out/'result.json').read_text())
