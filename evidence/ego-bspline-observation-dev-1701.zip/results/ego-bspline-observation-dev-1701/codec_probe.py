import base64
import hashlib
import json
from pathlib import Path

from rclpy.serialization import deserialize_message, serialize_message
from traj_utils.msg import Bspline

definition = Path('/ego_ws/install/traj_utils/share/traj_utils/msg/Bspline.msg').read_bytes()
assert hashlib.sha256(definition).hexdigest() == '6a81d3687daf49f3152f514ed5639e55374be32dd438a4f1c90900503f8e3f85'
cases = json.loads(Path('/cases.json').read_text())
observations = []
for case in cases:
    raw = base64.b64decode(case['raw_b64'], validate=True)
    msg = deserialize_message(raw, Bspline)
    canonical = bytes(serialize_message(msg))
    assert hashlib.sha256(canonical).hexdigest() == case['canonical_sha256']
    assert msg.traj_id == case['trajectory']['traj_id']
    assert [[p.x, p.y, p.z] for p in msg.pos_pts] == case['trajectory']['pos_pts']
    assert list(msg.knots) == case['trajectory']['knots']
    observations.append({'name': case['name'], 'raw_sha256': hashlib.sha256(raw).hexdigest(),
                         'canonical_sha256': hashlib.sha256(canonical).hexdigest(),
                         'canonical_bytes': len(canonical), 'type_fields': Bspline.get_fields_and_field_types()})
result = {'cases': observations, 'definition_sha256': hashlib.sha256(definition).hexdigest(),
          'rosbags_rclpy_bspline_bytes_equal': True, 'planner_started': False,
          'dds_node_started': False, 'teacher_qualified': False}
Path('/out/result.json').write_text(json.dumps(result, indent=2))
Path('/out/self-maps.txt').write_text(Path('/proc/self/maps').read_text())
print(json.dumps(result))
