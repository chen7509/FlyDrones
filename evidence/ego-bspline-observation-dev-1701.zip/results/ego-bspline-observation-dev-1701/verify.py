import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root = Path.cwd()
out = root / 'results/ego-bspline-observation-dev-1701/final-v1'
out.mkdir(exist_ok=False)
inputs = ['tools/benchmark/ego_bspline_observation.py', 'tests/benchmark/test_ego_bspline_observation.py',
          'tools/benchmark/ego_node.py', 'tools/benchmark/ego_causal_readonly_v2.patch',
          'evidence/ego-causal-provenance-dev-1701.zip']
before = {p: hashlib.sha256((root/p).read_bytes()).hexdigest() for p in inputs}
env = dict(os.environ)
env['PYTHONPATH'] = os.pathsep.join([str(root/'results/ego-cdr-field-audit-dev-1701/deps'), str(root),str(root/'src')])
commands = [
    [sys.executable,'-m','pytest','tests/benchmark/test_ego_bspline_observation.py',
     'tests/benchmark/test_ego_adapter.py','tests/benchmark/test_ego_bridge_cdr_audit.py',
     'tests/benchmark/test_ego_bridge_cdr_journal.py','tests/benchmark/test_ego_causal_join.py',
     'tests/benchmark/test_ego_diagnostic_reconcile.py','tests/benchmark/test_ego_wire_observation.py','-q'],
    [sys.executable,'-m','ruff','check',inputs[0],inputs[1]],
    ['git','diff','--check']]
observations = []
for i, cmd in enumerate(commands):
    run = subprocess.run(cmd,env=env,capture_output=True,text=True)
    (out/f'{i}-stdout.txt').write_text(run.stdout,encoding='utf-8')
    (out/f'{i}-stderr.txt').write_text(run.stderr,encoding='utf-8')
    observations.append({'command':cmd,'exit':run.returncode})
    print(run.stdout[-1200:], run.stderr[-500:])
after = {p: hashlib.sha256((root/p).read_bytes()).hexdigest() for p in inputs}
record = {'commands':observations,'source_before':before,'source_after':after,'unchanged':before==after,
          'python':sys.version,'scope':'fake runtime and actual independent CDR codecs; no ROS node/physical/full build'}
(out/'execution.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
assert before == after and all(o['exit']==0 for o in observations)
