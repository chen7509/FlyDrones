import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

root = Path.cwd()
study = root / 'results/ego-bspline-observation-dev-1701'
sources = ['tools/benchmark/ego_bspline_observation.py','tests/benchmark/test_ego_bspline_observation.py',
           'docs/EGO_BSPLINE_OBSERVATION_REPORT.md',
           'docs/superpowers/specs/2026-10-12-ego-bspline-observation-design.md',
           'docs/superpowers/plans/2026-10-12-ego-bspline-observation.md']
execution = json.loads((study/'final-v1/execution.json').read_text())
for path, digest in execution['source_after'].items():
    assert hashlib.sha256((root/path).read_bytes()).hexdigest() == digest
assert execution['unchanged'] and all(c['exit']==0 for c in execution['commands'])
codec = json.loads((study/'codec-v1/completion.json').read_text())
state = json.loads((study/'codec-v1/inspect.json').read_text())[0]
assert codec['docker_exit']==0 and codec['cleanup_exit']==0 and codec['inputs_stable']
assert state['State']['ExitCode']==0 and state['State']['OOMKilled'] is False
selected = {p: (root/p).read_bytes() for p in sources}
for path in study.rglob('*'):
    if path.is_file() and '__pycache__' not in path.parts and path.name not in {'seal.json','pr65-body.md','pr65-before.json'}:
        selected[str(path.relative_to(root)).replace('\\','/')] = path.read_bytes()
for name in ['Bspline.msg','traj_server.cpp','LICENSE']:
    selected['upstream/'+name] = (root/'results/ego-causal-provenance-dev-1701/source'/name).read_bytes()
manifest = {p:{'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)} for p,data in selected.items()}
archive = root/'evidence/ego-bspline-observation-dev-1701.zip'
with ZipFile(archive,'x',ZIP_DEFLATED) as zipped:
    for p,data in selected.items():
        zipped.writestr(p,data)
    zipped.writestr('manifest.json',json.dumps(manifest,indent=2))
with ZipFile(archive) as zipped:
    assert zipped.testzip() is None
    for p,m in manifest.items():
        data = zipped.read(p)
        assert len(data)==m['bytes'] and hashlib.sha256(data).hexdigest()==m['sha256']
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
sidecar = archive.with_suffix('.sha256')
with sidecar.open('x') as stream:
    stream.write(digest+'  '+archive.name+'\n')
record={'sha256':digest,'members':len(manifest)+1,'bytes':archive.stat().st_size,'all_members_crc_hash_verified':True,
        'focused_passed':33,'affected_passed':171,'actual_humble_codec_cases':3,'teacher_qualified':False}
(study/'seal.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record))
