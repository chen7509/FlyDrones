# OpenVINS feature-history and geometry research

## Upstream, license, and maintenance record

- Fixed upstream: `rpng/open_vins` commit
  `69488123ed9362dd44b6f28e7f4680abbff1442b`.
- License: GPL-3.0-or-later. The incremental diagnostic patch remains under
  `tools/benchmark/gpl/` and is not loaded by normal FlyDrones execution.
- Repository status reused from the preceding frozen-source review: not
  archived, last recorded push 2025-11-30; current maintenance cadence is
  uncertain.
- Primary sources inspected: the fixed `VioManager.cpp`, `UpdaterMSCKF.cpp`,
  `UpdaterSLAM.cpp`, and `FeatureInitializer.cpp/.h`; the official OpenVINS
  [feature initializer API](https://docs.openvins.com/classov__core_1_1FeatureInitializer.html),
  [initializer options](https://docs.openvins.com/structov__core_1_1FeatureInitializerOptions.html),
  and the OpenVINS ICRA 2020 paper
  [DOI 10.1109/ICRA40945.2020.9196524](https://doi.org/10.1109/ICRA40945.2020.9196524).

## Adopted method

The public post-update feature database cannot distinguish a one-observation
candidate from a multi-observation candidate pruned to one current clone, and
aggregate triangulation counters do not expose the failing geometry. The
adopted method therefore adds three read-only structured records to an
isolated GPL build:

- `FD_SELECT`: updater stage, feature identity, source category, and raw
  observation span;
- `FD_HISTORY`: observation span before and after clone-window cleaning;
- `FD_TRI`: fixed 3-D linear triangulation condition number, depth, baseline,
  parallax, and the unchanged rejection predicates.

The MIT-side parser fails closed on malformed, missing, duplicated, non-finite,
or unreconciled records. One complete replay consumes the immutable sealed
requests. Its non-timing camera-state sequence is compared with the earlier
uninstrumented control at `1e-12` tolerance.

## Rejected approaches

- Tuning clone count, tracker thresholds, triangulation thresholds, scene,
  motion, noise, or calibration on the sealed input.
- Inferring history length from aggregate updater counters or the final
  feature database.
- Repeating old frames to create apparent history, or using truth to initialize
  or repair OpenVINS.
- Treating replay wall time as physical or online latency.
- Running PX4/Gazebo again; the sealed physical capture is unchanged.

## Resource and adaptation cost

The isolated Release build uses Ubuntu GCC 13.3 and existing OpenCV, Boost,
Ceres, Eigen, and SuiteSparse libraries. The loaded OpenVINS library SHA-256 is
`ab83eb3617a6f7f41c116b9b02767765ea1ea991a6ef33e6cf36f15973445802`;
the native probe SHA-256 is
`a7d7631f0085ec44c79568f0bd649830ff47599ff0217079f69e029d736be17d`;
the incremental GPL patch SHA-256 is
`df6455aefb3882ad4b72bf8a3484d0e24a17903fad47ee1c0df58ee9a4c6b0b9`.
No dependency was installed and no training, PX4, Gazebo, ODOMETRY, EKF2, or
arming process was started.

The first provenance command inherited the Windows worktree's `GIT_DIR` into
WSL and printed invalid commit identities; that file is retained as a failed
attempt. `upstream-git-state.txt` is the authoritative isolated-worktree Git
record after explicitly clearing `GIT_DIR` and `GIT_WORK_TREE`.
