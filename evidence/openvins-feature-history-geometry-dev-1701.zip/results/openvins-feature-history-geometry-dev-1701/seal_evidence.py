import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
stage = root / "results" / "openvins-feature-history-geometry-dev-1701"
output = root / "evidence" / "openvins-feature-history-geometry-dev-1701.zip"

members = [
    root / "evidence" / "openvins-feature-rejection-trace-dev-1701-v3.zip",
    root / "docs" / "OPENVINS_FEATURE_HISTORY_GEOMETRY_REPORT.md",
    root / "docs" / "ESTIMATOR_PHYSICAL_REFUSAL_DIAGNOSIS_REPORT.md",
    root
    / "docs"
    / "superpowers"
    / "specs"
    / "2026-10-07-openvins-feature-history-geometry-design.md",
    root
    / "docs"
    / "superpowers"
    / "plans"
    / "2026-10-07-openvins-feature-history-geometry.md",
    root / "tools" / "benchmark" / "openvins_feature_trace.py",
    root / "tools" / "benchmark" / "audit_openvins_feature_trace.py",
    root / "tools" / "benchmark" / "replay_openvins_motion_intent.py",
    root / "tools" / "benchmark" / "openvins_online_probe.cpp",
    root
    / "tools"
    / "benchmark"
    / "gpl"
    / "openvins_feature_history_geometry.patch",
    root / "tools" / "benchmark" / "gpl" / "README.md",
    root / "tests" / "benchmark" / "test_openvins_feature_trace.py",
]
members.extend(path for path in stage.rglob("*") if path.is_file())

unique = {}
for path in members:
    resolved = path.resolve()
    if not resolved.is_file():
        raise FileNotFoundError(resolved)
    arcname = resolved.relative_to(root.resolve()).as_posix()
    if arcname in unique:
        raise ValueError(f"duplicate archive member: {arcname}")
    unique[arcname] = resolved

manifest = {
    name: {
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "size": path.stat().st_size,
    }
    for name, path in sorted(unique.items())
}
manifest_bytes = (
    json.dumps(
        {
            "schema": "openvins-feature-history-geometry-evidence-v1",
            "physical_replay": False,
            "truth_used": False,
            "fusion_eligible": False,
            "members": manifest,
        },
        indent=2,
        sort_keys=True,
    )
    + "\n"
).encode()

output.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, path in sorted(unique.items()):
        archive.write(path, name)
    archive.writestr("MANIFEST.json", manifest_bytes)

with zipfile.ZipFile(output) as archive:
    names = archive.namelist()
    if len(names) != len(set(names)) or archive.testzip() is not None:
        raise ValueError("archive CRC or member uniqueness failure")
    stored = json.loads(archive.read("MANIFEST.json"))
    if stored["members"] != manifest or len(names) != len(manifest) + 1:
        raise ValueError("archive manifest mismatch")
    for name, expected in manifest.items():
        data = archive.read(name)
        if len(data) != expected["size"] or hashlib.sha256(data).hexdigest() != expected["sha256"]:
            raise ValueError(f"archive member mismatch: {name}")

seal = {
    "path": output.relative_to(root).as_posix(),
    "sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
    "size": output.stat().st_size,
    "members": len(manifest) + 1,
    "manifest_members": len(manifest),
    "crc_verified": True,
}
(stage / "evidence-seal.json").write_text(
    json.dumps(seal, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)
print(json.dumps(seal, indent=2, sort_keys=True))
