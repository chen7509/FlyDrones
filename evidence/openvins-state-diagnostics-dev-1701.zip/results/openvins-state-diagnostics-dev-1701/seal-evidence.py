import hashlib
import json
import zipfile
from pathlib import Path

stage = Path(__file__).resolve().parent
root = stage.parents[1]
archive = root / 'evidence/openvins-state-diagnostics-dev-1701.zip'
index_path = archive.with_suffix('.sha256.json')
assert not archive.exists() and not index_path.exists()
sha = lambda data: hashlib.sha256(data).hexdigest()
omissions = ['state_probe', 'state_probe_v2', 'output_guard_test', 'output_guard_test_v2']
extras = [
    'docs/OPENVINS_STATE_DIAGNOSTICS_REPORT.md',
    'docs/superpowers/specs/2026-10-05-openvins-state-diagnostics-design.md',
    'docs/superpowers/plans/2026-10-05-openvins-state-diagnostics.md',
    'tools/benchmark/openvins_state_probe.cpp',
    'tools/benchmark/exclusive_probe_output.h',
    'tests/benchmark/exclusive_probe_output_test.cpp',
    'tools/benchmark/audit_openvins_state_diagnostics.py',
    'tools/benchmark/make_prearm_pattern_fixture.py',
    'tests/benchmark/test_openvins_state_diagnostics.py',
    'tests/benchmark/test_prearm_pattern_fixture.py',
    'evidence/openvins-board-pattern-dev-1701-reviewed.sha256.json',
]
files = sorted(p for p in stage.rglob('*') if p.is_file() and p.name not in omissions and '__pycache__' not in p.parts)
files += [root / p for p in extras]
assert len(files) == len(set(files)) and not any(p.is_symlink() for p in files)
entries = {p.relative_to(root).as_posix(): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in files}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in files:
        z.write(p, p.relative_to(root).as_posix())
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == set(entries) and len(z.namelist()) == len(entries)
    for name, entry in entries.items():
        payload = z.read(name)
        assert len(payload) == entry['bytes'] and sha(payload) == entry['sha256']
index = {
    'schema': 'flydrones-sealed-development-evidence-v1',
    'archive': archive.relative_to(root).as_posix(),
    'archive_bytes': archive.stat().st_size,
    'archive_sha256': sha(archive.read_bytes()),
    'member_count': len(entries),
    'members': entries,
    'dependencies': {'prior_evidence': 'openvins-board-pattern-dev-1701-reviewed.zip',
                     'prior_evidence_sha256': '669f3646e74c4e95826f12e79b456aba861a5b4003087541ce7dc1dc8cd1f4f3',
                     'upstream_library_sha256': '532ae57a6a952a0137cc1de291bc47ad556d419c7524fbb23b7a90c00addab5b'},
    'local_only': {name: {'sha256': sha((stage / name).read_bytes()),
                          'reason': 'Generated local executable; source/build evidence and dependency hashes included, binary not redistributed.'}
                   for name in omissions},
}
with index_path.open('x') as stream:
    json.dump(index, stream, indent=2)
print(json.dumps({k: v for k, v in index.items() if k not in ('members', 'local_only')}, indent=2))
