#!/bin/bash
set -uo pipefail
cd /mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility
out=results/openvins-state-diagnostics-dev-1701
source=results/openvins-board-pattern-dev-1701
test -e "$out/verified-inputs.json" || exit 2
test ! -e "$out/replay-v1" || exit 2
mkdir "$out/replay-v1" || exit 2
/usr/bin/time -v -o "$out/replay-v1/resources.txt" "$out/state_probe" "$source/dependencies-v1/config-v2/estimator_config.yaml" "$source/input-v1" "$source/episode-v2" "$out/replay-v1/states.csv" "$out/replay-v1/diagnostics.jsonl" > "$out/replay-v1/stdout.txt" 2> "$out/replay-v1/stderr.txt"
status=$?
printf '%s\n' "$status" > "$out/replay-v1/exit-code.txt"
exit "$status"
