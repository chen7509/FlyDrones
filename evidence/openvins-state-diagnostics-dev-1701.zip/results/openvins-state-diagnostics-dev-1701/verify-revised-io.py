import hashlib
import json
import subprocess
from pathlib import Path

stage = Path(__file__).resolve().parent
existing = stage / 'replay-v1/states.csv'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
before = sha(existing)
new = stage / 'must-not-be-created.jsonl'
assert not new.exists()
result = subprocess.run([str(stage / 'state_probe_v2'), 'unused-config', 'unused-input', 'unused-episode',
                         str(existing), str(new)], capture_output=True, text=True)
assert result.returncode == 1 and 'output exists' in result.stderr
assert sha(existing) == before and not new.exists()
with (stage / 'revised-probe-io-check.json').open('x') as stream:
    json.dump({'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr,
               'existing_state_sha256': before, 'no_new_diagnostics_created': True,
               'estimator_started': False, 'scope': 'existing output rejection occurs before config loading'}, stream, indent=2)
print('revised probe rejects existing output before estimator/config loading; raw states unchanged')
