import hashlib
import json
from pathlib import Path

import numpy as np

stage = Path(__file__).resolve().parent
rows = [json.loads(line) for line in (stage / 'replay-v1/diagnostics.jsonl').read_text().splitlines()]
prearm = [r for r in rows if 15_680_000_000 <= r['image_ns'] <= 19_700_000_000]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
old = stage.parent / 'openvins-board-pattern-dev-1701/replay-v1/states.csv'
new = stage / 'replay-v1/states.csv'
assert sha(old) == sha(new) == '2b5ce9c343e63f3178a74e8a02c889beba3bfbc02ddf9eaf4e1c526f94a6f550'
def quantiles(values):
    return dict(zip(['min', 'median', 'p95', 'max'], np.quantile(values, [0, .5, .95, 1]).tolist()))
summary = {
    'old_csv_exact_sha256_parity': sha(new),
    'prearm_frames': len(prearm),
    'prearm_velocity_norm_m_s': quantiles([np.linalg.norm(r['velocity']) for r in prearm]),
    'prearm_zupt_latched_frames': sum(r['zupt_flag_latched'] for r in prearm),
    'prearm_has_moved_frames': sum(r['has_moved_since_zupt'] for r in prearm),
    'prearm_native_imu_covariance_diagonal_min': np.min([np.diag(r['imu_covariance']) for r in prearm], axis=0).tolist(),
    'prearm_native_imu_covariance_diagonal_max': np.max([np.diag(r['imu_covariance']) for r in prearm], axis=0).tolist(),
    'feed_camera_wall_s': quantiles([r['feed_camera_wall_s'] for r in rows]),
    'prearm_feed_camera_wall_s': quantiles([r['feed_camera_wall_s'] for r in prearm]),
    'timing_scope': 'single offline replay, camera API call only; excludes IMU feed, image decode, covariance export, serialization, transport; not real-time qualification',
}
with (stage / 'summary-v1.json').open('x') as stream:
    json.dump(summary, stream, indent=2, allow_nan=False)
print(json.dumps(summary, indent=2))
