# Next dependency research, 2026-10-05 (not an implemented bridge)

Sources inspected before design:

- PX4 official external-position guide https://docs.px4.io/main/en/ros/external_position_estimation : recommends 30–50 Hz, time synchronization and frame conversion. This is guidance, not proof of a hard rejection threshold in the pinned firmware. Current camera input is 10 Hz; cannot simply duplicate observations and claim fresh estimates.
- MAVLink ODOMETRY https://mavlink.io/en/messages/common.html#ODOMETRY : wxyz attitude, 21-element upper-triangular pose/twist covariance, explicit parent/child frames, reset counter, quality 0 means unknown and -1 failure. Do not invent calibrated confidence.
- Actual pinned PX4 d6f12ad1c4f70ad3230afd7d86e971421e02fef4 source src/modules/mavlink/mavlink_receiver.cpp lines 1349–1560: sync_stamp(time_usec); LOCAL_FRD position and child LOCAL_FRD/BODY_FRD velocity supported; body-to-local quaternion copied directly; diagonal covariances extracted; reset/quality copied. Frame conversion is caller responsibility. Fixed firmware acceptance must be validated, not inferred from latest docs.
- OpenVINS 69488123ed9362dd44b6f28e7f4680abbff1442b ov_msckf/src/state/Propagator.h lines 117–126: fast_state_propagate(state, timestamp, state_plus, covariance) designed for high-rate between-update estimates, returns success boolean, 13-state q_GtoI,p_IinG,v_IinI,w_IinI and 12×12 covariance. Note velocity is BODY expressed here, unlike native state velocity exported in current diagnostics. No current implementation or validation of this new path.

Candidates checked on GitHub:

|Candidate|Version / activity snapshot|License from actual license file|Interface / costs / disposition|
|---|---|---|---|
|Existing OpenVINS fast propagation|Pinned above; no upstream upgrade|GPL-3.0|Read-only propagation API, existing native library; avoids scene/camera load changes. Proposed for validation; actual memory/latency and freshness must be measured.|
|ArduPilot/pymavlink|installed WSL 2.4.49; upstream master 20111a041f3abfeda1c4b34dae43c0cd4441ef52; nonarchived, pushed 2026-10-02|Library metadata LGPLv3; generator license includes generated-code MIT exception; not blanket MIT|Existing package supports direct MAVLink2 encoding, no ROS runtime added. Proposed reuse for future transport after contract tests; pin installed module/XML hashes first.|
|mavlink/mavros|ros2 5c68b905ab30de6ce630822dc46c33467e8f23ea; nonarchived, pushed 2026-09-27|LICENSE.md offers BSD/GPLv3/LGPLv3 alternatives|Existing odometry/frame plugin useful reference; deploying requires ROS2 and bridge integration/runtime not present in this replay. Do not add now merely for one message; resource use not measured.|

Paper continuity: Geneva et al., OpenVINS, ICRA 2020 https://pgeneva.com/downloads/papers/Geneva2020ICRA.pdf ; small covariance/fast propagation does not itself establish estimator consistency or a flight-ready quality score.

Proposed order after current independent review: validate upstream high-rate propagation and freeze message/frame/clock contract; replay and fault-test the contract without PX4 publication; then disarmed online shadow and EKF2 injection with explicit ULog evidence. Never skip current collision/latency failures or multi-aircraft gates.
