import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

root = Path.cwd()
study = root / 'results/curriculum-evaluation-integrity-dev-1701'
verified = json.loads((study / 'final-verification.json').read_text(encoding='utf-8-sig'))
assert all(verified[name] == 0 for name in ('pytest_exit', 'ruff_exit', 'diff_exit'))
assert '33 passed' in (study / 'final-green.txt').read_text(encoding='utf-8-sig')
assert '11 failed, 1 passed' in (study / 'red.txt').read_text(encoding='utf-8-sig')
assert '2 failed' in (study / 'review-red.txt').read_text(encoding='utf-8-sig')
artifacts = list((study / 'pytest-final').rglob('*'))
assert sum(p.is_file() for p in artifacts) == 48
states = [json.loads(p.read_text()) for p in artifacts if p.name == 'state.json']
assert any(s['status'] == 'FAILED' and s['latest_checkpoint'] is None for s in states)
assert any(s['status'] == 'FAILED' and s['completed_stages'] == ['stability']
           and s['latest_checkpoint'] == s['best_checkpoint'] for s in states)
files = {}
for p in study.rglob('*'):
    assert not p.is_symlink()
    if p.is_file() and p.name not in {'seal.json', 'pr65-before.json', 'pr65-body.md'}:
        files[p.relative_to(root).as_posix()] = p.read_bytes()
for rel in [
    'src/flydrones/connectome_training/curriculum.py',
    'src/flydrones/connectome_training/curriculum_config.py',
    'src/flydrones/connectome_training/curriculum_state.py',
    'tests/connectome_training/test_curriculum.py',
    'tests/connectome_training/test_curriculum_config.py',
    'tests/connectome_training/test_curriculum_state.py',
    'docs/CURRICULUM_EVALUATION_INTEGRITY_REPORT.md',
    'docs/superpowers/plans/2026-10-14-curriculum-evaluation-integrity.md',
]:
    files[rel] = (root / rel).read_bytes()
manifest = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
            for name, data in sorted(files.items())}
archive = root / 'evidence/curriculum-evaluation-integrity-dev-1701.zip'
with ZipFile(archive, 'x', ZIP_DEFLATED) as z:
    for name, data in sorted(files.items()):
        z.writestr(name, data)
    z.writestr('manifest.json', json.dumps(manifest, indent=2))
with ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(set(z.namelist()))
    for name, entry in manifest.items():
        data = z.read(name)
        assert len(data) == entry['bytes']
        assert hashlib.sha256(data).hexdigest() == entry['sha256']
        assert data == (root / name).read_bytes()
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
archive.with_suffix('.sha256').open('x').write(digest + '  ' + archive.name + '\n')
record = {'sha256': digest, 'members': len(manifest) + 1, 'bytes': archive.stat().st_size,
          'crc_member_hash_verified': True, 'tests_passed': 33, 'protocol_artifact_files': 48,
          'complete_model_trained': False, 'teacher_qualified': False, 'physical_verified': False}
(study / 'seal.json').open('x').write(json.dumps(record, indent=2))
print(json.dumps(record))
