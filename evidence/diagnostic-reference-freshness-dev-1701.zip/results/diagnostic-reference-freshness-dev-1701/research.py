import hashlib,json,shutil,urllib.request
from pathlib import Path
base=Path(__file__).resolve().parent;dest=base/'sources';dest.mkdir(exist_ok=False)
rev='446a44335a45b704b4d36dabcc5508ee34eeb3d8'
items={
 'Physics.cc':f'https://raw.githubusercontent.com/gazebosim/gz-sim/{rev}/src/systems/physics/Physics.cc',
 'Link.cc':f'https://raw.githubusercontent.com/gazebosim/gz-sim/{rev}/src/Link.cc',
 'EntityComponentManager.hh':f'https://raw.githubusercontent.com/gazebosim/gz-sim/{rev}/include/gz/sim/EntityComponentManager.hh',
 'SimulationFeatures.cc':'https://raw.githubusercontent.com/gazebosim/gz-physics/189471c86fa06ffad9c9bdb199f6928eb2fc02f3/dartsim/src/SimulationFeatures.cc',
 'plugin-tutorial.html':'https://gazebosim.org/api/sim/8/createsystemplugins.html',
 'gz-sim-metadata.json':'https://api.github.com/repos/gazebosim/gz-sim',
 'gz-physics-metadata.json':'https://api.github.com/repos/gazebosim/gz-physics',
 'OpenVINS-ICRA2020.pdf':'https://pgeneva.com/downloads/papers/Geneva2020ICRA.pdf',
 'python-tree.json':f'https://api.github.com/repos/gazebosim/gz-sim/git/trees/{rev}?recursive=1',
}
manifest=[]
for name,url in items.items():
    data=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'FlyDrones-evidence'}),timeout=30).read()
    (dest/name).write_bytes(data);manifest.append(dict(name=name,url=url,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
tree=json.loads((dest/'python-tree.json').read_text())
paths=[t['path'] for t in tree['tree'] if 'python' in t['path'] and ('EntityComponent' in t['path'] or t['path'].endswith('/Link.cc'))]
for path in paths:
    url=f'https://raw.githubusercontent.com/gazebosim/gz-sim/{rev}/{path}'
    data=urllib.request.urlopen(url,timeout=30).read();name=path.replace('/','__');(dest/name).write_bytes(data)
    manifest.append(dict(name=name,url=url,sha256=hashlib.sha256(data).hexdigest()))
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(paths)
