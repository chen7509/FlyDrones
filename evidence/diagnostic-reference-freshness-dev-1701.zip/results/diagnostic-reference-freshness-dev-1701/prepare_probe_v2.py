from pathlib import Path
b=Path(__file__).resolve().parent
s=(b/'native-api-probe.cc').read_text()
s=s.replace('#include <gz/sim/components/WorldPose.hh>\n','').replace('components/WorldLinearVelocity.hh','components/LinearVelocity.hh').replace('components/WorldLinearAcceleration.hh','components/LinearAcceleration.hh').replace('components/WorldAngularVelocity.hh','components/AngularVelocity.hh')
with (b/'native-api-probe-v2.cc').open('x') as f:f.write(s)
s=(b/'probe_capability.py').read_text().replace('native-api-probe.cc','native-api-probe-v2.cc').replace("base/'native-api-probe'","base/'native-api-probe-v2'").replace('capability.json','capability-v2.json')
with (b/'probe_capability_v2.py').open('x') as f:f.write(s)
