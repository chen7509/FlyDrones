// Compile/run capability probe only: no simulator, physics step or sensor.
#include <cmath>
#include <iostream>
#include <limits>
#include <gz/sim/EntityComponentManager.hh>
#include <gz/sim/components/Name.hh>
#include <gz/sim/components/ParentEntity.hh>
#include <gz/sim/components/Pose.hh>
#include <gz/sim/components/LinearVelocity.hh>
#include <gz/sim/components/LinearAcceleration.hh>
#include <gz/sim/components/AngularVelocity.hh>
int main() {
  gz::sim::EntityComponentManager ecm;
  auto parent=ecm.CreateEntity(); auto child=ecm.CreateEntity();
  if (!ecm.SetParentEntity(child,parent)) return 1;
  namespace c=gz::sim::components;
  ecm.CreateComponent(child,c::Name("isolated_diagnostic_probe"));
  ecm.CreateComponent(child,c::ParentEntity(parent));
  ecm.CreateComponent(child,c::Pose(gz::math::Pose3d::Zero));
  auto nan=std::numeric_limits<double>::quiet_NaN();
  auto value=gz::math::Vector3d(nan,nan,nan);
  ecm.CreateComponent(child,c::WorldLinearVelocity(value));
  ecm.CreateComponent(child,c::WorldLinearAcceleration(value));
  ecm.CreateComponent(child,c::WorldAngularVelocity(value));
  ecm.CreateComponent(child,c::WorldPose(gz::math::Pose3d::Zero));
  auto velocity=ecm.Component<c::WorldLinearVelocity>(child);
  if (!velocity || !std::isnan(velocity->Data().X())) return 2;
  velocity->Data()=gz::math::Vector3d::Zero;
  if (velocity->Data()!=gz::math::Vector3d::Zero) return 3;
  std::cout << "native component creation/read/write available; backend refresh NOT tested\n";
}
