import hashlib,importlib,json,subprocess,time
from pathlib import Path
import gz.sim8 as sim
base=Path(__file__).resolve().parent
report=dict(ecm_public_methods=[x for x in dir(sim.EntityComponentManager) if not x.startswith('_')],wall_ns=time.time_ns())
try:importlib.import_module('gz.sim8.components')
except ImportError as e:report['components_import_error']=repr(e)
report['pkg_config_version']=subprocess.check_output(['pkg-config','--modversion','gz-sim8'],text=True).strip()
flags=subprocess.check_output(['pkg-config','--cflags','--libs','gz-sim8'],text=True).split()
cmd=['g++','-std=c++17',str(base/'native-api-probe-v2.cc'),'-o',str(base/'native-api-probe-v2'),*flags]
build=subprocess.run(cmd,capture_output=True,text=True,timeout=90)
report['build']=dict(command=cmd,returncode=build.returncode,stdout=build.stdout,stderr=build.stderr)
if build.returncode==0:
    run=subprocess.run([str(base/'native-api-probe-v2')],capture_output=True,text=True,timeout=10)
    report['run']=dict(returncode=run.returncode,stdout=run.stdout,stderr=run.stderr)
    report['binary_sha256']=hashlib.sha256((base/'native-api-probe-v2').read_bytes()).hexdigest()
with (base/'capability-v2.json').open('x') as f:json.dump(report,f,indent=2)
print(json.dumps(report,indent=2))
