import json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[2];base=Path(__file__).resolve().parent
r=subprocess.run(['python','-m','ruff','check','.','--output-format','json'],cwd=root,capture_output=True,text=True)
rows=json.loads(r.stdout);files=sorted({Path(x['filename']).relative_to(root).as_posix() for x in rows})
changed=[n for n in files if subprocess.check_output(['git','diff','b658a32','--',n],cwd=root)]
out=dict(whole_ruff_exit=r.returncode,errors=len(rows),files=len(files),files_changed_since_base=changed,diagnostics=rows)
with (base/'publication-checks.json').open('x',encoding='utf-8') as f:json.dump(out,f,indent=2)
print(json.dumps({k:v for k,v in out.items() if k!='diagnostics'}))
