import hashlib,json,subprocess,sys,zipfile
from pathlib import Path
base=Path(__file__).resolve().parent;root=base.parents[1];sys.path[:0]=[str(root),str(root/'src')]
from tools.benchmark.diagnostic_reference_freshness import analyze_reference
archive=root/'evidence/readiness-anchor-dev-1701.zip'
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
assert digest=='acd5da7efa70312dbf5b75f6e1a2cbfe25ff286e1ee70e86dc9a3dba101458ba'
prefix='results/readiness-anchor-dev-1701/capture-v1/'
consumed={}
with zipfile.ZipFile(archive) as z:
    manifest=json.loads(z.read('SHA256-MANIFEST.json'))
    def read(name):
        path=prefix+name;data=z.read(path);m=manifest[path]
        assert len(data)==m['bytes'] and hashlib.sha256(data).hexdigest()==m['sha256']
        consumed[path]=m
        return data
    rows=[json.loads(x) for x in read('physics-substeps.jsonl').splitlines()]
    forces=[json.loads(x) for x in read('motion-force.jsonl').splitlines()]
    anchor=json.loads(read('readiness-anchor.json'))
    result=json.loads(read('result.json'))
assert result['status']=='capture_completed'
analysis=analyze_reference(rows)
post={r['sim_ns']:r for r in rows if r['phase']=='post'}
boundaries=[];previous=0.
for force in forces:
    lateral=force['force_world_n'][1]
    if lateral != previous:
        ns=force['sim_ns'];boundaries.append(dict(command=force,
            samples=[post[t] for t in range(ns-2_000_000,ns+3_000_000,1_000_000) if t in post]))
    previous=lateral
report=dict(archive_sha256=digest,consumed=consumed,producer=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    analysis=analysis,force_boundaries=boundaries,anchor=anchor['anchor_ns'],estimator_run=False,simulator_run=False,
    notes='No repaired input, differentiated truth or qualification; contradictory samples preserved verbatim.')
with (base/'audit.json').open('x',encoding='utf-8') as f:json.dump(report,f,indent=2,allow_nan=False)
print(json.dumps(analysis,indent=2,allow_nan=False))
