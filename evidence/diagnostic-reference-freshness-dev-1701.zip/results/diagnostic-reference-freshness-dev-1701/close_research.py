import hashlib,json,subprocess,sys,time
from pathlib import Path
base=Path(__file__).resolve().parent;root=base.parents[1];sys.path[:0]=[str(root),str(root/'src')]
from tools.benchmark.capture_disarmed_sensors import active_resources
headers=[]
for name in ['Pose.hh','LinearVelocity.hh','LinearAcceleration.hh','AngularVelocity.hh','ParentEntity.hh','Component.hh']:
    path=Path('/usr/include/gz/sim8/gz/sim/components')/name
    data=path.read_bytes();(base/'sources'/('installed-'+name)).write_bytes(data)
    headers.append(dict(path=str(path),sha256=hashlib.sha256(data).hexdigest()))
report=dict(headers=headers,compiler=subprocess.check_output(['g++','--version'],text=True),
    linked_libraries=subprocess.check_output(['ldd',str(base/'native-api-probe-v2')],text=True),
    resources=active_resources(),wall_ns=time.time_ns(),simulator_or_estimator_started=False)
with (base/'runtime-capability-provenance.json').open('x') as f:json.dump(report,f,indent=2)
print(json.dumps(dict(resources=report['resources'],headers=len(headers))))
