import hashlib
import json
import zipfile
from pathlib import Path

root=Path.cwd();raw=Path(__file__).resolve().parent;name='entry-context-v4-production-dev-1701'
archive=root/'evidence'/f'{name}.zip';mapping=root/'evidence'/f'{name}.sha256.json'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,v):
    with p.open('xb') as f:f.write(json.dumps(v,ensure_ascii=False,indent=2).encode())
private=raw/'initial-resource-private.json';inventory=json.loads(private.read_bytes());rows=inventory['windows']+inventory['wsl']
needles={r['argv_sha256'].encode() for r in rows if r.get('argv_sha256')!=sha(b'')}
explicit=['tools/benchmark/native_entry_context_v4.py','tests/benchmark/test_native_entry_context_v4.py',
 'tools/benchmark/native_loader_paths_v4.py','tools/benchmark/software_process_boundary.py','tests/benchmark/conftest.py','tools/benchmark/declared_runtime_snapshot.py',
 'docs/TARGET_BEARING_ENTRY_CONTEXT_V4_PRODUCTION_REPORT.md','docs/superpowers/plans/2026-10-15-loader-selected-path-production.md','docs/superpowers/specs/2026-10-15-loader-selected-path-production-design.md',
 'docs/TARGET_BEARING_STATIC_V3_HARNESS_FAILURE_REPORT.md','docs/TARGET_BEARING_LOADER_SELECTED_PATH_RESEARCH_REPORT.md','docs/TARGET_BEARING_LOADER_PATH_IDENTITY_PRODUCTION_REPORT.md',
 'evidence/flydrones-history-through-admitted-executor-dev-1701.json','evidence/flydrones-history-through-loader-path-research-dev-1701.json','evidence/loader-path-identity-production-publication.json']
files={root/p for p in explicit}|{p for p in raw.rglob('*') if p.is_file() and p!=private and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo')}
members=[]
for p in sorted(files):
    b=p.read_bytes();path=p.relative_to(root).as_posix()
    assert not any(n in b for n in needles),path
    if p.suffix=='.json':
        try:stack=[json.loads(b.decode('utf-8-sig'))]
        except (ValueError,UnicodeError):stack=[]
        while stack:
            x=stack.pop()
            if isinstance(x,dict):
                if {'pid','name','argv_sha256'}<=x.keys():
                    assert not any(all(x.get(k)==r.get(k) for k in ('pid','name','argv_sha256')) for r in rows),path
                stack.extend(x.values())
            elif isinstance(x,list):stack.extend(x)
    members.append(dict(path=path,bytes=len(b),sha256=sha(b)))
write(mapping,dict(schema='entry-context-v4-production-exact-map-v1',members=members,
 private_excluded=dict(path=private.relative_to(root).as_posix(),bytes=private.stat().st_size,sha256=sha(private.read_bytes())),
 nonempty_private_argv_hashes=len(needles),scope='Task2 software only;Task3..5 pending;all8/readinessfalse;no native dispatch authorization'))
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for row in members:z.write(root/row['path'],row['path'])
    z.write(mapping,mapping.relative_to(root).as_posix())
receipt=dict(archive=archive.relative_to(root).as_posix(),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),members=len(members)+1,mapped_members=len(members),
 manifest_sha256=sha(mapping.read_bytes()),preseal_exact_set=[r['path'] for r in members],scope='Task2 first2software boxesdone,lastpublicationpending;Task3..5pending;receipt/audit/publication/helpers outside sealed set')
write(raw/'seal-receipt.json',receipt)
print(json.dumps({k:v for k,v in receipt.items() if k!='preseal_exact_set'}))
