import hashlib
import json
from pathlib import Path

root=Path.cwd();raw=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes().decode('utf-8-sig'))
def save(name,v):
    with (raw/name).open('xb') as f:f.write(json.dumps(v,ensure_ascii=False,indent=2).encode())
old=load(root/'results/loader-selected-path-production-dev-1701/historical-archives-postsoftware.json')['members']
old.append(dict(path='evidence/loader-path-identity-production-dev-1701.zip',bytes=1610283,sha256='18459583fd919c50ddf0b1302c85d0672bc4a892003596a2bf7a3be8c59fca1b'))
assert len(old)==290 and {x['path'] for x in old}=={p.relative_to(root).as_posix() for p in (root/'evidence').glob('*.zip')}
for row in old:
    d=hashlib.sha256();size=0
    with (root/row['path']).open('rb') as f:
        while b:=f.read(1024*1024):d.update(b);size+=len(b)
    assert size==row['bytes'] and d.hexdigest()==row['sha256'],row['path']
save('historical-archives-postsoftware.json',dict(count=len(old),bytes=sum(x['bytes'] for x in old),members=old,scope='POSTsoftware preservation only;not retroactive target/source prepin'))
before=load(raw/'product-before.json')
assert all(sha((root/r['path']).read_bytes())==r['sha256'] for r in before)
save('product-after.json',dict(old_tracked_count=len(before),old_all_byte_same=True,new_product_files=['tools/benchmark/native_entry_context_v4.py','tests/benchmark/test_native_entry_context_v4.py']))
assert not (root/'results/target-bearing-runtime-freeze-v4-dev-1701').exists() and not (root/'results/target-bearing-physical-capture-dev-1701').exists()
save('software-absence.json',dict(v4_fixed_parent_absent=True,physical_fixed_attempt_absent=True,scope='software-phase observation,not native admission'))
print('290 oldZIP/825381846B unchanged;809oldproduct unchanged;no v4 or physical attempt')
