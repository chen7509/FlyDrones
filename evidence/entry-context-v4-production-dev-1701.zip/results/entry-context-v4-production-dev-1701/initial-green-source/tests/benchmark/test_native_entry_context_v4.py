"""Actual v4 producer with inert OS/query/filesystem protocols, no native acceptance."""
import copy
import hashlib
import importlib
import json
import posixpath
import stat
import subprocess
from pathlib import Path
from types import SimpleNamespace

import pytest

from tools.benchmark.software_process_boundary import guard_required

RENDERER='/sdk/libgz-rendering8-ogre2.so.8.2.3'
EXT='/sdk/_fixture.cpython-312-x86_64-linux-gnu.so'
NUMPY='/usr/local/lib/python3.12/dist-packages/numpy/_core/_multiarray_umath.cpython-312-x86_64-linux-gnu.so'
OGRE='/usr/lib/x86_64-linux-gnu/OGRE-2.3'
NAMES=['libOgreNextMain.so.2.3.1','libOgreNextHlmsPbs.so.2.3.1','libOgreNextPlanarReflections.so.2.3.1']
META=b"ELF Header:\n  Class: ELF64\n  Data: 2's complement, little endian\n  Type: DYN (Shared object file)\n  Machine: Advanced Micro Devices X86-64\n  Number of program headers: 2\nProgram Headers:\n  Type Offset VirtAddr PhysAddr FileSiz MemSiz Flg Align\n  LOAD 0 0 0 1 1 R 1\n  DYNAMIC 0 0 0 1 1 RW 1\n Section to Segment mapping:\nSymbol table '.dynsym' contains 4 entries:\n Num: Value Size Type Bind Vis Ndx Name\n 0: 0 0 NOTYPE LOCAL DEFAULT UND\n 1: 0 0 NOTYPE GLOBAL DEFAULT UND PyDict_New\n 2: 0 0 NOTYPE WEAK DEFAULT UND __gmon_start__\n 3: 10 16 FUNC GLOBAL DEFAULT 1 PyInit__fixture\n"


def test_guard_is_installed_without_process_backend():
    assert guard_required(Path(__file__).name)
    assert subprocess.Popen._execute_child.__name__=='denied'


class MemoryFiles:
    supported=True
    def __init__(self):
        self.data={};self.ids={};self.dirs={'/'};self.aliases={};self.fd={};self.offset={};self.opened=[]
    def add(self,path,data=b'\x7fELFfixture'):
        self.data[path]=data;self.ids[path]=len(self.ids)+100
        parent=posixpath.dirname(path)
        while parent!='/':self.dirs.add(parent);parent=posixpath.dirname(parent)
        return path
    def lstat(self,path):
        if path in self.dirs:return SimpleNamespace(st_dev=1,st_ino=1,st_mode=stat.S_IFDIR|0o755,st_size=0,st_mtime_ns=1,st_ctime_ns=1)
        p=self.aliases.get(path,path);data=self.data[p]
        return SimpleNamespace(st_dev=1,st_ino=self.ids[p],st_mode=stat.S_IFREG|0o755,st_size=len(data),st_mtime_ns=1,st_ctime_ns=1)
    def file_record(self,path):
        assert path.startswith('/') and '..' not in path.split('/')
        resolved=self.aliases.get(path,path);info=self.lstat(path);data=self.data[resolved]
        return dict(requested=path,resolved=resolved,links=[],identity=dict(device=info.st_dev,inode=info.st_ino,mode=info.st_mode,size=info.st_size,mtime_ns=1,ctime_ns=1),path_identity=dict(device=info.st_dev,inode=info.st_ino,mode=info.st_mode,size=info.st_size,mtime_ns=1,ctime_ns=1),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
    def readlink(self,path):raise AssertionError('no links in this explicit integration fixture')
    def open(self,path):
        self.opened.append(path);canonical=self.aliases.get(path,path);fd=len(self.fd)+10;self.fd[fd]=canonical;self.offset[fd]=0;return fd
    def fstat(self,fd):return self.lstat(self.fd[fd])
    def read(self,fd,size):
        p=self.fd[fd];data=self.data[p][self.offset[fd]:self.offset[fd]+size];self.offset[fd]+=len(data);return data
    def close(self,fd):pass


@pytest.fixture
def setup(tmp_path,monkeypatch):
    m=importlib.import_module('tools.benchmark.native_entry_context_v4')
    paths=importlib.import_module('tools.benchmark.native_loader_paths_v4');fs=MemoryFiles()
    tools=dict(ldd='/usr/bin/ldd',readelf='/usr/bin/readelf',python='/usr/bin/python3',loader='/lib64/ld-linux-x86-64.so.2')
    for p in [*tools.values(),RENDERER,EXT,NUMPY,'/sdk/unused.so',*[OGRE+'/'+n for n in NAMES]]:fs.add(p)
    root=Path(__file__).resolve().parents[2]
    retained={n:json.loads((root/'results/loader-selected-path-research-dev-1701/retained-v3'/f'query-{n:04d}.json').read_bytes()) for n in (63,64)}
    numpy_trace=bytes.fromhex(retained[64]['stdout_hex'])
    for line in numpy_trace.decode().splitlines():
        token=line.split(' => ')[-1].strip().split(' (0x')[0]
        if token.startswith('/'):
            # Explicit fixture-only mapping of the three retained spelling aliases.
            canonical=token.replace('/numpy/_core/../../numpy.libs/','/numpy.libs/')
            if canonical not in fs.data:fs.add(canonical)
            fs.aliases[token]=canonical
    context=dict(schema='python-extension-context-v1',pid=123,interpreter=fs.file_record(tools['python']),implementation='cpython',version='fixture CPython3.12.3',version_info=[3,12,3],soabi='cpython-312-x86_64-linux-gnu',ext_suffix='.cpython-312-x86_64-linux-gnu.so',dlopen_flags=2,modules=[dict(name='_fixture',origin=fs.file_record(EXT),module_file=EXT,spec_origin=EXT,loader='_frozen_importlib_external.ExtensionFileLoader')])
    observed=copy.deepcopy(context);calls=[]
    def run(argv,env,cwd):
        calls.append((copy.deepcopy(argv),copy.deepcopy(env),cwd))
        if argv[-1]=='--version':data=b'fixture tool version 1\n'
        elif argv[1]=='-d':
            if argv[-1]==EXT:data=b'Dynamic section at offset 0x1 contains 1 entries:\n 0x0 (NULL) 0x0\n'
            elif argv[-1]==NUMPY:data=bytes.fromhex(retained[63]['stdout_hex'])
            else:data=b'Dynamic section at offset 0x1 contains 5 entries:\n'+b''.join((' 0x1 (NEEDED) Shared library: ['+n+']\n').encode() for n in NAMES)+(' 0x1d (RUNPATH) Library runpath: ['+OGRE+']\n 0x0 (NULL) 0x0\n').encode()
        elif argv[1]=='-W':data=META
        elif argv[-1]==EXT:data=b'\tstatically linked\n'
        elif argv[-1]==NUMPY:data=numpy_trace
        else:data=b''.join((n+' => '+OGRE+'/'+n+' (0x1234)\n').encode() for n in NAMES)
        return dict(argv=argv,env=env,cwd=cwd,pid=321,returncode=0,error=None,timed_out=False,output_limited=False,owned_child_waited=True,reader_complete=True,cleanup=dict(exit=0,descendants='unknown'),stdout_hex=data.hex(),stderr_hex='',started_monotonic_ns=100,ended_monotonic_ns=200,started_utc_ns=1000,ended_utc_ns=2000,limits=dict(stream_bytes=2097152,timeout_seconds=10,terminate_seconds=5,kill_seconds=5))
    monkeypatch.setattr(m,'file_record',fs.file_record);monkeypatch.setattr(m,'tool_paths',lambda:copy.deepcopy(tools))
    monkeypatch.setattr(m,'query_cwd',lambda:'/work');monkeypatch.setattr(m,'collect_python_context',lambda:copy.deepcopy(observed))
    monkeypatch.setattr(m,'is_elf',lambda p:fs.data[fs.aliases.get(p,p)].startswith(b'\x7fELF'))
    monkeypatch.setattr(m,'_run',run);monkeypatch.setattr(paths,'_FS',fs)
    entries={'renderer':[RENDERER],'python':[EXT],'numpy':[NUMPY]}
    return SimpleNamespace(m=m,fs=fs,tools=tools,context=context,observed=observed,calls=calls,run=run,entries=entries,out=tmp_path/'bill',retained=retained)


def produce(s):
    return s.m.discover_entry_context_v4(s.entries,['/sdk/unused.so'],s.context,[],'/agent/lib',s.out)


def test_real_producer_uses_typed_paths_all_retained_numpy_lines(setup):
    s=setup;b=produce(s)
    numpy=b['entries'][2]
    assert len(numpy['selected'])==10 and sum('..' in p.split('/') for p in numpy['selected'])==3
    records=[b['selected_paths'][i] for i in numpy['path_records']]
    assert [r['raw_path'] for r in records]==numpy['selected']
    assert len(records)==10 and all(r['complete'] for r in records)
    assert len({f['requested'] for f in b['files']})==len(b['files'])
    assert all('..' not in f['requested'].split('/') for f in b['files'])
    assert b['candidates'][0]['role']=='candidate_only' and b['candidates'][0]['runtime_closure_qualified'] is False
    assert not any('/sdk/unused.so' in argv for argv,_,_ in s.calls)
    assert b['runtime_closure_qualified'] is False and b['complete'] is True
    s.m.audit_entry_context_bill_v4(b,baseline_files=b['files'],python_context=s.context)


def test_empty_python_selected_keeps_self_and_symbols(setup):
    s=setup;b=produce(s);row=b['entries'][1]
    assert row['entry_kind']=='python_extension_entry' and row['selected']==[] and row['dynamic']['needed']==[]
    assert row['runtime_import_verified'] is False and row['symbols_resolved'] is False
    assert {x['name'] for x in row['elf_metadata']['symbols'] if x['ndx']=='UND'}=={'','PyDict_New','__gmon_start__'}
    assert EXT in {f['requested'] for f in b['files']}
    with pytest.raises(ValueError):s.m.audit_entry_context_bill_v4(b,baseline_files=[f for f in b['files'] if f['requested']!=EXT],python_context=s.context)


def test_identical_invocation_across_roles_shares_query_only(setup):
    s=setup;s.entries['same-explicit-context']=[RENDERER];b=produce(s)
    assert sum(a==[s.tools['ldd'],RENDERER] for a,_,_ in s.calls)==1
    assert b['entries'][-1]['alias_of']==0 and b['entries'][-1]['source_role']=='same-explicit-context'
    s.m.audit_entry_context_bill_v4(b,baseline_files=b['files'],python_context=s.context)


@pytest.mark.parametrize('kind',['hardlink','canonical_alias'])
def test_conflicting_load_spelling_refuses_before_any_query(setup,kind):
    s=setup;other='/different/load-origin.so';s.fs.add(other)
    if kind=='hardlink':s.fs.ids[other]=s.fs.ids[RENDERER]
    else:s.fs.aliases[other]=RENDERER
    s.entries['conflicting']=[other]
    with pytest.raises(ValueError,match='invocation|origin|alias'):produce(s)
    assert not s.calls


@pytest.mark.parametrize('fault',['empty','extra','missing','stderr','timeout','cap','partial','nonzero','mutation','postcontext'])
def test_actual_pipeline_retains_index_raw_and_final_attempts(setup,monkeypatch,fault):
    s=setup
    def broken(argv,env,cwd):
        row=s.run(argv,env,cwd)
        if argv==[s.tools['ldd'],NUMPY]:
            if fault=='empty':row['stdout_hex']=''
            if fault=='extra':row['stdout_hex']+=b'unknown\n'.hex()
            if fault=='missing':row['stdout_hex']=b'libmissing.so => not found\n'.hex()
            if fault=='stderr':row['stderr_hex']=b'error'.hex()
            if fault=='timeout':row.update(error='fixture timeout',timed_out=True,returncode=-15,cleanup=dict(exit=-15,descendants='unknown'))
            if fault=='cap':row['output_limited']=True
            if fault=='partial':row['reader_complete']=False
            if fault=='nonzero':row.update(returncode=1,cleanup=dict(exit=1,descendants='unknown'))
            if fault=='mutation':s.fs.data[NUMPY]=b'changed input'
            if fault=='postcontext':s.observed['modules']=[]
        return row
    monkeypatch.setattr(s.m,'_run',broken)
    with pytest.raises(ValueError):produce(s)
    b=json.loads((s.out/'entry-bill.json').read_bytes())
    assert not b['complete'] and b['error'] and b['entries'][-1]['ldd_query']==len(b['queries'])
    assert b['queries'][-1]['record']['stdout_hex'] or fault=='empty'
    assert set(b['final_observations'])=={'context','declared','files','tools','candidates','selected_paths'}
    assert all(v['attempted'] for v in b['final_observations'].values())


@pytest.mark.parametrize('fault',['phrase','initializer','program','headers','truncated_symbols','dynamic','role','abi','origin'])
def test_zero_needed_stays_strict(setup,monkeypatch,fault):
    s=setup
    if fault=='role':s.context['modules']=[];s.observed['modules']=[]
    if fault=='abi':s.context['soabi']='cpython-311-x86_64-linux-gnu'
    if fault=='origin':s.context['modules'][0]['spec_origin']='/wrong.so'
    def broken(argv,env,cwd):
        r=s.run(argv,env,cwd);data=bytes.fromhex(r['stdout_hex'])
        if argv[-1]==EXT:
            if argv[0]==s.tools['ldd'] and fault=='phrase':data+=b'\n'
            if argv[1]=='-W':
                if fault=='initializer':data=data.replace(b'PyInit__fixture',b'PyInit_other')
                if fault=='program':data=data.replace(b'DYNAMIC',b'INTERP')
                if fault=='headers':data=data.replace(b'Program Headers:',b' Class: ELF32\nProgram Headers:')
                if fault=='truncated_symbols':data=data[:data.index(b' 3:')]
            if argv[1]=='-d' and fault=='dynamic':data=data.split(b'\n')[0]+b'\n'
        r['stdout_hex']=data.hex();return r
    monkeypatch.setattr(s.m,'_run',broken)
    with pytest.raises(ValueError):produce(s)


@pytest.mark.parametrize('fault',['token','querybytes','alias','file','candidate','extraquery','tool','self','context','agent'])
def test_auditor_rederives_complete_bill(setup,fault):
    s=setup;b=produce(s);changed=copy.deepcopy(b)
    if fault=='token':changed['selected_paths'][0]['trace']['origin']['token_span'][0]+=1
    if fault=='querybytes':changed['queries'][-1]['record']['stdout_hex']=''
    if fault=='alias':changed['entries'][0]['selected'][0]='/forged.so'
    if fault=='file':changed['files'].pop()
    if fault=='candidate':changed['candidates']=[]
    if fault=='extraquery':changed['queries'].append(copy.deepcopy(changed['queries'][-1]))
    if fault=='tool':changed['tools_after']['ldd']['sha256']='0'*64
    if fault=='self':changed['entries'][1]['file']['sha256']='0'*64
    if fault=='context':changed['observed_context_after']['modules']=[]
    if fault=='agent':changed['agent_paths']=['/sdk/unused.so']
    with pytest.raises(ValueError):s.m.audit_entry_context_bill_v4(changed,baseline_files=b['files'],python_context=s.context)
