import hashlib
import json
import subprocess
from pathlib import Path

root=Path.cwd();raw=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def save(name,b):
    with (raw/name).open('xb') as f:f.write(b)
files=subprocess.check_output(['git','ls-files','-z','src','tools','tests','configs']).split(b'\0')
save('product-before.json',json.dumps([dict(path=x.decode(),bytes=len(b:=(root/x.decode()).read_bytes()),sha256=sha(b)) for x in files if x],indent=2).encode())
save('ancestor-instructions.json',json.dumps([dict(path=str(p/'AGENTS.md'),text=(p/'AGENTS.md').read_text(encoding='utf-8-sig')) for p in [root,*root.parents] if (p/'AGENTS.md').is_file()],indent=2).encode())
history=[]
for name,size,digest in [('flydrones-history-through-admitted-executor-dev-1701.json',89359,'c88840b6f58dea4e7e4931683c4993b4fc3b8eb55887807994b6381ef6c2b989'),('flydrones-history-through-loader-path-research-dev-1701.json',80946,'80dfb89ed0e51e639bd6b24b115cbcd3c444b967614e2e8334d55962c262b824')]:
    p=root/'evidence'/name;b=p.read_bytes();assert len(b)==size and sha(b)==digest
    obj=json.loads(b.decode('utf-8-sig'));history.append(dict(path=str(p.relative_to(root)),bytes=len(b),sha256=sha(b),full_json_read=True,keys=list(obj)))
save('history-read.json',json.dumps(history,indent=2).encode())
assert not (root/'results/target-bearing-runtime-freeze-v4-dev-1701').exists()
assert not (root/'results/target-bearing-physical-capture-dev-1701').exists()
save('initial-readonly.py',(root/'results/loader-selected-path-production-dev-1701/initial-readonly.py').read_bytes())
p=subprocess.run(['python',str(raw/'initial-readonly.py')],capture_output=True,timeout=65)
save('initial-readonly.stdout',p.stdout);save('initial-readonly.stderr',p.stderr)
save('initial-readonly-return.json',json.dumps(dict(exit=p.returncode,helper_sha256=sha((raw/'initial-readonly.py').read_bytes()),scope='single initial readonly snapshot; no target commands/admission')).encode())
assert p.returncode==0,p.stderr
print(p.stdout.decode())
