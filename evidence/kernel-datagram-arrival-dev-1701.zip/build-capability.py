"""One installed-header capability compile; no socket or source process."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent / "capability-v1"
out.mkdir()
source = root / "tools/benchmark/kernel_timestamp_abi.c"
compiler = Path("/usr/bin/gcc")
env = {"PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C"}
commands = []

def run(name, argv, timeout=10):
    started = time.monotonic()
    result = subprocess.run(argv, env=env, capture_output=True, timeout=timeout)
    (out / (name + ".stdout")).write_bytes(result.stdout)
    (out / (name + ".stderr")).write_bytes(result.stderr)
    commands.append({"name": name, "argv": argv, "returncode": result.returncode,
                     "elapsed_wall_s": time.monotonic() - started})
    (out / "commands.json").write_text(json.dumps(commands, indent=2))
    if result.returncode:
        raise RuntimeError(name + " failed; no repair/retry in this variant")
    return result.stdout

def identity(path):
    path = Path(path)
    resolved = path.resolve(strict=True)
    before = resolved.stat()
    with resolved.open("rb") as handle:
        digest = hashlib.file_digest(handle, "sha256").hexdigest()
    after = resolved.stat()
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (
            after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
        raise RuntimeError("capability input changed while hashing")
    return {"requested": str(path), "resolved": str(resolved), "sha256": digest,
            "bytes": after.st_size, "device": after.st_dev, "inode": after.st_ino,
            "mtime_ns": after.st_mtime_ns}

def dependencies(data):
    text = data.decode().replace("\\\n", " ")
    if text.count(":") != 1 or "\\" in text:
        raise RuntimeError("unsupported narrow compiler dependency format")
    return {str(Path(name).resolve(strict=True)) for name in text.split(":", 1)[1].split()}

run("compiler-version", [str(compiler), "--version"])
run("kernel", ["/usr/bin/uname", "-a"])
flags = ["-std=c11", "-Wall", "-Wextra", "-Werror"]
dependency_bytes = run("dependencies-before", [str(compiler), *flags, "-M", str(source)])
headers = dependencies(dependency_bytes)
tools = {str(compiler), "/usr/bin/as", "/usr/bin/ld"}
tools.add(run("cc1-path", [str(compiler), "-print-prog-name=cc1"]).decode().strip())
paths = headers | tools
before = {name: identity(name) for name in sorted(paths)}
(out / "inputs-before.json").write_text(json.dumps(before, indent=2))
probe = out / "kernel_timestamp_abi"
run("compile", [str(compiler), *flags, "-MD", "-MF", str(out / "compiled-deps.d"), str(source), "-o", str(probe)])
if dependencies((out / "compiled-deps.d").read_bytes()) != headers:
    raise RuntimeError("actual compiler dependency set differs from predeclared set")
abi = run("abi", [str(probe)], 5)
if len(abi) > 4096 or json.loads(abi)["schema"] != "flydrones.kernel_timestampns_new_abi.v1":
    raise RuntimeError("ABI output invalid")
after = {name: identity(name) for name in sorted(paths)}
if after != before:
    raise RuntimeError("capability inputs drifted across build")
run("probe-ldd", ["/usr/bin/ldd", str(probe)])
(out / "abi.json").write_bytes(abi)
record = {"commands": commands, "inputs_before": before, "inputs_after": after,
          "inputs_stable": True, "probe": identity(probe), "abi_sha256": hashlib.sha256(abi).hexdigest(),
          "pid": os.getpid(), "scope": "read-only installed header compile, not socket or simulator run",
          "installed_kernel_equivalent_to_upstream": False, "runtime_closure_qualified": False}
(out / "build.json").write_text(json.dumps(record, indent=2))
print(json.dumps({"abi": json.loads(abi), "abi_sha256": record["abi_sha256"], "probe_sha256": record["probe"]["sha256"]}))
