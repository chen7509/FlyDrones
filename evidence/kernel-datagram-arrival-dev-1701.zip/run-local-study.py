"""Single prospective study dispatcher; no flight/source process."""
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.benchmark.probe_kernel_datagram_arrival import CONDITIONS, SOURCES, validate_profile

OUT = Path(__file__).parent / "study-v1"
OUT.mkdir()


def write(name, value):
    with (OUT / name).open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


selected = [*SOURCES, CONDITIONS["abi_path"], CONDITIONS["probe_path"],
            "tests/fixtures/kernel_timestampns/new-abi-x86_64.json",
            "tests/benchmark/test_kernel_datagram_arrival.py",
            "tests/benchmark/test_kernel_arrival_study_profile.py",
            "docs/superpowers/specs/2026-10-12-kernel-datagram-arrival-design.md",
            "docs/superpowers/plans/2026-10-12-kernel-datagram-arrival.md"]
before = {name: sha(ROOT / name) for name in selected}
for name in selected:
    copy = OUT / "inputs" / name
    copy.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / name, copy)
    if sha(copy) != before[name]:
        raise ValueError("dispatch source copy mismatch")
write("inputs-before.json", before)
profile = {**CONDITIONS, "sources": {name: before[name] for name in SOURCES},
           "abi_sha256": before[CONDITIONS["abi_path"]], "probe_sha256": before[CONDITIONS["probe_path"]]}
write("study-profile.json", profile)
path = OUT / "study-profile.json"
raw = path.read_bytes()
digest = hashlib.sha256(raw).hexdigest()
validate_profile(raw, digest)
command = ["/usr/bin/timeout", "--kill-after=2s", "20s", "/usr/bin/python3", "-B",
           str(ROOT / "tools/benchmark/probe_kernel_datagram_arrival.py"),
           "--profile", str(path), "--profile-sha256", digest, "--output", str(OUT / "capture-v1")]
write("dispatch.json", {"command": command, "profile_sha256": digest,
                        "dispatched_realtime_ns": time.time_ns(), "python": sys.version,
                        "kernel": platform.release(), "pid": os.getpid(),
                        "resource_boundary": "single small owned opaque loopback study; no simulator/model load",
                        "full_runtime_closure_qualified": False})
started = time.monotonic_ns()
with (OUT / "stdout.txt").open("xb") as stdout, (OUT / "stderr.txt").open("xb") as stderr:
    child = subprocess.Popen(command, cwd=ROOT, stdout=stdout, stderr=stderr)
    code = child.wait(timeout=25)
after = {name: sha(ROOT / name) for name in selected}
write("inputs-after.json", after)
write("completion.json", {"exit_code": code, "child_pid": child.pid,
                          "elapsed_wall_ns": time.monotonic_ns() - started,
                          "selected_inputs_stable": before == after,
                          "profile_stable": digest == sha(path),
                          "full_runtime_closure_qualified": False,
                          "all_unrelated_resources_released": None})
if code != 0 or before != after or digest != sha(path):
    raise RuntimeError("single local attempt failed; no retry")
print((OUT / "stdout.txt").read_text())
