import hashlib
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).parent
verification = json.loads((BASE / "final-v1/execution.json").read_text())
assert verification["selected_source_unchanged"]
assert all(row["exit_code"] == 0 for row in verification["commands"])
for name, expected in verification["source_after"].items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected
audit = json.loads((BASE / "audit-v2.json").read_text(encoding="utf-8-sig"))
assert audit["trial_status"] == "failed" and not audit["kernel_receive_instant_qualified"]
for name in ["docs/KERNEL_DATAGRAM_TIMESTAMP_REPORT.md",
             "docs/superpowers/specs/2026-10-12-kernel-datagram-arrival-design.md",
             "docs/superpowers/plans/2026-10-12-kernel-datagram-arrival.md"]:
    target = BASE / "documents" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / name, target)
files = sorted(path for path in BASE.rglob("*") if path.is_file() and path.suffix != ".pyc")
members = {str(path.relative_to(BASE)).replace("\\", "/"): {
    "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size} for path in files}
target = ROOT / "evidence/kernel-datagram-arrival-dev-1701.zip"
with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED) as archive:
    for path in files:
        archive.write(path, str(path.relative_to(BASE)).replace("\\", "/"))
    archive.writestr("member-hashes.json", json.dumps(members, indent=2))
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(members) | {"member-hashes.json"}
    for name, expected in members.items():
        raw = archive.read(name)
        assert len(raw) == expected["bytes"] and hashlib.sha256(raw).hexdigest() == expected["sha256"]
digest = hashlib.sha256(target.read_bytes()).hexdigest()
with target.with_suffix(".sha256").open("x", encoding="ascii") as stream:
    stream.write(digest + "  " + target.name + "\n")
record = {"sha256": digest, "members": len(members) + 1, "bytes": target.stat().st_size,
          "all_member_hashes_and_crc_verified": True, "trial_status": "failed",
          "software_checks_qualified_in_scoped_tests": True, "physical_or_source_qualification": False}
with (BASE / "seal.json").open("x") as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record, indent=2))
