# Kernel datagram arrival evidence plan

Existing user approval covers this independent low-resource transport work. Use current worktree and PR65; push only `personal`.

- [x] Recheck active goal/worktree/resources and existing source/timesync/receiver contracts; identify callback-time limitation and kernel timestamp-enabling race.
- [x] Read official Python/kernel API and fixed sources; document ABI, realtime domain and pre-bind constraints before implementation.
- [ ] Add header-probe source and read-only bounded native capability build; verify installed ABI, freeze source/compiler/headers/binary/metadata. Preserve failure without starting a live source.
- [ ] TDD opt-in timestamp profile and existing DatagramReceiver integration; retain defaults/guards/deadlines and raw evidence; pass synthetic/fault/adjacent tests.
- [ ] Independent read-only code review and repair findings; freeze a bounded local opaque-packet study after current source/test hashes.
- [ ] Run the declared3-packet delayed-read plus option-drift refusal study once; preserve all raw clocks/bytes/ancillary/FD/cleanup/failures. No physical/source qualification.
- [ ] Seal evidence/report with hashes/CRC; commit/push only `personal`, update PR65/automation and leave the full goal active.
