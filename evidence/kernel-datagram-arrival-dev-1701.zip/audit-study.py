"""Fixed failed trial audit; no networking or estimator invocation."""
import hashlib
import json
import struct
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).parent
STUDY = BASE / "study-v1"


def read(name):
    return json.loads((STUDY / name).read_text())


result = read("capture-v1/result.json")
completion = read("completion.json")
before, after = read("inputs-before.json"), read("inputs-after.json")
assert before == after and completion["selected_inputs_stable"] is True
for name, expected in before.items():
    assert hashlib.sha256((STUDY / "inputs" / name).read_bytes()).hexdigest() == expected
assert result["status"] == "failed" and completion["exit_code"] == 1
assert result["profile_post_verified"] is True
sent = result["normal"]["sent"]
assert len(sent) == 3
event = [item for item in result["normal"]["events"] if item["kind"] == "receive_return"]
assert len(event) == 1 and event[0]["data_hex"] == sent[0]["payload_hex"]
item = event[0]
assert item["flags"] == 0 and item["ancillary_count"] == 1
metadata = item["ancillary_raw"][0]
assert metadata["level"] == 1 and metadata["type"] == 64 and metadata["data_length"] == 16
sec, nsec = struct.unpack("<qq", bytes.fromhex(metadata["data_hex"]))
timestamp = sec * 1_000_000_000 + nsec
observed = [row for row in result["normal"]["events"] if row["kind"] == "kernel_timestamp_observed"]
assert len(observed) == 1 and observed[0]["kernel_received_realtime_ns"] == timestamp
assert sent[0]["after_realtime_ns"] < item["kernel_realtime_before_ns"] < timestamp < item["kernel_realtime_after_ns"]
assert result["option_drift"] == {}  # never reached; not an option-drift pass
assert len(result["owned_close"]) == 2
assert {row["fd"] for row in result["owned_close"]} == {3, 4}
assert all(row["fileno_after"] == -1 and row["fstat_errno"] == 9 and row["close_error"] is None
           for row in result["owned_close"])
assert not result["px4_ros_physics_or_training_started"] and not result["fusion_qualified"]
audit = {"trial_status": "failed", "native_option_and_ABI_decode_observed": True,
         "kernel_receive_instant_qualified": False, "clock_mapping_qualified": False,
         "source_freshness_qualified": False, "fusion_qualified": False,
         "owned_payloads_sent": 3, "owned_payloads_returned": 1,
         "unconsumed_payloads_before_close": 2, "option_drift_executed": False,
         "intentional_delay_ns": result["normal"]["delay_end_ns"] - result["normal"]["delay_start_ns"],
         "kernel_stamp_after_send_end_ns": timestamp - sent[0]["after_realtime_ns"],
         "kernel_stamp_after_userspace_recv_before_ns": timestamp - item["kernel_realtime_before_ns"],
         "userspace_recv_after_minus_kernel_stamp_ns": item["kernel_realtime_after_ns"] - timestamp,
         "owned_fd_close_observed": True, "child_exit_observed": completion["exit_code"],
         "all_unrelated_resources_released": None,
         "interpretation": "metadata fell inside recvmsg observations after delayed reading; receive-path synthesis is a source-supported hypothesis, not runtime causality proof",
         "final_changes_since_trial": [name for name, old in before.items()
                                       if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != old]}
with (BASE / "audit-v1.json").open("x") as stream:
    json.dump(audit, stream, indent=2)
print(json.dumps(audit, indent=2))
