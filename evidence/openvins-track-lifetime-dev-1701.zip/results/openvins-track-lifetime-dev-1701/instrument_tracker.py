"""Add diagnostic-only monocular KLT counters to an isolated OpenVINS checkout."""

from pathlib import Path
import sys


target = Path(sys.argv[1]) / "ov_core/src/track/TrackKLT.cpp"
source = target.read_text()


def replace_once(before: str, after: str) -> None:
    global source
    if source.count(before) != 1:
        raise SystemExit(f"expected one insertion point, found {source.count(before)}: {before[:80]!r}")
    source = source.replace(before, after)


replace_once(
    '#include "TrackKLT.h"\n',
    '#include "TrackKLT.h"\n\n#include <unordered_set>\n',
)
replace_once(
    "    perform_detection_monocular(imgpyr, mask, good_left, good_ids_left);\n"
    "    // Save the current image and pyramid\n",
    "    perform_detection_monocular(imgpyr, mask, good_left, good_ids_left);\n"
    '    PRINT_INFO("FD_KLT_FRAME t=%.9f cam=%zu previous=0 retained=0 added=%zu input=%zu accepted=0 branch=bootstrap\\n",\n'
    "               message.timestamp, cam_id, good_ids_left.size(), good_ids_left.size());\n"
    "    // Save the current image and pyramid\n",
)
replace_once(
    "  auto pts_left_old = pts_last[cam_id];\n"
    "  auto ids_left_old = ids_last[cam_id];\n"
    "  perform_detection_monocular(img_pyramid_last[cam_id], img_mask_last[cam_id], pts_left_old, ids_left_old);\n",
    "  auto pts_left_old = pts_last[cam_id];\n"
    "  auto ids_left_old = ids_last[cam_id];\n"
    "  const std::unordered_set<size_t> prior_ids(ids_left_old.begin(), ids_left_old.end());\n"
    "  perform_detection_monocular(img_pyramid_last[cam_id], img_mask_last[cam_id], pts_left_old, ids_left_old);\n"
    "  size_t retained = 0;\n"
    "  for (const auto id : ids_left_old)\n"
    "    retained += prior_ids.count(id);\n"
    "  const size_t added = ids_left_old.size() - retained;\n",
)
replace_once(
    "  if (mask_ll.empty()) {\n"
    "    std::lock_guard<std::mutex> lckv(mtx_last_vars);\n",
    "  if (mask_ll.empty()) {\n"
    '    PRINT_INFO("FD_KLT_FRAME t=%.9f cam=%zu previous=%d retained=%zu added=%zu input=%zu accepted=0 branch=reset\\n",\n'
    "               message.timestamp, cam_id, pts_before_detect, retained, added, ids_left_old.size());\n"
    "    std::lock_guard<std::mutex> lckv(mtx_last_vars);\n",
)
replace_once(
    "    database->update_feature(good_ids_left.at(i), message.timestamp, cam_id, good_left.at(i).pt.x, good_left.at(i).pt.y, npt_l.x, npt_l.y);\n"
    "  }\n\n"
    "  // Move forward in time\n"
    "  {\n"
    "    std::lock_guard<std::mutex> lckv(mtx_last_vars);\n",
    "    database->update_feature(good_ids_left.at(i), message.timestamp, cam_id, good_left.at(i).pt.x, good_left.at(i).pt.y, npt_l.x, npt_l.y);\n"
    "  }\n\n"
    "  // Record exactly the observations written to FeatureDatabase.\n"
    '  PRINT_INFO("FD_KLT_FRAME t=%.9f cam=%zu previous=%d retained=%zu added=%zu input=%zu accepted=%zu branch=normal\\n",\n'
    "             message.timestamp, cam_id, pts_before_detect, retained, added, ids_left_old.size(), good_ids_left.size());\n"
    "  for (const auto id : good_ids_left)\n"
    '    PRINT_INFO("FD_KLT_ID t=%.9f cam=%zu id=%zu\\n", message.timestamp, cam_id, id);\n'
    "\n"
    "  // Move forward in time\n"
    "  {\n"
    "    std::lock_guard<std::mutex> lckv(mtx_last_vars);\n",
)
replace_once(
    "  if (kpts0.empty() || kpts1.empty())\n"
    "    return;\n",
    "  if (kpts0.empty() || kpts1.empty()) {\n"
    '    PRINT_INFO("FD_KLT_MATCH cam0=%zu cam1=%zu input=0 klt=0 ransac=0 combined=0 status=empty\\n", id0, id1);\n'
    "    return;\n"
    "  }\n",
)
replace_once(
    "  if (pts0.size() < 10) {\n"
    "    for (size_t i = 0; i < pts0.size(); i++)\n"
    "      mask_out.push_back((uchar)0);\n"
    "    return;\n"
    "  }\n",
    "  if (pts0.size() < 10) {\n"
    "    for (size_t i = 0; i < pts0.size(); i++)\n"
    "      mask_out.push_back((uchar)0);\n"
    '    PRINT_INFO("FD_KLT_MATCH cam0=%zu cam1=%zu input=%zu klt=0 ransac=0 combined=0 status=few\\n", id0, id1, pts0.size());\n'
    "    return;\n"
    "  }\n",
)
replace_once(
    "  // Copy back the updated positions\n"
    "  for (size_t i = 0; i < pts0.size(); i++) {\n",
    "  size_t klt_pass = 0, ransac_pass = 0, combined_pass = 0;\n"
    "  for (size_t i = 0; i < pts0.size(); i++) {\n"
    "    klt_pass += i < mask_klt.size() && mask_klt[i];\n"
    "    ransac_pass += i < mask_rsc.size() && mask_rsc[i];\n"
    "    combined_pass += mask_out[i] != 0;\n"
    "  }\n"
    '  PRINT_INFO("FD_KLT_MATCH cam0=%zu cam1=%zu input=%zu klt=%zu ransac=%zu combined=%zu status=normal\\n",\n'
    "             id0, id1, pts0.size(), klt_pass, ransac_pass, combined_pass);\n"
    "\n"
    "  // Copy back the updated positions\n"
    "  for (size_t i = 0; i < pts0.size(); i++) {\n",
)

target.write_text(source)
