"""Seal one fixed-input KLT tracking audit without touching estimator inputs."""

import csv
import hashlib
import json
from collections import Counter
from pathlib import Path
from statistics import median

from tools.benchmark.audit_openvins_track_lifetime import parse_track_log, summarize_frames, validate_source_timeline


ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).parent
OUT = STAGE / "audit-v2"
PREVIOUS = ROOT / "results/openvins-track-eligibility-dev-1701"
SOURCE = Path("C:/Users/yuche/.codex/worktrees/FlyDrones/prearm-target/results/openvins-prearm-board-dev-1701")
START, END = 15.618, 19.642
EXPECTED_STATES = "1ccb4cd2eb55294e5130f052800d0bf83a962538ecba68c00c97e28c22af8975"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


if OUT.exists():
    raise SystemExit("refusing existing audit output")
if digest(STAGE / "replay-v1/states.csv") != EXPECTED_STATES:
    raise SystemExit("instrumented replay changed estimator states")
prior = json.loads((PREVIOUS / "provenance.json").read_text())
if digest(SOURCE / "input-v1/manifest.json") != prior["sha256"]["source_input_manifest"]:
    raise SystemExit("source input changed")
frames = parse_track_log((STAGE / "replay-v1/stdout.txt").read_text(errors="replace"))
if len(frames) != 608:
    raise SystemExit(f"unexpected tracked frame count: {len(frames)}")

with (SOURCE / "input-v1/frames.csv").open(newline="") as stream:
    source_timestamps = [int(row["timestamp_ns"]) for row in csv.DictReader(stream)]
with (PREVIOUS / "audit-v2/counts.csv").open(newline="") as stream:
    eligibility = list(csv.DictReader(stream))
initializer_timestamps = [int(row["image_ns"]) for row in eligibility]
if len(eligibility) != 254:
    raise SystemExit("unexpected initializer attempt count")
validate_source_timeline(frames, source_timestamps, initializer_timestamps)
prearm = [frame for frame in frames if START <= frame.time <= END]
prearm_eligibility = [row for row in eligibility if START <= int(row["image_ns"]) / 1e9 <= END]
if len(prearm) != 40 or len(prearm_eligibility) != 40:
    raise SystemExit("unexpected preunlock window size")

OUT.mkdir()
with (OUT / "frames.csv").open("w", newline="") as stream:
    fields = (
        "image_ns", "cam", "branch", "previous", "retained", "removed_by_detection", "added", "input", "klt", "ransac",
        "matched", "accepted", "id_count",
    )
    writer = csv.DictWriter(stream, fieldnames=fields)
    writer.writeheader()
    for frame in frames:
        writer.writerow({
            "image_ns": round(frame.time * 1e9), "cam": frame.cam, "branch": frame.branch,
            "previous": frame.previous, "retained": frame.retained,
            "removed_by_detection": frame.previous - frame.retained, "added": frame.added,
            "input": frame.input, "klt": frame.match.klt if frame.match else 0,
            "ransac": frame.match.ransac if frame.match else 0,
            "matched": frame.match.combined if frame.match else 0,
            "accepted": frame.accepted, "id_count": len(frame.ids),
        })

all_ids = {}
for frame in frames:
    for feature_id in frame.ids:
        all_ids.setdefault((frame.cam, feature_id), []).append(frame.time)
with (OUT / "id_lifetimes.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(("cam", "id", "first_s", "last_s", "writes", "prearm_writes"))
    for (cam, feature_id), times in sorted(all_ids.items()):
        writer.writerow((cam, feature_id, f"{times[0]:.9f}", f"{times[-1]:.9f}", len(times),
                         sum(START <= time <= END for time in times)))

prearm_writes = Counter((frame.cam, feature_id) for frame in prearm for feature_id in frame.ids)
distribution = Counter(prearm_writes.values())
report = {
    "schema": "flydrones-openvins-track-lifetime-audit-v1",
    "upstream": prior["upstream"],
    "source_manifest_sha256": digest(SOURCE / "input-v1/manifest.json"),
    "states_sha256": digest(STAGE / "replay-v1/states.csv"),
    "prior_eligibility_counts_sha256": digest(PREVIOUS / "audit-v2/counts.csv"),
    "tracker_frame_count": len(frames),
    "paired_initializer_count": len(eligibility),
    "full": summarize_frames(frames, 0, 100),
    "prearm": summarize_frames(frames, START, END),
    "prearm_window_s": [START, END],
    "prearm_eligibility_count": len(prearm_eligibility),
    "prearm_old2_max": max(int(row["old2"]) for row in prearm_eligibility),
    "prearm_new2_max": max(int(row["new2"]) for row in prearm_eligibility),
    "prearm_writes_distribution": {str(writes): count for writes, count in sorted(distribution.items())},
    "prearm_median_per_frame": {
        "previous": median(frame.previous for frame in prearm),
        "retained": median(frame.retained for frame in prearm),
        "added": median(frame.added for frame in prearm),
        "klt": median(frame.match.klt for frame in prearm if frame.match),
        "ransac": median(frame.match.ransac for frame in prearm if frame.match),
        "accepted": median(frame.accepted for frame in prearm),
    },
}
(OUT / "summary.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
