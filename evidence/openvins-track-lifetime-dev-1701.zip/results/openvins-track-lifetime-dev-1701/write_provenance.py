"""Record exact source, library, input, and output identity for one replay."""

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).parent
SOURCE = Path("C:/Users/yuche/.codex/worktrees/FlyDrones/prearm-target/results/openvins-prearm-board-dev-1701")
OUT = STAGE / "provenance-v2.json"
LIBRARY_SHA = "a13296b877333646065851e61831df7eba380829052f3962bd12e78501e9b319"
LIBRARY_BYTES = 292811280


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


if OUT.exists():
    raise SystemExit("refusing existing provenance")
prior = json.loads((ROOT / "results/openvins-track-eligibility-dev-1701/provenance.json").read_text())
files = {
    "new_logging_patch": ROOT / "tools/benchmark/openvins_track_lifetime.patch",
    "applied_upstream_diff": STAGE / "upstream-applied.patch",
    "prior_evidence_index": ROOT / "evidence/openvins-track-eligibility-dev-1701.sha256.json",
    "offline_runner": SOURCE / "dependencies-v1/offline_probe",
    "estimator_config": SOURCE / "dependencies-v1/config-v2/estimator_config.yaml",
    "source_input_manifest": SOURCE / "input-v1/manifest.json",
    "source_imu_csv": SOURCE / "input-v1/imu.csv",
    "source_frames_csv": SOURCE / "input-v1/frames.csv",
    "new_replay_states": STAGE / "replay-v1/states.csv",
    "new_replay_stdout": STAGE / "replay-v1/stdout.txt",
    "new_audit_summary": STAGE / "audit-v2/summary.json",
}
hashes = {key: digest(path) for key, path in files.items()}
for key in ("offline_runner", "estimator_config", "source_input_manifest", "source_imu_csv", "source_frames_csv"):
    if hashes[key] != prior["sha256"][key]:
        raise SystemExit(f"source changed: {key}")
if hashes["new_replay_states"] != prior["sha256"]["new_replay_states"]:
    raise SystemExit("instrumented estimator states changed")
data = {
    "schema": "flydrones-openvins-track-lifetime-provenance-v1",
    "upstream": prior["upstream"],
    "upstream_license": "GPL-3.0",
    "upstream_repository_not_archived": True,
    "upstream_pushed_at_utc_checked_2026_10_04": "2025-11-30T08:23:17Z",
    "compiler": prior["compiler"],
    "opencv": prior["opencv"],
    "new_library_sha256": LIBRARY_SHA,
    "new_library_bytes": LIBRARY_BYTES,
    "library_archived": False,
    "prior_pr": "https://github.com/chen7509/FlyDrones/pull/26",
    "prior_evidence_zip_sha256": json.loads(files["prior_evidence_index"].read_text())["archive_sha256"],
    "sha256": hashes,
}
OUT.write_text(json.dumps(data, indent=2) + "\n")
print(json.dumps(data, indent=2))
