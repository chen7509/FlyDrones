import hashlib
import json
from pathlib import Path
import sys
import zipfile

root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root))
from tools.benchmark.openvins_odometry_contract import convert_frozen_records

stage = Path(__file__).parent
archive = root / 'evidence/openvins-fast-propagation-dev-1701.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == '25c50d945156e6a05e14e52afa73b9acffd048a1bb3dbdfb6d484e7685015d29'
with zipfile.ZipFile(archive) as z:
    raw = z.read('results/openvins-fast-propagation-dev-1701/replay-v1/fast.jsonl')
rows = [json.loads(line) for line in raw.splitlines()]
original = [json.loads(line) for line in (stage / 'converted-v1.jsonl').read_text().splitlines()]
current = convert_frozen_records(rows)
assert current == original
result = {'scope': 'conversion-only parity after SciPy API compatibility fix; no estimator rerun',
          'entries_equal': len(current), 'real_wire_packets': 0,
          'converter_sha256': hashlib.sha256((root / 'tools/benchmark/openvins_odometry_contract.py').read_bytes()).hexdigest(),
          'converted_sha256': hashlib.sha256((stage / 'converted-v1.jsonl').read_bytes()).hexdigest()}
with (stage / 'final-conversion-parity.json').open('x') as f: json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
