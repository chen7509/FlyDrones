import datetime
import json
import os
from pathlib import Path

matches = []
for path in Path('/proc').iterdir():
    if not path.name.isdigit() or int(path.name) == os.getpid():
        continue
    try:
        name = (path / 'comm').read_text().strip()
        args = (path / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
    except (OSError, PermissionError):
        continue
    if name in {'px4', 'state_probe', 'fast_probe', 'gz', 'gzserver', 'gzclient'} or (
        name in {'python', 'python3', 'ruby'} and any(s in args for s in ['FlyDrones', 'gz sim', 'openvins', 'pytest'])):
        matches.append({'pid': int(path.name), 'name': name, 'command': args})
result = {'scope': 'WSL named PX4/Gazebo/probe and related Python processes',
          'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'matches': matches}
with (Path(__file__).parent / 'processes-after.json').open('x') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
