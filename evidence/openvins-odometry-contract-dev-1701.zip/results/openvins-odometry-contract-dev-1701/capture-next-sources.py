import hashlib
import json
from pathlib import Path

stage = Path(__file__).parent
dest = stage / 'next-source-snapshots'
dest.mkdir(exist_ok=False)
root = Path('/home/yuchen7509/PX4-Autopilot')
items = {}
for name in ['src/modules/mavlink/streams/HIGHRES_IMU.hpp', 'src/modules/mavlink/streams/SCALED_IMU.hpp',
             'src/modules/uxrce_dds_client/dds_topics.yaml']:
    data = (root / name).read_bytes()
    (dest / Path(name).name).write_bytes(data)
    items[name] = hashlib.sha256(data).hexdigest()
with (dest / 'hashes.json').open('x') as f: json.dump(items, f, indent=2)
print(json.dumps(items, indent=2))
