import hashlib
import importlib.metadata
import json
from pathlib import Path
import subprocess
import urllib.request

root = Path('/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility')
out = root / 'results/openvins-odometry-contract-dev-1701'
files = [Path('/home/yuchen7509/PX4-Autopilot') / p for p in [
    'msg/versioned/VehicleOdometry.msg', 'src/modules/mavlink/mavlink_receiver.cpp',
    'src/modules/ekf2/EKF2.cpp', 'src/modules/ekf2/EKF/aid_sources/external_vision/ev_yaw_control.cpp', 'LICENSE']]
ov = Path('/home/yuchen7509/flydrones-upstream/open_vins_vio_init_probe')
files += [ov / p for p in ['ov_core/src/types/JPLQuat.h', 'ov_core/src/utils/quat_ops.h',
                          'ov_msckf/src/state/Propagator.cpp']]
from pymavlink.dialects.v20 import common
files += [Path(common.__file__), Path(common.__file__).with_suffix('.xml')]
result = {'packages': {n: importlib.metadata.version(n) for n in ['pymavlink', 'numpy', 'scipy']}, 'files': {}}
snapshot = out / 'source-snapshots-v2'
snapshot.mkdir(exist_ok=False)
for i, path in enumerate(files):
    data = path.read_bytes()
    name = str(i) + '-' + path.name
    (snapshot / name).write_bytes(data)
    result['files'][str(path)] = {'sha256': hashlib.sha256(data).hexdigest(), 'snapshot': name}
result['repositories'] = {}
for repo, ref in [('rpng/open_vins', 'master'), ('ArduPilot/pymavlink', 'master'), ('mavlink/mavros', 'ros2')]:
    def fetch(suffix):
        req = urllib.request.Request('https://api.github.com/repos/' + repo + suffix, headers={'User-Agent': 'FlyDrones-research'})
        return json.load(urllib.request.urlopen(req, timeout=30))
    meta, commit = fetch(''), fetch('/commits/' + ref)
    result['repositories'][repo] = {'archived': meta['archived'], 'pushed_at': meta['pushed_at'], 'sha': commit['sha'],
                                    'license_api': meta.get('license')}
result['processes'] = subprocess.check_output(['ps', '-eo', 'pid,comm,args'], text=True)
with (out / 'research-provenance.json').open('x') as f:
    json.dump(result, f, indent=2)
print(json.dumps({k: v for k, v in result.items() if k != 'processes'}, indent=2))
