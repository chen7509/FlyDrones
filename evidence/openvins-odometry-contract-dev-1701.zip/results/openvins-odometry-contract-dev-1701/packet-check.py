"""Run in existing WSL pymavlink environment. All metadata below is synthetic."""
import json
from pathlib import Path
import sys
import numpy as np

root = Path('/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility')
sys.path.insert(0, str(root))
from tools.benchmark.openvins_odometry_contract import ShadowSession, encode_shadow
from pymavlink.dialects.v20 import common

row = dict(target_ns=2_000_000_000, success=True, internal_initialized=True, public_initialized=False,
           state13=[1, 0, 0, 0, 1, 2, 3, 4, 5, 6, .1, .2, .3], covariance12=np.eye(12).tolist())
results = []
for quality in [-1, 0, 80]:
    s = ShadowSession('synthetic', 'synthetic-clock', wire_offset_ns=1_000_000, max_age_ns=100_000_000)
    r = s.accept(row, session_id='synthetic', clock_id='synthetic-clock', observed_ns=2_004_000_000,
                 reset_total=256, quality=quality)
    packet = encode_shadow(r)
    decoder = common.MAVLink(None)
    parsed = decoder.parse_char(packet)
    assert parsed.get_type() == 'ODOMETRY' and packet[0] == 0xFD
    assert parsed.frame_id == common.MAV_FRAME_LOCAL_FRD and parsed.child_frame_id == common.MAV_FRAME_BODY_FRD
    assert parsed.estimator_type == common.MAV_ESTIMATOR_TYPE_VIO
    for key, value in r['fields'].items():
        np.testing.assert_allclose(getattr(parsed, key), value, rtol=1e-6, atol=1e-7)
    assert not r['eligible_for_px4_fusion']
    results.append({'quality': quality, 'packet_hex': packet.hex(), 'decoded': parsed.to_dict(), 'reasons': r['reasons']})
out = root / 'results/openvins-odometry-contract-dev-1701/packet-roundtrip-v1.json'
with out.open('x') as f: json.dump({'synthetic_only': True, 'cases': results}, f, indent=2)
print('3 real pymavlink 2.4.49 MAVLink2 roundtrips passed; no network opened')
