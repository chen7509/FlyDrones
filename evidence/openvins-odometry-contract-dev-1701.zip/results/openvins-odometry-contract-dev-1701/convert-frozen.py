import hashlib
import json
from pathlib import Path
import sys
import time
import zipfile

root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root))
from tools.benchmark.openvins_odometry_contract import convert_frozen_records

archive = root / 'evidence/openvins-fast-propagation-dev-1701.zip'
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
assert digest == '25c50d945156e6a05e14e52afa73b9acffd048a1bb3dbdfb6d484e7685015d29'
with zipfile.ZipFile(archive) as z:
    data = z.read('results/openvins-fast-propagation-dev-1701/replay-v1/fast.jsonl')
assert hashlib.sha256(data).hexdigest() == '19d468a25a2417bab08ebe19f3b00606c8b5b13f788206a0663aacdc752882d4'
rows = [json.loads(line) for line in data.splitlines()]
start = time.perf_counter()
converted = convert_frozen_records(rows)
elapsed = time.perf_counter() - start
out = Path(__file__).parent
with (out / 'converted-v1.jsonl').open('x') as f:
    for item in converted: f.write(json.dumps(item, allow_nan=False) + '\n')
summary = dict(archive_sha256=digest, native_sha256=hashlib.sha256(data).hexdigest(),
               entries=len(converted), geometry_candidates=sum(r['geometry'] is not None for r in converted),
               unavailable=sum(r['geometry'] is None for r in converted),
               fusion_eligible=sum(r['eligible_for_px4_fusion'] for r in converted),
               packets_created=0, conversion_batch_wall_s=elapsed,
               runtime_scope='offline batch including validation; not online latency',
               prearm_entries=sum(15_680_000_000 <= r['target_ns'] <= 19_700_000_000 for r in converted),
               prearm_public_initialized=sum(15_680_000_000 <= r['target_ns'] <= 19_700_000_000 and r['public_initialized'] for r in rows))
assert (summary['entries'], summary['geometry_candidates'], summary['unavailable'], summary['fusion_eligible']) == (2136, 2030, 106, 0)
with (out / 'conversion-summary-v1.json').open('x') as f: json.dump(summary, f, indent=2)
print(json.dumps(summary, indent=2))
