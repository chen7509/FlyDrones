import hashlib
import json
from pathlib import Path
import zipfile

stage = Path(__file__).resolve().parent
root = stage.parents[1]
archive = root / 'evidence/openvins-odometry-contract-dev-1701.zip'
index_path = archive.with_suffix('.sha256.json')
assert not archive.exists() and not index_path.exists()
sha = lambda b: hashlib.sha256(b).hexdigest()
extras = ['docs/OPENVINS_ODOMETRY_CONTRACT_REPORT.md',
          'docs/superpowers/specs/2026-10-06-openvins-odometry-contract-design.md',
          'docs/superpowers/plans/2026-10-06-openvins-odometry-contract.md',
          'tools/benchmark/openvins_odometry_contract.py',
          'tests/benchmark/test_openvins_odometry_contract.py',
          'tests/benchmark/check_openvins_odometry_packet.py',
          'evidence/openvins-fast-propagation-dev-1701.sha256.json']
files = sorted(p for p in stage.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
files += [root / p for p in extras]
assert len(files) == len(set(files)) and not any(p.is_symlink() for p in files)
members = {p.relative_to(root).as_posix(): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in files}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in files: z.write(p, p.relative_to(root).as_posix())
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(members) and set(z.namelist()) == set(members)
    for name, item in members.items():
        data = z.read(name)
        assert len(data) == item['bytes'] and sha(data) == item['sha256']
index = {'schema': 'flydrones-sealed-development-evidence-v1', 'archive': archive.relative_to(root).as_posix(),
         'archive_bytes': archive.stat().st_size, 'archive_sha256': sha(archive.read_bytes()),
         'member_count': len(members), 'members': members,
         'dependencies': {'fast_propagation_archive_sha256': '25c50d945156e6a05e14e52afa73b9acffd048a1bb3dbdfb6d484e7685015d29'},
         'scope': 'Offline conversion and synthetic file-only message tests. No online or flight qualification.'}
with index_path.open('x') as f: json.dump(index, f, indent=2)
print(json.dumps({k: v for k, v in index.items() if k != 'members'}, indent=2))
