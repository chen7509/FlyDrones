#!/bin/bash
set -euo pipefail
cd /mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility
export PYTHONPATH=.
python3 tests/benchmark/check_openvins_odometry_packet.py
