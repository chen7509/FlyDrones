import importlib.metadata
import json
from pathlib import Path
import subprocess
import urllib.request

out = Path(__file__).parent / 'licenses'
out.mkdir(exist_ok=False)
data = subprocess.check_output(['git', '-C', '/home/yuchen7509/flydrones-upstream/open_vins_vio_init_probe', 'show', 'HEAD:LICENSE'])
(out / 'OpenVINS-GPL-3.0.txt').write_bytes(data)
for repo, commit, name in [('ArduPilot/pymavlink', '20111a041f3abfeda1c4b34dae43c0cd4441ef52', 'COPYING'),
                            ('mavlink/mavros', '5c68b905ab30de6ce630822dc46c33467e8f23ea', 'LICENSE.md')]:
    url = 'https://raw.githubusercontent.com/' + repo + '/' + commit + '/' + name
    data = urllib.request.urlopen(url, timeout=30).read()
    (out / (repo.split('/')[1] + '-' + name)).write_bytes(data)
with (out / 'installed-metadata.json').open('x') as f:
    json.dump({n: {k: importlib.metadata.metadata(n).get(k) for k in ['Name', 'Version', 'License']}
               for n in ['pymavlink', 'scipy', 'numpy']}, f, indent=2)
print('actual license text snapshots saved')
