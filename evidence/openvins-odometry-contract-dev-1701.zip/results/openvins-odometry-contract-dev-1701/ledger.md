# SDD ledger — plan: docs/superpowers/plans/2026-10-06-openvins-odometry-contract.md

Task 1 BASE 21147414e7e7bde8e4f5f89e16a32fc6ee9b6957; brief read.
Pre-flight: geometry feeds serializer and fixed audit; covariance is explicit pinned-PX4 body tangent profile, not Euler. No online consumer. Clock/health supplied synthetically only in tests, absent from real archive stays absent.
Ruling: preserve workspace/evidence rather than delete after review — user explicitly requires all failures and logs — cost is disk usage.
Research source snapshot attempt failed on absent sparse-checkout LICENSE; partial snapshot retained, second destination v2 used. No simulation/replay started.

Research complete: pinned consumer uses body-tangent variance; source/license/package hashes and GitHub activity saved. Generic Euler covariance deliberately not claimed.
38 initial failures (missing module) → 38 passing geometry/session tests. Failure-preservation test RED missing API → implementation. Wire corruption test RED accepted changed frame_id → explicit second serialization boundary validation → 9 roundtrips + 9 corruption rejections in installed WSL pymavlink.
Frozen input conversion complete: 2136 entries,2030 geometry,106 unavailable,202 prearm,0 prearm public,0 real packets,0 fusion eligible. Batch wall0.400536s; not online latency.
Task 1: complete (commits 2114741..2114741, tests: python -m pytest tests/benchmark/test_openvins_odometry_contract.py -q → 39 passed in 0.99s)
Ledger correction: task-done ran before commit, so recorded BASE..BASE; verified implementation commit is 212bbcf. Remaining review/seal/publication checklist was not complete at that test checkpoint.

Final review: independent review_odometry_contract found no Critical/Minor and one Important SciPy1.10 API compatibility issue. Accepted; legacy signature test RED TypeError → explicit sign canonicalization. Final full regression pending at this entry.
Final: Ruling: online freshness/reset/EKF2/flight was declined by reviewer — report keeps these untested, file-only module cannot authorize fusion — cost: online validation remains necessary.
Final: Ruling: general mounting/other consumers was declined — retain identity FRD and pinned-PX4-only scope — cost: separate adaptation for other mounting/firmware.
Final: Ruling: covariance calibration was declined — retain approximate uncalibrated label — cost: no statistical health qualification from this stage.
Final: fixed SciPy1.10 compatibility — test_scipy_110_as_quat_signature_compatibility RED unexpected canonical keyword → GREEN; full suite667/667,2 existing warnings,205.26s. WSL final9 wire roundtrips+9 corruption refusals. Conversion-only parity all2136 equal. No estimator replay rerun. Review fix pass complete; no minors deferred.
