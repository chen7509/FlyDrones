# Read-only dependency inspection, 2026-10-09

The new offline adapter supplies the Controller-shaped boundary. It does not
qualify sensor provenance. No external job was started during this inspection.

- `tools/benchmark/run_episode.py` still selects FullFlyController or actual
  EgoController, and still uses NativeGazeboPx4Backend. Do not silently replace
  fly_raw/fly_guided or run frozen test scenes to tune the new rate core.
- `capture_input.py` rejects that backend by type, independently of mutable
  source labels; it requires PX4 estimate timestamps/health, calibrated camera
  source and inspected pinned EGO identity. A string on the offline adapter is
  not sufficient to satisfy this gate.
- Existing `ekf2_shadow.py` aligns archived ULog states causally to frames but
  explicitly labels simulation epoch calibration unqualified and live capture
  ineligible. It is an auditor, not a live Observation producer. Existing
  MAVLinkDrone.telemetry exposes neither full freshness/health evidence nor all
  state fields required here. Do not bypass gates by forwarding it directly.
- The corpus configuration declares 54 jobs and versioned training/validation
  directories. The foundation report says actual deployment-visible corpus
  capture remains incomplete. Training loss on smoke data is not full learning.
- Read-only Windows service query currently returned com.docker.service Stopped
  (enum 1). It did not inspect the pinned EGO image or launch Docker; image
  availability remains unverified, not declared absent.
- The reviewed live-wire preparation report records an offline package and an
  explicitly absent public live activation entry. It also records activation
  outside the current authorized scope. New capture source edits invalidate any
  old source freeze for future work; do not backfill or reuse that old freeze as
  current runtime proof.

Next independent work should bind an offline replay/corpus execution path to
actual source and teacher evidence, or finish the reviewed live activation gate
when authorized. Do not manufacture a VIO/teacher source to unblock full training.
No native Linux install is required by this inspection. Five-camera capacity,
full inference memory and remote publication remain separate limitations.
