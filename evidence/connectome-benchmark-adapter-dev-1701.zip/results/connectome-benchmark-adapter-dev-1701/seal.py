"""Preserve offline checks, failure reproduction and final source copies."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path(__file__).resolve().parents[2]
results = Path(__file__).resolve().parent
archive = root / 'evidence/connectome-benchmark-adapter-dev-1701.zip'
paths = set()
for folder in (results, root / 'results/worker-contract-stat-dev-1701'):
    paths.update(p for p in folder.rglob('*') if p.is_file() and p.name != 'seal-result.json')
paths.update(root / name for name in (
    'docs/OFFLINE_BENCHMARK_ADAPTER_REPORT.md',
    'src/flydrones/connectome_training/benchmark_adapter.py',
    'src/flydrones/connectome_training/inference.py',
    'src/flydrones/connectome_training/inference_artifact.py',
    'src/flydrones/connectome_training/features.py',
    'src/flydrones/benchmark/contract.py',
    'tools/benchmark/capture_disarmed_sensors.py',
    'tests/benchmark/test_capture_contract.py',
    'tests/benchmark/test_capture_preflight_entry.py',
    'tests/connectome_training/test_benchmark_adapter.py',
    'configs/fly_ego_benchmark.yaml',
))
old = root / 'evidence/connectome-inference-probe-dev-1701.zip'
old_sha = hashlib.sha256(old.read_bytes()).hexdigest()
if old_sha != '04f196671982358f4dfeb0030641112592aed546213b1b82faf6b886d6f9cc02':
    raise ValueError('Previous failure evidence drift')
payload = {p.relative_to(root).as_posix(): p.read_bytes() for p in paths}
manifest = {
    'schema': 'offline-benchmark-adapter-evidence-v1',
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'snapshot_basis': 'post-verification source and report copies, not runtime pre/post freeze',
    'prior_failure_archive': {'path': old.relative_to(root).as_posix(), 'sha256': old_sha},
    'full_model_run': False, 'physics_run': False, 'training_run': False,
    'fusion_qualified': False, 'flight_eligible': False,
    'members': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                for name, data in sorted(payload.items())},
}
payload['MANIFEST.json'] = json.dumps(manifest, indent=2, sort_keys=True).encode() + b'\n'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as bundle:
    for name, data in sorted(payload.items()):
        bundle.writestr(name, data)
with zipfile.ZipFile(archive) as bundle:
    if bundle.testzip() is not None or len(bundle.namelist()) != len(set(bundle.namelist())):
        raise ValueError('CRC or duplicate member failure')
    if set(bundle.namelist()) != set(payload):
        raise ValueError('Member set mismatch')
    for name, data in payload.items():
        if bundle.read(name) != data:
            raise ValueError(f'Member bytes mismatch: {name}')
result = {'path': str(archive), 'members': len(payload), 'bytes': archive.stat().st_size,
          'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
          'crc_verified': True, 'member_hashes_verified': True}
with (results / 'seal-result.json').open('x', encoding='utf-8') as output:
    json.dump(result, output, indent=2)
print(json.dumps(result))
