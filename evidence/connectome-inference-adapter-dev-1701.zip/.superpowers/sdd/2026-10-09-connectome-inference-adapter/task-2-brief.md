## Task 2: Causal controller and intent shaping

Files: add `src/flydrones/connectome_training/inference.py` and
`tests/connectome_training/test_inference.py`.

Consumes Task 1 loaded core/features; produces `InferenceLimits` and
`ConnectomeInferenceController` with `step(SequenceFrame)->Decision`, reset/close.

- [ ] RED: analytic raw output, parity with direct recurrent core, reset,
  correct ENU shaping, camera reuse and changed content, all time/refusal cases,
  nonfinite state/output, fail latch and terminal close.
- [ ] Implement single-owner CPU synchronous state transaction and diagnostic
  evidence. Default envelope uses existing `shape_command`; no live I/O.
- [ ] Run `python -m pytest tests/connectome_training -q`; expected all pass.
  Commit implementation and Task 2 result.

