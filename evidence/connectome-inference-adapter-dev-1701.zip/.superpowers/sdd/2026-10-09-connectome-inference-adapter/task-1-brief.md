## Task 1: Shared primitives and artifact loader

Files: modify `features.py`, `parameters.py`, `curriculum_session.py` in
`src/flydrones/connectome_training`; add `inference_artifact.py` and
`tests/connectome_training/test_inference_artifact.py`.

Produces: public `frame_features`, `parameter_mapping_digest`, frozen
`CheckpointIdentity(checkpoint_sha256, config_digest, dataset_sha256)`,
`load_inference_core(...) -> LoadedInferenceCore(core, provenance)` per spec.

- [ ] Write and run RED cases for public feature parity, file hash/topology/
  mapping/feature-order refusal, tiny/full identity, checkpoint exact keys/dtypes/
  shapes/nonfinite data, metadata mismatch and fixed-buffer injection.
- [ ] Reuse parameter/checkpoint loaders; expose unchanged feature/mapping code;
  validate all checkpoint tensors before copying, disable gradients, retain
  ordinary pre/post hashes. No optimizer/global RNG restoration.
- [ ] Run `python -m pytest tests/connectome_training/test_inference_artifact.py
  tests/connectome_training/test_parameters.py tests/connectome_training/test_curriculum.py
  tests/connectome_training/test_model.py -q`; expected all pass. Commit.

