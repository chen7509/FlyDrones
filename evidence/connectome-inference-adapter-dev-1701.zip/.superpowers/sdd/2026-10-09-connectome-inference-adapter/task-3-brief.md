## Task 3: Verification, evidence and resource decision

Files: report `docs/CONNECTOME_INFERENCE_ADAPTER_REPORT.md`; evidence directory
`results/connectome-inference-adapter-dev-1701`; preserve this plan's ledger.

- [ ] Run full pytest, changed Ruff and diff check; report every failure/skip.
- [ ] One independent review of the package against this spec; fix meaningful
  findings with demonstrated RED/GREEN and relevant regression.
- [ ] Recheck available RAM before any full-core construction. Below 4 GiB:
  retain resource preflight and do not run full model. Otherwise independently
  predeclare bounded initialization-only CPU probe before executing; no reuse
  of tiny results to declare full inference or learning performance.
- [ ] Record verified/implemented/unmeasured/failure boundaries, seal evidence
  with member hashes/CRC, commit. Existing remote upload problem remains
  separate; no blind push retry, merge or history rewrite.

## Review Focus

Checkpoint topology-buffer injection, mislabeled initialization, camera timestamp
reuse with changed pixels, state advancement on refusal, and SI/ENU output
direction all have explicit tests in Tasks 1/2. Full-core timing remains a separate
resource-gated probe, never a tiny-test acceptance claim.
