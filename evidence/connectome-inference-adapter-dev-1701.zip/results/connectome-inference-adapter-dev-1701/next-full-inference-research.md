# Next dependency: complete learned-core inference measurement

This stage leaves a real callable offline adapter rather than a trained-policy
performance result. Do not replay or modify the old Stage A LIF baseline to
represent the new rate core. The existing `profile_controller` external clock
can measure the new controller because it only consumes step/Decision/sim_ns.
The old `profile_baseline.py` CLI still instantiates FullFlyController/Brain.

No full construction occurs below the predeclared 4 GiB available-RAM margin.
First recheck resources after the suite has exited. If insufficient, retain the
resource refusal and proceed with independent offline work. Do not kill unrelated
apps, repeatedly attempt allocation, or infer actual peak demand from the margin.

When resources permit, independently predeclare an initialization-only probe:
exact model and parameter paths/hashes, CPU threads/runtime, startup/step timeout,
owned process termination, memory measurements, observation arrays/timestamps,
warmup versus measured samples, failure preservation and no network/flight jobs.
Inputs must retain 10 Hz image timestamps at 20 Hz policy steps. Use the same
core and preserve all topology; no chunking/pruning/substitution without a separate
equivalence design. Keep diagnostic timing separate from externally measured
step-return latency. Initialization-only and learned checkpoints have distinct
origins; matching checkpoint metadata does not establish training quality.

Current source `data/malecns_full.npz` is 81,745,462 bytes. Full initialization
manifest is `results/connectome-training/stage-b/full-initialization/manifest.json`.
These are availability observations, not fresh full artifact loading. Existing
training/corpus config expects real partitioned teacher sequences; historical
smoke data cannot stand in for a full trained model. No checkpoint is selected
merely because its filename includes full or trained.

Resources reused: installed PyTorch CPU and repository checkpoint/model/feature
code; official eval/inference/serialization/license references are in the spec.
No new algorithm/dependency or maintenance claim is introduced here. Future
optimization should inspect fixed upstream sparse implementation and benchmark
with versioned inputs, not assume a CSR/coalescing rewrite preserves all behavior.

The broader goal still needs trustworthy nontruth training corpus/teacher
integration, full learning/division, fair held-out baseline comparison and staged
flight-stack evidence. Existing live-wire work is offline preparation and cannot
authorize network activation. WSL2 five-camera capacity remains a separate failed
gate. Hardware calibration/HITL/real-flight evidence is external to this stage.
