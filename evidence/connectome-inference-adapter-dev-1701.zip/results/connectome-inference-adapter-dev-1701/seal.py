"""Post-verification evidence packaging; never execute models or rewrite evidence."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path(__file__).resolve().parents[2]
results = Path(__file__).resolve().parent
archive = root / 'evidence/connectome-inference-adapter-dev-1701.zip'
report = root / 'docs/CONNECTOME_INFERENCE_ADAPTER_REPORT.md'
plan = root / 'docs/superpowers/plans/2026-10-09-connectome-inference-adapter.md'
spec = root / 'docs/superpowers/specs/2026-10-09-connectome-inference-adapter-design.md'
workspace = root / '.superpowers/sdd/2026-10-09-connectome-inference-adapter'
paths = [report, plan, spec]
paths.extend(p for p in results.iterdir() if p.is_file() and p.name != 'seal-result.json')
paths.extend(p for p in workspace.iterdir() if p.is_file())
changed = subprocess.check_output(
    ['git', 'diff', '--name-only', '6ae9979', 'HEAD', '--', '*.py'], cwd=root, text=True,
).splitlines()
paths.extend(root / p for p in changed)
paths.extend([
    root / 'results/connectome-training/stage-a/baseline_profile.json',
    root / 'results/connectome-training/stage-b/full-initialization/manifest.json',
    root / 'configs/connectome_training_v1.yaml',
])
payload = {}
for path in paths:
    name = path.relative_to(root).as_posix()
    if name in payload:
        raise ValueError(f'duplicate evidence path: {name}')
    payload[name] = path.read_bytes()
manifest = {
    'schema': 'flydrones-offline-inference-evidence-v1',
    'git_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'snapshot_basis': 'post-verification source and document copies; not runtime pre/post freeze',
    'full_model_executed': False,
    'flight_eligible': False,
    'training_success_verified': False,
    'members': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                for name, data in sorted(payload.items())},
}
payload['MANIFEST.json'] = json.dumps(manifest, indent=2, sort_keys=True).encode() + b'\n'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as bundle:
    for name, data in sorted(payload.items()):
        bundle.writestr(name, data)
with zipfile.ZipFile(archive) as bundle:
    if bundle.testzip() is not None or len(bundle.namelist()) != len(set(bundle.namelist())):
        raise ValueError('CRC or duplicate member failure')
    if set(bundle.namelist()) != set(payload):
        raise ValueError('member set mismatch')
    for name, data in payload.items():
        if bundle.read(name) != data:
            raise ValueError(f'member bytes mismatch: {name}')
result = {
    'archive': archive.relative_to(root).as_posix(),
    'members': len(payload), 'bytes': archive.stat().st_size,
    'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'crc_verified': True, 'all_member_hashes_verified': True,
}
with (results / 'seal-result.json').open('x', encoding='utf-8') as output:
    json.dump(result, output, indent=2)
print(json.dumps(result))
