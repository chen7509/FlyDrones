from pathlib import Path
import hashlib,json,urllib.request
p=Path(__file__).resolve().parent
old=p.parent/'supported-excitation-dev-1701/run_capture_v2.py'
s=old.read_text(encoding='utf-8').replace('from tools.benchmark.supported_excitation import supported_profile as profile','from tools.benchmark.readiness_anchor import anchored_profile as profile')
for a,b in [('capture-v2','capture-v1'),('producer-v2-before','producer-before'),('producer-v2-after','producer-after'),('installed-packages-v2.txt','installed-packages.txt'),('prospective-profile-v2.json','prospective-profile.json'),('launch-v2.json','launch.json'),('exit-v2.json','exit.json'),('supported-lateral-v1','supported-ready-v1'),('substep-supported-v1','substep-ready-v1')]:s=s.replace(a,b)
with (p/'run_capture.py').open('x') as f:f.write(s)
sources=p/'sources';sources.mkdir()
urls={'HEARTBEAT.hpp':'https://raw.githubusercontent.com/PX4/PX4-Autopilot/d6f12ad1c4f70ad3230afd7d86e971421e02fef4/src/modules/mavlink/streams/HEARTBEAT.hpp','px4-metadata.json':'https://api.github.com/repos/PX4/PX4-Autopilot','pymavlink-metadata.json':'https://api.github.com/repos/ArduPilot/pymavlink'}
manifest=[]
for name,url in urls.items():
    data=urllib.request.urlopen(url,timeout=30).read();(sources/name).write_bytes(data)
    manifest.append(dict(name=name,url=url,sha256=hashlib.sha256(data).hexdigest()))
(sources/'manifest.json').write_text(json.dumps(manifest,indent=2))
