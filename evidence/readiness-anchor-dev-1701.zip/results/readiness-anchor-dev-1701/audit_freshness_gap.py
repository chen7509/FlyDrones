"""Supplement the preserved first audit; never alter capture or estimator input."""
import hashlib
import json
import shutil
from pathlib import Path

base = Path(__file__).resolve().parent
root = base.parents[1]
rows = [json.loads(line) for line in (base / 'capture-v1/physics-substeps.jsonl').read_text().splitlines()]
post = {r['sim_ns']: r for r in rows if r['phase'] == 'post'}
audit = json.loads((base / 'audit.json').read_text())
fields = ['position', 'velocity_world', 'accel_world', 'angular_world', 'quaternion_xyzw']
start, end = post[8_000_000_000], post[9_000_000_000]
assert all(start[k] == end[k] for k in fields)
assert start['velocity_world'][1] < -.01 and start['accel_world'][1] > 12
source = root / 'results/openvins-inertial-consistency-dev-1701/backend-sources/gzphysics-dartsim__src__SimulationFeatures.cc'
dest = base / 'next-sources/SimulationFeatures.cc'
if not dest.exists():
    shutil.copyfile(source, dest)
report = dict(
    input_audit_sha256=hashlib.sha256((base / 'audit.json').read_bytes()).hexdigest(),
    examples=[post[t] for t in [6_543_000_000, 6_544_000_000, 8_000_000_000, 9_000_000_000]],
    same_state_fields_over_one_second=fields,
    position_delta_y_m=end['position'][1]-start['position'][1],
    velocity_predicts_delta_y_m=start['velocity_world'][1],
    settled_integral_error_m_s=next(w['full']['right_error_norm_m_s'] for w in audit['windows'] if w['name']=='settled'),
    hypothesis='ChangedWorldPoses-gated link component refresh can leave velocity/acceleration cached when pose stops; child sensor acceleration follows a separate per-step path.',
    source_evidence='gz-physics SimulationFeatures.cc 163-199 compares cached pose with 1e-6 tolerance; gz-sim Physics.cc ChangedLinks 3376+ and link update 3674+ versus child acceleration 3966+.',
    installed_path_runtime_causality_proven=False,
    raw_numeric_criteria_pass=audit['new_development_consistency_pass'],
    raw_endpoint_reference_freshness_verified=False,
    overall_sensor_consistency_qualified=False,
    eligible_for_px4_fusion=False,
    warning='The first audit boolean covers only numeric raw criteria; cached endpoint velocities prevent treating it as qualification. state_time_ns is callback-assigned, not backend component freshness.',
    sources={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (base/'next-sources').glob('*.cc')},
)
with (base/'diagnostic-gap.json').open('x', encoding='utf-8') as f:
    json.dump(report, f, indent=2)
print(json.dumps(report, indent=2))
