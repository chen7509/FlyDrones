import hashlib,json,sys
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation
from pyulog import ULog
root=Path(__file__).resolve().parents[2];sys.path[:0]=[str(root),str(root/'src')]
from tools.benchmark.physics_substep_trace import phase_closures
from tools.benchmark.disarmed_sensor_provenance import audit_event_records
base=Path(__file__).resolve().parent;p=base/'capture-v1'
read=lambda name:[json.loads(s) for s in (p/name).read_text().splitlines()]
r=json.loads((p/'result.json').read_text());assert r['status']=='capture_completed' and not r['estimator_run']
schedule=json.loads((p/'readiness-anchor.json').read_text());anchor=schedule['anchor_ns']
assert anchor==schedule['selected_sim_ns']+200000000 and schedule['selected_sim_ns']<8000000000
events=read('events.jsonl');counts=audit_event_records(events,required_kinds={'imu','rgb','info','depth','heartbeat'})
proof=schedule['proof']
for kind,entry in proof['records'].items():
    original={k:v for k,v in entry.items() if k!='journal_ack_monotonic_ns'}
    assert original in events
    assert entry['arrival_monotonic_ns']<=entry['recorded_monotonic_ns']<=entry['journal_ack_monotonic_ns']<=proof['checked_wall_ns']
    assert proof['checked_wall_ns']-entry['arrival_monotonic_ns']<=2000000000
rows=read('physics-substeps.jsonl');assert len(rows)==50000
continuity={k:0. for k in ['position','velocity_world','accel_world','angular_world','quaternion_xyzw']}
for i,row in enumerate(rows):
    assert row['phase']==['pre','post'][i%2] and row['sim_ns']==(i//2+1)*1000000 and row['available']
    if i>=2 and i%2==0:
        for k in continuity:continuity[k]=max(continuity[k],float(np.max(abs(np.array(row[k])-rows[i-1][k]))))
post={x['sim_ns']:x for x in rows if x['phase']=='post'}
imu=[e for e in events if e['kind']=='imu']
commands=read('motion-force.jsonl')
assert [c['sim_ns'] for c in commands]==list(range(anchor,25001000000,1000000))
for c in commands:
    assert c['call_returned'] and len(c['per_link'])==6 and all(x['call_returned'] for x in c['per_link'])
    assert np.allclose(np.sum([x['force_world_n'] for x in c['per_link']],axis=0),c['force_world_n'],atol=1e-12,rtol=0)
assert commands[0]['wall_ns']>=proof['checked_wall_ns']
lateral=[c for c in commands if c['force_world_n'][1]]
assert len(lateral)==1600 and lateral[0]['sim_ns']==anchor+3000000000 and lateral[-1]['sim_ns']==anchor+4599000000
assert sum(c['force_world_n'][1] for c in lateral)==0
clearance=read('support-clearance.jsonl');assert len(clearance)==25000
assert [c['sim_ns'] for c in clearance]==list(range(1000000,25001000000,1000000))
minimum=min(c['ground_clearance_m'] for c in clearance if c['sim_ns']>=anchor+2000000000);assert minimum>=.1
windows=[]
for name,start,end in [('lateral_first100ms',anchor+3000000000,anchor+3100000000),('lateral_full',anchor+3000000000,anchor+4600000000),('settled',anchor+6000000000,anchor+7000000000),('lift',anchor,anchor+2000000000)]:
    w=phase_closures(rows,start,end);w['name']=name
    raw=[e for e in imu if start<=e['sample_ns']<=end]
    stamps=np.array([e['sample_ns'] for e in raw],dtype=np.int64)
    assert len(stamps)>2 and np.all(np.diff(stamps)==4000000)
    a=np.array([Rotation.from_quat(post[e['sample_ns']]['quaternion_xyzw']).apply(e['accel_flu'])+[0,0,-9.81] for e in raw])
    dv=np.array(post[int(stamps[-1])]['velocity_world'])-post[int(stamps[0])]['velocity_world']
    dt=np.diff(stamps)[:,None]*1e-9
    trap=np.sum((a[1:]+a[:-1])*.5*dt,axis=0);right=np.sum(a[1:]*dt,axis=0)
    w['raw']=dict(start_ns=int(stamps[0]),end_ns=int(stamps[-1]),samples=len(raw),phase_ns=int(stamps[0]%4000000),right_error_norm_m_s=float(np.linalg.norm(right-dv)),trapezoid_error_norm_m_s=float(np.linalg.norm(trap-dv)))
    windows.append(w)
ulogs=[]
for meta in r['px4_ulogs']:
    path=p/meta['path'];assert hashlib.sha256(path.read_bytes()).hexdigest()==meta['sha256']
    state=ULog(str(path)).get_dataset('vehicle_status').data['arming_state'];assert len(state) and np.all(state!=2)
    ulogs.append(dict(meta,arming_records=len(state),arming_values=[int(x) for x in np.unique(state)]))
positions=np.array([t['position'] for t in post.values()]);velocities=np.array([t['velocity_world'] for t in post.values()])
summary=dict(anchor_ns=anchor,selected_sim_ns=schedule['selected_sim_ns'],counts=counts,trace_records=len(rows),continuity=continuity,
             support_steps=len(commands),lateral_steps=len(lateral),minimum_ground_clearance_m=minimum,
             max_displacement_m=float(np.max(np.linalg.norm(positions-positions[0],axis=1))),max_speed_m_s=float(np.max(np.linalg.norm(velocities,axis=1))),
             windows=windows,ulogs=ulogs,new_development_consistency_pass=windows[0]['raw']['trapezoid_error_norm_m_s']<=.02 and windows[1]['raw']['trapezoid_error_norm_m_s']<=.05,
             eligible_for_px4_fusion=False,estimator_run=False)
with (base/'audit.json').open('x') as f:json.dump(summary,f,indent=2)
print(json.dumps(summary,indent=2))
