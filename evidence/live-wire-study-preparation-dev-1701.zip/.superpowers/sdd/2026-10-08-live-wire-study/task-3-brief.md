### Task 3: Prepare the reviewable package and activation decision

**Files:** new unique `results/live-wire-study-dev-1701/study-v1/` preparation
artifacts; report `docs/LIVE_WIRE_STUDY_PREPARATION_REPORT.md`. This task creates
no live dispatch or capture output.

- [ ] Generate a prospective command, complete declaration and manifest for the
  actual installed selection using read-only resolution. Reuse the exact selected
  model/config/binaries from the installed preflight; explain and hash any later
  committed source differences. No giant inventory rescan substitutes for selection.
- [ ] Freeze the exact audit implementation/version and all selected input hashes
  before any later activation. Bind the existing one-shot dispatch behavior and
  failure preservation; don't introduce a second general launcher.
- [ ] Run Task 1 validation on the actual files; deliberately mutated copies must
  refuse. These tests are offline and create no socket or simulator. Report
  preparation qualified separately from all still-false live outcomes.
- [ ] Independent whole-package review of spec, plan, validator and auditor,
  especially the five review-focus cases; repair Important/Critical once with
  demonstrated RED/GREEN. No new physical trial as a review shortcut.
- [ ] Seal/report the prepared package and targeted tests, changed Ruff and
  `git diff --check`; commit. Update PR65 with local/remote publication distinction.
- [ ] Evaluate the separate activation gate against the latest user scope. If
  actual communication remains restricted, leave the package ready for review
  and continue independent offline goal work; never execute simply because a
  manifest exists. Do not mark the overall FlyDrones goal complete.

## Later live acceptance (not an instruction to launch now)

Once actual live communication is authorized and the above gates pass, exactly
one new normal dispatch may use the prepared production command under the
existing supervisor. Monitor the actual handle; don't restart on observation
timeouts. Audit and preserve the terminal result, even if it fails before force.
Only after normal qualification may separately frozen live fault studies proceed.
ODOMETRY/EKF2/arming remain outside this package even then.
