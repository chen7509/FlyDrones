import json
from pathlib import Path
import subprocess
import sys

import pytest
import yaml

from flydrones.connectome_training.curriculum_session import verify_source_digest
from tools.connectome_training.run_curriculum import _restart


def smoke_config(tmp_path: Path) -> Path:
    value = yaml.safe_load(
        Path("configs/connectome_curriculum_v1.yaml").read_text(encoding="utf-8")
    )
    for stage in value["stages"][:2]:
        stage["epochs_per_batch"] = 15
        stage["max_batches"] = 2
        stage["maximum_validation_loss"] = 1.0
        stage["maximum_loss_ratio"] = 1.0
    path = tmp_path / "config.yaml"
    path.write_text(yaml.safe_dump(value, sort_keys=False), encoding="utf-8")
    return path


def run_cli(config: Path, output: Path, *extra: str):
    return subprocess.run(
        [
            sys.executable,
            "tools/connectome_training/run_curriculum.py",
            "--config",
            str(config),
            "--profile",
            "smoke",
            "--output",
            str(output),
            *extra,
        ],
        check=True,
        capture_output=True,
        text=True,
    )


def test_cli_smoke_stops_and_resumes_without_replaying_batch(tmp_path):
    config = smoke_config(tmp_path)
    output = tmp_path / "run"
    first = run_cli(config, output, "--max-batches", "1")
    first_payload = json.loads(first.stdout)
    assert first_payload["status"] == "COMMITTED"
    assert first_payload["completed_stages"] == ["stability"]
    second = run_cli(config, output)
    second_payload = json.loads(second.stdout)
    assert second_payload["status"] == "COMPLETE"
    assert second_payload["completed_stages"] == ["stability", "looming"]
    reports = list((output / "reports").glob("*.json"))
    assert len(reports) == 2
    measured = json.loads(reports[0].read_text(encoding="utf-8"))["train_metrics"]
    assert measured["elapsed_wall_s"] > 0
    assert measured["peak_process_memory_bytes"] > 0
    assert measured["device"] == "cpu"
    assert measured["torch_version"]
    summary = json.loads((output / "summary.json").read_text(encoding="utf-8"))
    assert summary["evidence_class"] == "synthetic-connectome-curriculum-smoke"
    assert summary["repository_artifact_scope"] == "summary-only"
    assert summary["model_identity"].startswith("tiny-connectome:")
    assert summary["measured_batches"] == 2
    assert summary["total_training_wall_s"] > 0
    assert summary["peak_process_memory_bytes"] > 0
    assert set(summary["stage_results"]) == {"stability", "looming"}


def test_cli_restart_refuses_an_active_lock(tmp_path):
    config = smoke_config(tmp_path)
    output = tmp_path / "run"
    output.mkdir()
    (output / "run.lock").write_text('{"pid": 123}\n', encoding="utf-8")
    with pytest.raises(subprocess.CalledProcessError) as error:
        run_cli(config, output, "--restart", "--max-batches", "1")
    assert "already locked" in error.value.stderr


def test_restart_preserves_repository_ignore_policy(tmp_path):
    output = tmp_path / "run"
    output.mkdir()
    (output / ".gitignore").write_text("checkpoints/\n", encoding="utf-8")
    (output / "state.json").write_text("old", encoding="utf-8")
    _restart(output)
    assert (output / ".gitignore").read_text(encoding="utf-8") == "checkpoints/\n"
    assert not (output / "state.json").exists()


def test_full_profile_fails_closed_when_sequence_evidence_is_absent(tmp_path):
    completed = subprocess.run(
        [
            sys.executable,
            "tools/connectome_training/run_curriculum.py",
            "--config",
            "configs/connectome_curriculum_v1.yaml",
            "--profile",
            "desktop",
            "--output",
            str(tmp_path / "full"),
            "--max-batches",
            "1",
        ],
        capture_output=True,
        text=True,
    )
    assert completed.returncode != 0
    assert "sequence evidence path does not exist" in completed.stderr


def test_complete_source_digest_must_match_parameter_identity(tmp_path):
    source = tmp_path / "connectome.npz"
    source.write_bytes(b"exact-source")
    import hashlib

    expected = hashlib.sha256(source.read_bytes()).hexdigest()
    assert verify_source_digest(source, expected) == expected
    with pytest.raises(ValueError, match="source hash"):
        verify_source_digest(source, "0" * 64)
