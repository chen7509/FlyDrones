from pathlib import Path
p=Path('tests/benchmark/test_calibration_static_v3_executor.py');s=p.read_text(encoding='utf8');s+='''

def test_request_includes_native_sources_headers_and_startup_controls(tmp_path,monkeypatch):
    from tools.benchmark import calibration_capture_contract as scene_api,prepare_calibration_capture as old
    from tools.benchmark.agent_capture_runtime import AGENT_SHA256,LIBRARY_SHA256,BUNDLE_SHA256
    m=load(tmp_path,monkeypatch)
    monkeypatch.setattr(m,'source_snapshot',lambda:{'source.py':'a'*64})
    base=m.ROOT/'results/target-bearing-runtime-freeze-dev-1701/frozen-study-v1';base.mkdir(parents=True)
    binary=m.linux(base/'agent-deployment-v1/bin/MicroXRCEAgent');lib=m.linux(base/'agent-deployment-v1/lib')
    expected={'bin/MicroXRCEAgent':AGENT_SHA256,**{'lib/'+k:v for k,v in LIBRARY_SHA256.items()}}
    config=dict(schema='capture-agent-runtime-v1',binary=binary,lib_dir=lib,bundle='/bundle',port=18888)
    (base/'agent-runtime.json').write_text(json.dumps(config))
    (base/'agent-deployment.json').write_text(json.dumps(dict(bundle={'sha256':BUNDLE_SHA256},members=[dict(member=k,deployed={'sha256':v})for k,v in expected.items()])))
    libs=tmp_path/'libs';libs.mkdir()
    for name in LIBRARY_SHA256:(libs/name).write_bytes(b'fixture')
    site=tmp_path/'site';site.mkdir()
    for name in ['numpy','scipy','pyulog','pymavlink','protobuf']:
        info=site/(name+'-1.dist-info');info.mkdir();(info/'METADATA').write_text('Name: '+name+'\\nVersion: 1\\n')
    (site/'startup.pth').write_text('fixture startup source')
    monkeypatch.setattr(m,'host_path',lambda p:libs if p==lib else site if p=='/usr/lib/python3/dist-packages' else tmp_path/'absent')
    hashes={binary:AGENT_SHA256,'/bundle':BUNDLE_SHA256,**{lib+'/'+k:v for k,v in LIBRARY_SHA256.items()}}
    monkeypatch.setattr(m,'host_pin',lambda p:dict(path=p,bytes=1,sha256=hashes.get(p,'a'*64)))
    monkeypatch.setattr(scene_api,'scene_record',lambda p:dict(path=str(tmp_path/'scene'),files={'world.sdf':{'sha256':'a'*64}}))
    catalog=tmp_path/'catalog.json';catalog.write_text(json.dumps({'inventory':{'graph:resolver':['/resolver'],'graph:source':['/source.cc'],'graph:dependencies':['/header.hh']}}))
    monkeypatch.setattr(old,'CATALOG',catalog)
    request=m.identity_request()
    assert {'/source.cc','/header.hh','/etc/python3.12/sitecustomize.py','/usr/lib/python3/dist-packages/startup.pth'}.issubset(request['paths'])
''';p.write_text(s,encoding='utf8')
