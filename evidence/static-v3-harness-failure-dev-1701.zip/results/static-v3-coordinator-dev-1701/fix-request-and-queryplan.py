from pathlib import Path
p=Path('results/target-bearing-runtime-freeze-v3-dev-1701/run-static-preparation-v3.py');s=p.read_text(encoding='utf8')
s=s.replace('    request = identity_request()\n    write(OUT / "identity-request.json", request)','    request = build_request_bounded()')
a=s.index('def preidentity():')
s=s[:a]+'''def build_request_bounded():
    output=OUT/'identity-request.json'
    code="import importlib.util,sys; s=importlib.util.spec_from_file_location('fixed_static_v3_request',sys.argv[1]); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); m.write(m.OUT/'identity-request.json',m.identity_request())"
    argv=[sys.executable,'-c',code,str(Path(__file__).resolve())]
    process=None;primary=None;row=dict(argv=argv,error=None,exit=None)
    write(OUT/'request-builder-command.json',dict(argv=argv,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),start_utc=datetime.datetime.now(datetime.UTC).isoformat()))
    start=time.monotonic_ns()
    try:
        with (OUT/'request-builder.stdout').open('xb') as stdout,(OUT/'request-builder.stderr').open('xb') as stderr:
            process=subprocess.Popen(argv,stdout=stdout,stderr=stderr)
            row['pid']=process.pid
            row['exit']=process.wait(timeout=15)
        if row['exit']!=0:raise ValueError('host request builder refused')
        return json.loads(output.read_bytes())
    except BaseException as exc:
        primary=exc;row['error']=repr(exc)
        raise
    finally:
        if process is not None:row['cleanup']=cleanup_child(process)
        end=time.monotonic_ns();row.update(start_monotonic_ns=start,end_monotonic_ns=end,elapsed_ns=end-start)
        try:write(OUT/'request-builder-return.json',row)
        except Exception as exc:
            if primary is None:raise
            primary.add_note('host request terminal writer: '+repr(exc))


'''+s[a:]
needle='    for row in [r for r in rows if r.get("kind") in {"version", "hash-query"}]:\n        q = row["query"]'
replace=needle+'''
        expected_argv=[row['file'],'--version'] if row['kind']=='version' else None
        if expected_argv is not None:
            if q['argv']!=expected_argv or not (q['stdout_hex'] or q['stderr_hex']):raise ValueError('primitive exact version argv/output differs')
            if row['file_before']!=before.get(row['file']) or row['file_after']!=row['file_before']:raise ValueError('version tool per-call identity differs')
        elif len(q['argv'])!=3 or q['argv'][:2]!=['/usr/bin/sha256sum','--'] or q['argv'][2] not in requested:raise ValueError('primitive hash argv differs')
        if q['environment']!=dict(PATH='/usr/bin:/bin',LANG='C.UTF-8') or type(q['pid'])is not int or q['pid']<=0:raise ValueError('primitive tool process/environment differs')'''
s=s.replace(needle,replace)
# Retain only relevant gate counters publicly; all unrelated identities remain private.
s=s.replace('blocked_processes=first["blocked_processes"],','blocked_process_count=len(first["blocked_processes"]),').replace('docker_running=first["docker_running"],','docker_running_empty=not first["docker_running"].strip(),')
p.write_text(s,encoding='utf8')
p=Path('tools/benchmark/static_v3_identity.py');s=p.read_text(encoding='utf8').replace('import os\nimport time','import os  # noqa: E402 - builtin policy gate precedes imports\nimport time  # noqa: E402 - builtin policy gate precedes imports')
s=s.replace('                    raw = query([path, "--version"],', '                    file_before = identity(path)\n                    raw = query([path, "--version"],',1)
s=s.replace('                    emit(dict(kind="version", file=path, query=raw))','                    file_after = identity(path)\n                    emit(dict(kind="version", file=path, query=raw, file_before=file_before, file_after=file_after))\n                    if file_before != file_after:\n                        raise ValueError("version tool per-call identity changed")',1)
p.write_text(s,encoding='utf8')
