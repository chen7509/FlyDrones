# Independent static-v3 coordinator review

Reviewed HEAD/base `748c62f6e224ff7ed71941ac01a0d8bbfa7a2a4b`. Verdict: **not ready for actual coordinator CLI**. C/I/M: **0/3/0**. This is source review only; no native, WSL, observer, resource, SDK, test or network execution was performed.

## Strengths

- Literal study path and exclusive write helper preserve once-only markers; real first resource refusal precedes a static claim.
- Standalone Linux observer imports only sys/os/time, checks builtin time and observed extension inventory, and uses primitive repr plus Windows literal_eval.
- Owned Popen cleanup is bounded; systemd stop requires fresh matching InvocationID/ControlGroup; unknown escaped closure remains unknown.
- Identity and query durations are computed within each host's monotonic clock; no cross-host subtraction.
- Protocol test fixtures exercise refusal and cleanup paths without claiming native results.

## Important findings

### I1 — Bind the complete metadata launch chain before first Linux use

`results/target-bearing-runtime-freeze-v3-dev-1701/run-static-preparation-v3.py` lines 211, 221, 223, 361, 422, 433, 540, 625, 651.

execute_once calls collect/admission before preidentity builds or verifies bootstrap; admission launches /usr/bin/python3 -S with no prior host pin. Later identity launch executes /usr/bin/env and /usr/bin/timeout and the ELF interpreter before the observer's Linux pins, but bootstrap currently covers only sha256sum/python3/observer. Subsequent Linux checks cannot be before-use identity for those earlier executions.

Fix: Create and retain a reviewed host-side bootstrap before the first admission child, covering the actual metadata/control entrypoints and loader; join its bytes to later Linux identity and repeat host checks around use. Keep separate budgets and no native/SDK qualification.

### I2 — Complete the current source and interpreter-startup input request

`results/target-bearing-runtime-freeze-v3-dev-1701/run-static-preparation-v3.py` lines 29, 31, 492, 503, 510, 530.

source_snapshot is *.py only and identity_request omits catalog graph:source and graph:dependencies. Current local catalog explicitly lists tools/benchmark/native/resource_resolver.cc and local_candidates.hh; prepare_calibration_capture_v3.py:273-276 actually reads and checks the .cc source. The request also lacks explicit /etc/python3.12/sitecustomize.py and startup .pth coverage, while the eventual SDK command is ordinary python without -S; retained v2 evidence supplied by root establishes the sitecustomize path was present then, not current Linux existence. Explicit package selection also excludes catalog's fastcrc Python root. Therefore the implementation cannot claim complete current source/interpreter input prepins.

Fix: Define the exact intended interpreter startup/import input membership without executing intended SDK imports; include current startup controls or explicit audited absence, all actually used source/native-header roles, and required package/module roots. Join the selected current inputs to pre/post observer rows and the independently sealed recipe; do not certify old catalog bytes.

### I3 — Require raw hash-query evidence for every admitted file digest

`results/target-bearing-runtime-freeze-v3-dev-1701/run-static-preparation-v3.py` lines 555, 577, 589, 597, 609, 660.

validate_identity_rows accepts before/after file SHA assertions without any hash-query rows and does not reparse/join hash stdout to those SHA records when rows exist. The valid fixture at tests/benchmark/test_calibration_static_v3_executor.py:268-300 has zero hash-query rows and is accepted at line323. Real observer does emit such rows, but the acceptance contract and positive fixture independently admit caller-only digest evidence.

Fix: Validate exact ordered query coverage for bootstrap/per-phase/per-version hashes, expected argv/environment, complete raw stdout/stderr, digest/path grammar, own child exit/cleanup and clocks, and join the parsed result to each identity record. Use a production-shaped positive fixture and omission/mismatch negative cases.

## Exact reviewed identities

- `results/target-bearing-runtime-freeze-v3-dev-1701/run-static-preparation-v3.py`: `5ab32e4f236c1927f3df6e820ce469d857c7328362483524e9b05909828e9f00`
- `tools/benchmark/static_v3_identity.py`: `818308d71c8b5ea5ea90e375203c03df134383c7677ef58edfc11938cf5def41`
- `tests/benchmark/test_calibration_static_v3_executor.py`: `af902e3b9e3e099a3abfaada915d8fd4936a20a131bada01da128ee2b0ad1729`
- `results/static-v3-coordinator-dev-1701/EXECUTOR_BRIEF.md`: `da16044d438454f99e61408db225c20a95b39236abf3b8e43e9eeabf23270245`
- `docs/superpowers/specs/2026-10-15-python-extension-context-production-design.md`: `59f8923d9d9f66acbcd51a46c1f576e61d1a973ce07225c6192f5f6d4a0562fa`
- `docs/superpowers/plans/2026-10-15-python-extension-context-production.md`: `1530f717a441c511ff3b2f04c64d895239b419250a1b66a28b21b99363dfc6b9`

## Verification and qualification boundaries

Local source reads, local git HEAD/status, Get-FileHash only. No tests, target imports, Linux/WSL/native/resource/SDK commands or network executed by reviewer. Root-reported 22 pass / Ruff 0 not independently rerun.

- Actual current Linux installed membership, live source bytes, version command outcomes, available resources, manager/scope state and timing feasibility: prohibited execution and not established by source review.
- Actual full static-v3 bill/study/native success and full installed/transitive license sufficiency: no actual static run or complete recipe/input/license evidence yet.
- Hostile interpreter/tool replacement or mapped-memory authenticity: explicitly outside bounded controlled-static identity claim.
- Task1/Task2 implementation as a fresh full review: prior independent seal is prerequisite supplied by root; only necessary integration source edges were inspected here.

All source/clock/measured-calibration/accuracy/teacher/fusion/training/flight qualifications and readiness remain false. No static or physical attempt was run by this reviewer. The root reports current attempts remain unconsumed. Source approval would still not replace the separately required exact pinned recipe/current input/tool/license audit or the later actual full static-study audit.
