from pathlib import Path
p=Path('tests/benchmark/test_calibration_static_v3_executor.py');s=p.read_text(encoding='utf8');s+='''

@pytest.mark.parametrize('fault',['empty','missing_version','extension','changed_file','bad_clock'])
def test_preidentity_terminal_and_membership_are_independently_verified(tmp_path,monkeypatch,fault):
    m=load(tmp_path,monkeypatch)
    monkeypatch.setattr(m,'source_snapshot',lambda:{'fixture':'source'})
    file=dict(requested='/usr/bin/sha256sum',resolved='/usr/bin/sha256sum',bytes=3,sha256='a'*64,identity={'inode':1})
    request=dict(sources={'fixture':'source'},paths=['/usr/bin/sha256sum'],roots=[],versions=['/usr/bin/sha256sum'],bootstrap=[dict(path='/usr/bin/sha256sum',bytes=3,sha256='a'*64)])
    monkeypatch.setattr(m,'host_pin',lambda p:dict(path=p,bytes=3,sha256='a'*64))
    monkeypatch.setattr(m,'linux',lambda p:str(p))
    monkeypatch.setattr(m,'OBSERVER',Path(__file__))
    rows=[dict(kind='bootstrap',file=file),dict(kind='begin',requested=['/usr/bin/sha256sum'],uid=1000,manager_control_environment=dict(PATH='/usr/bin:/bin',LANG='C.UTF-8',XDG_RUNTIME_DIR='/run/user/1000'),imported_extensions=[],start_monotonic_ns=1),dict(kind='file',phase='before',file=file),dict(kind='version',file='/usr/bin/sha256sum',query=dict(exit=0,error=None,reader_complete=True,stdout_hex='31',stderr_hex='',start_monotonic_ns=2,end_monotonic_ns=3,elapsed_ns=1,cleanup=dict(waited=True,escaped_closure='unknown'))),dict(kind='file',phase='after',file=file),dict(kind='terminal',error=None,imported_extensions=[],start_monotonic_ns=1,end_monotonic_ns=4,elapsed_ns=3)]
    if fault=='empty':rows=[dict(rows[1],requested=[]),rows[-1]]
    if fault=='missing_version':rows=[r for r in rows if r['kind']!='version']
    if fault=='extension':rows[-1]['imported_extensions']=['_json']
    if fault=='changed_file':rows[4]=dict(rows[4],file=dict(file,sha256='b'*64))
    if fault=='bad_clock':rows[-1]['elapsed_ns']=0
    def remote(*argv,**kw):
        (m.OUT/'preidentity-primitive.txt').write_text(''.join(repr(r)+'\\n' for r in rows),encoding='utf8')
        return subprocess.CompletedProcess(argv,0,b'',b'')
    monkeypatch.setattr(m,'remote',remote)
    with pytest.raises(ValueError):m.identity_run('preidentity',request)
''';p.write_text(s,encoding='utf8')
