from pathlib import Path
p=Path('results/target-bearing-runtime-freeze-v3-dev-1701/run-static-preparation-v3.py');s=p.read_text(encoding='utf8')
s=s.replace('BOOTSTRAP_TOOLS = ["/usr/bin/sha256sum", "/usr/bin/python3"]','BOOTSTRAP_TOOLS = ["/usr/bin/sha256sum", "/usr/bin/python3", "/usr/bin/env", "/usr/bin/timeout", "/lib64/ld-linux-x86-64.so.2"]')
s=s.replace('    observed = remote("/usr/bin/python3", "-S", "-c", code, timeout=30)','    startup_pins=[host_pin(p) for p in ["/usr/bin/python3","/lib64/ld-linux-x86-64.so.2"]]\n    verify_bootstrap(startup_pins)\n    observed = remote("/usr/bin/python3", "-S", "-c", code, timeout=30)\n    verify_bootstrap(startup_pins)')
s=s.replace('        wsl_stderr_hex=observed.stderr.hex(),','        admission_bootstrap=startup_pins,\n        wsl_stderr_hex=observed.stderr.hex(),',1)
s=s.replace('            role == "runtime:dependencies"\n            or role == "graph:resolver"','            role == "runtime:dependencies"\n            or role.startswith("graph:")',1)
s=s.replace('    roots = ["/usr/lib/python3.12", "/usr/share/doc"]','    paths.update(["/etc/python3.12/sitecustomize.py",linux(ROOT/"tools/benchmark/native/local_candidates.hh")])\n    roots = ["/usr/lib/python3.12", "/etc/python3.12", "/usr/share/doc"]')
s=s.replace('            name = entry.name\n','            name = entry.name\n            if entry.is_file() and (name.endswith(".pth") or name in {"sitecustomize.py", "usercustomize.py"}):\n                paths.add(base+"/"+name)\n            if name=="__pycache__" and entry.is_dir():\n                roots.append(base+"/"+name)\n',1)
# New -B only static SDK, explicit independent profile ruling, existing cache inputs pinned.
s=s.replace('        "tools.benchmark.prepare_calibration_capture_v3",','        "tools.benchmark.prepare_calibration_capture_v3",',1)
s=s.replace('        "180s",\n        "/usr/bin/python3",\n        "-m",','        "180s",\n        "/usr/bin/python3",\n        "-B",\n        "-m",',1)
# Use prepin closure after shared final verifier; do not accept merely successful child output.
s=s.replace('    return json.loads(result.stdout)','    checked=json.loads(result.stdout)\n    from tools.benchmark.calibration_capture_contract import scene_record\n    from tools.benchmark.calibration_capture_study import SOURCE\n    closure=validate_study_inputs(json.loads((OUT/"preidentity.json").read_bytes()),json.loads((FOLDER/"runtime-binding-v4.json").read_bytes()),scene_record(SOURCE))\n    write(OUT/"actual-study-prepin-closure.json",closure)\n    return checked',1)
# Every metadata input record must be joined to its owned raw SHA command, not an asserted digest.
needle='    return begin\n\n\ndef identity_run'
new='''    used_hashes=set()
    def link_hash(index,file):
        if index<0 or rows[index].get('kind')!='hash-query' or index in used_hashes:raise ValueError('missing/duplicate raw hash query')
        q=rows[index]['query'];data=bytes.fromhex(q['stdout_hex'])
        if q['argv']!=['/usr/bin/sha256sum','--',file['requested']] or data!=(file['sha256']+'  '+file['requested']+'\\n').encode():raise ValueError('raw hash query/file join differs')
        used_hashes.add(index)
    for i,row in enumerate(rows):
        if row['kind'] in {'bootstrap','file'}:link_hash(i-1,row['file'])
        if row['kind']=='version':
            link_hash(i-2,row['file_before']);link_hash(i-1,row['file_after'])
            a,b=rows[i-2]['query'],rows[i-1]['query'];v=row['query']
            if a['end_monotonic_ns']>v['start_monotonic_ns'] or v['end_monotonic_ns']>b['start_monotonic_ns']:raise ValueError('version per-call raw hash ordering differs')
    if used_hashes!={i for i,r in enumerate(rows) if r['kind']=='hash-query'}:raise ValueError('extra unbound raw hash query')
    return begin


def validate_study_inputs(identity,binding,scene):
    approved={r['requested']:r for r in identity['files_before']}
    copied={linux(FOLDER/'capture-input-v1'/name):(linux(Path(scene['path'])/name),row['sha256']) for name,row in scene['files'].items()}
    produced={linux(FOLDER/name) for name in ['wire-config.json','agent-runtime.json','agent-cache-reuse.json','sdk/python-context.json','sdk/entry-dependencies/entry-bill.json']}
    produced.update(binding.get('inventory',{}).get('runtime:entry-context-artifacts',[]))
    joins=[]
    for row in binding['baseline']['files']:
        path=row['requested']
        if path in approved:
            original=approved[path]
            if any(row.get(k)!=original.get(k) for k in ['resolved','sha256','bytes','identity','path_identity']):raise ValueError('actual study prepin identity changed')
            joins.append(dict(path=path,kind='preapproved'))
        elif path in copied:
            source,h=copied[path]
            if approved.get(source,{}).get('sha256')!=h or row['sha256']!=h:raise ValueError('copied scene lacks source prepin')
            joins.append(dict(path=path,kind='exact_scene_copy',source=source))
        elif path in produced and path.startswith(linux(FOLDER)+'/'):
            joins.append(dict(path=path,kind='declared_producer_output'))
        else:raise ValueError('actual study file absent from approved prepin: '+path)
    return dict(static_preapproved_input_join=True,files=joins,source_qualified=False)


def decode_prefix(raw):
    rows=[];error=None
    for line in raw.decode('utf8',errors='replace').splitlines():
        try:
            row=ast.literal_eval(line)
            if type(row)is not dict:raise ValueError('primitive row is not dict')
            rows.append(row)
        except (SyntaxError,ValueError) as exc:
            error=repr(exc);break
    return dict(rows=rows,parse_error=error)


def identity_run'''
assert needle in s;s=s.replace(needle,new,1)
# Recover bounded primitive prefix and TimeoutExpired pipes even when remote result was never assigned.
needle='    finally:\n        ended = time.monotonic_ns()\n        row = dict(\n            exit=result.returncode if result is not None else None,'
replace='''    finally:
        recovery_error=None
        try:
            if output.exists():
                with output.open('rb') as stream:raw=stream.read(16*1024**2+1)
                if len(raw)>16*1024**2:raise ValueError('primitive journal cap exceeded')
            if primary is not None:write(OUT/(label+'-decoded-prefix.json'),decode_prefix(raw))
        except Exception as exc:
            recovery_error=repr(exc)
            if primary is not None:primary.add_note('primitive partial recovery: '+repr(exc))
        ended = time.monotonic_ns()
        row = dict(
            recovery_error=recovery_error,
            exit=result.returncode if result is not None else None,'''
assert needle in s;s=s.replace(needle,replace,1)
s=s.replace('            stdout_hex=result.stdout.hex() if result else None,\n            stderr_hex=result.stderr.hex() if result else None,','            stdout_hex=result.stdout.hex() if result is not None else (getattr(primary,"output",None) or b"").hex(),\n            stderr_hex=result.stderr.hex() if result is not None else (getattr(primary,"stderr",None) or b"").hex(),',1)
p.write_text(s,encoding='utf8')
p=Path('tools/benchmark/static_v3_identity.py');s=p.read_text(encoding='utf8').replace('if name.endswith(".py") or ".so" in name','if name.endswith((".py", ".pyc", ".pth")) or ".so" in name');p.write_text(s,encoding='utf8')
