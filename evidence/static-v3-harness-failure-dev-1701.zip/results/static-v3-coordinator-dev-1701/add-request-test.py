from pathlib import Path
p=Path('tests/benchmark/test_calibration_static_v3_executor.py');s=p.read_text(encoding='utf8');s+='''

def test_request_builder_timeout_cleans_only_own_child(tmp_path,monkeypatch):
    m=load(tmp_path,monkeypatch)
    child=Child()
    def wait(timeout):
        child.calls.append(('wait',timeout))
        if timeout==15:raise subprocess.TimeoutExpired('fixture request',15)
        return -15
    child.wait=wait
    monkeypatch.setattr(m.subprocess,'Popen',lambda *a,**kw:child)
    with pytest.raises(subprocess.TimeoutExpired):m.build_request_bounded()
    assert 'terminate' in child.calls and ('wait',5) in child.calls
    saved=json.loads((m.OUT/'request-builder-return.json').read_bytes())
    assert saved['error'] and saved['cleanup']['exit']==-15
''';p.write_text(s,encoding='utf8')
