from pathlib import Path
p=Path('tests/benchmark/test_calibration_static_v3_executor.py');s=p.read_text(encoding='utf8').replace('["empty", "missing_version", "extension", "changed_file", "bad_clock"]','["empty", "missing_version", "extension", "changed_file", "bad_clock", "valid", "wrongargv", "emptyversion"]')
s=s.replace('            query=dict(\n                exit=0,','            file_before=file, file_after=file,\n            query=dict(\n                argv=["/usr/bin/sha256sum","--version"],environment=dict(PATH="/usr/bin:/bin",LANG="C.UTF-8"),pid=432,\n                exit=0,',1)
s=s.replace('    if fault == "empty":\n        rows', '    if fault == "wrongargv":rows[3]["query"]["argv"]=["/wrong", "--version"]\n    if fault == "emptyversion":rows[3]["query"]["stdout_hex"]=""\n    if fault == "empty":\n        rows',1)
s=s.replace('    with pytest.raises(ValueError):\n        m.identity_run("preidentity", request)', '    if fault=="valid":\n        assert m.identity_run("preidentity",request)["files_before"]==[file]\n    else:\n        with pytest.raises(ValueError):m.identity_run("preidentity", request)',1)
p.write_text(s,encoding='utf8')
