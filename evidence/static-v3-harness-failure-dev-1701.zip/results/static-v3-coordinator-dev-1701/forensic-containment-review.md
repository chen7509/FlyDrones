# Independent forensic and containment review

**Actual v3 status: CONSUMED_FAILED_UNADMITTED_HARNESS_ESCAPE.** This is not an overall C0/I0/M0 source approval. The earlier independent review's no-execution statement applied only to its earlier review time; the later real dispatch is now established by retained evidence.

## Actual evidence

- Real unit `fly-calibration-prepare-67600195ae0306816f63eb94.scope`, Invocation `585195c554f64dabb7412f4f764be722`; Windows owned Popen16984 exited1 and was waited. SDK/interpreter-context PID43964 agrees.
- Partial bill:29 entries started,28 classified,64 tool queries,463 retained initial file records. All64 raw query JSONs match the embedded bill; their per-query input-before/after records match, and local elapsed/exit/reader/cap fields are consistent.
- All145 declared candidate inputs have retained initial identities among those file records. This does not mean final candidate processing or closure completed: `candidates=[]`, `files_after=[]`, `tools_after={}`, and `observed_context_after` is absent.
- Query64 ldd returned0 with empty stderr. Parsing then rejected `/usr/local/lib/python3.12/dist-packages/numpy/_core/../../numpy.libs/libscipy_openblas64_-f48b354e.so`; RPATH was `$ORIGIN/../../numpy.libs`. This is parser refusal after retained output, not an OOM or absent-library finding.
- Actual current SDK context records CPython3.12.3/SOABI cpython-312-x86_64-linux-gnu/dlopen_flags2, PID43964. _json and _contextvars have zero-needed metadata/query pairs58/59 and61/62. Their symbols_resolved/runtime_import_verified remain false.
- Actual before/after limits match512MiB/swap0/CPU100/tasks64. SDK local elapsed27842605763ns; cgroup peak536870912B/max events1600/oom0/oom_kill0. These facts do not backfill admission or prove minimum memory/OOM causation.
- Later separate release evidence supports the original cgroup's disappearance: manager LoadState=not-found and directory test exit1. No unit stop occurred; escaped descendant closure remains unknown.
- The373-file source snapshot is POST. Seven current source hashes match recorder/post-snapshot records; no complete predispatch source/input/tool/license attestation is established. Fixed folder exists; final study.json was not produced.

## Correction and consumed-source blockers

FIXTURE_SCOPE_CORRECTION.json accurately supersedes synthetic admission counters, source_stable, postidentity.fixture_only and owned_group_released. Original fixture flags remain raw and are not actual evidence. Fixed-root attempt.json absence does not undo actual scope/SDK consumption.

- Actual unadmitted harness escape in the frozen scope-absence fixture: configure omitted a Popen stub while mocking safety/evidence paths.
- Frozen coordinator scope-absence path ignores manager return code.
- Frozen primitive observer secondary-writer failure can mask the primary failure.
- Prior independent review's partial fixes were not a final whole-change approval; current consumed revision must not be relabeled C0/I0/M0 or GREEN.

No frozen v3 CLI, observer, producer or executor suite is authorized for recovery/retry. All eight qualifications and readiness remain false; no physical attempt is established.

## Narrow new containment review

Acceptable for its explicitly limited normal-subprocess/supported-os test-body policy; no concrete new blocking defect identified in the three new guard files.

Autouse fixture selects explicit static executor test filenames; Popen._execute_child catches ordinary subprocess and saved original Popen class references, supported os entrypoints are denied, explicit inert doubles remain usable.

Retained final verification reports7pass0.14s/Ruff0; I did not run it. The retained7-failure RED is missing-interface RED. The three new guard files are separate from consumed v3 sources. The boundary makes no adversarial/FFI, collection-time, captured raw syscall or production dispatch guarantee. Future production pytest-context refusal, explicit cwd, literal claim/recipe/preidentity/nonce checks remain independent work.

## Report review and limits

Reviewed failure report SHA `30a1be2702b84a893d61efaa42afd8d4aae5e97dbca2160642e301988b951ac4`; no material factual contradiction identified in the inspected failure/admission/source/release separation.

- Explicitly distinguish 145 declared candidates with retained initial file identities from empty final candidates[] and missing files_after/tools_after/observed_context_after.
- Additively clarify escaped-attempt-actual-summary.json actual_fixed_study_exists=false as folder_exists=true and study_json_exists=false; preserve original summary.
- Archive CRC/size/SHA/exact membership/287 historical ZIP and publication statements require the separate sealing/publication audit; this seat has not established them.

Only local file reads, local JSON comparisons/counts and file hashing. No tests/target imports/WSL/native/observer/SDK/metadata/resource/process inspection/network performed by this reviewer.

## Reviewed identities

- `tools/benchmark/software_process_boundary.py`: `ea6ec69df99b2ad8e4823d265e285bda898741ef4ef3eae3781709f2be52d469`
- `tests/benchmark/conftest.py`: `e2b76c0e04b4fdd555a23310535b5b09cb5b0817f4bc94ae7c70df5506648e83`
- `tests/benchmark/test_static_harness_containment.py`: `a3f6947a7389bc97f9da1fc5c0db4729e3807b9ea3149324bdd76bb44ed71179`
- `docs/superpowers/specs/2026-10-15-static-harness-containment-and-v3-failure-design.md`: `d49c24a9604ad6d762b8f1ce801b0cc123da240fa6b948c2616da2f50915cef5`
- `docs/superpowers/plans/2026-10-15-static-harness-containment-and-v3-failure.md`: `914cfb44c1b0562b0eaa235b4118af3538000bee3788c23143bf38742cbdce77`
- `results/static-v3-coordinator-dev-1701/FIXTURE_SCOPE_CORRECTION.json`: `3603f5a3b1f5947d3ac06f73dfe98fcadb7253f517e488b839044975f30e681b`
- `results/static-v3-coordinator-dev-1701/escaped-attempt-actual-summary.json`: `b58bebeaca4166cac7c5ea247d3aab4aa0bcb9a3e34b9f09aaaf4a682864900c`
- `results/static-v3-coordinator-dev-1701/escaped-attempt-owned-release-followup.json`: `176e82955289c5960bbb884915b8a3682c56bce1efd12745015105de48bcf30e`

Frozen consumed v3 remains inadmissible and must not be rerun or changed to recover this attempt. Narrow containment may be retained independently. Separate retained-source research and independent new production/executor specification are required before a future revision.
