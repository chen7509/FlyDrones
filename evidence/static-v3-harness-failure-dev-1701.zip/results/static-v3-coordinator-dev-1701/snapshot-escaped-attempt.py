import datetime,hashlib,json,shutil,subprocess
from pathlib import Path
root=Path.cwd();raw=root/'results/static-v3-coordinator-dev-1701';snap=raw/'escaped-attempt-source';snap.mkdir()
records=[]
paths=[root/'results/target-bearing-runtime-freeze-v3-dev-1701/run-static-preparation-v3.py',root/'tests/benchmark/test_calibration_static_v3_executor.py']
for scope in ['src/flydrones','tools/benchmark','tools/connectome']:
 paths += [p for p in (root/scope).rglob('*.py') if '__pycache__' not in p.parts]
for p in sorted(set(paths)):
 rel=p.relative_to(root);b=p.read_bytes();target=snap/rel;target.parent.mkdir(parents=True,exist_ok=True)
 with target.open('xb') as f:f.write(b)
 records.append(dict(path=rel.as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),snapshot=target.relative_to(root).as_posix()))
run=json.loads((raw/'absence-red.json').read_bytes())
assert run['source_before']==run['source_after']
for name,h in run['source_before'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h,name
with (raw/'escaped-attempt-source-postsnapshot.json').open('xb') as f:f.write(json.dumps(dict(scope='POST escaped actualSDKattempt snapshot; seven recorder pre/post hashes join, no retroactive complete predispatch source pin',utc=datetime.datetime.now(datetime.UTC).isoformat(),members=records,source_before_after=run['source_before']),indent=2).encode())
parent=root/'results/target-bearing-runtime-freeze-v3-dev-1701'
for name in ['sdk-inside-before.json','sdk-inside-after.json','native-freeze-failure.json']:
 r=json.loads((parent/name).read_bytes());print(name,json.dumps(r)[:2500])
print('source_snapshots',len(records))
