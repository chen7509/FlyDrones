from pathlib import Path
root=Path.cwd();raw=root/'results/static-v3-coordinator-dev-1701'
spec='''# Static executor harness containment and consumed-v3 failure design

Trigger: the new scope-absence test called the real Popen because configure() mocked admission/source/preidentity/release but omitted the process boundary. A real systemd scope and prepare_v3 ran from inherited repository cwd despite fixture PYTHONPATH, then failed. This is an actual unadmitted, incompletely reviewed attempt. Static-v3 is CONSUMED_FAILED, regardless of missing fixed-root attempt.json. No current v3 script/parser/test suite is to be executed or changed to retry it. All source/raw snapshots stay immutable; fixture true flags do not establish actual admission/source/release.

Immediate independent containment production: add tools/benchmark/software_process_boundary.py and tests/benchmark/conftest.py. For audited test_calibration_static_vN_executor.py bodies, an autouse guard must replace Popen._execute_child and os process-entry primitives before test fixtures run. Explicit protocol stubs remain possible, but an omitted stub cannot reach the OS through the normal subprocess API or direct supported os spawn/exec/system/fork. Test the guard first using inert process and os doubles; no RED may attempt an actual native process. The original consumed v3 test file is preserved unchanged and not rerun. The guard tests themselves are opt-in to the same policy. Other deliberate native consumer test files remain unaffected; they retain their own original gates. This is a controlled-software test boundary, not a sandbox against arbitrary Python/FFI, captured raw syscalls or collection-time code. Audit test imports/collection separately. Do not provide an automatic allow-native switch for these executor unit tests.

Future v4 executor/producer must separately reject pytest-context native dispatch in the production launch path, use explicit cwd, and require literal coordinator claim/recipe/preidentity/nonce joins on the SDK side before folder/query side effects. No actual native scope may be launched inside software pytest; actual once execution remains an independently reviewed standalone CLI. These future v4 changes are not implemented by the immediate guard.

Failure research next, before any v4 static study: inspect retained query63/64 and strict _absolute rejection of /usr/local/.../numpy/_core/../../numpy.libs/... paths. Bind pinned loader RPATH/$ORIGIN/actual component-and-symlink semantics and notices using retained official sources; do not just collapse '..', ignore the line, change LD/RPATH/caps, or rerun ldd/readelf/SDK/import/observer. Preserve raw requested loader spelling, resolved identity/aliases, all strong/weak undefined context, exact ordinary trace/renderer/Agent coverage and source/binding obligations. A new independent concrete production spec and fixed study/coordinator are required after research. This is not permission for a blind folder retry.

The actual512MiB/swap0/CPU100/tasks64 scope and28s failure are not admitted resource validation. Actual memory.peak536870912/events max1600/oom0/oom_kill0 do not prove minimum memory, exact system peak or OOM cause. No fresh real dual1GiB admission or complete new Linux preidentity occurred. No physical PX4/Agent/sensors/native consumer/calibration ran. All8/readiness false and original physical4GiB/load/safety/RTF gates remain.
'''
(root/'docs/superpowers/specs/2026-10-15-static-harness-containment-and-v3-failure-design.md').write_text(spec,encoding='utf8')
plan='''# Containment and consumed-v3 failure plan

Independent scope after actual harness escape; standing autonomy applies, no per-step approval. Current consumed producer/coordinator/observer/test sources are frozen and may not be rerun. Preserve the actual attempt and supersede synthetic fixture evidence with an additive correction.

- [ ] Implement the default audited executor test process boundary; inert backend RED/GREEN, no actual child, necessary guard integration, independent review.
- [ ] Audit actual v3 raw queries/context/limits/clocks/owned release/source snapshot and fixture/actual split; report, seal CRC/size/SHA/exact membership and unchanged history; onlypersonal publication/PR65 exact head/body.
- [ ] Research typed loader-selected lexical path/symlink semantics from retained raw/pinned primary source without new target commands; independent new production/executor spec before any v4 study. No automatic directory retry.

Future actual CLI needs all original fresh resources/prepins/firstfacts/two admissions/exclusiveclaim/owned limits and complete source/runtime/binding/material/notices audits. Add producer-side claim and pytest-context dispatch refusal plus explicit cwd in the new revision. These are future work, not credentials of v3. Full physical/calibration/learning/fair-baseline goals remain unchanged; automation active, goal blocked without fake resume/complete.
'''
(root/'docs/superpowers/plans/2026-10-15-static-harness-containment-and-v3-failure.md').write_text(plan,encoding='utf8')
(root/'tests/benchmark/test_static_harness_containment.py').write_text('''"""Inert backend proof only; never starts an external process."""
from types import SimpleNamespace
from pathlib import Path
import pytest


def test_guard_blocks_saved_popen_class_without_reaching_backend(monkeypatch):
    from tools.benchmark.software_process_boundary import install, ProcessBoundaryError
    calls=[]
    class SavedPopen:
        def _execute_child(self,*a,**kw):calls.append(a)
        def __init__(self,*a,**kw):self._execute_child(*a,**kw)
    process=SimpleNamespace(Popen=SavedPopen)
    operating=SimpleNamespace(system=lambda *a:calls.append(a),execve=lambda *a:calls.append(a))
    install(monkeypatch,process_api=process,os_api=operating)
    with pytest.raises(ProcessBoundaryError):SavedPopen(['wsl','fixture'])
    with pytest.raises(ProcessBoundaryError):operating.system('fixture command')
    with pytest.raises(ProcessBoundaryError):operating.execve('/fixture',[],{})
    assert calls==[]


def test_guard_permits_explicit_inert_protocol_double(monkeypatch):
    from tools.benchmark.software_process_boundary import install
    class SavedPopen:
        def _execute_child(self):raise AssertionError('inert original must not run')
    process=SimpleNamespace(Popen=SavedPopen)
    install(monkeypatch,process_api=process,os_api=SimpleNamespace())
    marker=object()
    monkeypatch.setattr(process,'Popen',lambda *a,**kw:marker)
    assert process.Popen('inert protocol') is marker


@pytest.mark.parametrize('name,expected',[('test_calibration_static_v3_executor.py',True),('test_calibration_static_v4_executor.py',True),('test_static_harness_containment.py',True),('test_openvins_dataset_consumer.py',False),('test_capture_contract.py',False)])
def test_guard_selection_is_explicit(name,expected):
    from tools.benchmark.software_process_boundary import guard_required
    assert guard_required(Path(name)) is expected
''',encoding='utf8')
