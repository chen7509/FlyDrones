"""Seal retained failed sources and actual/fixture raw. Never imports a producer."""
import hashlib
import json
import zipfile
from pathlib import Path

ROOT=Path.cwd()
RAW=ROOT/'results/static-v3-coordinator-dev-1701'
ACTUAL=ROOT/'results/target-bearing-runtime-freeze-v3-dev-1701'
NAME='static-v3-harness-failure-dev-1701'
ARCHIVE=ROOT/'evidence'/f'{NAME}.zip'
MAP=ROOT/'evidence'/f'{NAME}.sha256.json'
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return json.loads(p.read_bytes().decode('utf-8-sig'))
def relative(p): return p.relative_to(ROOT).as_posix()
def write(p,v):
    with p.open('xb') as f: f.write(json.dumps(v,ensure_ascii=False,indent=2).encode('utf-8'))

assert not ARCHIVE.exists() and not MAP.exists()
private=RAW/'initial-resource-private.json'
explicit=[
 'tools/benchmark/prepare_calibration_capture_v3.py',
 'tools/benchmark/static_v3_identity.py',
 'tools/benchmark/software_process_boundary.py',
 'tests/benchmark/test_calibration_static_v3_executor.py',
 'tests/benchmark/conftest.py',
 'tests/benchmark/test_static_harness_containment.py',
 'docs/TARGET_BEARING_STATIC_V3_HARNESS_FAILURE_REPORT.md',
 'docs/superpowers/specs/2026-10-15-static-harness-containment-and-v3-failure-design.md',
 'docs/superpowers/plans/2026-10-15-static-harness-containment-and-v3-failure.md',
 'docs/superpowers/specs/2026-10-15-python-extension-context-production-design.md',
 'docs/superpowers/plans/2026-10-15-python-extension-context-production.md',
 'evidence/flydrones-history-through-admitted-executor-dev-1701.json',
 'evidence/python-extension-context-production-publication.json',
]
files=set(ROOT/p for p in explicit)
for folder in [RAW,ACTUAL]:
    files.update(p for p in folder.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo') and p != private)
assert private not in files
raw_inventory=read(private)
rows=raw_inventory['windows']+raw_inventory['wsl']
empty=sha(b'')
needles={r['argv_sha256'].encode() for r in rows if r.get('argv_sha256') and r['argv_sha256']!=empty}
compound=[]
manifest=[]
for p in sorted(files):
    b=p.read_bytes()
    assert not any(n in b for n in needles), f'private argv hash found in {relative(p)}'
    manifest.append(dict(path=relative(p),bytes=len(b),sha256=sha(b)))
    if p.suffix=='.json':
        try: data=json.loads(b.decode('utf-8-sig'))
        except (ValueError,UnicodeError): continue
        stack=[data]
        while stack:
            item=stack.pop()
            if isinstance(item,dict):
                if {'pid','name','argv_sha256'} <= item.keys():
                    if any(all(item.get(k)==r.get(k) for k in ['pid','name','argv_sha256']) for r in rows): compound.append(relative(p))
                stack.extend(item.values())
            elif isinstance(item,list): stack.extend(item)
assert not compound,compound
value=dict(schema='static-v3-failure-exact-member-map-v1',scope='CONSUMED_FAILED_UNADMITTED_HARNESS_ESCAPE; prepublication forensic seal, not source/runtime qualification',members=manifest,private_excluded=dict(path=relative(private),bytes=private.stat().st_size,sha256=sha(private.read_bytes())),nonempty_private_argv_hashes=len(needles),private_compound_matches=0)
write(MAP,value)
with zipfile.ZipFile(ARCHIVE,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for row in manifest: z.write(ROOT/row['path'],row['path'])
    z.write(MAP,relative(MAP))
receipt=dict(schema='static-v3-failure-seal-receipt-v1',archive=relative(ARCHIVE),sha256=sha(ARCHIVE.read_bytes()),bytes=ARCHIVE.stat().st_size,members=len(manifest)+1,mapped_members=len(manifest),manifest_sha256=sha(MAP.read_bytes()),nonempty_private_argv_hashes=len(needles),private_compound_matches=0,preseal_exact_set=[r['path'] for r in manifest],actual_status='CONSUMED_FAILED_UNADMITTED_HARNESS_ESCAPE')
write(RAW/'seal-receipt.json',receipt)
print({k:v for k,v in receipt.items() if k!='preseal_exact_set'})
