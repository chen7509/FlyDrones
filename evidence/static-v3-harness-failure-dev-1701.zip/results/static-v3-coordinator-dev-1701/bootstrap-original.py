from pathlib import Path
r=Path('results/static-v3-coordinator-dev-1701');r.mkdir()
(r/'initial-readonly.py').write_bytes(Path('results/python-extension-context-production-dev-1701/initial-readonly.py').read_bytes())
s=Path('results/python-extension-context-production-dev-1701/verify.py').read_text(encoding='utf8-sig')
a=s.index('sources=');b=s.index('\ndef hashes',a)
s=s[:a]+"sources=['results/target-bearing-runtime-freeze-v3-dev-1701/run-static-preparation-v3.py','tools/benchmark/static_v3_identity.py','tools/benchmark/prepare_calibration_capture_v3.py','tools/benchmark/calibration_capture_study_v3.py','tools/benchmark/native_entry_context_v3.py','tests/benchmark/test_calibration_static_v3_executor.py','results/target-bearing-runtime-freeze-v2-dev-1701/run-static-preparation-v2.py']"+s[b:]
(r/'verify.py').write_text(s,encoding='utf8')
s=Path('tests/benchmark/test_calibration_static_v2_executor.py').read_text(encoding='utf8').split('def test_version_postpin_failure')[0].replace('static_v2','static_v3').replace('freeze-v2','freeze-v3').replace('preparation-v2','preparation-v3').replace('frozen-study-v2','frozen-study-v3')
s+='''

def test_only_execute_flag_and_observer_source_has_no_import_effects(tmp_path,monkeypatch):
    import ast
    m=load(tmp_path,monkeypatch)
    observer=Path(__file__).resolve().parents[2]/'tools/benchmark/static_v3_identity.py'
    tree=ast.parse(observer.read_text(encoding='utf8'))
    imports=[n for n in ast.walk(tree) if isinstance(n,(ast.Import,ast.ImportFrom))]
    names={a.name for n in imports if isinstance(n,ast.Import) for a in n.names}
    assert names=={'os','sys','time'} and not any(isinstance(n,ast.ImportFrom) for n in imports)
    assert m.observer_arguments('/request','/output')[:2]==['/usr/bin/python3','-S']
    with pytest.raises(SystemExit):m.main(['--preidentity'])


def test_preidentity_rejects_changed_host_bootstrap_bytes(tmp_path,monkeypatch):
    m=load(tmp_path,monkeypatch)
    record=dict(path='/usr/bin/sha256sum',sha256='a'*64,bytes=2)
    monkeypatch.setattr(m,'host_pin',lambda p:dict(record,sha256='b'*64))
    with pytest.raises(ValueError,match='bootstrap'):m.verify_bootstrap([record])


def test_primitive_decoder_retains_prefix_before_terminal_error(tmp_path,monkeypatch):
    m=load(tmp_path,monkeypatch)
    raw=b"{'kind': 'file', 'file': {'requested': '/a'}}\\n{'kind': 'terminal', 'error': 'fixture failure'}\\n"
    rows=m.decode_observer(raw)
    assert rows[0]['file']['requested']=='/a' and rows[-1]['error']=='fixture failure'
    with pytest.raises(ValueError):m.decode_observer(raw+b'bad line\\n')


def test_preidentity_invalid_manager_uid_rejected_before_claim(tmp_path,monkeypatch):
    m=load(tmp_path,monkeypatch)
    with pytest.raises(ValueError):m.verify_preidentity({'error':None,'sources':m.source_snapshot(),'files_before':[],'files_after':[],'uid':1000,'manager_control_environment':{'XDG_RUNTIME_DIR':'/run/user/0'}})
'''
Path('tests/benchmark/test_calibration_static_v3_executor.py').write_text(s,encoding='utf8')
