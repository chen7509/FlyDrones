import datetime,json,re,subprocess
from pathlib import Path
root=Path.cwd();raw=root/'results/static-v3-coordinator-dev-1701';parent=root/'results/target-bearing-runtime-freeze-v3-dev-1701'
inside=json.loads((parent/'sdk-inside-before.json').read_bytes())
unit='fly-calibration-prepare-67600195ae0306816f63eb94.scope';group=inside['cgroup']
assert re.fullmatch('fly-calibration-prepare-[0-9a-f]{24}\\.scope',unit) and group.startswith('/user.slice/user-1000.slice/') and group.endswith('/'+unit) and '..'notin group.split('/')
props=dict(line.split('=',1) for line in inside['systemd_properties'].splitlines())
assert props['InvocationID']=='585195c554f64dabb7412f4f764be722' and props['ControlGroup']==group
commands=[['wsl','-d','Ubuntu','--','/usr/bin/env','-i','PATH=/usr/bin:/bin','LANG=C.UTF-8','XDG_RUNTIME_DIR=/run/user/1000','/usr/bin/systemctl','--user','show',unit,'--property=InvocationID','--property=ControlGroup','--property=LoadState','--property=ActiveState'],['wsl','-d','Ubuntu','--','/usr/bin/test','-d','/sys/fs/cgroup'+group]]
rows=[]
for argv in commands:
 p=subprocess.run(argv,capture_output=True,timeout=15);rows.append(dict(argv=argv,exit=p.returncode,stdout_hex=p.stdout.hex(),stderr_hex=p.stderr.hex()))
released=rows[0]['exit']==0 and b'LoadState=not-found' in bytes.fromhex(rows[0]['stdout_hex']) and rows[1]['exit']==1
with (raw/'escaped-attempt-owned-release-followup.json').open('xb') as f:f.write(json.dumps(dict(utc=datetime.datetime.now(datetime.UTC).isoformat(),unit=unit,original_invocation=props['InvocationID'],original_cgroup=group,rows=rows,owned_cgroup_released=released,escaped_closure='unknown',unit_stop_performed=False,scope='single readonly actual ownership-release followup; fixture release flag is not actual evidence'),indent=2).encode())
print(json.dumps(dict(owned_cgroup_released=released,manager_exit=rows[0]['exit'],group_test_exit=rows[1]['exit'])))
bill=json.loads((parent/'frozen-study-v3/sdk/entry-dependencies/entry-bill.json').read_bytes())
queries=bill['queries'];last=queries[-1]
print(json.dumps(dict(entries=len(bill['entries']),queries=len(queries),candidates=len(bill['input_candidates']),files=len(bill['files']),complete=bill['complete'],error=bill['error'],last_query=dict(kind=last['kind'],argv=last['argv'],exit=last['exit'],stdout_hex=last['stdout_hex'],stderr_hex=last['stderr_hex']),zero_python_entries=[r['file']['requested'] for r in bill['entries'] if r.get('trace_kind')=='zero_direct_needed_python_extension'])))
