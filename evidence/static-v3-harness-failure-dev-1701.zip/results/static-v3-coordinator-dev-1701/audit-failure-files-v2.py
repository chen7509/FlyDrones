"""Additive correction of file-audit SDK receipt key, not a native replay."""
from pathlib import Path

original = Path(__file__).with_name('audit-failure-files.py')
source = original.read_text(encoding='utf-8')
source = source.replace("read(p)['exit']==0", "read(p)['returncode']==0")
source = source.replace("    with (RAW/name).open('xb') as f:", "    if (RAW/name).exists():\n        assert read(RAW/name) == value, name\n        return\n    with (RAW/name).open('xb') as f:")
exec(compile(source, str(original), 'exec'), {'__name__': '__main__'})
