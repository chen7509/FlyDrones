import datetime
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root=Path.cwd();raw=Path(__file__).resolve().parent
label=sys.argv[1];argv=sys.argv[2:]
sources=['results/target-bearing-runtime-freeze-v3-dev-1701/run-static-preparation-v3.py','tools/benchmark/static_v3_identity.py','tools/benchmark/prepare_calibration_capture_v3.py','tools/benchmark/calibration_capture_study_v3.py','tools/benchmark/native_entry_context_v3.py','tests/benchmark/test_calibration_static_v3_executor.py','results/target-bearing-runtime-freeze-v2-dev-1701/run-static-preparation-v2.py']
def hashes():return {s:hashlib.sha256((root/s).read_bytes()).hexdigest() if (root/s).exists() else None for s in sources}
if '-m' in argv and 'pytest' in argv and not any(x.startswith('--basetemp') for x in argv):
    argv += ['--basetemp',str(raw/(label+'-fixtures'))]
before=hashes();start=datetime.datetime.now(datetime.UTC).isoformat();env=dict(os.environ,PYTHONPATH=os.pathsep.join([str(root),str(root/'src')]))
p=subprocess.run(argv,capture_output=True,env=env)
for ext,b in [('stdout',p.stdout),('stderr',p.stderr)]:
    with (raw/(label+'.'+ext)).open('xb') as f:f.write(b)
with (raw/(label+'.json')).open('xb') as f:f.write(json.dumps(dict(argv=argv,exit=p.returncode,start_utc=start,end_utc=datetime.datetime.now(datetime.UTC).isoformat(),interpreter=sys.executable,recorder_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),child_environment={k:env.get(k) for k in ['PYTHONPATH','PATH','VIRTUAL_ENV','PYTHONHOME']},source_before=before,source_after=hashes()),indent=2).encode())
print(p.stdout.decode(errors='replace')[-6000:]);print(p.stderr.decode(errors='replace')[-1500:]);print('actual_exit',p.returncode)
raise SystemExit(p.returncode)
