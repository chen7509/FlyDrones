from pathlib import Path
p=Path('tests/benchmark/test_calibration_static_v3_executor.py');s=p.read_text(encoding='utf8');needle='    def remote(*argv, **kw):\n        (m.OUT / "preidentity-primitive.txt").write_text'
a=s.index(needle)
s=s[:a]+'''    # Explicit raw hashing protocol rows, never a real SHA child or Linux proof.
    def hashrow(file,start):
        return dict(kind='hash-query',query=dict(argv=['/usr/bin/sha256sum','--',file['requested']],environment=dict(PATH='/usr/bin:/bin',LANG='C.UTF-8'),pid=433,exit=0,error=None,reader_complete=True,stdout_hex=(file['sha256']+'  '+file['requested']+'\\n').encode().hex(),stderr_hex='',start_monotonic_ns=start,end_monotonic_ns=start+1,elapsed_ns=1,cleanup=dict(waited=True,escaped_closure='unknown')))
    expanded=[]
    for row in rows:
        if row['kind']=='bootstrap':expanded += [hashrow(row['file'],0),row]
        elif row['kind']=='file':expanded += [hashrow(row['file'],2 if row['phase']=='before' else 8),row]
        elif row['kind']=='version':
            row['query'].update(start_monotonic_ns=5,end_monotonic_ns=6)
            expanded += [hashrow(file,4),hashrow(file,6),row]
        else:
            if row['kind']=='begin':row['start_monotonic_ns']=0
            if row['kind']=='terminal':row.update(start_monotonic_ns=0,end_monotonic_ns=10,elapsed_ns=0 if fault=='bad_clock' else 10)
            expanded.append(row)
    rows=expanded

'''+s[a:]
s+='''

def test_actual_prepare_includes_existing_python_cache_bytes(tmp_path,monkeypatch):
    from types import SimpleNamespace
    from tools.benchmark import prepare_calibration_capture_v3 as prepare
    from test_calibration_capture_study_v3 import test_actual_prepare_v3_pipeline_keeps_empty_selection_self_and_context as pipeline
    source=tmp_path/'cached-module.py';source.write_text('# source')
    cache=tmp_path/'cached-module.pyc';cache.write_bytes(b'fixture bytecode, never executed')
    monkeypatch.setattr(prepare,'sys',SimpleNamespace(modules={'fixture_source':SimpleNamespace(__file__=str(source),__cached__=str(cache))}))
    pipeline(tmp_path,monkeypatch)
    binding=json.loads((tmp_path/'out/frozen/runtime-binding-v4.json').read_bytes())
    assert str(cache) in binding['inventory']['runtime:python-modules']
''';p.write_text(s,encoding='utf8')
