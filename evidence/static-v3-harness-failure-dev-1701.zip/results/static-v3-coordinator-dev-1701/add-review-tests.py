from pathlib import Path
p=Path('tests/benchmark/test_calibration_static_v3_executor.py');s=p.read_text(encoding='utf8');s+='''

def test_before_use_bootstrap_includes_launchers_and_loader(tmp_path,monkeypatch):
    m=load(tmp_path,monkeypatch)
    assert {'/usr/bin/env','/usr/bin/timeout','/lib64/ld-linux-x86-64.so.2','/usr/bin/python3','/usr/bin/sha256sum'}.issubset(m.BOOTSTRAP_TOOLS)


def test_study_input_closure_refuses_unapproved_runtime_file(tmp_path,monkeypatch):
    m=load(tmp_path,monkeypatch)
    before=dict(requested='/approved',resolved='/approved',bytes=1,sha256='a'*64,identity={'inode':1},path_identity={'inode':1})
    binding=dict(inventory={},baseline={'files':[dict(before,requested='/new-file',role='runtime:python-modules')]})
    with pytest.raises(ValueError,match='prepin'):m.validate_study_inputs({'files_before':[before]},binding,{'path':'/scene','files':{}})


def test_identity_timeout_retains_existing_primitive_prefix_and_stdout(tmp_path,monkeypatch):
    m=load(tmp_path,monkeypatch)
    monkeypatch.setattr(m,'linux',lambda p:str(p))
    monkeypatch.setattr(m,'OBSERVER',Path(__file__))
    monkeypatch.setattr(m,'verify_bootstrap',lambda r:None)
    def remote(*a,**k):
        (m.OUT/'preidentity-primitive.txt').write_bytes(b"{'kind':'file','file':{'requested':'/prefix'}}\\n{'truncated'")
        raise subprocess.TimeoutExpired(a,45,output=b'actual fixture prefix stdout',stderr=b'fixture stderr')
    monkeypatch.setattr(m,'remote',remote)
    request=dict(paths=['/prefix'],roots=[],versions=[],bootstrap=[])
    with pytest.raises(subprocess.TimeoutExpired):m.identity_run('preidentity',request)
    row=json.loads((m.OUT/'preidentity-return.json').read_bytes())
    assert row['raw_bytes']>0 and bytes.fromhex(row['stdout_hex'])==b'actual fixture prefix stdout'
    prefix=json.loads((m.OUT/'preidentity-decoded-prefix.json').read_bytes())
    assert prefix['rows'][0]['file']['requested']=='/prefix' and prefix['parse_error']


def test_identity_rejects_claimed_hashes_without_raw_hash_queries(tmp_path,monkeypatch):
    m=load(tmp_path,monkeypatch)
    file=dict(requested='/a',resolved='/a',bytes=1,sha256='a'*64)
    rows=[dict(kind='bootstrap',file=file),dict(kind='begin',requested=['/a'],uid=1000,imported_extensions=[],start_monotonic_ns=1),dict(kind='file',phase='before',file=file),dict(kind='file',phase='after',file=file),dict(kind='terminal',error=None,imported_extensions=[],end_monotonic_ns=3,elapsed_ns=2)]
    request=dict(paths=['/a'],roots=[],versions=[],bootstrap=[dict(path='/a',bytes=1,sha256='a'*64)])
    with pytest.raises(ValueError,match='hash'):m.validate_identity_rows(rows,request)
''';p.write_text(s,encoding='utf8')
