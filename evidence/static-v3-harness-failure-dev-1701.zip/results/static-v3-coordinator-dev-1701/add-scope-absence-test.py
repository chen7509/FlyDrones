from pathlib import Path
p=Path('tests/benchmark/test_calibration_static_v3_executor.py');s=p.read_text(encoding='utf8');s+='''

def test_scope_absence_nonzero_return_is_not_admission(tmp_path,monkeypatch):
    m=load(tmp_path,monkeypatch);configure(m,monkeypatch)
    monkeypatch.setattr(m,'manager_call',lambda *a:subprocess.CompletedProcess(a,1,b'LoadState=not-found\\n',b'fixture nonzero'))
    with pytest.raises(ValueError,match='absence'):m.execute()
    assert not (m.OUT/'attempt.json').exists()
''';p.write_text(s,encoding='utf8')
