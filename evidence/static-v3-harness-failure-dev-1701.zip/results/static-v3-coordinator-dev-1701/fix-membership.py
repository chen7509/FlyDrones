from pathlib import Path
p=Path('results/target-bearing-runtime-freeze-v3-dev-1701/run-static-preparation-v3.py');s=p.read_text(encoding='utf8').replace('import importlib.metadata\n','')
s=s.replace('        row=ast.literal_eval(line)','        try:row=ast.literal_eval(line)\n        except (ValueError,SyntaxError) as exc:raise ValueError("malformed primitive row") from exc')
a=s.index('    roots=[\'/usr/lib/python3.12\'');b=s.index('    bootstrap=',a)
s=s[:a]+'''    roots=['/usr/lib/python3.12','/usr/share/doc']
    packages={}
    for base in ['/usr/lib/python3/dist-packages','/home/yuchen7509/.local/lib/python3.12/site-packages']:
        if not host_path(base).is_dir():continue
        for entry in host_path(base).iterdir():
            name=entry.name
            if name in {'gz','sdformat14','numpy','numpy.libs','scipy','scipy.libs','pymavlink','pyulog','google'}:
                if entry.is_dir():roots.append(base+'/'+name)
            if name.startswith(('sdformat14','gz_')) and entry.is_file() and (name.endswith('.py') or '.so' in name):paths.add(base+'/'+name)
            if name.endswith(('.dist-info','.egg-info')) and name.lower().startswith(('numpy-','scipy-','pyulog-','pymavlink-','protobuf-')):
                roots.append(base+'/'+name)
                meta=entry/'METADATA'
                if not meta.exists():meta=entry/'PKG-INFO'
                text=meta.read_text(encoding='utf8')
                package=next(x[6:] for x in text.splitlines() if x.startswith('Name: '))
                version=next(x[9:] for x in text.splitlines() if x.startswith('Version: '))
                if package in packages:raise ValueError('ambiguous installed package metadata')
                packages[package]=version
    if set(packages)!={'numpy','scipy','pyulog','pymavlink','protobuf'}:raise ValueError('required current package metadata missing')
    for relative in ['build/px4_sitl_default/rootfs/gz_env.sh','build/px4_sitl_default/etc/init.d-posix/rcS','src/modules/simulation/gz_bridge/server.config','Tools/simulation/gz/models/x500/model.sdf','Tools/simulation/gz/models/x500_base/model.sdf','LICENSE']:
        paths.add('/home/yuchen7509/PX4-Autopilot/'+relative)
    paths.add(linux(ROOT/'results/agent-capture-contract-dev-1701/agent-runtime.json'))
'''+s[b:]
s=s.replace('agent_files=checks)','agent_files=checks,packages=packages)')
s=s.replace('        begin=next(r for r in rows if r.get(\'kind\')==\'begin\')', '''        begin=validate_identity_rows(rows,request)''',1)
s=s.replace("row=dict(exit=result.returncode if result else None", "ended=time.monotonic_ns()\n        row=dict(exit=result.returncode if result is not None else None")
s=s.replace('end_monotonic_ns=time.monotonic_ns(),elapsed_ns=time.monotonic_ns()-start','end_monotonic_ns=ended,elapsed_ns=ended-start')
# Add row audit before observer invocation function.
a=s.index('def identity_run(')
s=s[:a]+'''def validate_identity_rows(rows,request):
    kinds=[r.get('kind') for r in rows]
    if kinds.count('begin')!=1 or kinds.count('terminal')!=1 or kinds[-1]!='terminal':raise ValueError('one complete primitive sequence required')
    if any(k not in {'bootstrap','begin','file','version','terminal','hash-query'} for k in kinds):raise ValueError('unknown primitive row')
    begin=rows[kinds.index('begin')];terminal=rows[-1]
    if begin.get('imported_extensions')!=[] or terminal.get('imported_extensions')!=[] or terminal.get('error') is not None:raise ValueError('primitive import policy/terminal refused')
    start,end,elapsed=(begin['start_monotonic_ns'],terminal['end_monotonic_ns'],terminal['elapsed_ns'])
    if any(type(x)is not int or x<0 for x in [start,end,elapsed]) or end-start!=elapsed or end<start:raise ValueError('primitive local clock facts differ')
    requested=begin['requested']
    if not requested or len(set(requested))!=len(requested) or requested!=sorted(requested) or len(requested)>8192 or not set(request['paths']).issubset(requested):raise ValueError('primitive exact request membership differs')
    before={r['file']['requested']:r['file'] for r in rows if r.get('kind')=='file' and r['phase']=='before'}
    if set(before)!=set(requested):raise ValueError('primitive input pin coverage differs')
    boots=[r['file'] for r in rows if r.get('kind')=='bootstrap']
    if [r['requested'] for r in boots]!=[r['path'] for r in request['bootstrap']]:raise ValueError('primitive bootstrap membership differs')
    for row,expected in zip(boots,request['bootstrap']):
        if row['sha256']!=expected['sha256'] or row['bytes']!=expected['bytes'] or row!=before.get(row['requested']):raise ValueError('primitive bootstrap identity differs')
    versions=[r for r in rows if r.get('kind')=='version']
    if [r['file'] for r in versions]!=request['versions']:raise ValueError('primitive version membership differs')
    for row in [r for r in rows if r.get('kind') in {'version','hash-query'}]:
        q=row['query']
        if q['exit']!=0 or type(q['exit'])is not int or q['error'] is not None or q['reader_complete'] is not True or q['cleanup'].get('waited')is not True:raise ValueError('primitive tool query refused')
        if q['end_monotonic_ns']-q['start_monotonic_ns']!=q['elapsed_ns'] or q['elapsed_ns']<0:raise ValueError('primitive tool clock differs')
        if len(bytes.fromhex(q['stdout_hex']))>2*1024**2 or len(bytes.fromhex(q['stderr_hex']))>2*1024**2:raise ValueError('primitive tool stream cap exceeded')
    return begin


'''+s[a:]
p.write_text(s,encoding='utf8')
p=Path('tools/benchmark/static_v3_identity.py');s=p.read_text(encoding='utf8');s=s.replace('import os\nimport sys\nimport time','import sys\n\nif "time" not in sys.builtin_module_names:\n    raise RuntimeError("builtin time required before import")\n\nimport os\nimport time')
s=s.replace('            for folder, _, names in os.walk(root):','            def fail_walk(exc):\n                raise exc\n            for folder, _, names in os.walk(root, onerror=fail_walk):')
s=s.replace("            emit(dict(kind='terminal', error=error, end_monotonic_ns=time.monotonic_ns(),\n                      elapsed_ns=time.monotonic_ns() - started,", "            ended = time.monotonic_ns()\n            emit(dict(kind='terminal', error=error, start_monotonic_ns=started, end_monotonic_ns=ended,\n                      elapsed_ns=ended - started,")
p.write_text(s,encoding='utf8')
