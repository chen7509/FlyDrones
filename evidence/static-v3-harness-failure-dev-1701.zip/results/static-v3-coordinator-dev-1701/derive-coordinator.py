from pathlib import Path
r=Path('results/static-v3-coordinator-dev-1701')
p=Path('results/target-bearing-runtime-freeze-v3-dev-1701');p.mkdir()
old=Path('results/target-bearing-runtime-freeze-v2-dev-1701/run-static-preparation-v2.py').read_text(encoding='utf8')
s=old.replace('v2','v3').replace('from tools.benchmark.run_openvins_dataset_consumer import admission, linux, write','from tools.benchmark.run_openvins_dataset_consumer import heavy_process, linux, write\nimport ast\nimport psutil')
a=s.index('def preidentity():');b=s.index('def verify_preidentity(',a)
s=s[:a]+ '# Primitive identity observation and admission are defined below.\n\n'+s[b:]
a=s.index('def linux_postidentity():');b=s.index('def admitted(',a)
s=s[:a]+s[b:]
s=s.replace('def main():','def main(argv=None):').replace('    args = parser.parse_args()','    args = parser.parse_args(argv)')
a=s.index('    action = parser.add_mutually');b=s.index('    try:\n        result = execute()',a)
s=s[:a]+'''    parser.add_argument("--execute-once", action="store_true", required=True)
    parser.parse_args(argv)
'''+s[b:]
s=s.replace('if __name__ == "__main__":\n    raise SystemExit(main())','')
s=s.replace('def execute():','def execute_once():').replace('result = execute()','result = execute_once()')
s+='\nexecute = execute_once\n'
(p/'run-static-preparation-v3.py').write_text(s,encoding='utf8')
(r/'EXECUTOR_BRIEF.md').write_text('''# Static-v3 coordinator implementation brief

Base748c62f; execute current Task3 after Task1/2 independent software seal. New coordinator source lives in its prospective fixed parent; creating that parent with source only is preparation, not an attempt. Claim/study/firstfacts/scope/actual SDK command remain absent until reviewed execution. The whole parent is not an absence gate because the plan explicitly locates its source there; every actual claim/study/firstfacts remains exclusive.

Ruling: Linux preflight never imports project modules/json/pathlib/hashlib/subprocess. A standalone python -S observer imports only os/sys and builtin time, primitive repr records decoded by Windows ast.literal_eval. SHA/version children are owned fork/exec, no shell; hash tool/interpreter/observer are first byte-pinned on Windows through declared WSL UNC paths, then Linux requested/resolved/stat/SHA before/after with the exact hash tool. This bootstrap is controlled-static file identity, not source authentication/mapped-memory proof. The actual observer validates no selected extension is present; current SDK imports occur only later inside the admitted production process.

Metadata limits: each tool bounded2MiB/stream, hash/version deadline10s, terminate5/kill5; whole observer30s GNU timeout+5kill, Windows45s. Hard16MiB primitive journal/8192 files. These separate metadata limits do not alter512MiB/swap0CPU100tasks64/210scope180inner+10kill240launcher or reserve1GiB each. Traversal includes current stdlib/Gz/NumPy/SciPy and actual installed package notices/source; fixed old catalog supplies candidates only. Every actual input is freshly pinned, not certified by old metadata. Any refusal retains prefix/terminal and cannot be gate-polled.

Full static once requires independent implementation/recipe/source/input/license audit; no manual generic worker or old preidentity rerun. All8/readiness remain false. Native tool/observer/SDK execution is not part of software tests.\n''',encoding='utf8')
