"""Entry-context dependency production. File traces grant no runtime/source authority."""

from __future__ import annotations

import copy
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys
import sysconfig
import threading
import time
from pathlib import Path

from tools.benchmark.capture_contract import _typed_equal
from tools.benchmark.declared_runtime_snapshot import file_record, write_manifest

SCHEMA = "native-entry-context-bill-v3"
QUALIFICATION = {
    k: False for k in ("source", "clock", "measured_calibration", "accuracy", "teacher", "fusion", "training", "flight")
}
LIMIT = 2 * 1024**2
OGRE_NAMES = {"libOgreNextMain.so.2.3.1", "libOgreNextPlanarReflections.so.2.3.1", "libOgreNextHlmsPbs.so.2.3.1"}
OGRE_DIR = "/usr/lib/x86_64-linux-gnu/OGRE-2.3"
BASE_ENV = {"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8"}


def context_digest(context):
    return hashlib.sha256(json.dumps(context, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def validate_python_context(context):
    keys = {
        "schema",
        "pid",
        "interpreter",
        "implementation",
        "version",
        "version_info",
        "soabi",
        "ext_suffix",
        "dlopen_flags",
        "modules",
    }
    if type(context) is not dict or set(context) != keys or context["schema"] != "python-extension-context-v1":
        raise ValueError("exact Python extension context required")
    version = context["version_info"]
    if (
        type(version) is not list
        or len(version) != 3
        or any(type(v) is not int or v < 0 for v in version)
        or context["implementation"] != "cpython"
        or type(context["version"]) is not str
        or not context["version"]
        or type(context["pid"]) is not int
        or context["pid"] <= 0
        or type(context["dlopen_flags"]) is not int
        or context["dlopen_flags"] < 0
        or type(context["soabi"]) is not str
        or not context["soabi"].startswith(f"cpython-{version[0]}{version[1]}-")
        or context["ext_suffix"] != "." + context["soabi"] + ".so"
    ):
        raise ValueError("Python interpreter ABI/flags context differs")
    modules = context["modules"]
    if type(modules) is not list or len(modules) > 4096:
        raise ValueError("bounded Python module context required")
    names = set()
    for module in modules:
        if type(module) is not dict or set(module) != {"name", "origin", "module_file", "spec_origin", "loader"}:
            raise ValueError("exact Python module context required")
        if (
            type(module["name"]) is not str
            or re.fullmatch(r"[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*", module["name"], re.ASCII) is None
            or module["name"] in names
            or module["loader"] != "_frozen_importlib_external.ExtensionFileLoader"
        ):
            raise ValueError("unsupported/duplicate Python extension module")
        names.add(module["name"])
        origin = module["origin"]
        if (
            type(origin) is not dict
            or module["module_file"] != origin.get("resolved")
            or module["spec_origin"] != origin.get("resolved")
        ):
            raise ValueError("Python module origin context differs")
        _absolute(origin["requested"])
        _absolute(origin["resolved"])


def collect_python_context():
    """Observe already imported SDK modules only; never import to obtain a witness."""
    modules = []
    for name, module in sorted(tuple(sys.modules.items())):
        spec = getattr(module, "__spec__", None)
        loader = getattr(spec, "loader", None)
        cls = type(loader)
        if cls.__module__ + "." + cls.__name__ != "_frozen_importlib_external.ExtensionFileLoader":
            continue
        origin, module_file = getattr(spec, "origin", None), getattr(module, "__file__", None)
        if not origin or not module_file or Path(origin).resolve() != Path(module_file).resolve():
            raise ValueError("current Python extension origin differs")
        record = file_record(str(Path(origin).resolve()))
        modules.append(
            dict(
                name=name,
                origin=record,
                spec_origin=str(Path(origin).resolve()),
                module_file=str(Path(module_file).resolve()),
                loader=cls.__module__ + "." + cls.__name__,
            )
        )
    context = dict(
        schema="python-extension-context-v1",
        pid=os.getpid(),
        interpreter=file_record(sys.executable),
        implementation=sys.implementation.name,
        version=sys.version,
        version_info=list(sys.version_info[:3]),
        soabi=sysconfig.get_config_var("SOABI"),
        ext_suffix=sysconfig.get_config_var("EXT_SUFFIX"),
        dlopen_flags=sys.getdlopenflags(),
        modules=modules,
    )
    validate_python_context(context)
    return context


def module_for(context, record):
    selected = [m for m in context["modules"] if m["origin"]["resolved"] == record["resolved"]]
    if len(selected) > 1:
        raise ValueError("ambiguous Python module origin")
    return selected[0] if selected else None


def parse_extension_metadata(data, module):
    text = data.decode("utf8", errors="strict")
    if module is None:
        raise ValueError("zero-needed extension lacks current module context")
    for label in ("Class", "Data", "Type", "Machine"):
        if len(re.findall(r"^\s*" + label + ":", text, re.MULTILINE)) != 1:
            raise ValueError("unique ELF header field required")
    for pattern in (
        r"^\s*Class:\s+ELF64\s*$",
        r"^\s*Data:\s+2's complement, little endian\s*$",
        r"^\s*Type:\s+DYN \(Shared object file\)\s*$",
        r"^\s*Machine:\s+Advanced Micro Devices X86-64\s*$",
    ):
        if len(re.findall(pattern, text, re.MULTILINE)) != 1:
            raise ValueError("unsupported extension ELF header")
    if text.count("Program Headers:") != 1 or text.count("Symbol table '.dynsym'") != 1:
        raise ValueError("complete ELF program/dynamic-symbol metadata required")
    if len(re.findall(r"^\s*Number of program headers:", text, re.MULTILINE)) != 1:
        raise ValueError("unique program header count required")
    header_count = re.search(r"^\s*Number of program headers:\s*([0-9]+)\s*$", text, re.MULTILINE)
    if header_count is None or not 1 <= int(header_count[1]) <= 65536:
        raise ValueError("complete program header count required")
    programs = text.split("Program Headers:", 1)[1].split("Section to Segment mapping:", 1)[0]
    program_rows = []
    for line in programs.splitlines():
        if not line.strip() or line.strip().startswith("Type "):
            continue
        parts = line.split()
        if len(parts) not in (8, 9) or not re.fullmatch(r"[A-Z_0-9]+", parts[0]):
            raise ValueError("malformed program header row")
        if any(not re.fullmatch(r"(?:0x)?[0-9a-fA-F]+", v) for v in [*parts[1:6], parts[-1]]):
            raise ValueError("invalid program header numeric fields")
        flags = "".join(parts[6:-1])
        if not flags or any(c not in "RWE" for c in flags):
            raise ValueError("invalid program header flags")
        program_rows.append(
            dict(
                type=parts[0],
                offset=parts[1],
                virtual=parts[2],
                physical=parts[3],
                file_size=parts[4],
                memory_size=parts[5],
                flags=flags,
                align=parts[-1],
            )
        )
    kinds = [r["type"] for r in program_rows]
    if len(program_rows) != int(header_count[1]) or "LOAD" not in kinds or kinds.count("DYNAMIC") != 1 or "INTERP" in kinds:
        raise ValueError("complete extension program headers require LOAD/PT_DYNAMIC and no PT_INTERP")
    match = re.search(r"Symbol table '\.dynsym' contains ([0-9]+) entries:\n", text)
    if match is None or not 1 <= int(match[1]) <= 65536:
        raise ValueError("bounded complete dynamic symbols required")
    rows = []
    for line in text[match.end() :].splitlines():
        if not line.strip() or line.strip().startswith("Num:"):
            continue
        parts = line.split()
        if len(parts) not in (7, 8) or not re.fullmatch(r"[0-9]+:", parts[0]):
            raise ValueError("malformed dynamic symbol row")
        index = int(parts[0][:-1])
        if index != len(rows) or not re.fullmatch(r"[0-9a-fA-F]+", parts[1]) or not parts[2].isdigit():
            raise ValueError("dynamic symbol index/value differs")
        rows.append(
            dict(
                index=index,
                value=parts[1],
                size=int(parts[2]),
                type=parts[3],
                bind=parts[4],
                visibility=parts[5],
                ndx=parts[6],
                name=parts[7] if len(parts) == 8 else "",
            )
        )
    if len(rows) != int(match[1]):
        raise ValueError("incomplete dynamic symbol table")
    initializer = "PyInit_" + module["name"].rsplit(".", 1)[-1]
    selected = [r for r in rows if r["name"] == initializer]
    if (
        len(selected) != 1
        or selected[0]["type"] != "FUNC"
        or selected[0]["bind"] != "GLOBAL"
        or not selected[0]["ndx"].isdigit()
        or int(selected[0]["ndx"]) == 0
    ):
        raise ValueError("expected defined Python initializer missing")
    return dict(
        elf_class="ELF64",
        machine="x86-64",
        elf_type="ET_DYN",
        program_headers=program_rows,
        pt_dynamic=True,
        pt_interp=False,
        initializer=initializer,
        symbols=rows,
        symbols_resolved=False,
    )


def classify_trace(entry, query):
    if bytes.fromhex(query["stderr_hex"]):
        raise ValueError("dependency trace stderr not empty")
    data = bytes.fromhex(query["stdout_hex"])
    if entry["entry_kind"] == "python_extension_entry" and not entry["dynamic"]["needed"]:
        if entry["elf_metadata"] is None or data != b"\tstatically linked\n":
            raise ValueError("exact zero-needed Python diagnostic required")
        return dict(trace_kind="zero_direct_needed_python_extension", selected=[], nonfiles=[])
    return dict(trace_kind="dynamic_dependencies", **_ldd(data))


def declared_python_context(binding):
    """Bind actual context bytes through an opt-in, exact baseline inventory role."""
    paths = binding.get("inventory", {}).get("runtime:python-extension-context")
    if paths is None:
        return None
    if (
        binding.get("schema") != "capture-resource-binding-v4"
        or binding.get("capture_profile") != "target-bearing-raw-v1"
        or type(paths) is not list
        or len(paths) != 1
    ):
        raise ValueError("Python context requires one declared raw binding role")
    from tools.benchmark.capture_contract import read_declaration

    path = _absolute(paths[0])
    record = file_record(path)
    selected = [
        {k: v for k, v in r.items() if k != "role"}
        for r in binding["baseline"]["files"]
        if r.get("requested") == path and r.get("role") == "runtime:python-extension-context"
    ]
    if len(selected) != 1 or not _typed_equal(selected[0], record):
        raise ValueError("Python context file baseline join differs")
    context = read_declaration(path)
    validate_python_context(context)
    return dict(schema="bound-python-extension-context-v1", file=record, context_sha256=context_digest(context))


def audit_python_runtime(expected, raw_maps, phase):
    current = None
    try:
        current = collect_python_context()
        return _audit_python_runtime_context(expected, current, raw_maps, phase)
    except Exception as exc:
        exc.observed_python_context = current
        raise


def _audit_python_runtime_context(expected, current, raw_maps, phase):
    from tools.benchmark.owned_runtime_maps import _device_parts, parse_maps

    if phase not in ("postimports", "postfinalize", "postfirststep"):
        raise ValueError("unsupported Python self-process phase")
    validate_python_context(expected)
    validate_python_context(current)
    if current["pid"] != os.getpid():
        raise ValueError("Python context is not the current SDK process")
    for key in ("interpreter", "implementation", "version", "version_info", "soabi", "ext_suffix", "dlopen_flags"):
        if not _typed_equal(current[key], expected[key]):
            raise ValueError("Python runtime interpreter/ABI differs")
    actual = {m["name"]: m for m in current["modules"]}
    maps = parse_maps(raw_maps)
    for module in expected["modules"]:
        if not _typed_equal(module, actual.get(module["name"])):
            raise ValueError("required current Python module origin missing/different")
        file = module["origin"]
        device = _device_parts(file["identity"]["device"])
        if not any(
            row["path"] == file["resolved"]
            and row["inode"] == file["identity"]["inode"]
            and tuple(int(p, 16) for p in row["device"].split(":")) == device
            for row in maps
        ):
            raise ValueError("required Python extension mapping missing/different")
    return dict(
        phase=phase,
        pid=current["pid"],
        observed_context=current,
        static_context_pid=expected["pid"],
        context_sha256=context_digest(expected),
        module_origins_consistent=True,
        required_modules=[m["name"] for m in expected["modules"]],
        runtime_import_verified=False,
        symbols_resolved=False,
        runtime_closure_qualified=False,
    )


def tool_paths():
    return dict(ldd="/usr/bin/ldd", readelf="/usr/bin/readelf", python=sys.executable, loader="/lib64/ld-linux-x86-64.so.2")


def _run_tool(argv, env):
    """Bound owned Popen and each stream; escaped descendants remain unknown."""
    start = time.monotonic_ns()
    row = dict(
        argv=argv,
        environment=env,
        pid=None,
        start_utc=datetime.datetime.now(datetime.UTC).isoformat(),
        end_utc=None,
        start_monotonic_ns=start,
        end_monotonic_ns=None,
        elapsed_ns=None,
        exit=None,
        stdout_hex="",
        stderr_hex="",
        error=None,
        cleanup=None,
        output_limit_exceeded=False,
        reader_complete=False,
    )
    process = None
    streams = [bytearray(), bytearray()]
    exceeded = threading.Event()
    readers, read_errors = [], []

    def read(pipe, bucket):
        try:
            while chunk := os.read(pipe.fileno(), 65536):
                remaining = LIMIT - len(bucket)
                bucket.extend(chunk[:remaining])
                if len(chunk) > remaining:
                    exceeded.set()
                    return
        except Exception as exc:
            read_errors.append(repr(exc))

    try:
        process = subprocess.Popen(argv, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        row["pid"] = process.pid
        for pipe, bucket in zip((process.stdout, process.stderr), streams, strict=True):
            thread = threading.Thread(target=read, args=(pipe, bucket), daemon=True)
            thread.start()
            readers.append(thread)
        deadline = time.monotonic() + 10
        while process.poll() is None:
            if exceeded.is_set():
                raise ValueError("dependency command output cap exceeded")
            if time.monotonic() >= deadline:
                raise subprocess.TimeoutExpired(argv, 10)
            exceeded.wait(0.02)
        row["exit"] = process.returncode
    except BaseException as exc:
        row["error"] = repr(exc)
    finally:
        if process is not None:
            cleanup = dict(before=process.poll(), exit=None, descendants="unknown")
            if cleanup["before"] is None:
                try:
                    process.terminate()
                    cleanup["terminate_sent"] = True
                except Exception as exc:
                    cleanup["terminate_error"] = repr(exc)
            try:
                cleanup["exit"] = process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                try:
                    process.kill()
                    cleanup["kill_sent"] = True
                except Exception as exc:
                    cleanup["kill_error"] = repr(exc)
                try:
                    cleanup["exit"] = process.wait(timeout=5)
                except Exception as exc:
                    cleanup["error"] = repr(exc)
            except Exception as exc:
                cleanup["error"] = repr(exc)
            if row["exit"] is None:
                row["exit"] = cleanup["exit"]
            if cleanup.get("error"):
                row["error"] = row["error"] or cleanup["error"]
            row["cleanup"] = cleanup
            deadline = time.monotonic() + 1
            for thread in readers:
                thread.join(timeout=max(0, deadline - time.monotonic()))
            row["reader_complete"] = not any(t.is_alive() for t in readers)
            # Never block closing a pipe held by a still-live reader. That case
            # refuses the whole bill; enclosing scope bounds residual resources.
            if row["reader_complete"]:
                for pipe in (process.stdout, process.stderr):
                    pipe.close()
            else:
                row["error"] = row["error"] or "owned stream readers incomplete; residual descendants unknown"
        row["output_limit_exceeded"] = exceeded.is_set()
        if exceeded.is_set() or read_errors:
            row["error"] = row["error"] or (repr(read_errors) if read_errors else "output cap exceeded")
        row.update(
            stdout_hex=streams[0].hex(),
            stderr_hex=streams[1].hex(),
            end_monotonic_ns=time.monotonic_ns(),
            end_utc=datetime.datetime.now(datetime.UTC).isoformat(),
        )
        row["elapsed_ns"] = row["end_monotonic_ns"] - start
    return row


def _absolute(path):
    if type(path) is not str or not Path(path).is_absolute() or ".." in Path(path).parts:
        raise ValueError("absolute non-traversing declared path required")
    return path


def _successful(row):
    if (
        type(row["exit"]) is not int
        or row["exit"] != 0
        or row["error"] is not None
        or row["output_limit_exceeded"] is not False
        or row["reader_complete"] is not True
        or type(row["pid"]) is not int
        or row["pid"] <= 0
    ):
        raise ValueError("dependency command failed/partial/exceeded")
    start, end, elapsed = (row[k] for k in ("start_monotonic_ns", "end_monotonic_ns", "elapsed_ns"))
    if any(type(n) is not int or n < 0 for n in (start, end, elapsed)) or end < start or end - start != elapsed:
        raise ValueError("dependency command local monotonic facts invalid")
    if len(bytes.fromhex(row["stdout_hex"])) > LIMIT or len(bytes.fromhex(row["stderr_hex"])) > LIMIT:
        raise ValueError("dependency retained output exceeded")
    if (
        row.get("kind", "").startswith("version:")
        and not (bytes.fromhex(row["stdout_hex"]) + bytes.fromhex(row["stderr_hex"])).strip()
    ):
        raise ValueError("dependency tool version output missing")
    if row["cleanup"].get("exit") != row["exit"] or row["cleanup"].get("descendants") != "unknown":
        raise ValueError("dependency owned cleanup facts differ")


def _ldd(data):
    lines = data.decode("utf8", errors="strict").splitlines()
    paths, nonfiles = [], []
    for raw in lines:
        line = raw.strip()
        if not line:
            continue
        if re.fullmatch(r"linux-vdso\S* \(0x[0-9a-fA-F]+\)", line):
            nonfiles.append(line)
            continue
        match = re.fullmatch(r"(?:[^\s]+ => )?(.+?) \(0x[0-9a-fA-F]+\)", line)
        if match is None:
            raise ValueError("unresolved or malformed dependency line: " + line)
        path = _absolute(match[1])
        if path in paths:
            raise ValueError("duplicate dependency selected path")
        paths.append(path)
    if not paths:
        raise ValueError("no complete ELF dependency paths")
    return dict(selected=paths, nonfiles=nonfiles)


def _dynamic(data):
    text = data.decode("utf8", errors="strict")
    header = re.search(r"Dynamic section at offset 0x[0-9a-fA-F]+ contains ([0-9]+) entries:", text)
    records = re.findall(r"^\s*0x[0-9a-fA-F]+\s+\(([A-Z0-9_]+)\).*$", text, re.MULTILINE)
    if header is None or not 1 <= int(header[1]) <= 65536 or len(records) != int(header[1]) or records[-1] != "NULL":
        raise ValueError("complete ELF dynamic metadata missing")
    result = dict(
        needed=re.findall(r"\(NEEDED\).*\[([^\]\n]+)\]", text),
        runpath=re.findall(r"\(RUNPATH\).*\[([^\]\n]*)\]", text),
        rpath=re.findall(r"\(RPATH\).*\[([^\]\n]*)\]", text),
        soname=re.findall(r"\(SONAME\).*\[([^\]\n]+)\]", text),
    )
    if any(
        len(result[key]) != records.count(tag)
        for key, tag in [("needed", "NEEDED"), ("runpath", "RUNPATH"), ("rpath", "RPATH"), ("soname", "SONAME")]
    ):
        raise ValueError("malformed ELF dynamic string record")
    return result


def _environment(path, agent_paths, agent_lib):
    result = dict(BASE_ENV)
    if path in agent_paths:
        if Path(path).parent.resolve() not in {Path(agent_lib).resolve(), Path(agent_lib).parent / "bin"}:
            raise ValueError("Agent selected entry outside declared directory")
        result["LD_LIBRARY_PATH"] = agent_lib
    return result


def _coverage(entries):
    renderer = [r for r in entries if Path(r["file"]["requested"]).name == "libgz-rendering8-ogre2.so.8.2.3"]
    if len(renderer) != 1:
        raise ValueError("actual renderer entry coverage required")
    row = renderer[0]
    if not OGRE_NAMES.issubset({Path(p).name for p in row["selected"]}):
        raise ValueError("renderer OGRE dependency coverage missing")
    if not OGRE_NAMES.issubset(set(row["dynamic"]["needed"])) or OGRE_DIR not in row["dynamic"]["runpath"]:
        raise ValueError("renderer direct dependency/RUNPATH relation changed")


def discover_entry_context(entries, candidates, python_context, agent_paths, agent_lib, output):
    output = Path(output)
    if output.exists():
        raise FileExistsError("entry dependency output already exists; no replay")
    output.mkdir()
    bill = dict(
        schema=SCHEMA,
        input_entries=entries,
        input_candidates=candidates,
        python_context=copy.deepcopy(python_context),
        python_context_sha256=context_digest(python_context),
        observed_context_before=None,
        observed_context_after=None,
        agent_paths=agent_paths,
        agent_lib=agent_lib,
        entries=[],
        candidates=[],
        files=[],
        tools_before={},
        tools_after={},
        files_after=[],
        queries=[],
        complete=False,
        error=None,
        runtime_closure_qualified=False,
        qualification=dict(QUALIFICATION),
    )
    files = {}
    primary = None

    def remember(path):
        row = file_record(path)
        if path in files and not _typed_equal(files[path], row):
            raise ValueError("dependency file changed while discovering")
        files[path] = row
        bill["files"] = list(files.values())
        return row

    def invoke(kind, argv, env):
        row = dict(kind=kind, argv=argv, environment=env, invoked=False, input_before={}, input_after={}, error=None)
        before = {}
        primary = None
        inputs = [argv[0]] + ([] if kind.startswith("version:") else [argv[-1]])
        try:
            before = {p: remember(p) for p in inputs}
            row["input_before"] = before
            observed = _run_tool(argv, env)
            row.update(observed, kind=kind, invoked=observed["pid"] is not None)
            row["input_after"] = {p: remember(p) for p in inputs}
            _successful(row)
            return row
        except BaseException as exc:
            primary = exc
            row["error"] = row["error"] or repr(exc)
            raise
        finally:
            bill["queries"].append(row)
            try:
                write_manifest(output / f"query-{len(bill['queries']):04d}.json", row)
            except Exception as exc:
                row["journal_error"] = repr(exc)
                if primary is None:
                    raise
                primary.add_note("query persistence failure: " + repr(exc))

    try:
        if (
            type(entries) is not dict
            or not entries
            or any(type(k) is not str or not k or type(v) is not list or not v for k, v in entries.items())
        ):
            raise ValueError("nonempty typed entry roles required")
        requested = [_absolute(p) for paths in entries.values() for p in paths]
        if len(set(requested)) != len(requested):
            raise ValueError("duplicate requested entry")
        if (
            not 1 <= len(requested) <= 256
            or type(candidates) is not list
            or len(candidates) > 4096
            or len(set(candidates)) != len(candidates)
        ):
            raise ValueError("bounded unique entries/candidates required")
        for path in candidates:
            _absolute(path)
        if (
            type(agent_paths) is not list
            or len(set(agent_paths)) != len(agent_paths)
            or not set(agent_paths).issubset(set(requested))
        ):
            raise ValueError("Agent paths must be unique selected entries")
        _absolute(agent_lib)
        for path in requested + candidates:
            remember(path)
        validate_python_context(python_context)
        bill["observed_context_before"] = collect_python_context()
        validate_python_context(bill["observed_context_before"])
        if not _typed_equal(bill["observed_context_before"], python_context):
            raise ValueError("current SDK Python context differs from requested context")
        for module in python_context["modules"]:
            if not _typed_equal(remember(module["origin"]["requested"]), module["origin"]):
                raise ValueError("Python module origin identity differs")
            if module["origin"]["resolved"] not in {files[p]["resolved"] for p in requested}:
                raise ValueError("Python context module absent from actual entries")
        if not _typed_equal(remember(python_context["interpreter"]["requested"]), python_context["interpreter"]):
            raise ValueError("Python interpreter context identity differs")
        tools = tool_paths()
        if set(tools) != {"ldd", "readelf", "python", "loader"}:
            raise ValueError("fixed dependency tools required")
        bill["tools_before"] = {key: remember(_absolute(path)) for key, path in tools.items()}
        if not _typed_equal(bill["tools_before"]["python"], python_context["interpreter"]):
            raise ValueError("Python context differs from selected interpreter")
        for name, tool in tools.items():
            invoke("version:" + name, [tool, "--version"], dict(BASE_ENV))
        seen = set()
        for role, paths in entries.items():
            for path in paths:
                record = files[path]
                resolved = record["resolved"]
                with Path(path).open("rb") as stream:
                    elf = stream.read(4) == b"\x7fELF"
                row = dict(
                    role=role,
                    entry_kind="python_extension_entry" if module_for(python_context, record) else "dependency_entry",
                    trace_kind=None,
                    elf_metadata=None,
                    metadata_query=None,
                    runtime_import_verified=False,
                    symbols_resolved=False,
                    file=record,
                    elf=elf,
                    alias_of=None,
                    ldd_query=None,
                    dynamic_query=None,
                    selected=[],
                    nonfiles=[],
                    dynamic=None,
                )
                bill["entries"].append(row)
                if resolved in seen:
                    original = next(r for r in bill["entries"][:-1] if r["file"]["resolved"] == resolved)
                    if _environment(path, agent_paths, agent_lib) != _environment(
                        original["file"]["requested"], agent_paths, agent_lib
                    ):
                        raise ValueError("entry aliases have different loader contexts")
                    row.update(
                        alias_of=original["file"]["requested"],
                        selected=original["selected"],
                        nonfiles=original["nonfiles"],
                        dynamic=original["dynamic"],
                    )
                    for key in ("entry_kind", "trace_kind", "elf_metadata", "runtime_import_verified", "symbols_resolved"):
                        row[key] = original[key]
                    continue
                seen.add(resolved)
                if not elf:
                    if row["entry_kind"] == "python_extension_entry":
                        raise ValueError("Python extension context requires ELF entry")
                    continue
                env = _environment(path, agent_paths, agent_lib)
                row["dynamic_query"] = len(bill["queries"]) + 1
                dynamic = invoke("dynamic", [tools["readelf"], "-d", path], env)
                row.update(dynamic_query=len(bill["queries"]), dynamic=_dynamic(bytes.fromhex(dynamic["stdout_hex"])))
                if row["entry_kind"] == "python_extension_entry" and not row["dynamic"]["needed"]:
                    row["metadata_query"] = len(bill["queries"]) + 1
                    metadata = invoke("elf-metadata", [tools["readelf"], "-W", "-h", "-l", "--dyn-syms", path], env)
                    row["elf_metadata"] = parse_extension_metadata(
                        bytes.fromhex(metadata["stdout_hex"]), module_for(python_context, record)
                    )
                row["ldd_query"] = len(bill["queries"]) + 1
                traced = invoke("ldd", [tools["ldd"], path], env)
                row.update(classify_trace(row, traced))
                for selected in row["selected"]:
                    remember(selected)
        selected_resolved = {files[p]["resolved"] for row in bill["entries"] for p in row["selected"]}
        bill["candidates"] = [
            dict(
                file=files[p],
                classification="selected_from_entry_trace" if files[p]["resolved"] in selected_resolved else "candidate_only",
            )
            for p in candidates
        ]
        _coverage(bill["entries"])
        bill["files_after"] = [file_record(path) for path in files]
        if not _typed_equal(bill["files"], bill["files_after"]):
            raise ValueError("dependency input/tool changed after trace")
        bill["tools_after"] = {key: file_record(path) for key, path in tools.items()}
        if not _typed_equal(bill["tools_before"], bill["tools_after"]):
            raise ValueError("dependency tool changed")
        bill["observed_context_after"] = collect_python_context()
        validate_python_context(bill["observed_context_after"])
        if not _typed_equal(bill["observed_context_after"], python_context):
            raise ValueError("current SDK Python context changed during dependency discovery")
        bill["complete"] = True
        audit_entry_context_bill(bill, baseline_files=bill["files"], python_context=python_context)
        return bill
    except BaseException as exc:
        primary = exc
        bill.update(complete=False, error=repr(exc))
        raise
    finally:
        try:
            write_manifest(output / "entry-bill.json", bill)
        except Exception as exc:
            if primary is None:
                raise
            primary.add_note("aggregate persistence failure: " + repr(exc))


def audit_entry_context_bill(bill, *, baseline_files, python_context):
    baseline = baseline_files
    """Recompute joins from retained raw calls; no caller eligibility assertion."""
    keys = {
        "schema",
        "input_entries",
        "input_candidates",
        "python_context",
        "python_context_sha256",
        "observed_context_before",
        "observed_context_after",
        "agent_paths",
        "agent_lib",
        "entries",
        "candidates",
        "files",
        "tools_before",
        "tools_after",
        "files_after",
        "queries",
        "complete",
        "error",
        "runtime_closure_qualified",
        "qualification",
    }
    if (
        type(bill) is not dict
        or set(bill) != keys
        or bill["schema"] != SCHEMA
        or bill["complete"] is not True
        or bill["error"] is not None
        or bill["runtime_closure_qualified"] is not False
        or not _typed_equal(bill["qualification"], QUALIFICATION)
    ):
        raise ValueError("complete exact entry dependency bill required")
    validate_python_context(python_context)
    if not _typed_equal(bill["python_context"], python_context) or bill["python_context_sha256"] != context_digest(
        python_context
    ):
        raise ValueError("Python context digest/join differs")
    for key in ("observed_context_before", "observed_context_after"):
        validate_python_context(bill[key])
        if not _typed_equal(bill[key], python_context):
            raise ValueError("observed current SDK context join differs")
    files = {r["requested"]: r for r in bill["files"]}
    known = {r["requested"]: {k: v for k, v in r.items() if k != "role"} for r in baseline}
    if (
        len(files) != len(bill["files"])
        or len(known) != len(baseline)
        or any(not _typed_equal(row, known.get(path)) for path, row in files.items())
    ):
        raise ValueError("entry files absent/duplicate/different baseline")
    if not _typed_equal(bill["files"], bill["files_after"]) or not _typed_equal(bill["tools_before"], bill["tools_after"]):
        raise ValueError("entry tool/input post identity differs")
    for record in [python_context["interpreter"], *(m["origin"] for m in python_context["modules"])]:
        if not _typed_equal(record, files.get(record["requested"])):
            raise ValueError("Python context file absent from baseline")
    if not _typed_equal(bill["tools_before"]["python"], python_context["interpreter"]):
        raise ValueError("Python interpreter differs from selected tool")
    expected_entries = [(role, p) for role, paths in bill["input_entries"].items() for p in paths]
    if len(expected_entries) > 256 or len({p for _, p in expected_entries}) != len(expected_entries):
        raise ValueError("duplicate/bounded entry inputs required")
    if [(r["role"], r["file"]["requested"]) for r in bill["entries"]] != expected_entries:
        raise ValueError("entry role/member set differs")
    if (
        type(bill["agent_paths"]) is not list
        or len(set(bill["agent_paths"])) != len(bill["agent_paths"])
        or not set(bill["agent_paths"]).issubset({p for _, p in expected_entries})
    ):
        raise ValueError("Agent paths must be unique selected entries")
    _absolute(bill["agent_lib"])
    tools = bill["tools_before"]
    if set(tools) != {"ldd", "readelf", "python", "loader"} or any(
        not _typed_equal(r, files.get(r["requested"])) for r in tools.values()
    ):
        raise ValueError("exact tool identity join required")
    fixed_tools = tool_paths()
    if set(fixed_tools) != set(tools) or any(tools[k]["requested"] != fixed_tools[k] for k in tools):
        raise ValueError("entry fixed tool path differs from current producer")
    expected_calls = [("version:" + k, [v["requested"], "--version"], dict(BASE_ENV)) for k, v in tools.items()]
    used = {r["requested"] for r in tools.values()} | set(bill["input_candidates"])
    used.update(m["origin"]["requested"] for m in python_context["modules"])
    used.add(python_context["interpreter"]["requested"])
    seen = {}
    for row in bill["entries"]:
        path = row["file"]["requested"]
        _absolute(path)
        used.add(path)
        if not _typed_equal(row["file"], files.get(path)) or type(row["elf"]) is not bool:
            raise ValueError("entry identity differs")
        module = module_for(python_context, row["file"])
        if (
            row["entry_kind"] != ("python_extension_entry" if module else "dependency_entry")
            or row["runtime_import_verified"] is not False
            or row["symbols_resolved"] is not False
        ):
            raise ValueError("Python entry kind/qualification differs")
        if module and row["elf"] is not True:
            raise ValueError("Python extension context requires ELF entry")
        resolved = row["file"]["resolved"]
        env = _environment(path, bill["agent_paths"], bill["agent_lib"])
        if resolved in seen:
            original = seen[resolved]
            if (
                row["alias_of"] != original["file"]["requested"]
                or row["ldd_query"] is not None
                or row["dynamic_query"] is not None
                or row["metadata_query"] is not None
            ):
                raise ValueError("alias entry invoked twice")
            if env != _environment(original["file"]["requested"], bill["agent_paths"], bill["agent_lib"]):
                raise ValueError("alias context differs")
            for key in ("elf", "dynamic", "selected", "nonfiles", "trace_kind", "elf_metadata", "entry_kind"):
                if not _typed_equal(row[key], original[key]):
                    raise ValueError("alias inherited trace differs")
        else:
            seen[resolved] = row
            if row["alias_of"] is not None:
                raise ValueError("undeclared alias")
            if row["elf"]:
                expected_calls.append(("dynamic", [tools["readelf"]["requested"], "-d", path], env))
                dynamic_number = len(expected_calls)
                dynamic = _dynamic(bytes.fromhex(bill["queries"][dynamic_number - 1]["stdout_hex"]))
                if module and not dynamic["needed"]:
                    expected_calls.append(
                        ("elf-metadata", [tools["readelf"]["requested"], "-W", "-h", "-l", "--dyn-syms", path], env)
                    )
                    if row["metadata_query"] != len(expected_calls):
                        raise ValueError("extension metadata query index differs")
                    metadata = parse_extension_metadata(
                        bytes.fromhex(bill["queries"][-1 + len(expected_calls)]["stdout_hex"]), module
                    )
                    if not _typed_equal(row["elf_metadata"], metadata):
                        raise ValueError("extension raw metadata differs")
                elif row["metadata_query"] is not None or row["elf_metadata"] is not None:
                    raise ValueError("undeclared extension metadata")
                expected_calls.append(("ldd", [tools["ldd"]["requested"], path], env))
                ldd_number = len(expected_calls)
                if row["dynamic_query"] != dynamic_number or row["ldd_query"] != ldd_number:
                    raise ValueError("entry raw query index differs")
                traced = classify_trace(dict(row, dynamic=dynamic), bill["queries"][ldd_number - 1])
                if not _typed_equal(row["dynamic"], dynamic) or any(not _typed_equal(row[k], traced[k]) for k in traced):
                    raise ValueError("entry raw dependency/dynamic trace differs")
            elif any(
                row[k] not in (None, [])
                for k in (
                    "ldd_query",
                    "dynamic_query",
                    "dynamic",
                    "selected",
                    "nonfiles",
                    "metadata_query",
                    "elf_metadata",
                    "trace_kind",
                )
            ):
                raise ValueError("non-ELF entry claims a trace")
        used.update(row["selected"])
    if len(expected_calls) != len(bill["queries"]):
        raise ValueError("extra/missing dependency command")
    for row, (kind, argv, env) in zip(bill["queries"], expected_calls, strict=True):
        _successful(row)
        inputs = [argv[0]] + ([] if kind.startswith("version:") else [argv[-1]])
        pins = {p: files[p] for p in inputs}
        if (
            row.get("invoked") is not True
            or not _typed_equal(row.get("input_before"), pins)
            or not _typed_equal(row.get("input_after"), pins)
        ):
            raise ValueError("per-command tool/entry pin join differs")
        if row["kind"] != kind or row["argv"] != argv or row["environment"] != env:
            raise ValueError("entry actual command/context differs")
    selected = {files[p]["resolved"] for row in bill["entries"] for p in row["selected"]}
    expected_candidates = [
        dict(file=files[p], classification="selected_from_entry_trace" if files[p]["resolved"] in selected else "candidate_only")
        for p in bill["input_candidates"]
    ]
    if (
        len(expected_candidates) > 4096
        or len(set(bill["input_candidates"])) != len(expected_candidates)
        or not _typed_equal(bill["candidates"], expected_candidates)
    ):
        raise ValueError("candidate identity/classification differs")
    if set(files) != used:
        raise ValueError("extra/missing entry dependency file")
    _coverage(bill["entries"])
    return dict(
        entry_trace_consistent=True,
        candidate_only=sum(r["classification"] == "candidate_only" for r in bill["candidates"]),
        runtime_closure_qualified=False,
        qualification=dict(QUALIFICATION),
    )
