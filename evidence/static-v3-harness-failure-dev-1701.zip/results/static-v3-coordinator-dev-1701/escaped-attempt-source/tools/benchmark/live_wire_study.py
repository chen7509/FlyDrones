"""Prospective full-load wire-study declarations; validation never grants launch.

The document API is pure. The file adapter is read-only and preparation-only:
existing output paths refuse. Neither function executes a runtime or network I/O.
"""

from __future__ import annotations

import copy
import os
import re
from pathlib import Path

from tools.benchmark.capture_contract import _typed_equal, derive_launch_environment, read_declaration
from tools.benchmark.declared_runtime_snapshot import file_record, snapshot, verify_unchanged
from tools.benchmark.runtime_resource_binding import estimator_inputs, validate_binding
from tools.benchmark.trajectory_gauge_contract import validate_trajectory_gauge_policy

FILE_ROLES = {"execution", "binding", "wire_config", "gauge_policy", "python", "capture", "auditor"}
AGENT_FILE_ROLES = FILE_ROLES | {"agent_config"}
LOGGER_FILE_ROLES = AGENT_FILE_ROLES | {"logger_topics", "logger_profile"}
DOC_ROLES = ("execution", "binding", "wire_config", "gauge_policy")
PROFILES = dict(
    motion_profile="supported-ready-v1",
    physics_trace_profile="substep-ready-v1",
    reference_fault_profile=None,
    source_fanout_profile="ready-shadow-heartbeat-estimator-v1",
    motion_intent_profile="native-beginning-zupt-v1",
    health_profile="px4-d6f12ad-gate-floor-v1",
)
LIMITS = dict(
    bootstrap_wall_ns=8_000_000_000,
    accepted_samples=500,
    operational_ns=2_000_000_000,
    source_startup_ns=10_000_000_000,
    readiness_sim_ns=8_000_000_000,
    anchor_ahead_ns=200_000_000,
    cleanup_ns=10_000_000_000,
    max_datagrams=4096,
    max_segments=64,
    segment_events=8192,
    journal_bytes=512 * 1024 * 1024,
)
ENDPOINT = dict(
    local_host="127.0.0.1",
    local_port=14548,
    peer_host="127.0.0.1",
    peer_port=14588,
    sender_system=254,
    sender_component=191,
    target_system=9,
    target_component=1,
    instance=8,
)
WORKLOAD = dict(
    schema="capture-execution-v3",
    wall_budget_s=300,
    supervisor_s=300,
    simulation_duration_ns=25_000_000_000,
    physics_step_ns=1_000_000,
    imu_hz=250,
    rgbd_hz=10,
    rgbd_size=[160, 120],
    estimator_run=True,
    simulation_seed=27601,
)


def _shape(value, keys, label):
    if type(value) is not dict or value.keys() != set(keys):
        raise ValueError("invalid " + label + " schema")


def _equal(value, expected, label):
    if not _typed_equal(value, expected):
        raise ValueError("mismatched " + label)


def _text(value, pattern, label):
    if type(value) is not str or re.fullmatch(pattern, value) is None:
        raise ValueError("invalid " + label)


def _path(value):
    if type(value) is not str or not value or "\0" in value or not Path(value).is_absolute() or ".." in Path(value).parts:
        raise ValueError("explicit absolute path required")
    return Path(value)


def _identity(value):
    _shape(value, ("device", "inode", "mode", "size", "mtime_ns", "ctime_ns"), "file identity")
    if any(type(v) is not int for v in value.values()) or value["size"] < 0:
        raise ValueError("invalid file identity values")


def _file(value):
    _shape(value, ("requested", "resolved", "links", "identity", "path_identity", "bytes", "sha256"), "file record")
    _path(value["requested"])
    _path(value["resolved"])
    _text(value["sha256"], "[0-9a-f]{64}", "file digest")
    if type(value["bytes"]) is not int or value["bytes"] < 0:
        raise ValueError("invalid file length")
    for key in ("identity", "path_identity"):
        _identity(value[key])
        if value[key]["size"] != value["bytes"]:
            raise ValueError("file size identity mismatch")
    if type(value["links"]) is not list or len(value["links"]) > 40:
        raise ValueError("invalid symlink chain")
    for link in value["links"]:
        _shape(link, ("path", "target", "identity"), "symlink")
        _path(link["path"])
        _identity(link["identity"])
        if type(link["target"]) is not str or not link["target"] or "\0" in link["target"]:
            raise ValueError("invalid symlink target")


def _key(value):
    return os.path.normcase(str(_path(value)))


def _outputs(document, inputs):
    outputs = document["outputs"]
    _shape(outputs, ("capture", "dispatch", "completion", "audit"), "outputs")
    values = [_path(v) for v in outputs.values()]
    for i, path in enumerate(values):
        if any(path == other or path in other.parents or other in path.parents for other in values[i + 1 :]):
            raise ValueError("output paths overlap")
        if any(path == other or path in other.parents for other in map(_path, inputs)):
            raise ValueError("output overlaps an input")


def _baseline(binding):
    rows = binding["baseline"]["files"]
    if type(rows) is not list or not rows:
        raise ValueError("missing baseline records")
    expected = {(role, _key(p)) for role, paths in binding["inventory"].items() for p in paths}
    found, by_path = set(), {}
    for row in rows:
        if type(row) is not dict or type(row.get("role")) is not str:
            raise ValueError("invalid baseline role")
        record = {k: v for k, v in row.items() if k != "role"}
        _file(record)
        key = _key(record["requested"])
        if key in by_path:
            raise ValueError("duplicate baseline path")
        found.add((row["role"], key))
        by_path[key] = record
    if found != expected:
        raise ValueError("baseline inventory coverage differs")
    return by_path


def _expected_command(document, execution):
    files = document["files"]
    command = [files["python"]["requested"], files["capture"]["requested"], "--output", document["outputs"]["capture"]]
    fields = {
        **execution["inputs"],
        **execution["profiles"],
        "simulation_seed": document["simulation_seed"],
        "reference_sha256": execution["reference_sha256"],
        "execution_contract": files["execution"]["resolved"],
        "runtime_binding": files["binding"]["resolved"],
        "trajectory_gauge_policy": files["gauge_policy"]["resolved"],
        "wire_config": files["wire_config"]["resolved"],
    }
    # Same production worker-option order, with paths already explicit; no resolve or filesystem access.
    order = (
        "shadow_binary",
        "shadow_config",
        "reference_module",
        "motion_profile",
        "physics_trace_profile",
        "reference_fault_profile",
        "source_fanout_profile",
        "simulation_seed",
        "motion_intent_profile",
        "health_profile",
        "reference_sha256",
        "execution_contract",
        "runtime_binding",
        "trajectory_gauge_policy",
        "wire_config",
    )
    for key in order:
        if fields[key] is not None:
            command += ["--" + key.replace("_", "-"), str(fields[key])]
    if document["schema"] in ("live-wire-study-v2", "live-wire-study-v3"):
        command += ["--agent-runtime-config", document["files"]["agent_config"]["resolved"]]
    if document["schema"] == "live-wire-study-v3":
        command += ["--logger-diagnostic-profile", "source-diagnostic-v1"]
    return command


def _agent_selection(document, execution, binding, baseline):
    from tools.benchmark.agent_capture_runtime import AGENT_SHA256, BUNDLE_SHA256, LIBRARY_SHA256

    record = execution.get("agent")
    keys = {"schema", "declaration", "declaration_sha256", "configuration", "selected_paths", "files",
            "authority", "typed_dds_provenance", "fusion_qualified"}
    _shape(record, keys, "Agent execution record")
    config = record["configuration"]
    _shape(config, ("schema", "bundle", "binary", "lib_dir", "port"), "Agent configuration")
    _equal(config["schema"], "capture-agent-runtime-v1", "Agent schema")
    _equal(config["port"], 18888, "Agent port")
    declaration = document["files"]["agent_config"]
    _equal(record["schema"], "capture-agent-runtime-record-v1", "Agent record schema")
    _equal(record["declaration"], declaration["requested"], "Agent declaration")
    _equal(record["declaration_sha256"], declaration["sha256"], "Agent declaration hash")
    _equal(baseline.get(_key(declaration["requested"])), declaration, "Agent declaration baseline")
    for flag in ("authority", "typed_dds_provenance", "fusion_qualified"):
        _equal(record[flag], False, "Agent " + flag)
    _path(config["bundle"])
    _path(config["binary"])
    directory = _path(config["lib_dir"])
    selected = [declaration["requested"], config["bundle"], config["binary"]]
    selected += [str(directory / name) for name in sorted(LIBRARY_SHA256)]
    _equal(record["selected_paths"], selected, "Agent selected paths")
    _equal(binding["inventory"].get("runtime-root:agent"), [config["binary"]], "Agent runtime root")
    _equal(set(binding["runtime_maps"]["owned_roles"]), {"px4", "openvins", "agent"}, "owned roles")
    if not {"ready", "prestop"} <= set(binding["runtime_maps"]["owned_roles"]["agent"]):
        raise ValueError("Agent owned phases missing")
    expected_hashes = [BUNDLE_SHA256, AGENT_SHA256, *(LIBRARY_SHA256[name] for name in sorted(LIBRARY_SHA256))]
    if type(record["files"]) is not list or len(record["files"]) != len(expected_hashes):
        raise ValueError("Agent file list incomplete")
    for path, sha, actual in zip(selected[1:], expected_hashes, record["files"]):
        _shape(actual, ("path", "resolved", "bytes", "sha256", "device", "inode"), "Agent selected file")
        current = baseline.get(_key(path))
        if current is None:
            raise ValueError("Agent selected file missing from baseline")
        _equal(actual, dict(path=path, resolved=current["resolved"], bytes=current["bytes"], sha256=sha,
                            device=current["identity"]["device"], inode=current["identity"]["inode"]),
               "Agent selected file")
        _equal(current["sha256"], sha, "Agent fixed file hash")


def _logger_selection(document, execution, binding, baseline):
    record = execution["logger_diagnostic"]
    _shape(record, ("schema", "profile_id", "source_paths", "topics_sha256", "declaration_sha256",
                    "px4_environment_override", "diagnostic_only", "runtime_topic_selection_verified",
                    "dds_ulog_parity_verified", "source_authenticated"), "logger diagnostic record")
    _equal(record["schema"], "capture-px4-logger-profile-v1", "logger schema")
    _equal(record["profile_id"], "source-diagnostic-v1", "logger profile")
    _equal(record["px4_environment_override"], {"PX4_PARAM_SDLOG_PROFILE": "0"}, "logger override")
    _equal(record["diagnostic_only"], True, "logger diagnostic flag")
    for flag in ("runtime_topic_selection_verified", "dds_ulog_parity_verified", "source_authenticated"):
        _equal(record[flag], False, "logger " + flag)
    topics, declaration = (document["files"][role] for role in ("logger_topics", "logger_profile"))
    paths = [topics["requested"], declaration["requested"]]
    _equal(record["source_paths"], paths, "logger source paths")
    _equal(record["topics_sha256"], topics["sha256"], "logger topics digest")
    _equal(record["declaration_sha256"], declaration["sha256"], "logger declaration digest")
    _equal(binding["inventory"].get("runtime:logger-diagnostic"), paths, "logger inventory")
    for item in (topics, declaration):
        _equal(baseline.get(_key(item["requested"])), item, "logger baseline")


def _canonical_logger_record(record):
    """File-adapter check; never called by the pure document validator."""
    from tools.benchmark.px4_logger_runtime import PROFILE_RELATIVE, profile_record

    fixed = profile_record(Path(__file__).resolve().parents[2] / PROFILE_RELATIVE)
    _equal(record, fixed, "canonical logger profile")


def validate_live_wire_study(document, *, execution, binding, wire_config, gauge_policy):
    """Check documents without touching files; no live authorization or code attestation."""
    _shape(
        document,
        (
            "schema",
            "study_id",
            "producer_commit",
            "role",
            "simulation_seed",
            "expected_status",
            "clock_scope",
            "live_activation_authorized",
            "endpoint",
            "limits",
            "outputs",
            "files",
            "command",
        ),
        "study",
    )
    version = document["schema"]
    if version not in ("live-wire-study-v1", "live-wire-study-v2", "live-wire-study-v3"):
        raise ValueError("unknown live wire study schema")
    agent_mode = version in ("live-wire-study-v2", "live-wire-study-v3")
    logger_mode = version == "live-wire-study-v3"
    expected_seed = 27603 if logger_mode else (27602 if agent_mode else 27601)
    for key, value in dict(
        schema=version,
        role="development",
        simulation_seed=expected_seed,
        expected_status="capture_completed",
        clock_scope="postupdate-simulation-epoch-v1",
        live_activation_authorized=False,
    ).items():
        _equal(document[key], value, key)
    _text(document["study_id"], "[A-Za-z0-9_.:-]{1,120}", "study id")
    _text(document["producer_commit"], "[0-9a-f]{40}", "producer commit")
    _equal(document["limits"], LIMITS, "limits")
    _equal(document["endpoint"], ENDPOINT, "endpoint")
    _shape(document["files"], LOGGER_FILE_ROLES if logger_mode else (AGENT_FILE_ROLES if agent_mode else FILE_ROLES),
           "study files")
    for record in document["files"].values():
        _file(record)
    for key in ("requested", "resolved"):
        if len({_key(r[key]) for r in document["files"].values()}) != len(document["files"]):
            raise ValueError("duplicate study file identity")
    validate_binding(binding)
    if binding["schema"] != "capture-resource-binding-v3":
        raise ValueError("live study requires v3 binding")
    baseline = _baseline(binding)
    runtime = binding["runtime_maps"]
    if (
        not {"postimports", "postfinalize", "postfirststep"} <= set(runtime["self_phases"])
        or set(runtime["owned_roles"]) != ({"px4", "openvins", "agent"} if agent_mode else {"px4", "openvins"})
        or any(not {"ready", "prestop"} <= set(phases) for phases in runtime["owned_roles"].values())
    ):
        raise ValueError("full native/PX4 runtime coverage must be declared")
    for role in ("runtime-root:px4", "runtime-root:openvins", "runtime-root:native-reference"):
        if role not in binding["inventory"] or len(binding["inventory"][role]) != 1:
            raise ValueError("explicit runtime root required")
    validate_trajectory_gauge_policy(gauge_policy)
    expected_wire = dict(schema="capture-wire-v1", session_id=document["study_id"] + ".clock",
                         sim_origin_ns=0, remote_origin_ns=0)
    if type(wire_config) is dict and wire_config.get("schema") == "capture-wire-startup-v2":
        cap = wire_config.get("startup_max_wall_ns")
        if type(cap) is not int or not 0 < cap <= 60_000_000_000:
            raise ValueError("invalid startup wall cap")
        expected_wire.update(schema="capture-wire-startup-v2", startup_max_wall_ns=cap)
    _equal(wire_config, expected_wire, "wire clock")
    _shape(
        execution,
        set(WORKLOAD) | {"profiles", "inputs", "reference_sha256", "launch_environment", "trajectory_gauge_policy", "wire"}
        | ({"agent"} if agent_mode else set()) | ({"logger_diagnostic"} if logger_mode else set()),
        "execution",
    )
    for key, value in {**WORKLOAD, "simulation_seed": expected_seed}.items():
        _equal(execution[key], value, "workload " + key)
    if agent_mode:
        _agent_selection(document, execution, binding, baseline)
    elif "agent" in execution:
        raise ValueError("v1 study cannot select an Agent")
    if logger_mode:
        _logger_selection(document, execution, binding, baseline)
    _equal(execution["profiles"], PROFILES, "profiles")
    _equal(execution["launch_environment"], derive_launch_environment(binding), "environment")
    _shape(execution["inputs"], ("shadow_binary", "shadow_config", "reference_module"), "native inputs")
    for value in execution["inputs"].values():
        if _key(value) not in baseline:
            raise ValueError("native input absent from baseline")
    for key, role in (("shadow_binary", "runtime-root:openvins"), ("reference_module", "runtime-root:native-reference")):
        _equal(execution["inputs"][key], binding["inventory"][role][0], "selected native root")
    _equal(execution["reference_sha256"], baseline[_key(execution["inputs"]["reference_module"])]["sha256"], "reference digest")
    for role, key, extra in (
        ("wire_config", "wire", {"configuration": wire_config}),
        ("gauge_policy", "trajectory_gauge_policy", {"schema": "trajectory-gauge-policy-v1"}),
    ):
        record = document["files"][role]
        _equal(
            execution[key],
            dict(path=record["requested"], resolved=record["resolved"], bytes=record["bytes"], sha256=record["sha256"], **extra),
            key,
        )
        _equal(baseline.get(_key(record["requested"])), record, "bound " + role)
    _outputs(document, [r[k] for r in [*document["files"].values(), *baseline.values()] for k in ("requested", "resolved")])
    _equal(document["command"], _expected_command(document, execution), "production command")
    return dict(
        manifest=copy.deepcopy(document),
        document_validated=True,
        files_verified=False,
        producer_commit_verified=False,
        live_qualified=False,
        fusion_qualified=False,
    )


def validate_live_wire_study_files(manifest_path):
    """Preparation-only ordinary drift checks. No atomic/hostile-ABA guarantee."""
    from tools.benchmark.capture_contract import declared_command
    from tools.benchmark.capture_disarmed_sensors import parse_capture_args
    from tools.benchmark.repository_python_sources import audit_source_roots, verify_sources

    path = Path(manifest_path)
    before_manifest = file_record(path)
    document = read_declaration(path)
    version = document.get("schema") if type(document) is dict else None
    roles = (LOGGER_FILE_ROLES if version == "live-wire-study-v3"
             else AGENT_FILE_ROLES if version == "live-wire-study-v2" else FILE_ROLES)
    _shape(document.get("files") if type(document) is dict else None, roles, "study files")
    docs = {}
    for role, expected in document["files"].items():
        _file(expected)
        _equal(file_record(expected["requested"]), expected, "study file " + role)
        if role in DOC_ROLES:
            docs[role] = read_declaration(expected["requested"])
            _equal(file_record(expected["requested"]), expected, "study file after read " + role)
    result = validate_live_wire_study(document, **docs)
    if version == "live-wire-study-v3":
        _canonical_logger_record(docs["execution"]["logger_diagnostic"])
    root = Path(__file__).resolve().parents[2]
    source_freeze = verify_sources(root, audit_source_roots(root), docs['binding']['baseline']['files'])
    result['static_audit_sources_verified'] = True
    result['static_audit_source_count'] = len(source_freeze['files'])
    result['dynamic_source_closure_qualified'] = False
    # Check all declared dependencies, not only the four small JSON documents.
    current = snapshot(docs["binding"]["inventory"])
    verify_unchanged(docs["binding"]["baseline"], current)
    selected = docs["execution"]["inputs"]
    required = estimator_inputs(
        Path(selected["shadow_binary"]), Path(selected["shadow_config"]), Path(selected["reference_module"])
    )
    declared = {_key(row["requested"]) for row in current["files"]}
    if any(_key(str(p)) not in declared for p in required):
        raise ValueError("complete frozen estimator configuration must be declared")
    args = parse_capture_args(document["command"][2:])
    command = declared_command(args, document["command"][0], document["command"][1], docs["execution"]["launch_environment"])
    _equal(document["command"], command, "actual capture declaration")
    # Resolve nonexisting outputs to detect aliases through existing parent links.
    resolved_document = copy.deepcopy(document)
    resolved_document["outputs"] = {k: str(Path(v).resolve()) for k, v in document["outputs"].items()}
    _outputs(
        resolved_document,
        [
            before_manifest["resolved"],
            *(r["resolved"] for r in document["files"].values()),
            *(r["resolved"] for r in current["files"]),
        ],
    )
    for value in document["outputs"].values():
        if os.path.lexists(value):
            raise ValueError("study output already exists")
    verify_unchanged(current, snapshot(docs["binding"]["inventory"]))
    for expected in document["files"].values():
        _equal(file_record(expected["requested"]), expected, "final study file")
    _equal(file_record(path), before_manifest, "manifest changed during validation")
    # Recheck after potentially lengthy dependency reads. This is still only an
    # observation at validation time, not a reservation against later writers.
    for value in document["outputs"].values():
        if os.path.lexists(value):
            raise ValueError("study output already exists")
    result["files_verified"] = True
    return result
