"""Post-failure file audit only. Does not import any project production code."""
import hashlib
import json
from pathlib import Path

ROOT = Path.cwd()
RAW = ROOT / 'results/static-v3-coordinator-dev-1701'
FIXED = ROOT / 'results/target-bearing-runtime-freeze-v3-dev-1701'
def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()
def read(path):
    return json.loads(path.read_bytes().decode('utf-8-sig'))
def write(name, value):
    with (RAW/name).open('xb') as f:
        f.write(json.dumps(value, indent=2, ensure_ascii=False).encode('utf-8'))

previous = read(ROOT/'results/python-extension-context-production-dev-1701/historical-archives-before-seal.json')
rows = previous['members'] + [read(ROOT/'evidence/python-extension-context-production-publication.json')['archive']]
assert len(rows) == 287 and sum(r['bytes'] for r in rows) == 803630878
for row in rows:
    path = ROOT/row['path']
    assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], row['path']
assert {str(p.relative_to(ROOT)).replace('\\','/') for p in (ROOT/'evidence').glob('*.zip')} == {r['path'] for r in rows}
write('historical-archives-postfailure.json',dict(count=len(rows),bytes=sum(r['bytes'] for r in rows),scope='POST escaped failure, no retroactive prepin',members=rows))
snap = read(RAW/'escaped-attempt-source-postsnapshot.json')
assert len(snap['members']) == 373
for r in snap['members']:
    assert sha(ROOT/r['path']) == r['sha256'] == sha(ROOT/r['snapshot']), r['path']
record = read(RAW/'absence-red.json')
assert record['source_before'] == record['source_after']
assert len(record['source_before']) == 7
for path, expected in record['source_before'].items():
    assert sha(ROOT/path) == expected, path
assert sha(RAW/'verify.py') == sha(RAW/'verify-escaped-version.py') == record['recorder_sha256']
history = ROOT/'evidence/flydrones-history-through-admitted-executor-dev-1701.json'
assert history.stat().st_size == 89359 and sha(history) == 'c88840b6f58dea4e7e4931683c4993b4fc3b8eb55887807994b6381ef6c2b989'
queries=list((FIXED/'frozen-study-v3/sdk').glob('resource-query-*.json'))
assert len(queries)==12 and all(read(p)['exit']==0 for p in queries)
clarification=dict(schema='escaped-static-v3-folder-clarification-v1',supersedes='escaped-attempt-actual-summary.json actual_fixed_study_exists ambiguous field',actual_fixed_folder_exists=(FIXED/'frozen-study-v3').is_dir(),final_study_json_exists=(FIXED/'frozen-study-v3/study.json').exists(),runtime_graph_frozen=False,physical_dispatch_ready=False,original_summary_unchanged=True)
assert clarification['actual_fixed_folder_exists'] and not clarification['final_study_json_exists']
write('escaped-attempt-folder-clarification.json',clarification)
private=RAW/'initial-resource-private.json'
assert private.stat().st_size==67936 and sha(private)=='c3fe78b8871588b6f35abac03acd6f2f05d3bc69624daddf20b31976a75a46b4'
write('postfailure-file-audit.json',dict(source_snapshot_members=373,source_scope='POST373, seven recorded pre/post current-byte joins only',recorder_sha256=sha(RAW/'verify.py'),sdk_queries=12,sdk_queries_exit_zero=True,historical_zip_count=287,historical_zip_bytes=803630878,history_sha256=sha(history),private_exclusion=dict(path=str(private.relative_to(ROOT)).replace('\\','/'),bytes=private.stat().st_size,sha256=sha(private)),all_assertions_passed=True))
print('POST file audit: 373 source snapshot / 7 pre-post joins / 12 SDK queries / 287 historical ZIPs unchanged')
