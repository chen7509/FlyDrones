from pathlib import Path
p=Path('results/target-bearing-runtime-freeze-v3-dev-1701/run-static-preparation-v3.py')
s=p.read_text(encoding='utf8')
s+='''

OBSERVER = ROOT / 'tools/benchmark/static_v3_identity.py'
BOOTSTRAP_TOOLS = ['/usr/bin/sha256sum','/usr/bin/python3']
VERSION_TOOLS = ['/usr/bin/ldd','/usr/bin/readelf','/usr/bin/python3','/lib64/ld-linux-x86-64.so.2',
                 '/usr/bin/systemd-run','/usr/bin/systemctl','/usr/bin/time','/usr/bin/timeout','/usr/bin/env','/usr/bin/dpkg-query']


def host_path(path):
    if path.startswith('/mnt/c/'):
        return Path('C:/'+path[7:])
    if not path.startswith('/') or '..' in path.split('/'):
        raise ValueError('absolute Linux path required')
    return Path('//wsl.localhost/Ubuntu'+path)


def host_pin(path):
    selected=host_path(path)
    before=selected.stat()
    digest=hashlib.sha256()
    with selected.open('rb') as f:
        for chunk in iter(lambda:f.read(128*1024),b''):digest.update(chunk)
    after=selected.stat()
    if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):
        raise ValueError('host file changed while pinning')
    return dict(path=path,sha256=digest.hexdigest(),bytes=after.st_size)


def verify_bootstrap(records):
    for record in records:
        if host_pin(record['path'])!=record:raise ValueError('bootstrap current bytes differ')


def observer_arguments(request,output):
    return ['/usr/bin/python3','-S',linux(OBSERVER),request,output]


def decode_observer(raw):
    if len(raw)>16*1024**2:raise ValueError('primitive journal aggregate cap')
    rows=[]
    for line in raw.decode('utf8').splitlines():
        row=ast.literal_eval(line)
        if type(row)is not dict:raise ValueError('primitive row must be dict')
        rows.append(row)
    return rows


def admission():
    # Readonly resource observer has the same audited primitive imports; no JSON on Linux.
    code="""import os,sys
mem={k:v for k,v in (line.split(':',1) for line in open('/proc/meminfo').read().splitlines())}
rows=[]
for n in os.listdir('/proc'):
 if not n.isdigit() or int(n) in (os.getpid(),os.getppid()):continue
 try:rows.append(dict(pid=int(n),name=open('/proc/'+n+'/comm').read().strip(),cmdline=open('/proc/'+n+'/cmdline','rb').read().replace(bytes([0]),b' ').decode(errors='replace')))
 except OSError:pass
print(repr(dict(available=int(mem['MemAvailable'].split()[0])*1024,processes=rows)))
"""
    observed=remote('/usr/bin/python3','-S','-c',code,timeout=30)
    if observed.returncode:raise ValueError('primitive admission observer refused')
    data=ast.literal_eval(observed.stdout.decode('utf8'))
    own={os.getpid(),*(x.pid for x in psutil.Process().parents())}
    windows=[dict(pid=x.pid,**x.info) for x in psutil.process_iter(['name','cmdline']) if x.pid not in own]
    blocked=[x for x in data['processes']+windows if heavy_process(x)]
    docker=subprocess.run(['docker','ps','--no-trunc','--format','{{json .}}'],capture_output=True,timeout=30)
    def identity(x):
        command=x['cmdline'] if isinstance(x['cmdline'],str) else ' '.join(x['cmdline'] or [])
        return dict(pid=x['pid'],name=x['name'],argv_sha256=hashlib.sha256(command.encode()).hexdigest())
    return dict(windows_available=psutil.virtual_memory().available,wsl=dict(available=data['available'],processes=[identity(x) for x in data['processes']]),windows_processes=[identity(x) for x in windows],blocked_processes=[identity(x) for x in blocked],docker_exit=docker.returncode,docker_running=docker.stdout.decode(),wsl_stderr_hex=observed.stderr.hex())


def identity_request():
    from tools.benchmark.calibration_capture_contract import scene_record
    from tools.benchmark.calibration_capture_study import SOURCE
    from tools.benchmark.prepare_calibration_capture import CATALOG
    from tools.benchmark.agent_capture_runtime import AGENT_SHA256,LIBRARY_SHA256,BUNDLE_SHA256
    scene=scene_record(SOURCE)
    folder=ROOT/'results/target-bearing-runtime-freeze-dev-1701/frozen-study-v1'
    config=json.loads((folder/'agent-runtime.json').read_bytes())
    deployment=json.loads((folder/'agent-deployment.json').read_bytes())
    if config['port']!=18888:raise ValueError('Agent port changed')
    expected={'bin/MicroXRCEAgent':AGENT_SHA256,**{'lib/'+k:v for k,v in LIBRARY_SHA256.items()}}
    members={r['member']:r['deployed'] for r in deployment['members']}
    if set(members)!=set(expected) or len(members)!=len(deployment['members']):raise ValueError('Agent exact cache members differ')
    if {p.name for p in host_path(config['lib_dir']).iterdir()}!=set(LIBRARY_SHA256):raise ValueError('Agent extra/missing library')
    checks=[]
    for name,h in expected.items():
        path=config['binary'] if name=='bin/MicroXRCEAgent' else config['lib_dir']+'/'+name[4:]
        row=host_pin(path)
        if row['sha256']!=h or row['sha256']!=members[name]['sha256']:raise ValueError('Agent pinned bytes differ')
        checks.append(row)
    bundle=host_pin(config['bundle'])
    if bundle['sha256']!=BUNDLE_SHA256 or bundle['sha256']!=deployment['bundle']['sha256']:raise ValueError('Agent bundle changed')
    checks.append(bundle)
    catalog=json.loads(CATALOG.read_bytes())
    paths=set(VERSION_TOOLS)|{linux(OBSERVER),'/usr/bin/sha256sum'}
    paths.update(linux(ROOT/p) for p in source_snapshot())
    paths.update(linux(Path(scene['path'])/n) for n in scene['files'])
    paths.update(x['path'] for x in checks)
    paths.update([linux(folder/'agent-runtime.json'),linux(folder/'agent-deployment.json'),linux(CATALOG)])
    for role,values in catalog['inventory'].items():
        if role=='runtime:dependencies' or role=='graph:resolver' or (role.startswith('runtime-root:') and not role.startswith('runtime-root:python') and role not in {'runtime-root:openvins','runtime-root:native-reference'}):paths.update(values)
    roots=['/usr/lib/python3.12','/usr/lib/python3/dist-packages/gz','/usr/lib/python3/dist-packages/sdformat14',
           '/home/yuchen7509/.local/lib/python3.12/site-packages/numpy','/home/yuchen7509/.local/lib/python3.12/site-packages/scipy']
    # Fixed existing package layouts are explicit declarations, not guessed fallbacks.
    # sdformat14 may be a module file; the parent dist-packages traversal already covers it.
    roots=['/usr/lib/python3.12','/usr/lib/python3/dist-packages','/home/yuchen7509/.local/lib/python3.12/site-packages']
    bootstrap=[host_pin(x) for x in [*BOOTSTRAP_TOOLS,linux(OBSERVER)]]
    # Existing static scene and immutable deployment were checked against their hard pins above.
    return dict(schema='static-v3-preidentity-request-v1',sources=source_snapshot(),paths=sorted(paths),roots=roots,versions=VERSION_TOOLS,bootstrap=bootstrap,scene=scene,agent_files=checks)


def identity_run(label,request):
    request_path=OUT/(label+'-request.txt')
    body=''.join('P\\t'+p.encode().hex()+'\\n' for p in request['paths'])
    body+=''.join('D\\t'+p.encode().hex()+'\\n' for p in request['roots'])
    body+=''.join('V\\t'+p.encode().hex()+'\\n' for p in request['versions'])
    body+=''.join('B\\t'+r['path'].encode().hex()+'\\t'+r['sha256']+'\\n' for r in request['bootstrap'])
    with request_path.open('x',encoding='utf8',newline='\\n') as f:f.write(body)
    output=OUT/(label+'-primitive.txt')
    argv=['/usr/bin/env','-i','PATH=/usr/bin:/bin','LANG=C.UTF-8','/usr/bin/timeout','--signal=TERM','--kill-after=5s','30s',*observer_arguments(linux(request_path),linux(output))]
    start=time.monotonic_ns();primary=None;result=None;raw=b''
    write(OUT/(label+'-command.json'),dict(argv=argv,start_monotonic_ns=start,start_utc=datetime.datetime.now(datetime.UTC).isoformat(),bootstrap=request['bootstrap'],observer_source_sha256=hashlib.sha256(OBSERVER.read_bytes()).hexdigest()))
    try:
        verify_bootstrap(request['bootstrap'])
        result=remote(*argv,timeout=45)
        if output.exists():raw=output.read_bytes()
        rows=decode_observer(raw)
        write(OUT/(label+'-decoded.json'),rows)
        if result.returncode or not rows or rows[-1].get('kind')!='terminal' or rows[-1].get('error') is not None:raise ValueError('primitive identity incomplete/refused')
        verify_bootstrap(request['bootstrap'])
        begin=next(r for r in rows if r.get('kind')=='begin')
        before=[r['file'] for r in rows if r.get('kind')=='file' and r['phase']=='before']
        after=[r['file'] for r in rows if r.get('kind')=='file' and r['phase']=='after']
        if before!=after or len(before)!=len(begin['requested']) or [r['requested'] for r in before]!=begin['requested']:raise ValueError('identity exact input prepost differs')
        record=dict(error=None,sources=source_snapshot(),files_before=before,files_after=after,uid=begin['uid'],manager_control_environment=begin['manager_control_environment'],versions=[r for r in rows if r.get('kind')=='version'],observer_terminal=rows[-1],request=request,qualification=False)
        if record['sources']!=request['sources']:raise ValueError('current source changed during preidentity')
        write(OUT/(label+'.json'),record)
        return record
    except BaseException as exc:
        primary=exc
        raise
    finally:
        row=dict(exit=result.returncode if result else None,stdout_hex=result.stdout.hex() if result else None,stderr_hex=result.stderr.hex() if result else None,error=repr(primary) if primary else None,raw_bytes=len(raw),end_monotonic_ns=time.monotonic_ns(),elapsed_ns=time.monotonic_ns()-start,end_utc=datetime.datetime.now(datetime.UTC).isoformat())
        try:write(OUT/(label+'-return.json'),row)
        except Exception as exc:
            if primary is None:raise
            primary.add_note('identity return writer: '+repr(exc))


def preidentity():
    request=identity_request()
    write(OUT/'identity-request.json',request)
    return identity_run('preidentity',request)


def postidentity():
    original=json.loads((OUT/'preidentity.json').read_bytes())
    observed=identity_run('postidentity',original['request'])
    if observed['files_before']!=original['files_before'] or observed['sources']!=original['sources']:raise ValueError('postidentity changed')
    return observed


if __name__ == '__main__':
    raise SystemExit(main())
'''
p.write_text(s,encoding='utf8')
