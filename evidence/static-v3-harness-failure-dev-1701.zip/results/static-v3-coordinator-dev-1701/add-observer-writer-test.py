from pathlib import Path
p=Path('tests/benchmark/test_calibration_static_v3_executor.py');s=p.read_text(encoding='utf8');s+='''

def test_primitive_writer_secondary_failure_keeps_primary(tmp_path,monkeypatch):
    from types import SimpleNamespace
    from tools.benchmark import static_v3_identity as observer
    request=tmp_path/'request.txt';request.write_text('P\\t'+b'/fixture'.hex()+'\\n')
    calls=[]
    def fail(fd,data):
        calls.append(data)
        raise OSError('primary journal' if len(calls)==1 else 'secondary journal')
    fake=SimpleNamespace(**{k:getattr(observer.os,k) for k in dir(observer.os) if not k.startswith('__')})
    fake.getuid=lambda:1000
    fake.lstat=lambda p:SimpleNamespace(st_uid=1000,st_mode=0o040700)
    fake.stat=lambda p:SimpleNamespace(st_dev=1,st_ino=1,st_mode=0o100600,st_size=1,st_mtime_ns=1,st_ctime_ns=1)
    fake.write=fail
    monkeypatch.setattr(observer,'os',fake)
    monkeypatch.setattr(observer,'sys',SimpleNamespace(platform='linux',flags=SimpleNamespace(no_site=1),builtin_module_names=['time'],version='fixture'))
    monkeypatch.setattr(observer,'imported_extensions',lambda:[])
    monkeypatch.setattr(observer,'query',lambda *a:dict(exit=0,error=None,stdout_hex=('a'*64+'  /fixture\\n').encode().hex(),stderr_hex='',reader_complete=True))
    with pytest.raises(OSError,match='primary journal') as caught:observer.observe(str(request),str(tmp_path/'primitive.txt'))
    assert 'secondary journal' in ' '.join(caught.value.__notes__)
''';p.write_text(s,encoding='utf8')
