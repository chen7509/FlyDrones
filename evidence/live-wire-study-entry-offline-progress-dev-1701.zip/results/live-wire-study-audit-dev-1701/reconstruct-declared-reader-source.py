"""Post-run reconstruction, verified against the earlier retained source hash."""
import hashlib
import json
from pathlib import Path

root=Path('results/live-wire-study-audit-dev-1701')
record=json.loads((root/'study-entry-declared-reader-v1.json').read_text())
current=Path('tools/benchmark/audit_live_wire_study.py').read_bytes()
new=(b'        checks[stage]["manifest_file_records_verified"] = True\n'
     b'        checks[stage]["full_dependency_inventory_read"] = False\n')
old=b'        checks[stage]["files_verified"] = True\n'
assert current.count(new)==1
reconstructed=current.replace(new,old,1)
assert hashlib.sha256(reconstructed).hexdigest()==record['auditor']['sha256']
with (root/'declared-reader-producer-reconstructed.py').open('xb') as stream:
    stream.write(reconstructed)
with (root/'declared-reader-source-provenance.json').open('x') as stream:
    json.dump(dict(method='post-run exact-byte reconstruction matching contemporaneous hash; not a pre-run source copy',
                   sha256=hashlib.sha256(reconstructed).hexdigest(),bytes=len(reconstructed)),stream,indent=2)
