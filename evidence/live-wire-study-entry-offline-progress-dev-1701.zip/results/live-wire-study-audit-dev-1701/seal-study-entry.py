import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

base='results/live-wire-study-audit-dev-1701/'
files=[
 'tools/benchmark/audit_live_wire_study.py','tools/benchmark/live_wire_study.py',
 'tests/benchmark/test_live_wire_capture_identity.py','tests/benchmark/test_live_wire_study_entry.py',
 'tests/benchmark/test_live_wire_runtime_audit.py','tests/benchmark/test_live_wire_study.py',
 'tests/benchmark/fixtures/live_wire/README.md','tests/benchmark/fixtures/live_wire/installed-startup-result.json',
 'docs/LIVE_WIRE_RAW_EVIDENCE_MAP.md','docs/LIVE_WIRE_STUDY_PREPARATION_REPORT.md',
 'docs/superpowers/specs/2026-10-08-live-wire-study-design.md',
 'docs/superpowers/plans/2026-10-08-live-wire-study.md',
 '.superpowers/sdd/2026-10-08-live-wire-study/progress.md',
]
files += [base+name for name in [
 'capture-identity-red-v1.txt','capture-identity-green-v1.txt',
 'study-entry-red-v1.txt','study-entry-green-v1.txt','study-entry-ulog-red-v1.txt',
 'study-entry-declared-red-v1.txt','study-entry-symlink-red-v1.txt',
 'study-entry-regression-v1.txt','study-entry-boundary-red-v1.txt','study-entry-regression-v2.txt',
 'study-entry-scope-red-v1.txt','study-entry-final-targeted.txt','study-entry-protocol-regression-v1.txt',
 'study-entry-declared-green-v1.txt','study-entry-declared-reader-v1.json',
 'study-entry-ruff-v1.txt','study-entry-ruff-final.txt','study-entry-diff-check.txt',
 'check-declared-reader.py','reconstruct-declared-reader-source.py',
 'declared-reader-producer-reconstructed.py','declared-reader-source-provenance.json','seal-study-entry.py',
]]
assert len(files)==len(set(files))
blobs={name:Path(name).read_bytes() for name in files}
rows=[dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()) for name,raw in blobs.items()]
manifest=dict(schema='offline-wire-progress-evidence-v1',
 producer_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 scope='read-only partial study entry/cross-file identity; synthetic leaf routing and real startup negative',
 record_chain_qualified=False,live_qualified=False,fusion_qualified=False,whole_package_review_complete=False,
 declared_reader_source='earlier exact bytes reconstructed post-run and matched to retained hash',members=rows)
out=Path('evidence/live-wire-study-entry-offline-progress-dev-1701.zip')
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED) as archive:
 for name,raw in blobs.items(): archive.writestr(name,raw)
 archive.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(out) as archive:
 assert archive.testzip() is None and len(archive.namelist())==len(set(archive.namelist()))==len(files)+1
 for row in rows:
  raw=archive.read(row['path'])
  assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
print(json.dumps(dict(path=str(out),members=len(files)+1,bytes=out.stat().st_size,
                     sha256=hashlib.sha256(out.read_bytes()).hexdigest(),crc_verified=True)))
