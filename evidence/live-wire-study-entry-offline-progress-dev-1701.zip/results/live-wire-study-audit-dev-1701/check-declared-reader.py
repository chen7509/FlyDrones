"""Read/hash only; never execute the declared binary or create runtime objects."""
import hashlib
import json
import tempfile
from pathlib import Path

from tools.benchmark.audit_live_wire_study import StudyEvidenceReader
from tools.benchmark.declared_runtime_snapshot import file_record

source = file_record('tools/benchmark/audit_live_wire_study.py')
real = file_record('/usr/bin/python3')
reader = StudyEvidenceReader()
raw = reader.declared_file(real)
reader.finish()
assert hashlib.sha256(raw).hexdigest() == real['sha256']
with tempfile.TemporaryDirectory(prefix='flydrones-offline-declared-') as directory:
    root=Path(directory)
    first,second,alias=[root/name for name in ('first','second','alias')]
    first.write_bytes(b'not executed'); second.write_bytes(b'not executed')
    alias.symlink_to(first)
    frozen=file_record(alias)
    audit=StudyEvidenceReader()
    assert audit.declared_file(frozen)==b'not executed'
    alias.unlink(); alias.symlink_to(second)
    try:
        audit.finish()
    except ValueError as exc:
        refusal=repr(exc)
    else:
        raise AssertionError('same-content symlink retarget accepted')
assert file_record(source['requested'])==source
result=dict(installed_declared_symlink_read=True, selected_file=real,
            same_content_retarget_refused=refusal, auditor=source,
            binary_executed=False,live_qualified=False,fusion_qualified=False)
with Path('results/live-wire-study-audit-dev-1701/study-entry-declared-reader-v1.json').open('x') as stream:
    json.dump(result,stream,indent=2)
print(json.dumps({key:value for key,value in result.items() if key not in ('selected_file','auditor')}))
