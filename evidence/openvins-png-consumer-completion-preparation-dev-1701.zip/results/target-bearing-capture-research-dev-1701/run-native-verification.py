import pathlib, runpy, types, json, traceback, datetime
root=pathlib.Path('results/target-bearing-capture-research-dev-1701/native-parser-direct-v1')
root.mkdir(exist_ok=False)
module=runpy.run_path('tests/benchmark/test_openvins_dataset_native.py')
factory=types.SimpleNamespace(mktemp=lambda name: root)
records=[]
try:
 binary=module['native'].__wrapped__(factory)
 cases=[('integer',module['test_actual_native_preserves_integer_nanoseconds'],None),
 ('camera_escape',module['test_native_refuses_camera_escape_extra_and_regression'],'1000000000,../1000000000.png\n'),
 ('camera_extra',module['test_native_refuses_camera_escape_extra_and_regression'],'1000000000,1000000000.png,extra\n'),
 ('camera_regression',module['test_native_refuses_camera_escape_extra_and_regression'],'1000000000,1000000000.png\n1000000000,1000000000.png\n'),
 ('imu_nan',module['test_native_refuses_nonfinite_partial_integer_and_overflow'],'1000000000,nan,0,0,0,0,9.81\n'),
 ('imu_partial',module['test_native_refuses_nonfinite_partial_integer_and_overflow'],'1000000000junk,0,0,0,0,0,9.81\n'),
 ('imu_overflow',module['test_native_refuses_nonfinite_partial_integer_and_overflow'],'9223372036854775808,0,0,0,0,0,9.81\n')]
 for name,function,value in cases:
  output=root/name; output.mkdir()
  if value is None: function(binary,output)
  else: function(binary,output,value)
  records.append({'case':name,'assertions_passed':True})
 (root/'assertions.json').write_text(json.dumps({'cases':records,'native_cases':7,'no_estimator':True,'qualification':False},indent=2))
 print(json.dumps({'actual_native_cases_passed':len(records)}))
except BaseException as error:
 (root/'harness-failure.json').write_text(json.dumps({'type':type(error).__name__,'message':str(error),'cases_completed':records,'native_dispatch_unknown_until_scope_record':True},indent=2))
 raise
