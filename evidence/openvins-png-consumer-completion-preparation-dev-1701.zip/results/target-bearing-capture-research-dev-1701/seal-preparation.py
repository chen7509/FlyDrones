import hashlib
import json
from pathlib import Path
import zipfile

root = Path.cwd()
trial = root/'results/target-bearing-capture-research-dev-1701'
def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(65536), b''):
            value.update(block)
    return value.hexdigest()
baseline = json.loads((root/'results/target-excitation-research-dev-1701/all-historical-archives-after.json').read_text())
expected = baseline['expected_sha256']
expected['evidence/kalibr-native-target-consumption-dev-1701.zip'] = 'b2ef3316e3be642da3501a20a2e460cf1cdbd6580f00ddb63138a8b49d1f7047'
changed = [name for name, value in expected.items() if sha(root/name) != value]
assert not changed, changed
with (trial/'historical-archives.json').open('x') as stream:
    json.dump({'count': len(expected), 'bytes': sum((root/name).stat().st_size for name in expected),
               'changed': changed, 'expected_sha256': expected}, stream, indent=2)
sources = json.loads((trial/'final-code-before.json').read_text())
files = [root/name for name in sources]
files += [root/'tools/benchmark/gpl/README.md',
          root/'docs/OPENVINS_PNG_CONSUMER_COMPLETION_PREPARATION_REPORT.md',
          root/'docs/superpowers/specs/2026-10-14-openvins-png-consumer-completion.md',
          root/'docs/superpowers/plans/2026-10-14-openvins-png-consumer-completion.md']
files += [p for p in trial.rglob('*') if p.is_file() and '__pycache__' not in p.parts
          and '.pytest_cache' not in p.parts and p.name != 'seal-result.json']
files = sorted(set(files))
manifest = {'status': 'pending-native-preparation', 'native_dispatched': False,
            'members': [{'path': p.relative_to(root).as_posix(), 'size': p.stat().st_size,
                         'sha256': sha(p)} for p in files]}
zip_path = root/'evidence/openvins-png-consumer-completion-preparation-dev-1701.zip'
with zipfile.ZipFile(zip_path, 'x', zipfile.ZIP_DEFLATED) as archive:
    for p in files:
        archive.write(p, p.relative_to(root).as_posix())
    archive.writestr('MANIFEST.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(zip_path) as archive:
    assert archive.testzip() is None
    for row in manifest['members']:
        data = archive.read(row['path'])
        assert len(data) == row['size'] and hashlib.sha256(data).hexdigest() == row['sha256']
        assert data == (root/row['path']).read_bytes()
result = {'path': zip_path.relative_to(root).as_posix(), 'sha256': sha(zip_path),
          'members': len(files)+1, 'bytes': zip_path.stat().st_size,
          'mapped_members': len(files), 'CRC_SHA_size_currentbytes_errors': 0,
          'historical_count': len(expected), 'historical_changed': changed,
          'native_dispatch': False, 'publication': 'not yet committed or pushed'}
(trial/'seal-result.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result))
