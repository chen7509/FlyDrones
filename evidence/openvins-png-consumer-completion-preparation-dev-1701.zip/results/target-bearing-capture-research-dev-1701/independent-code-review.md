# Independent review of pending PNG/native consumer preparation

Final source review: 2026-10-15, Asia/Shanghai. Checkout: `track-eligibility`; supplied base HEAD: `f128978`. Review followed the requesting-code-review workflow and the original candidate-dataset consumer spec/plan plus PNG completion addendum. The reviewer inspected source, diffs, frozen hashes, and retained logs. The reviewer ran no tests, resource admission, compiler, native consumer, or resource retry. The only reviewer-created artifact is this report.

## Final assessment

No remaining Critical, Important, or Minor code findings were identified in this review. The preparation may be sealed with its pending verification clearly stated. This is not approval to bypass admission or evidence that the native plan is complete.

The C++ adapter/header and real Linux procfs identity handshake remain UNCOMPILED/UNTESTED. No original native consumer study has been created or consumed. Actual compile, PNG consumption, all 251 frame outcomes/derivatives, all 6123 returned IMU calls including the tail, loaded-library audit, scoped runtime, and cleanup artifacts remain pending. The consumed cached PPM consumer must not be repeated.

## Original findings and resolution

All four original findings were Important; there were no Critical findings.

1. Frozen YAML configuration was copied and compared only with its own snapshot. The executor now pins all three historical YAML hashes, checks originals before study creation, checks copied files before dispatch, and compares final copies with the frozen values.
2. Dataset member hashes came from an unpinned manifest. The executor now checks the producer manifest SHA256 `1f7ab4c651e505a51a2317e477ff019128523976a6e8ccd22f01568986fb1e3f` before accepting its entries.
3. Returned IMU journal rows were buffered and omitted public initialization/reference fields. The C++ feed wrapper now records source index, integer sample nanoseconds, native-return status, public initialization status, and state reference timestamp; it flushes and checks each row, including tail rows.
4. Linker argv and an on-disk library hash did not establish the actual loaded library, and compiler identity was absent. Compiler resolved path/hash/version are now recorded and rechecked. A snapshotted Linux supervisor owns the native Popen and stdin barrier. Before release it records actual `/proc/PID/exe` bytes/path and library maps path/device/inode plus the pinned on-disk SHA. It persists an exclusive admission record before releasing the byte. The child loader override environment is cleared. This remains a controlled-file, pre-feed observation; mapped-memory, continuous, all-dependency integrity and escaped-descendant closure remain unknown.

## Follow-up findings and resolution

Both follow-up findings were Important; there were no Critical findings.

1. The marker became visible between exclusive open and PID write, while the supervisor treated existence as complete readiness. The supervisor now waits for contents matching its actual Popen PID within the existing readiness loop/deadline. Empty or incomplete marker contents cannot release feeds. The retained `readiness-race-red.txt` shows the valid-child rejection before correction.
2. State header and camera outcome flushes were unchecked, permitting subsequent calls after evidence writes failed. The C++ now checks stream status immediately after the header, range-refusal row, and returned-camera row. Failures stop subsequent feeds.

The final inspection confirmed these corrections in the source. It also checked monotonic source indexing, the immediate following IMU boundary logic, final IMU tail loop, PNG grayscale/PGM preservation, explicit camera range refusal, exclusive output/record creation, owned-child cleanup, unchanged declared scope budgets, and false qualification outputs.

## Retained verification boundaries

The inspected `final-software.txt` reports **21 passed, 7 deselected in 2.01 s**; `final-ruff.txt` reports all checks passed. These are software preparation checks. The added actual owned Python protocol child is a Windows software process with injected identity inspection; it does not exercise Linux procfs, the C++ marker, OpenVINS, or native sensor feeds.

The retained first parser attempt reports **2 guard passes / 7 setup errors**. Its first admission observed Windows `1963929600` and WSL `7042138112` bytes. The separate direct fixture admission observed Windows `1956474880` and WSL `7046025216` bytes and retained an assertion failure before compilation with no completed native cases. Both failed the unchanged Windows 2 GiB reserve. They are resource refusals, not native RED/GREEN. No fresh retry was made by this reviewer.

Earlier signature failures, first seal-test regex failure, missing-module failures, and platform fixture failures must retain their own stated boundaries; they cannot be reclassified as successful native behavior verification. The final review does not erase these records.

## Source bytes reviewed

| File | SHA256 |
| --- | --- |
| `tools/benchmark/run_openvins_dataset_consumer.py` | `f93c19ed132281339202f63172089711ee348697bedf8edee31a7d8ab32bf09a` |
| `tools/benchmark/gpl/openvins_dataset_consumer.cpp` | `a8a479c59c9880f3abcf9077fa772e0c1877810a9b1766937a77f8f3b460d53c` |
| `tools/benchmark/gpl/openvins_dataset_io.h` | `175226bd06b37d5236a891efec3c1871e4b2949b12425f5cd1d37c1122429e74` |
| `tools/benchmark/openvins_native_identity.py` | `8489d2d06a931832fe2ace305b9a283e9d83899a8835381cf673222d34417439` |
| `tools/benchmark/native_consumer_scope.py` | `5f1ef5c972d1719654a8c284462ede7467f9b1c8c033c40703fce18734206034` |

## Declined to judge

- Actual native compilation, feed returns, procfs observations, resource use, and cleanup: no admitted native execution exists.
- Hostile concurrent file mutation or mapped-memory verification: outside the explicitly controlled static-file boundary; no such resistance is claimed.
- Physical target-bearing source/camera production and calibration: require the original separate 4 GiB admission and physical trial.
- Live source authentication, clock/spatial-time calibration, accuracy, fusion, teacher, training, and flight qualification: raw offline return values cannot establish these claims.

Ready to merge as an explicitly pending preparation: **yes, subject to normal publication checks**. Ready to claim completed native consumer or production qualification: **no**.
