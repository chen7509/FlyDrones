import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import sys

out = pathlib.Path(__file__).parent
sources = ['tools/benchmark/run_openvins_dataset_consumer.py',
           'tools/benchmark/openvins_native_identity.py',
           'tools/benchmark/gpl/openvins_dataset_consumer.cpp',
           'tools/benchmark/gpl/openvins_dataset_io.h',
           'tools/benchmark/native_consumer_scope.py',
           'tests/benchmark/test_openvins_dataset_native.py',
           'tests/benchmark/test_openvins_png_admission_record.py',
           'tests/benchmark/test_openvins_native_identity.py']
snapshot = out/'final-code'
snapshot.mkdir(exist_ok=False)
hashes = {}
for name in sources:
    data = pathlib.Path(name).read_bytes()
    target = snapshot/name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    hashes[name] = hashlib.sha256(data).hexdigest()
(out/'final-code-before.json').write_text(json.dumps(hashes, indent=2))
commands = [
    ('retained-software', [sys.executable, '-m', 'pytest',
        'tests/benchmark/test_openvins_native_identity.py',
        'tests/benchmark/test_openvins_png_admission_record.py',
        'tests/benchmark/test_openvins_cached_bridge.py',
        'tests/benchmark/test_openvins_dataset_native.py',
        '-k', 'not actual_native and not native_refuses', '-q',
        '--basetemp='+str(out/'retained-software-cases')], 0),
    ('cli-required-record', [sys.executable, '-m', 'tools.benchmark.run_openvins_dataset_consumer',
                             '--execute-once'], 2),
    ('retained-ruff', [sys.executable, '-m', 'ruff', 'check',
        *[name for name in sources if name.endswith('.py')]], 0),
    ('working-diff', ['git', 'diff', '--check'], 0),
]
environment = os.environ.copy()
environment['PYTHONPATH'] = 'src;.'
environment['PYTHONUTF8'] = '1'
records = []
for label, command, expected in commands:
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (out/(label+'.stdout')).open('xb') as stdout, (out/(label+'.stderr')).open('xb') as stderr:
        result = subprocess.run(command, stdout=stdout, stderr=stderr, env=environment)
    record = {'argv': command, 'start_utc': start,
              'finish_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'exit': result.returncode, 'expected_exit': expected,
              'environment': {'PYTHONPATH': 'src;.', 'PYTHONUTF8': '1'},
              'source_before_sha256': hashes, 'native_dispatched': False}
    (out/(label+'.command.json')).write_text(json.dumps(record, indent=2))
    records.append(record)
    print(label, result.returncode)
    if result.returncode != expected:
        raise RuntimeError(label+' failed')
after = {name: hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest() for name in sources}
assert hashes == after
(out/'software-verification.json').write_text(json.dumps({'commands': records,
    'source_after_sha256': after, 'native_verified': False}, indent=2))
