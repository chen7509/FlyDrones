import pathlib,os,sys
out=pathlib.Path(sys.argv[2])
out.with_name(out.name+'.identity-ready').write_text(str(os.getpid()))
assert sys.stdin.buffer.read(1)==b'1'
assert out.with_name(out.name+'.identity.json').exists()
out.write_text('software protocol released, not native estimator')
