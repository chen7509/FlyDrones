# SDD ledger — plan: docs/superpowers/plans/2026-10-12-xrce-typed-odometry.md

Baseline: b60dc355cdb1b9b984a54602ae7adf43a2e0b535, clean tracked worktree before this plan.
Pre-flight: Task 1 produces a pinned C diagnostic client and payload contract consumed by Task 2; Task 2 produces bounded run records consumed by Task 3. No conflicting interfaces found.
Ruling: User's prior blanket authorization to execute each step takes precedence over the skill's repeated approval checkpoints; no new permission request is needed. Cost if wrong: design preference might differ, so preserve this as a synthetic diagnostic with fail-closed results.
Ruling: Use the actual fixed PX4-generated type/topic/version and binary entity QoS, not a guessed ROS or current-main string. Cost if wrong: a stale generated build could disagree with current ROS type, which the typed callback/parity gate will expose.
Task 1: complete. RED: frozen CDR extractor missing (pytest failed), then 3 positive/refusal tests GREEN. RED: native client source missing (targeted WSL GCC test failed), then pinned-client-header/native self-test GREEN. The client publishes exactly one synthetic body and claims no PX4 source.
Ruling: The plan's generic `run.py` will be split into immutable attempt-local build/runtime runners under ignored `results/xrce-typed-odometry-dev-1701*`; this preserves failed attempts without allowing a later reusable runner to overwrite their logs. Cost if wrong: less convenient replay, offset by exact scripts in sealed evidence.
