"""Inspect the fixed-image diagnostic client and frozen body before runtime."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
IMAGE = "sha256:a4dae62b38bc01a01d084be7b68db83ec804fef7673604e1a9c986a4baa88a6a"
WORK = "/tmp/flydrones-xrce-typed-1701-v4"
AGENT = "/tmp/flydrones-agent-humble-1701-v3"
REPO = "/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility"
EXE = "/diag/build/flydrones_xrce_typed_probe"
OUT = HERE / "abi-result.json"


def check(name: str, args: list[str]) -> dict:
    cmd = ["wsl", "-d", "Ubuntu", "--", "docker", "run", "--rm",
           "--name", f"flydrones-xrce-abi-{name}-v4", "--network", "none",
           "--cpus", "1", "--memory", "256m", "--memory-swap", "256m",
           "--mount", f"type=bind,src={WORK},dst=/diag,readonly",
           "--mount", f"type=bind,src={AGENT},dst=/work,readonly",
           "--mount", f"type=bind,src={REPO},dst=/repo,readonly", IMAGE, *args]
    res = subprocess.run(cmd, capture_output=True, text=True,
                         errors="replace", timeout=15)
    (HERE / f"abi-{name}.stdout").write_text(res.stdout, encoding="utf-8")
    (HERE / f"abi-{name}.stderr").write_text(res.stderr, encoding="utf-8")
    return {"args": cmd, "returncode": res.returncode}


def main() -> None:
    if OUT.exists():
        raise FileExistsError(OUT)
    ldd = check("ldd", ["ldd", EXE])
    versions = check("versions", ["readelf", "--version-info", EXE])
    describe = check("describe", [EXE, "--describe"])
    body = check("body", [EXE, "--self-test",
                          "/repo/results/xrce-typed-odometry-dev-1701-v4/odometry-body.bin"])
    remaining = subprocess.run(
        ["docker", "ps", "-a", "--filter", "name=flydrones-xrce-abi-",
         "--format", "{{.Names}}"], capture_output=True, text=True, timeout=10)
    good = (ldd["returncode"] == versions["returncode"] == describe["returncode"]
            == body["returncode"] == 0
            and "not found" not in (HERE / "abi-ldd.stdout").read_text()
            and '"topic":"rt/fmu/out/vehicle_odometry"' in
            (HERE / "abi-describe.stdout").read_text()
            and '"body_bytes":116' in (HERE / "abi-body.stdout").read_text()
            and remaining.returncode == 0 and not remaining.stdout.strip())
    OUT.write_text(json.dumps({"schema": "flydrones.xrce_client_abi.v1",
                               "ldd": ldd, "versions": versions, "describe": describe,
                               "body": body, "owned_containers_after": remaining.stdout.splitlines(),
                               "qualified": good, "typed_callback_verified": False,
                               "px4_source_authenticated": False}, indent=2), encoding="utf-8")
    print(json.dumps({"qualified": good, "codes": [ldd["returncode"],
                                                   versions["returncode"],
                                                   describe["returncode"],
                                                   body["returncode"]]}))


if __name__ == "__main__":
    main()
