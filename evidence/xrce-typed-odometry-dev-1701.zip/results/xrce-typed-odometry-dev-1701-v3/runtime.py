"""Launch one bounded, offline synthetic XRCE-to-typed-ROS diagnostic."""

from __future__ import annotations

import ctypes
import hashlib
import json
import subprocess
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
IMAGE = "sha256:a4dae62b38bc01a01d084be7b68db83ec804fef7673604e1a9c986a4baa88a6a"
REPO = "/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility"
AGENT_WORK = "/tmp/flydrones-agent-humble-1701-v3"
DIAG_WORK = "/tmp/flydrones-xrce-typed-1701-v3"
COLLECTOR_WORK = REPO + "/results/px4-ros2-full-build-attempt-dev-1701/workspace-v1"
EVIDENCE_WORK = REPO + "/results/xrce-typed-odometry-dev-1701-v3"
CONTAINER = "flydrones-xrce-typed-runtime-v3"
MIN_FREE = int(1.5 * 1024**3)
AGENT_SHA = "3918279bd7c3ae3a76a5338bd1b31a52e334c4e6c1d648141b0adca65a2d6d8e"
CLIENT_SHA = "80f7079b7adb997d26c44b07a96e5f4b9ad20df4e2e4d1611bf2f88c76d8bd43"
COLLECTOR_SHA = "31ad3958028660bf4ed468ddcbd25e7d5ca3e994b7729e4538ebe383a46ecf7f"
BODY_SHA = "fcd9a9219bb6b082906ba71a013132f500210367bf8737915e395270e530aa82"


class MemoryStatus(ctypes.Structure):
    _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]


def free_bytes() -> int:
    s = MemoryStatus()
    s.dwLength = ctypes.sizeof(s)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(s)):
        raise OSError("physical memory query failed")
    return s.ullAvailPhys


def call(args: list[str], timeout: int = 15) -> dict:
    r = subprocess.run(args, capture_output=True, text=True, errors="replace", timeout=timeout)
    return {"args": args, "returncode": r.returncode,
            "stdout": r.stdout, "stderr": r.stderr}


def main() -> None:
    preflight_path = HERE / "runtime-preflight.json"
    output_path = HERE / "runtime-result.json"
    if preflight_path.exists() or output_path.exists() or (HERE / "inside-result.json").exists():
        raise FileExistsError("runtime already attempted")
    build = json.loads((HERE / "build-result.json").read_text(encoding="utf-8"))
    abi = json.loads((HERE / "abi-result.json").read_text(encoding="utf-8"))
    local_hashes = {
        "collector": hashlib.sha256((ROOT / "results/px4-ros2-full-build-attempt-dev-1701/workspace-v1/install/flydrones_px4_ros2_source/lib/flydrones_px4_ros2_source/px4_odometry_source").read_bytes()).hexdigest(),
        "body": hashlib.sha256((HERE / "odometry-body.bin").read_bytes()).hexdigest(),
        "inside_source": hashlib.sha256((HERE / "inside.py").read_bytes()).hexdigest(),
    }
    agent = call(["wsl", "-d", "Ubuntu", "--", "sha256sum",
                  AGENT_WORK + "/build/MicroXRCEAgent"])
    client = call(["wsl", "-d", "Ubuntu", "--", "sha256sum",
                   DIAG_WORK + "/build/flydrones_xrce_typed_probe"])
    image = call(["docker", "image", "inspect", IMAGE, "--format", "{{.Id}}"])
    containers = call(["docker", "ps", "--format", "{{.Names}}"])
    free = free_bytes()
    good = (build["success"] and abi["qualified"] and free >= MIN_FREE
            and local_hashes["collector"] == COLLECTOR_SHA
            and local_hashes["body"] == BODY_SHA
            and agent["returncode"] == client["returncode"] == 0
            and agent["stdout"].split()[0] == AGENT_SHA
            and client["stdout"].split()[0] == CLIENT_SHA
            and image["returncode"] == 0 and image["stdout"].strip() == IMAGE
            and containers["returncode"] == 0 and not containers["stdout"].strip())
    preflight = {"schema": "flydrones.xrce_typed_runtime_preflight.v1",
                 "host_available_bytes": free, "minimum_bytes": MIN_FREE,
                 "build_success": build["success"], "abi_qualified": abi["qualified"],
                 "local_hashes": local_hashes, "agent": agent, "client": client,
                 "image": image, "containers": containers, "qualified": good,
                 "physical_simulation_qualified": False}
    preflight_path.write_text(json.dumps(preflight, indent=2), encoding="utf-8")
    if not good:
        print(json.dumps({"status": "preflight_refused", "free": free}))
        return
    command = ["wsl", "-d", "Ubuntu", "--", "docker", "run", "--rm",
               "--name", CONTAINER, "--network", "none", "--cpus", "1",
               "--memory", "768m", "--memory-swap", "768m", "--pids-limit", "128",
               "--mount", f"type=bind,src={AGENT_WORK},dst=/work,readonly",
               "--mount", f"type=bind,src={DIAG_WORK},dst=/diag,readonly",
               "--mount", f"type=bind,src={COLLECTOR_WORK},dst=/workspace,readonly",
               "--mount", f"type=bind,src={REPO},dst=/repo,readonly",
               "--mount", f"type=bind,src={EVIDENCE_WORK},dst=/evidence",
               IMAGE, "python3", "/repo/results/xrce-typed-odometry-dev-1701-v3/inside.py"]
    started = time.time_ns()
    timed_out = False
    try:
        run = call(command, timeout=30)
    except subprocess.TimeoutExpired as exc:
        timed_out = True
        run = {"args": command, "returncode": 124,
               "stdout": (exc.stdout or b"").decode("utf-8", errors="replace"),
               "stderr": (exc.stderr or b"").decode("utf-8", errors="replace")}
    (HERE / "runtime.stdout").write_text(run["stdout"], encoding="utf-8")
    (HERE / "runtime.stderr").write_text(run["stderr"], encoding="utf-8")
    listed = call(["docker", "ps", "-a", "--filter", f"name=^/{CONTAINER}$",
                   "--format", "{{.Names}}"])
    cleanup = call(["docker", "rm", "-f", CONTAINER]) if listed["stdout"].strip() else None
    after = call(["docker", "ps", "-a", "--filter", f"name=^/{CONTAINER}$",
                  "--format", "{{.Names}}"])
    result = {"schema": "flydrones.xrce_typed_runtime.v1",
              "command": command, "started_unix_ns": started,
              "ended_unix_ns": time.time_ns(), "timeout": timed_out,
              "docker_exit": run["returncode"], "listed_after": listed,
              "cleanup": cleanup, "owned_after": after,
              "synthetic_only": True, "px4_source_authenticated": False,
              "fusion_qualified": False, "typed_callback_verified": False}
    output_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({"docker_exit": run["returncode"], "timeout": timed_out,
                      "owned_after": after["stdout"].strip()}))


if __name__ == "__main__":
    main()
