"""Owned, synthetic XRCE Agent/client/typed-collector lifecycle inside Docker."""

from __future__ import annotations

import json
import os
import signal
import subprocess
import threading
import time
from pathlib import Path

OUT = Path("/evidence")
AGENT = "/work/build/MicroXRCEAgent"
CLIENT = "/diag/build/flydrones_xrce_typed_probe"
COLLECTOR = ("/workspace/install/flydrones_px4_ros2_source/lib/"
             "flydrones_px4_ros2_source/px4_odometry_source")
BODY = "/repo/results/xrce-typed-odometry-dev-1701-v7/odometry-body.bin"
JOURNAL = "/evidence/xrce-synthetic-v2.jsonl"


def stop_owned(process: subprocess.Popen, label: str, record: dict) -> None:
    if process.poll() is not None:
        record[f"{label}_cleanup"] = "already_exited"
        return
    os.killpg(process.pid, signal.SIGTERM)
    record[f"{label}_cleanup"] = "SIGTERM"
    try:
        process.wait(timeout=3)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        record[f"{label}_cleanup"] = "SIGTERM_then_SIGKILL"
        process.wait(timeout=2)


def main() -> None:
    output = OUT / "inside-result.json"
    if output.exists() or (OUT / "agent.log").exists() or Path(JOURNAL).exists():
        raise FileExistsError("runtime evidence already exists")
    result: dict = {"schema": "flydrones.xrce_typed_inside.v1",
                    "synthetic_only": True, "px4_source_authenticated": False,
                    "fusion_qualified": False, "started_unix_ns": time.time_ns(),
                    "collector_pid": None, "agent_pid": None, "client_pid": None,
                    "graph_pid": None, "graph_exit": None,
                    "collector_exit": None, "agent_exit": None, "client_exit": None,
                    "agent_ready": False, "completed": False}
    processes: dict[str, subprocess.Popen] = {}
    agent_lines: list[str] = []
    agent_ready = threading.Event()
    try:
        env = os.environ.copy()
        env["RMW_IMPLEMENTATION"] = "rmw_cyclonedds_cpp"
        env["ROS_DOMAIN_ID"] = "0"
        env["ROS_LOCALHOST_ONLY"] = "1"
        collector = subprocess.Popen(
            ["bash", "-lc", "source /opt/ros/humble/setup.bash && "
             "source /workspace/install/setup.bash && exec " + COLLECTOR +
             " " + JOURNAL + " synthetic-xrce-v7 15 1 --full-state-v2"],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, start_new_session=True, env=env)
        processes["collector"] = collector
        result["collector_pid"] = collector.pid
        time.sleep(1)
        if collector.poll() is not None:
            raise RuntimeError("collector exited before Agent")

        agent = subprocess.Popen([AGENT, "udp4", "-p", "18893", "-m", "dds",
                                  "-v", "6"],
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                 text=True, bufsize=1, start_new_session=True,
                                 env=env)
        processes["agent"] = agent
        result["agent_pid"] = agent.pid

        def read_agent() -> None:
            assert agent.stdout is not None
            for line in agent.stdout:
                agent_lines.append(line)
                if "running..." in line and "18893" in line:
                    agent_ready.set()

        reader = threading.Thread(target=read_agent, daemon=True)
        reader.start()
        if not agent_ready.wait(timeout=4) or agent.poll() is not None:
            raise RuntimeError("Agent readiness not observed")
        result["agent_ready"] = True

        graph = subprocess.Popen(
            ["bash", "-lc", "source /opt/ros/humble/setup.bash && "
             "source /workspace/install/setup.bash && exec python3 "
             "/repo/tools/connectome/xrce_typed_probe/graph_wait.py "
             "/evidence/graph-ready.txt /evidence/graph-proof.json"],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, start_new_session=True, env=env)
        processes["graph"] = graph
        result["graph_pid"] = graph.pid

        client = subprocess.Popen([CLIENT, "--send", "127.0.0.1", "18893", BODY,
                                   "/evidence/graph-ready.txt"],
                                  stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                  text=True, start_new_session=True, env=env)
        processes["client"] = client
        result["client_pid"] = client.pid
        client_output, _ = client.communicate(timeout=10)
        (OUT / "client.log").write_text(client_output, encoding="utf-8")
        result["client_exit"] = client.returncode

        graph_output, _ = graph.communicate(timeout=2)
        (OUT / "graph.log").write_text(graph_output, encoding="utf-8")
        result["graph_exit"] = graph.returncode

        collector_output, _ = collector.communicate(timeout=10)
        (OUT / "collector.log").write_text(collector_output, encoding="utf-8")
        result["collector_exit"] = collector.returncode
        if client.returncode != 0 or graph.returncode != 0 or collector.returncode != 0:
            raise RuntimeError("client, graph, or collector failed")
        result["completed"] = True
    except Exception as exc:
        result["error"] = repr(exc)
    finally:
        for label in ("client", "graph", "collector", "agent"):
            if label in processes:
                try:
                    stop_owned(processes[label], label, result)
                except Exception as exc:
                    result[f"{label}_cleanup_error"] = repr(exc)
                result[f"{label}_exit"] = processes[label].poll()
        if "agent" in processes:
            reader.join(timeout=2)
        (OUT / "agent.log").write_text("".join(agent_lines), encoding="utf-8")
        if "collector" in processes and not (OUT / "collector.log").exists():
            assert processes["collector"].stdout is not None
            (OUT / "collector.log").write_text(
                processes["collector"].stdout.read(), encoding="utf-8")
        if "client" in processes and not (OUT / "client.log").exists():
            assert processes["client"].stdout is not None
            (OUT / "client.log").write_text(
                processes["client"].stdout.read(), encoding="utf-8")
        if "graph" in processes and not (OUT / "graph.log").exists():
            assert processes["graph"].stdout is not None
            (OUT / "graph.log").write_text(
                processes["graph"].stdout.read(), encoding="utf-8")
        result["ended_unix_ns"] = time.time_ns()
        output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({"completed": result["completed"],
                      "client_exit": result["client_exit"],
                      "collector_exit": result["collector_exit"],
                      "error": result.get("error")}))
    if not result["completed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
