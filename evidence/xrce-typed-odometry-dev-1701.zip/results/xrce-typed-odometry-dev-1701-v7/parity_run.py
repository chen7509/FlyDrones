"""Read-only independent CDR decode in the pinned ROS 2 image."""

import json
import subprocess
from pathlib import Path

here = Path(__file__).resolve().parent
if (here / "parity-result.json").exists():
    raise FileExistsError("parity already attempted")
image = "sha256:a4dae62b38bc01a01d084be7b68db83ec804fef7673604e1a9c986a4baa88a6a"
repo = "/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility"
workspace = repo + "/results/px4-ros2-full-build-attempt-dev-1701/workspace-v1"
command = [
    "wsl", "-d", "Ubuntu", "--", "docker", "run", "--rm", "--network", "none",
    "--cpus", "1", "--memory", "256m", "--memory-swap", "256m",
    "--mount", f"type=bind,src={repo},dst=/repo,readonly",
    "--mount", f"type=bind,src={workspace},dst=/workspace,readonly",
    image, "bash", "-lc",
    "source /opt/ros/humble/setup.bash && "
    "source /workspace/install/setup.bash && "
    "python3 /repo/tools/connectome/check_full_odometry_cdr_parity.py "
    "/repo/results/xrce-typed-odometry-dev-1701-v7/xrce-synthetic-v2.jsonl",
]
run = subprocess.run(command, capture_output=True, text=True, errors="replace", timeout=20)
result = {"command": command, "returncode": run.returncode,
          "stdout": run.stdout, "stderr": run.stderr,
          "independent_decode_pass": run.returncode == 0,
          "synthetic_only": True, "px4_source_authenticated": False,
          "fusion_qualified": False}
(here / "parity-result.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps({"returncode": run.returncode, "stdout": run.stdout,
                  "stderr": run.stderr}))
