"""Seal immutable synthetic XRCE diagnostic attempts and reviewed sources."""

from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUTPUT = ROOT / "evidence/xrce-typed-odometry-dev-1701.zip"
PREFIX = "xrce-typed-odometry-dev-1701"
SOURCES = (
    "docs/XRCE_TYPED_ODOMETRY_DIAGNOSTIC_REPORT.md",
    "docs/superpowers/plans/2026-10-12-xrce-typed-odometry.md",
    "docs/superpowers/specs/2026-10-12-xrce-typed-odometry-design.md",
    ".superpowers/sdd/2026-10-12-xrce-typed-odometry/progress.md",
    "tests/test_xrce_typed_probe.py",
)


def main() -> None:
    if OUTPUT.exists():
        raise FileExistsError(OUTPUT)
    paths = [ROOT / name for name in SOURCES]
    paths.extend((ROOT / "tools/connectome/xrce_typed_probe").glob("*.py"))
    paths.extend((ROOT / "tools/connectome/xrce_typed_probe").glob("*.c"))
    paths.extend((ROOT / "tools/connectome/xrce_typed_probe").glob("CMakeLists.txt"))
    for suffix in ("", *(f"-v{n}" for n in range(2, 11))):
        directory = ROOT / "results" / (PREFIX + suffix)
        if not directory.is_dir():
            raise FileNotFoundError(directory)
        paths.extend(path for path in directory.rglob("*") if path.is_file()
                     and "__pycache__" not in path.parts
                     and not path.name.endswith(".pyc")
                     and path.name != "seal-result.json")
    members: dict[str, dict] = {}
    for path in sorted(set(paths)):
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"missing/symlink member: {path}")
        name = path.relative_to(ROOT).as_posix()
        data = path.read_bytes()
        if len(data) > 10_000_000:
            raise ValueError(f"unexpected large member: {name}")
        members[name] = {"size": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    if len(members) < 100:
        raise ValueError("attempt history incomplete")
    manifest = {"schema": "flydrones.xrce_typed_evidence_manifest.v1",
                "historical_attempts": list(range(1, 11)),
                "synthetic_only": True,
                "px4_source_authenticated": False,
                "runtime_daemon_identity_qualified": False,
                "members": members}
    with zipfile.ZipFile(OUTPUT, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for name in members:
            archive.write(ROOT / name, name)
        archive.writestr("MANIFEST.json", json.dumps(manifest, indent=2))
    with zipfile.ZipFile(OUTPUT) as archive:
        if archive.testzip() is not None:
            raise ValueError("archive CRC failure")
        for name, record in members.items():
            data = archive.read(name)
            if len(data) != record["size"] or hashlib.sha256(data).hexdigest() != record["sha256"]:
                raise ValueError(f"archive member mismatch: {name}")
        if json.loads(archive.read("MANIFEST.json")) != manifest:
            raise ValueError("manifest mismatch")
    result = {"schema": "flydrones.xrce_typed_evidence_seal.v1",
              "archive": OUTPUT.relative_to(ROOT).as_posix(),
              "sha256": hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),
              "member_count": len(members) + 1,
              "all_members_verified": True,
              "synthetic_only": True,
              "runtime_daemon_identity_qualified": False}
    (Path(__file__).with_name("seal-result.json")).write_text(
        json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
