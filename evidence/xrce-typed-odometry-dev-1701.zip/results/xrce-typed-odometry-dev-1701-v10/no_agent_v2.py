"""One bounded closed-port refusal using the fixed synthetic client."""

import json
import subprocess
from pathlib import Path

here = Path(__file__).resolve().parent
output = here / "no-agent-v2-result.json"
if output.exists():
    raise FileExistsError("no-Agent test already attempted")
image = "sha256:a4dae62b38bc01a01d084be7b68db83ec804fef7673604e1a9c986a4baa88a6a"
repo = "/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility"
command = ["wsl", "-d", "Ubuntu", "--", "docker", "run", "--rm",
           "--name", "flydrones-xrce-no-agent-v2", "--network", "none",
           "--cpus", "1", "--memory", "256m", "--memory-swap", "256m",
           "--pids-limit", "32",
           "--mount", "type=bind,src=/tmp/flydrones-xrce-typed-1701-v5,dst=/diag,readonly",
           "--mount", "type=bind,src=/tmp/flydrones-agent-humble-1701-v3,dst=/work,readonly",
           "--mount", f"type=bind,src={repo},dst=/repo,readonly",
           image, "timeout", "5s", "/diag/build/flydrones_xrce_typed_probe",
           "--send", "127.0.0.1", "18893",
           "/repo/results/xrce-typed-odometry-dev-1701-v10/odometry-body.bin",
           "/repo/results/xrce-typed-odometry-dev-1701-v10/graph-ready.txt"]
before = subprocess.run(["docker", "ps", "--format", "{{.Names}}"],
                        capture_output=True, text=True, timeout=10)
if before.returncode or before.stdout.strip():
    raise RuntimeError("competing container; no-Agent test refused")
run = subprocess.run(command, capture_output=True, text=True, errors="replace", timeout=12)
after = subprocess.run(["docker", "ps", "-a", "--filter",
                        "name=^/flydrones-xrce-no-agent-v2$", "--format", "{{.Names}}"],
                       capture_output=True, text=True, timeout=10)
record = {"command": command, "exit": run.returncode,
          "stdout": run.stdout, "stderr": run.stderr,
          "owned_after": after.stdout, "no_agent": True,
          "synthetic_only": True, "callback_verified": False,
          "px4_source_authenticated": False, "fusion_qualified": False}
output.write_text(json.dumps(record, indent=2), encoding="utf-8")
print(json.dumps({"exit": run.returncode, "owned_after": after.stdout.strip()}))
if run.returncode == 0 or after.returncode or after.stdout.strip():
    raise SystemExit(1)
