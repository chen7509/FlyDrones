"""One owned, offline build of the synthetic XRCE diagnostic client."""

from __future__ import annotations

import ctypes
import hashlib
import json
import subprocess
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
IMAGE = "sha256:a4dae62b38bc01a01d084be7b68db83ec804fef7673604e1a9c986a4baa88a6a"
SOURCE_WORK = "/tmp/flydrones-agent-humble-1701-v3"
DIAG_WORK = "/tmp/flydrones-xrce-typed-1701-v2"
REPO_WSL = "/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility"
MIN_FREE = int(1.5 * 1024**3)
AGENT_BUNDLE_SHA = "4279d999c02836e3f7076e948d2e92aefcc08bf62ea8c0e3e597dde2896c3262"
COLLECTOR_SHA = "31ad3958028660bf4ed468ddcbd25e7d5ca3e994b7729e4538ebe383a46ecf7f"
FROZEN_CDR_ZIP_SHA = "c651681d58013803c5ea7d15301a2ac39ca9526c275244c1839809fb3351ba4b"


class MemoryStatus(ctypes.Structure):
    _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]


def free_bytes() -> int:
    status = MemoryStatus()
    status.dwLength = ctypes.sizeof(status)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
        raise OSError("host physical memory query failed")
    return status.ullAvailPhys


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def call(args: list[str], timeout: int = 20) -> dict:
    result = subprocess.run(args, capture_output=True, text=True,
                            errors="replace", timeout=timeout)
    return {"args": args, "returncode": result.returncode,
            "stdout": result.stdout, "stderr": result.stderr}


def docker_phase(name: str, command: list[str], timeout: int) -> dict:
    container = f"flydrones-xrce-typed-{name}-v2"
    args = ["wsl", "-d", "Ubuntu", "--", "docker", "run", "--rm",
            "--name", container, "--network", "none", "--cpus", "1",
            "--memory", "512m", "--memory-swap", "512m", "--pids-limit", "64",
            "--mount", f"type=bind,src={SOURCE_WORK},dst=/work,readonly",
            "--mount", f"type=bind,src={DIAG_WORK},dst=/diag",
            "--mount", f"type=bind,src={REPO_WSL},dst=/repo,readonly",
            "-e", "CMAKE_BUILD_PARALLEL_LEVEL=1", "-e", "MAKEFLAGS=-j1",
            IMAGE, *command]
    started = time.time_ns()
    try:
        phase = call(args, timeout=timeout)
        timed_out = False
    except subprocess.TimeoutExpired as exc:
        phase = {"args": args, "returncode": 124,
                 "stdout": (exc.stdout or b"").decode("utf-8", errors="replace"),
                 "stderr": (exc.stderr or b"").decode("utf-8", errors="replace")}
        timed_out = True
    (HERE / f"{name}.stdout").write_text(phase["stdout"], encoding="utf-8")
    (HERE / f"{name}.stderr").write_text(phase["stderr"], encoding="utf-8")
    listed = call(["docker", "ps", "-a", "--filter", f"name=^/{container}$",
                   "--format", "{{.Names}}"], timeout=10)
    cleanup = call(["docker", "rm", "-f", container], timeout=10) if listed["stdout"].strip() else None
    after = call(["docker", "ps", "-a", "--filter", f"name=^/{container}$",
                  "--format", "{{.Names}}"], timeout=10)
    return {"args": args, "returncode": phase["returncode"],
            "started_unix_ns": started, "ended_unix_ns": time.time_ns(),
            "timeout": timed_out, "listed_after": listed,
            "cleanup": cleanup, "owned_after": after}


def main() -> None:
    preflight_path = HERE / "preflight.json"
    result_path = HERE / "build-result.json"
    if preflight_path.exists() or result_path.exists():
        raise FileExistsError("attempt already recorded")
    input_paths = {
        "agent_bundle": ROOT / "results/agent-humble-offline-build-dev-1701-v3/runtime-bundle.tar.gz",
        "collector": ROOT / "results/px4-ros2-full-build-attempt-dev-1701/workspace-v1/install/flydrones_px4_ros2_source/lib/flydrones_px4_ros2_source/px4_odometry_source",
        "client_c": ROOT / "tools/connectome/xrce_typed_probe/client.c",
        "cmake": ROOT / "tools/connectome/xrce_typed_probe/CMakeLists.txt",
        "frozen_cdr_zip": ROOT / "evidence/px4-ros2-synthetic-v6-parity-dev-1701.zip",
    }
    hashes = {name: sha(path) for name, path in input_paths.items()}
    docker = call(["docker", "ps", "--format", "{{.Names}}"])
    image = call(["docker", "image", "inspect", IMAGE, "--format", "{{.Id}}"])
    work_absent = call(["wsl", "-d", "Ubuntu", "--", "test", "!", "-e", DIAG_WORK])
    free = free_bytes()
    allowed = (free >= MIN_FREE and not docker["stdout"].strip()
               and docker["returncode"] == 0 and image["returncode"] == 0
               and image["stdout"].strip() == IMAGE and work_absent["returncode"] == 0
               and hashes["agent_bundle"] == AGENT_BUNDLE_SHA
               and hashes["collector"] == COLLECTOR_SHA
               and hashes["frozen_cdr_zip"] == FROZEN_CDR_ZIP_SHA)
    preflight = {"schema": "flydrones.xrce_typed_build_preflight.v1",
                 "host_available_bytes": free, "minimum_bytes": MIN_FREE,
                 "image": image, "docker": docker, "work_absent": work_absent,
                 "input_hashes": hashes, "qualified": allowed,
                 "physical_simulation_qualified": False}
    preflight_path.write_text(json.dumps(preflight, indent=2), encoding="utf-8")
    if not allowed:
        print(json.dumps({"status": "preflight_refused", "host_available_bytes": free}))
        return
    record = {"schema": "flydrones.xrce_typed_client_build.v1",
              "preflight_qualified": True, "owned_work": DIAG_WORK,
              "configure": None, "build": None, "success": False,
              "xrce_session_verified": False, "typed_callback_verified": False,
              "px4_source_authenticated": False, "fusion_qualified": False}
    try:
        created = call(["wsl", "-d", "Ubuntu", "--", "mkdir", DIAG_WORK])
        record["create_work"] = created
        if created["returncode"] != 0:
            raise RuntimeError("owned work creation failed")
        record["configure"] = docker_phase("configure", [
            "cmake", "-S", "/repo/tools/connectome/xrce_typed_probe", "-B", "/diag/build",
            "-G", "Unix Makefiles",
            "-DCMAKE_PREFIX_PATH=/work/build/temp_install/microxrcedds_client-2.4.3;"
            "/work/build/temp_install/microcdr-2.0.1"], 60)
        if record["configure"]["returncode"] == 0:
            record["build"] = docker_phase("build", [
                "cmake", "--build", "/diag/build", "--parallel", "1"], 120)
            record["success"] = record["build"]["returncode"] == 0
    except Exception as exc:
        record["error"] = repr(exc)
    finally:
        record["input_hashes_after"] = {name: sha(path) for name, path in input_paths.items()}
        record["docker_after"] = call(["docker", "ps", "--format", "{{.Names}}"])
        result_path.write_text(json.dumps(record, indent=2), encoding="utf-8")
    print(json.dumps({"success": record["success"],
                      "configure": record["configure"]["returncode"] if record["configure"] else None,
                      "build": record["build"]["returncode"] if record["build"] else None,
                      "error": record.get("error")}))


if __name__ == "__main__":
    main()
