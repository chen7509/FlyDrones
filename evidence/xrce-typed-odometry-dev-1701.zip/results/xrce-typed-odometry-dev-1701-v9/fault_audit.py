"""Verify the typed-link audit refuses independent evidence tampering."""

import json
import shutil
import sys
import tempfile
from pathlib import Path

here = Path(__file__).resolve().parent
root = here.parents[1]
sys.path.insert(0, str(root / "tools/connectome/xrce_typed_probe"))
from audit import audit  # noqa: E402

archive = root / "evidence/px4-ros2-synthetic-v6-parity-dev-1701.zip"
files = ("xrce-synthetic-v2.jsonl", "inside-result.json", "runtime-result.json",
         "runtime-preflight.json", "client.log", "agent.log",
         "graph-proof.json", "graph-ready.txt")
out = here / "fault-audit-result.json"
if out.exists():
    raise FileExistsError("fault audit already attempted")
results = []
with tempfile.TemporaryDirectory(prefix="flydrones-xrce-audit-") as temp:
    directory = Path(temp)
    for name in files:
        shutil.copyfile(here / name, directory / name)
    journal = directory / "xrce-synthetic-v2.jsonl"
    lines = journal.read_text(encoding="utf-8").splitlines()
    sample = json.loads(lines[0])
    sample["position_ned_m"][0] = 2.25
    journal.write_text(json.dumps(sample) + "\n" + lines[1] + "\n", encoding="utf-8")
    try:
        audit(directory, archive, "synthetic-xrce-v9", "rmw_fastrtps_cpp", True)
        results.append({"case": "mutated_field", "refused": False})
    except ValueError as exc:
        results.append({"case": "mutated_field", "refused": True, "reason": str(exc)})
    shutil.copyfile(here / "xrce-synthetic-v2.jsonl", journal)
    agent = directory / "agent.log"
    agent.write_text(agent.read_text(encoding="utf-8").replace(
        "0xF1D0D017", "0xDEADBEEF"), encoding="utf-8")
    try:
        audit(directory, archive, "synthetic-xrce-v9", "rmw_fastrtps_cpp", True)
        results.append({"case": "wrong_client_key", "refused": False})
    except ValueError as exc:
        results.append({"case": "wrong_client_key", "refused": True, "reason": str(exc)})
out.write_text(json.dumps(results, indent=2), encoding="utf-8")
print(json.dumps(results))
if not all(item["refused"] for item in results):
    raise SystemExit(1)
