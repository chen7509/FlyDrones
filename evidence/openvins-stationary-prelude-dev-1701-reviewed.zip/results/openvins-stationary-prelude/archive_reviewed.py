"""Build the non-overwriting reviewed evidence snapshot after guard fixes."""

import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
directory = root / "results/openvins-stationary-prelude"
prior = root / "evidence/openvins-stationary-prelude-dev-1701.zip"
archive = root / "evidence/openvins-stationary-prelude-dev-1701-reviewed.zip"
index = archive.with_suffix(".sha256.json")
if archive.exists() or index.exists():
    raise SystemExit("reviewed evidence archive or index already exists")
prior_sha = hashlib.sha256(prior.read_bytes()).hexdigest()
if prior_sha != "d382f637aea7197c5151243a61ef116df7c51d5d0cc1afc50e4b8eade76b004e":
    raise SystemExit("original evidence archive changed")
paths = sorted(path for path in directory.rglob("*") if path.is_file())
paths.extend(root / name for name in (
    "docs/OPENVINS_STATIONARY_PRELUDE_REPORT.md",
    "docs/superpowers/specs/2026-10-03-vio-stationary-prelude.md",
    "docs/superpowers/plans/2026-10-03-vio-stationary-prelude.md",
    "src/flydrones/distributed_stress.py",
    "tests/test_distributed_stress.py",
    "tests/benchmark/test_stationary_prelude.py",
    "tests/benchmark/test_stationary_prelude_audit.py",
    "tools/benchmark/run_episode.py",
    "tools/benchmark/audit_stationary_prelude.py",
    "tools/benchmark/prepare_openvins_offline.py",
    "tools/benchmark/analyze_openvins_trajectory.py",
    "tools/benchmark/audit_openvins_imu_init.py",
    "results/openvins-offline-1701/runner-v3/offline_probe",
    "results/openvins-offline-1701/runner-v3/offline_probe.cpp",
    "results/openvins-texture-dev/config-v2/estimator_config.yaml",
    "results/openvins-texture-dev/config-v2/kalibr_imu_chain.yaml",
    "results/openvins-texture-dev/config-v2/kalibr_imucam_chain.yaml",
    "results/openvins-clone-motion/instrumentation.patch",
    "results/openvins-clone-motion/instrument_clones.py",
    "results/openvins-clone-motion/metadata.json",
    "results/openvins-clone-motion/REPRODUCE.md",
))
paths = sorted(set(paths))
if not paths or any(not path.is_file() or path.is_symlink() or not path.resolve().is_relative_to(root)
                    for path in paths):
    raise SystemExit("missing or invalid reviewed archive input")
archive.parent.mkdir(parents=True, exist_ok=True)
manifest = {}
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED,
                     compresslevel=6, allowZip64=True) as bundle:
    for path in paths:
        relative = path.relative_to(root).as_posix()
        payload = path.read_bytes()
        manifest[relative] = {"bytes": len(payload),
                              "sha256": hashlib.sha256(payload).hexdigest()}
        bundle.writestr(relative, payload)
with archive.open("rb") as stream:
    archive_sha = hashlib.file_digest(stream, "sha256").hexdigest()
index.write_text(json.dumps({"schema": "flydrones-archive-index-v1",
                             "original_archive_sha256": prior_sha,
                             "archive_bytes": archive.stat().st_size,
                             "archive_sha256": archive_sha,
                             "files": manifest}, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps({"members": len(manifest), "archive_sha256": archive_sha,
                  "archive_bytes": archive.stat().st_size}))
