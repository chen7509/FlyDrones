"""Append logging-only camera clone pose export to the isolated OpenVINS checkout."""

from pathlib import Path
import sys


checkout = Path(sys.argv[1])
source = checkout / "ov_msckf/src/update/UpdaterMSCKF.cpp"
contents = source.read_text()
marker = "  // 3. Try to triangulate all MSCKF or new SLAM features that have measurements\n"
insertion = """  // Diagnostic only: export exactly the camera poses consumed by feature initialization.
  for (const auto &fd_feature : feature_vec) {
    for (const auto &fd_camera : fd_feature->timestamps) {
      for (const double fd_time : fd_camera.second) {
        auto &fd_pose = clones_cam.at(fd_camera.first).at(fd_time);
        const auto &fd_r = fd_pose.Rot();
        const auto &fd_p = fd_pose.pos();
        std::fprintf(stderr,
                     "FD_CLONE_POSE t=%.9f id=%zu cam=%zu obs_t=%.9f r00=%.12g r01=%.12g r02=%.12g r10=%.12g r11=%.12g r12=%.12g r20=%.12g r21=%.12g r22=%.12g p0=%.12g p1=%.12g p2=%.12g\\n",
                     state->_timestamp, fd_feature->featid, fd_camera.first, fd_time,
                     fd_r(0, 0), fd_r(0, 1), fd_r(0, 2),
                     fd_r(1, 0), fd_r(1, 1), fd_r(1, 2),
                     fd_r(2, 0), fd_r(2, 1), fd_r(2, 2),
                     fd_p(0), fd_p(1), fd_p(2));
      }
    }
  }

"""
if contents.count(marker) != 1 or "FD_CLONE_POSE" in contents:
    raise RuntimeError("unexpected instrumentation state or insertion point")
source.write_text(contents.replace(marker, insertion + marker))
