"""Seal both offline v13 attempts, preserving the first provenance failure."""

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
DEST = ROOT / "evidence/live-wire-logger-v13-preparation-dev-1701.zip"
SINGLES = (
    "docs/LIVE_WIRE_LOGGER_V13_PREPARATION_REPORT.md",
    "docs/LIVE_WIRE_LOGGER_STUDY_REPORT.md",
    "docs/superpowers/plans/2026-10-12-live-wire-logger-study.md",
    "results/live-wire-study-dev-1701/prepare-v13.py",
    "results/live-wire-study-dev-1701/audit-v13.py",
    "results/live-wire-study-dev-1701/audit-v13-retry.py",
    "results/live-wire-study-dev-1701/committed-source-v13.json",
    "results/live-wire-study-dev-1701/committed-source-v13-retry.json",
    "results/live-wire-study-dev-1701/seal-v13.py",
)


def selected():
    names = set(SINGLES)
    for folder in (HERE / "study-v13", HERE / "study-v13-retry"):
        for path in folder.rglob("*"):
            if path.is_symlink():
                raise ValueError("linked evidence input: " + str(path))
            if path.is_file():
                names.add(path.relative_to(ROOT).as_posix())
    return sorted(names)


def main():
    records = []
    with zipfile.ZipFile(DEST, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for name in selected():
            raw = (ROOT / name).read_bytes()
            archive.writestr(name, raw)
            records.append({"path": name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()})
        archive.writestr("MANIFEST.json", json.dumps({"schema": "stage-evidence-v1", "members": records},
                                                     sort_keys=True, indent=2) + "\n")
    with zipfile.ZipFile(DEST) as archive:
        if archive.testzip() is not None:
            raise ValueError("ZIP CRC failure")
        for record in records:
            if hashlib.sha256(archive.read(record["path"])).hexdigest() != record["sha256"]:
                raise ValueError("member digest failure: " + record["path"])
    print(f"{len(records)} members; SHA256 {hashlib.sha256(DEST.read_bytes()).hexdigest()}")


if __name__ == "__main__":
    main()
