"""Independent read-only checks of the prospective v3 preparation."""

import hashlib
import json
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / "src")]

from tools.benchmark.capture_contract import _typed_equal, read_declaration  # noqa: E402
from tools.benchmark.declared_runtime_snapshot import file_record, write_manifest  # noqa: E402
from tools.benchmark.execute_openvins_health_physical_run import prepare_live_wire_execution  # noqa: E402
from tools.benchmark.live_wire_study import validate_live_wire_study_files  # noqa: E402
from tools.benchmark.px4_logger_runtime import PROFILE_RELATIVE, profile_record  # noqa: E402

HERE = Path(__file__).resolve().parent
STUDY = HERE / "study-v13"
ARCHIVE = ROOT / "evidence/live-wire-agent-v12-preparation-dev-1701.zip"


def check():
    previous = read_declaration(HERE / "study-v12-retry2/preparation-result.json")
    current = read_declaration(STUDY / "preparation-result.json")
    version = read_declaration(HERE / "committed-source-v13.json")
    assert current["source_archive_sha256"] == hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()
    assert current["source_archive_sha256"] == "0b87812d0dca6c1dfbb01ffeb732046040c668ff8d3fd6e6438325fa8de2689f"
    with zipfile.ZipFile(ARCHIVE) as sealed:
        assert sealed.testzip() is None
        members = {row["path"]: row for row in json.loads(sealed.read("MANIFEST.json"))["members"]}
        for name, record in current["consumed_source"].items():
            if name.startswith("current_declared_"):
                continue
            raw = (ROOT / name).read_bytes()
            assert raw == sealed.read(name)
            assert hashlib.sha256(raw).hexdigest() == members[name]["sha256"] == record["sha256"]
    assert current["original_declared_files"] == previous["prepared_declared_files"] == 640
    assert current["producer_commit"] == version["head"]
    assert current["generator"]["sha256"] == version["preparer_sha256"]
    assert file_record(HERE / "prepare-v13.py") == current["generator"]
    for name, digest in version["source_sha256"].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
    manifest_path = STUDY / "study-manifest.json"
    manifest = read_declaration(manifest_path)
    result = validate_live_wire_study_files(manifest_path)
    assert result["files_verified"] is True
    assert manifest["schema"] == "live-wire-study-v3"
    assert manifest["simulation_seed"] == 27603
    assert manifest["live_activation_authorized"] is False
    assert manifest["producer_commit"] == version["head"]
    assert manifest["command"][-2:] == ["--logger-diagnostic-profile", "source-diagnostic-v1"]
    assert profile_record(ROOT / PROFILE_RELATIVE) == read_declaration(STUDY / "execution-contract.json")["logger_diagnostic"]
    prepared = prepare_live_wire_execution(manifest_path)
    assert _typed_equal(prepared, read_declaration(STUDY / "executor-binding.json"))
    for name in ("capture-v1", "dispatch.json", "completion.json", "audit.json", "physical-output.txt",
                 "activation-request.json"):
        assert not (STUDY / name).exists(), name
    negative = STUDY / "negative-cases"
    cases = read_declaration(STUDY / "preparation-result.json")["mutation_refusals"]
    for name in cases:
        try:
            validate_live_wire_study_files(negative / (name + ".json"))
        except ValueError:
            pass
        else:
            raise AssertionError("negative case accepted: " + name)
    audit = {
        "schema": "live-wire-v3-independent-preparation-audit-v1",
        "source_archive_crc_and_selected_bytes_verified": True,
        "committed_python_source_bytes_verified": True,
        "actual_v3_file_adapter_verified": True,
        "executor_binding_verified": True,
        "negative_cases_refused": len(cases),
        "no_activation_or_physical_outputs": True,
        "live_qualified": False,
        "fusion_qualified": False,
        "physical_run": False,
    }
    write_manifest(STUDY / "independent-audit.json", audit)
    print(json.dumps(audit, sort_keys=True))


if __name__ == "__main__":
    check()
