#!/usr/bin/env bash
set -u
set -o pipefail
source /opt/ros/humble/setup.bash
cd /work
export ROS_HOME=/work/ros-home
export HOME=/work/home
mkdir -p "$ROS_HOME" "$HOME"
printf '%s\n' 'colcon build --base-paths src --packages-select px4_msgs flydrones_px4_ros2_source --executor sequential --parallel-workers 1 --event-handlers console_direct+'
timeout --signal=TERM --kill-after=15s 2400s \
  colcon build --base-paths src --packages-select px4_msgs flydrones_px4_ros2_source \
  --executor sequential --parallel-workers 1 --event-handlers console_direct+
status=$?
printf '%s\n' "$status" > /work/colcon.exit
exit "$status"
