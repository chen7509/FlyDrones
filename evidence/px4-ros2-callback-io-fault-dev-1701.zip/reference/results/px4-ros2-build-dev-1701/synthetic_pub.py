"""Pinned-type synthetic VehicleOdometry publisher; not PX4 or EKF2."""
import time

import rclpy
from px4_msgs.msg import VehicleOdometry
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data


def main():
    rclpy.init()
    node = Node('flydrones_synthetic_odometry_source')
    publisher = node.create_publisher(
        VehicleOdometry, '/fmu/out/vehicle_odometry', qos_profile_sensor_data)
    try:
        for index in range(1, 121):
            message = VehicleOdometry()
            message.timestamp_sample = 1_000_000 + 50_000 * index
            message.timestamp = message.timestamp_sample + 1_000
            message.pose_frame = VehicleOdometry.POSE_FRAME_NED
            message.velocity_frame = VehicleOdometry.VELOCITY_FRAME_NED
            message.position = [0.01 * index, 0.0, -1.0]
            message.q = [1.0, 0.0, 0.0, 0.0]
            message.velocity = [0.2, 0.0, 0.0]
            message.angular_velocity = [0.0, 0.0, 0.0]
            message.position_variance = [0.01, 0.01, 0.01]
            message.orientation_variance = [0.001, 0.001, 0.001]
            message.velocity_variance = [0.02, 0.02, 0.02]
            message.reset_counter = 0
            message.quality = 0
            publisher.publish(message)
            time.sleep(0.05)
        print('synthetic_messages_published=120', flush=True)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
