#!/usr/bin/env bash
source /opt/ros/humble/setup.bash
source /old-build/install/setup.bash
set -u
export RMW_IMPLEMENTATION=rmw_cyclonedds_cpp
export ROS_DOMAIN_ID=221
export ROS_HOME=/run/ros-home
export ROS_LOG_DIR=/run/roslog
export HOME=/run/home
mkdir -p "$ROS_HOME" "$ROS_LOG_DIR" "$HOME"
binary=/old-build/install/flydrones_px4_ros2_source/lib/flydrones_px4_ros2_source/px4_odometry_source
timeout 20s env FAULT_MODE=partial_then_eio FAULT_TARGET=/run/source.jsonl \
  LD_PRELOAD=/fault-shim/libjournal_fault.so \
  "$binary" /run/source.jsonl callback-io-fault-1701 15 60 \
  > /run/subscriber.log 2>&1 &
subscriber=$!
sleep 0.7
timeout 20s python3 /old-build/synthetic_pub.py > /run/publisher.log 2>&1 &
publisher=$!
wait "$subscriber"
subscriber_exit=$?
wait "$publisher"
publisher_exit=$?
printf '%s\n' "$subscriber_exit" > /run/subscriber.exit
printf '%s\n' "$publisher_exit" > /run/publisher.exit
if [[ "$subscriber_exit" -ne 2 || "$publisher_exit" -ne 0 ]]; then exit 1; fi
