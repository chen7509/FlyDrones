"""Retain the failed profile and raw callback-fault evidence without overwrite."""

from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

repo = Path(__file__).resolve().parents[2]
run = Path(__file__).resolve().parent
archive_path = repo / "evidence/px4-ros2-callback-io-fault-dev-1701.zip"
if archive_path.exists():
    raise SystemExit(f"archive already exists: {archive_path}")

members: dict[str, bytes] = {}
for path in sorted(run.rglob("*")):
    if path.is_file():
        members[f"run/{path.relative_to(run).as_posix()}"] = path.read_bytes()
for relative in (
    "results/px4-ros2-exact-build-dev-1701/profile.json",
    "results/px4-ros2-exact-build-dev-1701/run-bounded.sh",
    "results/px4-ros2-exact-build-dev-1701/preflight-refusal.json",
    "results/px4-ros2-byte-bound-dev-1701/workspace-v3/build-source-profile.json",
    "results/px4-ros2-byte-bound-dev-1701/workspace-v3/build-source-profile.sha256",
    "results/px4-ros2-build-dev-1701/synthetic_pub.py",
    "results/px4-ros2-build-dev-1701/install/flydrones_px4_ros2_source/lib/flydrones_px4_ros2_source/px4_odometry_source",
    "results/px4-ros2-io-fault-dev-1701/journal_fault.c",
    "results/px4-ros2-io-fault-dev-1701/libjournal_fault.so",
    "src/flydrones/connectome_training/px4_ros2_source_journal.py",
    "tools/connectome/px4_ros2_source/px4_odometry_source.cpp",
    "docs/PX4_ROS2_CALLBACK_IO_FAULT_REPORT.md",
    "docs/superpowers/plans/2026-10-10-px4-ros2-source-journal.md",
):
    members[f"reference/{relative}"] = (repo / relative).read_bytes()

manifest = {
    "schema": "flydrones.px4_ros2_callback_io_fault_evidence.v1",
    "run_id": "px4-ros2-callback-io-fault-dev-1701",
    "predeclared_exit_expectation_met": False,
    "live_capture_eligible": False,
    "members": {
        name: {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}
        for name, data in sorted(members.items())
    },
}
members["MANIFEST.json"] = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
archive_path.parent.mkdir(parents=True, exist_ok=True)
with archive_path.open("xb") as stream, zipfile.ZipFile(
    stream, mode="w", compression=zipfile.ZIP_DEFLATED
) as archive:
    for name, data in sorted(members.items()):
        archive.writestr(name, data)

with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(members)
    retained = json.loads(archive.read("MANIFEST.json"))
    for name, record in retained["members"].items():
        data = archive.read(name)
        assert len(data) == record["bytes"]
        assert hashlib.sha256(data).hexdigest() == record["sha256"]

digest = hashlib.sha256(archive_path.read_bytes()).hexdigest()
(run / "archive.sha256").write_text(f"{digest}  {archive_path.name}\n", encoding="ascii")
print(json.dumps({"archive": str(archive_path), "sha256": digest, "members": len(members)}))
