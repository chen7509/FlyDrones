"""Audit the immutable synthetic ROS sample-write failure without reclassifying it."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from flydrones.connectome_training.px4_ros2_source_journal import audit_source_journal

root = Path(__file__).resolve().parent
repo = root.parents[1]
profile = json.loads((root / "profile.json").read_text(encoding="utf-8"))
preflight = json.loads((root / "preflight.json").read_text(encoding="utf-8"))


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert profile["schema"] == "flydrones.px4_ros2_callback_io_fault.v1"
assert preflight["profile_sha256"] == digest(root / "profile.json")
assert preflight["runner_sha256"] == digest(root / "run-bounded.sh")
assert profile["subscriber_sha256"] == digest(
    repo / "results/px4-ros2-build-dev-1701/install/flydrones_px4_ros2_source"
    "/lib/flydrones_px4_ros2_source/px4_odometry_source"
)
assert profile["publisher_sha256"] == digest(
    repo / "results/px4-ros2-build-dev-1701/synthetic_pub.py"
)
assert profile["shim_sha256"] == digest(
    repo / "results/px4-ros2-io-fault-dev-1701/libjournal_fault.so"
)

docker_exit = int((root / "docker.exit").read_text().strip())
subscriber_exit = int((root / "subscriber.exit").read_text().strip())
publisher_exit = int((root / "publisher.exit").read_text().strip())
assert docker_exit == 1
assert subscriber_exit == 1
assert publisher_exit == profile["expected_publisher_exit"] == 0
assert subscriber_exit != profile["expected_subscriber_exit"]
assert "synthetic_messages_published=120" in (root / "publisher.log").read_text()
assert "PX4 source journal failed" not in (root / "subscriber.log").read_text()

journal = (root / "source.jsonl").read_bytes()
assert journal.startswith(b'{"schema":"flydrones.px4_ros2_odometry_cdr.v1","kind":"sample"')
assert b'"journal_sequence":1' in journal
assert b'"rmw_reception_sequ{"schema"' in journal
assert b'"status":"failed","reason":"journal_error"}' in journal
assert journal.count(b"\n") == 1
try:
    audit_source_journal(root / "source.jsonl")
except ValueError as exc:
    assert str(exc) == "journal JSON invalid", str(exc)
else:
    raise AssertionError("partial sample and appended terminal unexpectedly audited")

result = {
    "schema": "flydrones.px4_ros2_callback_io_fault_audit.v1",
    "run_id": profile["run_id"],
    "predeclared_subscriber_exit": profile["expected_subscriber_exit"],
    "observed_subscriber_exit": subscriber_exit,
    "publisher_exit": publisher_exit,
    "harness_exit": docker_exit,
    "predeclared_exit_expectation_met": False,
    "typed_synthetic_publisher_sent": 120,
    "sample_journal_sha256": digest(root / "source.jsonl"),
    "sample_journal_bytes": len(journal),
    "journal_audit": "rejected_invalid_json_after_partial_sample_write",
    "product_failed_closed": True,
    "px4_authenticated": False,
    "live_capture_eligible": False,
}
print(json.dumps(result, indent=2, sort_keys=True))
