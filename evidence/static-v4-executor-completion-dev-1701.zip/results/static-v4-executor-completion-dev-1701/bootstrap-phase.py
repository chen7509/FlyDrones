import hashlib,json,subprocess
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def save(name,b):
    with (raw/name).open('xb') as stream:stream.write(b)
names=['ROADMAP.md','docs/TARGET_BEARING_STATIC_V4_EXECUTOR_COMPONENT_REPORT.md','docs/TARGET_BEARING_STATIC_V3_HARNESS_FAILURE_REPORT.md',
'docs/superpowers/plans/2026-10-15-loader-selected-path-production.md','docs/superpowers/specs/2026-10-15-loader-selected-path-production-design.md',
'results/static-v4-executor-production-dev-1701/NEXT_PHASE.md','results/static-v4-executor-production-dev-1701/executor-fix-pass.md',
'evidence/static-v4-executor-components-publication.json','evidence/flydrones-history-through-admitted-executor-dev-1701.json','evidence/flydrones-history-through-loader-path-research-dev-1701.json']
rows=[]
for name in names:
    data=(root/name).read_bytes();data.decode('utf8')
    if name.endswith('.json'):json.loads(data)
    rows.append(dict(path=name,bytes=len(data),sha256=sha(data),full_read=True))
save('preflight-read.json',json.dumps(rows,indent=2).encode())
files=subprocess.check_output(['git','ls-files','-z','src','tools','tests','configs']).split(b'\0')
save('product-before.json',json.dumps([dict(path=x.decode(),bytes=len(b:=(root/x.decode()).read_bytes()),sha256=sha(b)) for x in files if x],indent=2).encode())
old=(root/'results/static-v4-executor-production-dev-1701/initial-readonly.py').read_text(encoding='utf8')
old=old.replace("['windows_available','wsl_available','blocked','docker_exit','docker_running']", "['windows_available','wsl_available','docker_exit']")
old=old.replace('public.update(utc=', "public.update(classified_competitor_count=len(blocked),docker_running_empty=docker.returncode==0 and not docker.stdout.strip(),utc=")
save('initial-readonly.py',old.encode())
result=subprocess.run(['python',str(raw/'initial-readonly.py')],capture_output=True,timeout=65)
save('initial-readonly.stdout',result.stdout);save('initial-readonly.stderr',result.stderr);assert result.returncode==0
print(result.stdout.decode())
old_recorder=(root/'results/static-v4-executor-production-dev-1701/verify.py').read_text(encoding='utf8')
start=old_recorder.index('files=');end=old_recorder.index('\ndef pins()',start)
paths=['tools/benchmark/static_v4_identity.py','tools/benchmark/static_v4_bootstrap.py','tools/benchmark/static_v4_executor.py',
'tools/benchmark/static_v4_recipe.py','tests/benchmark/test_calibration_static_v4_executor.py',
'results/target-bearing-runtime-freeze-v4-dev-1701/run-static-preparation-v4.py',
'tools/benchmark/software_process_boundary.py','tests/benchmark/conftest.py','results/static-v4-executor-completion-dev-1701/verify.py']
save('verify.py',(old_recorder[:start]+'files='+repr(paths)+'\n'+old_recorder[end:]).encode())
save('progress.md',b'# SDD ledger - plan: docs/superpowers/plans/2026-10-15-loader-selected-path-production.md\nTask4 continuation at8f7a7102;Task5pending;publicpendingrefusals remain until completed/reviewed/sealed.\nRuling: user preservation and bounded specific testing override skill scratch deletion/fullsuite;consumed tests/native never run. Quiet heartbeat/no permission stages.\n')
