from pathlib import Path
path=Path('tools/benchmark/static_v4_identity.py')
text=path.read_text(encoding='utf8')
start=text.index('    def body(writer):',text.index('def observe('))
end=text.index('        value = dict(',start)
old=text[start:end]
begin=old[:old.index('        # Bootstrap the hash tool')].replace('def body(writer):','def operation(writer):')
middle=old[old.index('        if phase == "pre":'):old.index('        require(\n            tool_stat')]
replacement=begin+middle+'        return before, versions, after\n\n    def body(writer):\n        before, versions, after = with_hash_root(operation, writer)\n'
text=text[:start]+replacement+text[end:]
path.write_text(text,encoding='utf8',newline='\n')
