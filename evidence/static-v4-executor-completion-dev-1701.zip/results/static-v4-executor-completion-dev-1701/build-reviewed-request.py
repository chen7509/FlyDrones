from pathlib import Path
import hashlib,json
from tools.benchmark.static_v4_recipe import build_fixed_request
from tools.benchmark.static_v4_identity import encode_primitive
raw=Path('results/static-v4-executor-completion-dev-1701');r=build_fixed_request();b=encode_primitive(r)
check=json.loads((raw/'reviewfix-final-affected.json').read_bytes());assert check['exit']==0 and check['before']==check['after']
assert all(r['source_sha256'][row['path']]==row['sha256'] for row in check['after'] if row['path'] in r['source_sha256'])
for name,data in [('prospective-recipe-v2.frame',b),('prospective-recipe-v2.json',json.dumps(r,indent=2).encode()),('reviewed-recipe.frame',b)]:
 with (raw/name).open('xb') as f:f.write(data)
summary=dict(schema='reviewed-software-request-not-native-prepin-v4',bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),source_count=len(r['source_sha256']),coverage={k:len(v) for k,v in r['coverage'].items()},review='original C0/I5/M1 plus single executor fix pass;no second wholecode review',native_preidentity_observed=False,release_created=False,final146_sourcepins_match=True)
with (raw/'reviewed-recipe-summary.json').open('x') as f:json.dump(summary,f,indent=2)
print(json.dumps(summary))
