from pathlib import Path
p=Path('tools/benchmark/static_v4_identity.py');s=p.read_text().replace('        python_runtime=runtime,','        python_runtime=runtime,\n        observer_sys_path=list(sys.path),')
a=s.index('\ndef audit_sdk_admission_receipts(')
s=s[:a]+'''
def audit_sdk_invocation_facts(facts,recipe,*,initial):
    require(type(facts) is dict and set(facts)=={"environment","argv","cwd","executable","no_site","no_bytecode","sys_path"},"actual SDK invocation facts required")
    require(facts["environment"]==recipe["sdk_environment"],"actual SDK environment differs")
    root=recipe["source_root"]
    require(facts["argv"]==[root+"/tools/benchmark/static_v4_bootstrap.py","--admitted-once"] and facts["cwd"]==root and facts["executable"]=="/usr/bin/python3" and facts["no_site"] is True and facts["no_bytecode"] is True,"actual SDK startup invocation differs")
    paths=facts["sys_path"]
    require(type(paths) is list and all(type(path) is str and path.startswith("/") and ".." not in path.split("/") for path in paths),"actual SDK import path invalid")
    observed=recipe.get("metadata_observation",{}).get("observer_sys_path",[])
    expected=[root+"/tools/benchmark",root+"/src",root]+[p for p in observed if p!=root+"/tools/benchmark"]
    if initial:
        require(paths==expected,"actual SDK initial import path differs")
    else:
        allowed=recipe["metadata_observation"]["python_runtime"]["roots"]+[root,root+"/src",root+"/tools/benchmark"]
        require(all(any(path==base or (base!=root and path.startswith(base+"/")) for base in allowed) for path in paths),"actual SDK import search escaped pinned namespaces")
    return facts

'''+s[a:]
s=s.replace('def audit_sdk_admission_receipts(recipe, pre, claim, scope, marker, entered, preparation):\n    ticket', 'def audit_sdk_admission_receipts(recipe, pre, claim, scope, marker, entered, preparation):\n    audit_sdk_invocation_facts(scope["invocation"],recipe,initial=True)\n    ticket')
p.write_text(s)
p=Path('tools/benchmark/static_v4_bootstrap.py');s=p.read_text();a=s.index('\ndef actual_scope(')
s=s[:a]+'''
def current_sdk_invocation(recipe):
    facts=dict(environment=dict(os.environ),argv=list(sys.argv),cwd=os.getcwd(),executable=sys.executable,no_site=bool(sys.flags.no_site),no_bytecode=bool(sys.flags.dont_write_bytecode),sys_path=list(sys.path))
    return audit_sdk_invocation_facts(facts,recipe,initial="site" not in sys.modules)

'''+s[a:]
s=s.replace('def actual_scope(recipe):\n    require','def actual_scope(recipe):\n    invocation = current_sdk_invocation(recipe)\n    require')
s=s.replace('limits=limits, query=row\n    )','limits=limits, query=row, invocation=invocation\n    )')
s=s.replace('require(recipe["sdk_environment"] == expected_env, "SDK invocation environment differs")','require(recipe["sdk_environment"] == expected_env, "SDK invocation environment differs")\n    current_sdk_invocation(recipe)\n    audit_metadata_inventory(recipe)')
s=s.replace('    def body(writer):\n        return with_hash_root(lambda observed: [file_pin(path, emit=observed) for path in recipe["files"]], writer)','    def body(writer):\n        audit_metadata_inventory(recipe)\n        return with_hash_root(lambda observed: [file_pin(path, emit=observed) for path in recipe["files"]], writer)')
p.write_text(s)
# Extend explicit inert semantic fixture for new required role/facts; old raw unchanged.
p=Path('tests/benchmark/test_calibration_static_v4_executor.py');s=p.read_text();s=s.replace('"python-bytecode-inputs": [],','"python-bytecode-inputs": [],\n        "python-runtime-inputs": ["/usr/lib/python3.12/site.py"],')
s=s.replace('    prep = dict(sdk_ticket=copy.deepcopy(ticket), sdk_pid=99)','    scope["invocation"] = dict(environment=recipe["sdk_environment"],argv=[recipe["source_root"]+"/tools/benchmark/static_v4_bootstrap.py","--admitted-once"],cwd=recipe["source_root"],executable="/usr/bin/python3",no_site=True,no_bytecode=True,sys_path=[recipe["source_root"]+"/tools/benchmark",recipe["source_root"]+"/src",recipe["source_root"]])\n    prep = dict(sdk_ticket=copy.deepcopy(ticket), sdk_pid=99)')
s=s.replace('rows.append(dict(kind="file-hash-query", query=copy.deepcopy(q)))\n        rows.append(dict(kind="file-phase", phase=phase, edge="end"))','rows.append(dict(kind="file-hash-query", query=copy.deepcopy(q)))\n            if phase=="after":rows.append(dict(kind="final-input-observation",path=file["requested"],file=copy.deepcopy(file),error=None))\n        rows.append(dict(kind="file-phase", phase=phase, edge="end"))')
p.write_text(s)
