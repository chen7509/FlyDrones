from pathlib import Path
path=Path('tests/benchmark/test_calibration_static_v4_executor.py')
text=path.read_text(encoding='utf8')
start=text.index('    assert first == {path.name:',text.index('def test_primitive_observer_attempts_independent_bounded_failure_fallback'))
tail=text[start:]
text=text[:start]
at=text.index('\n\ndef test_claim_must_validate_before_any_sdk_marker_output')
text=text[:at]+'\n'+tail+text[at:]
at=text.index('    claim["nonce"] = "d" * 64',text.index('def test_claim_must_validate_before_any_sdk_marker_output'))
text=text[:at]+'    from types import SimpleNamespace\n    monkeypatch.setattr(p, "os", SimpleNamespace(getuid=lambda: 1000, getpid=lambda: 99))\n'+text[at:]
path.write_text(text,encoding='utf8',newline='\n')
