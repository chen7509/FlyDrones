# Independent full Task4 source and prospective recipe review

Review base: `8f7a7102aef6296be8b2e21161609df26ca32724`. Reviewed the current complete Task4 working source and prospective recipe v1, the Task4 production design/plan, prior partial component report, draft completion report, inert executor fixtures, and Task3 preparation/publication/finished-transport interfaces. This is the single new full-current-scope review, not reapproval of the old partial report. Original findings below are to remain unchanged through the authorized single executor fix pass.

**Result: Critical 0 / Important 5 / Minor 1. Task4 software is not ready to seal as complete until the Important findings are addressed. This review grants no native admission.**

Method: Windows source and retained JSON/frame data reads plus file hashing only. No project import, pytest, SDK/native/WSL/systemd/loader/metadata command, child dispatch, or consumed producer/observer execution. Historical bill bytes were read solely as retained evidence; their identity is not a current native prepin. Parent-reported 129-pass/Ruff evidence is not independently rerun or promoted to native acceptance here.

## Important findings

### I1 — Executable file size is incorrectly limited by the two-MiB stream cap

`tools/benchmark/static_v4_identity.py:656` and identical bootstrap line require every tool's descriptor size to be <= `CAP` before selecting the root-FD hashing branch. `CAP` is the two-MiB query-output cap. The reviewed request includes `/usr/bin/python3` in tools/version queries. The retained input bill explicitly records that executable as 8,020,928 bytes. Thus the intended unchanged interpreter cannot reach a successful `checked_query(['/usr/bin/python3', '--version'], ...)`: `tool_witness` refuses before the query. This makes the production preidentity lifecycle functionally incomplete even if all admission/release conditions pass. The root-FD branch streams the executable through sha256sum and does not need this in-memory data bound.

Fix direction: keep the primitive pure-byte bootstrap tool bound and hard output caps, but support larger regular tools in the held-root branch with complete descriptor/path/mutation checks. Add an inert >2-MiB executable descriptor case so the test represents the actual interpreter size rather than four-byte tools.

### I2 — Imported external Python source and installed bytecode have no native prepin

`static_v4_identity.py:1073-1096,1174-1181` collects the five distributions' metadata directories, startup files, and project bytecode; `:1139-1157` selects package runtime files only as selected shared libraries/resources. It never includes ordinary Python stdlib or distribution package `.py`/`.pyc` files. The actual prospective request has 918 seed files, zero native candidate `.py/.pyc` files, zero installed-package `.py/.pyc` files, and no `/usr/lib/python3.12/site.py`. The later materializer adds metadata rather than those code trees. Nevertheless `static_v4_bootstrap.py:2161-2166` imports site, runs site.main, then enters the late SDK pipeline, which imports standard and installed Python modules. Task3 `calibration_capture_pipeline_v4.py:1363-1374` records all loaded module origins and existing caches and adds them to `runtime:python-modules` at `:1401`.

This both violates the complete current input prepin-before-use contract and causes the finished receiver to reject the normal resulting baseline: `static_v4_identity.py:1681-1684` correctly refuses every newly seen outside-study file without an original prepin. For example site.py or json/__init__.py has no seed/materialized role but is ordinary late-import code. `-B` prevents new caches; it does not stop reading installed caches.

Fix direction: materialize bounded exact Python runtime/source/installed bytecode membership before admission, including startup dependencies and the SDK's actual installed code, without importing targets. Preserve the no-cache-regeneration rule and enforce that later module origins/caches are members of those native prepins. Add an inert realistic external Python origin/cache join case that traverses materialization, SDK admission, and finished receipts.

### I3 — The implemented namespace recheck is never called at admission or postidentity

`static_v4_identity.py:1261-1283` and the bootstrap copy define `audit_metadata_inventory`, but source search finds only those definitions. `static_v4_bootstrap.py:2128-2145` rehashes `recipe['files']` at each SDK gate without re-enumerating project bytecode or installed metadata/startup namespaces. Pre/post observe likewise hashes only the frozen membership. A new `.pth` file added to an already observed site root after initial collection leaves every existing pin unchanged, passes the preimport gate, and is consumed by the subsequent site.main. A newly added project cache can similarly change import selection without appearing in the prepin membership. The draft report's assertion that namespace changes refuse is therefore not implemented by the actual gate.

Fix direction: invoke and extend the current inventory recheck on the actual pre/post and preimport/revalidation paths before effects; ensure the startup search namespace itself is rederived, not only old files hashed. Retain refusal and first error without treating added files as newly authorized inputs. Test insertion of a .pth and project cache after materialization with inert enumeration.

### I4 — An early observer error skips the final input/source observation entirely

`static_v4_identity.py:1577-1601` and identical bootstrap code run before-file pins, expected-byte checks, versions, and after-file pins in one straight-line operation. A before-file/hash/writer/expected-byte exception exits that operation before `files_after` is attempted. `with_hash_root` finalizes only sha256sum, and `retain_observation` emits a terminal/fallback error; neither attempts the final file/source/context inventory or records its unavailability member by member. This is the same production failure-evidence requirement that the spec explicitly calls out: the final observation must still be attempted, with secondary failures retained and no successful closure claim. A failure halfway through the actual pre/post observation currently leaves partial events but no complete attempted final inventory.

Fix direction: separate initial failure from a bounded final-observation stage in finally, preserve partial per-file facts and explicit unavailable records, and keep the original exception primary over final observation/writer/fallback errors. Use inert early-file and writer failure cases that assert final observation was attempted, rather than only terminal/fallback output.

### I5 — SDK admission compares the declared environment, never the actual environment

`static_v4_bootstrap.py:2001-2014` compares recipe.sdk_environment with an expected dictionary, but `current_receipts`, `enter_sdk`, and `revalidate_sdk_reference` never join that dictionary to `os.environ` or the actual startup import path. The only actual environment check in `observer_boundary` is pytest detection. Therefore an in-scope launch with matching receipt files/PID/nonce/scope but an extra or changed environment variable can pass the primitive gate, despite the explicit exact argv/env/cwd admission contract. A changed HOME or additional Python startup environment is particularly relevant to site.main after the gate. The Windows command builder normally supplies env -i, but the SDK-side independent boundary is explicitly required to reject mismatched actual invocation facts rather than rely on coordinator declarations.

Fix direction: validate the actual admitted SDK environment and startup flags/path facts before writing SDK-start and before deferred imports, retaining actual facts in the admission receipts. Keep manager-control environment distinct. Add an inert changed/extra SDK environment case that refuses before marker/output/import effects.

## Minor finding

### M1 — Second-gate refusal is labeled unconsumed after native preidentity has consumed the revision

`static_v4_executor.py:145` sets state to `REFUSED_UNCONSUMED` when the second resource gate refuses. Native `prepare_identity` has already written the exclusive preidentity-attempt marker and set `self.consumed=True` at `:419`; finally then sets consumed=true. The saved completion consequently contains the contradictory pair state=REFUSED_UNCONSUMED / consumed=true. The inert second-gate fixture does not model the actual preidentity consumption. The conservative consumption behavior is correct; the state label is wrong and risks suggesting a retry after an actual observer command.

Fix direction: distinguish first unconsumed resource refusal from a consumed preidentity/second-gate refusal, and exercise the consumed backend case in the existing inert lifecycle protocol.

## Reviewed strengths and remaining evidence boundary

The Windows wrapper/API/default native methods gate pytest and literal cwd before their effects; a missing literal release still refuses production. Owned Popen recovery, timeout escalation, pipe closure, fresh matching Invocation/cgroup unit-stop restrictions, first-error retention and independent bounded persistence fallback are present in the source. Root-FD tool hashing retains raw helper queries and post identities; successful identity journal replay joins tool/file/output/membership/clock facts rather than trusting caller SHA labels. Bootstrap joins fixed claim/preidentity/start receipts and same SDK PID before late preparation; finished acquisition and read-only receipt revalidation are distinct. The literal parent remains source only per the reviewed evidence. No native outcome, Linux FD-exec, cross-host/atomic behavior, complete runtime study, physical readiness, or any qualification is inferred from these software properties.

Task5's independent full current Task3 graph/finished-transport audit is still required after a future admitted child exit; the coordinator deliberately ends at CHILD_ZERO_STATIC_AUDIT_PENDING. This is not treated as a native study acceptance claim. Linux root hash execution, actual current file/package membership and cost under the unchanged 30-second metadata/180-second SDK budgets remain unmeasured; no new probe is authorized by this review.

The byte-pinned review inventory is recorded in independent-review.json. The prospective frame is 232184 bytes/SHA256 87871c1215508cc356c885924a533a0115d57bd5b8306ef75d5839b2232703d5; its JSON representation has a separate size/SHA. The summary correctly refers to the frame rather than claiming its JSON serialization has that hash. The four production source hashes in the prospective request match the reviewed current files. Any fix requires a new prospective/reviewed request and source seal; it does not authorize replaying the old request or a consumed attempt.