from pathlib import Path
p=Path('tools/benchmark/static_v4_identity.py');s=p.read_text()
s=s.replace('require(before["mode"] & 0o170000 == 0o100000 and before["size"] <= CAP, "bounded tool required")','require(before["mode"] & 0o170000 == 0o100000 and 0 <= before["size"] < 2**63, "regular tool required")')
s=s.replace('        if root is None:\n            data = bytearray()','        if root is None:\n            require(before["size"] <= CAP, "bounded primitive bootstrap tool required")\n            data = bytearray()')
a=s.index('\ndef collect_installed_metadata(')
new='''
def collect_python_runtime(request):
    """Enumerate existing importable external bytes without importing them."""
    project = request["source_root"]
    paths = sorted(set(request["metadata_protocol"]["roots"] + [p for p in sys.path if p and p.startswith("/") and not (p == project or p.startswith(project + "/"))]))
    roots = []
    for path in sorted(paths, key=lambda p: (len(p), p)):
        strict_path(path)
        if not any(path.startswith(root + "/") for root in roots if os.path.isdir(root)):
            roots.append(path)
    files, trees, states = [], [], {}
    def fail(exc):
        raise exc
    for root in roots:
        directory = os.path.isdir(root)
        regular = os.path.isfile(root)
        states[root] = "directory" if directory else "file" if regular else "absent"
        if not directory:
            if regular:
                require(root.endswith(".zip"), "unrecognized Python search file")
                files.append(root)
            continue
        for folder, dirs, names in os.walk(root, onerror=fail, followlinks=False):
            dirs.sort();names.sort()
            require(len(dirs) + len(names) <= 4096 and len(trees) < 8192, "Python runtime namespace bound")
            for sub in dirs:
                require(os.lstat(folder + "/" + sub).st_mode & 0o170000 == 0o040000, "Python runtime directory link unsupported")
            metadata = any(part.endswith((".dist-info", ".egg-info")) for part in folder.split("/"))
            selected = [name for name in names if metadata or name.endswith((".py", ".pyc", ".pth", ".zip")) or ".so" in name or name.startswith(("LICENSE", "COPYING", "NOTICE"))]
            values = [strict_path(folder + "/" + name) for name in selected]
            files.extend(values)
            require(len(files) <= 8192, "complete Python runtime file bound")
            trees.append(dict(directory=folder, directories=list(dirs), files=values))
    return dict(roots=sorted(roots), states=states, directories=trees, files=sorted(set(files)))


def collect_startup_search(request):
    project=request["source_root"]
    paths=sorted(set(request["metadata_protocol"]["roots"] + [p for p in sys.path if p and p.startswith("/")] + [project,project+"/src"]))
    files=[]
    for directory in paths:
        strict_path(directory)
        if os.path.isdir(directory):
            for name in ("sitecustomize.py","usercustomize.py"):
                selected=directory.rstrip("/")+"/"+name
                if os.path.isfile(selected):files.append(strict_path(selected))
        elif os.path.isfile(directory) and directory.endswith(".zip"):
            files.append(directory)
    return dict(paths=paths,files=sorted(set(files)))

'''
s=s[:a]+new+s[a:]
a=s.index('    startup_search = []',s.index('def collect_installed_metadata'));b=s.index('    require(found ==',a)
s=s[:a]+'''    startup_search = collect_startup_search(request)
    startup.extend(startup_search["files"])
    runtime = collect_python_runtime(request)
'''+s[b:]
s=s.replace('            "python-bytecode-inputs": bytecode,','            "python-bytecode-inputs": bytecode,\n            "python-runtime-inputs": runtime["files"],')
s=s.replace('        startup_search=sorted(set(startup_search)),','        startup_search=startup_search,\n        python_runtime=runtime,')
s=s.replace('        "python-bytecode-inputs",\n    }','        "python-bytecode-inputs",\n        "python-runtime-inputs",\n    }')
s=s.replace('def audit_metadata_inventory(recipe):\n    observation = recipe["metadata_observation"]','def audit_metadata_inventory(recipe):\n    observation = recipe["metadata_observation"]\n    require(collect_python_runtime(recipe) == observation["python_runtime"], "current external Python runtime namespace changed")\n    require(collect_startup_search(recipe) == observation["startup_search"], "current Python startup search changed")')
# Failed observers must attempt final membership and every requested file independently.
a=s.index('    def operation(writer):',s.index('def observe('));b=s.index('\n    def body(writer):',a)
s=s[:a]+'''    def operation(writer):
        nonlocal recipe
        before,versions,after=[],[],[]
        primary=None
        def secondary(exc,label):
            nonlocal primary
            if primary is None:primary=exc
            else:primary.add_note(label+": "+repr(exc))
        def retained(row):
            try:writer(row)
            except BaseException as exc:secondary(exc,"final writer secondary")
        try:
            require(recipe["source_root"] == source_root() and os.getcwd() == source_root(), "actual native recipe cwd differs")
            if phase == "pre":
                recipe=materialize_recipe_request(recipe,writer)
                write_exclusive(fixed["recipe"],recipe)
            audit_metadata_inventory(recipe)
            writer(dict(kind="file-phase",phase="before",edge="begin"))
            for path in recipe["files"]:before.append(file_pin(path,emit=writer))
            writer(dict(kind="file-phase",phase="before",edge="end"))
            for row in before:
                if row["requested"] in recipe.get("expected_bytes",{}):
                    require({k:row[k] for k in ("bytes","sha256")} == recipe["expected_bytes"][row["requested"]],"fixed original/current input bytes differ")
            for argv in recipe["versions"]:
                q=checked_query(argv,{"PATH":"/usr/bin:/bin","LANG":"C.UTF-8"})
                versions.append(q);writer(dict(kind="version-query",query=q))
        except BaseException as exc:primary=exc
        finally:
            try:audit_metadata_inventory(recipe)
            except BaseException as exc:secondary(exc,"final namespace observation secondary")
            retained(dict(kind="file-phase",phase="after",edge="begin"))
            for path in recipe["files"]:
                value,error=None,None
                try:
                    value=file_pin(path,emit=writer);after.append(value)
                except BaseException as exc:
                    error=repr(exc);secondary(exc,"final input observation secondary")
                retained(dict(kind="final-input-observation",path=path,file=value,error=error))
            retained(dict(kind="file-phase",phase="after",edge="end"))
        if primary is not None:raise primary
        return before,versions,after
'''+s[b:]
s=s.replace('phase, seen, phases, versions, helpers, installed = None, [], [], [], [], []','phase, seen, phases, versions, helpers, installed, finals = None, [], [], [], [], [], []')
a=s.index('        if kind == "version-query":',s.index('def audit_identity_journal'))
s=s[:a]+'''        if kind == "final-input-observation":
            require(phase == "after" and not helpers and record["error"] is None and record["path"] in files and record["file"] == files[record["path"]], "final native input observation differs")
            finals.append(record["path"])
            continue
'''+s[a:]
s=s.replace('and versions == value["versions"]\n        and records[-1]', 'and versions == value["versions"]\n        and finals == recipe["files"]\n        and records[-1]')
p.write_text(s)
p=Path('tools/benchmark/static_v4_executor.py');s=p.read_text();s=s.replace('        if not admitted(second):\n            state["state"] = "REFUSED_UNCONSUMED"','        if not admitted(second):\n            state["state"] = "REFUSED_CONSUMED_PREIDENTITY" if getattr(backend,"consumed",False) is True else "REFUSED_UNCONSUMED"');p.write_text(s)
