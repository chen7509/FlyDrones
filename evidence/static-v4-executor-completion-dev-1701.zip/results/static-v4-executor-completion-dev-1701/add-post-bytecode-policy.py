from pathlib import Path
p=Path('tools/benchmark/static_v4_identity.py');s=p.read_text().replace('                "-S",\n                native_path(ROOT / "tools/benchmark/static_v4_identity.py"),','                "-S",\n                "-B",\n                native_path(ROOT / "tools/benchmark/static_v4_identity.py"),');p.write_text(s)
