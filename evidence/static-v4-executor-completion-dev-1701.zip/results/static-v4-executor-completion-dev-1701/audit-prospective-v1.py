from pathlib import Path
import hashlib,json
from tools.benchmark.static_v4_identity import decode_primitive
raw=Path('results/static-v4-executor-completion-dev-1701');b=(raw/'prospective-recipe-v1.frame').read_bytes();r=decode_primitive(b)
summary=dict(schema='prospective-windows-recipe-not-native-prepin-v4',bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),source_count=len(r['source_sha256']),coverage={k:len(v) for k,v in r['coverage'].items()},native_preidentity_observed=False,release_created=False,original_helper_summary_KeyError_retained=True)
with (raw/'prospective-recipe-v1-summary.json').open('x') as f:json.dump(summary,f,indent=2)
print(json.dumps(summary))
