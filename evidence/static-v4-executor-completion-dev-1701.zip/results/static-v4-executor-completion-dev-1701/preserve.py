import hashlib,json
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(n,v):
 with (raw/n).open('x',encoding='utf8') as f:json.dump(v,f,indent=2)
prior=json.loads((root/'results/static-v4-executor-production-dev-1701/historical-archives-postsoftware.json').read_bytes())['members']
prior.append(dict(path='evidence/static-v4-executor-components-dev-1701.zip',bytes=1405412,sha256='55d2101315cf87f9da4aaa082d9cfd653214d804129949656707dfa39916335c'))
assert len(prior)==293 and {r['path'] for r in prior}=={p.relative_to(root).as_posix() for p in (root/'evidence').glob('*.zip')}
for row in prior:
 h=hashlib.sha256();size=0
 with (root/row['path']).open('rb') as f:
  while block:=f.read(1048576):size+=len(block);h.update(block)
 assert size==row['bytes'] and h.hexdigest()==row['sha256'],row['path']
save('historical-archives-postsoftware.json',dict(members=prior,count=len(prior),bytes=sum(r['bytes'] for r in prior),scope='POSTsoftware preservation only;not native prepin'))
before=json.loads((raw/'product-before.json').read_bytes());changed=[]
for row in before:
 if sha((root/row['path']).read_bytes())!=row['sha256']:changed.append(row['path'])
assert set(changed)=={'tools/benchmark/static_v4_identity.py','tools/benchmark/static_v4_bootstrap.py','tools/benchmark/static_v4_executor.py','tests/benchmark/test_calibration_static_v4_executor.py'},changed
save('product-preservation-postsoftware.json',dict(count=len(before),changed=changed,all_other_old_product_byte_same=True,new_product=['tools/benchmark/static_v4_recipe.py']))
parent=root/'results/target-bearing-runtime-freeze-v4-dev-1701';members=sorted(p.relative_to(parent).as_posix() for p in parent.rglob('*') if p.is_file());assert members==['run-static-preparation-v4.py']
assert not (root/'results/target-bearing-physical-capture-dev-1701').exists()
assert not (root/'evidence/static-v4-executor-completion-release.frame').exists()
save('software-source-only-state.json',dict(v4_parent_exists=True,only_members=members,claim_firstfacts_marker_study_absent=True,actual_scope_or_sdk_command=False,v4_attempt_consumed=False,physical_attempt_absent=True,software_release_absent=True,scope='source-only observation;not dispatchgate or escaped closure proof'))
print(json.dumps(dict(old_zip_count=len(prior),old_zip_bytes=sum(r['bytes'] for r in prior),old_product_count=len(before),changed=changed)))
