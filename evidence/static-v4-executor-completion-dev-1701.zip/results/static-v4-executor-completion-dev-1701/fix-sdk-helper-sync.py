from pathlib import Path
p=Path('tools/benchmark/static_v4_bootstrap.py');s=p.read_text();a=s.index('\ndef production_recipe(');s=s[:a]+'''
def current_sdk_invocation(recipe):
    # Environment is checked before inspecting any other invocation field.
    require(dict(os.environ)==recipe["sdk_environment"],"actual SDK environment differs")
    facts=dict(environment=dict(os.environ),argv=list(sys.argv),cwd=os.getcwd(),executable=sys.executable,no_site=bool(sys.flags.no_site),no_bytecode=bool(sys.flags.dont_write_bytecode),sys_path=list(sys.path))
    return audit_sdk_invocation_facts(facts,recipe,initial="site" not in sys.modules)

'''+s[a:];p.write_text(s)
