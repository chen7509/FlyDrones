from pathlib import Path
import hashlib,json
from tools.benchmark.static_v4_recipe import build_fixed_request
from tools.benchmark.static_v4_identity import encode_primitive
raw=Path('results/static-v4-executor-completion-dev-1701')
r=build_fixed_request();b=encode_primitive(r)
for name,data in [('prospective-recipe-v1.frame',b),('prospective-recipe-v1.json',json.dumps(r,indent=2).encode())]:
 with (raw/name).open('xb') as f:f.write(data)
summary=dict(schema='prospective-windows-recipe-not-native-prepin-v4',bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),source_count=len(r['source_sha256']),coverage={k:len(v) for k,v in r['coverage_seed'].items()},native_preidentity_observed=False,release_created=False)
with (raw/'prospective-recipe-v1-summary.json').open('x') as f:json.dump(summary,f,indent=2)
print(json.dumps(summary))
