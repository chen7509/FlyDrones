"""Exercise only the frozen scoped launcher prefix with harmless Python."""

import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from tools.connectome.run_px4_status_firmware_build import build_scope_command

command = build_scope_command()[:-3] + [
    "/usr/bin/python3", "-c",
    "import json,os;print(json.dumps({k:os.environ.get(k) for k in "
    "['PATH','PX4_UXRCE_DDS_NS','GIT_CONFIG_VALUE_0','HOME']}))",
]
completed = subprocess.run(command, capture_output=True, text=True, timeout=20)
record = {"command": command, "exit": completed.returncode,
          "stdout": completed.stdout, "stderr_tail": completed.stderr[-600:]}
Path(__file__).with_suffix(".json").open("x", encoding="utf-8").write(
    json.dumps(record, indent=2) + "\n"
)
print(json.dumps({"exit": completed.returncode, "stdout": completed.stdout}))
