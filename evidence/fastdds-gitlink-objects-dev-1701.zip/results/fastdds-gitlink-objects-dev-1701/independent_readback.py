"""Independently re-read fixed parent/child Git stores and v1 manifest."""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent / "px4-agent-dependency-objects-dev-1701" / "fast_dds.git"
CHILDREN = {
    "android_ifaddrs": "thirdparty/android-ifaddrs",
    "asio": "thirdparty/asio",
    "fastcdr_gitlink": "thirdparty/fastcdr",
    "tinyxml2": "thirdparty/tinyxml2",
}
ENV = {**os.environ, "GIT_NO_REPLACE_OBJECTS": "1"}


def git(repo: Path, *args: str) -> bytes:
    return subprocess.check_output(
        ["git", "-C", str(repo), *args], env=ENV, stderr=subprocess.PIPE,
    )


def main() -> None:
    manifest = json.loads((HERE / "source-manifest-v2.json").read_text(encoding="utf-8"))
    assert set(manifest["children"]) == set(CHILDREN)
    parent = manifest["parent"]
    assert git(PARENT, "rev-parse", "refs/flydrones/pins/source").decode().strip() == parent["parent_commit"]
    assert git(PARENT, "rev-parse", "FETCH_HEAD").decode().strip() == parent["parent_commit"]
    assert git(PARENT, "rev-parse", f"{parent['parent_commit']}^{{tree}}").decode().strip() == parent["parent_tree"]
    parent_entries = {}
    for row in git(PARENT, "ls-tree", "-rz", "--full-tree", parent["parent_commit"]).split(b"\0"):
        if row:
            meta, path = row.split(b"\t", 1)
            parent_entries[path.decode()] = meta.split()
    modules_oid = parent_entries[".gitmodules"][2].decode()
    modules = git(PARENT, "cat-file", "blob", modules_oid)
    assert hashlib.sha256(modules).hexdigest() == parent["gitmodules_sha256"]
    assert modules_oid == parent["gitmodules_blob"]
    report = {}
    for name, parent_path in CHILDREN.items():
        repo = HERE / f"{name}.git"
        row = manifest["children"][name]
        oid = parent["links"][parent_path]["commit"]
        assert row["commit"] == oid
        assert parent_entries[parent_path] == [b"160000", b"commit", oid.encode()]
        assert parent["links"][parent_path]["url"].encode() in modules
        assert git(repo, "rev-parse", "refs/flydrones/pins/source").decode().strip() == oid
        assert git(repo, "rev-parse", "FETCH_HEAD").decode().strip() == oid
        assert git(repo, "cat-file", "-t", oid).strip() == b"commit"
        tree = git(repo, "rev-parse", f"{oid}^{{tree}}").decode().strip()
        assert tree == row["tree"]
        entries = {}
        for item in git(repo, "ls-tree", "-rz", "--full-tree", oid).split(b"\0"):
            if item:
                meta, path = item.split(b"\t", 1)
                entries[path.decode()] = meta.split()
        assert len(entries) == row["tree_entry_count"]
        license_sources = []
        for source in row["license_sources"]:
            path = source["path"]
            mode, kind, blob = entries[path]
            assert mode in (b"100644", b"100755") and kind == b"blob"
            raw = git(repo, "cat-file", "blob", blob.decode())
            assert blob.decode() == source["git_blob"]
            assert hashlib.sha256(raw).hexdigest() == source["sha256"]
            assert len(raw) == source["bytes"]
            license_sources.append({"path": path, "sha256": source["sha256"]})
        gitlinks = [path for path, (mode, kind, _) in entries.items()
                    if (mode, kind) == (b"160000", b"commit")]
        assert sorted(gitlinks) == [entry["path"] for entry in row["nested_gitlinks"]]
        fsck = subprocess.run(["git", "-C", str(repo), "fsck", "--full", "--no-reflogs"],
                              env=ENV, capture_output=True)
        assert fsck.returncode == 0, (name, fsck.stderr.decode(errors="replace"))
        object_files = sorted(p for p in (repo / "objects").rglob("*") if p.is_file())
        assert object_files
        report[name] = {
            "commit": oid, "tree": tree, "entries": len(entries),
            "license_sources": license_sources, "nested_gitlinks": gitlinks,
            "fsck_exit": fsck.returncode,
            "object_storage_sha256": {
                p.relative_to(repo).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in object_files
            },
        }
    print(json.dumps({
        "schema": "flydrones.fastdds_gitlink_readback.v1",
        "all_four_local_objects_readback": True,
        "build_selection_verified": False,
        "transitive_source_closure_verified": False,
        "agent_binary_built_or_run": False,
        "children": report,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
