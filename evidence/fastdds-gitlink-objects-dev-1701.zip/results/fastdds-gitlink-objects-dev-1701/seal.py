"""Seal four exact Git stores, provenance reports and retained failures."""

from __future__ import annotations

import hashlib
import json
import zipfile
import zlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OUTPUT = ROOT / "evidence/fastdds-gitlink-objects-dev-1701.zip"
SOURCE_FILES = [
    ROOT / "docs/FAST_DDS_GITLINK_OBJECTS_REPORT.md",
    ROOT / "docs/superpowers/specs/2026-10-10-fastdds-gitlink-objects-design.md",
    ROOT / "docs/superpowers/plans/2026-10-10-fastdds-gitlink-objects.md",
    ROOT / "tools/connectome/audit_fastdds_gitlink_objects.py",
    ROOT / "tests/connectome_training/test_fastdds_gitlink_objects.py",
]
SOURCE_FILES.extend(path for path in HERE.rglob("*")
                    if path.is_file() and not path.name.endswith(".lock")
                    and path.name != "seal.py")
SOURCE_FILES.append(Path(__file__))


def main() -> None:
    if OUTPUT.exists():
        raise FileExistsError(OUTPUT)
    if not all(path.is_file() for path in SOURCE_FILES):
        raise ValueError("evidence input missing")
    names = [path.relative_to(ROOT).as_posix() for path in SOURCE_FILES]
    if len(names) != len(set(names)):
        raise ValueError("duplicate evidence member")
    manifest = {}
    with zipfile.ZipFile(OUTPUT, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for path, name in sorted(zip(SOURCE_FILES, names), key=lambda item: item[1]):
            data = path.read_bytes()
            manifest[name] = {
                "sha256": hashlib.sha256(data).hexdigest(),
                "crc32": format(zlib.crc32(data) & 0xFFFFFFFF, "08x"),
                "bytes": len(data),
            }
            archive.writestr(name, data)
        archive.writestr("MANIFEST.json", json.dumps({"members": manifest}, sort_keys=True))
    with zipfile.ZipFile(OUTPUT) as archive:
        saved = json.loads(archive.read("MANIFEST.json"))["members"]
        assert set(archive.namelist()) == set(saved) | {"MANIFEST.json"}
        for name, info in saved.items():
            data = archive.read(name)
            assert hashlib.sha256(data).hexdigest() == info["sha256"]
            assert format(zlib.crc32(data) & 0xFFFFFFFF, "08x") == info["crc32"]
            assert len(data) == info["bytes"]
    print(json.dumps({"archive": str(OUTPUT), "members": len(manifest),
                      "sha256": hashlib.sha256(OUTPUT.read_bytes()).hexdigest()}, sort_keys=True))


if __name__ == "__main__":
    main()
