import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility')
sys.path[:0] = [str(ROOT), str(ROOT / 'src')]
from tools.benchmark.capture_disarmed_sensors import active_resources

base = ROOT / 'results/estimator-physical-refusal-diagnosis-dev-1701'
study = base / 'study-v9'
destination = study / 'capture-v1'
dispatch_path = base / 'physical-run-v4-dispatch.json'
completion_path = base / 'physical-run-v4-completion.json'
output_path = base / 'physical-run-v4-output.txt'
head = (base / 'current-head-for-physical-v4.txt').read_text(encoding='utf-8').strip()
manifest = json.loads((study / 'study-manifest.json').read_text(encoding='utf-8'))
prepare_audit = json.loads((base / 'study-v9-audit-v2.json').read_text(encoding='utf-8'))
startup_audit = json.loads((base / 'startup-preflight-v3-audit.json').read_text(encoding='utf-8'))
command = manifest['command']
expected = destination.as_posix()
if head != 'a15f43c':
    raise SystemExit(f'unexpected committed head: {head}')
if destination.exists():
    raise SystemExit(f'refusing existing destination: {destination}')
if dispatch_path.exists() or completion_path.exists() or output_path.exists():
    raise SystemExit('refusing to overwrite physical-run-v4 evidence')
if prepare_audit.get('failures') or prepare_audit.get('prepare_qualified') is not True:
    raise SystemExit('prepare-only audit not qualified')
if startup_audit.get('failures') or startup_audit.get('startup_preflight_qualified') is not True:
    raise SystemExit('startup preflight not qualified')
if manifest.get('future_destination') != expected or command[command.index('--output') + 1] != expected:
    raise SystemExit('destination mismatch')
resources_before = active_resources()
if resources_before:
    raise SystemExit(f'active resources before dispatch: {resources_before!r}')
dispatch = {
    'schema': 'estimator-physical-run-dispatch-v2',
    'study': study.as_posix(),
    'destination': expected,
    'command': command,
    'head': head,
    'prepare_audit': (base / 'study-v9-audit-v2.json').as_posix(),
    'startup_audit': (base / 'startup-preflight-v3-audit.json').as_posix(),
    'resources_before': resources_before,
    'single_actual_attempt': True,
    'physical_run': True,
    'started_wall_ns': time.time_ns(),
}
dispatch_path.write_text(json.dumps(dispatch, indent=2, sort_keys=True) + '\n', encoding='utf-8')
with output_path.open('wb') as stream:
    completed = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, check=False)
resources_after = active_resources()
completion = {
    'schema': 'estimator-physical-run-completion-v2',
    'returncode': completed.returncode,
    'destination': expected,
    'destination_exists': destination.exists(),
    'resources_after': resources_after,
    'ended_wall_ns': time.time_ns(),
    'physical_run': True,
}
completion_path.write_text(json.dumps(completion, indent=2, sort_keys=True) + '\n', encoding='utf-8')
print(json.dumps(completion, indent=2, sort_keys=True))
raise SystemExit(completed.returncode)
