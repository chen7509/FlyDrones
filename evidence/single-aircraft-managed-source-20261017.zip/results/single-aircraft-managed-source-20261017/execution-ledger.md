# SDD ledger — plan: docs/superpowers/plans/2026-10-17-managed-capture-source.md

Base db4bc80de4974c88baae5590311675561b405350, tracked clean at entry, same authorized worktree/branch/personalPR65. Goal remains blocked/read-only; no resource queries or target-native runs. Full-history reads already completed in preceding phase of this continuous conversation; constraints carried forward, not falsely claimed a new scan.

Using brainstorming/writing-plans/executing-plans/TDD. User explicitly directs production software continuation without staged approvals. Ruling: build calibration→managed state→single existing receiver-only owner together; no new independent socket, no fake covariance/quality/clock. Cost if wrong: weak source may otherwise enter a live controller. All flight/fusion authority stays closed.

Ruling: existing native helper rejects nonzero camera/IMU offsets. Preserve it and reject unsupported managed launch before Popen, rather than relabel samples or silently loosen the consumer. Actual offset-aware native implementation/build/measurement remains a hard dependency. Cost: nonzero measured artifacts cannot yet start this version.

Ruling: read-only receiver stage proves configured external fusion disabled (EKF2_EV_CTRL=0), sends quality0 and unknown covariance only for observation. It is not actual fusion; enabling fusion still requires real measured/health/source evidence and actual EKF2/ULog signals. No parameter writes/ARM/control. Cost: this stage cannot complete the user's full flight/fusion validation.

Ruling: scope software verification to new source and necessarily affected neighbors, with native/process/network test guards. Preserve sealed old report/raw/ZIP and all CONSUMED/UNKNOWN; no old native tests/probes. No independent archive re-audit as progress.


Implementation correction to the earlier planning sentence "sends quality0": that was conditional on truthful reset representation. The actual delta sends ONLY PARAM_REQUEST_READ; no ODOMETRY, covariance or quality/reset is manufactured. The native reset-null fact blocks publication. This is not actual EKF2 fusion.

ONE14pin review C0/I2/M0; one bounded fix for total admission deadline and atomic snapshot, original grades and reports unchanged. Two true software RED1.05s after retained v3 setup failure. Final155pass6.87s/no warning,21new+134necessary, ordinary host files/math/codec and injected processes/sockets. Actual native3old files remain unmodified; no source authentication/runtime qualification. No second review/delivery audit. All10 declined judgments ruled individually with costs.
