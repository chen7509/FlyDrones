"""Production calibration/source consumption with synthetic measurement artifacts."""

import hashlib
import json
import os
import socket
import subprocess
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest


@pytest.fixture(autouse=True)
def inert(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("native process/network forbidden")
    monkeypatch.setattr(subprocess, "Popen", forbidden)
    monkeypatch.setattr(socket, "socket", forbidden)
    monkeypatch.setattr(os, "system", forbidden)


def write(path, value):
    data = json.dumps(value).encode()
    path.write_bytes(data)
    return hashlib.sha256(data).hexdigest()


def calibration(tmp_path):
    from flydrones.benchmark.px4_camera_source import CameraRigBinding
    from flydrones.benchmark.kalibr_camera_consumption import KalibrCameraArtifact, RAW_IMU_CONTRACT

    rig = CameraRigBinding("a" * 64, "body", "camera", "simulation-candidate", 160, 120,
                           (100., 0., 80., 0., 100., 60., 0., 0., 1.),
                           ((1., 0., 0.), (0., 1., 0.), (0., 0., 1.)), (0., 0., 0.), ())
    transform = [[0., -1., 0., 1.], [1., 0., 0., 2.], [0., 0., 1., 3.], [0., 0., 0., 1.]]
    chain = {"cam0":dict(camera_model="pinhole", distortion_model="radtan", resolution=[160,120],
                          intrinsics=[100.,100.,80.,60.], distortion_coeffs=[0.,0.,0.,0.],
                          T_cam_imu=transform, timeshift_cam_imu=0.)}
    ch = write(tmp_path / "camchain.yaml", chain)
    (tmp_path / "result.txt").write_bytes(b"synthetic, not measured")
    doc = dict(schema="flydrones-kalibr-artifact-binding-v1", rig_sha256=rig.sha256,
               body_id="body", camera_id="camera", imu_contract=RAW_IMU_CONTRACT, camera_key="cam0",
               camchain=dict(path="camchain.yaml",sha256=ch),
               results=dict(path="result.txt",sha256=hashlib.sha256(b"synthetic, not measured").hexdigest()))
    digest = write(tmp_path / "artifact.json",doc)
    artifact = KalibrCameraArtifact.load(tmp_path / "artifact.json",digest,rig,imu_contract=RAW_IMU_CONTRACT)
    return artifact, rig, digest


def test_raw_imu_artifact_is_explicit_and_cannot_cross_px4_consumer(tmp_path):
    from flydrones.benchmark.kalibr_camera_consumption import KalibrCameraArtifact
    artifact, rig, digest = calibration(tmp_path)
    with pytest.raises(ValueError,match="contract"):
        KalibrCameraArtifact.load(tmp_path / "artifact.json",digest,rig)
    assert artifact.record()["camera_calibration_qualified"] is False


def test_actual_managed_pose_uses_artifact_inverse_and_native_body_velocity(tmp_path):
    from tools.benchmark.managed_capture_source import ManagedCaptureSource
    artifact, rig, digest = calibration(tmp_path)
    clock = [1_000_000_000]
    process = SimpleNamespace(pid=421, poll=lambda:None)
    source = ManagedCaptureSource(artifact,now=lambda:clock[0])
    source.attach_native(process)
    camera = dict(sample_ns=100_000_000, acknowledged_ns=clock[0], state_time_s=.1,
                  internal_initialized=True, public_initialized=True,
                  imu_state=[0.,0.,0.,1.,10.,20.,30.,0.,0.,0.,0.,0.,0.,0.,0.,0.],
                  reset_counter=None, fusion_eligible=False, quality=None)
    source.accept_camera(camera, process)
    fast = dict(target_ns=120_000_000,success=True,public_initialized=True,internal_initialized=True,
                last_camera_ns=100_000_000, camera_imu_offset_s=0., reset_counter=None,
                state13=[0.,0.,0.,1.,11.,22.,33.,1.,2.,3.,0.,0.,.5])
    source.accept_fast(fast,dict(acknowledged_ns=clock[0]), process)
    view = source.diagnostic_snapshot(120_000_000,100_000_000)
    # T_cam_imu inverse translation is (-2,+1,-3), independently derived.
    assert view["camera_pose"][:3] == pytest.approx([8.,21.,27.])
    assert view["position"] == pytest.approx([11.,22.,33.])
    assert view["velocity"] == pytest.approx([1.,2.,3.])
    assert view["yaw_rate"] == pytest.approx(.5)
    assert view["reset_counter"] is None
    with pytest.raises(RuntimeError,match="qualified"):
        source.require_ready(120_000_000)


def test_native_process_change_latches_source_and_blocks_following_updates(tmp_path):
    from tools.benchmark.managed_capture_source import ManagedCaptureSource
    artifact, rig, digest = calibration(tmp_path)
    p=SimpleNamespace(pid=421,poll=lambda:None)
    source=ManagedCaptureSource(artifact,now=lambda:1_000_000_000)
    source.attach_native(p)
    p.pid=422
    with pytest.raises(ValueError,match="process"):
        source.accept_camera({},p)
    p.pid=421
    with pytest.raises(ValueError,match="latched"):
        source.accept_camera({},p)


def test_cli_rejects_managed_source_without_sole_wire_owner(tmp_path):
    from tools.benchmark.capture_disarmed_sensors import parse_capture_args
    argv = ["--output", str(tmp_path), "--online-estimate-feed", "--shadow-binary", "native",
            "--shadow-config", "estimator_config.yaml", "--execution-contract", "execution.json",
            "--runtime-binding", "binding.json", "--managed-source-config", "managed.json",
            "--managed-source-sha256", "a"*64]
    with pytest.raises(SystemExit):
        parse_capture_args(argv)
    args = parse_capture_args(argv + ["--wire-config", "wire.json"])
    from tools.benchmark.capture_contract import worker_options
    options = worker_options(args)
    assert options[options.index("--managed-source-sha256")+1] == "a"*64
    assert Path(options[options.index("--managed-source-config")+1]).name == "managed.json"


def test_factory_uses_managed_client_and_concrete_owner(tmp_path, monkeypatch):
    from tools.benchmark import managed_capture_source as managed
    from tools.benchmark.capture_disarmed_sensors import make_capture_native_client
    artifact, _, _ = calibration(tmp_path)
    monkeypatch.setattr(managed, "load_managed_configuration", lambda *args: (artifact, ()))
    captured = {}
    def construct(self, command, output, *, source, **kwargs):
        captured.update(command=command, source=source)
        self.managed_source = source
    monkeypatch.setattr(managed.ManagedEstimateNativeClient, "__init__", construct)
    args = SimpleNamespace(online_estimate_feed=True, managed_source_config=tmp_path/"managed.json",
                           managed_source_sha256="a"*64, shadow_binary=tmp_path/"native",
                           shadow_config=tmp_path/"config.yaml")
    client = make_capture_native_client(args, tmp_path, on_first_ack=None)
    assert type(client) is managed.ManagedEstimateNativeClient
    assert type(captured["source"]) is managed.ManagedCaptureSource


def test_managed_client_does_not_publish_parent_deadline_failure(tmp_path, monkeypatch):
    from tools.benchmark.managed_capture_source import ManagedCaptureSource, ManagedEstimateNativeClient
    from tools.benchmark.capture_online_estimates import LiveEstimateNativeClient
    artifact, _, _ = calibration(tmp_path)
    source = ManagedCaptureSource(artifact)
    client = object.__new__(ManagedEstimateNativeClient)
    client.managed_source = source
    client._pending_events = None
    client._feed_failure = client.failed = None
    def failed(self, action, pixels=None):
        self._pending_events.append(("camera_state", {"ack": {}}))
        raise TimeoutError("parent deadline")
    monkeypatch.setattr(LiveEstimateNativeClient, "send", failed)
    with pytest.raises(TimeoutError, match="parent deadline"):
        client.send({})
    assert source._last_camera == -1
    assert client.failed
