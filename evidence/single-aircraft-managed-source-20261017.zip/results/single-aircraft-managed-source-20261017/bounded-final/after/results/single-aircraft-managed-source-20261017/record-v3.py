"""Prospective software-only command recorder; retained fixtures, no native grant."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
if os.name == "nt":
    ROOT = Path("\\\\?\\" + str(ROOT))
    OUT = Path("\\\\?\\" + str(OUT))
SOURCES = ('src/flydrones/benchmark/kalibr_camera_consumption.py', 'src/flydrones/benchmark/px4_camera_source.py', 'tools/benchmark/capture_contract.py', 'tools/benchmark/capture_disarmed_sensors.py', 'tools/benchmark/capture_wire_lifecycle.py', 'tools/benchmark/openvins_observed_wire_session.py', 'tools/benchmark/managed_capture_source.py', 'tools/benchmark/disarmed_estimate_receiver.py', 'tests/benchmark/test_managed_capture_source.py', 'tests/benchmark/test_disarmed_estimate_receiver.py', 'tests/benchmark/managed_capture_software_plugin.py', 'docs/superpowers/specs/2026-10-17-managed-capture-source-design.md', 'docs/superpowers/plans/2026-10-17-managed-capture-source.md', 'docs/SINGLE_AIRCRAFT_MANAGED_SOURCE_PROGRESS.md', 'results/single-aircraft-managed-source-20261017/record.py', 'results/single-aircraft-managed-source-20261017/record-v2.py', 'results/single-aircraft-managed-source-20261017/record-v3.py', 'results/single-aircraft-managed-source-20261017/prepare_software_codec.py', 'results/single-aircraft-managed-source-20261017/software-deps/pymavlink/dialects/v20/common.py', 'tools/benchmark/openvins_online_shadow.py', 'tools/benchmark/openvins_online_probe.cpp', 'tools/benchmark/openvins_fast_probe.h')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def snapshot(destination):
    destination.mkdir()
    records = {}
    for name in SOURCES:
        path = ROOT / name
        if not path.is_file():
            records[name] = None
            continue
        data = path.read_bytes()
        target = destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        records[name] = {"bytes": len(data), "sha256": sha(data)}
    return records


label, *arguments = sys.argv[1:]
if arguments[:1] == ["--"]:
    arguments = arguments[1:]
run = OUT / label
run.mkdir(exist_ok=False)
pytest_run = arguments[:2] == ["-m", "pytest"]
if pytest_run:
    fixtures = run / "fixtures"
    spelling = str(fixtures.resolve())
    if os.name == "nt":
        spelling = "\\\\?\\" + spelling
    arguments.append("--basetemp=" + spelling)
argv = [sys.executable, *arguments]
env = os.environ.copy()
env.update(PYTHONPATH=os.pathsep.join((str(ROOT / "src"), str(OUT / "software-deps"))), PYTEST_DISABLE_PLUGIN_AUTOLOAD="1", PYTHONDONTWRITEBYTECODE="1")
record = {
    "argv": argv, "cwd": str(ROOT), "utc_start": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "declared_env": {key: env[key] for key in ("PYTHONPATH", "PYTEST_DISABLE_PLUGIN_AUTOLOAD", "PYTHONDONTWRITEBYTECODE")},
    "source_before": snapshot(run / "before"), "recorder_sha256": sha(Path(__file__).read_bytes()),
    "scope": "ordinary software subprocess; no full inherited environment/collection or FFI sandbox, no native qualification",
}
(run / "start.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
start = time.monotonic()
with (run / "stdout").open("xb") as stdout, (run / "stderr").open("xb") as stderr:
    child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr)
    try:
        code = child.wait(timeout=60)
    except subprocess.TimeoutExpired:
        child.terminate()
        code = child.wait(timeout=5)
        record["timeout"] = True
record.update(exit=code, elapsed_s=time.monotonic() - start,
              utc_finish=datetime.datetime.now(datetime.timezone.utc).isoformat(), source_after=snapshot(run / "after"))
retained = []
if pytest_run and fixtures.exists():
    for path in sorted(fixtures.rglob("*")):
        if path.is_file() and not path.is_symlink():
            data = path.read_bytes()
            retained.append({"path": path.relative_to(run).as_posix(), "bytes": len(data), "sha256": sha(data)})
record["retained_regular_fixtures"] = retained
(run / "completion.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
print(json.dumps({"label": label, "exit": code, "elapsed_s": record["elapsed_s"], "fixtures": len(retained)}))
print((run / "stdout").read_text(encoding="utf-8", errors="replace")[-6000:])
print((run / "stderr").read_text(encoding="utf-8", errors="replace")[-1000:])
raise SystemExit(code)
