from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
path=root/'software-deps/pymavlink/dialects/v20/common.py'
raw=path.read_bytes()
normalized=raw.replace(b'\r\n',b'\n')
assert hashlib.sha256(raw).hexdigest()=='3ea65f5611b53b4e9cab51fb79d57746f0be4022497686c623ddcf66681ef15e'
assert hashlib.sha256(normalized).hexdigest()=='a7c6b23d908322134d19cb94b937c1ea6b1f5d5ffa9d1b0ad139174bf8d75809'
with (root/'software-codec-original-common.py').open('xb') as f: f.write(raw)
path.write_bytes(normalized)
print(json.dumps(dict(original_sha256=hashlib.sha256(raw).hexdigest(),test_source_sha256=hashlib.sha256(normalized).hexdigest(),change='CRLF to LF only in owned Windows software dependency; production pin unchanged; not Linux/native admission')))
