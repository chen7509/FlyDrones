"""Analyze only saved Windows evidence, without opening Linux files or loading ELF."""
import collections
import hashlib
import json
from pathlib import Path
import posixpath
import re
import shlex
import struct

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
OLD = ROOT/'results/native-linux-file-receipts-20261018'
contract = json.loads((OUT/'selection-contract.json').read_bytes())
files = json.loads((OUT/'current-files.json').read_bytes())
old_raw = (OLD/'current-files.json').read_bytes()
assert hashlib.sha256(old_raw).hexdigest() == contract['previous_manifest_sha256']
old = json.loads(old_raw)
completion = json.loads((OUT/'collection-completion.json').read_bytes())
build = contract['build_root']


def save(name, value):
    with (OUT/name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=True)


def data(row):
    raw = (OUT/row['blob']).read_bytes()
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
    return raw


def ref(name, row, prefix):
    return dict(linux_path=name, observed_status=row['status'], bytes=row.get('bytes'),
                sha256=row.get('sha256'), saved_blob=prefix+'/'+row['blob'] if row.get('blob') else None,
                observation_only=True, build_time_input_digest_proven=False)


def absolute_lexical(name):
    # Lexical comparison only: this never resolves a filesystem symlink.
    return posixpath.normpath(name if name.startswith('/') else build+'/'+name)


def elf_object(raw, source):
    if raw[:6] != b'\x7fELF\x02\x01' or len(raw) < 64:
        raise ValueError('only complete ELF64 little endian observations supported')
    etype, machine = struct.unpack_from('<HH', raw, 16)
    shoff = struct.unpack_from('<Q', raw, 40)[0]
    entsize, count, namesidx = struct.unpack_from('<HHH', raw, 58)
    if entsize != 64 or count == 0 or namesidx == 65535:
        raise ValueError('unsupported extended section indexing')
    if count > 65534 or shoff+count*64 > len(raw) or namesidx >= count:
        raise ValueError('invalid section table')
    sections = [struct.unpack_from('<IIQQQQIIQQ', raw, shoff+i*64) for i in range(count)]
    ns = sections[namesidx]
    if ns[4]+ns[5] > len(raw):
        raise ValueError('invalid section name bytes')
    names = raw[ns[4]:ns[4]+ns[5]]
    selected = {}
    for s in sections:
        end = names.index(b'\0', s[0])
        name = names[s[0]:end].decode('ascii', errors='backslashreplace')
        if s[1] != 8 and s[4]+s[5] > len(raw):
            raise ValueError('section outside retained object')
        if name in ('.comment', '.debug_line_str', '.debug_str', '.debug_info', '.text', '.symtab'):
            selected[name] = dict(offset=s[4], bytes=s[5], flags=s[2])
    result = dict(elf_class=64, little_endian=True, e_type=etype, machine=machine,
                  section_count=count, selected_sections=selected, executed_or_loaded=False,
                  source_to_object_proven=False, object_to_library_proven=False)
    comment = selected.get('.comment')
    if comment:
        result['comment_strings'] = [x.decode('utf-8', errors='backslashreplace')
            for x in raw[comment['offset']:comment['offset']+comment['bytes']].split(b'\0') if x]
    line = selected.get('.debug_line_str')
    if line and not line['flags'] & 2048:
        text = raw[line['offset']:line['offset']+line['bytes']]
        strings = text.split(b'\0')
        result['debug_line_string_observations'] = dict(
            exact_source_path_present=source.encode() in strings,
            source_basename_present=posixpath.basename(source).encode() in strings,
            build_path_present=build.encode() in strings,
            note='String-table occurrences only; not DWARF DIE/path/relocation attribution or source digest.')
    return result


bindings = {}
for name, row in files.items():
    assert name not in contract['previous_acquired_paths']
    if row['status'] == 'observed':
        data(row)
        assert row['before'] == row['after']
        bindings[name] = dict(**row, native_linux_identity_verified=False, native_admission=False)
save('file-bindings.json', dict(schema='openvins-build-supplement-files-v1', files=bindings,
    complete_linux_closure=False, source_to_library_proven=False, all_qualifications=False))

associations = []
index = {}
object_observations = {}
for source in contract['associations']:
    dep = files.get(source['depfile'])
    obj = files.get(source['object'])
    joined = dict(source_path=source['source'], object_path=source['object'], depfile_path=source['depfile'],
        association_basis=contract['association_evidence'],
        depfile_status=dep['status'] if dep else 'not_attempted_after_stop',
        object_status=obj['status'] if obj else 'not_attempted_after_stop',
        historical_compile_execution_verified=False, source_to_object_proven=False,
        object_to_library_proven=False)
    previous_source = old.get(source['source'])
    if previous_source:
        joined['previous_source_observation'] = ref(source['source'], previous_source,
                                                   'results/native-linux-file-receipts-20261018')
    if dep and dep['status'] == 'observed':
        text = data(dep).decode('utf-8').replace('\\\n', ' ')
        if '$' in text:
            raise ValueError('unsupported Make expansion in saved dependency text')
        target, body = text.split(':', 1)
        targets = shlex.split(target, posix=True)
        dependencies = shlex.split(body, posix=True)
        joined['depfile'] = ref(source['depfile'], dep, 'results/openvins-build-provenance-20261018')
        joined['depfile_parsed'] = dict(targets=targets, dependency_count=len(dependencies),
            target_matches_expected_object=len(targets)==1 and absolute_lexical(targets[0])==source['object'],
            expected_source_path_listed=source['source'] in dependencies,
            paths_are_compiler_records_not_input_hashes=True)
        for depname in dependencies:
            normalized = absolute_lexical(depname)
            entry = index.setdefault(normalized, dict(recorded_spellings=[], depfiles=[],
                bytes_at_compile_time=None, resolved_linux_identity=None))
            if depname not in entry['recorded_spellings']:
                entry['recorded_spellings'].append(depname)
            entry['depfiles'].append(source['depfile'])
            # Reuse actual retained observations only; never read dependencies from Linux here.
            prior = old.get(normalized)
            if prior and prior.get('blob'):
                entry['previous_file_observation'] = ref(normalized, prior,
                    'results/native-linux-file-receipts-20261018')
    if obj and obj['status'] == 'observed':
        joined['object'] = ref(source['object'], obj, 'results/openvins-build-provenance-20261018')
        try:
            parsed = elf_object(data(obj), source['source'])
        except (ValueError, IndexError, struct.error) as exc:
            parsed = dict(parse_error=repr(exc), source_to_object_proven=False)
        object_observations[source['object']] = parsed
    associations.append(joined)
save('translation-unit-associations.json', dict(schema='openvins-saved-tu-correspondence-v1',
    units=associations, link_recipe_evidence=ref(build+'/CMakeFiles/ov_msckf_lib.dir/link.txt',
        old[build+'/CMakeFiles/ov_msckf_lib.dir/link.txt'], 'results/native-linux-file-receipts-20261018'),
    source_to_existing_library_proven=False, historical_same_build_session_proven=False,
    note='Named associations from actual retained metadata; no authenticated historical input hash or main build execution receipt.'))
save('dependency-path-index.json', dict(schema='openvins-saved-dependency-path-index-v1',
    paths=index, lexical_normalization_only=True, headers_recollected=False,
    historical_input_content_proven=False))
save('object-static-observations.json', dict(schema='openvins-object-static-observations-v1',
    objects=object_observations, note='Static retained ELF/strings only, no ELF loading/execution, ABI or DWARF source-content proof.'))

logs = {}
for name, row in files.items():
    if row['role'] == 'build-log-or-dependency':
        observation = dict(file=ref(name, row, 'results/openvins-build-provenance-20261018'),
                           authenticated_execution_log=False)
        if row['status'] == 'observed':
            text = data(row).decode('utf-8')
            if name.endswith('CMakeConfigureLog.yaml'):
                lines = text.splitlines()
                observation.update(kind='stored CMake configure/probe log, not main library compilation/link transcript',
                    line_count=len(lines), event_kinds=dict(collections.Counter(re.findall(r'kind: "([^"]+)"', text))),
                    library_target_name_occurrences=text.count('ov_msckf_lib'),
                    compiler_version_lines=[dict(line=i+1,text=s.strip()) for i,s in enumerate(lines)
                        if 'gcc version ' in s or 'GNU C++' in s or 'GNU C17' in s],
                    recorded_exit_codes=[dict(line=i+1,text=s.strip()) for i,s in enumerate(lines) if 'exitCode:' in s],
                    current_compiler_alias_identity_proven=False, main_target_build_proven=False)
            elif name.endswith('LastTest.log'):
                observation.update(kind='stored CTest log', retained_text=text,
                    test_case_results_present=False, current_tests_executed=False,
                    note='Contains start/end only; no test case pass or historical target execution inference.')
            else:
                observation.update(kind='CMake dependency timestamp marker', retained_text=text)
        logs[name] = observation
save('log-observations.json', dict(schema='openvins-stored-build-log-observations-v1', files=logs,
    no_commands_in_logs_were_executed_this_phase=True))

summary = dict(schema='openvins-build-supplement-summary-v1',
    selected_paths=len(files), status_counts=dict(collections.Counter(r['status'] for r in files.values())),
    observed_files=len(bindings), deduplicated_blobs=len({r['sha256'] for r in bindings.values()}),
    observed_payload_bytes=sum(r['bytes'] for r in bindings.values()),
    actual_payload_bytes_read=completion['payload_bytes_read'],
    previous_acquired_path_overlap=len(set(files)&set(contract['previous_acquired_paths'])),
    declared_tus=len(associations), depfiles_observed=sum(r['depfile_status']=='observed' for r in associations),
    depfile_target_matches=sum(r.get('depfile_parsed',{}).get('target_matches_expected_object',False) for r in associations),
    depfile_source_path_matches=sum(r.get('depfile_parsed',{}).get('expected_source_path_listed',False) for r in associations),
    objects_observed=len(object_observations),
    objects_static_rel_x86_64=sum(r.get('e_type')==1 and r.get('machine')==62 for r in object_observations.values()),
    object_parse_errors={k:v for k,v in object_observations.items() if 'parse_error' in v},
    unique_lexical_dependency_paths=len(index),
    dependencies_with_previous_bytes=sum('previous_file_observation' in r for r in index.values()),
    new_logs_or_dependency_markers=sum(r['role']=='build-log-or-dependency' and r['status']=='observed' for r in files.values()),
    object_remaining_unknown=sum(r['object_status']!='observed' for r in associations),
    acquisition_complete=completion['complete'], stop_reason=completion.get('stop_reason'),
    current_library_sha256=None, source_to_object_proven=False, object_to_library_proven=False,
    source_to_existing_library_proven=False, native_admission=False, all_qualifications=False,
    native_commands=False, resource_queries=False, tests_run=False, linux_writes=False)
save('analysis-summary.json', summary)
save('missing-evidence.json', dict(schema='openvins-build-supplement-missing-evidence-v1',
    source_to_existing_library_proven=False, current_library_sha256=None,
    missing=[
        'Existing291717384B library remains unaccessed in this phase, unbound, SHA/ELF/ABI unknown after earlier64MiB refusal.',
        '15 of34 objects acquired; next object would exceed192MiB aggregate.19 objects unknown, no second batch/retry.',
        'Depfiles contain paths, not build-time source/header/tool content hashes or authenticated compile execution.',
        'Stored configure log reports historical probe subprocess outputs only, not all34 library TU compilations or final successful link.',
        'Seven selected log/internal paths unavailable; cannot infer absence of logs at all other unsearched locations.',
        'No signed/session-correlated source-to-object-to-library transcript, historical inputs, or full linked-object set/library comparison.',
        'Windows share stability is not native Linux device/inode/permission/symlink identity or atomic snapshot.',
        'Current observed source/package/tool bytes from the prior phase do not establish historical compiler aliases/headers or source authenticity.',
        'No actual ABI/propagation/reset/receiver/fusion/RTF/cleanup or native admission results.'],
    unavailable={n:r for n,r in files.items() if r['status']=='unavailable'},
    unobserved_objects=[dict(object=r['object_path'],status=r['object_status']) for r in associations if r['object_status']!='observed']))
print(json.dumps(summary))
