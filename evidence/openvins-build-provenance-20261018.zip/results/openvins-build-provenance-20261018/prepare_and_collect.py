"""One authorized Windows-only build-directory supplement; never executes Linux files."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
PREVIOUS = ROOT / 'results/native-linux-file-receipts-20261018'
BUILD = '/home/yuchen7509/flydrones-upstream/open_vins/ov_msckf/build'


def save(name, value):
    with (OUT / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=True, indent=2)


prior_bytes = (PREVIOUS / 'current-files.json').read_bytes()
prior = json.loads(prior_bytes)
exclude = {name: {key: row[key] for key in ('status', 'bytes', 'sha256', 'blob') if key in row}
           for name, row in prior.items() if row.get('blob')}
dep_path = BUILD + '/CMakeFiles/ov_msckf_lib.dir/DependInfo.cmake'
dep_row = prior[dep_path]
dep_raw = (PREVIOUS / dep_row['blob']).read_bytes()
assert hashlib.sha256(dep_raw).hexdigest() == dep_row['sha256']
tuples = re.findall(r'"([^"\n]+\.cpp)"\s+"([^"\n]+\.o)"\s+"gcc"\s+"([^"\n]+\.o\.d)"', dep_raw.decode('utf-8'))
assert len(tuples) == 34
associations = [dict(source=s, object=BUILD+'/'+o, depfile=BUILD+'/'+d) for s, o, d in tuples]
save('selection-contract.json', dict(schema='openvins-build-supplement-selection-v1',
    previous_manifest='results/native-linux-file-receipts-20261018/current-files.json',
    previous_manifest_sha256=hashlib.sha256(prior_bytes).hexdigest(),
    previous_acquired_paths=exclude,
    association_evidence=dict(linux_path=dep_path, sha256=dep_row['sha256'],
        retained_blob='results/native-linux-file-receipts-20261018/'+dep_row['blob']),
    associations=associations, build_root=BUILD,
    deliberately_not_reprobed=[BUILD+'/libov_msckf_lib.so'],
    limits=dict(file_bytes=67108864, aggregate_payload_bytes=201326592,
        selected_paths=6000, directory_entries=20000, read_seconds=27,
        parent_wait_seconds=30, terminate_wait_seconds=5, kill_wait_seconds=5, outer_seconds=45),
    source_to_library_proven=False, native_commands=False, resource_queries=False, tests_run=False))
save('collection-start.json', dict(utc=datetime.datetime.now(datetime.UTC).isoformat(),
    argv=[sys.executable, str(OUT/'collect_build_files.py')], cwd=str(ROOT),
    env_policy='inherited Windows environment, no full environment capture',
    linux_access='Windows standard readonly file I/O only', limits='selection-contract.json'))
start = time.monotonic()
result = dict(complete=False)
with (OUT/'collection.stdout').open('xb') as stdout, (OUT/'collection.stderr').open('xb') as stderr:
    child = subprocess.Popen([sys.executable, str(OUT/'collect_build_files.py')], cwd=ROOT,
                             stdout=stdout, stderr=stderr)
    result['owned_windows_child_pid'] = child.pid
    try:
        result['returncode'] = child.wait(timeout=30)
        result['complete'] = result['returncode'] == 0
    except subprocess.TimeoutExpired:
        result['parent_timeout'] = True
        child.terminate()
        try:
            result['returncode'] = child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            child.kill()
            try:
                result['returncode'] = child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                result['cleanup_unknown'] = True
result['elapsed_seconds'] = time.monotonic()-start
save('collection-parent-completion.json', result)
print(json.dumps(result))
