"""Link-name correspondence from retained bytes only, not successful link proof."""
import hashlib
import json
from pathlib import Path
import shlex

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
OLD = ROOT/'results/native-linux-file-receipts-20261018'
contract = json.loads((OUT/'selection-contract.json').read_bytes())
prior = json.loads((OLD/'current-files.json').read_bytes())
build = contract['build_root']
name = build+'/CMakeFiles/ov_msckf_lib.dir/link.txt'
row = prior[name]
raw = (OLD/row['blob']).read_bytes()
assert hashlib.sha256(raw).hexdigest() == row['sha256']
tokens = shlex.split(raw.decode('utf-8'))
objects = [token if token.startswith('/') else build+'/'+token for token in tokens if token.endswith('.o')]
expected = [r['object'] for r in contract['associations']]
new = json.loads((OUT/'current-files.json').read_bytes())
receipt = dict(schema='openvins-link-name-correspondence-v1', saved_link_recipe_sha256=row['sha256'],
    saved_link_recipe_path='results/native-linux-file-receipts-20261018/'+row['blob'],
    linked_object_names=objects, named_object_count=len(objects),
    object_name_sets_match_dependinfo=set(objects)==set(expected),
    duplicate_object_names=len(objects)!=len(set(objects)),
    objects_with_new_observed_bytes=[n for n in objects if new.get(n,{}).get('status')=='observed'],
    link_recipe_executed_this_phase=False, historical_link_exit_code=None,
    old_library_current_sha256=None, object_bytes_used_by_old_link_proven=False,
    source_to_existing_library_proven=False)
with (OUT/'link-name-correspondence.json').open('x', encoding='utf-8') as target:
    json.dump(receipt,target,indent=2)
print(json.dumps({k:v for k,v in receipt.items() if not isinstance(v,list)}))
