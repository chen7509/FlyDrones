"""Readonly supplementary build evidence through Windows file share, one27s window."""
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import time

OUT = Path(__file__).resolve().parent
CONTRACT = json.loads((OUT/'selection-contract.json').read_bytes())
BUILD = CONTRACT['build_root']
EXCLUDED = CONTRACT['previous_acquired_paths']
SHARE = Path(r'\\wsl.localhost\Ubuntu')
DEADLINE = time.monotonic()+27
CAP = 67108864
TOTAL_CAP = 201326592
total = 0
attempted = 0
records = {}
directories = {}
skipped = set()
(OUT/'blobs').mkdir(exist_ok=False)
log = (OUT/'files.jsonl').open('x', encoding='utf-8')
dlog = (OUT/'directories.jsonl').open('x', encoding='utf-8')


class AggregateCap(Exception):
    pass


def check():
    if time.monotonic() >= DEADLINE:
        raise TimeoutError('one27s aggregate read deadline')


def path(name):
    parts = PurePosixPath(name).parts
    if not name.startswith(BUILD+'/') and name != BUILD:
        raise ValueError('outside fixed build root')
    if '..' in parts or '\\' in name:
        raise ValueError('noncanonical path')
    return SHARE/name.lstrip('/').replace('/', '\\')


def meta(s):
    return dict(mode=s.st_mode, size=s.st_size, ino=s.st_ino, dev=s.st_dev,
                mtime_ns=s.st_mtime_ns, ctime_ns=s.st_ctime_ns,
                attributes=getattr(s, 'st_file_attributes', 0),
                reparse_tag=getattr(s, 'st_reparse_tag', 0))


def safe_ancestry(name):
    # Check every accessed Linux directory ancestor; do not follow LX links.
    current = SHARE
    for part in PurePosixPath(name).parts[1:-1]:
        check()
        current /= part
        s = current.lstat()
        if getattr(s, 'st_file_attributes', 0) & 1024 or not stat.S_ISDIR(s.st_mode):
            raise ValueError('unresolved/non-directory ancestor: '+str(current))


def take(name, role):
    global total, attempted
    if name in EXCLUDED:
        skipped.add(name)
        return
    if name in records:
        return
    check()
    if attempted >= 6000:
        raise AggregateCap('6000 selection cap')
    attempted += 1
    row = dict(linux_path=name, role=role, utc=datetime.datetime.now(datetime.UTC).isoformat(),
               status='unknown', linux_resolved_path=None)
    try:
        p = path(name)
        safe_ancestry(name)
        before = meta(p.lstat())
        row['before'] = before
        if before['attributes'] & 1024:
            row['status'] = 'unresolved_reparse'
        elif not stat.S_ISREG(before['mode']):
            row['status'] = 'not_regular'
        elif before['size'] > CAP:
            row.update(status='file_cap', limit=CAP)
        elif total+before['size'] > TOTAL_CAP:
            row.update(status='aggregate_cap', limit=TOTAL_CAP)
            raise AggregateCap('192MiB payload cap; stop, no fit-to-budget selection')
        else:
            raw = bytearray()
            with p.open('rb') as stream:
                while True:
                    check()
                    block = stream.read(min(1024**2, CAP-len(raw)+1, TOTAL_CAP-total+1))
                    if not block:
                        break
                    total += len(block)
                    raw.extend(block)
                    check()
                    if len(raw) > CAP:
                        raise AggregateCap('file grew past64MiB; stop')
                    if total > TOTAL_CAP:
                        raise AggregateCap('payload grew past192MiB; stop')
            after = meta(p.lstat())
            check()
            digest = hashlib.sha256(raw).hexdigest()
            blob = OUT/'blobs'/digest
            if not blob.exists():
                with blob.open('xb') as target:
                    target.write(raw)
            row.update(status='observed' if before == after and len(raw) == before['size'] else 'changed',
                       after=after, bytes=len(raw), sha256=digest, blob='blobs/'+digest)
    except (TimeoutError, AggregateCap) as exc:
        row.update(status=row['status'] if row['status']=='aggregate_cap' else 'interrupted', error=repr(exc))
        records[name] = row
        log.write(json.dumps(row)+'\n')
        log.flush()
        raise
    except (OSError, ValueError) as exc:
        row.update(status='unavailable', error=repr(exc))
    records[name] = row
    log.write(json.dumps(row)+'\n')
    log.flush()


def walk(name, depth=0):
    check()
    if depth > 20:
        raise AggregateCap('directory depth20')
    row = dict(path=name, entries=[], complete=False)
    try:
        p = path(name)
        safe_ancestry(name+'/sentinel')
        row['before'] = meta(p.lstat())
        if row['before']['attributes'] & 1024:
            raise ValueError('unresolved directory reparse')
        with os.scandir(p) as entries:
            for entry in entries:
                check()
                if len(row['entries']) >= 20000:
                    raise AggregateCap('directory20000 entries')
                row['entries'].append(entry.name)
        row['entries'].sort()
        row['after'] = meta(p.lstat())
        row['complete'] = row['before'] == row['after']
        directories[name] = row
        dlog.write(json.dumps(row)+'\n')
        dlog.flush()
        for part in row['entries']:
            check()
            child = name+'/'+part
            s = path(child).lstat()
            if getattr(s, 'st_file_attributes', 0) & 1024:
                take(child, 'build-log-or-dependency')
            elif stat.S_ISDIR(s.st_mode):
                walk(child, depth+1)
            elif part.endswith(('.log', '.yaml', '.txt', '.o.d', '.internal', '.ts', '.json')):
                take(child, 'build-log-or-dependency')
    except (TimeoutError, AggregateCap):
        if name not in directories:
            directories[name] = row
            dlog.write(json.dumps(row)+'\n')
            dlog.flush()
        raise
    except (OSError, ValueError) as exc:
        row['error'] = repr(exc)
        directories[name] = row
        dlog.write(json.dumps(row)+'\n')
        dlog.flush()


completion = dict(schema='openvins-build-supplement-collection-v1', complete=False,
    source_to_existing_library_proven=False, all_qualifications=False,
    native_commands=False, resource_queries=False, tests_run=False, linux_writes=False,
    atomic_snapshot=False, linux_identity_verified=False)
try:
    # Read exact 34 dependency paths from previously saved DependInfo, not guessed headers.
    for row in CONTRACT['associations']:
        take(row['depfile'], 'library-tu-dependency')
    # These are build-directory log paths, not arbitrary homedir/history searches.
    for suffix in ('CMakeFiles/CMakeConfigureLog.yaml', 'CMakeFiles/CMakeOutput.log',
                   'CMakeFiles/CMakeError.log', 'build.log', 'configure.log', 'compile.log',
                   'link.log', 'CMakeFiles/ov_msckf_lib.dir/compiler_depend.internal',
                   'CMakeFiles/ov_msckf_lib.dir/compiler_depend.ts'):
        take(BUILD+'/'+suffix, 'build-log-or-dependency')
    walk(BUILD+'/Testing')
    # Last: exact linked-target objects. File cap refusal is recorded and not retried.
    for row in CONTRACT['associations']:
        take(row['object'], 'library-tu-object')
    completion['complete'] = True
except (TimeoutError, AggregateCap) as exc:
    completion['stop_reason'] = repr(exc)
finally:
    completion.update(selected_paths=attempted, payload_bytes_read=total,
                      skipped_previously_acquired=sorted(skipped))
    for name, value in (('current-files.json', records), ('directory-listings.json', directories),
                        ('collection-completion.json', completion)):
        with (OUT/name).open('x', encoding='utf-8') as stream:
            json.dump(value, stream, indent=2)
    log.close()
    dlog.close()
    print(json.dumps(completion))
