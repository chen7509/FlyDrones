"""Executor verifies only this new saved-byte supplement and its archive."""
import ast
import hashlib
import json
from pathlib import Path
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
POST = OUT/'postseal'
FILES = ['docs/OPENVINS_BUILD_PROVENANCE_PROGRESS.md',
         'docs/superpowers/plans/2026-10-18-openvins-build-provenance.md']
FILES += ['results/openvins-build-provenance-20261018/'+n+'.json' for n in (
    'file-bindings', 'translation-unit-associations', 'dependency-path-index',
    'object-static-observations', 'log-observations', 'link-name-correspondence',
    'missing-evidence', 'analysis-summary')]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


summary = json.loads((OUT/'analysis-summary.json').read_bytes())
contract = json.loads((OUT/'selection-contract.json').read_bytes())
observed = json.loads((OUT/'current-files.json').read_bytes())
assert set(observed).isdisjoint(contract['previous_acquired_paths'])
assert len(observed) == 60 and summary['observed_files'] == 52
assert summary['depfile_target_matches'] == summary['depfile_source_path_matches'] == 34
assert summary['objects_static_rel_x86_64'] == 15 and not summary['object_parse_errors']
assert summary['actual_payload_bytes_read'] == summary['observed_payload_bytes'] == 186048617
assert summary['actual_payload_bytes_read'] < 201326592
assert not summary['acquisition_complete'] and '192MiB' in summary['stop_reason']
assert summary['source_to_existing_library_proven'] is False
assert summary['current_library_sha256'] is None and summary['native_admission'] is False
for name,row in observed.items():
    if row['status'] == 'observed':
        raw = (OUT/row['blob']).read_bytes()
        assert len(raw) == row['bytes'] <= 67108864 and sha(raw) == row['sha256']
        assert row['before'] == row['after']
link = json.loads((OUT/'link-name-correspondence.json').read_bytes())
assert link['named_object_count'] == 34 and link['object_name_sets_match_dependinfo']
assert not link['duplicate_object_names'] and len(link['objects_with_new_observed_bytes']) == 15
for source in OUT.glob('*.py'):
    ast.parse(source.read_text(encoding='utf-8'), filename=str(source))
with (OUT/'self-check.json').open('x', encoding='utf-8') as target:
    json.dump(dict(scope='Executor new saved payload/JSON correspondence and helper AST only. No tests, Linux access or old archive/source/native/delivery review.',
        observed_files_verified=52, observed_object_ELFs=15, matched_depfiles=34,
        no_previously_acquired_path_recollected=True, no_native_command=True,
        resource_queries=False, tests_run=False, current_library_sha256=None,
        source_to_existing_library_proven=False, all_qualifications=False), target, indent=2)
paths = set(FILES)
for p in OUT.rglob('*'):
    if 'postseal' in p.relative_to(OUT).parts or '__pycache__' in p.parts or p.suffix == '.pyc':
        continue
    if p.is_file() and not p.is_symlink():
        paths.add(p.relative_to(ROOT).as_posix())
mapping = {}
archive = ROOT/'evidence/openvins-build-provenance-20261018.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for name in sorted(paths):
        raw = (ROOT/name).read_bytes()
        mapping[name] = dict(bytes=len(raw), sha256=sha(raw))
        entry = zipfile.ZipInfo(name, (2026,10,18,0,0,0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        entry.external_attr = 0o100600 << 16
        output.writestr(entry, raw)
    manifest = json.dumps(dict(schema='openvins-build-supplement-archive-v1', mapping=mapping,
        note='New unacquired build-directory files only, with prior retained evidence references; not source-to-old-library or native admission proof.'),
        sort_keys=True, indent=2).encode()
    output.writestr('manifest.json', manifest)
with zipfile.ZipFile(archive) as source:
    assert source.testzip() is None and len(source.namelist()) == len(mapping)+1
    for name,row in mapping.items():
        assert sha(source.read(name)) == row['sha256']
receipt = dict(schema='openvins-build-supplement-seal-v1', archive=archive.relative_to(ROOT).as_posix(),
    bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()), members=len(mapping)+1, mapped=len(mapping),
    mapped_payload_bytes=sum(r['bytes'] for r in mapping.values()), manifest_bytes=len(manifest),
    whole_expanded_bytes=sum(r['bytes'] for r in mapping.values())+len(manifest),
    software_files=FILES, source_to_existing_library_proven=False,
    native_admission=False, all_qualifications=False)
with archive.with_suffix('.sha256.json').open('x', encoding='utf-8') as target:
    json.dump(dict(**receipt, mapping=mapping), target, indent=2)
POST.mkdir(exist_ok=False)
with (POST/'seal-receipt.json').open('x', encoding='utf-8') as target:
    json.dump(receipt, target, indent=2)
print(json.dumps({k:v for k,v in receipt.items() if k != 'software_files'}))
