"""Seal this development stage's selected evidence without touching old archives."""

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DEST = ROOT / "evidence/live-wire-logger-study-dev-1701.zip"
SELECTED = (
    "docs/LIVE_WIRE_LOGGER_STUDY_REPORT.md",
    "docs/superpowers/specs/2026-10-12-live-wire-logger-study-design.md",
    "docs/superpowers/plans/2026-10-12-live-wire-logger-study.md",
    "tools/benchmark/live_wire_study.py",
    "tools/benchmark/audit_live_wire_study.py",
    "tools/benchmark/execute_openvins_health_physical_run.py",
    "tests/benchmark/test_live_wire_study.py",
    "tests/benchmark/test_live_wire_explicit_entry.py",
    "results/live-wire-logger-study-dev-1701/regression.txt",
    "results/live-wire-logger-study-dev-1701/regression-final.txt",
    "results/live-wire-logger-study-dev-1701/regression-stable.txt",
    "results/live-wire-logger-study-dev-1701/review.txt",
    "results/live-wire-logger-study-dev-1701/checks.txt",
    "results/live-wire-logger-study-dev-1701/seal.py",
)


def main():
    records = []
    with zipfile.ZipFile(DEST, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for name in SELECTED:
            raw = (ROOT / name).read_bytes()
            archive.writestr(name, raw)
            records.append({"path": name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()})
        archive.writestr("MANIFEST.json", json.dumps({"schema": "stage-evidence-v1", "members": records},
                                                     sort_keys=True, indent=2) + "\n")
    with zipfile.ZipFile(DEST) as archive:
        if archive.testzip() is not None:
            raise ValueError("ZIP CRC failure")
        for record in records:
            if hashlib.sha256(archive.read(record["path"])).hexdigest() != record["sha256"]:
                raise ValueError("member digest failure: " + record["path"])
    print(f"{len(records)} members; SHA256 {hashlib.sha256(DEST.read_bytes()).hexdigest()}")


if __name__ == "__main__":
    main()
