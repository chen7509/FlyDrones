"""Seal the v2 journal source and bounded build/synthetic evidence."""

import hashlib
import json
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
ARCHIVE = ROOT / "evidence/px4-ros2-full-odometry-dev-1701.zip"
FILES = (
    "docs/PX4_ROS2_FULL_ODOMETRY_JOURNAL_REPORT.md",
    "docs/superpowers/specs/2026-10-10-px4-ros2-full-odometry-journal-design.md",
    "docs/superpowers/plans/2026-10-10-px4-ros2-full-odometry-journal.md",
    "src/flydrones/connectome_training/px4_ros2_build_source.py",
    "src/flydrones/connectome_training/px4_ros2_source_journal.py",
    "tests/connectome_training/test_px4_ros2_build_source.py",
    "tests/connectome_training/test_px4_ros2_full_journal.py",
    "tests/connectome_training/test_full_odometry_synthetic_runner.py",
    "tests/native/px4_ros2_full_odometry_fields_test.cc",
    "tools/connectome/px4_ros2_source/README.md",
    "tools/connectome/px4_ros2_source/px4_odometry_source.cpp",
    "tools/connectome/px4_ros2_source/full_odometry_fields.hpp",
    "tools/connectome/run_full_odometry_ros_build.py",
    "tools/connectome/run_full_odometry_synthetic.py",
    "tools/connectome/check_full_odometry_cdr_parity.py",
    "results/px4-ros2-full-byte-build-dev-1701/source-v1/build-source-profile.json",
    "results/px4-ros2-full-byte-build-dev-1701/source-v1/build-source-profile.sha256",
    "results/px4-ros2-full-build-attempt-dev-1701/run-profile.json",
    "results/px4-ros2-full-build-attempt-dev-1701/preflight.json",
    "results/px4-ros2-full-build-attempt-dev-1701/launch.json",
    "results/px4-ros2-full-build-attempt-dev-1701/result.json",
    "results/px4-ros2-full-build-attempt-dev-1701/docker-colcon.log",
    "results/px4-ros2-byte-build-dev-1701/resume-result.json",
    "results/px4-ros2-byte-build-dev-1701/docker-colcon.log",
    "results/px4-ros2-full-synthetic-dev-1701/preflight.json",
    "results/px4-ros2-full-synthetic-dev-1701/result.json",
    "results/px4-ros2-full-synthetic-dev-1701-v2/preflight.json",
    "results/px4-ros2-full-synthetic-dev-1701-v2/launch.json",
    "results/px4-ros2-full-synthetic-dev-1701-v2/container.log",
    "results/px4-ros2-full-synthetic-dev-1701-v2/result.json",
    "results/px4-ros2-full-synthetic-dev-1701-v3/preflight.json",
    "results/px4-ros2-full-synthetic-dev-1701-v3/result.json",
    "results/px4-ros2-full-odometry-dev-1701/tests-final.txt",
    "results/px4-ros2-full-odometry-dev-1701/native-final.txt",
    "results/px4-ros2-full-odometry-dev-1701/ruff-final.txt",
    "results/px4-ros2-full-odometry-dev-1701/diff-check-final.txt",
    "results/px4-ros2-full-odometry-dev-1701/seal.py",
)


def main() -> None:
    manifest = {
        "schema": "flydrones.px4_ros2_full_odometry_evidence.v1",
        "typed_callback_parity_verified": False,
        "live_source_qualified": False,
        "fusion_qualified": False,
        "files": {},
    }
    if ARCHIVE.exists():
        raise FileExistsError("evidence archive already exists")
    ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ARCHIVE, "x", zipfile.ZIP_DEFLATED) as archive:
        for name in FILES:
            data = (ROOT / name).read_bytes()
            manifest["files"][name] = {
                "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()
            }
            archive.writestr(name, data)
        archive.writestr("manifest.json", json.dumps(manifest, sort_keys=True, indent=2))
    with zipfile.ZipFile(ARCHIVE) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("ZIP CRC check failed")
        for name, expected in manifest["files"].items():
            data = archive.read(name)
            if len(data) != expected["bytes"] or hashlib.sha256(data).hexdigest() != expected["sha256"]:
                raise RuntimeError(f"evidence member drift: {name}")
    seal = {"archive": str(ARCHIVE),
            "sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
            "member_count": len(FILES) + 1, "crc_and_hash_verified": True}
    (Path(__file__).parent / "seal.json").write_text(
        json.dumps(seal, sort_keys=True, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(seal, sort_keys=True))


if __name__ == "__main__":
    main()
