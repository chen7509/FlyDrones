from pathlib import Path
root=Path.cwd()
def edit(path,changes):
 p=root/path;s=p.read_text()
 for old,new,count in changes:
  assert s.count(old)==count,(path,old,s.count(old),count)
  s=s.replace(old,new)
 p.write_text(s,encoding='utf-8',newline='')
imports='from .model import ConnectomeConstrainedCore, topology_identity_suffix, validate_topology_backend'
newimports='from .model import ConnectomeConstrainedCore, dynamics_identity_suffix, topology_identity_suffix, validate_dynamics_backend, validate_topology_backend'
entry='src/flydrones/connectome_training/'
edit(entry+'curriculum_session.py',[
 (imports,newimports,1),
 ('        topology_format: str = "coo_reference",','        topology_format: str = "coo_reference",\n        dynamics_format: str = "clipped-euler-v1",',1),
 ('        self._topology_format = topology_format','        self._topology_format = topology_format\n        dynamics_suffix = dynamics_identity_suffix(dynamics_format)\n        self._dynamics_format = dynamics_format',1),
 ('        self.model = ConnectomeConstrainedCore(connectome, parameters, **backend).to(self.device)','        if dynamics_format != "clipped-euler-v1":\n            backend["dynamics_format"] = dynamics_format\n        self.model = ConnectomeConstrainedCore(connectome, parameters, **backend).to(self.device)',1),
 ('            + topology_suffix','            + topology_suffix\n            + dynamics_suffix',1),
 ('        validate_topology_backend(self.model, self._topology_format)','        validate_topology_backend(self.model, self._topology_format)\n        validate_dynamics_backend(self.model, self._dynamics_format)',1),
 ('**({"topology_format": self._topology_format} if self._topology_format != "coo_reference" else {}),','**({"topology_format": self._topology_format} if self._topology_format != "coo_reference" else {}),\n            **({"dynamics_format": self._dynamics_format} if self._dynamics_format != "clipped-euler-v1" else {}),',2),
 ('        named = dict(self.model.named_parameters())\n        validate_learning_state','        if payload["metadata"].get("dynamics_format", "clipped-euler-v1") != self._dynamics_format:\n            raise ValueError("checkpoint metadata mismatch: dynamics_format")\n        named = dict(self.model.named_parameters())\n        validate_learning_state',1),
])
edit(entry+'inference_artifact.py',[
 (imports,newimports,1),
 ('    topology_format: str = "coo_reference",','    topology_format: str = "coo_reference",\n    dynamics_format: str = "clipped-euler-v1",',1),
 ('    topology_suffix = topology_identity_suffix(topology_format)','    topology_suffix = topology_identity_suffix(topology_format)\n    dynamics_suffix = dynamics_identity_suffix(dynamics_format)',1),
 (' + topology_suffix\n',' + topology_suffix + dynamics_suffix\n',1),
 ('**({"topology_format": topology_format} if topology_format != "coo_reference" else {}),','**({"topology_format": topology_format} if topology_format != "coo_reference" else {}),\n            **({"dynamics_format": dynamics_format} if dynamics_format != "clipped-euler-v1" else {}),',1),
 ('        if learning_profile is not None:\n            declared =','        if checkpoint["metadata"].get("dynamics_format", "clipped-euler-v1") != dynamics_format:\n            raise ValueError("checkpoint metadata mismatch: dynamics_format")\n        if learning_profile is not None:\n            declared =',1),
 ('    core = ConnectomeConstrainedCore(Connectome.load(source), parameters, **backend)','    if dynamics_format != "clipped-euler-v1":\n        backend["dynamics_format"] = dynamics_format\n    core = ConnectomeConstrainedCore(Connectome.load(source), parameters, **backend)',1),
 ('    validate_topology_backend(core, topology_format)','    validate_topology_backend(core, topology_format)\n    validate_dynamics_backend(core, dynamics_format)',1),
 ('            "topology_format": topology_format,','            "topology_format": topology_format,\n            "dynamics_format": dynamics_format,',1),
])
edit(entry+'inference.py',[( '                "topology_format": self.provenance.get("topology_format"),','                "topology_format": self.provenance.get("topology_format"),\n                "dynamics_format": self.provenance.get("dynamics_format"),',1)])
p=root/'tools/connectome_training/run_curriculum.py';s=p.read_text();line=next(x for x in s.splitlines() if 'import TOPOLOGY_FORMATS' in x)
edit('tools/connectome_training/run_curriculum.py',[(line,line.replace('import TOPOLOGY_FORMATS','import DYNAMICS_FORMATS, TOPOLOGY_FORMATS'),1),('    parser.add_argument("--topology-format", choices=TOPOLOGY_FORMATS, default="coo_reference")','    parser.add_argument("--topology-format", choices=TOPOLOGY_FORMATS, default="coo_reference")\n    parser.add_argument("--dynamics-format", choices=DYNAMICS_FORMATS, default="clipped-euler-v1")',1),('        topology_format=getattr(args, "topology_format", "coo_reference"),','        topology_format=getattr(args, "topology_format", "coo_reference"),\n        dynamics_format=getattr(args, "dynamics_format", "clipped-euler-v1"),',1)])
print('connected explicit dynamics/session/offline/decision/CLI;legacy default preserved')
