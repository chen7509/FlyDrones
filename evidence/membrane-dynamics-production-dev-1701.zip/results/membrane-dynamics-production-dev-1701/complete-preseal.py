import difflib,hashlib,json
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest()
def save(n,b):
 with (raw/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
review=json.loads((raw/'independent-dynamics-review.json').read_bytes());assert review['original_counts']==dict(Critical=0,Important=0,Minor=1)
join=[]
for r in review['source_pins']:
 path=r['relative_path'];p=root/path;b=p.read_bytes();original=None;origin=None
 if sha(b)==r['sha256']:original=b;origin=path
 else:
  for folder in raw.glob('*-source'):
   q=folder/path
   if q.exists() and sha(q.read_bytes())==r['sha256']:original=q.read_bytes();origin=q.relative_to(root).as_posix();break
 assert original is not None,path
 dest=raw/'review-source-original'/path;dest.parent.mkdir(parents=True,exist_ok=True)
 with dest.open('xb') as f:f.write(original)
 join.append(dict(path=path,reviewed_sha256=r['sha256'],reviewed_bytes_from=origin,current_sha256=sha(b),changed_after_original_review=sha(b)!=r['sha256']))
 if original!=b:save('review-delta-'+p.name+'.patch',''.join(difflib.unified_diff(original.decode().splitlines(True),b.decode().splitlines(True),fromfile='review/'+path,tofile='final/'+path)))
save('review-source-join.json',json.dumps(dict(rows=join,scope='Additive POSTreview byte join to retained raw/current bytes,not reconstructed prepins or new review'),indent=2))
save('executor-fix-pass.md','''# One bounded executor fix pass

Original single whole-source review remains C0/I0/M1, SHA/grade unchanged. MD-M1 is regraded Important by the executor because save_checkpoint can report success with a checkpoint the same session cannot resume. Normal coordinator metadata omits the reserved key; no previous successful training claim is withdrawn. This is a real public save API consistency defect, not mere formatting. One bounded pass rejects a conflicting caller dynamics_format before file creation for either mode, and strips a matching legacy key from the owned serialization while leaving the caller dict intact. No second whole-source review.

Seven real behavior REDs3.69s/24deselected: six conflicting/invalid reserved labels accepted, plus matching legacy key wrongly retained. After product fix, first final attempt6failed31passed5.36s: all six error checks now threw correctly, but the test wrongly required an empty tmp_path that already contained config fixture curriculum.yaml. This is a fixture postcondition error, not a failed product rejection or new native failure. Record initial directory members and require the same set; no production weakening. Final37passed5.36s afterformat includes31newtests plus6state-neighbors,one CSR-beta warning; finalRuff0/dedicateddiff0. No subsequent source changes.

Earlier initial4missingAPI TypeError+1legacyzero-gradientcontrolpass .38s are not behavior/native RED. First scalargreen1precisionfixturefail4pass3.36s came from float32 inverse-gain initialization promoted to float64; fixture fixes rawgain to the exact double inverse of gain1,not tolerance relaxation. Then5pass2.96s1warning. Three coherent metadata DIDNOTRAISE3.95s→18pass4.53s1warning. Analytical derivative/short-unequal dt coverage directly passes. Necessary129pass8.93s had exactly TWO warnings total (oneCSRbeta,oneweights_onlysparse-invariant); original reviewerJSON text says 'plus two weights_only warnings', an incorrect supplied-context wording retained unchanged and corrected here from actual raw. Signed16neuron new20Hz COO/CSR gradients/twoSGDupdates coverage1pass3.31s/23deselected1warning;included in same ongoing original review before its freeze. Later fix tests and session delta are executor-only, bytejoined through review-source-join.json/patches and retained original snapshots.

Rulings: preserve default clipped-euler-v1 and its documented dead20Hz tau derivative to avoid silently changing old checkpoint meaning. Explicit frozen-drive-exponential-v1 is a different discrete model with its own identity; it is exact only for held drive/recurrent input,not continuously coupled/LIF accuracy. Cost if the new discretization is unsuitable: future scientific behavior/accuracy fails; no full qualification or deployment permission follows. No claims for hostile model mutation/source authentication/arbitrarylaterRNGrestore atomicity,fullmodel/GPU/memory/latency/fairness/native/flight. All reviewer declined scopes stand and actual publication is audited separately. Existing fullhistory/source/refusal/budget/truth/pidfd restrictions remain.
''')
plan=root/'docs/superpowers/plans/2026-10-16-membrane-dynamics-production.md';b=plan.read_bytes();assert b.count(b'- [ ]')==3;new=b.replace(b'- [ ]',b'- [x]',2);plan.write_bytes(new)
save('review-seal-plan-join.json',json.dumps(dict(review_plan_sha256=sha(b),sealed_plan_sha256=sha(new),changed_byte_offsets=[i for i,(a,c) in enumerate(zip(b,new)) if a!=c],scope='Firsttwo checkboxspaces only;revieworiginal unchanged'),indent=2))
report='''# Explicit trainable membrane decay at20Hz

The actual legacy training/inference cadence is50ms and the default membrane timeconstant is20ms. Its clippedEuler alpha=clamp(50/tau_ms,0,1) becomes1, with zero derivative with respect to raw_tau_m. The real legacy control test confirms this; requires_grad and optimizer membership alone never proved effective learning of that coefficient. Previous tinyCSR comparisons used1ms to avoid saturation and did not qualify20Hz tau learning. Historical raw/results remain exact.

Production now supports explicit dynamics_format=frozen-drive-exponential-v1 through core, curriculum, checkpoint, offline inference, decision evidence and run_curriculum --dynamics-format. It computes alpha=-expm1(-dt_ms/tau_ms) with drive and recurrence sampled once at interval start. This is exact scalar leak for the held input, not exact continuous coupled-network integration, LIF equivalence, accuracy or learned-flight proof. No artificial1ms observation clock,50substep multiplier, parameter-bound inflation or new learningdegree was introduced. Both existing topology formats use this same selected formula. Graph/signs/roles/initialization/window/corpus/codec/loss/gates remain.

Default clipped-euler-v1 retains old numeric behavior, identity and absent-field checkpoint convention, including its known zero-gradient limitation in this regime. Only explicit new selection changes the model and adds a dynamics identity suffix and owned metadata. New sessions capture the original four coefficients and their actual initial validation losses under the selected dynamics. Offline reconstruction uses the actual source/parameter artifact, then existing role/init checks, with validation_baseline_verified=false without validation data. Legacy-style missing initialization is not retroactively qualified. Live session mode drift and conflicting checkpoint labels reject before updates/copy, offline invalid choice before file effects/coreconstruction. Save rejects conflicting reserved dynamics labels before output; a matching legacy label is stripped without mutating caller metadata. This is controlled ordinary API drift detection, not hostile mutation/source authentication or all-failure atomic restore.

## Actual software evidence

Raw results/membrane-dynamics-production-dev-1701 retains exact argv/env/recorderSHA,all22declared source-before/after copies,exclusivefixtures,streams and clocks. All initial declared paths exist; newtest is pinned when first invoked. Whole828productbefore separately covers unchanged neighbors; no retroactive pin claims. Original single source review C0/I0/M1/hash stays unchanged. The executor regraded the save consistency issue Important by effect and fixed it in one bounded pass. Additive source joins/patches distinguish original session/test from fixed source and onlytwo plan checkbox changes. No secondwholecode review; archive/publication audits onlyintegrity/honesty.

| Record | Actual result |
| --- | --- |
| initial dynamics-red |4missingAPI TypeError failures+1legacyzero-gradientcontrolpass .38s;notbehavior/nativeRED |
| firstgreen |1scalarreference fixtureprecisionfailure/4pass3.36s;float32 inversegain promoted todouble |
| scalarfixturefix |5pass2.96s1CSRwarning;exactdoublegain1,not looser tolerance |
| metadata-red |3true coherent-rehashDIDNOTRAISE failures3.95s/15deselected |
| productiongreen |18pass4.53s1CSRwarning |
| analytical/shortdtcoverage |5 additional direct passes,notfakeRED |
| necessaryneighbors |129pass8.93s,exactly2warnings:CSRbeta+weights_onlysparse-invariant |
| signedsparsecoverage |1pass3.31s/23deselected1CSRwarning,new20Hz outputs/rawgradients/twoSGDupdates;part of original review |
| reviewfixRED |7genuine failures3.69s/24deselected,reservedmetadata acceptance/legacykeyretention |
| firstfinal |6fixturepostcondition failures/31pass5.36s;configfixturealreadycreatedcurriculum.yaml,errorrejection itself nowcorrect |
| final |37pass5.36s afterformat(31new+6state-neighbors),1CSRwarning,finalRuff0/dedicateddiff0 |

InitialRuff2importerrors/importfix/3formatted3unchanged and laterfix-testformat are retained. The original reviewerJSON incorrectly describes supplied warning context as 'plus two weights_only warnings'; its bytes remain and executor note corrects it against actual129run: TWO TOTAL,notthree. No fake GREEN/fake RED/reconstruction. Tiny actual scalar and16-neuron CPU sparse/NNforwardbackward/SGD/Adam run; actual20Hz tau gradient matches independent analytic derivative and changes under optimizer, recurrent detach stays at declaredwindow boundaries. Hand scalar held-input solution covers unequal intervals. Default inertfixture and additional neighborplugin disable child/resource/CUDA callbacks;peak0/CUDAfalse are fixture protocol,not measurements/gates. HostNumPy/SciPy/Torch/nativeCPU sparse execute,not targetSDK/Linux/nativeobserver/fullMaleCNS/GPU/physics/calibration. Guard is not collection/FFIsandbox. No crash/timeout this phase; old3221225477/exactcauseUNKNOWN and120srecorderpartial/completiongap remain untouched.

## Preservation and delivery scope

300oldZIP889452728B fullystreamedunchangedPOSTsoftware/nonprepin.828oldproducts onlymodel,session,inference_artifact,inference,CLI changed/823same/newtestseparate. All consumedversion-specific source bytes unchanged. Original382beforeafter/copies exact,current6evolved remain session,dataset,inference,inference_artifact,trainer,model;CLIoutsideoriginal382 androles/corpuspost382namespace unchanged. Oldrequest232184B/SHA546c... and release44826B/SHAf7ce... exactCURRENTSTALE. Originalv4sixfileREFUSED_UNCONSUMED/Win1620271104WSL6851129344/memorypasscompetitor1Dockerempty/ownedCLIexit0wait2.437s,notfreeze/nativefailure. No preidentity-attempt/request/recipe/claim/sdkstart/study/SDKcommand/scope;physicalabsent/unconsumed. No rerun/rewrite/delete/rename/blindfolderretry/resourcepoll/competitorlookup/termination/manualmetadata/genericworker bypass. Futurestatic requires newcompleteindependentcurrent source/receipt/routingdesign and originalfullfreshprepins/review/once preserving all evolution/refusal.

All3complete histories80946B/80df...,89359B/c888...,81675B/df122e... remain byteexact,includingfull63552prompt plusolderreferences andalloriginalgoals/failures/budgets;no newtruncation/externalization. Full64305charPRhistory unchanged,immediate13377body keptverbatimsuffix. Saved475private rows175empty/202nonemptyargvhashes two-tripleschecked;private3 unchangedexcludedwithoutresource refresh. Currentactualautomation16172char/dba0... will be preserved as exactsuffix underlatestfacts,no terminalLF trimming. OldLFtrimcorrection/rawhelpererrors unchanged.

All8source/clock/measuredcalibration/accuracy/teacher/fusion/training/flight/runtime_graph_frozen/physical_dispatch_ready=false,goalblockedreadonly/automationACTIVE. FullMaleCNSlearning/fairupstream/source/calibration/HITLflight remain pending;no tinygradient/SHA/exit0 replaces qualification. Oldv3CONSUMED_FAILED_UNADMITTED_HARNESS_ESCAPE/allv1v2JSONobserverEGOOpenVINSKalibr CONSUMEDUNKNOWN/fixtureMOCK/251pose185init/5agent.873RTFfailures remain. Staticdual1GiB/nocompetition/Dockerempty/512MiBswap0CPU100tasks64/210scope180inner+10kill240launcher/metadata30+5/45outer/postidentity30/control15/inputcaps and conservativeconsume unchanged. PhysicalfullMaleCNSPX4dual4GiB/4Gswap0CPU100tasks256/330scope315inner360outer300worker/25s1ms250Hz10Hz160x120near.2far19.1/anchor1mm1mrad/originalprecision/sensors/velocity/safetyRTF. Truthabort/auditonly,neverVIOteachertraining,pidfdfailclosed nofallback/sysctl/privilege. PNG7native/Kalibrfullnoise/toolchain/observability/PX4firmware/fulllearningfairbaseline goals unchanged.

Archive seals firsttwo softwarecriteria done/pubpending;receipt/deliveryaudit/stage/Gitidentities/pubsolebyte/PR/automation/NEXT_PHASE are postseal separate,raw/source/ZIPneverbackfilled. onlypersonalneverorigin/draftPR65exactCRLFonly/softwarependingDONT_NOTIFY.
'''
with (root/'docs/MEMBRANE_DYNAMICS_PRODUCTION_REPORT.md').open('x',encoding='utf-8',newline='') as f:f.write(report)
s=(root/'results/csr-runtime-production-dev-1701/seal.py').read_text().replace('tests/connectome_training/test_csr_runtime.py\',\'src','tests/connectome_training/test_membrane_dynamics.py\',\'src',1).replace('docs/CSR_RUNTIME_PRODUCTION_REPORT.md','docs/MEMBRANE_DYNAMICS_PRODUCTION_REPORT.md').replace('2026-10-16-csr-runtime-production','2026-10-16-membrane-dynamics-production').replace('evidence/sequence-corpus-production-publication.json','evidence/csr-runtime-production-publication.json').replace('evidence/csr-runtime-production-dev-1701.zip','evidence/membrane-dynamics-production-dev-1701.zip').replace('csr-runtime-production-map-v1','membrane-dynamics-production-map-v1').replace('TinyCPU explicit CSR production wiring/software only','TinyCPU explicit membrane dynamics software only')
save('seal.py',s)
print('preseal report/plan/reviewjoins/onefixledger/sealhelper ready')
