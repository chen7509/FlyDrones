import math
from dataclasses import replace

import numpy as np
import pytest
import torch
from scipy import sparse
from test_learning_roles import config as _config
from test_learning_roles import inert_backends as _inert

from flydrones.brain.connectome import Connectome
from flydrones.connectome_training.model import ConnectomeConstrainedCore
from flydrones.connectome_training.parameters import build_structure_identity, initial_parameter_set

config = _config
inert_backends = _inert
EXP = "frozen-drive-exponential-v1"


def scalar_core(**kwargs):
    graph = Connectome("scalar", sparse.csc_matrix((2, 2), dtype=np.float32), np.array(["x", "x"]), np.array(["", ""]))
    parameters = initial_parameter_set(build_structure_identity(graph, "a" * 64), ("feature",), ("out",), np.array([0]))
    parameters = replace(parameters, readout=np.array([[1.0]], np.float32))
    return ConnectomeConstrainedCore(graph, parameters, **kwargs).double()


def test_legacy_twenty_hz_clips_timeconstant_gradient_control():
    model = scalar_core()
    command, state = model.forward_step(torch.tensor([[0.4]], dtype=torch.float64), model.initial_state(1), 0.05)
    state.voltage.square().sum().backward()
    assert model.raw_tau_m.grad.item() == 0
    assert state.voltage[0, 0].item() == pytest.approx(0.4)
    assert command.item() == pytest.approx(math.tanh(1 / (1 + math.exp(-0.4))))


@pytest.mark.parametrize("topology", ["coo_reference", "csr_compact_v1"])
def test_actual_twenty_hz_timeconstant_gradient_and_update(topology):
    model = scalar_core(dynamics_format=EXP, topology_format=topology)
    optimizer = torch.optim.SGD(model.parameters(), lr=0.1)
    before = model.raw_tau_m.detach().clone()
    _, state = model.forward_step(torch.tensor([[0.4]], dtype=torch.float64), model.initial_state(1), 0.05)
    state.voltage.square().sum().backward()
    assert torch.isfinite(model.raw_tau_m.grad).all() and model.raw_tau_m.grad.abs().item() > 1e-5
    optimizer.step()
    assert not torch.equal(model.raw_tau_m, before)


def test_held_drive_exact_scalar_solution_and_unequal_intervals():
    model = scalar_core(dynamics_format=EXP)
    features = torch.tensor([[0.4]], dtype=torch.float64)
    state = model.initial_state(1)
    elapsed = 0
    tau = model.tau_m_ms.item()
    for dt in (0.012, 0.05, 0.003):
        _, state = model.forward_step(features, state, dt)
        elapsed += dt
        assert state.voltage[0, 0].item() == pytest.approx(0.4 * (1 - math.exp(-elapsed * 1000 / tau)), abs=1e-13)


def test_sequence_uses_actual_twenty_hz_dynamics_and_detach():
    model = scalar_core(dynamics_format=EXP)
    features = torch.tensor([[[0.4], [0.2], [0.3]]], dtype=torch.float64, requires_grad=True)
    _, state = model.forward_sequence(features, truncate_steps=2)
    state.voltage.sum().backward()
    assert features.grad[0, :2].abs().sum().item() == 0
    assert features.grad[0, 2].abs().item() > 0
    assert model.raw_tau_m.grad.abs().item() > 1e-5
