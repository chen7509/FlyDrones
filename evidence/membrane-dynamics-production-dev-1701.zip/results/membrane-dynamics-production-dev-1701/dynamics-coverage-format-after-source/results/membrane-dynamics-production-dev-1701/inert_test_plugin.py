"""Explicit software test protocol, no host resource observation or children."""
import pytest


@pytest.fixture(autouse=True)
def software_only(monkeypatch):
    import torch
    from flydrones.connectome_training import curriculum_session
    from tools.benchmark.software_process_boundary import install
    install(monkeypatch)
    monkeypatch.setattr(torch.cuda, 'is_available', lambda: False)
    monkeypatch.setattr(curriculum_session, '_peak_process_memory_bytes', lambda: 0)
