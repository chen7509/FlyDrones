# Track geometry audit reproduction

This is an offline development-data diagnostic. `openvins-texture-dev-1701.zip`
(SHA-256 `82f9377c1ad11f824064e1cbbc5feb834f77803af3ec83d00bfb0c8355072ddd`)
contains the original RGB/ULog episode and runner. The current ZIP contains
the diagnostic trace, patch, fixed config, Python scorer and all per-attempt
results. Verify both ZIP indexes before using them. No PX4 or Gazebo process is
needed for scoring.

The source patch applies to upstream OpenVINS commit
`69488123ed9362dd44b6f28e7f4680abbff1442b`; build its `ov_msckf_lib`
target with the isolated ROS-free setup used in the preceding rejection report.
The 293 MB diagnostic library is deliberately not archived; see
`metadata.json` for its exact SHA-256 and size. Replaying the 604 frames must
produce the state CSV hash
`f0f1966527c80bc49a5d219053a3e9c282aeb04eab7439dccd0fe3d265f8740f`
before geometry scoring is accepted.

From the repository root with Python, NumPy and pyulog installed, run the
following against a *new* output directory (the CLI refuses to overwrite):

```sh
python3 tools/benchmark/audit_openvins_track_geometry.py \
  --trace results/openvins-track-geometry/replay-v1/stderr.txt \
  --ulog results/openvins-texture-dev/episode-v1/px4-ulog/log/2026-10-03/01_28_24.ulg \
  --state-csv results/openvins-track-geometry/replay-v1/states.csv \
  --original-state-csv results/openvins-texture-dev/openvins-run-v2/states.csv \
  --config results/openvins-texture-dev/config-v2/kalibr_imucam_chain.yaml \
  --output-dir results/openvins-track-geometry/audit-reproduction
```

Check `attempts.csv` has 183 rows, including all 5 nonpositive-depth cases,
and `summary.json` has 1001 observations, 178 scored positive-depth attempts,
and no unscored reference gaps. EKF2 poses are offline diagnostics, not VIO or
ground truth. Do not use this script to supply estimator or controller state.
