"""Add logging-only post-clean track export to an isolated pinned OpenVINS copy."""

import sys
from pathlib import Path


root = Path(sys.argv[1])
source = root / "ov_msckf/src/update/UpdaterMSCKF.cpp"
text = source.read_text()
old = "  const size_t fd_after_clean = feature_vec.size();\n"
new = """  const size_t fd_after_clean = feature_vec.size();
  for (const auto &fd_feature : feature_vec) {
    size_t fd_measurements = 0;
    for (const auto &fd_camera : fd_feature->timestamps)
      fd_measurements += fd_camera.second.size();
    std::fprintf(stderr, "FD_TRACK_START t=%.9f id=%zu n=%zu\\n",
                 state->_timestamp, fd_feature->featid, fd_measurements);
    for (const auto &fd_camera : fd_feature->timestamps) {
      for (size_t fd_i = 0; fd_i < fd_camera.second.size(); ++fd_i) {
        const auto &fd_uv = fd_feature->uvs_norm.at(fd_camera.first).at(fd_i);
        std::fprintf(stderr,
                     "FD_TRACK_OBS t=%.9f id=%zu cam=%zu obs_t=%.9f u=%.9f v=%.9f\\n",
                     state->_timestamp, fd_feature->featid, fd_camera.first,
                     fd_camera.second.at(fd_i), (double)fd_uv(0), (double)fd_uv(1));
      }
    }
  }
"""
if text.count(old) != 1:
    raise RuntimeError("expected one insertion point")
source.write_text(text.replace(old, new))
