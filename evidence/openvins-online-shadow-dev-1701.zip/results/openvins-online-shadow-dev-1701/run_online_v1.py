"""Prospective one-run launcher; preserves all files and pre/post provenance."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(root), str(root/'src')]
from tools.benchmark.capture_disarmed_sensors import active_resources

output = Path(__file__).resolve().parent
assert not active_resources(), 'competing resource exists'
up = Path('/home/yuchen7509/flydrones-upstream/open_vins_vio_init_probe')
px4 = Path('/home/yuchen7509/PX4-Autopilot')
sources = output/'upstream-snapshots-v3'
sources.mkdir(exist_ok=False)
for rel in ['ov_msckf/src/core/VioManager.cpp','ov_msckf/src/core/VioManagerHelper.cpp',
            'ov_msckf/src/core/VioManager.h','ov_msckf/src/state/Propagator.cpp','ov_init/src/init/InertialInitializer.cpp']:
    target = sources/rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(up/rel, target)
(sources/'LICENSE').write_bytes(subprocess.check_output(['git','-C',str(up),'show','HEAD:LICENSE']))
(sources/'upstream.diff').write_bytes(subprocess.check_output(['git','-C',str(up),'diff']))
files = [root/'tools/benchmark'/name for name in ['capture_disarmed_sensors.py','disarmed_sensor_provenance.py',
         'openvins_causal_input.py','openvins_online_shadow.py','openvins_online_probe.cpp','openvins_fast_probe.h','exclusive_probe_output.h']]
files += list((output/'raw-model-zero-bias-diffusion-v1').glob('*'))
files += [output/'online_probe',up/'ov_msckf/build/libov_msckf_lib.so',px4/'build/px4_sitl_default/bin/px4']
files += list((root/'assets/gazebo/models').glob('*/model.sdf'))
files += [px4/'Tools/simulation/gz/models/x500_base/model.sdf']
def snapshot(name):
    directory = output/name
    directory.mkdir(exist_ok=False)
    rows=[]
    for i, file in enumerate(files):
        data=file.read_bytes()
        rows.append(dict(path=str(file), sha256=hashlib.sha256(data).hexdigest(), bytes=len(data)))
        if file.suffix in ['.py','.cpp','.h','.yaml','.json','.sdf']:
            (directory/(str(i)+'-'+file.name)).write_bytes(data)
    (directory/'manifest.json').write_text(json.dumps(rows,indent=2))
    return rows
before=snapshot('producer-before')
with (output/'resource-preflight.json').open('x') as f:
    json.dump(dict(wall_ns=time.time_ns(),competing=active_resources()),f,indent=2)
command=[sys.executable,str(root/'tools/benchmark/capture_disarmed_sensors.py'),
         '--output',str(output/'capture-v1'),'--shadow-binary',str(output/'online_probe'),
         '--shadow-config',str(output/'raw-model-zero-bias-diffusion-v1/estimator_config.yaml')]
with (output/'online-launch.json').open('x') as f:
    json.dump(dict(command=command,started_wall_ns=time.time_ns()),f,indent=2)
with (output/'capture-v1-console.txt').open('x') as log:
    completed=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
after=snapshot('producer-after')
with (output/'online-exit.json').open('x') as f:
    json.dump(dict(exit=completed.returncode, unchanged=before==after,competing_after=active_resources(),
                   finished_wall_ns=time.time_ns()),f,indent=2)
print(json.dumps(dict(exit=completed.returncode,unchanged=before==after)))
