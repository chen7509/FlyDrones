"""Exclusive evidence archive with per-member manifest; no prior evidence is overwritten."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

root=Path(__file__).resolve().parents[2]
base=Path(__file__).resolve().parent
snapshot=base/'final-source'
snapshot.mkdir(exist_ok=False)
files=[
 'tools/benchmark/openvins_online_shadow.py','tools/benchmark/openvins_online_probe.cpp',
 'tools/benchmark/openvins_fast_probe.h','tools/benchmark/exclusive_probe_output.h',
 'tools/benchmark/openvins_causal_input.py','tools/benchmark/disarmed_sensor_provenance.py',
 'tools/benchmark/capture_disarmed_sensors.py','tools/benchmark/check_online_native_protocol.py',
 'tools/benchmark/check_native_setup_cleanup.py','tests/benchmark/test_openvins_online_shadow.py',
 'docs/OPENVINS_ONLINE_SHADOW_REPORT.md','docs/superpowers/specs/2026-10-06-openvins-online-shadow.md',
 'docs/superpowers/plans/2026-10-06-openvins-online-shadow.md',
 '.superpowers/sdd/2026-10-06-openvins-online-shadow/progress.md',
 '.superpowers/sdd/2026-10-06-openvins-online-shadow/review-ce61a0e..066e9f9.diff']
for name in files:
    target=snapshot/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(root/name,target)
with (base/'sealed-head.json').open('x') as f:
    json.dump(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
                   status=subprocess.check_output(['git','status','--short'],cwd=root,text=True)),f,indent=2)
members={}
archive=root/'evidence/openvins-online-shadow-dev-1701.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(base.rglob('*')):
        if not path.is_file():
            continue
        name=path.relative_to(root).as_posix()
        data=path.read_bytes()
        members[name]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
        z.writestr(name,data)
    z.writestr('SHA256-MANIFEST.json',json.dumps(members,indent=2,sort_keys=True).encode())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(members)+1
    for name,meta in members.items():
        data=z.read(name)
        assert len(data)==meta['bytes'] and hashlib.sha256(data).hexdigest()==meta['sha256']
seal=dict(path=str(archive),bytes=archive.stat().st_size,members=len(members)+1,
          sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
with (base/'seal.json').open('x') as f:
    json.dump(seal,f,indent=2)
print(json.dumps(seal))
