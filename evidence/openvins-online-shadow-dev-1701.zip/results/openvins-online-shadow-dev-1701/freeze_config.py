import hashlib
import json
from pathlib import Path
import re
import sys
import time

root = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(root), str(root/'src')]
from tools.benchmark.openvins_causal_input import raw_profile

output = Path(__file__).resolve().parent/'raw-model-zero-bias-diffusion-v1'
output.mkdir(exist_ok=False)
prior = root/'results/openvins-board-pattern-dev-1701/dependencies-v1/config-v2'
noise = raw_profile()['noise']
values = dict(accelerometer_noise_density=noise['accel']['scalar_density_envelope'],
              gyroscope_noise_density=noise['gyro']['scalar_density_envelope'],
              accelerometer_random_walk=0., gyroscope_random_walk=0.)
hashes = {}
for name in ['estimator_config.yaml','kalibr_imucam_chain.yaml','kalibr_imu_chain.yaml']:
    data = (prior/name).read_bytes()
    if name == 'kalibr_imu_chain.yaml':
        text = data.decode()
        for key, value in values.items():
            text, count = re.subn(r'(^  '+key+r':) [^\n]+', r'\g<1> '+format(value,'.17g')+'  # uncalibrated simulated-model assumption', text, flags=re.M)
            assert count == 1
        data = text.encode()
    with (output/name).open('xb') as stream:
        stream.write(data)
    hashes[name] = hashlib.sha256(data).hexdigest()
with (output/'freeze.json').open('x') as stream:
    json.dump(dict(name=output.name, frozen_wall_ns=time.time_ns(), applied_values=values, sha256=hashes,
                   covariance_calibrated=False, eligible_for_px4_fusion=False,
                   bias_scope='zero diffusion in ideal SDF model only; not real or empirical bias calibration',
                   source_profile=raw_profile()), stream, indent=2)
print(json.dumps(values))
