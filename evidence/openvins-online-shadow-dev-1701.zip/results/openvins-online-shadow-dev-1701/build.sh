#!/usr/bin/env bash
set -euo pipefail
cd /mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility
out=results/openvins-online-shadow-dev-1701
upstream=/home/yuchen7509/flydrones-upstream/open_vins_vio_init_probe
test ! -e "$out/online_probe"
test "$(git -C "$upstream" rev-parse HEAD)" = 69488123ed9362dd44b6f28e7f4680abbff1442b
printf '%s  %s\n' 532ae57a6a952a0137cc1de291bc47ad556d419c7524fbb23b7a90c00addab5b "$upstream/ov_msckf/build/libov_msckf_lib.so" | sha256sum -c -
g++ -std=c++17 -O2 -DENABLE_ARUCO_TAGS=1 -DROS_AVAILABLE=0 \
 -I"$upstream/ov_msckf/src" -I"$upstream/ov_core/src" -I"$upstream/ov_init/src" -I/usr/include/eigen3 \
 tools/benchmark/openvins_online_probe.cpp -L"$upstream/ov_msckf/build" \
 -Wl,-rpath,"$upstream/ov_msckf/build" -lov_msckf_lib \
 $(pkg-config --cflags --libs opencv4) -lboost_thread -lboost_system -lboost_filesystem -o "$out/online_probe"
sha256sum "$out/online_probe" tools/benchmark/openvins_online_probe.cpp tools/benchmark/openvins_fast_probe.h
g++ --version
ldd "$out/online_probe"
