"""Read-only audit of both retained online attempts; no estimator/simulation replay."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
from pyulog import ULog

root=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(root),str(root/'src')]
from tools.benchmark.disarmed_sensor_provenance import audit_event_records
from tools.benchmark.openvins_online_shadow import validate_ack

base=Path(__file__).resolve().parent
def readlines(path):
    return [json.loads(line) for line in path.read_text().splitlines()]
def stats(values):
    return dict(count=len(values),min=float(np.min(values)),median=float(np.median(values)),
                p95=float(np.percentile(values,95)),max=float(np.max(values))) if values else None

audits=[]
for name in ['capture-v1','capture-v2']:
    p=base/name
    result=json.loads((p/'result.json').read_text())
    rows=readlines(p/'events.jsonl')
    counts=audit_event_records(rows,required_kinds={'imu','rgb','info','depth'})
    requests=readlines(p/'shadow/native-requests.jsonl')
    acks=readlines(p/'shadow/native-acks.jsonl')
    states=readlines(p/'shadow/states.jsonl')
    predictions=readlines(p/'shadow/fast.jsonl')
    assert len(requests)==len(acks)==result['native']['accepted']
    assert [r['sequence'] for r in requests]==list(range(len(requests)))
    raw_imus={r['sample_ns']:r for r in rows if r['kind']=='imu'}
    rgb={r['sample_ns']:r for r in rows if r['kind']=='rgb'}
    infos={r['sample_ns']:r for r in rows if r['kind']=='info'}
    raw_bases=[r for r in rows if r['kind'] in {'imu','rgb','info'}]
    latest_imu=-1
    payload_checked=0
    for request,ack in zip(requests,acks):
        action=request['action']
        kind=action['kind']
        assert request['sequence']==ack['sequence']
        validate_ack(ack,sequence=request['sequence'],kind={'imu':'I','camera':'C'}[kind],
                     dispatch_ns=request['dispatch_ns'],acknowledged_ns=ack['acknowledged_ns'])
        assert action['source_arrival_ns'] <= request['dispatch_ns']
        assert ack['quality'] is None and ack['reset_counter'] is None and not ack['fusion_eligible']
        if kind=='imu':
            raw=raw_imus[action['sample_ns']]
            assert action['wm']==raw['gyro_frd'] and action['am']==raw['accel_frd']
            latest_imu=action['sample_ns']
        else:
            stamp=action['sample_ns']
            assert latest_imu==action['imu_boundary_ns']>stamp
            assert raw_bases[action['rgb_sequence']]['sample_ns']==stamp
            assert raw_bases[action['info_sequence']]['sample_ns']==stamp
            assert raw_bases[action['imu_boundary_sequence']]['sample_ns']==latest_imu
            raw=(p/'rgb-frames'/f'{stamp}.ppm').read_bytes().split(b'\n',3)[3]
            assert len(raw)==57600 and hashlib.sha256(raw).hexdigest()==request['rgb_sha256']
            assert rgb[stamp]['arrival_monotonic_ns']==action['source_arrival_ns']
            assert infos[stamp]['sample_ns']==stamp
            payload_checked+=1
    assert len(states)==payload_checked
    assert all(s['sequence'] in {a['sequence'] for a in acks if a['kind']=='C'} for s in states)
    assert len({p['target_ns'] for p in predictions})==len(predictions)
    assert all(p['available_imu_ns']>p['target_ns'] for p in predictions)
    assert all(b['target_ns']-a['target_ns']==20_000_000 for a,b in zip(predictions,predictions[1:]))
    numeric=[]
    for prediction in predictions:
        ack=acks[prediction['trigger_sequence']]
        assert ack['kind']=='I' and ack['sample_ns']==prediction['available_imu_ns']
        assert ack['start_ns']<=prediction['native_begin_ns']<=prediction['native_end_ns']<=ack['end_ns']
        assert prediction['filter_unchanged'] and prediction['quality'] is None and not prediction['fusion_eligible']
        if prediction['success']:
            v=np.asarray(prediction['state13']); c=np.asarray(prediction['covariance12'])
            assert v.shape==(13,) and c.shape==(12,12) and np.isfinite(v).all() and np.isfinite(c).all()
            eig=np.linalg.eigvalsh((c+c.T)/2)
            numeric.append(dict(quat_error=abs(np.linalg.norm(v[:4])-1),sym_error=np.max(abs(c-c.T)),minimum_eigenvalue=float(eig.min())))
    ulogs=[]
    for meta in result['px4_ulogs']:
        file=p/meta['path']
        assert hashlib.sha256(file.read_bytes()).hexdigest()==meta['sha256']
        ulg=ULog(str(file))
        status=ulg.get_dataset('vehicle_status').data
        arming=status['arming_state']
        assert np.all(arming!=2)
        ulogs.append(dict(path=meta['path'],sha256=meta['sha256'],arming_records=len(arming),
                          arming_values=[int(x) for x in np.unique(arming)]))
    heartbeats=[r for r in rows if r['kind']=='heartbeat']
    assert all(not r['base_mode']&128 for r in heartbeats)
    if name=='capture-v2':
        assert result['status']=='capture_completed' and result['end_sim_ns']==25_000_000_000
        assert counts['imu']==6251 and counts['rgb']==counts['info']==counts['depth']==251
        assert len(states)==250 and len(heartbeats)>0
        assert result['shadow']['pending'][0]['reason']=='later_imu_missing'
    latencies={}
    for k in ['I','C']:
        selected=[a for a in acks if a['kind']==k]
        latencies[k]=dict(processing_ms=stats([(a['end_ns']-a['start_ns'])/1e6 for a in selected]),
                         callback_to_native_end_ms=stats([(a['end_ns']-a['source_arrival_ns'])/1e6 for a in selected]),
                         callback_to_ack_ms=stats([(a['acknowledged_ns']-a['source_arrival_ns'])/1e6 for a in selected]))
    initialized=[s for s in states if s.get('internal_initialized')]
    public=[s for s in states if s.get('public_initialized')]
    audits.append(dict(capture=name,status=result['status'],errors=result['errors'],counts=counts,
        requested_sim_s=25,completed_sim_s=result['end_sim_ns']/1e9,capture_wall_s=result['capture_wall_s'],
        native_acknowledgements=len(acks),pixel_pairs_verified=payload_checked,internal_initialized_frames=len(initialized),
        public_initialized_frames=len(public),first_internal=initialized[0] if initialized else None,
        first_public=public[0] if public else None,zupt_frames=sum(s.get('zupt_flag_latched',False) for s in states),
        fast_targets=len(predictions),fast_success=sum(p['success'] for p in predictions),
        fast_public=sum(p['public_initialized'] for p in predictions),
        fast_target_boundary_ms=stats([(p['available_imu_ns']-p['target_ns'])/1e6 for p in predictions]),
        fast_numeric_checks=dict(count=len(numeric),max_quat_error=max([r['quat_error'] for r in numeric] or [0]),
                                max_cov_sym_error=max([r['sym_error'] for r in numeric] or [0]),
                                min_cov_eigenvalue=min([r['minimum_eigenvalue'] for r in numeric] or [0])),
        latencies=latencies,ulog=ulogs,unarmed_heartbeats=len(heartbeats),fusion_eligible=False,
        timing_scope='actual callback arrival to native processing/end/ack; not sample-generation wall latency or real flight',
        noise_calibrated=False))
with (base/'online-audit.json').open('x') as stream:
    json.dump(audits,stream,indent=2)
print(json.dumps([{k:v for k,v in a.items() if k not in ['first_internal','first_public']} for a in audits],indent=2))
