# One fresh-context branch review

Reviewer: /root/review_online_shadow, gpt-6-astra. Scope ce61a0e..066e9f9. Read-only; no test/native/simulation/audit rerun or edits. Returned3Important,0Critical,0Minor.

1. NativeClient constructor can leak descriptors and a live child after partial file/pipe setup, set_blocking failure or native-session metadata failure before caller cleanup registration. Fix: exception-safe acquisition of every resource and terminate/reap an already-launched owned child on failure.
2. CausalInput removes an entire released batch before delivery; failure of its first action omits later cameras from causal.finish and request records. Camera pixels were popped before acknowledgement. Fix: explicit failed/unattempted action dispositions and retained pixel ownership until acknowledgement, including causal source references.
3. Frozen manifest checks did not prove the config actually launched belonged to that manifest. An unlisted other.yaml or empty manifest passed. Fix: require selected estimator and both referenced calibration files to be the exact verified set; reject unlisted/empty/missing/escaping entries.

Reviewer found the v1/v2 limited evidence/report consistent: v1 startup failure, v2 completed25s,6501ack,250images,1129/1250predictions,0public-ready. ZUPT explanation matches fixed upstream. Timing scope and uncalibratedzero diffusion are explicit; inspected724-passed regression log.

Declined to judge: no independent numerical/hash/ULog rerun, binary rebuild or visual pixel inspection; no dynamic calibration, flight, EKF2 fusion, real-time capacity or physical safety qualification. These are retained limitations, not claims made by this stage.

# One fix pass

All3findings accepted Important. Eight new unit cases failed before correction (batch failure atIMU/camera, selected config/reference cases) then passed. Five real POSIX setup fault injections showed leaked resources/live child in RED, then no remaining child/FD in GREEN. ExitStack owns partial setup; batch ledger preserves failed and never-attempted actions, pixel hashes and source indices; selected config/calibration set is now exact and hashed.65focused tests green; final15synthetic native protocol checks pass, blocked writer refused in0.2519s. Final full regression is recorded separately.

No second independent review or new physical/estimator replay. The successful capture-v2 remains produced by its sealed pre-review source snapshot. Hardened failure paths are supported by targeted synthetic tests and regression; they are not represented as a new live run. Native C++ binary/library/config unchanged.
