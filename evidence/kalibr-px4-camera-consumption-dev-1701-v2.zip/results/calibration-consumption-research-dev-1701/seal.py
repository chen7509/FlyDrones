import hashlib
import json
import zipfile
from pathlib import Path

out = Path(__file__).resolve().parent
root = out.parents[1]
old = json.loads((root / 'results/owned-logger-source-association-dev-1701/twelve-original-archives-after.json').read_text())
old['evidence/owned-ulog-source-association-dev-1701.zip'] = 'd7c022cf53d1a5347b798b18c152647d59c2835a7e50f7649bb00880cdc804d1'
for name, expected in old.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
with (out / 'thirteen-original-archives-after.json').open('x', encoding='utf8') as stream:
    json.dump(old, stream, indent=2)
names = ['src/flydrones/benchmark/kalibr_camera_consumption.py', 'src/flydrones/benchmark/px4_camera_source.py',
         'tools/benchmark/produce_px4_camera_file.py', 'tests/benchmark/test_kalibr_camera_consumption.py',
         'docs/KALIBR_PX4_CAMERA_CONSUMPTION_REPORT.md',
         'docs/superpowers/specs/2026-10-14-kalibr-px4-camera-consumption.md',
         'docs/superpowers/plans/2026-10-14-kalibr-px4-camera-consumption.md']
files = sorted(set([root / p for p in names] + [p for p in out.rglob('*')
                   if p.is_file() and '__pycache__' not in p.parts]))
members = {p.relative_to(root).as_posix(): {'bytes': p.stat().st_size,
           'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
archive = root / 'evidence/kalibr-px4-camera-consumption-dev-1701.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for p in files:
        z.write(p, p.relative_to(root).as_posix())
    z.writestr('archive-members.json', json.dumps({'members': members,
                 'genuine_measured_calibration': False, 'actual_px4_native_optimizer_execution': False}, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(set(z.namelist())) == len(members)+1
    for name, row in members.items():
        data = z.read(name)
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
record = {'archive': archive.relative_to(root).as_posix(), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
          'bytes': archive.stat().st_size, 'members': len(members)+1,
          'report_sha256': members[names[4]]['sha256'], 'prepublication_plan_sha256': members[names[6]]['sha256'],
          'genuine_measured_calibration': False, 'actual_px4_native_optimizer_execution': False}
with (root / 'evidence/kalibr-px4-camera-consumption-seal.json').open('x', encoding='utf8') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record))
