import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

out = Path(__file__).resolve().parent
root = out.parents[1]
sources = ['src/flydrones/benchmark/kalibr_camera_consumption.py', 'src/flydrones/benchmark/px4_camera_source.py',
           'tools/benchmark/produce_px4_camera_file.py', 'tests/benchmark/test_kalibr_camera_consumption.py']
tests = ['test_kalibr_camera_consumption', 'test_px4_camera_source', 'test_px4_camera_file_cli',
         'test_camera_imu_dataset', 'test_camera_imu_dataset_cli']
env = dict(os.environ, PYTHONPATH='src;.', PYTHONUTF8='1')
commands = {'final-tests': [sys.executable, '-m', 'pytest', '-q',
                          *['tests/benchmark/' + t + '.py' for t in tests], '--basetemp', str(out / 'final-fixtures')],
            'final-ruff': [sys.executable, '-m', 'ruff', 'check', *sources], 'final-diff': ['git', 'diff', '--check']}
for name, argv in commands.items():
    record = {'argv': argv, 'cwd': str(root), 'started_utc': datetime.now(timezone.utc).isoformat(),
              'environment_override': {'PYTHONPATH': 'src;.', 'PYTHONUTF8': '1'},
              'source_sha256_before': {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in sources}}
    with (out / (name+'.txt')).open('xb') as stream:
        p = subprocess.run(argv, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=60)
    record.update(exit_code=p.returncode, completed_utc=datetime.now(timezone.utc).isoformat())
    with (out / (name+'.json')).open('x', encoding='utf8') as stream:
        json.dump(record, stream, indent=2)
    print(name, p.returncode)
