"""Seal the exact Agent source-research evidence once, including member hashes."""

from __future__ import annotations

import hashlib
import json
import zipfile
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DESTINATION = ROOT / "evidence/px4-agent-v243-source-research-dev-1701.zip"
MEMBERS = (
    "docs/PX4_AGENT_V243_SOURCE_READINESS_REPORT.md",
    "results/px4-agent-v243-source-dev-1701/capture_source_provenance.py",
    "results/px4-agent-v243-source-dev-1701/capture-console.txt",
    "results/px4-agent-v243-source-dev-1701/source-provenance.json",
    "results/px4-agent-v243-source-dev-1701/upstream/CMakeLists.txt",
    "results/px4-agent-v243-source-dev-1701/upstream/cmake/SuperBuild.cmake",
    "results/px4-agent-v243-source-dev-1701/upstream/Dockerfile",
    "results/px4-agent-v243-source-dev-1701/upstream/LICENSE",
    "results/px4-agent-v243-source-dev-1701/upstream/README.md",
    "results/px4-agent-v243-source-dev-1701/seal.py",
)


def main() -> None:
    if DESTINATION.exists():
        raise FileExistsError(DESTINATION)
    payload = {}
    manifest = {"schema": "flydrones.evidence_manifest.v1", "members": {}}
    for member in MEMBERS:
        path = ROOT / member
        if path.is_symlink() or not path.is_file():
            raise FileNotFoundError(path)
        raw = path.read_bytes()
        payload[member] = raw
        manifest["members"][member] = {
            "sha256": hashlib.sha256(raw).hexdigest(),
            "bytes": len(raw),
            "crc32": f"{zlib.crc32(raw):08x}",
        }
    manifest_raw = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    DESTINATION.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DESTINATION, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for member, raw in payload.items():
            archive.writestr(member, raw)
        archive.writestr("manifest.json", manifest_raw)
    with zipfile.ZipFile(DESTINATION) as archive:
        if archive.testzip() is not None:
            raise ValueError("ZIP CRC failed")
        sealed = json.loads(archive.read("manifest.json"))
        if set(archive.namelist()) != set(MEMBERS) | {"manifest.json"}:
            raise ValueError("ZIP member set changed")
        for member, expected in sealed["members"].items():
            raw = archive.read(member)
            if (len(raw) != expected["bytes"]
                    or hashlib.sha256(raw).hexdigest() != expected["sha256"]
                    or f"{zlib.crc32(raw):08x}" != expected["crc32"]):
                raise ValueError(f"ZIP member changed: {member}")
    print(json.dumps({
        "path": str(DESTINATION),
        "sha256": hashlib.sha256(DESTINATION.read_bytes()).hexdigest(),
        "members": len(MEMBERS) + 1,
        "crc_and_hash_verified": True,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
