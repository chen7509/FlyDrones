"""Capture exact read-only Agent source and observed dependency ref identities."""

from __future__ import annotations

import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
UPSTREAM = HERE / "upstream"
OUT = HERE / "source-provenance.json"
AGENT_COMMIT = "73622810d984349b80bbac0ef55fc0b694d62222"
DEPS = {
    "fast_cdr": ("https://github.com/eProsima/Fast-CDR.git", "refs/heads/2.2.x"),
    "fast_dds": ("https://github.com/eProsima/Fast-DDS.git", "refs/heads/2.14.x"),
    "foonathan_memory": ("https://github.com/foonathan/memory.git", "refs/tags/v0.7-3"),
    "spdlog": ("https://github.com/gabime/spdlog.git", "refs/tags/v1.9.2"),
    "xrce_client": ("https://github.com/eProsima/Micro-XRCE-DDS-Client.git", "refs/tags/v2.4.3"),
}
SELECTED = ("CMakeLists.txt", "cmake/SuperBuild.cmake", "LICENSE", "README.md", "Dockerfile")


def git(*args: str) -> bytes:
    return subprocess.run(["git", *args], check=True, capture_output=True).stdout.strip()


def main() -> None:
    if OUT.exists():
        raise FileExistsError(OUT)
    head = git("-C", str(UPSTREAM), "rev-parse", "HEAD").decode()
    if head != AGENT_COMMIT or git("-C", str(UPSTREAM), "status", "--porcelain"):
        raise ValueError("Agent checkout is not the exact clean v2.4.3 source")
    cmake = (UPSTREAM / "CMakeLists.txt").read_text(encoding="utf-8")
    if not all(item in cmake for item in (
        'option(UAGENT_SUPERBUILD "Enable superbuild compilation." ON)',
        "set(_fastcdr_tag 2.2.x)",
        "set(_fastdds_tag 2.14.x)",
    )):
        raise ValueError("Agent dependency declarations changed")
    refs = {}
    for name, (url, ref) in DEPS.items():
        rows = git("ls-remote", url, ref).decode().splitlines()
        if len(rows) != 1 or rows[0].split("\t")[-1] != ref:
            raise ValueError(f"dependency ref ambiguous or unavailable: {name}")
        commit = rows[0].split("\t")[0]
        if len(commit) != 40 or any(char not in "0123456789abcdef" for char in commit):
            raise ValueError(f"dependency hash invalid: {name}")
        refs[name] = {"url": url, "requested_ref": ref, "observed_object": commit,
                      "mutable_branch": ref.startswith("refs/heads/")}
    manifest = {
        "schema": "flydrones.xrce_agent_source_research.v1",
        "observed_utc": datetime.now(timezone.utc).isoformat(),
        "agent_tag": "v2.4.3",
        "agent_commit": head,
        "agent_tree": git("-C", str(UPSTREAM), "rev-parse", "HEAD^{tree}").decode(),
        "tracked_file_count": len(git("-C", str(UPSTREAM), "ls-files", "-z").split(b"\0")) - 1,
        "selected_source_sha256": {
            name: hashlib.sha256((UPSTREAM / name).read_bytes()).hexdigest()
            for name in SELECTED
        },
        "dependency_refs": refs,
        "default_superbuild_reproducible": False,
        "agent_binary_built_or_run": False,
        "px4_agent_interoperability_verified": False,
        "eligible_for_owned_source_trial": False,
    }
    OUT.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"agent_commit": head, "source_file_count": manifest["tracked_file_count"],
                      "dependency_refs": refs, "out_sha256": hashlib.sha256(OUT.read_bytes()).hexdigest()},
                     sort_keys=True))


if __name__ == "__main__":
    main()
