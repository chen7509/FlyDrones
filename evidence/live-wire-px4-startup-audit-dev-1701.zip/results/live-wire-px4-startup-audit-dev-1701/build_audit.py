"""Read-only comparison of the failed wire PX4 startup and earlier completed runs."""

from __future__ import annotations

import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
FAILED = ROOT / "results/live-wire-study-dev-1701/study-v6/capture-v1/px4.log"
COHORT = ROOT / "results/openvins-health-physical-dev-1701-v2"
LOGS = {"failed_v6": FAILED}
LOGS.update({
    seed: COHORT / seed / "capture-v1/px4.log"
    for seed in (
        "development-seed-27201", "held-out-seed-27211",
        "held-out-seed-27212", "held-out-seed-27213",
    )
})
MARKERS = (
    "Gazebo world is ready", "PX4_GZ_MODEL_NAME set",
    "setting initial absolute time", "world: fly_ego_benchmark",
    "[mavlink] mode: Onboard", "Startup script returned successfully",
)
SOURCES = (
    "ROMFS/px4fmu_common/init.d-posix/px4-rc.gzsim",
    "src/modules/simulation/gz_bridge/GZBridge.cpp",
    "platforms/posix/src/px4/common/lockstep_scheduler/src/lockstep_scheduler.cpp",
)
PX4 = "/home/yuchen7509/PX4-Autopilot"


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def wsl(*args: str) -> bytes:
    result = subprocess.run(["wsl.exe", "-e", *args], capture_output=True, check=True)
    return result.stdout


def main() -> None:
    report: dict = {"schema": "flydrones-px4-startup-marker-audit-v1",
                    "physical_run_performed": False, "qualified": False, "logs": {}, "sources": {}}
    archive = ROOT / "evidence/live-wire-first-activation-dev-1701.zip"
    with zipfile.ZipFile(archive) as sealed:
        failed_sealed = sealed.read("results/live-wire-study-dev-1701/study-v6/capture-v1/px4.log")
    assert failed_sealed == FAILED.read_bytes(), "failed v6 local log differs from sealed bytes"
    report["failed_log_matches_sealed_archive_sha256"] = sha(archive.read_bytes())

    for name, path in LOGS.items():
        raw = path.read_bytes()
        lines = raw.decode("utf8", errors="replace").splitlines()
        (OUT / f"{name}.px4.log").write_bytes(raw)
        report["logs"][name] = {
            "sha256": sha(raw), "bytes": len(raw),
            "first_marker_line": {
                marker: next((index + 1 for index, line in enumerate(lines) if marker in line), None)
                for marker in MARKERS
            },
            "last_line": lines[-1] if lines else None,
        }

    commit = wsl("git", "-C", PX4, "rev-parse", "HEAD").decode().strip()
    assert commit == "d6f12ad1c4f70ad3230afd7d86e971421e02fef4", commit
    status = wsl("git", "-C", PX4, "status", "--porcelain", "--", *SOURCES)
    assert not status, "selected PX4 source files are modified"
    report["px4_commit"] = commit
    for source in SOURCES:
        raw = wsl("cat", f"{PX4}/{source}")
        target = OUT / "px4-source" / source
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        report["sources"][source] = {"sha256": sha(raw), "bytes": len(raw)}

    failed_markers = report["logs"]["failed_v6"]["first_marker_line"]
    assert failed_markers[MARKERS[0]] and failed_markers[MARKERS[1]]
    assert all(failed_markers[marker] is None for marker in MARKERS[2:])
    for name, entry in report["logs"].items():
        if name != "failed_v6":
            assert all(entry["first_marker_line"][marker] for marker in MARKERS)
    (OUT / "audit.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf8")


if __name__ == "__main__":
    main()
