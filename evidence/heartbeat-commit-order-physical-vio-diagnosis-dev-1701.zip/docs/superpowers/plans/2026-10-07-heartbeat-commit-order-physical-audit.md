# Heartbeat commit-order physical audit plan

- [x] Add failing tests for immutable-attempt drift, gauge scoring and ZUPT/bias timeline classification.
- [x] Implement the independent physical-attempt audit and fixed-input drift diagnosis.
- [x] Run the audit on `study-v21/capture-v1`, preserve its failed accuracy result and write the stage report.
- [ ] Run focused and full regression, seal evidence, commit, push and update PR 65.

