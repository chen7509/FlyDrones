# Next dependency: bounded runtime mappings

Read `docs/COLLADA_ORDERED_CANDIDATES_REPORT.md`, the v3 pre/post manifests, mapping phase records, current `RuntimeBinding`, and fixed Gazebo SystemLoader / rendering / sensors sources.

Design an independently named prospective contract for actual lazy Gazebo renderer/sensor mappings and the already-owned PX4/OpenVINS processes. Reuse recorded process identities and bounded cleanup; do not scan or govern unrelated processes. Distinguish declared files, self-process bootstrap maps, child process maps, lazy-load coverage, and total runtime closure. Unknown, unreadable, deleted, replaced or out-of-scope mappings keep qualification false. No physics run is authorized merely to enumerate paths until the bounded lifecycle and failure tests are frozen.

After mapping coverage, freeze the trajectory/gauge contract before any online VIO retry. Do not use truth as estimator input, choose a post-hoc origin, weaken the 2-second watchdogs or reduce the fixed physical/sensor load.
