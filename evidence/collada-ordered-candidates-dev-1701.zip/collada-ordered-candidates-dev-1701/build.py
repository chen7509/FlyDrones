import hashlib
import json
import shlex
import shutil
import subprocess
from pathlib import Path

stage = Path(__file__).resolve().parent
root = stage.parents[1]
out = stage / 'build-v1'
out.mkdir(exist_ok=False)


def run(args, name):
    proc = subprocess.run(args, capture_output=True, text=True, timeout=90)
    (out / f'{name}.json').write_text(json.dumps({
        'args': args, 'returncode': proc.returncode,
        'stdout': proc.stdout, 'stderr': proc.stderr,
    }, indent=2))
    if proc.returncode:
        raise RuntimeError(name)
    return proc.stdout


source = root / 'tools/benchmark/native/resource_resolver.cc'
header = source.parent / 'local_candidates.hh'
binary = out / 'resource_resolver'
(out / 'source-before.cc').write_bytes(source.read_bytes())
(out / 'local-candidates-before.hh').write_bytes(header.read_bytes())
tools = []
for name in ('g++', 'pkg-config'):
    path = Path(shutil.which(name))
    tools.append({'name': name, 'path': str(path), 'resolved': str(path.resolve()),
                  'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
(out / 'tools-before.json').write_text(json.dumps(tools, indent=2))
flags = shlex.split(run(['pkg-config', '--cflags', '--libs', 'gz-sim8',
                         'gz-common5-graphics', 'sdformat14'], 'flags'))
run(['g++', '--version'], 'compiler')
run(['pkg-config', '--modversion', 'gz-sim8', 'gz-common5-graphics', 'sdformat14'],
    'versions')
run(['g++', '-std=c++17', '-Wall', '-Wextra', str(source), '-o', str(binary), *flags],
    'compile')
linked = run(['ldd', str(binary)], 'ldd')
paths = {str(source), str(header), str(binary)}
for line in linked.splitlines():
    for word in line.split():
        if word.startswith('/') and Path(word).is_file():
            paths.add(word)
(out / 'build-hashes.json').write_text(json.dumps([
    {'path': item, 'sha256': hashlib.sha256(Path(item).read_bytes()).hexdigest()}
    for item in sorted(paths)
], indent=2))
for script, name in (
        ('run_bound_uri_checks.py', 'bound-green'),
        ('run_uri_resolver_checks.py', 'uri-green'),
        ('run_resource_resolver_checks.py', 'native-regression'),
        ('run_search_context_checks.py', 'search-green')):
    run(['python3', str(root / 'tests/native' / script), str(binary)], name)
print('ordered COLLADA and existing native checks passed')
