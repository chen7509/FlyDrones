import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root=Path(__file__).resolve().parents[2]
out=Path(__file__).parent/sys.argv[1]
out.mkdir(exist_ok=False)
names=['tools/benchmark/run_calibration_capture.py','tools/benchmark/calibration_capture_scope.py',
       'tools/benchmark/calibration_capture_study.py','tools/benchmark/prepare_calibration_capture.py',
       'tools/benchmark/calibration_capture_contract.py','tools/benchmark/capture_contract.py',
       'tools/benchmark/capture_disarmed_sensors.py','tools/benchmark/disarmed_sensor_provenance.py',
       'tests/benchmark/test_calibration_admitted_executor.py',
       'results/target-bearing-runtime-freeze-dev-1701/run-static-preparation.py',
       'results/target-bearing-runtime-freeze-dev-1701/run-recovery-static-preparation.py']
def collect(save=False):
    result={}
    for name in names:
        p=root/name
        if not p.exists():
            result[name]=None
            continue
        data=p.read_bytes();result[name]=hashlib.sha256(data).hexdigest()
        if save:
            target=out/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    return result
argv=sys.argv[2:]
record=dict(argv=argv,cwd=str(root),start_utc=datetime.datetime.now(datetime.UTC).isoformat(),source_before=collect(True),
            env={k:os.environ.get(k) for k in ('PYTHONUTF8','PYTHONPATH','OPENBLAS_NUM_THREADS')})
(out/'command.json').write_text(json.dumps(record,indent=2),encoding='utf8')
with (out/'stdout.bin').open('xb') as stdout,(out/'stderr.bin').open('xb') as stderr:
    done=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr)
record.update(exit=done.returncode,end_utc=datetime.datetime.now(datetime.UTC).isoformat(),source_after=collect())
(out/'completion.json').write_text(json.dumps(record,indent=2),encoding='utf8')
print(json.dumps(dict(argv=argv,exit=done.returncode)))
print((out/'stdout.bin').read_text(encoding='utf8',errors='replace')[-5000:])
print((out/'stderr.bin').read_text(encoding='utf8',errors='replace')[-1000:])
raise SystemExit(done.returncode)
