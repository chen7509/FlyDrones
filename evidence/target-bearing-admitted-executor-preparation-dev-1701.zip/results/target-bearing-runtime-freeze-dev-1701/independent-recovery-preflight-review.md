# Independent recovery preflight review

Assessment: **no concrete blocking finding identified** in the reviewed sealed-Agent deployment and recovery path. Critical 0, Important 0, Minor 0. This is a source/evidence preflight, not native GREEN.

## Recovery boundary

The retained `static-preidentity.json` records the historical Agent executable and all 13 library paths as absent, while the interpreter, existing resolver and sealed scene manifest are present. The reviewed local result listing contains neither the original static-attempt marker nor `frozen-study-v1`. The distinct recovery coordinator therefore targets the same still-prospective study rather than a consumed SDK or physical attempt. The original coordinator and its observations remain preserved.

The specification and plan now explicitly declare this deployment recovery before the first actual static scope. The recovery script uses the sealed bundle as its prerequisite, rechecks fresh dual 1 GiB reserves/no classified competition/no running containers, and retains the same 512 MiB / swap 0 / CPU 100% / Tasks 64 / 210 s scope / 180 s inner / 240 s outer limits. It creates its exclusive recovery marker before Popen, invokes only the static preparation module, and keeps the verified-own-scope and own-Popen cleanup boundaries.

## Agent deployment reviewed

`stage_agent` first checks the original bundle hard SHA and compressed size. It requires the exact expected 14 binary/library names plus `bin` and `lib`, rejects unsupported member types or escaping aliases, and bounds aggregate archive/deployed bytes. It creates an exclusive study-owned deployment directory and writes each name as a regular file containing the original archive member or linked bytes, verifying each against its original hard SHA. It retains archive type/link/mode, deployed file identity, and bundle before/after identity records. The local bundle SHA was independently read and matches the fixed source SHA.

The new Agent configuration uses the deployed binary/library paths and unchanged port 18888. The deployment record is included in the binding inventory. The existing Agent record verifier continues to enforce the same original binary/library hashes and exact library name set. Dependency inspection applies the declared Agent library path only to that deployed binary and its libraries, rather than relying on a historical `/tmp` prefix. No staging operation launches Agent, opens a listener, installs software or rebuilds binaries.

The new fixture exercises actual archive-byte copying with regular members, exclusive destination refusal and changed-bundle refusal. Its 27 reported software passes were not rerun by this reviewer. Actual archive alias handling on the target filesystem and native dependency resolution remain part of the prospective static command; no native proof is inferred from the fixture.

## Remaining evidence obligations

Retain the first actual static scope outcome, exact SDK queries/graph, dependency records, environment, deployment identities and any failures before deciding whether a frozen study exists. Original upstream license/source evidence must remain separately bound as required by the addendum; installed package notices alone do not certify bundled Agent licenses. Physical execution still requires its separate unchanged dual 4 GiB admission and fixed exclusive claim. All eight qualification flags remain false.

No tests, SDK, Agent, systemctl, procfs, resource/permission probes or physics commands were run during this review, and no production source was edited. The paired JSON contains source/spec/plan/script/evidence and bundle hashes. Earlier review files are preserved.