# Independent final preparation code review

Assessment: I5, I6 and I7 are corrected. **One Important/P1 launch blocker remains before first static preparation.** No Critical or Minor findings. This is a source review, not native execution certification.

## Accepted study corrections

`verify_execution_join` now compares the independently observed prepared record with the selected declaration using exact typed equality, and reconstructs the execution using `derive_launch_environment(binding)`. `audit_preparation` now requires unique requested identities and exact baseline-plus-generated-scene membership. The new fixtures exercise changed prepared/environment declarations, extra graph members and duplicate identities. No tests were run by this reviewer.

## I8 — Important / P1: cleaned helper environment cannot reach user systemd

The new static script at `results/target-bearing-runtime-freeze-dev-1701/run-static-preparation.py:55-58` invokes the preparation helper through `env -i`, without `XDG_RUNTIME_DIR` or `DBUS_SESSION_BUS_ADDRESS`. `prepare_calibration_capture.scope_before` then calls `systemctl --user show` (line 57) inheriting that cleaned environment. The physical launcher/helper has the same issue at `calibration_capture_scope.py:62`.

Systemd's direct user-manager connection reads `XDG_RUNTIME_DIR`, otherwise falling back to the default user bus; that fallback returns `ENOMEDIUM` when both variables are absent. This follows the official [user-manager connection implementation](https://raw.githubusercontent.com/systemd/systemd/v255/src/shared/bus-util.c) and [user bus address implementation](https://raw.githubusercontent.com/systemd/systemd/v255/src/libsystemd/sd-bus/sd-bus.c). No local `systemctl` or permission probe was run. The missing environment can consume the static attempt before helper ownership evidence or SDK queries exist.

Give the manager-control subprocess an explicit own-user bus environment derived from the actual Linux UID/runtime directory. Keep this control environment separate from the declared SDK/collector environment. Preserve unknown-identity refusal and do not introduce privilege fallback. Cover the constructed subprocess environment in a software fixture; actual bus/cgroup behavior still requires the single admitted command.

## Static dispatcher boundaries reviewed

The script retains source/preidentity/admission facts, uses an exclusive static marker before Popen, requires dual 1 GiB reserves and no classified competition or running Docker containers, and constructs the fixed static command. It sets 512 MiB MemoryMax, swap zero, CPU 100%, TasksMax 64, scope 210 s, inner timeout 180 s plus 10 s kill-after, and Windows wait 240 s. It invokes only the preparation module; it does not invoke the physical dispatcher. Cleanup calls the existing InvocationID/ControlGroup-verified scope stop and bounds cleanup to its actual Windows Popen. Those are code properties, not measured resource sufficiency or native GREEN.

The original four fixes and interpreter identity join remain accepted by source inspection. All earlier review files are preserved. The paired JSON contains hashes for the nine production/test files and the new static dispatcher. Actual concrete SDK graph/study freeze remains pending, and all eight qualification flags remain false.