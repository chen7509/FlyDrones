import json
from pathlib import Path
from tools.benchmark.run_openvins_dataset_consumer import admission

facts = admission()
with (Path(__file__).parent/'initial-readonly.json').open('x',encoding='utf8') as stream:
    json.dump(facts,stream,indent=2)
print(json.dumps(dict(windows_available=facts['windows_available'],wsl_available=facts['wsl']['available'],
                      blocked=facts['blocked_processes'],docker_exit=facts['docker_exit'],
                      docker_running_empty=not facts['docker_running'].strip(),original_2g_admitted=facts['admitted'])))
