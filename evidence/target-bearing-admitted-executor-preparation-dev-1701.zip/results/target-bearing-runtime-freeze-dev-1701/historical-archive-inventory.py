import hashlib,json
from pathlib import Path
root=Path.cwd();out=root/'results/target-bearing-runtime-freeze-dev-1701'
rows=[]
for p in sorted((root/'evidence').glob('*.zip')):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 rows.append(dict(path=p.relative_to(root).as_posix(),bytes=p.stat().st_size,sha256=h.hexdigest()))
(out/'historical-archives-before-seal.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
print(json.dumps(dict(count=len(rows),bytes=sum(r['bytes'] for r in rows))))
