# Independent corrected preflight review

Assessment: the original four Important findings and the interpreter identity correction are addressed by source inspection. **Three remaining Important study-join gaps should be corrected before publishing a frozen study or claiming the physical attempt.** No Critical or Minor findings.

Read-only review of the same nine source/test files, original specification, catalog and sealed scene references. No tests, native SDK, physics, process/resource/permission polls or production edits. Source hashes for this reviewed snapshot are in the paired JSON. Earlier review files remain unchanged.

## Accepted corrections

- The raw prepared worker validates the input before writing its exclusive environment record; legacy directory-absence behavior remains the default.
- Required system plugins are selected through retained SDK queries from all original prepared SDF files before dependency/baseline construction; the final graph rechecks them.
- Linux helper and Windows launcher now wrap post-spawn work in cleanup/finally evidence. Windows scope stops still require fresh matching InvocationID and ControlGroup.
- Dependency queries now retain each attempted command, timeout partial output and earlier successful records.
- The second resource admission follows both expensive source verifications.
- The additional interpreter issue found during this review is fixed: `require_command_baseline` joins requested and resolved paths. This accepts a recorded `/usr/bin/python3` symlink while the independent `file_record` comparison continues to detect link/file drift. The added protocol fixture tests both accepted identity and missing-command refusal; it is not a real Linux symlink test.

## Remaining findings

### I5 — Important / P2: prepared-input declaration is not joined to the observed prepared record

`tools/benchmark/calibration_capture_study.py:159` discards the return of `validate_prepared_scene`. At line 166, the selected declaration's `prepared_input` is copied directly into the expected execution. A wrong declared prepared path or file record can therefore pass the prelaunch study gate when its enclosing hashes agree. The actual collector reconstructs this record and rejects it only after the exclusive physical claim. Compare the selected declaration with the independently observed prepared record before claim, with a fixture that mutates its path and file declaration.

### I6 — Important / P2: execution environment is self-validated instead of joined to the binding

`tools/benchmark/calibration_capture_study.py:165` calls `execution_contract(args, execution["launch_environment"])`. The native graph proof is tied to the binding environment, while the eventual collector derives its environment from that binding. Different binding/execution environments can thus pass study verification and be rejected later by the collector. Derive the expected execution environment using `derive_launch_environment(binding)` and require the exact declaration match before claim.

### I7 — Important / P2: preparation accepts undeclared additional graph members

`tools/benchmark/calibration_capture_study.py:101-114` checks containment, not exact membership: it converts `pre.files` to a dictionary, checks baseline rows and expected generated paths, but permits extra rows and duplicate requested identities. The graph auditor trusts those additional pre rows as graph dependencies, even when they are absent from `binding.inventory`; current study revalidation never rehashes those extra dependencies. Require unique requested identities and an exact preparation set equal to the binding baseline plus the final prepared scene files (excluding runtime-only generated `gz_env.sh` as designed), with matching roles/records. Add fixtures for an extra selected dependency and a duplicate requested identity.

## Limits

The current preparer normally constructs the intended exact preparation set and shared environment; I5-I7 concern the production study gate's enforcement of that correspondence. Hash equality alone does not establish these semantic joins. Reported software regressions were inspected only through their source fixtures and were not rerun. Native SDK behavior, actual final graph construction, resource admission, cgroup/kernel behavior and physical calibration remain untested here. Task2 concrete freeze is pending and all eight qualification flags remain false.