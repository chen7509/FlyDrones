"""Own scoped collector invocation; no new simulation, estimator or flight algorithm."""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

from tools.benchmark.run_openvins_dataset_consumer import write


def verify_scope(unit,group,limits,properties):
    expected={'memory.max':str(4*1024**3),'memory.swap.max':'0','cpu.max':'100000 100000','pids.max':'256'}
    if (re.fullmatch(r'fly-calibration-[0-9a-f]{3,24}\.scope',unit) is None
            or not group.endswith('/'+unit) or limits!=expected
            or properties.get('ControlGroup')!=group or not properties.get('InvocationID')):
        raise ValueError('own physical scope identity/limits mismatch')


def main(argv=None):
    from tools.benchmark.calibration_capture_study import verify_study

    args=sys.argv[1:] if argv is None else argv
    profile=json.loads(Path(args[0]).read_text(encoding='utf8'))
    output=Path(profile['output'])
    lines=[line[3:] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::')]
    if len(lines)!=1:
        raise ValueError('own unified physical cgroup unknown')
    group=lines[0];root=Path('/sys/fs/cgroup'+group)
    limits={name:(root/name).read_text().strip() for name in ('memory.max','memory.swap.max','cpu.max','pids.max')}
    props=subprocess.run(['systemctl','--user','show',profile['unit'],'--property=InvocationID','--property=ControlGroup'],
                         capture_output=True,text=True,timeout=10,check=True)
    properties=dict(line.split('=',1) for line in props.stdout.splitlines() if '=' in line)
    before=dict(pid=__import__('os').getpid(),cgroup=group,limits=limits,systemd_properties=props.stdout,qualification=False)
    write(output/'inside-before.json',before)
    verify_scope(profile['unit'],group,limits,properties)
    checked=verify_study(Path(profile['study']),profile['study_sha256'])
    write(output/'verified-before.json',checked)
    if checked!=profile['verified']:
        raise ValueError('physical scope selected inputs changed before command')
    command=['/usr/bin/time','-v','-o',str(output/'resources.txt'),'/usr/bin/timeout','--signal=TERM','--kill-after=10s','315s',
             *checked['command']]
    with (output/'collector.stdout').open('xb') as stdout,(output/'collector.stderr').open('xb') as stderr:
        process=subprocess.Popen(command,cwd=checked['cwd'],stdout=stdout,stderr=stderr)
        write(output/'collector-start.json',dict(pid=process.pid,command=command,cgroup=group))
        code=process.wait(timeout=330)
    after=verify_study(Path(profile['study']),profile['study_sha256'],require_absent=False)
    write(output/'verified-after.json',after)
    write(output/'inside-completion.json',dict(exit=code,cgroup=group,
          limits_after={name:(root/name).read_text().strip() for name in limits},
          memory_events=(root/'memory.events').read_text(),
          memory_peak=(root/'memory.peak').read_text() if (root/'memory.peak').exists() else None,
          selected_inputs_stable=after==checked,qualification=False))
    return code if after==checked else 2


if __name__=='__main__':
    raise SystemExit(main())
