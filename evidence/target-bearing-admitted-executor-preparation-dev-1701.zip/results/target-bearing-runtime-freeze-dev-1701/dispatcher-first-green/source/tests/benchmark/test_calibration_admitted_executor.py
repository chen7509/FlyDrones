"""Real dispatcher paths with explicit file/process protocol fixtures only."""
import importlib
import json

import pytest


def api():
    return importlib.import_module('tools.benchmark.run_calibration_capture')


def facts(memory=4*1024**3):
    return dict(windows_available=memory,wsl=dict(available=4*1024**3,processes=[]),
                windows_processes=[],blocked_processes=[],docker_exit=0,docker_running='',admitted=True)


@pytest.mark.parametrize('scenario',['first_refusal','second_refusal','source_drift','success'])
def test_actual_dispatch_admission_claim_and_replay(tmp_path,scenario):
    m=api()
    events=[]
    study=tmp_path/'study.json'
    study.write_text('{}')
    record=tmp_path/'admission.json'
    attempt=tmp_path/'attempt'
    counters=[facts(4*1024**3-1 if scenario=='first_refusal' else 4*1024**3),
              facts(4*1024**3-1 if scenario=='second_refusal' else 4*1024**3)]
    def collect():
        events.append('admission')
        return counters.pop(0)
    n=[0]
    def verify(*_):
        n[0]+=1
        events.append('verify')
        return dict(study_sha256='frozen',files_sha256='changed' if scenario=='source_drift' and n[0]==2 else 'current')
    def launch(*_):
        assert (attempt/'attempt.json').exists()
        events.append('launch')
        return dict(exit=0,owned_group_released=True)
    result=m.execute_once(study,'a'*64,record,attempt,collect=collect,verify=verify,launch=launch)
    assert json.loads(record.read_text())['first']==facts(4*1024**3-1 if scenario=='first_refusal' else 4*1024**3)
    if scenario=='success':
        assert events==['admission','verify','admission','verify','launch']
        assert result['attempt_claimed'] is True
        with pytest.raises(FileExistsError):
            m.execute_once(study,'a'*64,tmp_path/'next-record.json',attempt,collect=collect,verify=verify,launch=launch)
    else:
        assert 'launch' not in events and not attempt.exists()
        assert result['attempt_claimed'] is False
        if scenario=='first_refusal':
            assert events==['admission']
    assert all(v is False for v in result['qualification'].values())


def test_partial_launch_failure_consumes_claim_without_new_directory(tmp_path):
    m=api()
    study=tmp_path/'study.json';study.write_text('{}')
    attempt=tmp_path/'attempt'
    def launch(*_):
        raise OSError('actual Popen protocol refusal')
    result=m.execute_once(study,'a'*64,tmp_path/'admission.json',attempt,
                          collect=facts,verify=lambda *_:dict(current='same'),launch=launch)
    assert result['attempt_claimed'] is True and 'Popen protocol refusal' in result['error']
    assert (attempt/'completion.json').exists()
    with pytest.raises(FileExistsError):
        m.execute_once(study,'a'*64,tmp_path/'admission2.json',attempt,collect=facts,
                       verify=lambda *_:dict(current='same'),launch=launch)


def test_inside_real_counter_gate_before_collector(tmp_path):
    m=importlib.import_module('tools.benchmark.calibration_capture_scope')
    values={'memory.max':str(4*1024**3),'memory.swap.max':'0','cpu.max':'100000 100000','pids.max':'256'}
    properties={'InvocationID':'fixture','ControlGroup':'/user.slice/fly-calibration-123.scope'}
    assert m.verify_scope('fly-calibration-123.scope',properties['ControlGroup'],values,properties) is None
    values['memory.swap.max']='1'
    with pytest.raises(ValueError,match='scope'):
        m.verify_scope('fly-calibration-123.scope',properties['ControlGroup'],values,properties)
