"""Real dispatcher paths with explicit file/process protocol fixtures only."""
import importlib
import json

import pytest


def api():
    return importlib.import_module('tools.benchmark.run_calibration_capture')


def facts(memory=4*1024**3):
    return dict(windows_available=memory,wsl=dict(available=4*1024**3,processes=[]),
                windows_processes=[],blocked_processes=[],docker_exit=0,docker_running='',admitted=True)


@pytest.mark.parametrize('scenario',['first_refusal','second_refusal','source_drift','success'])
def test_actual_dispatch_admission_claim_and_replay(tmp_path,scenario):
    m=api()
    events=[]
    study=tmp_path/'study.json'
    study.write_text('{}')
    record=tmp_path/'admission.json'
    attempt=tmp_path/'attempt'
    counters=[facts(4*1024**3-1 if scenario=='first_refusal' else 4*1024**3),
              facts(4*1024**3-1 if scenario=='second_refusal' else 4*1024**3)]
    def collect():
        events.append('admission')
        return counters.pop(0)
    n=[0]
    def verify(*_):
        n[0]+=1
        events.append('verify')
        return dict(study_sha256='frozen',files_sha256='changed' if scenario=='source_drift' and n[0]==2 else 'current')
    def launch(*_):
        assert (attempt/'attempt.json').exists()
        events.append('launch')
        return dict(exit=0,owned_group_released=True)
    result=m.execute_once(study,'a'*64,record,attempt,collect=collect,verify=verify,launch=launch)
    assert json.loads(record.read_text())['first']==facts(4*1024**3-1 if scenario=='first_refusal' else 4*1024**3)
    if scenario=='success':
        assert events==['admission','verify','admission','verify','launch']
        assert result['attempt_claimed'] is True
        with pytest.raises(FileExistsError):
            m.execute_once(study,'a'*64,tmp_path/'next-record.json',attempt,collect=collect,verify=verify,launch=launch)
    else:
        assert 'launch' not in events and not attempt.exists()
        assert result['attempt_claimed'] is False
        if scenario=='first_refusal':
            assert events==['admission']
    assert all(v is False for v in result['qualification'].values())


def test_partial_launch_failure_consumes_claim_without_new_directory(tmp_path):
    m=api()
    study=tmp_path/'study.json';study.write_text('{}')
    attempt=tmp_path/'attempt'
    def launch(*_):
        raise OSError('actual Popen protocol refusal')
    result=m.execute_once(study,'a'*64,tmp_path/'admission.json',attempt,
                          collect=facts,verify=lambda *_:dict(current='same'),launch=launch)
    assert result['attempt_claimed'] is True and 'Popen protocol refusal' in result['error']
    assert (attempt/'completion.json').exists()
    with pytest.raises(FileExistsError):
        m.execute_once(study,'a'*64,tmp_path/'admission2.json',attempt,collect=facts,
                       verify=lambda *_:dict(current='same'),launch=launch)


def test_inside_real_counter_gate_before_collector(tmp_path):
    m=importlib.import_module('tools.benchmark.calibration_capture_scope')
    values={'memory.max':str(4*1024**3),'memory.swap.max':'0','cpu.max':'100000 100000','pids.max':'256'}
    properties={'InvocationID':'fixture','ControlGroup':'/user.slice/fly-calibration-123.scope'}
    assert m.verify_scope('fly-calibration-123.scope',properties['ControlGroup'],values,properties) is None
    values['memory.swap.max']='1'
    with pytest.raises(ValueError,match='scope'):
        m.verify_scope('fly-calibration-123.scope',properties['ControlGroup'],values,properties)


def test_prepared_scene_handoff_uses_frozen_bytes_and_refuses_extra(tmp_path,monkeypatch):
    from tools.benchmark import calibration_capture_contract as raw
    from tools.benchmark import capture_disarmed_sensors as capture
    import hashlib

    out=tmp_path/'prepared';out.mkdir()
    (out/'world.sdf').write_bytes(b'fixture-world')
    source=dict(path='source',files={'world.sdf':dict(bytes=13,sha256=hashlib.sha256(b'fixture-world').hexdigest())})
    prepared=dict(source,path=str(out))
    def record(path):
        if str(path)==str(out) and (out/'unexpected').exists():
            raise ValueError('member set changed')
        return prepared if str(path)==str(out) else source
    monkeypatch.setattr(raw,'scene_record',record)
    assert raw.validate_prepared_scene(source,out)==prepared
    result=capture.select_capture_scene(out,dict(raw_measurement=dict(scene=source,prepared_input=prepared)))
    assert result=={'world.sdf':source['files']['world.sdf']['sha256']}
    (out/'unexpected').write_bytes(b'old-result')
    with pytest.raises(ValueError):
        raw.validate_prepared_scene(source,out)


def test_supervisor_prepared_handoff_keeps_original_absence_guard(tmp_path,monkeypatch):
    from tools.benchmark import calibration_capture_contract as raw
    from tools.benchmark.disarmed_sensor_provenance import supervise_worker
    selected=[]
    def validate(source,out):
        selected.append((source,out))
    monkeypatch.setattr(raw,'validate_prepared_scene',validate)
    def spawn(*_,**__):
        raise RuntimeError('fixture launch boundary reached')
    with pytest.raises(FileExistsError):
        supervise_worker(['fixture'],tmp_path,spawn=spawn,terminate=lambda _:None)
    with pytest.raises(RuntimeError,match='launch boundary'):
        supervise_worker(['fixture'],tmp_path,spawn=spawn,terminate=lambda _:None,prepared_input={'scene':'fixture'})
    assert selected==[({'scene':'fixture'},tmp_path)]


def test_study_current_files_detect_actual_member_mutation(tmp_path):
    from tools.benchmark.declared_runtime_snapshot import file_record
    m=importlib.import_module('tools.benchmark.calibration_capture_study')
    p=tmp_path/'binding.json';p.write_bytes(b'bound-fixture')
    rows={'binding':file_record(p)}
    assert m.verify_files(rows)==rows
    p.write_bytes(b'changed-input')
    with pytest.raises(ValueError,match='study input'):
        m.verify_files(rows)


def test_scope_timeout_missing_identity_only_cleans_own_launcher(tmp_path,monkeypatch):
    import subprocess
    m=api()
    from types import SimpleNamespace
    stopped=[]
    class Process:
        pid=700
        waits=0
        done=False
        def wait(self,timeout):
            self.waits+=1
            if self.waits==1:
                raise subprocess.TimeoutExpired('protocol fixture',timeout)
            return -1
        def poll(self):return -1 if self.done else None
        def terminate(self):self.done=True;stopped.append('own-terminate')
    monkeypatch.setattr(m.subprocess,'Popen',lambda *_args,**_kwargs:Process())
    monkeypatch.setattr(m,'wsl',lambda *_args,**_kwargs:SimpleNamespace(returncode=1,stdout=b'LoadState=not-found\n',stderr=b''))
    monkeypatch.setattr(m,'stop_scope',lambda *_:stopped.append('unit-stop'))
    with pytest.raises(RuntimeError,match='timeout'):
        m.launch_scope(tmp_path,tmp_path/'study','a'*64,{},'fly-calibration-'+'a'*24+'.scope')
    assert stopped==['own-terminate']
    assert json.loads((tmp_path/'scope-ownership-unknown.json').read_text())['residual']=='unknown; no unit stop'


def test_scope_stop_rejects_different_invocation(tmp_path,monkeypatch):
    from types import SimpleNamespace
    m=api()
    unit='fly-calibration-'+'a'*24+'.scope';group='/user.slice/'+unit
    calls=[]
    def observed(*argv,**kwargs):
        calls.append(argv)
        return SimpleNamespace(returncode=0,stdout=('InvocationID=changed\nControlGroup='+group+'\n').encode(),stderr=b'')
    monkeypatch.setattr(m,'wsl',observed)
    with pytest.raises(RuntimeError,match='ownership unknown'):
        m.stop_scope(tmp_path,unit,dict(cgroup=group,systemd_properties='InvocationID=original\nControlGroup='+group+'\n'))
    assert len(calls)==1 and 'stop' not in calls[0]


def test_preparation_never_reuses_old_estimator_roots():
    m=importlib.import_module('tools.benchmark.prepare_calibration_capture')
    assert m.runtime_catalog(dict(inventory={
        'runtime-root:openvins':['old-consumed'],
        'runtime-root:native-reference':['old-reference'],
        'runtime:estimator-inputs':['old-yaml'],
        'runtime-root:physics-dartsim':['installed-physics'],
        'runtime:dependencies':['/lib/installed.so','/usr/local/old-numpy.so'],
        'runtime-root:python-numpy':['/usr/local/old-module.so']})) == ['installed-physics','/lib/installed.so']
