# Independent preflight code review

Base: `18ebb8fc9b0f516a36d3424b78042b3369942138`. Assessment: **changes required before actual static preparation or physical dispatch**.

Read-only review of the four new production modules, four shared changes, admitted-executor tests, matching spec/plan, actual old catalog and sealed scene references. No tests, native SDK, engine, capture, PX4, Agent, compiler, consumer, permission checks or resource polls were run. No production source was edited. The paired JSON records source hashes for this reviewed snapshot.

## Findings

### I1 — Important / P1: prepared input always fails worker environment initialization

`tools/benchmark/capture_disarmed_sensors.py:750` calls `record_worker_environment` for the raw v2 execution. That function still performs `output.mkdir(parents=True, exist_ok=False)` at line 115. The new prepared-scene handoff deliberately accepts an existing 45-file directory, so every such worker exits with `FileExistsError` before capture while consuming the fixed physical claim. Add an explicit validated raw prepared-input path to worker environment recording; retain the original default absent-output behavior. A software fixture should cover the real declaration-to-worker-environment transition, not just `select_capture_scene` or a mocked supervisor spawn.

### I2 — Important / P1: final preparation inventory omits required system plugins

`tools/benchmark/prepare_calibration_capture.py:216-224` obtains roots from `runtime_catalog` (lines 23-34), which discards `declared:resources`. The actual pinned catalog stores all gz-sim system plugins there, and its `runtime:dependencies` contains none of those plugin paths. Python/Agent roots added later do not supply them. The sealed `world.sdf:8` first references `gz-sim-physics-system`; after SDK resolution, `bound_resource_graph.py` demands that selected path exist in the frozen baseline and refuses it. Include freshly observed required system plugin candidates and their library dependencies before the final graph is frozen. Do not weaken the graph declaration guard or use a physical invocation to discover this known static omission.

### I3 — Important / P1: post-spawn errors bypass owned cleanup and terminal evidence

`tools/benchmark/calibration_capture_scope.py:70-87` lacks a `try/finally` cleanup/evidence envelope. A `collector-start.json` write failure or `wait` exception can leave its actual child unmanaged; post-run `verify_study` failure skips the actual exit, cgroup events and peak report. `tools/benchmark/run_calibration_capture.py:124-127` also writes `launcher.json` after `Popen` but before its timeout handler, so a write failure abandons that launcher. Preserve actual process ownership, bounded child cleanup, original exceptions and terminal counters independently of verification success. Scope stopping must continue to require a fresh matching InvocationID/ControlGroup; unknown identity must remain unknown. Cover post-spawn write errors, wait errors/timeouts and post-run input drift with process fixtures.

### I4 — Important / P2: ldd timeout loses the native failure trail

`tools/benchmark/prepare_calibration_capture.py:77-94` keeps all dependency observations in memory until the full loop finishes (or a normal nonzero result is detected). `TimeoutExpired`, spawn failure, or a later missing root bypasses the write entirely. The outer error record at line 322 only stores `repr(exc)`, so prior actual native calls and timeout partial output disappear after the one-shot preparation has been claimed. Journal each query in a `finally` path with its error/partial output, keeping completed records even if a later query fails.

## Preserved boundaries and scope

The new command is constructed from fixed arguments rather than arbitrary JSON argv; the dual 4 GiB decision is distinct from the reused helper's old 2 GiB boolean; first/second refusal precedes the fixed exclusive attempt claim; current-file checks, original workload values and eight false qualification fields are present. Default supervisor absent-output behavior and InvocationID/ControlGroup timeout-stop checks remain present. These positives do not resolve the four findings.

The new tests cover dispatcher fixture events, limited file mutation, scope-limit checking and timeout identity refusal. They do not execute the full worker environment transition, actual `verify_study` graph joins, the native inventory construction, or Linux helper exception cleanup. The parent's reported 240 passing Python regressions were not rerun or independently certified here. Task2 concrete freeze and all native/physical qualification remain pending; no native RED/GREEN, runtime closure, source, calibration or whole-plan completion is asserted.