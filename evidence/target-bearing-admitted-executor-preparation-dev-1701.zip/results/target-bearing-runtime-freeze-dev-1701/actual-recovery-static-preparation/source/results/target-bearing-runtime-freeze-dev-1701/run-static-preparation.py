import datetime, hashlib, json, os, secrets, subprocess
from pathlib import Path
from tools.benchmark.run_calibration_capture import wsl, stop_scope, ROOT
from tools.benchmark.run_openvins_dataset_consumer import admission, linux, write, finish_owned_launcher
out=Path(__file__).parent
folder=out/'frozen-study-v1'
if folder.exists() or (out/'static-attempt.json').exists():
    raise FileExistsError('static scope/prepared study already attempted; no replay')
# These are actual pre-command snapshots, separate from historical source pins.
sources={}
for scope in (ROOT/'src/flydrones',ROOT/'tools/benchmark',ROOT/'tools/connectome'):
    for path in sorted(scope.rglob('*.py')):
        if '__pycache__' in path.parts:continue
        data=path.read_bytes();sources[str(path.relative_to(ROOT))]=hashlib.sha256(data).hexdigest()
write(out/'static-source-before.json',sources)
pre_script="""import hashlib,json,pathlib,sys,importlib.metadata
root=pathlib.Path(sys.argv[1]);agent=json.loads((root/'results/agent-capture-contract-dev-1701/agent-runtime.json').read_text())
paths=[pathlib.Path('/usr/bin/python3'),root/'results/collada-ordered-candidates-dev-1701/build-v1/resource_resolver',pathlib.Path(agent['binary'])]
from tools.benchmark.agent_capture_runtime import LIBRARY_SHA256
paths += [pathlib.Path(agent['lib_dir'])/name for name in LIBRARY_SHA256]
paths += [root/'results/target-bearing-scene-production-dev-1701/actual-scene-v3/manifest.json']
rows=[]
for path in paths:
 row={'requested':str(path),'exists':path.is_file()}
 if row['exists']:
  row.update(resolved=str(path.resolve()),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
 rows.append(row)
from tools.benchmark.calibration_capture_scope import manager_environment
print(json.dumps({'manager_control_environment':manager_environment(),'files':rows,'python':sys.version,'versions':{p:importlib.metadata.version(p) for p in ('numpy','scipy','pyulog','pymavlink','protobuf')}}))
"""
# Retain both command and return even if dependency inventory fails before scope.
preargv=['/usr/bin/env','-i','HOME=/home/yuchen7509','PATH=/usr/bin:/bin','OPENBLAS_NUM_THREADS=1','PYTHONPATH='+linux(ROOT)+'/src:'+linux(ROOT),'/usr/bin/python3','-c',pre_script,linux(ROOT)]
write(out/'static-preidentity-command.json',dict(argv=preargv,utc=datetime.datetime.now(datetime.UTC).isoformat()))
pre=wsl(*preargv,check=False,timeout=30)
write(out/'static-preidentity-return.json',dict(exit=pre.returncode,stdout_hex=pre.stdout.hex(),stderr_hex=pre.stderr.hex()))
if pre.returncode:raise RuntimeError('pre-command identity inventory failed; no SDK scope')
identities=json.loads(pre.stdout)
write(out/'static-preidentity.json',identities)
if any(not row['exists'] for row in identities['files']):raise RuntimeError('required input absent before scope')
unit='fly-calibration-prepare-'+secrets.token_hex(12)+'.scope'
absent=wsl('systemctl','--user','show',unit,'--property=LoadState',check=False,timeout=10)
write(out/'static-scope-before.json',dict(unit=unit,exit=absent.returncode,stdout_hex=absent.stdout.hex(),stderr_hex=absent.stderr.hex()))
if b'LoadState=not-found' not in absent.stdout:raise RuntimeError('new static scope absence unknown')
facts=admission()
admitted=(type(facts['windows_available']) is int and facts['windows_available']>=1024**3 and
          type(facts['wsl']['available']) is int and facts['wsl']['available']>=1024**3 and
          facts['blocked_processes']==[] and facts['docker_exit']==0 and not facts['docker_running'].strip() and
          not any(p['name'].lower().removesuffix('.exe') in {'microxrceagent','kalibr','kalibr_calibrate_imu_camera'}
                  for p in facts['windows_processes']+facts['wsl']['processes']))
write(out/'static-first-admission.json',dict(facts=facts,static_reserve_bytes=1024**3,static_admitted=admitted,physical_admitted=False))
print(json.dumps(dict(static_admitted=admitted,win=facts['windows_available'],wsl=facts['wsl']['available'])),flush=True)
if not admitted:raise SystemExit(2)
cmd=['wsl','-d','Ubuntu','--','/usr/bin/systemd-run','--user','--scope','--unit='+unit.removesuffix('.scope'),
     '--property=MemoryMax=536870912','--property=MemorySwapMax=0','--property=CPUQuota=100%',
     '--property=TasksMax=64','--property=RuntimeMaxSec=210','--property=TimeoutStopSec=10s',
     '/usr/bin/env','-i','HOME=/home/yuchen7509','PATH=/usr/bin:/bin','LANG=C.UTF-8',
     'PYTHONPATH='+linux(ROOT)+'/src:'+linux(ROOT),'OPENBLAS_NUM_THREADS=1','OMP_NUM_THREADS=1',
     '/usr/bin/time','-v','-o',linux(out/'static-resources.txt'),'/usr/bin/timeout','--signal=TERM','--kill-after=10s','180s',
     '/usr/bin/python3','-m','tools.benchmark.prepare_calibration_capture','--prepare-only','--unit',unit]
write(out/'static-attempt.json',dict(unit=unit,command=cmd,utc=datetime.datetime.now(datetime.UTC).isoformat(),physical_attempt=False))
process=None;result=dict(exit=None,owned_group_released=None,escaped_closure='unknown',physical_attempt=False,error=None)
try:
    with (out/'static-launcher.stdout').open('xb') as stdout,(out/'static-launcher.stderr').open('xb') as stderr:
        process=subprocess.Popen(cmd,stdout=stdout,stderr=stderr)
        write(out/'static-launcher.json',dict(pid=process.pid,command=cmd))
        result['exit']=process.wait(timeout=240)
except BaseException as exc:
    result['error']=repr(exc)
finally:
    try:
        inside_path=out/'sdk-inside-before.json'
        if inside_path.exists():
            inside=json.loads(inside_path.read_text());group=inside['cgroup']
            exists=wsl('test','-d','/sys/fs/cgroup'+group,check=False,timeout=10)
            if exists.returncode==0:
                stop_scope(out,unit,inside)
            final=wsl('systemctl','--user','show',unit,'--property=LoadState','--property=ActiveState',check=False,timeout=10)
            exists=wsl('test','-d','/sys/fs/cgroup'+group,check=False,timeout=10)
            result.update(owned_group_released=exists.returncode==1 and b'LoadState=not-found' in final.stdout,
                          after_properties_hex=final.stdout.hex(),after_exit=final.returncode,group_test_exit=exists.returncode)
        else:
            result['scope_identity']='unknown; no unit stop'
    except Exception as exc:result['scope_cleanup_error']=repr(exc)
    if process is not None:
        try:finish_owned_launcher(out,process)
        except Exception as exc:result['launcher_cleanup_error']=repr(exc)
    result['end_utc']=datetime.datetime.now(datetime.UTC).isoformat()
    result['source_after']={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in sources}
    write(out/'static-completion.json',result)
print(json.dumps(result),flush=True)
raise SystemExit(0 if result['exit']==0 and result['owned_group_released'] is True else 1)
