# Independent dispatch preflight review

Assessment: **I8 is resolved by source inspection. No additional concrete blocking finding was identified in this review of the static dispatch path.** Critical 0, Important 0, Minor 0. This does not certify native execution or resource admission.

## Manager correction verified

`calibration_capture_scope.manager_environment` derives the manager runtime directory from the actual Linux `os.getuid()`. It uses `lstat`, requires directory type and matching owner UID, and therefore rejects a symlink at that directory entry. It returns only `PATH`, `LANG` and `XDG_RUNTIME_DIR` for the control subprocess.

Both `calibration_capture_scope.main` and `prepare_calibration_capture.scope_before` now supply that environment explicitly to `systemctl --user show`. The helper does not mutate `os.environ`, the SDK query environment or the declared collector environment. The added software fixture checks the constructed environment, absence refusal and no ambient mutation. It does not demonstrate native user-bus or cgroup behavior.

## Static dispatcher checked

The fixed static script still preserves its exclusive marker before Popen and retains the 1 GiB dual reserve, 512 MiB memory ceiling, zero swap, CPU 100%, TasksMax 64, 210 s scope, 180 s inner timeout with 10 s cleanup and 240 s outer wait. It invokes the static preparation module only. The static marker and fixed study folder prohibit replay after an attempt. Scope cleanup still requires the recorded own InvocationID/ControlGroup to match fresh systemd properties through `stop_scope`; unknown identity does not authorize a unit-name-only stop. Windows cleanup is limited to the actual Popen.

I5-I7 remain corrected: prepared record equality, binding-derived execution environment, and exact unique preparation member set. Original I1-I4 and the interpreter requested/resolved identity correction remain accepted from the previous reviews.

## Evidence limits

No tests, SDK, systemctl, procfs, resource/permission polls or physics commands were run during this review, and no production source was edited. The parent's reported 26 software passes were not independently rerun. The paired JSON records hashes for the nine production/test files and the static script; earlier review files remain unchanged.

The actual static SDK graph, final frozen study and native resource/cleanup outcome remain pending and must be evaluated from the one admitted command's retained outputs. Physical capture still requires its separate unchanged dual 4 GiB admission and exclusive claim. All eight qualification flags remain false; this review does not mark Task2 or the overall plan complete.