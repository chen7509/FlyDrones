import datetime
import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[2]
out = Path(__file__).parent
sys.path[:0] = [str(root), str(root / 'src')]
from tools.benchmark.calibration_capture_contract import scene_record

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024**2), b''):
            h.update(block)
    return h.hexdigest()

scene = root / 'results/target-bearing-scene-production-dev-1701/actual-scene-v3'
selected = scene_record(scene)
with (out / 'actual-static-scene-selection.json').open('x', encoding='utf8') as stream:
    json.dump(dict(utc=datetime.datetime.now(datetime.UTC).isoformat(), selected=selected,
                   selector_sha256=digest(root/'tools/benchmark/calibration_capture_contract.py'),
                   read_only=True, copies_created=False, physical_capture=False,
                   prior_scene_archive=dict(path='evidence/target-bearing-scene-load-production-dev-1701.zip',
                                           sha256=digest(root/'evidence/target-bearing-scene-load-production-dev-1701.zip'))), stream, indent=2)
old = {p.name:dict(bytes=p.stat().st_size,sha256=digest(p)) for p in sorted((root/'evidence').glob('*.zip'))}
with (out/'historical-archives.json').open('x',encoding='utf8') as stream:
    json.dump(old,stream,indent=2)
print(json.dumps(dict(scene_members=len(selected['files']), scene_bytes=sum(r['bytes'] for r in selected['files'].values()),
                      historic_count=len(old),historic_bytes=sum(r['bytes'] for r in old.values()),
                      runtime_graph_frozen=False,physical_dispatch_ready=False)))
