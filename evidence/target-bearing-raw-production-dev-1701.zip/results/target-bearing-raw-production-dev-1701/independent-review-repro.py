import datetime, importlib.util, json, sys, tempfile
from pathlib import Path
from types import SimpleNamespace
import pytest
root=Path.cwd()
sys.path[:0]=[str(root),str(root/'src')]
spec=importlib.util.spec_from_file_location('review_fixture',root/'tests/benchmark/test_calibration_raw_capture.py')
f=importlib.util.module_from_spec(spec); spec.loader.exec_module(f)
m=f.api()
from tools.benchmark import capture_contract as common, calibration_capture_contract as raw, agent_capture_runtime
class V:
    def __init__(self,v): self.v=v
    def x(self): return self.v[0]
    def y(self): return self.v[1]
    def z(self): return self.v[2]
class R:
    def roll(self): return 0.0
    def pitch(self): return 0.0
    def yaw(self): return 0.0
class StateLink(f.Link):
    bad_box=False
    def world_pose(self,_): return SimpleNamespace(pos=lambda:V([-8,0,.227]),rot=R)
    def world_linear_velocity(self,_): return V([0,0,0])
    def world_angular_velocity(self,_): return V([0,0,0])
    def world_axis_aligned_box(self,_):
        return SimpleNamespace(min=lambda:V([-7 if self.bad_box else -8.3,-.3,0]),max=lambda:V([-7.7,.3,.3]))
results={}
with tempfile.TemporaryDirectory(prefix='raw-review-') as temp:
    temp=Path(temp)
    args=f.raw_args(temp)
    args.wire_config.write_text(json.dumps(dict(schema='capture-wire-v1',session_id='fixture',sim_origin_ns=0,remote_origin_ns=0)))
    with pytest.MonkeyPatch.context() as mp:
        mp.setattr(raw,'scene_record',lambda _:dict(path='fixture',files={}))
        mp.setattr(agent_capture_runtime,'agent_runtime_record',lambda _:dict(configuration={},selected_paths=[]))
        contract=common.execution_contract(args,{'HOME':'fixture'})
        results['legacy_wire_accepted_for_raw']=contract['wire']['configuration']['schema']=='capture-wire-v1'
    for scenario in ('partial_call','invalid_collision'):
        out=temp/scenario; out.mkdir()
        events=[]; errors=[]; traces=[]
        g=f.geometry();g['links']['base_link']['pose_model']=[0,0,.24,0,0,0]
        links={name:StateLink(name,events) for name in g['links']}
        probe=m.CalibrationProbe(out,errors,lambda:1,scene=dict(geometry=g,design=dict(target_pose_world=[-7.28,0,.419])),readiness=lambda:f.proof(),guard=lambda:None,trace=SimpleNamespace(observe=lambda phase,*_:traces.append(phase)),clock=lambda:1,resolver=lambda *_:links,vector=lambda *v:v)
        final=201 if scenario=='partial_call' else 1
        for step in range(1,final+1):
            info=SimpleNamespace(sim_time=datetime.timedelta(milliseconds=step),dt=datetime.timedelta(milliseconds=1),paused=False)
            if step==final:
                if scenario=='partial_call': links['rotor_1'].fail=True
                else: links['base_link'].bad_box=True
            probe.pre_update(info,None)
            probe.post_update(info,None)
        probe.commands.flush();probe.audit.flush()
        results[scenario]=dict(errors=errors,last_two_trace_phases=traces[-2:],audit_rows=probe.audit_rows,command_rows=[json.loads(x) for x in (out/'calibration-load-calls.jsonl').read_text().splitlines()][-2:],audit_last_rows=[json.loads(x) for x in (out/'calibration-collision-audit.jsonl').read_text().splitlines()][-2:])
        probe.finish()
print(json.dumps(results,indent=2))
