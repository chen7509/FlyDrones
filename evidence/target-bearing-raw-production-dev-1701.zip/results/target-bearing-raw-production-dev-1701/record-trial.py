import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[2]
out = Path(__file__).parent / sys.argv[1]
out.mkdir(exist_ok=False)
names = ['tools/benchmark/calibration_capture_contract.py','tools/benchmark/calibration_excitation.py',
         'tools/benchmark/capture_contract.py','tools/benchmark/capture_disarmed_sensors.py',
         'tools/benchmark/runtime_resource_binding.py','tests/benchmark/test_calibration_raw_capture.py']
before = {}
for name in names:
    blob = (root/name).read_bytes()
    dest = out/'source'/name
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(blob)
    before[name] = hashlib.sha256(blob).hexdigest()
argv = sys.argv[2:]
record = dict(argv=argv,cwd=str(root),start_utc=datetime.datetime.now(datetime.UTC).isoformat(),
              source_before_sha256=before,env={k:os.environ.get(k) for k in ('PYTHONUTF8','PYTHONPATH','OPENBLAS_NUM_THREADS')})
(out/'command.json').write_text(json.dumps(record,indent=2),encoding='utf8')
with (out/'stdout.bin').open('xb') as stdout,(out/'stderr.bin').open('xb') as stderr:
    done = subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr)
record.update(exit=done.returncode,end_utc=datetime.datetime.now(datetime.UTC).isoformat(),
              source_after_sha256={k:hashlib.sha256((root/k).read_bytes()).hexdigest() for k in names})
(out/'completion.json').write_text(json.dumps(record,indent=2),encoding='utf8')
print(json.dumps(dict(argv=argv,exit=done.returncode)))
print((out/'stdout.bin').read_text(encoding='utf8',errors='replace')[-7000:])
print((out/'stderr.bin').read_text(encoding='utf8',errors='replace')[-1000:])
raise SystemExit(done.returncode)
