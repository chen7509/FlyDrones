import json
from pathlib import Path
from tools.benchmark.run_openvins_dataset_consumer import admission
facts = admission()
with (Path(__file__).parent/'initial-readonly.json').open('x') as stream:
    json.dump(facts,stream,indent=2)
print(json.dumps({k:facts[k] for k in ('windows_available','blocked_processes','docker_exit','admitted')}))
print(facts['wsl']['available'])
