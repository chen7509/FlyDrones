# Independent review: target-bearing raw production

Reviewed uncommitted production changes against base/HEAD `6300398684fb40142252841e3069eb8dc81795a5` and the original measurement-capture spec/plan plus the raw-production integration spec. Review covers actual contract/worker/shared ownership and scene-binding routes, not just helpers. Recommendation: changes required before Task2 preparation seal. Critical: 0; Important: 3; Minor: 0.

## Important 1: require the staged wire schema for the raw graph

`tools/benchmark/capture_contract.py:179-184` / `calibration_capture_contract.py:48`.

The raw selector only requires a nonempty wire-config path, while `wire_configuration_record` accepts both `capture-wire-v1` and `capture-wire-startup-v2`. Consequently a complete raw contract can carry the legacy v1 wire configuration; `run_capture_runtime` then selects `wire_owner.bind` instead of `begin_startup`. This bypasses the staged cold-start probe/gate required by the raw-production spec. The new route needs a raw-only check requiring the v2 staged schema; old graph acceptance should remain intact.

Genuine behavioral reproduction: write a valid real v1 JSON wire file, select production raw args, stub only unavailable scene/Agent source records, and call the real `execution_contract`. It returns a raw contract with `wire.configuration.schema == capture-wire-v1`. Proposed regression: require that same invocation to raise before ownership/effects, and verify a v2 file succeeds while legacy-profile v1 remains supported.

## Important 2: retain post-step diagnostics after partial load failure

`tools/benchmark/calibration_excitation.py:278-280`.

`post_update` immediately returns when pre-update has latched any error. A failure on the fourth per-link force call leaves three accepted COM requests in the physics step, but suppresses the matching post trace and collision/state audit. The requested/partial-failure command journal correctly identifies returned calls; the actual resulting state is lost. Subsequent calls should remain refused, while independently capturing the post phase of the already-entered step (and subsequent bounded diagnostic callbacks if the server completes its current batch).

Genuine behavioral reproduction: run real `CalibrationProbe` callbacks with explicit Python SDK state stubs through201ms, fail `rotor_1.add_world_force` at the first active step, then invoke the real post callback. Journal shows three force returns and the partial refusal; trace phases end `[post, pre]`, audit has401rows and no post201ms row. Proposed regression: assert no further load calls after refusal, preserve the original failure, and require matching post201ms trace/audit with the partial-call identity. This is Python protocol validation, not ECM/physics proof.

## Important 3: write invalid collision-envelope abort diagnostics

`tools/benchmark/calibration_excitation.py:217-224`.

Missing or invalid collision boxes call `policy.refuse` before any collision-audit row is written. The result retains only a textual error, omitting phase/time/link and the offending values needed to audit this safety refusal. Valid angular/target/ground violations are already recorded before refusal; invalid collision observations need the same independent evidence boundary. Serialize a finite-safe attempted row or explicit missing/invalid per-link diagnostic before latching the refusal; do not treat a failed observation as a valid envelope.

Genuine behavioral reproduction: first pre callback receives a finite box with min.x=-7 and max.x=-7.7. It refuses as invalid, but `audit_rows == 0` and the collision-audit file is empty. Proposed regression: missing box, reversed bounds and nonfinite bounds each leave a named/time/phase abort record with safe raw-value representation, no requested load and a latched failure.

## Evidence and limits

`independent-review-repro.py` ran once under Python3.12 and returned exit0; output is retained in `independent-review-repro.json`. It invokes actual production contract and callback methods with explicit Python SDK/process/source-record fixtures. No Gazebo, native extension, ECM, PX4, Agent, physical capture, solver, stage materializer or consumed consumer ran. The coordinator's173pass1skip result was provided context, not independently rerun. Resource closure, once-only physical executor and actual physical qualification remain pending; all qualifications stayfalse.

Reviewed source SHA256:

- capture_contract.py: 984e93e23f5da4528f32499586ba80b0a9119c21a3759d3aac2d8a38ed9b6b60
- capture_disarmed_sensors.py: 7fc79f1be01789f82599ebe0ad9b7e15eeec06850d3a57aa63816ea94bf8522b
- runtime_resource_binding.py: 0a29c1753632d206e572379dc2951340dcaa3792960021a60d5b5c803f0cd0f0
- calibration_capture_contract.py: b98dc969ef6b929c35ca213e85517f83d911bcd21087ee428f4b9ad99de7bc60
- calibration_excitation.py: c9a10417598ebac4e20c3f8d39d7e2c3a092d754f66207c28462e55e43edeebd

Positive evidence: raw selection uses its frozen scene manifest and complete generated-member set; legacy selection retains its sealed archive. Motion is time-only, supports each link at COM and requests base torque with zero force. Requested call vectors flush before effects, and synchronous partial API refusal retains returned-call flags. Existing writer/readiness/owned source and Agent/PX4 cleanup functions are reused. These strengths do not resolve the three findings above.
