import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[2]
out = Path(__file__).parent

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024**2), b''):
            h.update(block)
    return h.hexdigest()

old = json.loads((out/'historical-archives.json').read_text())
changes = [name for name,row in old.items() if digest(root/'evidence'/name) != row['sha256']]
assert not changes, changes
with (out/'historical-archives-final.json').open('x',encoding='utf8') as stream:
    json.dump(dict(count=len(old),bytes=sum(r['bytes'] for r in old.values()),changed=changes),stream,indent=2)
names = ['tools/benchmark/calibration_capture_contract.py','tools/benchmark/calibration_excitation.py',
         'tools/benchmark/capture_contract.py','tools/benchmark/capture_disarmed_sensors.py',
         'tools/benchmark/runtime_resource_binding.py','tests/benchmark/test_calibration_raw_capture.py',
         'docs/TARGET_BEARING_RAW_PRODUCTION_REPORT.md',
         'docs/superpowers/specs/2026-10-15-target-bearing-raw-production.md',
         'docs/superpowers/specs/2026-10-15-target-bearing-measurement-capture.md',
         'docs/superpowers/plans/2026-10-15-target-bearing-measurement-capture.md']
files = [root/name for name in names] + sorted(p for p in out.rglob('*') if p.is_file()
         and '__pycache__' not in p.parts and p.name != 'seal-result.json')
manifest = dict(schema='target-bearing-raw-production-evidence-v1',
                status='software-production-preparation-only',runtime_graph_frozen=False,physical_dispatch_ready=False,
                actual_native_physical_attempt=False,
                qualification={k:False for k in ('source','clock','measured_calibration','accuracy','teacher','fusion','training','flight')},
                members=[dict(path=p.relative_to(root).as_posix(),size=p.stat().st_size,sha256=digest(p)) for p in files])
archive = root/'evidence/target-bearing-raw-production-dev-1701.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for p in files:
        z.write(p,p.relative_to(root).as_posix())
    z.writestr('MANIFEST.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(set(z.namelist())) == len(files)+1
    for row in manifest['members']:
        blob = z.read(row['path'])
        assert len(blob)==row['size'] and hashlib.sha256(blob).hexdigest()==row['sha256']
        assert blob == (root/row['path']).read_bytes()
result = dict(path=archive.relative_to(root).as_posix(),sha256=digest(archive),bytes=archive.stat().st_size,
              members=len(files)+1,mapped=len(files),crc_size_sha_currentbyte_errors=0,historical_changed=changes)
with (out/'seal-result.json').open('x',encoding='utf8') as stream:
    json.dump(result,stream,indent=2)
print(json.dumps(result))
