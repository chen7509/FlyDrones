# Independent final review: target-bearing raw production

Fresh re-review of the complete current Task2 production changes and shared integration against base6300398684fb40142252841e3069eb8dc81795a5. The initial review and its reproduction remain intact. Critical:0; Important:0; Minor:0 remaining actionable findings in reviewed Task2 scope.

The three initial findings are resolved:

- I1: actual raw execution-contract construction rejects capture-wire-v1 and accepts a real capture-wire-startup-v2 JSON declaration. The raw-only check leaves the shared legacy parser available to old routes.
- I2: after the fourth COM force call refuses, the matching post trace and post collision/state audit remain recorded; failure stays latched. Post callbacks do not reauthorize or apply motion. The explicit SDK fixture now ends with pre/post and402audit rows, including the post201ms state. Subsequent post diagnostics remain available while the server finishes its current bounded batch.
- I3: missing/invalid collision envelopes journal time/phase/link evidence before refusal. Finite bounds remain numeric; nonfinite bounds have explicit repr strings. The reversed-bound fixture now retains two independent diagnostics (pre and matching post) while refusing effects.

The additive standalone reproduction `independent-review-final-repro.py` ran once and returned exit0 with assertions. Its result is preserved in `independent-review-final-repro.json`. It invokes actual Python execution-contract and CalibrationProbe methods, with source-record stubs for unavailable scene/Agent declarations and explicit Python SDK state stubs. The real wire JSON parser is used for both v1 and v2 cases. This is behavioral software evidence, not Gazebo/ECM/physics validation. The coordinator's23pass result was provided context, not independently rerun.

Full re-review also inspected raw argument rejection/worker forwarding, exact frozen-source copying and generated-member selection, raw v4 environment/scene binding plus owned mapping requirements, writer/journal-readiness/heartbeat refusal, per-link COM support/base zero-force pure torque, pre-effect guard ordering, partial-call journals, and shared Agent/PX4/ULog cleanup. No additional actionable regression was identified in these reviewed Task2 changes.

Task2 code preparation is suitable for its pending-preparation seal on this review evidence. This does not complete the original goal: full runtime lookup/dependency/native closure and physical study freeze, once-only physical executor, fresh dual4GiB/no-competition admission, native/ECM/physical acceptance, capture and calibration consumption remain pending. No native, PX4, Agent, physics, solver, resource poll, source-stage materializer or consumed consumer ran during this re-review. All source/clock/calibration/accuracy/teacher/fusion/training/flight qualifications stayfalse.

Reviewed SHA256:

- tools/benchmark/capture_contract.py: cc4c7cc51ddf6071df16c99d7f6c2c426c71b2dcb58bb4302e547d85f9bbc1c1
- tools/benchmark/capture_disarmed_sensors.py: 7fc79f1be01789f82599ebe0ad9b7e15eeec06850d3a57aa63816ea94bf8522b
- tools/benchmark/runtime_resource_binding.py: 0a29c1753632d206e572379dc2951340dcaa3792960021a60d5b5c803f0cd0f0
- tools/benchmark/calibration_capture_contract.py: b98dc969ef6b929c35ca213e85517f83d911bcd21087ee428f4b9ad99de7bc60
- tools/benchmark/calibration_excitation.py: a48a688ebdeb6ec063d4dc8908306d32957c8fa652f7a34baf74229e24535971
- tests/benchmark/test_calibration_raw_capture.py: 020acaca3d8920afe16862cfe284df516efabf3a56a7487046dd488c33abaccb
