"""Production path behavior with explicit Python/SDK protocol fixtures only."""

import importlib
import io
from pathlib import Path

import numpy as np
import pytest

from tools.benchmark import capture_disarmed_sensors as capture


def api():
    return importlib.import_module('tools.benchmark.calibration_excitation')


def raw_args(tmp_path, *extra):
    return capture.parse_capture_args(['--output', str(tmp_path/'capture'), '--capture-profile', 'target-bearing-raw-v1',
        '--calibration-scene', str(tmp_path/'scene'), '--execution-contract', str(tmp_path/'execution.json'),
        '--runtime-binding', str(tmp_path/'binding.json'), '--wire-config', str(tmp_path/'wire.json'),
        '--agent-runtime-config', str(tmp_path/'agent.json'), '--logger-diagnostic-profile', 'source-diagnostic-v1',
        '--record-owned-ulog', '--simulation-seed', '1701', '--motion-profile', 'target-bearing-multiaxis-v1',
        '--physics-trace-profile', 'substep-calibration-v1', *extra])


def test_raw_graph_selected_without_dummy_native(tmp_path):
    selected = raw_args(tmp_path)
    assert selected.shadow_binary is None and selected.reference_module is None
    from tools.benchmark.capture_contract import worker_options
    forwarded = worker_options(selected)
    assert '--capture-profile' in forwarded and '--calibration-scene' in forwarded


@pytest.mark.parametrize('extra', [('--shadow-binary','dummy'), ('--source-fanout-profile','ready-shadow-v1'),
                                  ('--reference-module','dummy'), ('--health-profile','px4-d6f12ad-gate-floor-v1')])
def test_raw_rejects_native_profile_masquerading(tmp_path, extra):
    with pytest.raises(SystemExit):
        raw_args(tmp_path, *extra)


def geometry():
    masses = {'base_link':2., **{f'rotor_{i}':.016076923076923075 for i in range(4)}, 'camera_link':.061}
    return dict(mass_kg=sum(masses.values()), links={k:dict(mass=v) for k,v in masses.items()},
                inertia_com_model_kg_m2=np.diag([.024,.025,.045]).tolist(),
                model_pose_world=[-8,0,-.013,0,0,0],
                expected_base_position_world=[-8,0,.227], target_plane_world_x=-7.28)


def proof(armed=False):
    return {'records': {'heartbeat': {'system_id':9,'base_mode':128 if armed else 0}}}


def policy(ready=lambda:proof(), persist=lambda _:None):
    return api().CalibrationPolicy(geometry(), ready, persist)


def test_policy_anchor_only_from_journal_and_no_startup_force():
    saved=[]
    p=policy(ready=lambda:None, persist=saved.append)
    assert not any(p.step(1_000_000,1_000_000,unarmed_wall_ns=None,wall_ns=1)['force_world_n'])
    p.readiness=lambda:proof()
    p.step(2_000_000,1_000_000,unarmed_wall_ns=2,wall_ns=2)
    assert p.anchor_ns == 202_000_000 and len(saved)==1
    for ns in range(3_000_000,203_000_000,1_000_000):
        row=p.step(ns,1_000_000,unarmed_wall_ns=3,wall_ns=3)
    assert row['force_world_n'][2] == pytest.approx(geometry()['mass_kg']*9.81)


@pytest.mark.parametrize('bad', ['armed','stale','wall_backwards','sim_gap','writer','witness'])
def test_policy_latches_before_effects(bad):
    p=policy()
    p.step(1_000_000,1_000_000,unarmed_wall_ns=10,wall_ns=10)
    if bad=='armed': p.readiness=lambda:proof(True)
    if bad in ('writer','witness'):
        def failure(): raise ValueError(bad)
        p.readiness=failure
    kwargs=dict(unarmed_wall_ns=10, wall_ns=10)
    if bad=='stale': kwargs['wall_ns']=2_000_000_011
    if bad=='wall_backwards': kwargs['wall_ns']=9
    with pytest.raises(ValueError):
        p.step(3_000_000 if bad=='sim_gap' else 2_000_000,1_000_000,**kwargs)
    p.readiness=lambda:proof()
    with pytest.raises(ValueError,match='latched'):
        p.step(3_000_000,1_000_000,unarmed_wall_ns=11,wall_ns=11)


class Link:
    def __init__(self,name,events,fail=False): self.name,self.events,self.fail=name,events,fail
    def add_world_force(self,ecm,v):
        self.events.append(('COM',self.name,tuple(v)))
        if self.fail: raise RuntimeError('injected SDK call refusal')
    def add_world_wrench(self,ecm,force,torque): self.events.append(('origin',self.name,tuple(force),tuple(torque)))


def test_actual_application_order_pure_torque_and_partial_failure():
    m=api(); events=[]
    links={name:Link(name,events,name=='rotor_1') for name in geometry()['links']}
    stream=io.StringIO()
    row=dict(sim_ns=1,force_world_n=[0,0,20],torque_world_nm=[.01,0,0])
    attempt={}
    with pytest.raises(RuntimeError):
        m.apply_load(links,None,row,geometry(),stream,attempt,vector=lambda *v:v)
    assert events[0][0]=='COM'
    assert not any(e[0]=='origin' for e in events)
    assert attempt['per_link'][0]['call_returned'] is True
    assert attempt['per_link'][-1]['call_returned'] is False
    assert 'partial_failure' in stream.getvalue()
    events.clear(); stream=io.StringIO()
    for link in links.values(): link.fail=False
    m.apply_load(links,None,row,geometry(),stream,{},vector=lambda *v:v)
    assert events[-1] == ('origin','base_link',(0.,0.,0.),(.01,0,0))
    assert sum(e[2][2] for e in events[:-1]) == pytest.approx(20)


def test_failed_pre_effect_journal_makes_no_call():
    m=api(); events=[]
    links={name:Link(name,events) for name in geometry()['links']}
    class Broken:
        def write(self,_): raise OSError('writer refused')
    with pytest.raises(OSError):
        m.apply_load(links,None,dict(sim_ns=1,force_world_n=[0,0,20],torque_world_nm=[.01,0,0]),
                     geometry(),Broken(),{},vector=lambda *v:v)
    assert events == []


def test_raw_scene_selector_uses_own_bill_and_leaves_legacy_route(tmp_path, monkeypatch):
    from tools.benchmark import calibration_capture_contract as contract
    chosen=[]
    record=dict(path='sealed-v3',files={'world.sdf':{'sha256':'new-world'}})
    def copy(value, output):
        chosen.append((value,output))
        return {'world.sdf':'new-world'}
    monkeypatch.setattr(contract,'copy_scene',copy)
    result=capture.select_capture_scene(tmp_path,dict(raw_measurement=dict(scene=record)))
    assert result == {'world.sdf':'new-world'}
    assert chosen == [(record,tmp_path)]
    # Legacy selection uses its old archive; cannot be silently swapped to raw.
    with pytest.raises(FileNotFoundError):
        capture.select_capture_scene(tmp_path,{},legacy_archive=tmp_path/'missing.zip')


def test_raw_generated_names_do_not_use_old_obstacle_placeholders():
    from tools.benchmark.runtime_resource_binding import generated_names
    scene=dict(files={'world.sdf':{},'manifest.json':{},'models/x500/model.sdf':{}})
    names=generated_names(dict(schema='capture-resource-binding-v4',calibration_scene=scene))
    assert set(names) == {'world.sdf','manifest.json','models/x500/model.sdf','gz_env.sh'}
    assert 'obstacle_albedo.png' not in names


def test_raw_readiness_requires_owned_witness_and_wire_health():
    from types import SimpleNamespace
    ready=SimpleNamespace(proof=lambda:proof())
    wire=SimpleNamespace(health_ready=lambda:True)
    source=SimpleNamespace(failure=None,logs={})
    assert capture.raw_measurement_readiness(ready,wire,source) is None
    source.logs={'owned.ulg':{}}
    assert capture.raw_measurement_readiness(ready,wire,source) == proof()
    wire.health_ready=lambda:False
    assert capture.raw_measurement_readiness(ready,wire,source) is None
    source.failure='denied'
    with pytest.raises(ValueError):
        capture.raw_measurement_readiness(ready,wire,source)
