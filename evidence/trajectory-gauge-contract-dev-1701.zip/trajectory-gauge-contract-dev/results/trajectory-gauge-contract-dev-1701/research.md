# Trajectory/gauge research record — 2026-10-06

## OpenVINS state semantics

- Project: `rpng/open_vins`, fixed commit `69488123ed9362dd44b6f28e7f4680abbff1442b` dated 2025-11-30.
- License: GPL-3.0. GitHub API snapshot in `openvins-repository.json` reports non-archived and last push 2025-11-30; this does not establish active 2026 maintenance.
- Official interfaces: [State](https://docs.openvins.com/classov__msckf_1_1State.html), [IMU](https://docs.openvins.com/classov__type_1_1IMU.html), [quaternion utilities](https://github.com/rpng/open_vins/blob/master/ov_core/src/utils/quat_ops.h), and the Geneva et al. ICRA 2020 OpenVINS paper already sealed in PR48.
- Relevant data: active IMU state `q_GtoI, p_IinG, v_IinG, bg, ba`. The JPL rotation is the transpose of the numerical Hamilton matrix, so SciPy's Hamilton interpretation of the emitted `xyzw` values gives IMU-to-G. Camera-state velocity is global and is not the body-frame velocity from `fast_state_propagate`.
- Resource/adaptation cost: no estimator process, rebuild, configuration change, or added dependency. Offline validation is linear in the 65 state rows and 1,604 truth rows in PR48.
- Decision: adopt the fixed state definitions and existing producer bytes. Do not infer North, calibrated covariance, reset, or quality.

## evo evaluation reference

- Project: `MichaelGrupp/evo`, observed head `9690a0cbf6ab6fe03ccc4a4d9d05bd9f36bccbe2` dated 2026-10-05.
- License: GPL-3.0. GitHub API snapshot reports non-archived and last push 2026-10-05.
- Official documentation: [metrics and alignment](https://github.com/MichaelGrupp/evo/wiki/Metrics) and [trajectory implementation](https://github.com/MichaelGrupp/evo/blob/master/evo/core/trajectory.py).
- Interfaces: APE/RPE, SE(3)/Sim(3) Umeyama alignment, and first-origin alignment. Whole-trajectory fitting changes the measured trajectory to optimize agreement; origin alignment applies one fixed transform.
- Resource/adaptation cost: adopting evo would add a package/CLI and a second trajectory schema. Existing NumPy/SciPy already supplies the required rotation and norm operations for 41 matched rows.
- Decision: use evo only as an evaluation reference. Reject whole-trajectory Umeyama, scale correction, time shift, and an evo runtime dependency for this prerequisite. Implement a narrower, prospectively named first-internal-state yaw/translation gauge so gravity tilt remains observable.

## Fixed evidence and frame boundary

- Input archive: `evidence/supported-online-vio-dev-1701.zip`, SHA-256 `07a2a247b87ff43304ec4c0fe787640264772ad12c272b354d5a5116cdecaeb2`.
- Six consumed members are verified against the embedded archive manifest before parsing; their identities are in `pr48-audit-v2.json`.
- Truth is FLU-to-world and is converted offline to BODY_FRD-to-world by right multiplication with `diag(1,-1,-1)`.
- The native estimator-global trajectory is scored offline. PX4 `LOCAL_FRD` position and `BODY_FRD` velocity remain the separate PR33 wire contract and are not emitted here.
- Truth does not participate in origin selection, estimator initialization, online correction, inputs, or control.
