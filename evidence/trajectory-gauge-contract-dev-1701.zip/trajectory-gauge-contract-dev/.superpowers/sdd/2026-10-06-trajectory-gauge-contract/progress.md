# SDD ledger — trajectory/gauge contract

Base: `5b442aa` on the existing isolated worktree. Previous goal turn classification: progress; it completed and published the exact launch-environment gate as PR59.

Standing authorization covers this offline contract and fixed-evidence audit. No new PX4, Gazebo, OpenVINS, training, ODOMETRY, arming, or EKF2 process is permitted in this plan.

Research: fixed OpenVINS `69488123ed9362dd44b6f28e7f4680abbff1442b` GPL-3.0 state definitions; current GitHub metadata still non-archived with last push 2025-11-30, so 2026 maintenance remains uncertain. evo head `9690a0cbf6ab6fe03ccc4a4d9d05bd9f36bccbe2` GPL-3.0 is a maintained evaluation reference. Whole-trajectory/scale/time fitting and a new evo dependency are rejected; existing NumPy/SciPy implements a fixed first-state 4DoF gauge.

Task 1 RED: the new test module initially failed collection because the contract module did not exist. First implementation produced 14 failures from an overly narrow vector helper that rejected its own validated NumPy slices. The helper was corrected without loosening scalar finite/type checks. Final analytic/fixed-input suite currently passes 15 tests and focused Ruff passes.

Contract: origin is the first internal state in the estimator session, selected without truth. The gauge applies yaw and translation only; scale=1, time shift=0, no later fit. Exact integer-ns truth association is mandatory. Startup after the motion anchor remains unavailable and cannot be retroactively scored. Unknown reset/quality or uncalibrated covariance keeps health/fusion false.

PR48 projection v1 is retained. Review renamed the potentially broad `accuracy_screens_pass` field to `diagnostic_screens_pass`; v2 is authoritative and v1 is not overwritten. Both consume the same sealed bytes with no estimator/physics replay.

Fixed projection v2: archive and six consumed members pass SHA/length/CRC checks. First internal origin is 2.4s, independent of truth; anchor is1.622s, so 778ms startup is unavailable. First public is2.8s. The partial 41-state diagnostic passes the development numeric screens (max position0.1024110826m, velocity0.1506612828m/s, attitude0.9675004506deg, gravity-axis0.0064045940deg), but the capture ended6.42s, public coverage is incomplete, reset/quality are unknown, covariance is uncalibrated, and trajectory/health/fusion/flight qualifications remain false.

Verification: 16 trajectory/gauge tests and 133 focused cross-contract tests pass. Full regression with the current worktree `src` passes 1,257 tests with 3 skips and 2 existing warnings in 287.65s. Changed-file Ruff and diff check pass. Whole-repository Ruff remains 53 findings in 34 files, exactly the `5b442aa` base count, so whole-tree lint is not claimed as passing.

Self-review Important: the original single `trajectory_qualified` name could overstate a future run whose scoring origin occurs after the motion anchor. The contract now distinguishes `post_origin_trajectory_qualified` and `full_motion_trajectory_qualified`; the latter, and the compatibility `trajectory_qualified` field, remain false whenever `startup_unavailable` exists. A synthetic complete healthy trajectory proves the post-origin gate can pass while the full-motion gate stays false. PR48 v3 is the authoritative projection; v1/v2 remain retained. The change passed 16 targeted tests and Ruff; a new final full regression is required because production code changed after the earlier 1,257-test run.

Self-review Important 2: state rows carried reset/quality and multiple wall-clock fields, but the first implementation only checked session-level reset/quality and within-row clock order. The audit now validates receive/start/end monotonicity across rows, initializer monotonicity, public regular-update availability, every row reset/quality type, reset transitions, and quality changes. Five new counterexamples pass after the fix. PR48 v4 is authoritative; all earlier outputs stay retained. Targeted suite is now21 passed and Ruff passes; final focused/full regression remains to run.

Final verification after all production changes: 21 contract tests; 138 focused cross-contract tests; full regression 1,262 passed/3 skipped/2 existing warnings in284.39s. Changed-file Ruff and diff check pass. Whole-tree Ruff remains53 findings/34 files, equal to base5b442aa and not claimed as passing.
