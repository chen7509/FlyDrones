# Prospective choices and source evidence

Gazebo installed libgz-sim8/plugins/dev8.15.0-1~noble. GitHub taggz-sim8_8.15.0 resolves446a44335a45b704b4d36dabcc5508ee34eeb3d8; repoApache-2.0,nonarchived,pushed2026-10-05T03:38:09Z (raw API metadata retained). Downloaded pinned Link.cc, Python binding, Physics.cc andLICENSE with hashes. Official Link and ApplyLinkWrench API documentation checked; existing Python method signatures inspected without starting a simulation.

|Candidate|Interface/resources/adaptation|Decision|
|---|---|---|
|Link.add_world_force|Installed Python binding; per-step force atCOM, sameECM/physics. One small optional fixture and250Hz isolated audit logging, no new dependency.|Adopt. Link.cc469–488 computesCOMtorque and callsAddWorldWrench. Physics.cc4108–4113 clearsExternalWorldWrenchCmd eachstep. Deterministic callback avoids extra transport timing.|
|ApplyLinkWrench system|InstalledApache2plugin, sameGazebo tag; world-frame one-shot/persistent topic protocol.|Available but reject for this stage: extra topic/subscription/clear lifecycle adds cost without need.|
|Old dynamic camera probe|Localprevioushelper directlysetsangularvelocity andzeroesgravity.|Reject: it is a separate kinematic sensor-axis fixture, not unchanged physical excitation.|
|Disable ZUPT|PinnedOpenVINS6948812,GPL3,existingCPU/OpenCVlibrary. Maintenancemetadata retainedPR36, nonarchived.|Reject as a presumedfix: initialization waitsforjerk withoutZUPT, and stationary geometry remains unobservable. No fork or configchange.|

Official https://gazebosim.org/api/sim/8/classgz_1_1sim_1_1Link.html supportsforceCOM/one-step semantics and enabling physics readback. https://docs.openvins.com/update-zerovelocity.html explains stationary geometry/ZUPT motivation. Geneva etal ICRA2020 https://pgeneva.com/downloads/papers/Geneva2020ICRA.pdf is estimator reference, not proof of this fixture. Actual nativepublic lifecycle is fixed-source PR36 snapshots. No library upgrade/rebuild, ROS orDDS install.

Force condition lateral-wrench-v1 is fixed prospectively in the spec. Ideal free2kg bounds2.6m/s and0.52m are analytical design estimates, not measured performance. Actualcontact/tilt can fail; abortwithin10ms supervisory chunks, unchanged1msphysics and sensorload. Truth abort monitor is explicitly simulator-only and isolated fromVIO; it must not be described as an onboard safety capability. Publicready output alone does not establish covariance calibration or fusion quality. Keep allfailedruns and do not retune this named condition after inspecting results.
