"""Read-only source/evidence preparation; never launches an estimator."""
import hashlib
import json
from pathlib import Path
import urllib.request

out = Path(__file__).resolve().parent / 'next-diagnosis-sources'
out.mkdir(exist_ok=False)
commit = '69488123ed9362dd44b6f28e7f4680abbff1442b'
files = ['ov_msckf/src/state/Propagator.cpp', 'ov_msckf/src/state/Propagator.h',
         'ov_msckf/src/update/UpdaterZeroVelocity.cpp', 'ov_msckf/src/core/VioManager.cpp',
         'ov_msckf/src/update/UpdaterMSCKF.cpp', 'ov_core/src/feat/FeatureInitializer.cpp',
         'ov_core/src/track/TrackKLT.cpp', 'LICENSE']
entries = []
for name, url in [('metadata.json', 'https://api.github.com/repos/rpng/open_vins')] + [
    (n.replace('/', '__'), f'https://raw.githubusercontent.com/rpng/open_vins/{commit}/{n}') for n in files]:
    try:
        request = urllib.request.Request(url, headers={'User-Agent': 'FlyDrones-evidence-research'})
        with urllib.request.urlopen(request, timeout=30) as response:
            data = response.read()
        with (out / name).open('xb') as stream: stream.write(data)
        entries.append(dict(file=name, url=url, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
    except Exception as exc:
        entries.append(dict(file=name, url=url, error=repr(exc)))
with (out / 'manifest.json').open('x') as stream: json.dump(entries, stream, indent=2)
print(json.dumps(entries, indent=2))
