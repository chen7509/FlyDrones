import hashlib
import json
from pathlib import Path
import sys

import numpy as np
from scipy.spatial.transform import Rotation
from pyulog import ULog

root=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(root),str(root/'src')]
from tools.benchmark.disarmed_sensor_provenance import audit_event_records
from tools.benchmark.openvins_online_shadow import validate_ack
base=Path(__file__).resolve().parent
p=base/'capture-v1'
read=lambda name:[json.loads(x) for x in (p/name).read_text().splitlines()]
result=json.loads((p/'result.json').read_text())
rows=read('events.jsonl'); counts=audit_event_records(rows,required_kinds={'imu','rgb','depth','info','heartbeat'})
commands=read('motion-force.jsonl'); truth=read('motion-ground-truth.jsonl')
assert len(commands)==1601 and all(c['call_returned'] for c in commands)
assert [c['sim_ns'] for c in commands]==list(range(5_000_000_000,6_601_000_000,1_000_000))
assert commands[-1]['force_world_n']==[0,0,0]
force=np.array([c['force_world_n'][1] for c in commands])
assert np.sum(force)*.001==0 and abs(np.sum(abs(force))*.001-41.6)<1e-10
pos=np.array([t['position'] for t in truth]);vel=np.array([t['velocity_world'] for t in truth]);rpy=np.array([t['rpy'] for t in truth])
assert len(truth)==6250 and np.isfinite(pos).all() and np.isfinite(vel).all()
disp=np.linalg.norm(pos-pos[0],axis=1);speed=np.linalg.norm(vel,axis=1)
assert disp.max()<=1 and speed.max()<=3 and abs(rpy[:,:2]).max()<=np.pi/4
states=read('shadow/states.jsonl');fast=read('shadow/fast.jsonl');requests=read('shadow/native-requests.jsonl');acks=read('shadow/native-acks.jsonl')
assert len(acks)==len(requests)==6501 and len(states)==250
for request,ack in zip(requests,acks):
    validate_ack(ack,sequence=request['sequence'],kind={'imu':'I','camera':'C'}[request['action']['kind']],
                 dispatch_ns=request['dispatch_ns'],acknowledged_ns=ack['acknowledged_ns'])
    if request['action']['kind']=='camera':
        a=request['action'];assert a['imu_boundary_ns']>a['sample_ns']
        payload=(p/'rgb-frames'/f"{a['sample_ns']}.ppm").read_bytes().split(b'\n',3)[3]
        assert hashlib.sha256(payload).hexdigest()==request['rgb_sha256']
    assert not ack['fusion_eligible'] and ack['quality'] is None and ack['reset_counter'] is None
assert all(f['available_imu_ns']>f['target_ns'] and f['filter_unchanged'] for f in fast)
truthmap={t['sim_ns']:t for t in truth}
imupairs=[(r,truthmap[r['sample_ns']]) for r in rows if r['kind']=='imu' and r['sample_ns'] in truthmap]
residuals=[]
for r,t in imupairs:
    rot=Rotation.from_quat(t['quaternion_xyzw'])
    predicted=rot.inv().apply(np.array(t['accel_world'])-[0,0,-9.80665])
    gyro=rot.inv().apply(t['angular_world'])
    residuals.append(dict(sim_ns=r['sample_ns'],gyro=np.array(r['gyro_flu'])-gyro,accel=np.array(r['accel_flu'])-predicted))
def summarize(values):
    a=np.array(values)
    return dict(count=len(a),median=float(np.median(a)),p95=float(np.percentile(a,95)),max=float(np.max(a))) if len(a) else None
res={}
for phase,start,end in [('static_before',1_000_000_000,5_000_000_000),('excitation',5_000_000_000,6_600_000_000),('settled_after',8_000_000_000,25_000_000_001)]:
    selected=[r for r in residuals if start<=r['sim_ns']<end]
    res[phase]=dict(gyro_norm=summarize([np.linalg.norm(r['gyro']) for r in selected]),
                    accel_norm=summarize([np.linalg.norm(r['accel']) for r in selected]))
initialized=[s for s in states if s['internal_initialized']]; public=[s for s in states if s['public_initialized']]
# Gauge-independent lower bound: no orientation fit/scale/trajectory alignment can
# make relative displacement norm difference smaller than this value.
anchor=next(s for s in states if s['sample_ns']==4_900_000_000)
assert anchor['internal_initialized']
anchor_pos=np.array(anchor['imu_state'][4:7]);anchor_truth=np.array(truthmap[anchor['sample_ns']]['position'])
trace=[]
for s in states:
    if s['sample_ns']<anchor['sample_ns']:continue
    t=truthmap[s['sample_ns']]
    vio=np.array(s['imu_state'][4:7])-anchor_pos
    actual=np.array(t['position'])-anchor_truth
    trace.append(dict(sample_ns=s['sample_ns'],vio_displacement_norm_m=float(np.linalg.norm(vio)),
                      physics_displacement_norm_m=float(np.linalg.norm(actual)),
                      translation_error_lower_bound_m=float(abs(np.linalg.norm(vio)-np.linalg.norm(actual))),
                      public_initialized=s['public_initialized']))
with (base/'displacement-trace.json').open('x') as f:json.dump(trace,f,indent=2)
ulogs=[]
for meta in result['px4_ulogs']:
    path=p/meta['path'];assert hashlib.sha256(path.read_bytes()).hexdigest()==meta['sha256']
    state=ULog(str(path)).get_dataset('vehicle_status').data['arming_state']
    assert np.all(state!=2)
    ulogs.append(dict(meta,arming_records=len(state),arming_values=[int(x) for x in np.unique(state)]))
summary=dict(capture_status=result['status'],requested_s=25,actual_s=result['end_sim_ns']/1e9,counts=counts,
             force_steps=len(commands)-1,absolute_impulse_ns=41.6,net_impulse_ns=0.,
             physics_displacement_max_m=float(disp.max()),physics_speed_max_m_s=float(speed.max()),
             physics_roll_pitch_max_deg=float(np.rad2deg(abs(rpy[:,:2]).max())),
             physics_final_position=pos[-1].tolist(),physics_final_speed_m_s=float(speed[-1]),
             internal_frames=len(initialized),public_frames=len(public),
             first_public_ns=public[0]['sample_ns'] if public else None,
             first_internal_ns=initialized[0]['sample_ns'] if initialized else None,
             fast_targets=len(fast),fast_success=sum(f['success'] for f in fast),fast_public=sum(f['public_initialized'] for f in fast),
             final_displacement_check=trace[-1],
             imu_truth_residuals=res,imu_truth_scope='same-stamp diagnostic; expected gravity9.80665; no timing fit or calibration grant',
             camera_callback_to_native_end_ms=summarize([(a['end_ns']-a['source_arrival_ns'])/1e6 for a in acks if a['kind']=='C']),
             ulogs=ulogs,fusion_eligible=False,readiness_flag_observed=bool(public),
             reliable_dynamic_vio_verified=False,source_or_estimator_root_cause_proven=False)
with (base/'audit.json').open('x') as f:json.dump(summary,f,indent=2)
print(json.dumps(summary,indent=2))
