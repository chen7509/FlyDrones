import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time
import zipfile

root=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(root),str(root/'src')]
from tools.benchmark.capture_disarmed_sensors import active_resources
from tools.benchmark.disarmed_motion_probe import profile
from tools.benchmark.openvins_online_shadow import validate_frozen_config

out=Path(__file__).resolve().parent
assert active_resources()==[]
archive=root/'evidence/openvins-online-shadow-dev-1701.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='8aab46377da3016b9cdc4e595fbaf8316383a3b75cbe5e36505545e0434c30fa'
prior=root/'results/openvins-online-shadow-dev-1701'
config=out/'raw-model-zero-bias-diffusion-v1'
config.mkdir(exist_ok=False)
with zipfile.ZipFile(archive) as z:
    prefix='results/openvins-online-shadow-dev-1701/'
    for name in ['estimator_config.yaml','kalibr_imu_chain.yaml','kalibr_imucam_chain.yaml','freeze.json']:
        data=z.read(prefix+'raw-model-zero-bias-diffusion-v1/'+name)
        assert data==(prior/'raw-model-zero-bias-diffusion-v1'/name).read_bytes()
        (config/name).write_bytes(data)
    assert z.read(prefix+'online_probe')==(prior/'online_probe').read_bytes()
validate_frozen_config(config/'estimator_config.yaml')
with (out/'prospective-profile.json').open('x') as f:
    json.dump(dict(profile=profile(),frozen_wall_ns=time.time_ns(),source_archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),f,indent=2)
px4=Path('/home/yuchen7509/PX4-Autopilot')
up=Path('/home/yuchen7509/flydrones-upstream/open_vins_vio_init_probe')
paths=[root/'tools/benchmark'/name for name in ['capture_disarmed_sensors.py','disarmed_sensor_provenance.py','disarmed_motion_probe.py',
       'openvins_causal_input.py','openvins_online_shadow.py','openvins_online_probe.cpp','openvins_fast_probe.h','exclusive_probe_output.h']]
paths+=list(config.glob('*'))+[prior/'online_probe',up/'ov_msckf/build/libov_msckf_lib.so',px4/'build/px4_sitl_default/bin/px4']
paths+=list((root/'assets/gazebo/models').glob('*/model.sdf'))+[px4/'Tools/simulation/gz/models/x500_base/model.sdf']
def snapshot(name):
    dest=out/name;dest.mkdir(exist_ok=False)
    hashes=[]
    for n,p in enumerate(paths):
        data=p.read_bytes();hashes.append(dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
        if p.suffix in ['.py','.cpp','.h','.sdf','.json','.yaml']:(dest/(str(n)+'-'+p.name)).write_bytes(data)
    (dest/'manifest.json').write_text(json.dumps(hashes,indent=2));return hashes
before=snapshot('producer-before')
command=[sys.executable,str(root/'tools/benchmark/capture_disarmed_sensors.py'),'--output',str(out/'capture-v1'),
         '--shadow-binary',str(prior/'online_probe'),'--shadow-config',str(config/'estimator_config.yaml'),'--motion-profile','lateral-wrench-v1']
with (out/'launch.json').open('x') as f:json.dump(dict(command=command,wall_ns=time.time_ns(),resources=active_resources()),f,indent=2)
with (out/'capture-v1-console.txt').open('x') as log:done=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
after=snapshot('producer-after')
result=dict(exit=done.returncode,unchanged=before==after,resources=active_resources(),wall_ns=time.time_ns())
with (out/'exit.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(result))
