"""Seal every retained artifact exclusively and verify every member digest."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

root = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent
snapshot = base / 'final-source'
snapshot.mkdir(exist_ok=False)
files = [
    'tools/benchmark/disarmed_motion_probe.py', 'tools/benchmark/capture_disarmed_sensors.py',
    'tools/benchmark/disarmed_sensor_provenance.py', 'tools/benchmark/openvins_online_shadow.py',
    'tools/benchmark/openvins_causal_input.py', 'tools/benchmark/openvins_online_probe.cpp',
    'tools/benchmark/openvins_fast_probe.h', 'tools/benchmark/exclusive_probe_output.h',
    'tests/benchmark/test_disarmed_motion_probe.py', 'docs/OPENVINS_MOTION_READINESS_REPORT.md',
    'docs/superpowers/specs/2026-10-06-openvins-motion-readiness.md',
    'docs/superpowers/plans/2026-10-06-openvins-motion-readiness.md',
    '.superpowers/sdd/2026-10-06-openvins-motion-readiness/progress.md',
    '.superpowers/sdd/2026-10-06-openvins-motion-readiness/review-ac77f7b..23ff25a.diff',
]
for name in files:
    dest = snapshot / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root / name, dest)
with (base / 'sealed-head.json').open('x') as stream:
    json.dump(dict(head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
                   status=subprocess.check_output(['git', 'status', '--short'], cwd=root, text=True)), stream, indent=2)
archive = root / 'evidence/openvins-motion-readiness-dev-1701.zip'
members = {}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
    for path in sorted(base.rglob('*')):
        if not path.is_file(): continue
        name, data = path.relative_to(root).as_posix(), path.read_bytes()
        members[name] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
        zipped.writestr(name, data)
    zipped.writestr('SHA256-MANIFEST.json', json.dumps(members, indent=2, sort_keys=True).encode())
with zipfile.ZipFile(archive) as zipped:
    assert zipped.testzip() is None
    assert len(zipped.namelist()) == len(members) + 1
    for name, meta in members.items():
        data = zipped.read(name)
        assert len(data) == meta['bytes'] and hashlib.sha256(data).hexdigest() == meta['sha256']
seal = dict(path=str(archive), bytes=archive.stat().st_size, members=len(members) + 1,
            sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
with (base / 'seal.json').open('x') as stream: json.dump(seal, stream, indent=2)
print(json.dumps(seal))
