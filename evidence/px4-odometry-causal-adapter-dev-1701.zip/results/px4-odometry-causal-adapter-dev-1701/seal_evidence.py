"""Seal this stage's explicitly named source, report, and test evidence."""

from __future__ import annotations

import hashlib
import json
import zlib
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


root = Path(__file__).resolve().parents[2]
result_dir = Path(__file__).resolve().parent
output = root / "evidence" / "px4-odometry-causal-adapter-dev-1701.zip"
sources = [
    root / "docs" / "superpowers" / "specs" / "2026-10-10-px4-odometry-causal-adapter-design.md",
    root / "docs" / "superpowers" / "plans" / "2026-10-10-px4-odometry-causal-adapter.md",
    root / "docs" / "PX4_ODOMETRY_CAUSAL_ADAPTER_REPORT.md",
    root / "src" / "flydrones" / "connectome_training" / "px4_odometry_adapter.py",
    root / "tests" / "connectome_training" / "test_px4_odometry_causal_adapter.py",
    *sorted(result_dir.glob("*.txt")),
    *sorted(result_dir.glob("*.json")),
    *sorted(result_dir.glob("*.py")),
    *sorted((root / "results").glob("px4-odometry-causal-adapter-*.txt")),
]
if len(sources) != len(set(sources)):
    raise RuntimeError("duplicate evidence path")
manifest = []
with ZipFile(output, "x", compression=ZIP_DEFLATED) as archive:
    for path in sources:
        payload = path.read_bytes()
        member = path.relative_to(root).as_posix()
        archive.writestr(member, payload)
        manifest.append({
            "path": member,
            "size": len(payload),
            "sha256": hashlib.sha256(payload).hexdigest(),
            "crc32": f"{zlib.crc32(payload):08x}",
        })
    archive.writestr("manifest.json", json.dumps(manifest, indent=2, sort_keys=True) + "\n")
with ZipFile(output) as archive:
    if archive.testzip() is not None:
        raise RuntimeError("bad zip CRC")
    for item in manifest:
        payload = archive.read(item["path"])
        if hashlib.sha256(payload).hexdigest() != item["sha256"]:
            raise RuntimeError(f"bad member hash: {item['path']}")
print(json.dumps({
    "path": str(output),
    "members": len(manifest) + 1,
    "sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
    "bytes": output.stat().st_size,
}, sort_keys=True))
