from pathlib import Path
from pyulog import ULog

path = Path('/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/results/openvins-health-physical-dev-1701-v2/development-seed-27201/capture-v1/px4-ulog/log/2026-10-07/12_15_00.ulg')
log = ULog(str(path), message_name_filter_list=['vehicle_odometry', 'vehicle_local_position', 'vehicle_attitude'])
for data in log.data_list:
    stamps = data.data.get('timestamp', [])
    print(data.name, 'instance', data.multi_id, 'count', len(stamps), 'first', int(stamps[0]) if len(stamps) else None, 'last', int(stamps[-1]) if len(stamps) else None)
    if data.name == 'vehicle_odometry':
        print('fields', sorted(data.data))
