from pathlib import Path
from hashlib import sha256
import json
import numpy as np
from pyulog import ULog

path = Path('/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/results/openvins-health-physical-dev-1701-v2/development-seed-27201/capture-v1/px4-ulog/log/2026-10-07/12_15_00.ulg')
expected = '55428c6d37e75d7fa2d53ab67a6527b4350fa020dca4a761a44fa7aec68d1028'
assert sha256(path.read_bytes()).hexdigest() == expected
log = ULog(str(path), message_name_filter_list=['vehicle_attitude', 'vehicle_local_position'])
att = next(d.data for d in log.data_list if d.name == 'vehicle_attitude' and d.multi_id == 0)
pos = next(d.data for d in log.data_list if d.name == 'vehicle_local_position' and d.multi_id == 0)
a = np.asarray(att['timestamp_sample'], dtype=np.int64)
p = np.asarray(pos['timestamp_sample'], dtype=np.int64)
idx = np.searchsorted(a, p, side='right') - 1
valid = idx >= 0
age = np.zeros(len(p), dtype=np.int64)
age[valid] = p[valid] - a[idx[valid]]
valid &= age <= 20_000
q = np.asarray([att[f'q[{i}]'] for i in range(4)], dtype=np.float64).T
selected_indices = np.flatnonzero(valid)
selected_q = q[idx[valid]]
norm = np.linalg.norm(selected_q, axis=1)
selected_indices = selected_indices[(norm >= .95) & (norm <= 1.05)]
selected_q = selected_q[(norm >= .95) & (norm <= 1.05)]
heading = np.asarray(pos['heading'], dtype=np.float64)[valid][(norm >= .95) & (norm <= 1.05)]
w,x,y,z = selected_q.T
computed = np.arctan2(2*(w*z+x*y), 1-2*(y*y+z*z))
finite = np.isfinite(heading)
error = np.abs((computed[finite]-heading[finite]+np.pi)%(2*np.pi)-np.pi)
selected_indices = selected_indices[finite]
outliers = selected_indices[error > .01]
print(json.dumps({'source_ulog_sha256':expected,'attitude_records':len(a),'local_position_records':len(p),'matched_finite_heading_count':len(error),'matching_window_us':20_000,'heading_abs_error_rad_p50':float(np.percentile(error,50)) if len(error) else None,'heading_abs_error_rad_p95':float(np.percentile(error,95)) if len(error) else None,'heading_abs_error_rad_max':float(np.max(error)) if len(error) else None,'outlier_over_0_01_rad_count':len(outliers),'outlier_first_ten': [{'position_sample_us':int(p[i]),'attitude_sample_us':int(a[idx[i]]),'error_rad':float(error[k])} for k,i in enumerate(selected_indices) if error[k]>.01][:10]},indent=2))
