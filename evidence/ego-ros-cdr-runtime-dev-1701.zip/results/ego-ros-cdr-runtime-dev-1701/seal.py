"""Seal only this completed bounded probe, preserving all retained failures."""

import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


repo = Path(__file__).resolve().parents[2]
base = Path("results/ego-ros-cdr-runtime-dev-1701")
members = [
    base / name
    for name in (
        "probe.py", "run.ps1", "verify.py", "seal.py", "preflight.json",
        "command.json", "stdout.json", "stderr.txt", "completion.json",
        "verification.json", "initial-runner-failure.txt",
        "adjacent-tests-path-failure.txt", "adjacent-tests.txt",
    )
]
members += [
    Path("docs/EGO_ROS_CDR_RUNTIME_REPORT.md"),
    Path("docs/superpowers/plans/2026-10-10-ego-causal-provenance.md"),
]
manifest = {
    "schema": "flydrones-ego-ros-cdr-runtime-evidence-v1",
    "members": {
        path.as_posix(): {
            "sha256": hashlib.sha256((repo / path).read_bytes()).hexdigest(),
            "bytes": (repo / path).stat().st_size,
        }
        for path in members
    },
}
output = repo / "evidence/ego-ros-cdr-runtime-dev-1701.zip"
output.parent.mkdir(parents=True, exist_ok=True)
with ZipFile(output, "w", compression=ZIP_DEFLATED) as archive:
    for path in members:
        archive.write(repo / path, path.as_posix())
    archive.writestr("manifest.json", json.dumps(manifest, sort_keys=True, indent=2) + "\n")
with ZipFile(output) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(manifest["members"]) | {"manifest.json"}
    for name, item in manifest["members"].items():
        data = archive.read(name)
        assert len(data) == item["bytes"]
        assert hashlib.sha256(data).hexdigest() == item["sha256"]
print(json.dumps({
    "archive": str(output),
    "sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
    "members": len(archive.namelist()),
    "bytes": output.stat().st_size,
}, sort_keys=True))
