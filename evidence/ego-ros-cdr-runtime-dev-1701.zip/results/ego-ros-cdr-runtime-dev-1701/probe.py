"""Read-only six-message ROS Humble serialization probe inside fixed image."""

import base64
import hashlib
import json
import struct
from pathlib import Path

import rclpy
from ament_index_python.packages import get_package_share_directory
from builtin_interfaces.msg import Time
from geometry_msgs.msg import Point, Pose, PoseStamped, Quaternion, Vector3
from nav_msgs.msg import Odometry
from quadrotor_msgs.msg import PositionCommand
from rclpy.serialization import serialize_message
from rosgraph_msgs.msg import Clock
from sensor_msgs.msg import Image
from std_msgs.msg import Header


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


time = Time(sec=0, nanosec=1000)
header = Header(stamp=time, frame_id="world")
point = Point(x=0.0, y=0.0, z=1.0)
vector = Vector3(x=0.0, y=0.0, z=0.0)
pose = Pose(position=point, orientation=Quaternion(x=0.0, y=0.0, z=0.0, w=1.0))

odom = Odometry()
odom.header = header
odom.child_frame_id = "base_link"
odom.pose.pose = pose

image = Image()
image.header = Header(stamp=time, frame_id="camera_optical")
image.height = image.width = 1
image.encoding = "32FC1"
image.is_bigendian = 0
image.step = 4
image.data = struct.pack("<f", 1.0)

command = PositionCommand()
command.header = Header(stamp=Time(sec=0, nanosec=9000), frame_id="world")
command.position = point
command.velocity = vector
command.acceleration = vector
command.yaw = command.yaw_dot = 0.0
command.trajectory_id = 7
command.trajectory_flag = PositionCommand.TRAJECTORY_STATUS_READY

messages = {
    "clock": Clock(clock=time),
    "odometry": odom,
    "trigger": PoseStamped(header=header, pose=pose),
    "camera_pose": PoseStamped(header=header, pose=pose),
    "depth": image,
    "position_command": command,
}
package = Path(__import__("quadrotor_msgs").__file__).resolve().parent
definition = Path(get_package_share_directory("quadrotor_msgs")) / "msg/PositionCommand.msg"
if not definition.is_file():
    raise RuntimeError("installed PositionCommand.msg missing")
result = {
    "schema": "flydrones-ego-ros-cdr-probe-v1",
    "rclpy_file": str(Path(rclpy.__file__).resolve()),
    "rclpy_file_sha256": sha(rclpy.__file__),
    "quadrotor_package": str(package),
    "position_command_msg_path": str(definition),
    "position_command_msg_sha256": sha(definition),
    "messages": {},
}
for kind, message in messages.items():
    raw = serialize_message(message)
    result["messages"][kind] = {
        "message_type": message.__class__.__module__ + "." + message.__class__.__name__,
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "cdr_b64": base64.b64encode(raw).decode("ascii"),
    }
print(json.dumps(result, sort_keys=True, separators=(",", ":")))
