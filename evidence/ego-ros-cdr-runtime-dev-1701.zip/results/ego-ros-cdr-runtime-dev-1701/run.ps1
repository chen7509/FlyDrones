$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$probe = Join-Path $root 'probe.py'
$expectedImage = 'sha256:a4dae62b38bc01a01d084be7b68db83ec804fef7673604e1a9c986a4baa88a6a'
$containerName = 'fly-ego-cdr-probe-1701'
$availableBefore = [double](Get-Counter '\Memory\Available MBytes').CounterSamples[0].CookedValue
$image = (& docker image inspect fly-ego-benchmark:humble --format '{{.Id}}').Trim()
$existing = [string]::Join('', @(& docker ps -a --filter "name=^/$containerName$" --format '{{.Names}}'))
$preflight = [ordered]@{
    schema = 'flydrones-ego-ros-cdr-runtime-preflight-v1'
    timestamp_utc = [DateTime]::UtcNow.ToString('o')
    available_memory_mib = $availableBefore
    min_available_memory_mib = 448
    image_id = $image
    expected_image_id = $expectedImage
    container_name = $containerName
    existing_owned_container = $existing
    probe_sha256 = (Get-FileHash -LiteralPath $probe -Algorithm SHA256).Hash.ToLowerInvariant()
}
$preflight | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $root 'preflight.json') -Encoding utf8
if ($availableBefore -lt 448 -or $image -ne $expectedImage -or $existing) {
    throw 'Bound ROS CDR probe preflight refused dispatch.'
}
$args = @(
    'run', '--rm', '--name', $containerName, '--pull', 'never',
    '--network', 'none', '--read-only', '--tmpfs', '/tmp:rw,size=16m',
    '--memory', '192m', '--memory-swap', '192m', '--cpus', '0.25',
    '--pids-limit', '64', '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges',
    '--mount', "type=bind,source=$probe,target=/probe.py,readonly",
    '--entrypoint', '/bin/bash', $expectedImage, '-lc',
    'source /opt/ros/humble/setup.bash && source /ego_ws/install/setup.bash && exec /usr/bin/timeout 15s python3 -B /probe.py'
)
[ordered]@{ executable = 'docker'; argv = $args } | ConvertTo-Json -Depth 5 |
    Set-Content -LiteralPath (Join-Path $root 'command.json') -Encoding utf8
$stdout = Join-Path $root 'stdout.json'
$stderr = Join-Path $root 'stderr.txt'
try {
    & docker @args 1> $stdout 2> $stderr
    $code = $LASTEXITCODE
} finally {
    $remaining = [string]::Join('', @(& docker ps -a --filter "name=^/$containerName$" --format '{{.Names}}'))
    [ordered]@{
        exit_code = $code
        available_memory_after_mib = [double](Get-Counter '\Memory\Available MBytes').CounterSamples[0].CookedValue
        owned_container_remaining = $remaining
        timestamp_utc = [DateTime]::UtcNow.ToString('o')
    } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $root 'completion.json') -Encoding utf8
}
if ($code -ne 0 -or $remaining) { throw "Bound ROS CDR probe failed: exit=$code remaining=$remaining" }
