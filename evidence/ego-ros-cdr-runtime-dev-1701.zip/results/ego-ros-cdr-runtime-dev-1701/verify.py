"""Independently decode retained rclpy CDR bytes with pinned rosbags."""

import base64
import hashlib
import json
import math
import struct
from pathlib import Path

from tools.benchmark.ego_cdr_field_audit import (
    MESSAGE_TYPES,
    POSITION_COMMAND_SHA256,
    _stamp_ns,
    _typestore,
    _validate_message,
)


root = Path(__file__).resolve().parent
source = (root / "stdout.json").read_bytes()
payload = json.loads(source)
assert payload["schema"] == "flydrones-ego-ros-cdr-probe-v1"
assert payload["position_command_msg_sha256"] == POSITION_COMMAND_SHA256
assert set(payload["messages"]) == set(MESSAGE_TYPES)
store = _typestore()
checks = {}
for kind, record in payload["messages"].items():
    raw = base64.b64decode(record["cdr_b64"], validate=True)
    assert len(raw) == record["bytes"] and len(raw) < 8_000_000
    assert hashlib.sha256(raw).hexdigest() == record["sha256"]
    msgtype = MESSAGE_TYPES[kind]
    message = store.deserialize_cdr(raw, msgtype)
    canonical = bytes(store.serialize_cdr(message, msgtype))
    assert canonical == raw, kind
    expected_stamp = 9_000 if kind == "position_command" else 1_000
    assert _validate_message(kind, message) == expected_stamp
    if kind == "clock":
        assert _stamp_ns(message.clock) == 1_000
    elif kind == "odometry":
        assert message.pose.pose.position.z == 1.0
        assert message.pose.pose.orientation.w == 1.0
    elif kind in ("trigger", "camera_pose"):
        assert message.pose.position.z == 1.0
        assert message.pose.orientation.w == 1.0
    elif kind == "depth":
        assert (message.height, message.width, message.step) == (1, 1, 4)
        assert struct.unpack("<f", bytes(message.data))[0] == 1.0
    elif kind == "position_command":
        assert message.trajectory_id == 7 and message.trajectory_flag == 1
        assert message.position.z == 1.0 and message.velocity.z == 0.0
        assert math.isfinite(message.yaw) and math.isfinite(message.yaw_dot)
    checks[kind] = {
        "cdr_bytes": len(raw),
        "cdr_sha256": record["sha256"],
        "stamp_ns": expected_stamp,
        "canonical_round_trip": True,
        "fixed_fields_verified": True,
    }

report = {
    "schema": "flydrones-ego-ros-cdr-runtime-verification-v1",
    "ros_probe_sha256": hashlib.sha256(source).hexdigest(),
    "position_command_msg_sha256": POSITION_COMMAND_SHA256,
    "message_checks": checks,
    "rclpy_to_rosbags_fixed_fixture_parity": True,
    "actual_bridge_journal_verified": False,
    "dds_transport_verified": False,
    "ego_cpp_serialization_verified": False,
    "planner_consumption_verified": False,
    "teacher_qualified": False,
}
(root / "verification.json").write_text(
    json.dumps(report, sort_keys=True, indent=2) + "\n", encoding="utf-8"
)
