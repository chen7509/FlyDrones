import json,hashlib
from pathlib import Path
from tools.benchmark.audit_live_wire_ulog import audit_unarmed_ulog
from tools.benchmark.declared_runtime_snapshot import file_record
capture=Path('results/openvins-health-physical-dev-1701-v2/development-seed-27201/capture-v1')
output=Path('results/live-wire-study-audit-dev-1701/ulog-fixed-v1'); output.mkdir(exist_ok=False)
manifest_path=capture/'px4-ulog-manifest.json'; before_manifest=file_record(manifest_path)
manifest=json.loads(manifest_path.read_bytes()); assert len(manifest['logs'])==1
entry=manifest['logs'][0]; path=capture/entry['path']
assert path.resolve().is_relative_to((capture/'px4-ulog').resolve())
before=file_record(path); raw=path.read_bytes()
try:
 verdict=audit_unarmed_ulog(raw,entry)
except Exception as exc:
 verdict=dict(unarmed_log_observations=False,refusal=repr(exc),live_qualified=False,fusion_qualified=False)
assert file_record(path)==before and file_record(manifest_path)==before_manifest
record=dict(scope='new offline ULog observation audit of prior development input; no replay or wire qualification',
 inputs=[before_manifest,before],sources=[file_record('tools/benchmark/audit_live_wire_ulog.py'),
 file_record('tools/benchmark/openvins_receiver_parity.py')],verdict=verdict)
(output/'audit.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
print(json.dumps(verdict,indent=2))
