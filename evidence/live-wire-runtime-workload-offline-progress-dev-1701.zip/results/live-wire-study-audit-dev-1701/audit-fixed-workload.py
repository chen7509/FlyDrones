"""Read-only new joins on retained development evidence; no estimator replay."""
import hashlib
import json
from pathlib import Path

from tools.benchmark.audit_live_wire_workload import audit_source_native_records
from tools.benchmark.declared_runtime_snapshot import file_record

capture = Path('results/openvins-health-physical-dev-1701-v2/development-seed-27201/capture-v1')
output = Path('results/live-wire-study-audit-dev-1701/workload-fixed-v1')
output.mkdir(exist_ok=False)
source = Path('tools/benchmark/audit_live_wire_workload.py')
source_pre = file_record(source)
(output/'producer.py').write_bytes(source.read_bytes())
inputs = {}

def read(name):
    path = capture/name
    before = file_record(path)
    data = path.read_bytes()
    assert before == file_record(path) and hashlib.sha256(data).hexdigest() == before['sha256']
    inputs[name] = before
    return data

def rows(name):
    data = read(name)
    assert data.endswith(b'\n')
    return [json.loads(line) for line in data.splitlines()]

sources = rows('events.jsonl')
payloads = {}
for row in sources:
    if row['kind'] == 'rgb':
        data = read('rgb-frames/'+str(row['sample_ns'])+'.ppm')
        header = b'P6\n160 120\n255\n'
        assert data.startswith(header)
        payloads[row['source_sequence']] = data[len(header):]
    elif row['kind'] == 'info':
        payloads[row['source_sequence']] = read(row['payload_path'])
terminal = json.loads(read('shadow/shadow-input-result.json'))
session = json.loads(read('shadow/native-session.json'))
arguments = dict(sources=sources, payloads=payloads, terminal=terminal, session_id=session['session_id'],
                 fanout=rows('source-fanout.jsonl'), requests=rows('shadow/native-requests.jsonl'),
                 acknowledgements=rows('shadow/native-acks.jsonl'), states=rows('shadow/states.jsonl'))
try:
    verdict = audit_source_native_records(**arguments)
except Exception as exc:
    verdict = dict(source_native_records_consistent=False, refusal=repr(exc), live_qualified=False, fusion_qualified=False)
for name, before in inputs.items():
    assert file_record(capture/name) == before
assert file_record(source) == source_pre
record = dict(scope='offline source/native joins on prior development; no replay or new live study',
              inputs=inputs, source_pre=source_pre, source_post=file_record(source), verdict=verdict)
with (output/'audit.json').open('x', encoding='utf8') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(verdict, indent=2))
