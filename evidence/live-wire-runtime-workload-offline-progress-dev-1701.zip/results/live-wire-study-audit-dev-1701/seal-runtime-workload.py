from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root = Path.cwd()
base = 'results/live-wire-study-audit-dev-1701/'
output = root/'evidence/live-wire-runtime-workload-offline-progress-dev-1701.zip'
files = [
    'tools/benchmark/audit_live_wire_runtime.py', 'tools/benchmark/audit_live_wire_ulog.py',
    'tools/benchmark/audit_live_wire_workload.py', 'tools/benchmark/audit_live_wire_study.py',
    'tools/benchmark/native_supervisor_integration.py', 'tools/benchmark/openvins_receiver_parity.py',
    'tools/benchmark/owned_runtime_maps.py', 'tools/benchmark/openvins_causal_input.py',
    'tools/benchmark/openvins_online_shadow.py', 'tools/benchmark/disarmed_sensor_provenance.py',
    'tools/benchmark/ready_shadow_fanout.py', 'tools/benchmark/runtime_resource_binding.py',
    'tests/benchmark/test_live_wire_runtime_audit.py', 'tests/benchmark/test_live_wire_ulog_audit.py',
    'tests/benchmark/test_live_wire_workload_audit.py',
    'docs/LIVE_WIRE_RAW_EVIDENCE_MAP.md', 'docs/LIVE_WIRE_STUDY_PREPARATION_REPORT.md',
    'docs/superpowers/specs/2026-10-08-live-wire-study-design.md',
    'docs/superpowers/plans/2026-10-08-live-wire-study.md',
    '.superpowers/sdd/2026-10-08-live-wire-study/progress.md',
]
names = [
    'runtime-red-v1.txt', 'runtime-green-v1.txt', 'runtime-supervisor-red-v1.txt',
    'runtime-supervisor-green-v1.txt', 'runtime-boundary-red-v1.txt', 'runtime-final-regression-v1.txt',
    'ulog-red-v1.txt', 'ulog-green-v1.txt', 'ulog-boundary-regression-v1.txt',
    'workload-red-v1.txt', 'workload-red-v2.txt', 'workload-green-v1.txt',
    'workload-boundary-red-v1.txt', 'workload-regression-v1.txt',
    'workload-fixed-console-v1.txt', 'workload-fixed-console-v2.txt', 'workload-fixed-console-v3.txt',
    'runtime-workload-diff-check.txt', 'runtime-workload-ruff-v1.txt',
    'audit-fixed-runtime.py', 'audit-fixed-supervisor.py', 'audit-fixed-ulog.py',
    'audit-fixed-workload.py', 'audit-fixed-workload-v2.py', 'audit-fixed-workload-v3.py',
    'runtime-fixed-v1/audit.json', 'supervisor-fixed-v1/audit.json', 'ulog-fixed-v1/audit.json',
    'workload-fixed-v1/producer.py', 'workload-fixed-v2/producer.py', 'workload-fixed-v2/audit.json',
    'workload-fixed-v3/producer.py', 'workload-fixed-v3/audit.json', 'seal-runtime-workload.py',
]
files += [base+name for name in names]
assert len(files) == len(set(files))
blobs = {name:(root/name).read_bytes() for name in files}
members = [dict(path=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()) for name,raw in blobs.items()]
manifest = dict(
    schema='offline-wire-progress-evidence-v1',
    producer_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    scope='offline raw runtime/ULog/normal-supervisor/source-native joins; Task2 incomplete',
    source_capture='results/openvins-health-physical-dev-1701-v2/development-seed-27201/capture-v1',
    original_input_bytes_duplicated=False,
    input_references='Each fixed audit records original consumed input hashes; old capture remains unchanged.',
    original_runtime_helper_source_preserved=False,
    runtime_positive_boundary='runtime-fixed-v1 records earlier helper hash; final role/budget guards tested synthetically only.',
    live_qualified=False, fusion_qualified=False, whole_package_review_complete=False, members=members,
)
with zipfile.ZipFile(output, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name,raw in blobs.items():
        archive.writestr(name,raw)
    archive.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(output) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(files)+1
    for member in members:
        raw = archive.read(member['path'])
        assert len(raw) == member['bytes'] and hashlib.sha256(raw).hexdigest() == member['sha256']
print(json.dumps(dict(path=str(output), members=len(files)+1, bytes=output.stat().st_size,
                     sha256=hashlib.sha256(output.read_bytes()).hexdigest(), crc_verified=True)))
