import json,hashlib
from pathlib import Path
from tools.benchmark.audit_live_wire_runtime import audit_runtime_mapping_records
from tools.benchmark.declared_runtime_snapshot import file_record
capture=Path('results/openvins-health-physical-dev-1701-v2/development-seed-27201/capture-v1')
output=Path('results/live-wire-study-audit-dev-1701/runtime-fixed-v1'); output.mkdir(exist_ok=False)
inputs={}
def read(name, raw=False):
 p=capture/name
 before=file_record(p); data=p.read_bytes(); after=file_record(p)
 assert before==after and hashlib.sha256(data).hexdigest()==before['sha256']
 inputs[name]=before
 return data.decode('utf8') if raw else json.loads(data)
pre=read('runtime-binding-pre.json'); post=read('runtime-binding-post.json'); result=read('result.json')
d=pre['declaration']; maps={}; owners={}
for phase in ['postgraph','bootstrap',*d['runtime_maps']['self_phases']]:
 name='runtime-maps-'+phase
 maps[name]=dict(raw=read(name+'.txt',True),summary=read(name+'.json'))
for role,phases in d['runtime_maps']['owned_roles'].items():
 owners[role]=read('runtime-owner-'+role+'.json')
 for phase in phases:
  name='runtime-maps-'+role+'-'+phase
  maps[name]=dict(raw=read(name+'.txt',True),summary=read(name+'.json'))
process=read('process.json')
try:
 verdict=audit_runtime_mapping_records(declaration=d,pre=pre,post=post,summary=result['runtime_binding'],maps=maps,owners=owners,process=process)
except Exception as exc:
 verdict=dict(runtime_records_consistent=False,refusal=repr(exc),live_qualified=False,fusion_qualified=False)
for name,before in inputs.items(): assert file_record(capture/name)==before
record=dict(capture=str(capture),scope='new offline raw mapping audit of prior development run; no replay or wire qualification',
 inputs=inputs,source=file_record('tools/benchmark/audit_live_wire_runtime.py'),verdict=verdict)
(output/'audit.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
print(json.dumps(verdict,indent=2))
