import json,hashlib
from pathlib import Path
from tools.benchmark.native_supervisor_integration import audit_supervisor
from tools.benchmark.declared_runtime_snapshot import file_record
capture=Path('results/openvins-health-physical-dev-1701-v2/development-seed-27201/capture-v1')
output=Path('results/live-wire-study-audit-dev-1701/supervisor-fixed-v1'); output.mkdir(exist_ok=False)
inputs={}
def read(path, lines=False):
 before=file_record(path); raw=path.read_bytes()
 assert file_record(path)==before and hashlib.sha256(raw).hexdigest()==before['sha256']
 inputs[str(path)]=before
 return [json.loads(line) for line in raw.decode().splitlines()] if lines else json.loads(raw)
summary=read(capture/'supervisor.json')
journal=read(capture.with_name(capture.name+'.supervisor-events.jsonl'),True)
verdict=audit_supervisor(summary,journal,profile='normal-capture-v1')
for name,before in inputs.items(): assert file_record(name)==before
record=dict(scope='offline normal-profile cleanup audit of prior retained development run; no rerun',
 inputs=inputs,source=file_record('tools/benchmark/native_supervisor_integration.py'),verdict=verdict)
(output/'audit.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
print(json.dumps(verdict,indent=2))
