# Independent static-v2 coordinator pre-dispatch review

Verdict: **changes required; C0 / I2 / M0**. No actual static dispatch is cleared by this review.

Scope: Task3 coordinator and fixtures at the exact source identities below, read against the production plan/design. Task1/Task2 previously sealed work is treated as an established dependency; its old tests/native stages were not rerun or reopened. Only this review pair was written. No tests, admission/resource probes, WSL/native commands, process/PID actions, or Git actions were executed by the reviewer.

## Findings

**I1 — Complete current input identity coverage and post-command joins (coordinator lines 104–134, 337–351).** `linux_preidentity` excludes historical Python roots, but never adds the current imported Python native-extension/module paths that `prepare_v2` gathers from `sys.modules`. The current selection fixture only asserts omission of an old extension and inclusion of renderer/candidate paths; it does not assert current-extension inclusion. Scene and immutable Agent cache are independently validated into `scene`/`agent_cache`, but are absent from `files_before`; `linux_postidentity` only rechecks `files_before` and source hashes. Thus those pre-command observations are not joined to post-command observations. Include the current import selection and the original scene/cache/configuration identities in the retained before/after contract, then fail closed if any required member/identity changes. Full final study verification remains necessary but does not replace the explicit coordinator joins required by this spec.

**I2 — Later file-pin failure discards earlier successful observations (coordinator lines 104–125, 337–349).** Catalog parsing, initial `before = [file_record(...)]`, and postidentity's `current = [file_record(...)]` happen before their observation is durably persisted. If the second/later file is missing/unreadable, earlier successful pins disappear; a preidentity subprocess error/traceback or outer completion error does not retain those earlier structured file records. Build and persist partial observation lists under `try/finally`, retaining the primary pin failure and separate persistence errors. Add fixture failures after at least one successful initial and post-command file pin. The version helper now correctly preserves an earlier query across post-pin/journal errors; the same retention rule must cover file identity collection.

## Confirmed behavior

- Literal v2 folder and original `--prepare-only -m tools.benchmark.prepare_calibration_capture_v2` invocation; no arbitrary worker/physical override.
- Exclusive source/admission/attempt journals prevent replay. Two fresh dual-1-GiB resource collections precede the claim; first/second refusal leaves the native attempt unconsumed and prior facts prohibit polling/replay.
- Static command retains 512 MiB, swap0, CPU100%, Tasks64, scope210s, inner180s+kill10s, outer240s. Original physical limits were not changed by the coordinator.
- Own UID joins the separate manager environment. Unit stop requires a fresh InvocationID and matching cgroup, while unknown ownership forbids stop. Owned launcher cleanup is bounded and escaped closure remains unknown.
- Post-spawn journal/timeout/verification errors reach cleanup; completion fallback preserves a primary error. Version helper retains partial owned query on post-pin failure.
- Actual final study is reverified through the fixed registry. Source before/after equality is a terminal success condition. Tool queries retain local monotonic intervals with UTC facts; coordinator attempt has its own local interval, without cross-host duration inference.
- Public admission facts exclude unrelated process inventory; private observations are kept separately. This report does not reproduce process inventory contents.

## Retained evidence

Read retained six missing-interface RED → six GREEN; three behavioral lifecycle RED → nine GREEN; version-helper missing-interface RED → ten GREEN; historical-Python-selection behavioral RED → combined 64 GREEN (3.17s). These are software fixtures, not native/runtime results. Initial unused-os Ruff failure remains, and final retained preidentity Ruff is zero. Final GREEN source-before/source-after pins equal the exact reviewed source hashes below. No reviewer rerun was performed.

The initial read-only resource sample is historical and explicitly not dispatch admission. Actual v2 first-admission/attempt/study records and frozen-study-v2 were absent in the production folder during inspection. All eight qualifications remain false; no rendering, physics, Agent/PX4, calibration, physical capture, or native-consumer result is established.

## Exact reviewed identities

| Path | SHA-256 |
| --- | --- |
| results/target-bearing-runtime-freeze-v2-dev-1701/run-static-preparation-v2.py | e3dd794b5744ee54124d2cd9eb79e635a256f9416c9eba223694c41a044e5072 |
| tests/benchmark/test_calibration_static_v2_executor.py | 550388be637a0ff8c851e192e41a6de4e570922d37e724ee6304db1281955a37 |
| tools/benchmark/prepare_calibration_capture_v2.py | 068f52eac326024a72cba0c06bf8fcca2bddc71536c5f279880540afc48cb7c0 |
| tools/benchmark/native_entry_dependencies.py | 38bdb30431abb6d399f0a79c20671c7a7d75ecf444436b7a0d956f08bed988ea |
| tools/benchmark/calibration_capture_study_v2.py | 00cd4c5890a6833af8f3656d8665a2888614f37bcb40dffef534474125202fc2 |

Limitations: read-only source/retained-evidence review, with fixture behavior assessed from retained actual output. No successful Linux preidentity/version query, systemd scope, SDK trace, cgroup release, final v2 graph, or physical result has been observed. Findings must be resolved and independently re-reviewed at fresh exact hashes before any native scope.
