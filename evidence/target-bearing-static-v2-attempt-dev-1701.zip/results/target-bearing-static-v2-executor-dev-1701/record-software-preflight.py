import datetime,hashlib,json,subprocess
from pathlib import Path
root=Path.cwd();raw=root/'results/target-bearing-static-v2-executor-dev-1701'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(root/'evidence/target-bearing-entry-dependency-production-dev-1701.zip')=='124c4e8550ff8e1d85c23dc725223f95d00f3841117c427b058266b3a7c6fe43'
assert not (root/'results/target-bearing-runtime-freeze-v2-dev-1701/attempt.json').exists()
assert not (root/'results/target-bearing-runtime-freeze-v2-dev-1701/frozen-study-v2').exists()
code=root/'results/target-bearing-runtime-freeze-v2-dev-1701/run-static-preparation-v2.py'
recipe=dict(schema='static-v2-coordinator-pre-dispatch-recipe-v1',status='PROSPECTIVE_NOT_DISPATCHED',utc=datetime.datetime.now(datetime.UTC).isoformat(),base=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),coordinator=dict(path=code.relative_to(root).as_posix(),sha256=sha(code)),test_sha256=sha(root/'tests/benchmark/test_calibration_static_v2_executor.py'),static_limits=dict(reserve_each_bytes=1073741824,memory_max_bytes=536870912,swap_max_bytes=0,cpu_percent=100,tasks=64,scope_seconds=210,inner_seconds=180,kill_after_seconds=10,scope_launcher_wait_seconds=240),preidentity_limits=dict(inner_seconds=30,kill_after_seconds=5,parent_wait_seconds=45),postidentity_parent_seconds=30,manager_control_seconds_each=15,qualification=False,mandatory_pending='Independent code review, onlypersonal code commit/push, fresh actual two admissions and Linux file/version identities; actual claim consumes attempt',first_red=dict(exit=int((raw/'first-red-exit.txt').read_text().strip()),stdout_path='first-red.txt',tool_session=80411,start_clock_persisted=False,precommand_source_snapshot_persisted=False,statement='Six missing-interface software failures; direct PowerShell command. No later clock/source fills this gap.'))
with (raw/'prospective-coordinator-recipe.json').open('xb') as f:f.write(json.dumps(recipe,indent=2).encode())
ledger=root/'.superpowers/sdd/2026-10-15-target-bearing-entry-dependency-production/progress.md'
with ledger.open('ab') as f:f.write(b'\nTask3: in progress; BASE d12ecd846627b91d91bb53887efeb7e60607ec00. New fixed once coordinator/lifecycle software; oldTask1/2 not repeated as progress. Preidentity30s+5kill/45parent and postidentity30s/control15s each separate from unchanged210scope180inner240launcher wait. No actual native scope yet; retain all raw/private/failed evidence.\n')
print(json.dumps(dict(coordinator_sha256=recipe['coordinator']['sha256'],actual_attempt=False)))
