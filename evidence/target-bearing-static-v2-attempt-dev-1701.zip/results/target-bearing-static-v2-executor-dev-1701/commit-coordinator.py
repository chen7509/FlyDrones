import datetime,hashlib,json,subprocess
from pathlib import Path
root=Path.cwd();raw=root/'results/target-bearing-static-v2-executor-dev-1701'
r=json.loads((raw/'independent-coordinator-review-final.json').read_bytes())
assert r.get('counts')==dict(critical=0,important=0,minor=0)
verification=json.loads((raw/'review-green-final.json').read_bytes());assert verification['exit']==0 and verification['source_before']==verification['source_after']
for name,sha in verification['source_after'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha
assert set(subprocess.check_output(['git','diff','--cached','--name-only']).decode().splitlines())=={'results/target-bearing-runtime-freeze-v2-dev-1701/run-static-preparation-v2.py','tests/benchmark/test_calibration_static_v2_executor.py'}
assert subprocess.run(['git','diff','--cached','--check']).returncode==0
for label,argv in [('coordinator-commit',['git','commit','-m','Add admitted once-only static v2 preparation coordinator']),('coordinator-push',['git','push','personal','HEAD'])]:
    p=subprocess.run(argv,capture_output=True)
    with (raw/(label+'.json')).open('xb') as f:f.write(json.dumps(dict(argv=argv,exit=p.returncode,stdout_hex=p.stdout.hex(),stderr_hex=p.stderr.hex(),utc=datetime.datetime.now(datetime.UTC).isoformat()),indent=2).encode())
    assert p.returncode==0,p.stderr.decode(errors='replace')
print(subprocess.check_output(['git','rev-parse','HEAD']).decode())
