import datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path.cwd();raw=root/'results/target-bearing-static-v2-executor-dev-1701';label=sys.argv[1];argv=sys.argv[2:]
names=['results/target-bearing-runtime-freeze-v2-dev-1701/run-static-preparation-v2.py','tests/benchmark/test_calibration_static_v2_executor.py','tools/benchmark/prepare_calibration_capture_v2.py','tools/benchmark/native_entry_dependencies.py','tools/benchmark/calibration_capture_study_v2.py']
def pins():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in names if (root/p).is_file()}
env=dict(os.environ,PYTHONPATH=str(root/'src')+os.pathsep+str(root),PYTHONUTF8='1')
record=dict(argv=argv,start_utc=datetime.datetime.now(datetime.UTC).isoformat(),source_before=pins(),python=sys.version,executable=sys.executable,environment={k:env[k] for k in ['PYTHONPATH','PYTHONUTF8']})
with (raw/(label+'.stdout')).open('xb') as out,(raw/(label+'.stderr')).open('xb') as err:p=subprocess.run(argv,stdout=out,stderr=err,env=env)
record.update(exit=p.returncode,end_utc=datetime.datetime.now(datetime.UTC).isoformat(),source_after=pins())
with (raw/(label+'.json')).open('xb') as f:f.write(json.dumps(record,indent=2).encode())
print(json.dumps(dict(label=label,exit=p.returncode)));print((raw/(label+'.stdout')).read_text(encoding='utf8',errors='replace')[-4000:]);print((raw/(label+'.stderr')).read_text(encoding='utf8',errors='replace')[-1000:])
