import hashlib,json,zipfile
from pathlib import Path
root=Path.cwd();raw=root/'results/target-bearing-static-v2-executor-dev-1701';actual=root/'results/target-bearing-runtime-freeze-v2-dev-1701'
review=json.loads((raw/'independent-actual-review.json').read_bytes());assert review['counts'] in [dict(C=0,I=0,M=0),dict(critical=0,important=0,minor=0)]
docs=json.loads((raw/'independent-report-review-final.json').read_bytes());assert docs['counts'] in [dict(C=0,I=0,M=0),dict(critical=0,important=0,minor=0)]
run=json.loads((raw/'actual-once.json').read_bytes());assert run['exit']==1 and run['source_before']==run['source_after']
for p,h in run['source_after'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h
c=json.loads((actual/'completion.json').read_bytes());assert c['attempt_consumed'] is True and c['exit']==1 and c['owned_group_released'] is True and c['source_stable'] is True
old=json.loads((root/'results/target-bearing-entry-dependency-production-dev-1701/historical-archives-before.json').read_bytes())['files']
old.append(dict(path='evidence/target-bearing-entry-dependency-production-dev-1701.zip',bytes=6220873,sha256='124c4e8550ff8e1d85c23dc725223f95d00f3841117c427b058266b3a7c6fe43'))
assert len(old)==284 and sum(r['bytes'] for r in old)==778750978
for row in old:
    path=root/row['path'];h=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
    assert path.stat().st_size==row['bytes'] and h.hexdigest()==row['sha256']
with (raw/'historical-archives-postattempt-before-seal.json').open('xb') as stream:stream.write(json.dumps(dict(files=sorted(old,key=lambda r:r['path']),count=284,bytes=778750978,all_streamed_sha_equal=True,scope='POSTattempt audit, not predispatch observation'),indent=2).encode())
private=[raw/'initial-admission-private.json',actual/'first-admission-private.json',actual/'second-admission-private.json']
excluded=set(private)|{raw/'archive-seal-receipt.json',raw/'independent-archive-review.json',raw/'independent-archive-review.md'}
paths=[p for base in [raw,actual] for p in base.rglob('*') if p.is_file() and p not in excluded and '__pycache__' not in p.parts and p.suffix!='.pyc']
paths += [root/p for p in ['tests/benchmark/test_calibration_static_v2_executor.py','tools/benchmark/prepare_calibration_capture_v2.py','tools/benchmark/native_entry_dependencies.py','tools/benchmark/calibration_capture_study_v2.py','tools/benchmark/calibration_capture_study.py','docs/TARGET_BEARING_STATIC_V2_ATTEMPT_REPORT.md','docs/superpowers/specs/2026-10-15-target-bearing-entry-dependency-production-design.md','docs/superpowers/plans/2026-10-15-target-bearing-entry-dependency-production.md','docs/superpowers/specs/2026-10-15-zero-needed-python-entry-research-design.md','docs/superpowers/plans/2026-10-15-zero-needed-python-entry-research.md','.superpowers/sdd/2026-10-15-target-bearing-entry-dependency-production/progress.md']]
paths=sorted(set(paths));records=[]
for path in paths:
    data=path.read_bytes();records.append(dict(path=path.relative_to(root).as_posix(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
manifest=root/'evidence/target-bearing-static-v2-attempt-dev-1701.sha256.json'
with manifest.open('xb') as stream:stream.write(json.dumps(dict(schema='sealed-working-byte-map-v1',scope='Consumed actual static-v2 failure with software coordinator and complete partial records; no full runtime freeze/physics/source/calibration',members=records,private_originals=[dict(path=p.relative_to(root).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),policy='LOCAL_UNPUBLISHED') for p in private],qualification={k:False for k in ['source','clock','measured_calibration','accuracy','teacher','fusion','training','flight']}),indent=2).encode())
target=root/'evidence/target-bearing-static-v2-attempt-dev-1701.zip'
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for path in paths:archive.write(path,path.relative_to(root).as_posix())
    archive.write(manifest,manifest.relative_to(root).as_posix())
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None and len(archive.namelist())==len(records)+1
    for row in records:
        data=archive.read(row['path']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
receipt=dict(path=target.relative_to(root).as_posix(),bytes=target.stat().st_size,members=len(records)+1,mapped_members=len(records),sha256=hashlib.sha256(target.read_bytes()).hexdigest())
with (raw/'archive-seal-receipt.json').open('xb') as stream:stream.write(json.dumps(receipt,indent=2).encode())
print(json.dumps(receipt))
