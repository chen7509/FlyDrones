# SDD ledger - plan: docs/superpowers/plans/2026-10-15-target-bearing-entry-dependency-production.md

Task 1: in progress; BASE a71401009b604db97938cd68d7fbf6ffff0dbf91.
Pre-flight: Task1 entry bill -> Task2 v2 study: exact schema, complete candidate/tool/entry/current-file joins required; no conflict. Task2 fixed v2 study -> Task3 static -> Task4 existing single physical attempt: v1 immutable, literal registry routes only, old budgets/once guards unchanged.
Ruling: retain all raw/failed evidence and plan ledger; do not delete skill workspace or old inputs because user preservation instruction overrides scratch cleanup. Existing isolated named worktree reused. Native stages cannot be completed by software fixture tests.

Task1/Task2 software implemented and independently reviewed C0/I0/M0; real native entry/context/SDK/static-v2 and physical stages remain untested. Six behavior checkboxes done, two commit/seal checkboxes pending. Actual v2 scope/study/coordinator absent and unconsumed. Current recipe is prospective; no Linux pre-attestation. All raw/bootstrap/behavior/review failures retained.

Task3: in progress; BASE d12ecd846627b91d91bb53887efeb7e60607ec00. New fixed once coordinator/lifecycle software; oldTask1/2 not repeated as progress. Preidentity30s+5kill/45parent and postidentity30s/control15s each separate from unchanged210scope180inner240launcher wait. No actual native scope yet; retain all raw/private/failed evidence.
