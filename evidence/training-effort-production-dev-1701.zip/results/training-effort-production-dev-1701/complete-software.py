import hashlib,json
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes().decode('utf-8-sig'))
def save(n,b):
 with (raw/n).open('xb') as f:f.write(b)
review=load(raw/'review-source-map.json')
for r in review:assert sha((root/r['path']).read_bytes())==r['sha256']
assert load(raw/'effort-final.json')['exit']==0 and b'15 passed in 5.49s' in (raw/'effort-final.stdout').read_bytes()
assert load(raw/'effort-affected.json')['exit']==0 and b'83 passed, 1 warning in 12.10s' in (raw/'effort-affected.stdout').read_bytes()
assert load(raw/'effort-final-lint.json')['exit']==0 and load(raw/'effort-final-diff.json')['exit']==0
plan=root/'docs/superpowers/plans/2026-10-16-training-effort-production.md';old=plan.read_bytes();new=old.replace(b'- [ ]',b'- [x]',2);assert new.count(b'- [x]')==2 and new.count(b'- [ ]')==1;plan.write_bytes(new)
offsets=[i for i,(a,b) in enumerate(zip(old,new)) if a!=b];assert len(offsets)==2
save('review-plan-seal-join.json',json.dumps(dict(review_plan_sha256=sha(old),seal_plan_sha256=sha(new),changed_byte_offsets=offsets,all15_original_review_source_exact_before_checkbox_change=True,product_and_test_no_changes_after_original_review=True),indent=2).encode())
save('executor-fix-pass.md',b'''# Single bounded executor verification

Original whole source review C0/I0/M0, fifteen independently read/pinned files, no fix required. No fake fix, behavioral RED or second whole source review. Final ordinary new9+state6 =15passed5.49s/no warnings; necessary affected83passed12.10s/oneCSR warning on identical production/test bytes. Ruff0/dedicateddiff0. Initial five failures were missing reporting interfaces after actual tiny training, not behavior/native RED. Four later coverage tests directly passed.

Final Ruling: full convergence/equal-effort/upstream/flight qualification remains false; counters do not claim it. Cost if wrong: conclusions still cannot use this software as scientific/flight evidence.
Final Ruling: resource/memory/latency/CUDA/Linux/SDK judgments remain unmeasured and not queried; no associated claim. Cost if wrong: original native admission and measurement still required.
Final Ruling: historical/hostile/concurrent/reentrant/asynchronous interruption authentication is outside the internal software counter contract. Cost if wrong: adversarial/reentrant use can misstate counters; no certified total-work claim.
Final Ruling: error snapshot is copied in memory before del current, persisted later by ordinary outer error handler; unwritable output/kill/powerloss can lose it. No crash journal promise or repaired DL-M1. Cost if wrong: partial work requires retained ordinary exception output and cannot be reconstructed from absent evidence.
Final Ruling: source reviewer did not reproduce tests or audit delivery; actual recorder verification plus separate integrity delivery handles that scope, never source/native reapproval. Cost if wrong: delivery limits must remain explicit and no target qualification follows.

No deferred minors. Current session lifetime counts do not rewind on rollback; fresh restored session starts zero. Optimizer call return is not parameter-change proof, raised call can already mutate; partial backward frames omitted explicitly. No resources/targetnative/consumed attempt or old evidence repair.
''')
invs=[load(p) for p in raw.glob('*-fixtures.json')];payloads=[r for inv in invs for r in inv['retained_payload'] if 'sha256' in r]
runs=[load(raw/(p.name.removesuffix('-fixtures.json')+'.json')) for p in raw.glob('*-fixtures.json')]
assert all(len(r['source_before'])==30 and not any(x.get('absent') for x in r['source_before']) for r in runs)
assert all(r['source_before']==r['source_after'] for r in runs if r['argv'][1:3]==['-m','pytest'])
report=f'''# Actual training effort production

Existing trainer.py now accounts directly around actual sequence backward and optimizer.step, actual curriculum_session owns one live lifetime counter, and actual role_comparison exports detached snapshots in successful rows and ordinary exception records. This addresses the previous producer's missing actual call/exposure counts. It does not run full MaleCNS or establish equal compute/fair upstream comparison. No standalone validator or metadata-only exporter substitutes for these production consumers.

Nine integer fields distinguish admitted epoch/sequence calls, fully returned backward sequences/frames, actual optimizer calls started/returned/raised and frames associated with normally returned optimizer calls. Batch-times-time sample frames are counted. Whole backward passes only earn frame credit after return; partial-window work is explicitly omitted. A normally returning optimizer call is not proof of parameter change; a raised call may already have updated parameters. Counters are software bookkeeping, not authenticated hardware work or equal-effort certification.

Session lifetime starts at construction and is never serialized/restored/rewound in official parameter checkpoints. Model rollback does not erase counted work; a fresh restored session reports zero historical work. Initialization/evaluation/restoration are excluded. Original updates/global_updates remain epoch counters, environment_steps/caps/stage trajectories/gates remain unchanged. Actual per-batch reports retain the cumulative session snapshot. Comparison copies error snapshot into row before dropping its session reference, then persists it in the existing outer exception handler afterward. There is no disk-write-before-release or crash-safe journal claim. Unwritable output/kill/power loss can lose ordinary records, and no absent evidence is reconstructed.

No math/topology/sign/clock/loss/training freedom/role/init/corpus/window/codec/checkpoint identity/default changed. Default COO/clippedEuler at20Hz/20ms still has its known tau zero derivative; exponential is opt-in. Frozen inference coefficient implementation and all source/baseline joins remain unchanged. Same cap may produce different trajectories/exposure/work; full learning/fair actual upstream/source/calibration/flight remain pending.

## Actual tests and original review

First five new tests failed in5.12s on missing training_effort reporting KeyError/AttributeError after actual tiny neural/Adam paths; these are missing-interface failures, not behavior/native RED. After production integration5passed4.27s. Four added actual trajectory/failure/interrupt coverage tests directly passed:9passed4.70s, not manufactured RED. Three eight-frame sequences over two epochs give six returning optimizer calls/48 frame samples while updates remains2. Actual Adam update-then-raise at third call preserves started3/returned2/raised1, whole backward frames24 and returned-step frames16; actual parameters have changed. Model rollback keeps12 prior returns, fresh resume claims0, exported snapshot edits cannot change live counters. Actual three-role success/error persistence, partial backward omission despite actual nonempty gradients, late input failure, KeyboardInterrupt and exact two-epoch numerical trajectory/metrics equality are exercised.

Initial Ruff0; format1newtest/3unchanged. Necessary affected trainer/window/comparison/curriculum plus new tests83passed12.10s, exactly one original CSR-beta warning. ONE original independent whole source review C0/I0/M0 with15 independently read frozen/current pins, no fix requested. Single bounded executor only final verification: ordinary new9+state6 =15passed5.49s/no warnings, all formatted, Ruff0/dedicateddiff0. No new source/test changes after original review, no fake fix and no second whole code/native approval. Five explicit declined judgments are ruled in executor-fix-pass.md: scientific/flight, resource/native, adversarial/concurrent/historical authentication, crash durability/unwritable records, and runtime/delivery reproduction are excluded from source verdict and remain pending or separately audited. No deferred minors.

Host NumPy/SciPy/Torch/CPU sparse and real tiny16-neuron NN forward/backward/Adam ran. No full MaleCNS/GPU/resource/process/Docker/Linux/SDK/native observer/physics/measured calibration/oldv4/consumed replay. Default actual imported inert fixture and explicit affected-neighbor plugin provide peak0/CUDAfalse protocol values, not measured resources or admission; guard is not cold collection/FFI sandbox. No new AV/timeout; original3221225477 UNKNOWN and120s recorder partial/completion gap unchanged, not repaired.

## Evidence and preserved limits

NEW prospective recorder has30declared all existing from first run; effective argv and initially absent owned extended-Windows --basetemp, sourcebefore/after/recorderSHA/fourdeclaredEnv/streams/localclocks retained. {len(invs)}inventories/{sum(r['argv'][1:3]==['-m','pytest'] for r in runs)}pytest/{len(payloads)}regular fixture entries/{sum(r['bytes'] for r in payloads)}B retained postrun. Nonpytest inventories empty. Source stability is required for pytest/nonmutating commands; the intentional format command changes only its declared new test. Not all inheritedenv, every intermediate fixture mutation, authenticated collection/FFI, or crash-safe recording. No old temporary fixture search/reconstruction/rerun/generalized old completeness claim.

303oldZIP899717611B streamed byte/SHA unchanged POSTsoftware/nonprepin. 832oldproducts exactly trainer/session/role_comparison changed,829same; newtest separate, all consumed-version-specific bytes same. Original382 CLIbefore/after/copies exact; current SIX evolved names session/dataset/inference/inference_artifact/trainer/model same set, current trainer/session already in it; role_comparison outsideold382/postnamespace, no invented seventh/prepin. Oldrequest232184B/546c9ae9... and release44826B/f7ce10ba... exact CURRENTSTALE. Exact sixfile v4 REFUSED_UNCONSUMED/Win1620271104WSL6851129344/memorypasscompetitor1/Dockerempty/CLIexit0wait2.437s retained, not freeze/native failure. No preidentity-attempt/request/recipe/claim/sdkstart/study/SDKcommand/scope; physicalabsent/unconsumed.

Three full histories89359B/c88840...,80946B/80dfb8...,81675B/df122e... and64305char PRhistory preserved. Entire immediate25877char PRbody retained for verbatim suffix. Actual40450char automation prompt/TOML copied before seal, full goals/history/budgets remain. Private3 unchanged excluded;475savedrows/175empty/202nonemptyargvhash and both triples scanned without refreshing resource inventory. Empty SHA is not private identity.

Prior membrane10pytest payload loss remains unrepaired: evidence/membrane-dynamics-production-retention-correction.json6546B/SHA802f6402c44f72b4b565e8cff5ef31a1525c027da0edb9877502161db99e0152. Prior rolecomparison DL-M1 actual postsealprogress append/restoration remains an historical immutability exception: correction1053B/SHAd9334ebe173e58f3c69c7d045dbb37a69e8c77e87245504fa417b71616caabf7; preserve original/applied/restored bytes and limitedverdict, never global pristine history. Prior frozen-cache delivery helper's overstrict Ruff mutation predicate and additivev2, final publication audit and postaudit automation prefix all retained. This phase does not repair or generalize those limitations.

Canonical evidence/training-effort-production-dev-1701.zip/map distinguish mapped payload/manifest/whole expanded bytes; receipt has exact totals after seal. Plan first2done/publicationpending in ZIP; publication sole checkbox byte separately ledgered. Working/Git-normalized identities separate. Raw/report/source/ZIP immutable after seal; postsealreceipt/audits/helpers/stage/publication/PR/automation/NEXT_PHASE new separate files. Independent delivery integrity/honesty does not reapprove source/native.

All8 source/clock/measuredcalibration/accuracy/teacher/fusion/training/flight and runtime_graph_frozen/physical_dispatch_ready FALSE. Goal blocked read-only, automation ACTIVE, personal only/draftPR65, never origin/newchat/manualresume/stepapproval. All original CONSUMED/UNKNOWN/v3 harnessescape/fixtureMOCK/251pose185init/5agent.873RTF<.95, staticdual1GiB/physical-fullMaleCNS-PX4dual4GiB/exact scopeclockcleanup/sensorsprecisionvelocitysafetyRTF, truth ONLY abort/audit NEVER VIO/teacher/training and pidfd failclosed remain. PNG7native/Kalibr full intrinsicnoise/toolchain/observability/PX4firmware/fulllearning/fairupstream/HITL/flight pending. No polling/lowered gates/unrelatedkill/pausewhilelocalitemsremain. Software pending DONT_NOTIFY, no all-local-items or overall drone completion.
'''
p=root/'docs/TRAINING_EFFORT_PRODUCTION_REPORT.md'
with p.open('x',encoding='utf-8') as f:f.write(report)
with (raw/'progress.md').open('a') as f:f.write('\nTask2 source/verification complete: originalC0/I0/M0, nofixrequired; singleboundedfinal15pass5.49s/no warnings, earliernecessary83pass12.10s1CSR. Ruff0/diff0. All5declinedscopejudgments ruled in executor-fix-pass; no deferredminor. Original15pins all exact except two separately joined plancheckbox bytes, no product/test changes. Task3 publication pending. Seal next; NEVER append this mapped progress afterseal.\n')
print(json.dumps(dict(inventories=len(invs),pytest=sum(r['argv'][1:3]==['-m','pytest'] for r in runs),payloads=len(payloads),payload_bytes=sum(r['bytes'] for r in payloads),plan_offsets=offsets)))
