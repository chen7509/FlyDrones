"""Prospective recorder v1: effective argv and owned fixture payload retention."""
import hashlib,json,os,re,subprocess,sys,time
from pathlib import Path
ROOT=Path.cwd();RAW=Path(__file__).resolve().parent
SOURCES=['src/flydrones/connectome_training/role_comparison.py','tools/connectome_training/run_curriculum.py','tests/connectome_training/test_training_effort.py','src/flydrones/connectome_training/curriculum.py','src/flydrones/connectome_training/curriculum_session.py','src/flydrones/connectome_training/curriculum_state.py','src/flydrones/connectome_training/curriculum_config.py','src/flydrones/connectome_training/training_roles.py','src/flydrones/connectome_training/model.py','src/flydrones/connectome_training/trainer.py','src/flydrones/connectome_training/sequence_corpus.py','src/flydrones/connectome_training/checkpoint.py','src/flydrones/connectome_training/parameters.py','src/flydrones/connectome_training/features.py','src/flydrones/connectome_training/losses.py','tests/connectome_training/test_learning_roles.py','tests/connectome_training/test_curriculum.py','tests/connectome_training/test_curriculum_state.py','tests/connectome_training/conftest.py','tools/benchmark/software_process_boundary.py',Path(__file__).relative_to(ROOT).as_posix()]
SOURCES+=['src/flydrones/connectome_training/inference_artifact.py','src/flydrones/connectome_training/inference.py','tests/connectome_training/test_inference_artifact.py','tests/connectome_training/test_model.py']
SOURCES+=['tests/connectome_training/test_role_comparison.py','tests/connectome_training/test_trainer.py','tests/connectome_training/test_windowed_training.py']
def sha(b):return hashlib.sha256(b).hexdigest()
SOURCES+=['configs/connectome_curriculum_v1.yaml','results/training-effort-production-dev-1701/inert_test_plugin.py']
def save(n,v):
 with (RAW/n).open('xb') as f:f.write(json.dumps(v,indent=2).encode())
def pins(label):
 rows=[]
 for name in SOURCES:
  p=ROOT/name
  if not p.exists():rows.append(dict(path=name,absent=True));continue
  b=p.read_bytes();rows.append(dict(path=name,bytes=len(b),sha256=sha(b)));dest=RAW/(label+'-source')/name;dest.parent.mkdir(parents=True,exist_ok=True)
  with dest.open('xb') as f:f.write(b)
 return rows
label=sys.argv[1];args=sys.argv[2:]
assert re.fullmatch('[a-z0-9-]+',label) and args and not (RAW/(label+'-start.json')).exists()
effective=list(args);base=None
if len(args)>2 and args[1:3]==['-m','pytest']:
 assert not any(a.startswith('--basetemp') for a in args)
 base=RAW/'fixtures'/label;assert base.resolve().is_relative_to(RAW.resolve()) and not base.exists()
 base.parent.mkdir(exist_ok=True)
 logical_base=base
 if os.name=='nt':base=Path('\\\\?\\'+str(base))
 effective+=['--basetemp',str(base)]
env=dict(os.environ);env['PYTHONPATH']=str(ROOT/'src')+os.pathsep+str(ROOT)
start=dict(requested_argv=args,argv=effective,cwd=str(ROOT),source_before=pins(label),recorder_sha256=sha(Path(__file__).read_bytes()),environment={k:env.get(k) for k in ('PYTHONPATH','PATH','PYTHONHOME','VIRTUAL_ENV')},started_monotonic_ns=time.monotonic_ns(),started_utc_ns=time.time_ns(),owned_basetemp=str(base) if base else None,scope='tiny CPU neural software; default inert process/resource/CUDA fixture; no fullMaleCNS/SDK/resources')
save(label+'-start.json',start)
try:p=subprocess.run(effective,cwd=ROOT,env=env,capture_output=True,timeout=120);out,err,code,exception=p.stdout,p.stderr,p.returncode,None
except subprocess.TimeoutExpired as exc:out,err,code,exception=exc.stdout or b'',exc.stderr or b'',None,repr(exc)
except Exception as exc:out,err,code,exception=b'',b'',None,repr(exc)
for ext,b in [('stdout',out),('stderr',err)]:
 with (RAW/(label+'.'+ext)).open('xb') as f:f.write(b)
fixtures=[]
if base and base.exists():
 for p in sorted(base.rglob('*')):
  name=(logical_base.relative_to(ROOT)/p.relative_to(base)).as_posix()
  if p.is_symlink():fixtures.append(dict(path=name,symlink=os.readlink(p)));continue
  if p.is_file():
   b=p.read_bytes();fixtures.append(dict(path=name,bytes=len(b),sha256=sha(b)))
save(label+'-fixtures.json',dict(owned_basetemp=str(base) if base else None,retained_payload=fixtures,scope='Actual post-run payload retained in place, not reconstructed; fixture symlinks recorded without following'))
save(label+'.json',dict(**start,exit=code,exception=exception,ended_monotonic_ns=time.monotonic_ns(),ended_utc_ns=time.time_ns(),source_after=pins(label+'-after'),stdout_sha256=sha(out),stderr_sha256=sha(err)))
print(json.dumps(dict(label=label,exit=code,exception=exception,fixture_members=len(fixtures),stdout=out.decode(errors='replace')[-14000:],stderr=err.decode(errors='replace')[-3000:])))
sys.exit(0 if code==0 else 1)
