import ctypes,struct,json,sys,datetime
from ctypes import wintypes as W
from pathlib import Path
k=ctypes.WinDLL("kernel32",use_last_error=True)
k.CreateFileW.argtypes=[W.LPCWSTR,W.DWORD,W.DWORD,W.LPVOID,W.DWORD,W.DWORD,W.HANDLE];k.CreateFileW.restype=W.HANDLE
k.DeviceIoControl.argtypes=[W.HANDLE,W.DWORD,W.LPVOID,W.DWORD,W.LPVOID,W.DWORD,ctypes.POINTER(W.DWORD),W.LPVOID];k.DeviceIoControl.restype=W.BOOL
k.CloseHandle.argtypes=[W.HANDLE]
p=Path(r"\\wsl.localhost\Ubuntu\etc\os-release");out=Path(sys.argv[1]);row=dict(path=str(p),utc=datetime.datetime.now(datetime.UTC).isoformat(),operation="CreateFileW READ_CONTROL/OPEN_REPARSE_POINT + FSCTL_GET_REPARSE_POINT only")
h=k.CreateFileW(str(p),0,7,None,3,0x02200000,None)
try:
 if h==ctypes.c_void_p(-1).value:raise ctypes.WinError(ctypes.get_last_error())
 b=ctypes.create_string_buffer(16384);n=W.DWORD()
 if not k.DeviceIoControl(h,0x900a8,None,0,b,len(b),ctypes.byref(n),None):raise ctypes.WinError(ctypes.get_last_error())
 raw=b.raw[:n.value];(out/"os-release.reparse.raw").write_bytes(raw)
 tag,length,reserved=struct.unpack_from("<IHH",raw);row.update(tag=tag,length=length,payload_hex=raw[8:].hex(),returned_bytes=n.value)
except Exception as exc:row["error"]=repr(exc)
finally:
 if h!=ctypes.c_void_p(-1).value:k.CloseHandle(h)
with (out/"reparse-result.json").open("x",encoding="utf-8") as f:json.dump(row,f,indent=2)
print(json.dumps(row))
