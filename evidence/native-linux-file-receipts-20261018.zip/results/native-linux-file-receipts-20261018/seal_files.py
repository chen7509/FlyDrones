"""Seal only this actual-file observation set; executor byte integrity, no runtime approval."""
import hashlib
import json
from pathlib import Path
import zipfile

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
POST=OUT/'postseal'
FILES=['docs/NATIVE_LINUX_FILE_RECEIPTS_PROGRESS.md','docs/superpowers/plans/2026-10-18-native-linux-file-receipts.md']
FILES+=['results/native-linux-file-receipts-20261018/'+name+'-v2.json' for name in (
    'file-bindings','package-receipts','existing-build-metadata','candidate-bindings','missing-evidence','analysis-summary')]


def sha(raw):return hashlib.sha256(raw).hexdigest()


summary=json.loads((OUT/'analysis-summary-v2.json').read_bytes())
bindings=json.loads((OUT/'file-bindings-v2.json').read_bytes())
package=json.loads((OUT/'package-receipts-v2.json').read_bytes())
assert len(bindings['files'])==919 and bindings['qualification'] is False
assert summary['source_matches']==141 and not summary['source_mismatches']
assert not summary['md5_mismatch_files'] and summary['md5_match_files']==455
assert all(value is not None for value in package['selected_packages'].values())
for name,row in bindings['files'].items():
    raw=(OUT/row['blob']).read_bytes()
    assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
candidate=json.loads((OUT/'candidate-bindings-v2.json').read_bytes())
assert len(candidate['bindings'])==8 and candidate['existing_library']['sha256'] is None
assert candidate['existing_library']['bound'] is False and not candidate['dispatchable']
selfcheck=dict(scope='executor only new retained actual-file bytes/derived JSON consistency; no old archives/history/private475 or source/native/delivery review',
    files_verified=919,source_current_bytes_compared=141,source_missing=['LICENSE','ReadMe.md'],local_package_md5_match_files=455,
    source_to_existing_library_proven=False,current_library_sha256=None,complete_linux_closure=False,
    native_commands=False,resource_queries=False,tests_run=False,all_qualifications=False,
    limitations='Windows share metadata/escaped names/link ambiguity, partial headers and file/deadline caps remain. No full environment/FFI/crashsafe proof.')
with (OUT/'self-check.json').open('x',encoding='utf-8') as stream:json.dump(selfcheck,stream,indent=2)
paths=set(FILES)
for path in OUT.rglob('*'):
    if 'postseal' in path.relative_to(OUT).parts or '__pycache__' in path.parts or path.suffix=='.pyc':continue
    if path.is_file() and not path.is_symlink():paths.add(path.relative_to(ROOT).as_posix())
mapping={}
archive=ROOT/'evidence/native-linux-file-receipts-20261018.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as output:
    for name in sorted(paths):
        raw=(ROOT/name).read_bytes();mapping[name]=dict(bytes=len(raw),sha256=sha(raw))
        entry=zipfile.ZipInfo(name,(2026,10,18,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;entry.external_attr=0o100600<<16
        output.writestr(entry,raw)
    manifest=json.dumps(dict(schema='current-linux-file-observations-archive-v1',mapping=mapping,
        note='Actual readonly shared-file observations with explicit incomplete closure; not library build provenance or native admission.'),sort_keys=True,indent=2).encode()
    output.writestr('manifest.json',manifest)
with zipfile.ZipFile(archive) as source:
    assert source.testzip() is None and len(source.namelist())==len(mapping)+1
    for name,row in mapping.items():assert sha(source.read(name))==row['sha256']
receipt=dict(schema='current-linux-file-receipts-seal-v1',archive=archive.relative_to(ROOT).as_posix(),bytes=archive.stat().st_size,
    sha256=sha(archive.read_bytes()),members=len(mapping)+1,mapped=len(mapping),mapped_payload_bytes=sum(r['bytes'] for r in mapping.values()),
    manifest_bytes=len(manifest),whole_expanded_bytes=sum(r['bytes'] for r in mapping.values())+len(manifest),software_files=FILES,
    native_admission=False,all_qualifications=False,complete_linux_closure=False)
with archive.with_suffix('.sha256.json').open('x',encoding='utf-8') as stream:json.dump(dict(**receipt,mapping=mapping),stream,indent=2)
POST.mkdir(exist_ok=False)
with (POST/'seal-receipt.json').open('x',encoding='utf-8') as stream:json.dump(receipt,stream,indent=2)
print(json.dumps({k:v for k,v in receipt.items() if k!='software_files'}))
