from pathlib import Path
import os,json,datetime,hashlib,sys
out=Path(sys.argv[1]);rows=[]
for name in ("/etc/os-release","/usr/lib/os-release"):
 p=Path(r"\\wsl.localhost\Ubuntu"+name.replace("/","\\"));row=dict(linux_path=name,utc=datetime.datetime.now(datetime.UTC).isoformat())
 try:
  st=p.lstat();row["stat"]=dict(mode=st.st_mode,size=st.st_size,ino=st.st_ino,dev=st.st_dev,attributes=getattr(st,"st_file_attributes",None),reparse_tag=getattr(st,"st_reparse_tag",None))
  if getattr(st,"st_file_attributes",0)&1024:
   try:row["readlink"]=os.readlink(p)
   except OSError as exc:row["readlink_error"]=repr(exc)
  else:
   with p.open("rb") as f:raw=f.read(65537)
   if len(raw)>65536:raise ValueError("cap exceeded")
   (out/("link-"+name.replace("/","_")+".raw")).write_bytes(raw);row.update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),success=True)
 except OSError as exc:row["error"]=repr(exc)
 rows.append(row)
with (out/"link-characterization.json").open("x",encoding="utf-8") as f:json.dump(rows,f,indent=2)
print(json.dumps(rows))
