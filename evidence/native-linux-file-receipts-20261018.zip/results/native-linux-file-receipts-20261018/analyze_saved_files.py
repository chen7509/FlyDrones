"""Analyze only this acquisition's retained bytes; never touches the Linux share."""
import collections
import hashlib
import json
from pathlib import Path
import re

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
rows=json.loads((OUT/'current-files.json').read_bytes())
completion=json.loads((OUT/'collection-completion.json').read_bytes())


def raw(name):
    row=rows.get(name,{})
    if row.get('status')!='observed':return None
    payload=(OUT/row['blob']).read_bytes()
    assert len(payload)==row['bytes'] and hashlib.sha256(payload).hexdigest()==row['sha256']
    return payload


def save(name,value):
    with (OUT/name).open('x',encoding='utf-8') as stream:json.dump(value,stream,indent=2)


packages={}
for paragraph in raw('/var/lib/dpkg/status').decode('utf-8').split('\n\n'):
    fields={}
    for line in paragraph.splitlines():
        if line and not line.startswith((' ','\t')) and ': ' in line:
            key,value=line.split(': ',1);fields[key]=value
    if 'Package' in fields:
        packages[fields['Package']]=dict(package=fields['Package'],version=fields.get('Version'),
            architecture=fields.get('Architecture'),status=fields.get('Status'),source=fields.get('Source'),
            maintainer=fields.get('Maintainer'),origin=fields.get('Origin'))
ownership=collections.defaultdict(list);checksums=collections.defaultdict(list);selected=set()
for name,row in rows.items():
    if row['status']!='observed' or 'package-inventory' not in row['roles']:continue
    leaf=Path(name).name;package=leaf.rsplit('.',1)[0].split(':',1)[0];selected.add(package)
    if leaf.endswith('.list'):
        for line in raw(name).decode('utf-8').splitlines():
            if line.startswith('/'):ownership[line].append(package)
    elif leaf.endswith('.md5sums'):
        for line in raw(name).decode('utf-8').splitlines():
            match=re.fullmatch(r'([a-f0-9]{32})\s+(.+)',line)
            if match:checksums['/'+match[2].lstrip('/')].append((package,match[1]))
observed={};status_counts=collections.Counter();role_counts=collections.defaultdict(collections.Counter)
for name,row in rows.items():
    status_counts[row['status']]+=1
    for role in row['roles']:role_counts[role][row['status']]+=1
    if row['status']!='observed':continue
    payload=raw(name);md5=hashlib.md5(payload).hexdigest()
    observed[name]=dict(bytes=row['bytes'],sha256=row['sha256'],blob=row['blob'],roles=row['roles'],
        windows_share_before=row['before'],windows_share_after=row['after'],linux_resolved_path=None,
        linux_device_inode_permissions_verified=False,package_list_exact_path=ownership.get(name,[]),
        package_md5_comparisons=[dict(package=p,md5=expected,matches=md5==expected) for p,expected in checksums.get(name,[])],
        static_elf=row.get('elf'),elf_error=row.get('elf_error'))
save('file-bindings.json',dict(schema='current-linux-regular-file-observations-v1',files=observed,
    qualification=False,linux_identity_complete=False,dispatchable=False,
    scope='Current bytes via Windows share, exact .list ownership and local md5 content comparisons only; not signed package origin/current Linux file_pin schema or runtime resolution.'))
save('package-receipts.json',dict(schema='current-linux-package-file-observations-v1',
    status_file=observed['/var/lib/dpkg/status'],selected_packages={name:packages.get(name) for name in sorted(selected)},
    package_database_authenticated=False,repository_origin_verified=False,install_or_dpkg_program_run=False,
    note='Versions/ownership come from the retained actual local database; current checksums do not authenticate its origin.'))
base='/home/yuchen7509/flydrones-upstream/open_vins/'
expected=json.loads((ROOT/'results/native-offset-run-plan-20261018/upstream-build-source-manifest.json').read_bytes())['files']
comparison={}
for name,wanted in expected.items():
    current=rows.get(base+name,{})
    comparison[name]=dict(actual_status=current.get('status'),current_sha256=current.get('sha256'),
        expected_upstream_sha256=wanted['sha256'],match=(current.get('sha256')==wanted['sha256']) if current.get('status')=='observed' else None)
cache={}
for line in raw(base+'ov_msckf/build/CMakeCache.txt').decode('utf-8').splitlines():
    match=re.fullmatch(r'([^/#][^:]*):([^=]+)=(.*)',line)
    if match:cache[match[1]]=dict(type=match[2],value=match[3])
flags=raw(base+'ov_msckf/build/CMakeFiles/ov_msckf_lib.dir/flags.make').decode('utf-8')
depend=raw(base+'ov_msckf/build/CMakeFiles/ov_msckf_lib.dir/DependInfo.cmake').decode('utf-8')
tu=re.findall(r'"([^"\n]+\.cpp)"\s+"([^"\n]+\.o)"\s+"gcc"\s+"([^"\n]+\.d)"',depend)
make=raw(base+'ov_msckf/build/CMakeFiles/ov_msckf_lib.dir/compiler_depend.make')
dependency_paths=sorted(set(re.findall(r'(?m)(/[^\n\\]+)',make.decode('utf-8')))) if make else []
save('existing-build-metadata.json',dict(schema='current-existing-openvins-build-metadata-observations-v1',
    current_git_head=raw(base+'.git/HEAD').decode().strip(),current_master=raw(base+'.git/refs/heads/master').decode().strip(),
    source_comparison=comparison,cache=cache,flags_make=flags,translation_units=tu,
    compiler_depend_make_paths=dependency_paths,library_observation=rows[base+'ov_msckf/build/libov_msckf_lib.so'],
    source_to_existing_binary_proven=False,current_library_sha256=None,current_library_elf=None,abi_verified=False,
    missing=['Current full library bytes/hash:291717384B exceeds unchanged67108864B file cap.',
        'compile_commands.json unavailable; metadata recipes are not a build execution receipt.',
        'Original tool/header/config/object/link execution snapshots/logs and authenticated build provenance absent.',
        'No current object/.o.d payload collection; compiler_depend.make alone cannot bind historical reads.',
        'Current source content does not establish source content at the earlier link time.',
        'Current /usr/bin/c++ alias is unresolved through Windows share.',
        'LICENSE and ReadMe.md not found at expected current source paths.']))
candidate_map={
    'pinned_cmake':'/usr/bin/cmake','pinned_gxx':'/usr/bin/x86_64-linux-gnu-g++-13','pinned_make':'/usr/bin/make',
    'pinned_python':'/usr/bin/python3.12',
    'eigen_config_dir':'/usr/share/eigen3/cmake/Eigen3Config.cmake',
    'opencv4_config_dir':'/usr/lib/x86_64-linux-gnu/cmake/opencv4/OpenCVConfig.cmake',
    'boost_config_dir':'/usr/lib/x86_64-linux-gnu/cmake/Boost-1.83.0/BoostConfig.cmake',
    'ceres_config_dir':'/usr/lib/x86_64-linux-gnu/cmake/Ceres/CeresConfig.cmake'}
candidates={}
for field,path in candidate_map.items():
    if path not in observed:continue
    candidates[field]=dict(path=path if not field.endswith('_dir') else str(Path(path).parent).replace('\\','/'),
        evidenced_file=path,sha256=observed[path]['sha256'],bytes=observed[path]['bytes'],
        state='current_regular_file_candidate_not_admitted',same_as_unresolved_alias_proven=False)
save('candidate-bindings.json',dict(schema='native-offset-current-file-binding-candidates-v1',bindings=candidates,
    upstream_source_tree=dict(path=base.rstrip('/'),actual_matching_source_files=sum(v['match'] is True for v in comparison.values()),
        required_missing_files=[k for k,v in comparison.items() if v['match'] is None]),
    existing_library=dict(path=base+'ov_msckf/build/libov_msckf_lib.so',bytes=291717384,sha256=None,bound=False),
    new_toolchain_written=False,original45binding_template_modified=False,admission_granted=False,dispatchable=False,all_qualifications=False,
    note='The versioned g++ candidate is not evidence that historical /usr/bin/c++ selected it. Config bytes do not prove all referenced headers/libraries/modules were acquired.'))
gaps={
 'library_current_bytes':dict(status='blocked_file_cap',actual_size=291717384,unchanged_cap=67108864,current_sha256=None),
 'existing_library_source_provenance':dict(status='not_proven',metadata_only=True,compile_commands_absent=True),
 'linux_identity_and_symlinks':dict(status='unavailable_via_share',unresolved_count=status_counts['unresolved_reparse'],native_stat_or_readlink_run=False),
 'headers':dict(status='partial_deadline',package_selected_paths=completion.get('header_paths_selected'),
     actual_observed=role_counts['header-package-selection']['observed'],selected_before_after='Per-file observations, not whole-tree or native compiler dependency closure'),
 'compiler_implicit_inputs':dict(status='partial',specs_sysroot_startfiles_full_system_headers_not_proven=True),
 'ELF_resolution_and_ABI':dict(status='static_candidates_only',actual_loader_maps=False,recursive_current_loaded_closure=False),
 'package_origin':dict(status='local_db_only',authenticated_repository_or_package_archives=False),
 'build_and_run':dict(status='not_requested_not_executed',newbinary_absent=True,review_resources_calibration_noise_pins_not_filled=True)}
save('missing-evidence.json',dict(schema='native-offset-current-file-evidence-gaps-v1',gaps=gaps,
    unavailable_or_unresolved={n:r for n,r in rows.items() if r['status']!='observed'},historical_hashes_substituted=False))
summary=dict(selected=len(rows),observed=len(observed),status_counts=status_counts,role_counts=role_counts,
    source_matches=sum(v['match'] is True for v in comparison.values()),source_mismatches=[n for n,v in comparison.items() if v['match'] is False],
    source_missing=[n for n,v in comparison.items() if v['match'] is None],existing_library_bytes=291717384,
    unique_blob_count=len(list((OUT/'blobs').iterdir())),package_inventory_packages=len(selected),
    md5_match_files=sum(any(q['matches'] for q in r['package_md5_comparisons']) for r in observed.values()),
    md5_mismatch_files=[n for n,r in observed.items() if any(not q['matches'] for q in r['package_md5_comparisons'])],
    elf_files=sum(bool(r['static_elf']) for r in observed.values()),translation_units=len(tu),complete=False,qualification=False)
save('analysis-summary.json',summary)
print(json.dumps({k:v for k,v in summary.items() if k not in ('role_counts','md5_mismatch_files')}))
