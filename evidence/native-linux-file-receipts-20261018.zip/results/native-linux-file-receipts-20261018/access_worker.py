import datetime,json,os,stat,sys,hashlib
from pathlib import Path
p=Path(r"\\wsl.localhost\Ubuntu\etc\os-release")
out=Path(sys.argv[1])
row=dict(requested=str(p),method="Windows standard file I/O only; no WSL/Linux command",utc=datetime.datetime.now(datetime.UTC).isoformat())
try:
 before=p.lstat();row["lstat"]=dict(mode=before.st_mode,size=before.st_size,ino=before.st_ino,dev=before.st_dev,attributes=getattr(before,"st_file_attributes",None),reparse_tag=getattr(before,"st_reparse_tag",None))
 row["is_symlink"]=stat.S_ISLNK(before.st_mode)
 if row["is_symlink"]:row["readlink"]=os.readlink(p)
 raw=p.read_bytes()
 if len(raw)>65536:raise ValueError("access file cap exceeded")
 (out/"os-release.raw").write_bytes(raw)
 row.update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),success=True)
except BaseException as exc:row.update(success=False,error=repr(exc))
with (out/"access-result.json").open("x",encoding="utf-8") as f:json.dump(row,f,indent=2)
print(json.dumps(row))
