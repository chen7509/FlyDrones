"""Windows-only read of current Linux regular files; no Linux command/loader invocation."""
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import struct
import sys
import time

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
SHARE=Path(r'\\wsl.localhost\Ubuntu')
SOURCE='/home/yuchen7509/flydrones-upstream/open_vins'
DEADLINE=time.monotonic()+27
CAP=64*1024**2
TOTAL_CAP=192*1024**2
records={};listings={};total=0
(OUT/'blobs').mkdir(exist_ok=False)
log=(OUT/'files.jsonl').open('x',encoding='utf-8')


def check():
    if time.monotonic()>=DEADLINE:raise TimeoutError('one27s aggregate Linux read deadline')


def unc(name):
    if not name.startswith('/') or '..' in PurePosixPath(name).parts:raise ValueError('absolute normalized Linux path required')
    return SHARE/name.lstrip('/').replace('/','\\')


def meta(s):
    return dict(mode=s.st_mode,size=s.st_size,ino=s.st_ino,dev=s.st_dev,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,
                attributes=getattr(s,'st_file_attributes',None),reparse_tag=getattr(s,'st_reparse_tag',None))


def listing(name):
    if name in listings:return listings[name]['names']
    check();p=unc(name);row=dict(path=name,utc=datetime.datetime.now(datetime.UTC).isoformat(),names=[],complete=False)
    try:
        row['before']=meta(p.lstat())
        if row['before']['attributes']&1024:raise ValueError('unresolved LX link directory')
        with os.scandir(p) as stream:
            for entry in stream:
                check()
                if len(row['names'])>=20000:raise ValueError('directory entry cap')
                row['names'].append(entry.name)
        row['after']=meta(p.lstat());row['complete']=row['before']==row['after']
    except TimeoutError:
        row['error']='deadline';listings[name]=row;raise
    except (OSError,ValueError) as exc:row['error']=repr(exc)
    row['names'].sort();listings[name]=row
    return row['names']


def take(name,role):
    global total
    if name in records:
        if role not in records[name]['roles']:records[name]['roles'].append(role)
        return records[name]
    check();row=dict(linux_path=name,roles=[role],utc=datetime.datetime.now(datetime.UTC).isoformat(),status='unknown')
    try:
        p=unc(name);before=meta(p.lstat());row['before']=before
        if before['attributes']&1024:
            row.update(status='unresolved_reparse',reason='Windows readlink and read-only FSCTL unsupported on observed share; target not inferred')
        elif not stat.S_ISREG(before['mode']):row.update(status='not_regular')
        elif before['size']>CAP:row.update(status='file_cap',limit=CAP)
        elif total+before['size']>TOTAL_CAP:raise ValueError('aggregate192MiB payload cap')
        else:
            raw=bytearray()
            with p.open('rb') as stream:
                while block:=stream.read(1024**2):
                    check();raw.extend(block)
                    if len(raw)>CAP:raise ValueError('file grew beyond64MiB')
            after=meta(p.lstat());row['after']=after
            digest=hashlib.sha256(raw).hexdigest();blob=OUT/'blobs'/digest
            if not blob.exists():
                with blob.open('xb') as stream:stream.write(raw)
            total+=len(raw)
            row.update(status='observed' if before==after and len(raw)==before['size'] else 'changed',
                       bytes=len(raw),sha256=digest,blob='blobs/'+digest)
    except TimeoutError:
        row.update(status='deadline');records[name]=row;log.write(json.dumps(row)+'\n');log.flush();raise
    except (OSError,ValueError) as exc:row.update(status='unavailable',error=repr(exc))
    records[name]=row;log.write(json.dumps(row)+'\n');log.flush()
    return row


def data(row):
    return (OUT/row['blob']).read_bytes() if row.get('status')=='observed' else None


def elf(raw):
    if not raw or raw[:6]!=b'\x7fELF\x02\x01':return None
    phoff=struct.unpack_from('<Q',raw,32)[0];size,count=struct.unpack_from('<HH',raw,54)
    loads=[];dynamic=None;interpreter=None
    for i in range(count):
        kind,flags,offset,va,pa,filesz,memsz,align=struct.unpack_from('<IIQQQQQQ',raw,phoff+i*size)
        if kind==1:loads.append((va,va+filesz,offset))
        if kind==2:dynamic=(offset,filesz)
        if kind==3:interpreter=raw[offset:offset+filesz].split(b'\0')[0].decode()
    result=dict(class_bits=64,endianness='little',machine=struct.unpack_from('<H',raw,18)[0],needed=[],interpreter=interpreter)
    if not dynamic:return result
    entries=[]
    for off in range(dynamic[0],sum(dynamic),16):
        tag,value=struct.unpack_from('<qQ',raw,off)
        if not tag:break
        entries.append((tag,value))
    address=next((v for t,v in entries if t==5),None)
    if address is None:return result
    strings=next(o+address-a for a,b,o in loads if a<=address<b)
    for tag,value in entries:
        if tag in (1,14,15,29):
            start=strings+value;end=raw.index(b'\0',start);text=raw[start:end].decode()
            if tag==1:result['needed'].append(text)
            else:result[{14:'soname',15:'rpath',29:'runpath'}[tag]]=text
    return result


def children(name,role,suffixes=None):
    for part in listing(name):
        check();path=name+'/'+part
        if suffixes and not part.endswith(suffixes):continue
        row=take(path,role)
        if row.get('status')=='not_regular' and stat.S_ISDIR(row.get('before',{}).get('mode',0)):
            children(path,role,suffixes)


completion=dict(schema='current-linux-file-collection-v1',complete=False,native_commands=False,linux_writes=False,
    resources_queried=False,tests_run=False,limitations=['Windows share metadata is not Linux st_dev/inode/permission identity.',
        'LX symlink target and resolved identity unavailable through this share; unresolved entries never become pins.',
        'Files are observed separately in one bounded window, not an atomic filesystem snapshot.',
        'ELF parsing is static candidate evidence, not loader resolution/ABI/runtime provenance.'])
try:
    # Establish ordinary directory ancestry without following LX reparse points.
    for path in ('/usr','/usr/bin','/usr/lib','/usr/include','/home','/home/yuchen7509',SOURCE):listing(path)
    for name in ('/usr/lib/os-release','/var/lib/dpkg/status','/etc/ld.so.cache','/etc/ld.so.conf'):
        take(name,'package-platform')
    for part in listing('/etc/ld.so.conf.d'):
        if part.endswith('.conf'):take('/etc/ld.so.conf.d/'+part,'loader-config')
    # Select regular versioned candidates from actual directory entries, never substitute them for unresolved aliases.
    aliases=('cmake','g++','c++','gcc','make','as','ld','ar','ranlib','python3','env','time','timeout','systemd-run','systemctl')
    bins=listing('/usr/bin')
    selected=set(aliases)|{n for n in bins if re.fullmatch(r'(?:x86_64-linux-gnu-)?(?:g\+\+|gcc|cpp|as|ld(?:\.bfd)?|ar|ranlib)(?:-\d+)?',n)
                               or re.fullmatch(r'python3\.\d+',n)}
    for name in sorted(selected):take('/usr/bin/'+name,'tool')
    for version in listing('/usr/lib/gcc/x86_64-linux-gnu'):
        if not version.isdigit():continue
        base='/usr/lib/gcc/x86_64-linux-gnu/'+version
        for name in ('cc1plus','cc1','collect2','specs','libgcc.a','libgcc_s.so','libstdc++.so','crtbegin.o','crtend.o'):
            take(base+'/'+name,'compiler-component')
    build=SOURCE+'/ov_msckf/build'
    for base in (SOURCE+'/.git',build,build+'/CMakeFiles',build+'/CMakeFiles/ov_msckf_lib.dir'):
        listing(base)
    for name in ('CMakeCache.txt','compile_commands.json','Makefile','cmake_install.cmake','libov_msckf_lib.so'):
        take(build+'/'+name,'openvins-build')
    head=data(take(SOURCE+'/.git/HEAD','source-git'))
    if head and head.startswith(b'ref: '):take(SOURCE+'/.git/'+head.decode().strip()[5:],'source-git')
    take(SOURCE+'/.git/packed-refs','source-git')
    manifest=json.loads((ROOT/'results/native-offset-run-plan-20261018/upstream-build-source-manifest.json').read_bytes())
    for name in manifest['files']:take(SOURCE+'/'+name,'current-upstream-source')
    for name in ('link.txt','flags.make','build.make','DependInfo.cmake','compiler_depend.make','depend.make'):
        take(build+'/CMakeFiles/ov_msckf_lib.dir/'+name,'openvins-build')
    for part in listing(build+'/CMakeFiles'):
        if re.fullmatch(r'\d+(?:\.\d+)+',part):
            for name in ('CMakeCXXCompiler.cmake','CMakeSystem.cmake'):
                take(build+'/CMakeFiles/'+part+'/'+name,'openvins-build')
    # Actual package database and selected package ownership/hash inventories; no dpkg invocation.
    wanted=re.compile(r'^(?:cmake(?:-data)?|make|time|coreutils|systemd(?:-.*)?|binutils(?:-.*)?|g\+\+(?:-.*)?|gcc(?:-.*)?|cpp(?:-.*)?|python3(?:\.\d+)?(?:-minimal)?|lib(?:c6(?:-dev)?|gcc.*|stdc\+\+.*|eigen3-dev|opencv.*|boost.*|ceres.*|google-glog.*|gflags.*|tbb.*|suitesparse.*|blas.*|lapack.*|atlas.*|unwind.*))(?:\:amd64)?\.(?:list|md5sums)$')
    for name in listing('/var/lib/dpkg/info'):
        if wanted.fullmatch(name):take('/var/lib/dpkg/info/'+name,'package-inventory')
    # Config files and linked-library candidates from current package inventory paths.
    package_paths=set()
    for row in tuple(records.values()):
        if 'package-inventory' in row['roles'] and row['linux_path'].endswith('.list'):
            raw=data(row)
            if raw:package_paths.update(line for line in raw.decode('utf-8').splitlines() if line.startswith('/'))
    configs=sorted(p for p in package_paths if p.endswith('.cmake') and any(x in p.lower() for x in ('ceres','opencv','boost','eigen3')))
    for path in configs:take(path,'dependency-cmake-config')
    library_dirs=['/usr/lib/x86_64-linux-gnu','/usr/lib','/usr/local/lib']
    available={directory:listing(directory) for directory in library_dirs}
    queue=[]
    for row in tuple(records.values()):
        if row.get('status')=='observed' and any(role in row['roles'] for role in ('tool','compiler-component','openvins-build')):
            raw=data(row)
            try:parsed=elf(raw)
            except (ValueError,struct.error,IndexError,StopIteration,UnicodeError) as exc:
                row['elf_error']=repr(exc);continue
            if parsed:row['elf']=parsed;queue.extend(parsed['needed'])
    # Include direct declared dependency families even if the old library is absent.
    wantedlib=re.compile(r'lib(?:ceres|opencv_(?:core|imgproc)|boost_(?:filesystem|system|thread|date_time|chrono)|stdc\+\+|gcc_s|tbbmalloc)\.so(?:\..*)?')
    queue.extend(n for names in available.values() for n in names if wantedlib.fullmatch(n))
    seen=set()
    while queue:
        check();name=queue.pop(0)
        if name in seen:continue
        seen.add(name);matches=[]
        for directory,names in available.items():
            # Record exact aliases and regular versioned candidates separately; never infer an unresolved target.
            candidates=[n for n in names if n==name or n.startswith(name+'.')]
            for candidate in candidates:
                path=directory+'/'+candidate;row=take(path,'elf-candidate');matches.append(path)
                if row.get('status')=='observed' and 'elf' not in row:
                    try:parsed=elf(data(row))
                    except (ValueError,struct.error,IndexError,StopIteration,UnicodeError) as exc:
                        row['elf_error']=repr(exc);continue
                    if parsed:row['elf']=parsed;queue.extend(parsed['needed'])
        completion.setdefault('elf_lookup_candidates',{})[name]=matches
    # Current header payload selection derives from actual package lists, bounded globally, not a future compiler depfile.
    headers=sorted(p for p in package_paths if p.startswith('/usr/include/') and not p.endswith('/')
                   and any(x in p for x in ('/eigen3/','/ceres/','/opencv4/','/boost/')))
    completion['header_paths_selected']=len(headers)
    for name in headers:
        if len(records)>=6000:raise ValueError('6000 selected-file cap; remaining header closure uncollected')
        take(name,'header-package-selection')
    completion['complete']=True
except BaseException as exc:
    completion['error']=repr(exc)
finally:
    log.close()
    completion.update(observed=sum(r['status']=='observed' for r in records.values()),
        unresolved=sum(r['status']=='unresolved_reparse' for r in records.values()),selected=len(records),payload_read_bytes=total,
        qualification=False,finish_utc=datetime.datetime.now(datetime.UTC).isoformat())
    for name,value in [('current-files.json',records),('directory-listings.json',listings),('collection-completion.json',completion)]:
        with (OUT/name).open('x',encoding='utf-8') as stream:json.dump(value,stream,indent=2)
    print(json.dumps({k:v for k,v in completion.items() if k!='elf_lookup_candidates'}))
