"""Seal this completed offline stage only; never invokes a study or network."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).resolve().parent
PREP = ROOT / 'results/live-wire-study-dev-1701'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    assert (STAGE / 'full-pytest-v2-exit.txt').read_text(encoding='utf-8-sig').strip() == '0'
    assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=ROOT).strip()
    bound = json.loads((PREP / 'study-v5/executor-binding.json').read_text())
    assert digest((ROOT / 'tools/benchmark/execute_openvins_health_physical_run.py').read_bytes()) == bound['executor']['sha256']
    for path in bound['outputs'].values():
        assert path.startswith('/mnt/c/')
        assert not Path('C:/' + path[len('/mnt/c/'):]).exists()
    assert not (PREP / 'study-v5/activation-request.json').exists()
    paths = {p for p in STAGE.rglob('*') if p.is_file()}
    for version in (4, 5):
        paths.update(p for p in (PREP / f'study-v{version}').rglob('*') if p.is_file())
        paths.update(PREP / n for n in (f'prepare-v{version}.py', f'prepare-v{version}.txt', f'committed-source-v{version}.json'))
    paths.update(ROOT / p for p in (
        'tools/benchmark/execute_openvins_health_physical_run.py',
        'tests/benchmark/test_live_wire_explicit_entry.py',
        'docs/superpowers/specs/2026-10-09-live-wire-explicit-entry-design.md',
        'docs/LIVE_WIRE_EXPLICIT_ENTRY_REPORT.md',
        'docs/LIVE_WIRE_STUDY_PREPARATION_REPORT.md',
    ))
    payload = {p.relative_to(ROOT).as_posix(): p.read_bytes() for p in sorted(paths)}
    manifest = {
        'schema': 'offline-stage-evidence-v1',
        'sealed_source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        'implementation_commit': '438f9f8419918cc9d877ef77fb0394dd583daf47',
        'selected_manifest_sha256': digest((PREP / 'study-v5/study-manifest.json').read_bytes()),
        'actual_dispatch': False, 'network_run': False, 'physical_run': False,
        'fusion_eligible': False,
        'source_copy_scope': 'post-verification worktree copies; installed declaration is not complete runtime closure',
        'members': [{'path': n, 'bytes': len(b), 'sha256': digest(b)} for n, b in payload.items()],
    }
    archive = ROOT / 'evidence/live-wire-explicit-entry-dev-1701.zip'
    encoded = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
        for name, raw in payload.items():
            z.writestr(name, raw)
        z.writestr('MANIFEST.json', encoded)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(payload) + 1
        for name, raw in payload.items():
            assert z.read(name) == raw == (ROOT / name).read_bytes(), name
        assert z.read('MANIFEST.json') == encoded
    summary = {'archive': archive.relative_to(ROOT).as_posix(), 'bytes': archive.stat().st_size,
               'sha256': digest(archive.read_bytes()), 'members': len(payload) + 1,
               'crc_and_members_verified': True, 'physical_run': False, 'fusion_eligible': False}
    with archive.with_suffix('.manifest.json').open('x', encoding='utf-8') as stream:
        json.dump({'summary': summary, 'manifest': manifest}, stream, indent=2)
        stream.write('\n')
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
