# Execution ledger — 2026-10-09-live-wire-explicit-entry-design.md

Base: 36b4f67. Scope: bounded public entry into existing executor; no real runner or network activation.
Prior goal turn: no progress (status explanation); resumed concrete work here.

- Spec exists and user automatic implementation authorization applies.
- Existing executor, validator and offline test fixture inspected.
- New test file covers digest, intent, repeats, aliases, resource recheck, failure retention and CLI routes.
- RED run session 47036 started; terminal result pending. No production implementation yet.
- Ruling: preserve all stage artifacts; skill scratch deletion does not apply to user-required evidence.
- Actual study remains unauthorized under the user's earlier explicit offline-only scope; no change to it in this stage.

- RED complete: 27 assertion failures because execute_live_wire was absent (30.00s); not 27 reproduced production defects.
- Implemented explicit digest-selected entry and separated CLI routes; original _execute_once body unchanged.
- GREEN: 46 new/existing executor tests passed in 107.86s, exit 0. No real subprocess/socket allowed in new tests.
- Changed Ruff and git diff --check passed. Full regression and v5 installed preparation pending.
- Fresh reviewer spawn hit thread limit; resumed an independent completed reviewer with a new bounded source-only request. No implementation delegation or competing test run.

- v5 installed preparation exit0: 610 declared files,82 static sources,8 XML documents,46 edges,40 readonly native queries,5 mutation refusals. No physics/estimator/network. WSL selected-resource scan afterward empty.
- Full pytest first invocation exit2: 73 collection errors,22 skips,6.72s. PYTHONPATH was unset and flydrones resolved to curriculum-training/src. Preserved log and exit. No production defect inferred.
- Import experiment confirms explicit current-worktree src resolves the correct package. v2 full regression session26751 running with process-local PYTHONPATH; no installation or environment persistence.
- v5 package independently reviewed without findings; proposal saved, not executed or authorized.

- Full v2 terminal exit0:3977 passed,33 skipped,3 existing warnings in674.62s. Current-worktree src selected. No production changes after run.
- Final checks preserve request/dispatch/capture/completion/audit/stdout absence; actual activation remains unauthorized. verification.json supersedes the proposal's historical pending-regression observation, not its false authority.
- This turn makes concrete progress (implemented/tested entry and refreshed verified package). Goal remains active; next actual communication step needs scope resolution, not inferred from preparation.
