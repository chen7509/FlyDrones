"""Seal one offline track-eligibility replay and its exact software provenance."""

import hashlib
import json
import zipfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).parent
ARCHIVE = ROOT / 'evidence/openvins-track-eligibility-dev-1701.zip'
INDEX = ROOT / 'evidence/openvins-track-eligibility-dev-1701.sha256.json'
EXTRAS = (
    'docs/OPENVINS_TRACK_ELIGIBILITY_REPORT.md',
    'docs/superpowers/specs/2026-10-04-openvins-track-eligibility-design.md',
    'docs/superpowers/plans/2026-10-04-openvins-track-eligibility.md',
    'tools/benchmark/openvins_init_feature_trace.patch',
    'tools/benchmark/openvins_track_eligibility.patch',
    'tools/benchmark/audit_openvins_init_feature_trace.py',
    'tools/benchmark/audit_openvins_track_eligibility.py',
    'tests/benchmark/test_openvins_track_eligibility.py',
    'evidence/openvins-prearm-board-dev-1701-reviewed.sha256.json',
)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


if ARCHIVE.exists() or INDEX.exists():
    raise SystemExit('refusing existing sealed evidence')
files = sorted((p for p in STAGE.rglob('*') if p.is_file()), key=str)
files.extend(ROOT / rel for rel in EXTRAS)
if len(files) != len(set(files)) or any(p.is_symlink() or not p.is_file() for p in files):
    raise SystemExit('duplicate, missing or unsafe evidence member')
entries = {}
for path in files:
    name = path.relative_to(ROOT).as_posix()
    if PurePosixPath(name).is_absolute() or '..' in PurePosixPath(name).parts:
        raise SystemExit(f'unsafe evidence path: {name}')
    entries[name] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
temporary = ARCHIVE.with_suffix('.zip.partial')
if temporary.exists():
    raise SystemExit('refusing existing partial evidence')
with zipfile.ZipFile(temporary, 'x', compression=zipfile.ZIP_DEFLATED,
                     compresslevel=6) as target:
    for path in files:
        target.write(path, path.relative_to(ROOT).as_posix())
with zipfile.ZipFile(temporary) as source:
    if len(source.namelist()) != len(entries) or set(source.namelist()) != set(entries):
        raise RuntimeError('archive membership mismatch')
    for name, expected in entries.items():
        payload = source.read(name)
        if len(payload) != expected['bytes'] or hashlib.sha256(payload).hexdigest() != expected['sha256']:
            raise RuntimeError(f'archive readback mismatch: {name}')
temporary.replace(ARCHIVE)
index = {
    'schema': 'flydrones-sealed-development-evidence-v1',
    'archive': ARCHIVE.relative_to(ROOT).as_posix(),
    'archive_bytes': ARCHIVE.stat().st_size,
    'archive_sha256': sha(ARCHIVE),
    'member_count': len(entries),
    'members': entries,
}
INDEX.write_bytes((json.dumps(index, indent=2) + '\n').encode())
print(json.dumps({k: v for k, v in index.items() if k != 'members'}, indent=2))
