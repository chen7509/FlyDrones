"""Record immutable inputs for the single track-eligibility offline replay."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).parent
SOURCE = Path('C:/Users/yuche/.codex/worktrees/FlyDrones/prearm-target/results/openvins-prearm-board-dev-1701')
OUT = STAGE / 'provenance.json'
if OUT.exists():
    raise SystemExit('refusing existing provenance')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


paths = {
    'earlier_logging_patch': ROOT / 'tools/benchmark/openvins_init_feature_trace.patch',
    'new_logging_patch': ROOT / 'tools/benchmark/openvins_track_eligibility.patch',
    'applied_upstream_diff': STAGE / 'upstream-applied.patch',
    'offline_runner': SOURCE / 'dependencies-v1/offline_probe',
    'estimator_config': SOURCE / 'dependencies-v1/config-v2/estimator_config.yaml',
    'source_input_manifest': SOURCE / 'input-v1/manifest.json',
    'source_imu_csv': SOURCE / 'input-v1/imu.csv',
    'source_frames_csv': SOURCE / 'input-v1/frames.csv',
    'source_episode_result': SOURCE / 'episode-run-v3/result.json',
    'previous_replay_states': SOURCE / 'replay-v1/states.csv',
    'new_replay_states': STAGE / 'replay-v1/states.csv',
    'new_replay_stdout': STAGE / 'replay-v1/stdout.txt',
}
manifest = {
    'schema': 'flydrones-openvins-track-eligibility-provenance-v1',
    'upstream': 'rpng/open_vins@69488123ed9362dd44b6f28e7f4680abbff1442b',
    'upstream_license': 'GPL-3.0',
    'compiler': 'g++ (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0',
    'opencv': '4.6.0',
    'new_library_sha256': 'a89787d424e2a127c2dcaf52b381e50229c413385036df6131dda077677a86be',
    'library_archived': False,
    'prior_reviewed_evidence_zip_sha256': '4b2f77d7f54b1a50f78c8b5d7a05cba0bed93a5a6bdff06c77e0e360ce1e9f29',
    'prior_pr': 'https://github.com/chen7509/FlyDrones/pull/25',
    'sha256': {name: sha(path) for name, path in paths.items()},
}
OUT.write_bytes((json.dumps(manifest, indent=2) + '\n').encode())
print(json.dumps(manifest, indent=2))
