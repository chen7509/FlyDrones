import hashlib
import json
import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
archive = ROOT/'evidence/openvins-cold-bootstrap-dev-1701.zip'
external = ROOT/'evidence/openvins-cold-bootstrap-dev-1701-manifest.json'
assert not archive.exists() and not external.exists()
assert (OUT/'full-tests-exit.txt').read_text().strip() == '0'
full = (OUT/'full-tests.txt').read_text()
assert re.search(r'3080 passed, 3 skipped, 2 warnings in', full)
assert sha((ROOT/'evidence/openvins-listener-wire-format-dev-1701.zip').read_bytes()) == '2b6ee4dc97668336c511b7903c79edc754e953a27b0e3a038b85d48ccb9ac117'
assert sha((ROOT/'tests/fixtures/timesync/pinned-listener-implicit.bin').read_bytes()) == 'ac6ac202582da1725b491cc0a7d326198edd5683fed475e080088795e2e5cda0'
matrix = json.loads((OUT/'matrix-v1/summary.json').read_text())
assert len(matrix) == 12 and sum(x['progress']['modeled_bootstrap_ready'] for x in matrix) == 2
paths = sorted(p for p in OUT.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
paths += [ROOT/p for p in (
    'tools/benchmark/openvins_timesync_bootstrap.py',
    'tools/benchmark/openvins_timesync_listener.py',
    'tools/benchmark/openvins_timesync_observer.py',
    'tests/benchmark/test_openvins_timesync_bootstrap.py',
    'tests/fixtures/timesync/pinned-listener-implicit.bin',
    'tests/fixtures/timesync/pinned-listener-implicit.json',
    'tests/fixtures/timesync/.gitattributes',
    'docs/OPENVINS_TIMESYNC_BOOTSTRAP_REPORT.md',
    'docs/superpowers/specs/2026-10-08-timesync-cold-bootstrap-design.md',
    'docs/superpowers/plans/2026-10-08-timesync-cold-bootstrap.md',
    '.superpowers/sdd/2026-10-08-timesync-cold-bootstrap/progress.md')]
payload = {p.relative_to(ROOT).as_posix(): p.read_bytes() for p in paths}
assert len(payload) == len(paths)
manifest = dict(schema='evidence-members-v1', producer='1d92b91',
    members=[dict(path=name, bytes=len(data), sha256=sha(data)) for name, data in sorted(payload.items())],
    clock='synthetic supplied clock; no measured live timing',
    live_convergence_qualified=False, network_authorized=False, fusion_qualified=False)
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for name, data in payload.items():
        z.writestr(name, data)
    z.writestr('member-manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for member in manifest['members']:
        data = z.read(member['path'])
        assert len(data) == member['bytes'] and sha(data) == member['sha256']
    count = len(z.namelist())
result = dict(archive=archive.relative_to(ROOT).as_posix(), sha256=sha(archive.read_bytes()),
              members=count, bytes=archive.stat().st_size, crc_verified=True,
              member_hashes_verified=True, historical_archive_unchanged=True)
with external.open('x', encoding='utf-8') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
