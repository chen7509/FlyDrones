# Next concrete dependency (not permission to transmit)

Current coordinator is an offline model, not an actual epoch verifier. Reuse
existing owned isolated launch, interval restoration, pinned listener framing and
serial observer. Do not repeat the namespace harness or normal physical study.

Before implementation inspect the actual capture/launch call sites and pinned
PX4 command-client/server code: inherited cwd and filesystem socket, runtime
resource selection, fresh process start, actual receiver/channel discovery,
exclusive responder and source identity. A token supplied by the caller proves
none of these. Existing bootstrap instance0 is a subscription, not channel0.

Define one bounded offline transport adapter with concrete evidence inputs,
explicit read/write/exit deadlines, monotonic clock and a journal that records
attempt/result rather than merely intent. Prevent journal blocking from silently
extending the8s readiness or2s deadlines. Account for latest-value uORB coalescing:
500 listener records alone do not prove500 accepted real filter updates.
Use synthetic process/transport fixtures first; preserve every unsuccessful
attempt, partial delivery and exact stream restore transaction. No runtime
boolean may turn this model's live/network/fusion flags true.

Actual PX4 startup, MAVLink stream changes or injections are outside the current
offline authority. Next live design must state all gates and limited requested
actions; do not silently send ODOMETRY or arm. No thresholds may be relaxed to
avoid a failed startup. Keep25s/1ms/250Hz/10Hz160x120 and8s/2s/500 unchanged.
