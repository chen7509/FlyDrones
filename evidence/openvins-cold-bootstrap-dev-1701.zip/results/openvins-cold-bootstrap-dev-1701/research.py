import hashlib
import json
import urllib.request
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
archive=ROOT/'evidence/openvins-listener-wire-format-dev-1701.zip'
assert sha(archive.read_bytes())=='2b6ee4dc97668336c511b7903c79edc754e953a27b0e3a038b85d48ccb9ac117'
with zipfile.ZipFile(archive) as z:
    member='results/openvins-listener-wire-format-dev-1701/native-v1/implicit-one.stdout'
    data=z.read(member)
    assert data==(ROOT/'tests/fixtures/timesync/pinned-listener-implicit.bin').read_bytes()
    fixture=dict(archive_sha256=sha(archive.read_bytes()),member=member,sha256=sha(data),bytes=len(data),
                 source='Unchanged fixed listener with stub uORB/field printer, no real PX4',
                 live_listener_qualified=False)
    with (ROOT/'tests/fixtures/timesync/pinned-listener-implicit.json').open('x',encoding='utf-8') as f:
        json.dump(fixture,f,indent=2)
sources=[]
for relative in ('platforms/common/uORB/uORBManager.hpp','platforms/common/uORB/uORBManager.cpp'):
    url='https://raw.githubusercontent.com/PX4/PX4-Autopilot/d6f12ad1c4f70ad3230afd7d86e971421e02fef4/'+relative
    target=OUT/'sources'/Path(relative).name
    target.parent.mkdir(exist_ok=True)
    try:
        with urllib.request.urlopen(url,timeout=20) as response:
            data=response.read()
        with target.open('xb') as f:
            f.write(data)
        installed=Path('/home/yuchen7509/PX4-Autopilot')/relative
        sources.append(dict(url=url,path=str(target),sha256=sha(data),installed_equal=data==installed.read_bytes()))
    except Exception as exc:
        sources.append(dict(url=url,error=type(exc).__name__+':'+str(exc)))
        (OUT/'source-errors.json').write_text(json.dumps(sources,indent=2))
        raise
metadata=json.loads((ROOT/'results/openvins-timesync-channel-dev-1701/px4-metadata.json').read_text())
record=dict(pin='d6f12ad1c4f70ad3230afd7d86e971421e02fef4',license='BSD-3-Clause',sources=sources,
    reused_maintenance=dict(archived=metadata['archived'],pushed_at=metadata['pushed_at'],new_fetch=False),
    fixture=fixture,
    reused_source_paths=['results/openvins-timesync-listener-dev-1701/reused/src/systemcmds/topic_listener/listener_main.cpp',
        'results/openvins-timesync-listener-dev-1701/reused/platforms/common/uORB/uORBDeviceNode.cpp'],
    interface='Source-derived implicit0/#1 snapshot; initial explicit #1 replays that same data once.',
    decision='Compose existing parser/filter, reject ambiguity, do not infer channel number or fresh process from tags.',
    resources='No new packages/runtime process; bounded8s model,2s progress,65536 journal events. Real latency unqualified.',
    adaptation='Opaque lifecycle tags and journal callable need actual owned transport/process binding later.',
    paper_scope='No new estimation algorithm; protocol/source-derived startup composition only.')
record['reused_source_hashes']={p:sha((ROOT/p).read_bytes()) for p in record['reused_source_paths']}
with (OUT/'research.json').open('x',encoding='utf-8') as f:
    json.dump(record,f,indent=2)
print(json.dumps(sources))
