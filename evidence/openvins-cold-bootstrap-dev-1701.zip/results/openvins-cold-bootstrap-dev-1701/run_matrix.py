"""File-only prospective matrix. All clocks and protocol bodies are synthetic."""
import hashlib
import json
import subprocess
from pathlib import Path

from tools.benchmark.openvins_timesync_bootstrap import ColdTimesyncBootstrap

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent / 'matrix-v1'
PREFIX = b'\x1b[2J\n\x1b[H'
EPOCH = 'synthetic-epoch-a'
LISTENER = 'synthetic-listener-a'
CASES = ['normal500', 'insufficient499', 'retained-rejection501', 'first-mismatch',
         'partial-unsolicited', 'partial-next', 'silent-frame', 'epoch-change',
         'clock-regression', 'eight-second-boundary', 'journal-failure', 'bad-exit']


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        data = json.dumps(value, indent=2) + '\n'
        assert stream.write(data) == len(data)
        stream.flush()


def record(index=0, rtt=2000, single=False):
    request = 100000 + index * 20000
    remote = request + rtt // 2
    header = (b'\nTOPIC: timesync_status\n' if single else
              PREFIX + f'\nTOPIC: timesync_status instance 0 #{index+1}\n'.encode())
    body = (f' timesync_status\n    timestamp: {request+rtt} (0.000001 seconds ago)\n'
            f'    remote_timestamp: {remote}\n    observed_offset: 0\n'
            f'    estimated_offset: 0\n    round_trip_time: {rtt}\n'
            '    source_protocol: 0\n\n').encode()
    return request*1000, remote*1000, header+body


def main():
    OUT.mkdir(exist_ok=False)
    sources = [Path(__file__), ROOT/'tools/benchmark/openvins_timesync_bootstrap.py',
               ROOT/'tools/benchmark/openvins_timesync_listener.py',
               ROOT/'tools/benchmark/openvins_timesync_observer.py']
    pre = {str(p.relative_to(ROOT)): digest(p) for p in sources}
    save(OUT/'prospective.json', dict(cases=CASES, hashes=pre,
         producer=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
         clock='synthetic uint64 nanoseconds, not measured wall time',
         stream_count='500 except retained-rejection501=501',
         expected_success=['normal500', 'retained-rejection501'],
         readiness_ns=8000000000, frame_timeout_ns=2000000000,
         live_convergence_qualified=False, network_authorized=False, fusion_qualified=False))
    summaries = []
    for case in CASES:
        folder = OUT/case
        folder.mkdir()
        inputs = []
        serial = 0

        def journal(event):
            nonlocal serial
            if case == 'journal-failure' and event['kind'] == 'reply_intent':
                raise OSError('prospective synthetic journal failure')
            # Each immutable event is its own exclusive JSONL file. This checks
            # close before returning; no crash durability or actual I/O timeout.
            path = folder/f'event-{serial:04d}.jsonl'
            with path.open('x', encoding='utf-8', newline='\n') as stream:
                data = json.dumps(event, separators=(',', ':')) + '\n'
                if stream.write(data) != len(data):
                    raise OSError('short write')
                stream.flush()
            serial += 1

        obj = ColdTimesyncBootstrap(case, EPOCH, 0, journal,
                                   stream_records=501 if case == 'retained-rejection501' else 500)

        def call(method, *args, now, epoch=EPOCH):
            inputs.append(dict(method=method, args=[{'hex': a.hex()} if isinstance(a, bytes) else a for a in args],
                               now_ns=now, epoch_token=epoch))
            return getattr(obj, method)(*args, now_ns=now, epoch_token=epoch)

        error = None
        try:
            call('confirm_empty', b'never published\n', 0, now=1)
            call('reserve_reply', *record()[:2], now=2)
            call('confirm_first', record(1 if case == 'first-mismatch' else 0, single=True)[2], 0, now=3)
            call('begin_stream', LISTENER, now=4)
            call('feed_stream', record()[2], LISTENER, now=5)
            if case == 'partial-unsolicited':
                call('feed_stream', PREFIX[:3], LISTENER, now=6)
            elif case == 'partial-next':
                call('reserve_reply', *record(1)[:2], now=6)
                call('feed_stream', record(1)[2]+PREFIX[:3], LISTENER, now=7)
            elif case == 'silent-frame':
                call('reserve_reply', *record(1)[:2], now=1900000000)
                call('check', now=2000000005)
            elif case == 'epoch-change':
                call('check', now=6, epoch='synthetic-epoch-b')
            elif case == 'clock-regression':
                call('check', now=4)
            elif case == 'eight-second-boundary':
                call('check', now=8000000000)
            else:
                count = 501 if case == 'retained-rejection501' else 500
                for index in range(1, count):
                    rtt = 10000 if index == 1 and case in ('insufficient499', 'retained-rejection501') else 2000
                    call('reserve_reply', *record(index, rtt)[:2], now=index*10000000)
                    call('feed_stream', record(index, rtt)[2], LISTENER, now=index*10000000+1)
                call('finish_stream', 7 if case == 'bad-exit' else 0, LISTENER, now=(count-1)*10000000+2)
        except (ValueError, OSError) as exc:
            error = dict(type=type(exc).__name__, message=str(exc))
        progress = obj.progress
        expected = case in ('normal500', 'retained-rejection501')
        assert progress['modeled_bootstrap_ready'] == expected
        assert (error is None) == expected
        assert all(progress[k] is False for k in ('live_convergence_qualified', 'network_authorized', 'fusion_qualified'))
        journaled = [json.loads(p.read_text()) for p in sorted(folder.glob('event-*.jsonl'))]
        replay = [e for e in journaled if e['kind'] == 'latest_replay']
        if expected:
            assert progress['modeled_accepted_samples'] == 500
            assert len(replay) == 1 and replay[0]['counts_as_new_sample'] is False
        result = dict(case=case, expected_success=expected, progress=progress, exception=error,
                      journal_files=len(journaled), modeled_memory_events=obj.events)
        save(folder/'inputs.json', inputs)
        save(folder/'result.json', result)
        summaries.append({k: result[k] for k in ('case', 'expected_success', 'progress', 'exception', 'journal_files')})
    post = {str(p.relative_to(ROOT)): digest(p) for p in sources}
    save(OUT/'post-hashes.json', post)
    assert post == pre
    save(OUT/'summary.json', summaries)
    print(f'{len(summaries)} fixed file-only cases matched prospective outcomes; no live authority')


if __name__ == '__main__':
    main()
