# SDD ledger — plan: docs/superpowers/plans/2026-10-08-timesync-cold-bootstrap.md
Previous goal turn progress:d34ecef, framing correction published. Current initial
tracked tree clean and selected Windows/WSL simulation/training/test scan empty.
Existing worktree retained. Architectural composition uses written spec/plan,
user preapproval and inline executing-plans/TDD; no new physical authority.
Pre-flight shared interfaces: implicit snapshot maps only exact fixed default0/#1
header into existing plain parser; multi stream uses explicit pinned profile;
first latest replay not fed to observer, so subsequent ordinal2 remains ordinal2.
Task1 initialRED was missing module collection error, not behavioral failure.
FirstGREEN920 tests passed. Two additional actual RED assertions exposed early
partial bytes before next reservation / after completed reserved record in same
chunk. Added read-only incomplete_frame_bytes parser property and immediate
coordinator refusal; focused975passed, changedRuff/diff passed.
Ruling: add65536 journal event cap for repeated empty input / stalled supplied
clock; cap stated in spec, no relaxation of acceptance/window requirements.
Fixed Manager.hpp/cpp downloaded with verified TLS, both equal installed files.
Implicit fixture reused from sealed2b6ee4... archive, no native rerun. Tokens are
comparison tags, not observed process identity; journal/supplied clock do not
provide asynchronous timeout or crash-durable storage. Full/live flags remainfalse.
Independent review found one Important: public check did not poll active decoder deadline. Exact-boundary assertion RED reproduced, active decoder.check added to every transition, 976 focused GREEN; no other findings. Previous user status turn was no-progress; resumed with this verified fix.
Review final clean. File-only prospective matrix-v1 producer1d92b91:12cases matched (2modeled success,10expected refusals), exact source pre/post unchanged. Full pytest session97601 remains live; do not duplicate.
Full regression terminal exit0:3080passed/3skipped/2existingwarnings339.45s. Existing CLI training smoke fixtures only, no new training study. Matrix all10refusal reasons individually checked against their intended condition;2modeled success, all live authority false. Source/fixture/history hashes retained; sealing and existing PR65 publication next.
