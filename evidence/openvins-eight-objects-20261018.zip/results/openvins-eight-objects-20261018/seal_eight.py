"""Verify and seal only newly retained remaining-object evidence, never Linux files."""
import ast
import hashlib
import json
from pathlib import Path
import zipfile

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
POST=OUT/'postseal'
FILES=['docs/OPENVINS_EIGHT_OBJECTS_PROGRESS.md','docs/superpowers/plans/2026-10-18-openvins-eight-objects.md']
FILES+=['results/openvins-eight-objects-20261018/'+n+'.json' for n in (
    'file-bindings','object-static-observations','object-union-bindings','analysis-summary','missing-evidence')]


def sha(raw):return hashlib.sha256(raw).hexdigest()


s=json.loads((OUT/'analysis-summary.json').read_bytes())
c=json.loads((OUT/'selection-contract.json').read_bytes())
f=json.loads((OUT/'current-files.json').read_bytes())
assert s['status_counts']==dict(observed=5,file_cap=1,aggregate_cap=1)
assert s['authorized_object_paths']==8 and len(f)==7
assert set(f).isdisjoint(c['previously_acquired_paths']) and set(f).isdisjoint(c['known_overcap_paths_not_reprobed'])
assert s['new_static_rel_x86_64']==5 and not s['object_parse_errors']
assert s['actual_payload_bytes_read']==s['new_payload_bytes']==160403224<201326592
assert s['total_objects_with_retained_bytes']==30 and s['objects_remaining_unknown']==4
assert s['current_known_overcap_objects']==s['unacquired_not_confirmed_overcap']==2
assert s['known_overcap_paths_reprobed']==s['prior_acquired_path_overlap']==0
assert s['no_log_search'] and s['no_directory_enumeration']
assert not s['acquisition_complete'] and not s['source_to_existing_library_proven']
assert s['current_library_sha256'] is None and s['native_admission'] is False
for name,row in f.items():
    if row['status']=='observed':
        raw=(OUT/row['blob']).read_bytes()
        assert len(raw)==row['bytes']<=67108864 and sha(raw)==row['sha256']
        assert row['before']==row['after']
    elif row['status']=='file_cap':assert row['before']['size']==81915872 and 'blob' not in row
    elif row['status']=='aggregate_cap':assert row['before']['size']==45841632 and 'blob' not in row
for p in OUT.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'),filename=str(p))
with (OUT/'self-check.json').open('x',encoding='utf-8') as stream:
    json.dump(dict(scope='Executor new saved payload/JSON/helperAST only; no old archives/tests/source/native/delivery review.',
        new_files_verified=5,new_objects_static_rel_x86_64=5,prior_path_overlap=0,known_overcap_paths_reprobed=0,
        aggregate_read_stopped=True,total_retained_objects=30,objects_unknown=4,
        no_log_search=True,no_directory_enumeration=True,current_library_sha256=None,
        source_to_existing_library_proven=False,native_commands=False,resource_queries=False,
        tests_run=False,all_qualifications=False),stream,indent=2)
paths=set(FILES)
for p in OUT.rglob('*'):
    if 'postseal' in p.relative_to(OUT).parts or '__pycache__' in p.parts or p.suffix=='.pyc':continue
    if p.is_file() and not p.is_symlink():paths.add(p.relative_to(ROOT).as_posix())
mapping={}
archive=ROOT/'evidence/openvins-eight-objects-20261018.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as output:
    for name in sorted(paths):
        raw=(ROOT/name).read_bytes();mapping[name]=dict(bytes=len(raw),sha256=sha(raw))
        entry=zipfile.ZipInfo(name,(2026,10,18,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;entry.external_attr=0o100600<<16
        output.writestr(entry,raw)
    manifest=json.dumps(dict(schema='openvins-remaining-object-evidence-archive-v1',mapping=mapping,
        note='Newly authorized exact8 object selection, known overcap skipped; partial, not old library provenance or native admission.'),sort_keys=True,indent=2).encode()
    output.writestr('manifest.json',manifest)
with zipfile.ZipFile(archive) as source:
    assert source.testzip() is None and len(source.namelist())==len(mapping)+1
    for name,row in mapping.items():assert sha(source.read(name))==row['sha256']
receipt=dict(schema='openvins-eight-objects-seal-v1',archive=archive.relative_to(ROOT).as_posix(),bytes=archive.stat().st_size,
    sha256=sha(archive.read_bytes()),members=len(mapping)+1,mapped=len(mapping),
    mapped_payload_bytes=sum(r['bytes'] for r in mapping.values()),manifest_bytes=len(manifest),
    whole_expanded_bytes=sum(r['bytes'] for r in mapping.values())+len(manifest),software_files=FILES,
    source_to_existing_library_proven=False,native_admission=False,all_qualifications=False)
with archive.with_suffix('.sha256.json').open('x',encoding='utf-8') as stream:json.dump(dict(**receipt,mapping=mapping),stream,indent=2)
POST.mkdir(exist_ok=False)
with (POST/'seal-receipt.json').open('x',encoding='utf-8') as stream:json.dump(receipt,stream,indent=2)
print(json.dumps({k:v for k,v in receipt.items() if k!='software_files'}))
