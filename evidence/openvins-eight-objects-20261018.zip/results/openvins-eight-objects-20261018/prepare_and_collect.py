"""New authorized eight-object acquisition; never executes or modifies Linux files."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
PRIOR=['results/native-linux-file-receipts-20261018','results/openvins-build-provenance-20261018','results/openvins-remaining-objects-20261018']


def save(name,value):
    with (OUT/name).open('x',encoding='utf-8') as s:json.dump(value,s,ensure_ascii=True,indent=2)


excluded={};known_overcap={};refs=[]
for phase in PRIOR:
    raw=(ROOT/phase/'current-files.json').read_bytes()
    refs.append(dict(path=phase+'/current-files.json',sha256=hashlib.sha256(raw).hexdigest()))
    for name,row in json.loads(raw).items():
        if row.get('blob'):excluded[name]=dict(phase=phase,blob=row['blob'],bytes=row['bytes'],sha256=row['sha256'])
        if row['status']=='file_cap':known_overcap[name]=dict(phase=phase,observed_metadata=row['before'],limit=row['limit'])
all_units=json.loads((ROOT/PRIOR[1]/'selection-contract.json').read_bytes())['associations']
remaining=json.loads((ROOT/PRIOR[2]/'missing-evidence.json').read_bytes())['unobserved_objects']
names={r['object'] for r in remaining if r['object'] not in known_overcap}
units=[r for r in all_units if r['object'] in names]
assert len(units)==8 and len(excluded)==981
assert len([n for n in known_overcap if n.endswith('/DynamicInitializer.cpp.o')])==1
assert all(r['object'] not in excluded and r['object'] not in known_overcap for r in units)
source='/home/yuchen7509/flydrones-upstream/open_vins'
save('selection-contract.json',dict(schema='openvins-eight-object-selection-v1',prior_manifest_references=refs,
    previously_acquired_paths=excluded,known_overcap_paths_not_reprobed=known_overcap,
    associations=units,all_associations=all_units,build_root=source+'/ov_msckf/build',
    no_directory_enumeration=True,no_log_search=True,
    limits=dict(file_bytes=67108864,aggregate_payload_bytes=201326592,selected_paths=6000,
        read_seconds=27,parent_wait_seconds=30,terminate_wait_seconds=5,kill_wait_seconds=5,outer_seconds=45),
    all_qualifications=False,source_to_existing_library_proven=False))
save('collection-start.json',dict(utc=datetime.datetime.now(datetime.UTC).isoformat(),
    argv=[sys.executable,str(OUT/'collect_eight_objects.py')],cwd=str(ROOT),
    limits='selection-contract.json',linux_access='Windows standard readonly file I/O only',
    env_policy='Windows inherited environment, not a full environment capture'))
start=time.monotonic();result=dict(complete=False)
with (OUT/'collection.stdout').open('xb') as stdout,(OUT/'collection.stderr').open('xb') as stderr:
    child=subprocess.Popen([sys.executable,str(OUT/'collect_eight_objects.py')],cwd=ROOT,stdout=stdout,stderr=stderr)
    result['owned_windows_child_pid']=child.pid
    try:
        result['returncode']=child.wait(timeout=30);result['complete']=result['returncode']==0
    except subprocess.TimeoutExpired:
        result['parent_timeout']=True;child.terminate()
        try:result['returncode']=child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            child.kill()
            try:result['returncode']=child.wait(timeout=5)
            except subprocess.TimeoutExpired:result['cleanup_unknown']=True
result['elapsed_seconds']=time.monotonic()-start
save('collection-parent-completion.json',result)
print(json.dumps(result))
