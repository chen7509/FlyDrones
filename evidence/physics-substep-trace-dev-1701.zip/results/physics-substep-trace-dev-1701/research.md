# Prospective source/adapter choice

Adopt installed Gazebo8.15 TestFixture pre/post callbacks and Link readback. Official https://gazebosim.org/api/sim/8/createsystemplugins.html states simTime is end-of-step: pre precedes dynamics, post follows. https://gazebosim.org/api/sim/8/classgz_1_1sim_1_1TestFixture.html documents finalize/callback lifecycle. No assumed arrival-to-simulation time subtraction. Cost is1000Hz double-state IO and no native estimator; not a benchmark optimization.

Pinned Gazebo source446a44335a45b704b4d36dabcc5508ee34eeb3d8 Apache2; gz-physics189471c86fa06ffad9c9bdb199f6928eb2fc02f3 Apache2; DARTa51e08c210d7892605c6dc0b9ae96fce4446d9fe BSD2, existing PR37/38 source seals. Repos nonarchived with prior current metadata. DARTGenericJoint includes constraintdeltaV/dt in acceleration; source alone cannot prove installed binary behavior or sampling consistency. Record actual loaded backend maps/hashes plus installed package provenance. No installation or upgrade.

OpenVINS6948812 GPL3 and ICRA2020 reference https://pgeneva.com/downloads/papers/Geneva2020ICRA.pdf remain context for inertial consistency but estimator is deliberately not used in this physics diagnosis. Existing raw encoder/recorder/watchdog and motion boundaries reused. Reject another estimator replay, noise sweep, truth-derived input or altered physics/rate: those obscure the existing discrepancy.

Named substep-lateral-v1 condition and exact analysis windows frozen in spec. All four250Hz phases analyzed with own true endpoints; no favored phase chosen to make the sensor appear correct. Full-rate integral and pre/post continuity measured before any causal interpretation. No claim of final drift root cause or calibrated source from this diagnostic alone.
