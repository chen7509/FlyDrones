import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
import numpy as np
from scipy.spatial.transform import Rotation
from pyulog import ULog
root=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(root),str(root/'src')]
from tools.benchmark.physics_substep_trace import phase_closures
from tools.benchmark.disarmed_sensor_provenance import audit_event_records
base=Path(__file__).resolve().parent
p=base/'capture-v1'
read=lambda name:[json.loads(x) for x in (p/name).read_text().splitlines()]
result=json.loads((p/'result.json').read_text())
assert result['status']=='capture_completed' and not result['estimator_run']
rows=read('physics-substeps.jsonl')
assert len(rows)==50000
for i,r in enumerate(rows):
    assert r['phase']==['pre','post'][i%2] and r['sim_ns']==(i//2+1)*1000000
    assert r['state_time_ns']==r['sim_ns']-(1000000 if i%2==0 else 0)
    assert r['truth_for_diagnostics_only'] and r['dt_ns']==1000000
    if i:assert r['wall_ns']>=rows[i-1]['wall_ns']
keys=['position','velocity_world','accel_world','angular_world','quaternion_xyzw']
continuity={k:0. for k in keys}
for i in range(2,len(rows),2):
    if rows[i]['available'] and rows[i-1]['available']:
        for k in keys:continuity[k]=max(continuity[k],float(np.max(abs(np.array(rows[i][k])-rows[i-1][k]))))
events=read('events.jsonl')
counts=audit_event_records(events,required_kinds={'imu','rgb','info','depth','heartbeat'})
post={r['sim_ns']:r for r in rows if r['phase']=='post' and r['available']}
imu=[r for r in events if r['kind']=='imu']
gravity=np.array([float(x) for x in ET.parse(p/'world.sdf').getroot().findtext('world/gravity').split()])
windows=[]
for start,end in [(5000000000,5100000000),(5000000000,6600000000),(8000000000,9000000000)]:
    analysis=phase_closures(rows,start,end)
    raw=[r for r in imu if start<=r['sample_ns']<=end]
    assert [r['sample_ns'] for r in raw]==list(range(start,end+1,4000000))
    a=np.array([Rotation.from_quat(post[r['sample_ns']]['quaternion_xyzw']).apply(r['accel_flu'])+gravity for r in raw])
    t=np.array([r['sample_ns'] for r in raw],dtype=np.int64)
    dv=np.array(post[end]['velocity_world'])-post[start]['velocity_world']
    right=np.sum(a[1:]*np.diff(t)[:,None]*1e-9,axis=0)
    trap=np.sum((a[1:]+a[:-1])*.5*np.diff(t)[:,None]*1e-9,axis=0)
    phys=np.array([post[r['sample_ns']]['accel_world'] for r in raw])
    analysis['raw_actual_phase']=dict(phase_ns=int(t[0]%4000000),samples=len(raw),right_error_norm_m_s=float(np.linalg.norm(right-dv)),trapezoid_error_norm_m_s=float(np.linalg.norm(trap-dv)),same_stamp_accel_residual_p95=float(np.percentile(np.linalg.norm(a-phys,axis=1),95)))
    windows.append(analysis)
commands=read('motion-force.jsonl')
assert len(commands)==1601 and all(c['call_returned'] for c in commands)
assert [c['sim_ns'] for c in commands]==list(range(5000000000,6601000000,1000000))
force=np.array([c['force_world_n'] for c in commands])
assert np.sum(force)==0 and abs(np.sum(abs(force))*.001-41.6)<1e-10
ulogs=[]
for meta in result['px4_ulogs']:
    path=p/meta['path'];assert hashlib.sha256(path.read_bytes()).hexdigest()==meta['sha256']
    state=ULog(str(path)).get_dataset('vehicle_status').data['arming_state']
    assert len(state)>0 and np.all(state!=2)
    ulogs.append(dict(meta,arming_records=len(state),arming_values=[int(x) for x in np.unique(state)]))
backend=json.loads((p/'backend-loaded.json').read_text())
for entry in backend:assert hashlib.sha256(Path(entry['path']).read_bytes()).hexdigest()==entry['sha256']
summary=dict(trace_records=len(rows),unavailable_records=sum(not r['available'] for r in rows),pre_previous_post_max_abs=continuity,counts=counts,force_steps=1600,ulogs=ulogs,backend=backend,windows=windows,eligible_for_px4_fusion=False,estimator_run=False,root_cause_of_all_vio_drift_proven=False)
with (base/'audit.json').open('x') as f:json.dump(summary,f,indent=2)
print(json.dumps(summary,indent=2))
