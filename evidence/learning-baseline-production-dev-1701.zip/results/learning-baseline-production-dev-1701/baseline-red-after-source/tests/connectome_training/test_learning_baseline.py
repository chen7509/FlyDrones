import pytest
import torch

from flydrones.connectome_training import curriculum_session as sessions
from test_learning_roles import config, rewrite_payload, save_session, session  # noqa: F401


@pytest.mark.parametrize('field', ['input_gain','type_bias_mv','tau_m_ms','readout'])
def test_changed_active_initialization_cannot_reuse_identity_or_restore(config,tmp_path,monkeypatch,field):
    first=session(config,'shared-dynamics-v1')
    save_session(first,tmp_path/'checkpoint')
    original=sessions._smoke_components
    def changed(cfg):
        c,p,d=original(cfg)
        setattr(p,field,getattr(p,field)+0.125)
        return c,p,d
    monkeypatch.setattr(sessions,'_smoke_components',changed)
    other=session(config,'shared-dynamics-v1')
    assert first.model_identity != other.model_identity
    before=[p.detach().clone() for p in other.model.parameters()]
    with pytest.raises(ValueError,match='metadata mismatch'):
        other.restore_checkpoint(tmp_path/'checkpoint')
    assert all(torch.equal(a,b) for a,b in zip(before,other.model.parameters()))


@pytest.mark.parametrize('drift',['loss','truncate','weights'])
def test_validation_baseline_drift_refuses_checkpoint_output(config,tmp_path,drift):
    current=session(config,'shared-dynamics-v1')
    if drift=='loss':current.initial_losses[config.stages[0].id] *= 2
    elif drift=='truncate':current.truncate_steps+=1
    else:current.loss_weights=type(current.loss_weights)(velocity=2)
    with pytest.raises(ValueError,match='baseline'):
        save_session(current,tmp_path/'checkpoint')
    assert not (tmp_path/'checkpoint').exists()


def test_coherent_baseline_tamper_refuses_before_parameter_copy(config,tmp_path):
    first=session(config,'shared-dynamics-v1')
    first.train_batch(config.stages[0],1101)
    save_session(first,tmp_path/'checkpoint')
    rewrite_payload(tmp_path/'checkpoint',lambda p:p['metadata'].update(validation_baseline={'fabricated':1}))
    other=session(config,'shared-dynamics-v1')
    before=[p.detach().clone() for p in other.model.parameters()]
    with pytest.raises(ValueError,match='metadata mismatch'):
        other.restore_checkpoint(tmp_path/'checkpoint')
    assert all(torch.equal(a,b) for a,b in zip(before,other.model.parameters()))


def test_same_initialized_session_restores_without_relabeling_trained_values(config,tmp_path):
    first=session(config,'shared-dynamics-v1')
    identity=first.model_identity
    first.train_batch(config.stages[0],1101)
    save_session(first,tmp_path/'checkpoint')
    other=session(config,'shared-dynamics-v1')
    other.restore_checkpoint(tmp_path/'checkpoint')
    assert other.model_identity==identity
    assert other.initial_losses==first.initial_losses
    assert all(torch.equal(a,b) for a,b in zip(first.model.parameters(),other.model.parameters()))
