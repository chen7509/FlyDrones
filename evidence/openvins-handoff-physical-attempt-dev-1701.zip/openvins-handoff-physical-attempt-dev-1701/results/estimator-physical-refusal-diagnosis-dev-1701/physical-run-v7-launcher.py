import argparse
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path("/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility")
sys.path[:0] = [str(ROOT), str(ROOT / "src")]

from tools.benchmark.capture_disarmed_sensors import active_resources

EXPECTED_HEAD = "5d36f6fd6fb47df412cb70044256e8313eeb017b"
EXPECTED_ARCHIVE_SHA256 = "7f8bbaacf577a073b8c0452a18151bb8aa5c2bb244b8517d74490bf86984c647"
BASE = ROOT / "results/estimator-physical-refusal-diagnosis-dev-1701"
STUDY = BASE / "study-v15"
DESTINATION = STUDY / "capture-v1"
DISPATCH = BASE / "physical-run-v7-dispatch.json"
COMPLETION = BASE / "physical-run-v7-completion.json"
OUTPUT = BASE / "physical-run-v7-output.txt"
HEAD_FILE = BASE / "current-head-for-physical-v7.txt"
PRECONDITIONS = ROOT / "results/openvins-handoff-physical-attempt-dev-1701/preconditions.json"
PACKAGE_AUDIT = ROOT / "results/openvins-handoff-retry-preflight-dev-1701/study-v15-audit-v4-physical-boundary.json"
STARTUP_AUDIT = ROOT / "results/openvins-handoff-retry-preflight-dev-1701/study-v15-startup-preflight-audit-v2.json"
ARCHIVE = ROOT / "evidence/openvins-handoff-retry-preflight-dev-1701.zip"


def read_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if type(value) is not dict:
        raise ValueError(f"object required: {path}")
    return value


def validate() -> tuple[list[str], dict]:
    head = HEAD_FILE.read_text(encoding="utf-8").strip()
    if head != EXPECTED_HEAD:
        raise ValueError(f"unexpected committed head: {head}")
    pre = read_json(PRECONDITIONS)
    if pre.get("qualified") is not True or pre.get("failures") != [] or pre.get("head") != head:
        raise ValueError("physical preconditions not qualified")
    if any(value is not True for value in pre.get("checks", {}).values()):
        raise ValueError("physical precondition check changed")
    if hashlib.sha256(ARCHIVE.read_bytes()).hexdigest() != EXPECTED_ARCHIVE_SHA256:
        raise ValueError("sealed archive changed")
    package_audit = read_json(PACKAGE_AUDIT)
    startup_audit = read_json(STARTUP_AUDIT)
    if package_audit.get("failures") or package_audit.get("prepare_qualified") is not True:
        raise ValueError("post-startup package audit not qualified")
    if startup_audit.get("failures") or startup_audit.get("startup_preflight_qualified") is not True:
        raise ValueError("startup preflight audit not qualified")
    manifest = read_json(STUDY / "study-manifest.json")
    command = list(manifest.get("command", []))
    expected = DESTINATION.as_posix()
    if manifest.get("future_destination") != expected:
        raise ValueError("manifest destination mismatch")
    if "--output" not in command or command[command.index("--output") + 1] != expected:
        raise ValueError("command destination mismatch")
    if "--startup-preflight" in command:
        raise ValueError("physical command contains startup-preflight")
    existing = [path.as_posix() for path in (DESTINATION, DISPATCH, COMPLETION, OUTPUT) if path.exists()]
    if existing:
        raise FileExistsError(f"refusing existing physical evidence: {existing}")
    resources = active_resources()
    if resources:
        raise RuntimeError(f"active resources before dispatch: {resources!r}")
    return command, {
        "head": head,
        "destination": expected,
        "archive_sha256": EXPECTED_ARCHIVE_SHA256,
        "resources_before": resources,
    }


def write_exclusive(path: Path, value: dict) -> None:
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def main(argv=None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args(argv)
    command, checked = validate()
    if args.check_only:
        print(json.dumps({"schema": "physical-run-v7-check-v1", "qualified": True, **checked}, indent=2))
        return 0
    dispatch = {
        "schema": "estimator-physical-run-dispatch-v3",
        "study": STUDY.as_posix(),
        "destination": checked["destination"],
        "command": command,
        "head": checked["head"],
        "preconditions": PRECONDITIONS.as_posix(),
        "package_audit": PACKAGE_AUDIT.as_posix(),
        "startup_audit": STARTUP_AUDIT.as_posix(),
        "archive": ARCHIVE.as_posix(),
        "archive_sha256": checked["archive_sha256"],
        "resources_before": checked["resources_before"],
        "single_actual_attempt": True,
        "physical_run": True,
        "started_wall_ns": time.time_ns(),
    }
    write_exclusive(DISPATCH, dispatch)
    with OUTPUT.open("xb") as stream:
        completed = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, check=False)
    completion = {
        "schema": "estimator-physical-run-completion-v3",
        "returncode": completed.returncode,
        "destination": checked["destination"],
        "destination_exists": DESTINATION.exists(),
        "resources_after": active_resources(),
        "ended_wall_ns": time.time_ns(),
        "physical_run": True,
    }
    write_exclusive(COMPLETION, completion)
    print(json.dumps(completion, indent=2, sort_keys=True))
    return completed.returncode


if __name__ == "__main__":
    raise SystemExit(main())