"""One bounded, offline rebuild of fixed Agent sources in the pinned Humble image."""

from __future__ import annotations

import ctypes
import json
import subprocess
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
IMAGE = "sha256:a4dae62b38bc01a01d084be7b68db83ec804fef7673604e1a9c986a4baa88a6a"
SOURCE_ROOT = "/tmp/flydrones-agent-offline-1701-v4"
WORK = "/tmp/flydrones-agent-humble-1701-v2"
POLICY = SOURCE_ROOT + "/agent-src/cmake/SuperBuild.cmake"
POLICY_SHA = "9621355850e1095dcd2983a7c3573010453ec4b816350c205bdb32ebf6aaf640"
MIN_FREE = 2 * 1024**3
SAFE_BARE = (
    "android_ifaddrs.git", "asio.git", "fast_cdr_combined.git", "fast_dds.git",
    "foonathan_memory.git", "micro_cdr.git", "spdlog.git", "tinyxml2.git",
    "xrce_client.git",
)
XRCE_CLIENT_COMMIT = "d44dc3fa0c488376e34d26ed92853f1c66dcb670"


class MemoryStatus(ctypes.Structure):
    _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]


def free_bytes() -> int:
    status = MemoryStatus()
    status.dwLength = ctypes.sizeof(status)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
        raise OSError("Windows physical memory query failed")
    return status.ullAvailPhys


def call(args: list[str], timeout: int = 15) -> dict:
    result = subprocess.run(args, capture_output=True, text=True, errors="replace", timeout=timeout)
    return {"args": args, "returncode": result.returncode,
            "stdout": result.stdout, "stderr": result.stderr}


def phase(name: str, memory_mib: int, timeout: int, command: list[str]) -> dict:
    container = "flydrones-agent-humble-" + name + "-v2"
    args = ["wsl", "-d", "Ubuntu", "--", "docker", "run", "--rm", "--name", container,
            "--network", "none", "--cpus", "1", "--memory", str(memory_mib) + "m",
            "--memory-swap", str(memory_mib) + "m", "--pids-limit", "128",
            "--mount", f"type=bind,src={SOURCE_ROOT},dst={SOURCE_ROOT},readonly",
            "--mount", f"type=bind,src={WORK},dst=/work",
            "-e", "GIT_CONFIG_GLOBAL=/work/gitconfig",
            "-e", "GIT_CONFIG_NOSYSTEM=1", "-e", "GIT_ALLOW_PROTOCOL=file",
            "-e", "GIT_TERMINAL_PROMPT=0", "-e", "CMAKE_BUILD_PARALLEL_LEVEL=1",
            "-e", "MAKEFLAGS=-j1", "-e", "HTTPS_PROXY=http://127.0.0.1:9",
            "-e", "HTTP_PROXY=http://127.0.0.1:9", "-e", "ALL_PROXY=http://127.0.0.1:9",
            IMAGE, *command]
    started = time.time_ns()
    timed_out = False
    try:
        result = subprocess.run(args, capture_output=True, timeout=timeout,
                                text=True, errors="replace")
        code, stdout, stderr = result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired as exc:
        timed_out = True
        code = 124
        stdout = (exc.stdout or b"").decode("utf-8", errors="replace") if isinstance(
            exc.stdout, bytes) else (exc.stdout or "")
        stderr = (exc.stderr or b"").decode("utf-8", errors="replace") if isinstance(
            exc.stderr, bytes) else (exc.stderr or "")
    (HERE / f"{name}.stdout").write_text(stdout, encoding="utf-8")
    (HERE / f"{name}.stderr").write_text(stderr, encoding="utf-8")
    observed = call(["docker", "ps", "-a", "--filter", "name=^/" + container + "$",
                     "--format", "{{.ID}}"], timeout=10)
    cleanup = None
    if observed["stdout"].strip():
        cleanup = call(["docker", "rm", "-f", container], timeout=10)
    after = call(["docker", "ps", "-a", "--filter", "name=^/" + container + "$",
                  "--format", "{{.ID}}"], timeout=10)
    return {"command": args, "started_unix_ns": started, "ended_unix_ns": time.time_ns(),
            "exit_code": code, "timeout": timed_out, "observed_after": observed,
            "cleanup": cleanup, "owned_container_after": after}


def main() -> None:
    if (HERE / "run-result.json").exists() or (HERE / "preflight.json").exists():
        raise FileExistsError("build attempt already recorded")
    start_free = free_bytes()
    docker = call(["docker", "ps", "--format", "{{.Names}}"])
    image = call(["docker", "image", "inspect", IMAGE, "--format", "{{.Id}}"])
    source = call(["wsl", "-d", "Ubuntu", "--", "sha256sum", POLICY])
    absent = call(["wsl", "-d", "Ubuntu", "--", "test", "!", "-e", WORK])
    okay = (start_free >= MIN_FREE and docker["returncode"] == 0
            and not docker["stdout"].strip() and image["returncode"] == 0
            and image["stdout"].strip() == IMAGE and source["returncode"] == 0
            and source["stdout"].split()[:2] == [POLICY_SHA, POLICY]
            and absent["returncode"] == 0)
    preflight = {"schema": "flydrones.agent_humble_offline_build_preflight.v1",
                 "observed_unix_ns": time.time_ns(), "host_available_bytes": start_free,
                 "minimum_bytes": MIN_FREE, "docker": docker, "image": image,
                 "source": source, "work_absent": absent, "qualified": okay}
    (HERE / "preflight.json").write_text(json.dumps(preflight, indent=2), encoding="utf-8")
    if not okay:
        print(json.dumps({"status": "preflight_refused", "free_bytes": start_free}))
        return
    create = call(["wsl", "-d", "Ubuntu", "--", "mkdir", WORK])
    if create["returncode"] != 0:
        raise RuntimeError("owned work directory creation failed: " + create["stderr"])
    outcome = {"schema": "flydrones.agent_humble_offline_build.v1",
               "preflight_qualified": True, "owned_work": WORK,
               "source_readonly": True, "network_disabled": True,
               "safe_bare": [SOURCE_ROOT + "/" + name for name in SAFE_BARE],
               "prepare": [], "git_preflight": None,
               "configure": None, "build": None, "build_success": False,
               "xrce_session_verified": False, "dds_discovery_verified": False,
               "px4_source_authenticated": False, "fusion_qualified": False}
    try:
        copy = call(["wsl", "-d", "Ubuntu", "--", "cp",
                     SOURCE_ROOT + "/gitconfig", WORK + "/gitconfig"])
        outcome["prepare"].append(copy)
        if copy["returncode"] != 0:
            raise RuntimeError("local Git config copy failed")
        for name in SAFE_BARE:
            added = call(["wsl", "-d", "Ubuntu", "--", "git", "config", "--file",
                          WORK + "/gitconfig", "--add", "safe.directory",
                          SOURCE_ROOT + "/" + name])
            outcome["prepare"].append(added)
            if added["returncode"] != 0:
                raise RuntimeError("explicit safe.directory registration failed: " + name)
        selected = call(["wsl", "-d", "Ubuntu", "--", "git", "config", "--file",
                         WORK + "/gitconfig", "--get-all", "safe.directory"])
        outcome["safe_directory_selection"] = selected
        if (selected["returncode"] != 0 or selected["stdout"].splitlines()
                != outcome["safe_bare"]):
            raise RuntimeError("safe.directory selection changed")
        outcome["git_preflight"] = phase("git-preflight", 256, 30, [
            "git", "--git-dir", SOURCE_ROOT + "/xrce_client.git", "rev-parse", "HEAD"])
        if (outcome["git_preflight"]["exit_code"] != 0
                or (HERE / "git-preflight.stdout").read_text().strip() != XRCE_CLIENT_COMMIT):
            raise RuntimeError("pinned XRCE client object cannot be read in container")
        outcome["configure"] = phase("configure", 512, 180, [
            "cmake", "-S", SOURCE_ROOT + "/agent-src", "-B", "/work/build",
            "-G", "Unix Makefiles", "-DCMAKE_BUILD_TYPE=Release",
            "-DUAGENT_SUPERBUILD=ON", "-DUAGENT_BUILD_TESTS=OFF"])
        if outcome["configure"]["exit_code"] == 0:
            outcome["build"] = phase("build", 1024, 1500, [
                "cmake", "--build", "/work/build", "--parallel", "1"])
            outcome["build_success"] = outcome["build"]["exit_code"] == 0
    except Exception as exc:
        outcome["error"] = repr(exc)
    finally:
        outcome["source_after"] = call(["wsl", "-d", "Ubuntu", "--", "sha256sum", POLICY])
        outcome["docker_after"] = call(["docker", "ps", "--format", "{{.Names}}"])
        (HERE / "run-result.json").write_text(json.dumps(outcome, indent=2), encoding="utf-8")
    print(json.dumps({"configure_exit": outcome["configure"]["exit_code"]
                      if outcome["configure"] else None,
                      "build_exit": outcome["build"]["exit_code"] if outcome["build"] else None,
                      "work": WORK, "build_success": outcome["build_success"],
                      "error": outcome.get("error")}))


if __name__ == "__main__":
    main()
