"""Read-only ABI and lifecycle checks for the fixed Humble Agent build."""

from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
IMAGE = "sha256:a4dae62b38bc01a01d084be7b68db83ec804fef7673604e1a9c986a4baa88a6a"
WORK = "/tmp/flydrones-agent-humble-1701-v3"
SOURCE = "/tmp/flydrones-agent-offline-1701-v4"
BUILD = "/work/build"
ARTIFACTS = {
    "agent": f"{BUILD}/MicroXRCEAgent",
    "agent_lib": f"{BUILD}/libmicroxrcedds_agent.so.2.4.3",
    "fastdds": f"{BUILD}/temp_install/fastrtps-2.14/lib/libfastrtps.so.2.14.7",
    "fastcdr": f"{BUILD}/temp_install/fastcdr-2.2.0/lib/libfastcdr.so.2.2.8",
    "xrce_client": f"{BUILD}/temp_install/microxrcedds_client-2.4.3/lib/libmicroxrcedds_client.so.2.4.3",
    "microcdr": f"{BUILD}/temp_install/microcdr-2.0.1/lib/libmicrocdr.so.2.0.1",
}
SOURCES = {
    "xrce_client": f"{BUILD}/microxrcedds_client/src/microxrcedds_client",
    "microcdr": f"{BUILD}/microxrcedds_client/src/microxrcedds_client-build/microcdr/src/microcdr",
    "fastcdr": f"{BUILD}/fastcdr/src/fastcdr",
    "fastdds": f"{BUILD}/fastdds/src/fastdds",
    "foonathan": f"{BUILD}/foonathan_memory/src/foonathan_memory",
    "spdlog": f"{BUILD}/spdlog/src/spdlog",
}


def run(label: str, command: list[str], timeout: int = 20) -> dict:
    args = ["wsl", "-d", "Ubuntu", "--", "docker", "run", "--rm", "--network", "none",
            "--cpus", "1", "--memory", "512m", "--memory-swap", "512m",
            "--name", f"flydrones-agent-humble-audit-{label}-v3",
            "--mount", f"type=bind,src={WORK},dst=/work,readonly",
            "--mount", f"type=bind,src={SOURCE},dst={SOURCE},readonly",
            IMAGE, *command]
    result = subprocess.run(args, text=True, errors="replace", capture_output=True, timeout=timeout)
    (HERE / f"audit-{label}.stdout").write_text(result.stdout, encoding="utf-8")
    (HERE / f"audit-{label}.stderr").write_text(result.stderr, encoding="utf-8")
    return {"args": args, "returncode": result.returncode,
            "stdout_file": f"audit-{label}.stdout", "stderr_file": f"audit-{label}.stderr"}


def main() -> None:
    output = HERE / "audit-result.json"
    if output.exists():
        raise FileExistsError(output)
    build = json.loads((HERE / "run-result.json").read_text(encoding="utf-8"))
    if not build["build_success"] or build["build"]["exit_code"] != 0:
        raise RuntimeError("build did not succeed")
    result: dict = {"schema": "flydrones.agent_humble_abi_audit.v1",
                    "build_success": True, "image": IMAGE, "work": WORK,
                    "artifacts": ARTIFACTS, "sources": SOURCES,
                    "observations": {}, "verified": False,
                    "xrce_session_verified": False, "dds_discovery_verified": False,
                    "px4_source_authenticated": False}
    try:
        result["observations"]["file"] = run("file", ["file", *ARTIFACTS.values()])
        result["observations"]["hashes"] = run(
            "hashes", ["sha256sum", *ARTIFACTS.values(),
                        f"{SOURCE}/agent-src/cmake/SuperBuild.cmake"])
        for key, path in SOURCES.items():
            result["observations"][f"git_{key}"] = run(
                f"git-{key}", ["git", "-C", path, "rev-parse", "HEAD"])
        result["observations"]["fastdds_submodules"] = run(
            "submodules", ["git", "-C", SOURCES["fastdds"], "submodule", "status"])
        for key, path in ARTIFACTS.items():
            result["observations"][f"ldd_{key}"] = run(f"ldd-{key}", ["ldd", path])
            result["observations"][f"version_{key}"] = run(
                f"version-{key}", ["readelf", "--version-info", path])
        result["observations"]["help"] = run(
            "help", [ARTIFACTS["agent"], "--help"])
        result["observations"]["listener"] = run(
            "listener", ["timeout", "--signal=TERM", "--kill-after=2", "3",
                         ARTIFACTS["agent"], "udp4", "-p", "18891", "-m", "dds"],
            timeout=15)
        result["observations"]["container_after"] = {
            "args": ["docker", "ps", "-a", "--filter", "name=flydrones-agent-humble-audit-",
                     "--format", "{{.Names}}"],
        }
        remaining = subprocess.run(result["observations"]["container_after"]["args"],
                                   capture_output=True, text=True, errors="replace", timeout=10)
        result["observations"]["container_after"].update(
            {"returncode": remaining.returncode, "stdout": remaining.stdout,
             "stderr": remaining.stderr})
        versions: dict[str, list[str]] = {}
        for key in ARTIFACTS:
            data = (HERE / f"audit-version-{key}.stdout").read_text(encoding="utf-8")
            versions[key] = sorted(set(re.findall(r"GLIBC_\d+\.\d+", data)))
        result["glibc_versions"] = versions
        result["max_glibc"] = max(
            (tuple(map(int, s.removeprefix("GLIBC_").split(".")))
             for values in versions.values() for s in values), default=(0, 0))
        ldd_ok = all(
            "not found" not in (HERE / f"audit-ldd-{key}.stdout").read_text()
            and result["observations"][f"ldd_{key}"]["returncode"] == 0
            for key in ARTIFACTS)
        required_ok = all(
            result["observations"][name]["returncode"] == 0
            for name in ["file", "hashes", *[f"git_{key}" for key in SOURCES],
                         "fastdds_submodules", *[f"version_{key}" for key in ARTIFACTS]])
        help_text = (HERE / "audit-help.stdout").read_text(encoding="utf-8")
        help_ok = "Usage:" in help_text and "udp4" in help_text
        result["verified"] = (required_ok and ldd_ok and help_ok
                              and result["max_glibc"] <= (2, 35)
                              and not remaining.stdout.strip())
    except Exception as exc:
        result["error"] = repr(exc)
    finally:
        output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({"verified": result["verified"],
                      "max_glibc": result.get("max_glibc"),
                      "listener_exit": result["observations"].get("listener", {}).get("returncode"),
                      "error": result.get("error")}))


if __name__ == "__main__":
    main()
