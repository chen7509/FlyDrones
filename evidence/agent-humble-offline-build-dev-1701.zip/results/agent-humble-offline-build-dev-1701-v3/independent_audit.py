"""Independently audit the frozen build, ABI logs, and preserved runtime bundle."""

from __future__ import annotations

import hashlib
import json
import subprocess
import tarfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
RESULT = HERE / "independent-audit.json"
EXPECTED_COMMITS = {
    "xrce_client": "d44dc3fa0c488376e34d26ed92853f1c66dcb670",
    "microcdr": "3d1b17703c7cf4f22def2910bc845bdb5152d7b5",
    "fastcdr": "757d5e422253568c487ad97c22e44680fc1ddbaf",
    "fastdds": "575d045b55c16be1074ccd9eebf95e3e4274fe61",
}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    if RESULT.exists():
        raise FileExistsError(RESULT)
    build = json.loads((HERE / "run-result.json").read_text(encoding="utf-8"))
    abi = json.loads((HERE / "audit-v3-result.json").read_text(encoding="utf-8"))
    preflight = json.loads((HERE / "preflight.json").read_text(encoding="utf-8"))
    issues: list[str] = []
    if not (preflight["qualified"] and build["preflight_qualified"]
            and build["configure"]["exit_code"] == 0
            and build["build"]["exit_code"] == 0 and build["build_success"]):
        issues.append("preflight/configure/build not all successful")
    if build["source_after"]["stdout"].split()[0] != preflight["source"]["stdout"].split()[0]:
        issues.append("source policy changed")
    if build["docker_after"]["stdout"].strip() or not abi["verified"]:
        issues.append("build container not released or ABI audit failed")
    if tuple(abi["max_glibc"]) > (2, 35):
        issues.append("glibc requirement exceeds Humble image")
    hashes = {}
    for line in (HERE / "audit-v3-hashes.stdout").read_text(encoding="utf-8").splitlines():
        if line.strip():
            value, path = line.split(maxsplit=1)
            hashes[path.strip()] = value
    bundle = HERE / "runtime-bundle.tar.gz"
    if not bundle.is_file():
        issues.append("runtime bundle absent")
        bundle_members = {}
    else:
        with tarfile.open(bundle, "r:gz") as archive:
            bundle_members = {}
            for key, source in abi["artifacts"].items():
                name = source.removeprefix("/work/build/")
                item = archive.getmember(name)
                if not item.isfile():
                    issues.append(f"bundle artifact is not regular: {key}")
                    continue
                raw = archive.extractfile(item).read()
                bundle_members[key] = {"path": name, "sha256": digest(raw), "size": len(raw)}
                if digest(raw) != hashes.get(source):
                    issues.append(f"bundle hash mismatch: {key}")
    for key, expected in EXPECTED_COMMITS.items():
        actual = (HERE / f"audit-v3-git-{key}.stdout").read_text(encoding="utf-8").strip()
        if actual != expected:
            issues.append(f"fixed source commit mismatch: {key}")
    help_text = (HERE / "audit-v3-help.stdout").read_text(encoding="utf-8")
    listener_text = (HERE / "audit-v3-listener.stdout").read_text(encoding="utf-8")
    if not ("Usage:" in help_text and "udp4" in help_text
            and "running..." in listener_text and "18891" in listener_text
            and abi["observations"]["listener"]["returncode"] == 124):
        issues.append("bounded Agent startup not evidenced")
    for name in ("agent-humble-offline-build-dev-1701", "agent-humble-offline-build-dev-1701-v2"):
        path = HERE.parent / name / "run-result.json"
        if not path.exists():
            issues.append(f"prior failed attempt missing: {name}")
    observed = subprocess.run(
        ["docker", "ps", "-a", "--filter", "name=flydrones-agent-humble-",
         "--format", "{{.Names}}"], capture_output=True, text=True, timeout=10)
    if observed.returncode != 0 or observed.stdout.strip():
        issues.append("owned Docker container still present")
    report = {"schema": "flydrones.agent_humble_independent_audit.v1",
              "build_qualified": not issues,
              "issues": issues,
              "build_artifact_hashes": hashes,
              "bundle_sha256": digest(bundle.read_bytes()) if bundle.exists() else None,
              "bundle_members": bundle_members,
              "fixed_commits": EXPECTED_COMMITS,
              "max_glibc": abi["max_glibc"],
              "listener_exit": abi["observations"]["listener"]["returncode"],
              "owned_containers": observed.stdout.splitlines(),
              "xrce_session_verified": False,
              "dds_discovery_verified": False,
              "px4_source_authenticated": False,
              "fusion_qualified": False}
    RESULT.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({"qualified": report["build_qualified"],
                      "bundle_sha256": report["bundle_sha256"], "issues": issues}))


if __name__ == "__main__":
    main()
