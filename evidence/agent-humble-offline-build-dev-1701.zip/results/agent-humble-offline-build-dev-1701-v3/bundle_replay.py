"""Bounded loader and listener checks from the preserved runtime bundle."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
IMAGE = "sha256:a4dae62b38bc01a01d084be7b68db83ec804fef7673604e1a9c986a4baa88a6a"
EXTRACTED = "/tmp/flydrones-agent-humble-bundle-1701-v1"
OUT = HERE / "bundle-replay-result.json"


def call(name: str, args: list[str]) -> dict:
    command = ["wsl", "-d", "Ubuntu", "--", "docker", "run", "--rm",
               "--name", f"flydrones-agent-bundle-{name}-v1",
               "--network", "none", "--cpus", "1", "--memory", "512m",
               "--memory-swap", "512m",
               "--mount", f"type=bind,src={EXTRACTED},dst=/work/build,readonly",
               IMAGE, *args]
    run = subprocess.run(command, capture_output=True, text=True,
                         errors="replace", timeout=20)
    (HERE / f"bundle-{name}.stdout").write_text(run.stdout, encoding="utf-8")
    (HERE / f"bundle-{name}.stderr").write_text(run.stderr, encoding="utf-8")
    return {"command": command, "returncode": run.returncode}


def main() -> None:
    if OUT.exists():
        raise FileExistsError(OUT)
    ldd = call("ldd", ["ldd", "/work/build/MicroXRCEAgent"])
    help_ = call("help", ["/work/build/MicroXRCEAgent", "--help"])
    listener = call("listener", ["timeout", "--signal=TERM", "--kill-after=2", "3",
                                 "/work/build/MicroXRCEAgent", "udp4", "-p", "18892",
                                 "-m", "dds"])
    observed = subprocess.run(
        ["docker", "ps", "-a", "--filter", "name=flydrones-agent-bundle-",
         "--format", "{{.Names}}"], capture_output=True, text=True, timeout=10)
    ok = (ldd["returncode"] == 0
          and "not found" not in (HERE / "bundle-ldd.stdout").read_text()
          and "Usage:" in (HERE / "bundle-help.stdout").read_text()
          and listener["returncode"] == 124
          and "running..." in (HERE / "bundle-listener.stdout").read_text()
          and "18892" in (HERE / "bundle-listener.stdout").read_text()
          and observed.returncode == 0 and not observed.stdout.strip())
    result = {"schema": "flydrones.agent_humble_bundle_replay.v1",
              "image": IMAGE, "extracted": EXTRACTED, "ldd": ldd,
              "help": help_, "listener": listener,
              "owned_containers_after": observed.stdout.splitlines(),
              "qualified": ok, "xrce_session_verified": False,
              "dds_discovery_verified": False}
    OUT.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({"qualified": ok, "listener_exit": listener["returncode"]}))


if __name__ == "__main__":
    main()
