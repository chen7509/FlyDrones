"""Seal the fixed offline build, failed attempts, and ABI/bundle evidence."""

from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
ARCHIVE = ROOT / "evidence/agent-humble-offline-build-dev-1701.zip"
MANIFEST = HERE / "manifest.json"
FOLDERS = (
    ROOT / "results/agent-humble-offline-build-dev-1701",
    ROOT / "results/agent-humble-offline-build-dev-1701-v2",
    HERE,
)


def main() -> None:
    if ARCHIVE.exists() or MANIFEST.exists():
        raise FileExistsError("evidence already exists; refuse overwrite")
    members = [
        ROOT / "docs/superpowers/specs/2026-10-12-agent-humble-rebuild-design.md",
        ROOT / "docs/superpowers/plans/2026-10-12-agent-humble-rebuild.md",
        ROOT / "docs/AGENT_HUMBLE_OFFLINE_BUILD_REPORT.md",
    ]
    for folder in FOLDERS:
        members.extend(path for path in folder.iterdir() if path.is_file())
    members = sorted(set(members), key=lambda path: path.relative_to(ROOT).as_posix())
    manifest = {
        path.relative_to(ROOT).as_posix(): {
            "size": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        }
        for path in members
    }
    MANIFEST.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    with zipfile.ZipFile(ARCHIVE, "x", zipfile.ZIP_DEFLATED) as bundle:
        for path in [*members, MANIFEST]:
            bundle.write(path, path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(ARCHIVE) as bundle:
        assert bundle.testzip() is None
        assert set(bundle.namelist()) == set(manifest) | {MANIFEST.relative_to(ROOT).as_posix()}
        for name, item in manifest.items():
            raw = bundle.read(name)
            assert len(raw) == item["size"]
            assert hashlib.sha256(raw).hexdigest() == item["sha256"]
    print(json.dumps({"archive": str(ARCHIVE), "members": len(manifest) + 1,
                      "sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()}))


if __name__ == "__main__":
    main()
