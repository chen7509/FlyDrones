from pathlib import Path
p=Path('tools/benchmark/capture_contract.py');s=p.read_text().replace("    if binding_path is not None and Path(binding_path).is_file():","    if (getattr(args, 'capture_profile', None) == 'target-bearing-raw-v1'\n            and binding_path is not None and Path(binding_path).is_file()):",1);p.write_text(s)
