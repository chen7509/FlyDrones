from pathlib import Path
p=Path('tests/benchmark/test_native_entry_context_v3.py');s=p.read_text();s=s.replace('    from tools.benchmark.native_entry_context_v3 import collect_python_context as collector\n','');s=s.replace('    from importlib.machinery import ExtensionFileLoader\n','    from tools.benchmark.native_entry_context_v3 import collect_python_context as collector\n    from importlib.machinery import ExtensionFileLoader\n',1)
s+='''

@pytest.mark.parametrize("fault", ["timeout", "cap", "partial", "mutation", "postcontext"])
def test_new_producer_retains_protocol_failures(tmp_path, monkeypatch, fault):
    m,p,c,e,_,run=fixture(tmp_path,monkeypatch)
    target=e['current-python'][0]
    def protocol(argv,env):
        row=run(argv,env)
        if argv[0]==str(p['ldd']) and argv[-1]==target:
            if fault=='timeout':row.update(error='fixture TimeoutExpired',exit=-15,cleanup=dict(exit=-15,descendants='unknown'))
            if fault=='cap':row['output_limit_exceeded']=True
            if fault=='partial':row['reader_complete']=False
            if fault=='mutation':Path(target).write_bytes(b'changed fixture input')
            if fault=='postcontext':monkeypatch.setattr(m,'collect_python_context',lambda:dict(c,modules=[]))
        return row
    monkeypatch.setattr(m,'_run_tool',protocol)
    with pytest.raises(ValueError):produce(m,p,c,e,tmp_path/'bill')
    saved=json.loads((tmp_path/'bill/entry-bill.json').read_bytes())
    assert saved['complete'] is False and saved['error'] and saved['queries']
    assert saved['entries'][-1]['ldd_query']==len(saved['queries'])
    if fault=='postcontext':assert saved['observed_context_after']['modules']==[]


def test_query_writer_preserves_primary_and_partial_aggregate(tmp_path,monkeypatch):
    m,p,c,e,_,run=fixture(tmp_path,monkeypatch)
    writer=m.write_manifest
    def protocol(argv,env):
        row=run(argv,env)
        row['reader_complete']=False
        return row
    def failing(path,data):
        if Path(path).name.startswith('query-'):raise OSError('fixture journal writer')
        return writer(path,data)
    monkeypatch.setattr(m,'_run_tool',protocol)
    monkeypatch.setattr(m,'write_manifest',failing)
    with pytest.raises(ValueError,match='partial') as caught:produce(m,p,c,e,tmp_path/'bill')
    saved=json.loads((tmp_path/'bill/entry-bill.json').read_bytes())
    assert 'fixture journal writer' in saved['queries'][0]['journal_error']
    assert 'partial' in saved['error'] and caught.value.__notes__
'''
p.write_text(s)
p=Path('tools/benchmark/native_entry_context_v3.py');s=p.read_text().replace('        if re.search(pattern, text, re.MULTILINE) is None:','        if len(re.findall(pattern, text, re.MULTILINE)) != 1:',1).replace('    header_count = re.search(', '    if len(re.findall(r"^\\s*Number of program headers:", text, re.MULTILINE)) != 1:\n        raise ValueError("unique program header count required")\n    header_count = re.search(',1);p.write_text(s)
