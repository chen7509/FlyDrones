from pathlib import Path
p=Path('tests/benchmark/test_calibration_capture_study_v3.py');s=p.read_text()+'''

def test_legacy_contract_does_not_read_binding_for_new_raw_context(tmp_path):
    from tools.benchmark import capture_contract as contract
    from tools.benchmark.capture_disarmed_sensors import parse_capture_args
    args=parse_capture_args(['--output',str(tmp_path/'capture')])
    bound=tmp_path/'binding.json'
    bound.write_text('not a binding document')
    args.runtime_binding=bound
    assert 'python_extension_context' not in contract.execution_contract(args)
''';p.write_text(s)
