from pathlib import Path
p=Path('tests/benchmark/test_native_entry_context_v3.py');s=p.read_text()+'''

@pytest.mark.parametrize('extra',[b'  Type: EXEC (Executable file)\\n',b'  Class: ELF32\\n',b'  Machine: AArch64\\n'])
def test_conflicting_elf_header_labels_refuse(tmp_path,monkeypatch,extra):
    m,p,c,e,_,run=fixture(tmp_path,monkeypatch)
    def protocol(argv,env):
        row=run(argv,env)
        if argv[1]=='-W':row['stdout_hex']=bytes.fromhex(row['stdout_hex']).replace(b'Program Headers:',extra+b'Program Headers:').hex()
        return row
    monkeypatch.setattr(m,'_run_tool',protocol)
    with pytest.raises(ValueError,match='header'):produce(m,p,c,e,tmp_path/'bill')
''';p.write_text(s)
