import hashlib
from pathlib import Path

root=Path.cwd()
p=root/'tools/benchmark/calibration_capture_study_v2.py';data=p.read_bytes();s=data.decode()
s=s.replace('v2','v3').replace('from tools.benchmark.native_entry_dependencies import audit_entry_bill','from tools.benchmark.native_entry_context_v3 import audit_entry_context_bill, context_digest, declared_python_context')
s=s.replace('        entry_bill=FOLDER / "sdk/entry-dependencies/entry-bill.json",','        entry_bill=FOLDER / "sdk/entry-dependencies/entry-bill.json",\n        python_context=FOLDER / "sdk/python-context.json",')
s=s.replace('    if (\n        preparation.get("schema")','    context_record = declared_python_context(binding)\n    if context_record is None:\n        raise ValueError("v3 preparation requires declared Python context")\n    context = read_declaration(context_record["file"]["requested"])\n    if preparation.get("python_context_file_sha256") != context_record["file"]["sha256"] or preparation.get("python_context_sha256") != context_digest(context):\n        raise ValueError("preparation Python context digest differs")\n    if (\n        preparation.get("schema")')
s=s.replace('{"entry_bill_sha256", "query_clocks"}', '{"entry_bill_sha256", "query_clocks", "python_context_file_sha256", "python_context_sha256"}')
s=s.replace('    return dict(graph, **audit_entry_bill(bill, binding["baseline"]["files"]))','''    required = {p for entry in bill["entries"] for p in [entry["file"]["requested"], *entry["selected"]]}
    if not required.issubset(set(binding["inventory"].get("graph:dependencies", []))):
        raise ValueError("entry self/dependency membership missing from graph dependencies")
    baseline = {r["requested"]:{k:v for k,v in r.items() if k != "role"} for r in binding["baseline"]["files"]}
    for number, query in enumerate(bill["queries"], 1):
        path = Path(bill_path).parent / f"query-{number:04d}.json"
        if not _typed_equal(file_record(path), baseline.get(str(path))) or not _typed_equal(read_declaration(path), query):
            raise ValueError("entry query artifact baseline/raw join differs")
    return dict(graph, **audit_entry_context_bill(bill, baseline_files=binding["baseline"]["files"], python_context=context))''')
s=s.replace('v3=True','v3=True') # distinct shared parameter added separately
s=s.replace('\ndef paths():','\ndef digest(path):\n    return hashlib.sha256(Path(path).read_bytes()).hexdigest()\n\n\ndef paths():')
target=root/'tools/benchmark/calibration_capture_study_v3.py';assert not target.exists();target.write_text(s,encoding='utf8',newline='\n')
p=root/'tools/benchmark/prepare_calibration_capture_v2.py';s=p.read_text()
s=s.replace('v2','v3').replace('from tools.benchmark.native_entry_dependencies import BASE_ENV, _run_tool, discover_entry_dependencies','from tools.benchmark.native_entry_context_v3 import BASE_ENV, _run_tool, discover_entry_context, collect_python_context, context_digest')
s=s.replace('        bill = discover_entry_dependencies(\n            entries, candidates, loader_paths, agent_configuration["lib_dir"], sdk / "entry-dependencies"\n        )','''        python_context = collect_python_context()
        write_manifest(sdk / "python-context.json", python_context)
        bill = discover_entry_context(
            entries, candidates, python_context, loader_paths, agent_configuration["lib_dir"], sdk / "entry-dependencies"
        )''')
s=s.replace('        add("graph:dependencies", [p for entry in bill["entries"] for p in entry["selected"]])','''        add("graph:dependencies", [p for entry in bill["entries"] for p in [entry["file"]["requested"], *entry["selected"]]])
        add("runtime:python-extension-context", [sdk / "python-context.json"])
        add("runtime:entry-context-artifacts", sorted((sdk / "entry-dependencies").glob("query-*.json")))''')
s=s.replace('        write_manifest(FOLDER / "runtime-binding-v4.json", binding)\n        write_manifest(FOLDER / "execution-contract.json", contract)','''        write_manifest(FOLDER / "runtime-binding-v4.json", binding)
        # The final contract now binds actual context bytes via the newly written
        # binding; the earlier contract supplied only Agent/logger selection.
        contract = execution_contract(args, env)
        write_manifest(FOLDER / "execution-contract.json", contract)''')
s=s.replace('            schema="raw-static-sdk-preparation-v3",','''            schema="raw-static-sdk-preparation-v3",
            python_context_file_sha256=file_record(sdk / "python-context.json")["sha256"],
            python_context_sha256=context_digest(python_context),''')
target=root/'tools/benchmark/prepare_calibration_capture_v3.py';assert not target.exists();target.write_text(s,encoding='utf8',newline='\n')
print('distinct v3 source created; v2 files unchanged')
