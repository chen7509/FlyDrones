from pathlib import Path
p=Path('tools/benchmark/native_entry_context_v3.py');s=p.read_text()
s=s.replace('    programs = text.split', '''    header_count = re.search(r"^\\s*Number of program headers:\\s*([0-9]+)\\s*$", text, re.MULTILINE)
    if header_count is None or not 1 <= int(header_count[1]) <= 65536:
        raise ValueError("complete program header count required")
    programs = text.split''',1)
a=s.index('    if len(re.findall(r"^\\s*DYNAMIC');b=s.index('    match = re.search',a)
s=s[:a]+'''    program_rows = []
    for line in programs.splitlines():
        if not line.strip() or line.strip().startswith("Type "):
            continue
        parts = line.split()
        if len(parts) not in (8, 9) or not re.fullmatch(r"[A-Z_0-9]+", parts[0]):
            raise ValueError("malformed program header row")
        if any(not re.fullmatch(r"(?:0x)?[0-9a-fA-F]+", v) for v in [*parts[1:6], parts[-1]]):
            raise ValueError("invalid program header numeric fields")
        flags = "".join(parts[6:-1])
        if not flags or any(c not in "RWE" for c in flags):
            raise ValueError("invalid program header flags")
        program_rows.append(dict(type=parts[0], offset=parts[1], virtual=parts[2], physical=parts[3],
                                 file_size=parts[4], memory_size=parts[5], flags=flags, align=parts[-1]))
    kinds = [r["type"] for r in program_rows]
    if len(program_rows) != int(header_count[1]) or "LOAD" not in kinds or kinds.count("DYNAMIC") != 1 or "INTERP" in kinds:
        raise ValueError("complete extension program headers require LOAD/PT_DYNAMIC and no PT_INTERP")
'''+s[b:]
s=s.replace('        pt_dynamic=True,','        program_headers=program_rows,\n        pt_dynamic=True,',1)
s=s.replace('def audit_python_runtime(expected, raw_maps, phase):','''def audit_python_runtime(expected, raw_maps, phase):
    current = None
    try:
        current = collect_python_context()
        return _audit_python_runtime_context(expected, current, raw_maps, phase)
    except Exception as exc:
        exc.observed_python_context = current
        raise


def _audit_python_runtime_context(expected, current, raw_maps, phase):''',1)
s=s.replace('    current = collect_python_context()\n    validate_python_context(current)','    validate_python_context(current)',1)
s=s.replace('        static_context_pid=expected["pid"],','        observed_context=current,\n        static_context_pid=expected["pid"],',1)
s=s.replace('        python_context_sha256=context_digest(python_context),','        python_context_sha256=context_digest(python_context),\n        observed_context_before=None,\n        observed_context_after=None,',1)
s=s.replace('        validate_python_context(python_context)\n        for module', '''        validate_python_context(python_context)
        bill["observed_context_before"] = collect_python_context()
        validate_python_context(bill["observed_context_before"])
        if not _typed_equal(bill["observed_context_before"], python_context):
            raise ValueError("current SDK Python context differs from requested context")
        for module''',1)
s=s.replace('                dynamic = invoke("dynamic",','                row["dynamic_query"] = len(bill["queries"]) + 1\n                dynamic = invoke("dynamic",',1)
s=s.replace('        bill["complete"] = True','''        bill["observed_context_after"] = collect_python_context()
        validate_python_context(bill["observed_context_after"])
        if not _typed_equal(bill["observed_context_after"], python_context):
            raise ValueError("current SDK Python context changed during dependency discovery")
        bill["complete"] = True''',1)
s=s.replace('        "python_context_sha256",','        "python_context_sha256",\n        "observed_context_before",\n        "observed_context_after",',1)
s=s.replace('    files = {r["requested"]: r for r in bill["files"]}','''    for key in ("observed_context_before", "observed_context_after"):
        validate_python_context(bill[key])
        if not _typed_equal(bill[key], python_context):
            raise ValueError("observed current SDK context join differs")
    files = {r["requested"]: r for r in bill["files"]}''',1)
s=s.replace('    tools = bill["tools_before"]','''    if (type(bill["agent_paths"]) is not list or len(set(bill["agent_paths"])) != len(bill["agent_paths"])
            or not set(bill["agent_paths"]).issubset({p for _, p in expected_entries})):
        raise ValueError("Agent paths must be unique selected entries")
    _absolute(bill["agent_lib"])
    tools = bill["tools_before"]''',1)
p.write_text(s)
p=Path('tools/benchmark/runtime_resource_binding.py');s=p.read_text();s=s.replace("observed['error'] = repr(exc)\n                    raise","observed['error'] = repr(exc)\n                    observed['observed_context'] = getattr(exc, 'observed_python_context', None)\n                    raise",1);p.write_text(s)
p=Path('tools/benchmark/calibration_capture_study_v3.py');s=p.read_text().replace('    context_record = declared_python_context(binding)','    if not _typed_equal(read_declaration(bill_path), bill):\n        raise ValueError("actual entry bill bytes differ from supplied bill")\n    context_record = declared_python_context(binding)',1).replace('dependency_code=ROOT / "tools/benchmark/native_entry_dependencies.py"','dependency_code=ROOT / "tools/benchmark/native_entry_context_v3.py"');p.write_text(s)
p=Path('tests/benchmark/test_native_entry_context_v3.py');s=p.read_text().replace('X86-64\\nProgram Headers:','X86-64\\n  Number of program headers: 2\\nProgram Headers:');needle='    m, p, c, e, _, _ = fixture(tmp_path, monkeypatch)\n    target =';s=s.replace(needle,'    from tools.benchmark.native_entry_context_v3 import collect_python_context as collector\n    m, p, c, e, _, _ = fixture(tmp_path, monkeypatch)\n    target =',1).replace('    observed=m.collect_python_context()','    observed=collector()',1);p.write_text(s)
