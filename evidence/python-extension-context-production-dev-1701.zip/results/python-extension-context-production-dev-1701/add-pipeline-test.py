from pathlib import Path

root=Path.cwd();old=(root/'tests/benchmark/test_calibration_study_v2.py').read_text()
s=old.split('def test_actual_prepare_v2_pipeline_reaches_real_binding_role_guard',1)[1].split('\ndef test_paired_clock_hash_failure',1)[0]
s='\n\ndef test_actual_prepare_v3_pipeline_keeps_empty_selection_self_and_context'+s
s=s.replace('calibration_capture_study_v2','calibration_capture_study_v3').replace('    m = api()','    m = importlib.import_module("tools.benchmark.prepare_calibration_capture_v3")')
s=s.replace('    def record(path):','    from tools.benchmark.declared_runtime_snapshot import file_record as real_record\n\n    def record(path):')
s=s.replace('        data = path.read_bytes() if path.is_file() else b"fixture-unavailable-native-input"','        if path.is_file():\n            return real_record(path)\n        data = b"fixture-unavailable-native-input"')
s=s.replace('    def bill(*args):','''    context = dict(schema="python-extension-context-v1",pid=123,interpreter=record('/usr/bin/python3'),implementation='cpython',version='fixture3.12.3',version_info=[3,12,3],soabi='cpython-312-x86_64-linux-gnu',ext_suffix='.cpython-312-x86_64-linux-gnu.so',dlopen_flags=2,modules=[])
    monkeypatch.setattr(m,'collect_python_context',lambda:context)

    def bill(*args):''')
s=s.replace('return {"files": [record(dependency)], "entries": [{"selected": [str(dependency)]}]}','return {"files": [record(dependency)], "entries": [{"file":record(dependency), "selected": []}]}')
s=s.replace('"discover_entry_dependencies"','"discover_entry_context"').replace('audit_v2_preparation','audit_v3_preparation').replace('publish_study_v2','publish_study_v3').replace('m.prepare_v2','m.prepare_v3')
s=s.replace('    assert binding["inventory"]["graph:dependencies"] == [str(dependency)]','''    assert binding["inventory"]["graph:dependencies"] == [str(dependency)]
    assert binding['inventory']['runtime:python-extension-context']==[str(out/'frozen/sdk/python-context.json')]
    assert binding['inventory']['runtime:entry-context-bill']==[str(out/'frozen/sdk/entry-dependencies/entry-bill.json')]
    prep=json.loads((out/'frozen/preparation.json').read_bytes())
    assert prep['schema']=='raw-static-sdk-preparation-v3' and prep['python_context_sha256']==m.context_digest(context)
    assert json.loads((out/'frozen/wire-config.json').read_bytes())['schema']=='capture-wire-startup-v2' ''')
p=root/'tests/benchmark/test_calibration_capture_study_v3.py'
with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
