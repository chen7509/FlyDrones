# Independent production-context review — follow-up

Static Windows source review against the original design/plan and initial six findings. BASE `0f30589dbcd2fbbbaeeaeae9ccef6d57dc905ef9`. The initial report remains unchanged. Current file hashes are recorded in the adjacent JSON. No production/test/raw edits, Python execution, tests, WSL/native/SDK commands, resource/PID probes, network or Git mutations were performed by this reviewer.

**Verdict: one important correction remains. C/I/M = 0/1/0.** Initial findings I1/I2/I3/I4/I6 are closed by static inspection; I5 is partially closed. This is source review, not native acceptance. All eight qualifications and readiness remain false. Task3 coordinator/static execution and physical/calibration work remain pending.

## Remaining I5 — P2: conflicting ELF header labels still pass

`tools/benchmark/native_entry_context_v3.py:142–149` counts matches of the expected full value, rather than occurrences of each header label. Starting with the valid protocol metadata, append `Type: EXEC (Executable file)` next to the existing `Type: DYN (Shared object file)`. There remains exactly one match of the DYN pattern, so the header loop accepts both contradictory type declarations. The unchanged valid program-header rows and dynsym table then reach successful classification. The same construction works for a valid ELF64 Class plus an extra ELF32 Class, or the expected Machine plus another Machine. This follows directly from the regular-expression conditions; no execution reproduction was performed.

The added program-header count, numeric row/flag parsing and LOAD/DYNAMIC/no-INTERP conditions close the original truncated `DYNAMIC`-only input. They do not close contradictory header metadata, which the specification requires to refuse as malformed/type mismatch. Require exactly one occurrence of each recognized header label, then validate its sole value. Add producer-path protocol negatives for conflicting Type/Class/Machine values while preserving valid program headers and symbols, so rejection is attributable to this condition.

## Verified corrections

| Initial finding | Static follow-up result |
| --- | --- |
| I1 caller-only context | Closed: producer now collects and retains current before/after context, compares both with the supplied context, and offline auditor joins both observations. The actual collector remains an already-imported-module observer. |
| I2 Agent membership | Closed: offline auditor now requires unique declared Agent paths to be actual entries and validates the Agent library path; per-entry environment validation remains. Preparation still joins those declarations with the bound Agent configuration. |
| I3 independent bill object | Closed: preparation first compares the supplied bill with the parsed retained bill. Existing digest, exact baseline identity and per-query raw artifact joins remain. |
| I4 dynamic-query index | Closed: dynamic index is assigned before invocation/parsing and the truncated dynamic negative now checks its retained value. |
| I5 metadata completeness | Partial: program count/rows now checked; conflicting header-label values still accepted as described above. |
| I6 runtime actual context | Closed: successful self-phase result contains the actual context; failures attach a completed observation when available and RuntimeBinding persists it. Collector failure can legitimately leave the observation null rather than inventing a snapshot. |

The v3 study's `dependency_code` now selects `native_entry_context_v3.py`; outer study command-source baseline enforcement consequently pins the actual new dependency implementation. Fixed workload, binding/execution digest, reconstructed prepared-input handoff, graph and source joins remain in the outer verifier. No unprotected final execution path was established.

The shared legacy contract gate now reads the binding for the new Python context only when `capture_profile == target-bearing-raw-v1`. Thus the ordinary legacy contract no longer parses an existing malformed binding merely while constructing its execution declaration. The new regression checks this exact old behavior. Normal binding validation remains separate. The redundant inner raw-profile check is harmless and is not counted as a finding.

Path-alias trace reuse, zero-selection self retention and renderer direct dependency/RUNPATH checks remain intact. The exact unique resolver path keeps `graph:resolver`; every other required self/selected path must be in `graph:dependencies`. SDK Python module checks remain confined to self phases; owned PX4/Agent map requirements retain their own PIDs.

I read the main worker's retained outputs: review-red reports 8 failed/24 passed, review-green reports 1 failed/31 passed due to the collector fixture NameError, and review-corrected-green reports 38 passed in 19.20 seconds. These are externally produced Windows protocol-test records, not tests run by this reviewer or native proof. The broad preparation test still explicitly stubs discovery/graph/v3 publishing boundaries. The initial/follow-up review artifacts and raw failures must remain retained. No current-final or admitted-static success is asserted.
