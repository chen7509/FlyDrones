"""Derive a distinct production module; original consumed implementation unchanged."""
import hashlib
from pathlib import Path

root=Path.cwd();old=root/'tools/benchmark/native_entry_dependencies.py';data=old.read_bytes()
assert hashlib.sha256(data).hexdigest()=='38bdb30431abb6d399f0a79c20671c7a7d75ecf444436b7a0d956f08bed988ea'
s=data.decode().replace('import datetime\n','import datetime\nimport copy\nimport hashlib\nimport json\nimport sysconfig\n')
s=s.replace('SCHEMA = "raw-entry-dependency-bill-v1"','SCHEMA = "native-entry-context-bill-v3"')
s=s.replace('def discover_entry_dependencies(entries, candidates, agent_paths, agent_lib, output):','def discover_entry_context(entries, candidates, python_context, agent_paths, agent_lib, output):')
s=s.replace('        input_candidates=candidates,','        input_candidates=candidates,\n        python_context=copy.deepcopy(python_context),\n        python_context_sha256=context_digest(python_context),')
s=s.replace('        for path in requested + candidates:\n            remember(path)','        for path in requested + candidates:\n            remember(path)\n        validate_python_context(python_context)\n        for module in python_context["modules"]:\n            if not _typed_equal(remember(module["origin"]["requested"]), module["origin"]):\n                raise ValueError("Python module origin identity differs")\n            if module["origin"]["resolved"] not in {files[p]["resolved"] for p in requested}:\n                raise ValueError("Python context module absent from actual entries")\n        if not _typed_equal(remember(python_context["interpreter"]["requested"]), python_context["interpreter"]):\n            raise ValueError("Python interpreter context identity differs")')
s=s.replace('        for name, tool in tools.items():','        if not _typed_equal(bill["tools_before"]["python"], python_context["interpreter"]):\n            raise ValueError("Python context differs from selected interpreter")\n        for name, tool in tools.items():')
s=s.replace('                    role=role,','                    role=role,\n                    entry_kind="python_extension_entry" if module_for(python_context, record) else "dependency_entry",\n                    trace_kind=None,\n                    elf_metadata=None,\n                    metadata_query=None,\n                    runtime_import_verified=False,\n                    symbols_resolved=False,')
s=s.replace('                    continue\n                seen.add(resolved)','                    for key in ("entry_kind", "trace_kind", "elf_metadata", "runtime_import_verified", "symbols_resolved"):\n                        row[key] = original[key]\n                    continue\n                seen.add(resolved)')
oldblock='''                traced = invoke("ldd", [tools["ldd"], path], env)
                row.update(ldd_query=len(bill["queries"]), **_ldd(bytes.fromhex(traced["stdout_hex"])))'''
newblock='''                if row["entry_kind"] == "python_extension_entry" and not row["dynamic"]["needed"]:
                    row["metadata_query"] = len(bill["queries"]) + 1
                    metadata = invoke("elf-metadata", [tools["readelf"], "-W", "-h", "-l", "--dyn-syms", path], env)
                    row["elf_metadata"] = parse_extension_metadata(bytes.fromhex(metadata["stdout_hex"]), module_for(python_context, record))
                row["ldd_query"] = len(bill["queries"]) + 1
                traced = invoke("ldd", [tools["ldd"], path], env)
                row.update(classify_trace(row, traced))'''
assert oldblock in s;s=s.replace(oldblock,newblock)
s=s.replace('        audit_entry_bill(bill, bill["files"])','        audit_entry_context_bill(bill, baseline_files=bill["files"], python_context=python_context)')
s=s.replace('def audit_entry_bill(bill, baseline):','def audit_entry_context_bill(bill, *, baseline_files, python_context):\n    baseline = baseline_files')
s=s.replace('        "input_candidates",','        "input_candidates",\n        "python_context",\n        "python_context_sha256",')
s=s.replace('    files = {r["requested"]: r for r in bill["files"]}','    validate_python_context(python_context)\n    if not _typed_equal(bill["python_context"], python_context) or bill["python_context_sha256"] != context_digest(python_context):\n        raise ValueError("Python context digest/join differs")\n    files = {r["requested"]: r for r in bill["files"]}')
s=s.replace('    expected_entries = [(role, p)', '    for record in [python_context["interpreter"], *(m["origin"] for m in python_context["modules"])]:\n        if not _typed_equal(record, files.get(record["requested"])):\n            raise ValueError("Python context file absent from baseline")\n    if not _typed_equal(bill["tools_before"]["python"], python_context["interpreter"]):\n        raise ValueError("Python interpreter differs from selected tool")\n    expected_entries = [(role, p)')
s=s.replace('    seen = {}\n    for row in bill["entries"]:', '    used.update(m["origin"]["requested"] for m in python_context["modules"])\n    used.add(python_context["interpreter"]["requested"])\n    seen = {}\n    for row in bill["entries"]:')
s=s.replace('        resolved = row["file"]["resolved"]\n        env =','        module = module_for(python_context, row["file"])\n        if row["entry_kind"] != ("python_extension_entry" if module else "dependency_entry") or row["runtime_import_verified"] is not False or row["symbols_resolved"] is not False:\n            raise ValueError("Python entry kind/qualification differs")\n        resolved = row["file"]["resolved"]\n        env =')
s=s.replace('                or row["dynamic_query"] is not None','                or row["dynamic_query"] is not None\n                or row["metadata_query"] is not None')
s=s.replace('            for key in ("elf", "dynamic", "selected", "nonfiles"):','            for key in ("elf", "dynamic", "selected", "nonfiles", "trace_kind", "elf_metadata", "entry_kind"):')
oldblock='''                expected_calls.append(("ldd", [tools["ldd"]["requested"], path], env))
                ldd_number = len(expected_calls)
                if row["dynamic_query"] != dynamic_number or row["ldd_query"] != ldd_number:
                    raise ValueError("entry raw query index differs")
                dynamic = _dynamic(bytes.fromhex(bill["queries"][dynamic_number - 1]["stdout_hex"]))
                traced = _ldd(bytes.fromhex(bill["queries"][ldd_number - 1]["stdout_hex"]))
                if not _typed_equal(row["dynamic"], dynamic) or any(not _typed_equal(row[k], traced[k]) for k in traced):
                    raise ValueError("entry raw dependency/dynamic trace differs")'''
newblock='''                dynamic = _dynamic(bytes.fromhex(bill["queries"][dynamic_number - 1]["stdout_hex"]))
                if module and not dynamic["needed"]:
                    expected_calls.append(("elf-metadata", [tools["readelf"]["requested"], "-W", "-h", "-l", "--dyn-syms", path], env))
                    if row["metadata_query"] != len(expected_calls):
                        raise ValueError("extension metadata query index differs")
                    metadata = parse_extension_metadata(bytes.fromhex(bill["queries"][-1 + len(expected_calls)]["stdout_hex"]), module)
                    if not _typed_equal(row["elf_metadata"], metadata):
                        raise ValueError("extension raw metadata differs")
                elif row["metadata_query"] is not None or row["elf_metadata"] is not None:
                    raise ValueError("undeclared extension metadata")
                expected_calls.append(("ldd", [tools["ldd"]["requested"], path], env))
                ldd_number = len(expected_calls)
                if row["dynamic_query"] != dynamic_number or row["ldd_query"] != ldd_number:
                    raise ValueError("entry raw query index differs")
                traced = classify_trace(dict(row, dynamic=dynamic), bill["queries"][ldd_number - 1])
                if not _typed_equal(row["dynamic"], dynamic) or any(not _typed_equal(row[k], traced[k]) for k in traced):
                    raise ValueError("entry raw dependency/dynamic trace differs")'''
assert oldblock in s;s=s.replace(oldblock,newblock)
s=s.replace('("ldd_query", "dynamic_query", "dynamic", "selected", "nonfiles")','("ldd_query", "dynamic_query", "dynamic", "selected", "nonfiles", "metadata_query", "elf_metadata", "trace_kind")')
target=root/'tools/benchmark/native_entry_context_v3.py'
assert not target.exists();target.write_text(s,encoding='utf8',newline='\n')
