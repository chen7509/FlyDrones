import datetime, hashlib, json, subprocess
from pathlib import Path
root=Path.cwd();out=root/'results/python-extension-context-production-dev-1701'
sha=lambda b:hashlib.sha256(b).hexdigest()
prior=json.loads((root/'results/zero-needed-python-entry-research-dev-1701/historical-archives-before-seal.json').read_bytes())['members']
prior += [json.loads((root/'evidence/zero-needed-python-entry-research-publication.json').read_bytes())['archive']]
rows=[]
for r in prior:
 p=root/r['path'];h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 assert h.hexdigest()==r['sha256'] and p.stat().st_size==r['bytes'],r['path']
 rows.append(dict(path=r['path'],bytes=p.stat().st_size,sha256=h.hexdigest()))
assert len(rows)==286
with (out/'historical-archives-before-seal.json').open('xb') as f:f.write(json.dumps(dict(count=len(rows),bytes=sum(r['bytes'] for r in rows),scope='POSTsoftware verification, not pre-native attestation',members=rows),indent=2).encode())
old=['tools/benchmark/native_entry_dependencies.py','tools/benchmark/prepare_calibration_capture.py','tools/benchmark/prepare_calibration_capture_v2.py','tools/benchmark/calibration_capture_study_v2.py','evidence/flydrones-history-through-admitted-executor-dev-1701.json']
oldrows=[]
for name in old:
 p=root/name;b=p.read_bytes();oldrows.append(dict(path=name,bytes=len(b),sha256=sha(b)))
assert oldrows[0]['sha256']=='38bdb30431abb6d399f0a79c20671c7a7d75ecf444436b7a0d956f08bed988ea'
assert oldrows[1]['sha256']=='9113bd1148c9e529de2f0ab1a97b818f86766ba5e44a5d0c94133f0cb8f8c68d'
assert oldrows[-1]['sha256']=='c88840b6f58dea4e7e4931683c4993b4fc3b8eb55887807994b6381ef6c2b989'
for name in old[2:4]:
 current=(root/name).read_bytes();git=subprocess.check_output(['git','show','HEAD:'+name])
 assert current.replace(b'\r\n',b'\n')==git.replace(b'\r\n',b'\n')
with (out/'immutable-source-and-attempt-audit.json').open('xb') as f:f.write(json.dumps(dict(files=oldrows,v3_fixed_parent_exists=(root/'results/target-bearing-runtime-freeze-v3-dev-1701').exists(),physical_attempt_exists=(root/'results/target-bearing-physical-capture-dev-1701').exists(),qualification={k:False for k in ['source','clock','measured_calibration','accuracy','teacher','fusion','training','flight']}),indent=2).encode())
assert not (root/'results/target-bearing-runtime-freeze-v3-dev-1701').exists()
assert not (root/'results/target-bearing-physical-capture-dev-1701').exists()
commands=[]
for p in sorted(out.glob('*.json')):
 try:r=json.loads(p.read_bytes())
 except Exception:continue
 if type(r)is dict and 'source_before' in r:
  commands.append(dict(record=p.name,argv=r['argv'],exit=r['exit'],start_utc=r['start_utc'],end_utc=r['end_utc'],source_members=len(r['source_before']),source_before_after_equal=r['source_before']==r['source_after'],recorder_hash_present='recorder_sha256'in r,child_environment_present='child_environment'in r))
with (out/'command-index.json').open('xb') as f:f.write(json.dumps(commands,indent=2).encode())
print(json.dumps(dict(historical_count=len(rows),bytes=sum(r['bytes'] for r in rows),commands=len(commands),old_source_unchanged=True,v3_attempt_absent=True)))
