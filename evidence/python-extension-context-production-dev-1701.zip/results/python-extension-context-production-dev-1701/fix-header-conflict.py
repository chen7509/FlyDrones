from pathlib import Path
p=Path('tools/benchmark/native_entry_context_v3.py');s=p.read_text().replace('    for pattern in (\n', '    for label in ("Class", "Data", "Type", "Machine"):\n        if len(re.findall(r"^\\s*" + label + ":", text, re.MULTILINE)) != 1:\n            raise ValueError("unique ELF header field required")\n    for pattern in (\n',1);p.write_text(s)
