import json,subprocess
from pathlib import Path
out=Path('results/python-extension-context-production-dev-1701')
p=subprocess.run(['gh','pr','view','65','--repo','chen7509/FlyDrones','--json','headRefOid,body'],capture_output=True)
with (out/'pr-before.json').open('xb') as f:f.write(json.dumps(dict(argv=p.args,exit=p.returncode,stdout_hex=p.stdout.hex(),stderr_hex=p.stderr.hex()),indent=2).encode())
assert p.returncode==0
r=json.loads(p.stdout);print(json.dumps(dict(head=r['headRefOid'],body_chars=len(r['body']))))
