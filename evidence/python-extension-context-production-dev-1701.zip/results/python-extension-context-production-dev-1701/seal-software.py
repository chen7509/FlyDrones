import hashlib,json,zipfile
from pathlib import Path
root=Path.cwd();out=root/'results/python-extension-context-production-dev-1701'
sha=lambda b:hashlib.sha256(b).hexdigest()
for name in ['independent-code-final.json','independent-deliverable-review.json']:
 r=json.loads((out/name).read_bytes());assert r['counts']==dict(critical=0,important=0,minor=0),name
for name,h in json.loads((out/'final-ruff.json').read_bytes())['source_after'].items():
 assert sha((root/name).read_bytes())==h,name
private=out/'initial-resource-private.json';privatebytes=private.read_bytes()
assert len(privatebytes)==66618 and sha(privatebytes)=='1c9ec0bdd49833d028ed4c2451f14a5c64e23332f486c8cebb3fc55908d88e53'
assert json.loads((out/'historical-archives-before-seal.json').read_bytes())['count']==286
excluded={private,out/'archive-seal-receipt.json'}
paths=[p for p in out.rglob('*') if p.is_file() and p not in excluded and '__pycache__' not in p.parts and p.suffix!='.pyc']
paths += [root/p for p in ['tools/benchmark/native_entry_context_v3.py','tools/benchmark/prepare_calibration_capture_v3.py','tools/benchmark/calibration_capture_study_v3.py','tools/benchmark/calibration_capture_study.py','tools/benchmark/capture_contract.py','tools/benchmark/runtime_resource_binding.py','tools/benchmark/capture_disarmed_sensors.py','tests/benchmark/test_native_entry_context_v3.py','tests/benchmark/test_calibration_capture_study_v3.py','docs/TARGET_BEARING_PYTHON_CONTEXT_PRODUCTION_REPORT.md','docs/superpowers/specs/2026-10-15-python-extension-context-production-design.md','docs/superpowers/plans/2026-10-15-python-extension-context-production.md','tools/benchmark/native_entry_dependencies.py','tools/benchmark/prepare_calibration_capture_v2.py','tools/benchmark/calibration_capture_study_v2.py','docs/TARGET_BEARING_ZERO_NEEDED_RESEARCH_REPORT.md','results/zero-needed-python-entry-research-dev-1701/observer-scope-correction.json','evidence/flydrones-history-through-admitted-executor-dev-1701.json','results/zero-needed-python-entry-research-dev-1701/elf-file-facts.json','results/target-bearing-runtime-freeze-v2-dev-1701/frozen-study-v2/sdk/entry-dependencies/query-0057.json']]
paths=sorted(set(paths));records=[]
for p in paths:
 b=p.read_bytes();records.append(dict(path=p.relative_to(root).as_posix(),bytes=len(b),sha256=sha(b)))
processes=[r for key in ['windows','wsl'] for r in json.loads(privatebytes)[key]]
empty=sha(b'');needles={r['argv_sha256'].encode() for r in processes if r['argv_sha256']!=empty}
leaks=[]
for p in paths:
 b=p.read_bytes()
 if any(n in b for n in needles):leaks.append(p.relative_to(root).as_posix())
assert not leaks,leaks
manifest=root/'evidence/python-extension-context-production-dev-1701.sha256.json'
body=dict(schema='sealed-working-byte-map-v1',scope='Task1/Task2 implemented software only; Windows protocol fixtures; Task3 static coordinator/native freeze and Task4 physical pending',members=records,private_originals=[dict(path=private.relative_to(root).as_posix(),bytes=len(privatebytes),sha256=sha(privatebytes),policy='LOCAL_UNPUBLISHED')],private_nonempty_argv_hash_needles=len(needles),private_matches=leaks,qualification={k:False for k in ['source','clock','measured_calibration','accuracy','teacher','fusion','training','flight']},runtime_graph_frozen=False,physical_dispatch_ready=False,static_v3_attempt_consumed=False,physical_attempt_consumed=False,early_fixture_retention='earlier-fixture-retention-scope.json; eight of ten referenced roots missing, not reconstructed')
with manifest.open('xb') as f:f.write(json.dumps(body,indent=2).encode())
target=root/'evidence/python-extension-context-production-dev-1701.zip'
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in paths:z.write(p,p.relative_to(root).as_posix())
 z.write(manifest,manifest.relative_to(root).as_posix())
with zipfile.ZipFile(target) as z:
 assert z.testzip()is None
 assert len(z.namelist())==len(records)+1
 for r in records:
  b=z.read(r['path']);assert len(b)==r['bytes'] and sha(b)==r['sha256']
receipt=dict(path=target.relative_to(root).as_posix(),bytes=target.stat().st_size,members=len(records)+1,mapped_members=len(records),sha256=sha(target.read_bytes()),private_excluded=True,nonempty_private_hash_needles=len(needles))
with (out/'archive-seal-receipt.json').open('xb') as f:f.write(json.dumps(receipt,indent=2).encode())
print(json.dumps(receipt))
