"""Seal this stage once; preserve every earlier result and archive."""

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
ARCHIVE = ROOT / "evidence/openvins-timesync-wire-dev-1701.zip"


def digest(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


assert (OUT / "full-pytest-exit.txt").read_text(encoding="utf-8-sig").strip() == "0"
post = json.loads((OUT / "final-tests-post.json").read_text())
assert post["returncode"] == 0 and post["unchanged"] is True
selected = ["tools/benchmark/openvins_timesync_wire.py", "tools/benchmark/openvins_timesync_observer.py",
            "tools/benchmark/openvins_ekf2_disarmed_preflight.py", "tools/benchmark/owned_daemon_connection.py",
            "tests/benchmark/test_openvins_timesync_wire.py",
            "docs/superpowers/specs/2026-10-08-timesync-wire-design.md",
            "docs/superpowers/plans/2026-10-08-timesync-wire.md", "docs/OPENVINS_TIMESYNC_WIRE_REPORT.md"]
entries = {"results/" + str(p.relative_to(OUT)).replace("\\", "/"): p.read_bytes()
           for p in OUT.rglob("*") if p.is_file() and "__pycache__" not in p.parts}
for relative in selected:
    raw = (ROOT / relative).read_bytes()
    linux = "/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/" + relative
    if linux in post["files"]:
        assert digest(raw) == post["files"][linux]
    entries["selected-source/" + relative] = raw
entries["execution-ledger.md"] = (ROOT / ".superpowers/sdd/2026-10-08-timesync-wire/progress.md").read_bytes()
manifest = {name: digest(raw) for name, raw in sorted(entries.items())}
entries["manifest.json"] = (json.dumps(dict(members=manifest, source_copy_basis="post-test selected copies; matched to test snapshots where listed",
                                           network_authorized=False, fusion_qualified=False), indent=2) + "\n").encode()
prior = ROOT / "evidence/openvins-owned-bootstrap-dev-1701.zip"
prior_digest = digest(prior.read_bytes())
assert prior_digest["sha256"] == "af24b495ec0fbd0fb3501ef9f1e3354a34e08f32e7387ea138198cbd762ce6e6"
with zipfile.ZipFile(ARCHIVE, "x", compression=zipfile.ZIP_DEFLATED) as z:
    for name, raw in sorted(entries.items()):
        z.writestr(name, raw)
with zipfile.ZipFile(ARCHIVE) as z:
    assert z.testzip() is None
    assert len(set(z.namelist())) == len(entries)
    assert set(z.namelist()) == set(entries)
    for name, expected in manifest.items():
        assert digest(z.read(name)) == expected
assert digest(prior.read_bytes()) == prior_digest
report = dict(archive=str(ARCHIVE), **digest(ARCHIVE.read_bytes()), members=len(entries), crc_ok=True,
              member_hashes_ok=True, preceding_archive_unchanged=True, fusion_qualified=False)
with (ROOT / "evidence/openvins-timesync-wire-dev-1701-verification.json").open("x") as stream:
    json.dump(report, stream, indent=2)
with (ROOT / "evidence/openvins-timesync-wire-dev-1701.sha256").open("x") as stream:
    stream.write(report["sha256"] + "  " + ARCHIVE.name + "\n")
print(json.dumps(report))
