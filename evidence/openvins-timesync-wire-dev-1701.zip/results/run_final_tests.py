"""One final installed-codec unittest verification with selected pre/post hashes."""

import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
from pymavlink.dialects.v20 import common  # noqa: E402


def snapshot():
    files = [ROOT / "tools/benchmark/openvins_timesync_wire.py",
             ROOT / "tools/benchmark/openvins_timesync_observer.py",
             ROOT / "tools/benchmark/openvins_ekf2_disarmed_preflight.py",
             ROOT / "tools/benchmark/owned_daemon_connection.py",
             ROOT / "tests/benchmark/test_openvins_timesync_wire.py", Path(__file__),
             Path(common.__file__), Path(sys.executable).resolve()]
    return {str(p): {"sha256": hashlib.sha256(p.read_bytes()).hexdigest(), "bytes": p.stat().st_size} for p in files}


def save(name, value):
    with (OUT / name).open("x") as stream:
        json.dump(value, stream, indent=2)


command = [sys.executable, "-m", "unittest", "tests.benchmark.test_openvins_timesync_wire", "-v"]
before = snapshot()
save("final-tests-pre.json", dict(producer=sys.argv[1], files=before, command=command,
                                 execution="in-memory unittest, no network", python=sys.version))
with (OUT / "final-codec-tests.txt").open("x") as stream:
    result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, timeout=60)
after = snapshot()
save("final-tests-post.json", dict(files=after, unchanged=before == after, returncode=result.returncode))
print(json.dumps(dict(returncode=result.returncode, unchanged=before == after)))
raise SystemExit(result.returncode if before == after else 2)
