Next: concrete bounded receive/send ownership and the actual bootstrap callback
composition, still offline/private fixture authority only. Do not run actual
PX4/Gazebo/OpenVINS, emit networkODOMETRY, mutate parameters/streams or claim
clock convergence. Current stage adds real installed codec, not a UDP backend.

Read current wire spec/report/review plus prior OwnedBootstrap and interval
contracts. Do not repeat14-case codec research or previous ordinary socket
matrix. No need to upgrade/installpymavlink: fixed2.4.49 common SHA remains.
Preserve one pending reply and separate8s/2s/500 gates. Outputsequence is not
requestidentity. Supplied peer/time/simulationclock is not actual socket
provenance, sourceprotocol0 is not exclusivity, sendbytecount is not delivery.

Resolve deferred received_ns cross-datagram monotonicity before qualifying
the realreceive chain. Accountfor callbacks reentry, lost/short/late sends,
posteffect logfailure, and primaryinterrupt without losing sink return evidence.
Bound the actualdescriptor/peer/owner and capture actualrecv/read/sendreturn
times; avoid generic arbitrarysocket constructors grantingliveauthority.
The current complete4096byte/64frame unsigneddatagram profile is predeclared,
not established against actualPX4traffic. Unsupported traffic must retainfailure.

Correlated interval ACK/query remains a separate missing concrete adapter;
no inventednonce, wrongsourceACK mustnotmatch, baseline/restore evidence stays
mandatory. ActualcoldPX4 epoch/filter/status/acceptedrate study needs a later
explicit gated design. ExistingVIO/health qualification remains simulationonly;
fullfruitfly learning/decision/division/comparison and5/20aircraft gates stayopen.
