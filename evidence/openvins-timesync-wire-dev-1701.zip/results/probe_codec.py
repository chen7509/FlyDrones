"""One in-memory installed-codec study. No sockets, sender or PX4 process."""
import hashlib
import importlib.metadata
import json
import os
import sys
from pathlib import Path

from pymavlink.dialects.v20 import common

OUT = Path(__file__).resolve().parent


def save(name, value):
    with (OUT/name).open('x') as f:
        json.dump(value, f, indent=2)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


files = [Path(__file__), Path(common.__file__), Path(sys.executable).resolve()]
before = {str(p): digest(p) for p in files}
assert importlib.metadata.version('pymavlink') == '2.4.49'
assert common.MAVLink_timesync_message.fieldnames == ['tc1', 'ts1']
assert not common.MAVLINK_IGNORE_CRC
save('prospective-codec.json', dict(files=before, version='2.4.49', clock_input='literal synthetic ns',
    cases=['v2-request', 'v2-response', 'v1-wire-request', 'negative-timestamp', 'int64-overflow',
           'concatenated', 'every-split', 'truncated', 'crc-corruption', 'signed-without-key',
           'tampered-signature-without-key', 'tampered-signature-with-key', 'pack-sequence', 'missing-target-fields'],
    signing_key='fixture only: byte x repeated32; not a credential', no_socket=True, no_live_px4=True,
    env={k: os.environ.get(k) for k in ('MAVLINK_IGNORE_CRC','MAVLINK20','MAVLINK_DIALECT')}))
encoder = common.MAVLink(None, srcSystem=9, srcComponent=1)
request = common.MAVLink_timesync_message(0, 100000000).pack(encoder)
response = common.MAVLink_timesync_message(101000000, 100000000).pack(common.MAVLink(None, srcSystem=254, srcComponent=191))
v1 = common.MAVLink_timesync_message(0, 100000000).pack(encoder, force_mavlink1=True)
negative = common.MAVLink_timesync_message(0, -1).pack(encoder)
heartbeat = common.MAVLink_heartbeat_message(2, 12, 0, 0, 3, 3).pack(encoder)
results = []


def decoded_row(message):
    return dict(type=message.get_type(), system=message.get_srcSystem(), component=message.get_srcComponent(),
        sequence=message.get_seq(), fields=message.to_dict(), signature_verified=message.get_signed())


for name, packet in [('v2-request',request),('v2-response',response),('v1-wire-request',v1),('negative-timestamp',negative)]:
    parser = common.MAVLink(None)
    value = parser.parse_char(packet)
    assert value is not None
    results.append(dict(case=name, raw_hex=packet.hex(), decoded=decoded_row(value), buffered=parser.buf_len()))
try:
    common.MAVLink_timesync_message(0, 2**63).pack(encoder)
except Exception as exc:
    results.append(dict(case='int64-overflow', refused=type(exc).__name__, error=str(exc)))
else:
    raise AssertionError('out-of-range timestamp packed')
parser = common.MAVLink(None)
batch = heartbeat+request+response
messages = parser.parse_buffer(batch)
assert [m.get_type() for m in messages] == ['HEARTBEAT','TIMESYNC','TIMESYNC']
results.append(dict(case='concatenated', raw_hex=batch.hex(), decoded=[decoded_row(m) for m in messages], buffered=parser.buf_len()))
split_rows = []
for index in range(1,len(request)):
    parser = common.MAVLink(None)
    first = parser.parse_buffer(request[:index])
    second = parser.parse_buffer(request[index:])
    assert not first and len(second) == 1 and second[0].ts1 == 100000000 and parser.buf_len() == 0
    split_rows.append(dict(index=index, first_complete=0, second_complete=1))
results.append(dict(case='every-split', rows=split_rows))
parser = common.MAVLink(None)
value = parser.parse_char(request[:-1])
assert value is None and parser.buf_len() > 0
results.append(dict(case='truncated', raw_hex=request[:-1].hex(), complete=False, buffered=parser.buf_len(), automatic_error=False))
corrupt = request[:-1]+bytes([request[-1]^1])
try:
    common.MAVLink(None).parse_char(corrupt)
except Exception as exc:
    results.append(dict(case='crc-corruption', raw_hex=corrupt.hex(), refused=type(exc).__name__, error=str(exc)))
else:
    raise AssertionError('bad CRC accepted')
signed_encoder = common.MAVLink(None, srcSystem=9, srcComponent=1)
signed_encoder.signing.secret_key = b'x'*32
signed_encoder.signing.sign_outgoing = True
signed_encoder.signing.timestamp = 1000
signed = common.MAVLink_timesync_message(0,100000000).pack(signed_encoder)
tampered = signed[:-1]+bytes([signed[-1]^1])
for name,packet in [('signed-without-key',signed),('tampered-signature-without-key',tampered)]:
    parser = common.MAVLink(None)
    value = parser.parse_char(packet)
    assert value is not None and value.get_signed() is False
    results.append(dict(case=name, raw_hex=packet.hex(), decoded=decoded_row(value), accepted_without_signature_verification=True))
parser = common.MAVLink(None)
parser.signing.secret_key = b'x'*32
try:
    parser.parse_char(tampered)
except Exception as exc:
    results.append(dict(case='tampered-signature-with-key',raw_hex=tampered.hex(),refused=type(exc).__name__,error=str(exc)))
else:
    raise AssertionError('configured key accepted tampered signature')
first = common.MAVLink_timesync_message(0,100000000).pack(encoder)
second = common.MAVLink_timesync_message(0,120000000).pack(encoder)
a = common.MAVLink(None).parse_char(first).get_seq()
b = common.MAVLink(None).parse_char(second).get_seq()
assert a == b
results.append(dict(case='pack-sequence', first_hex=first.hex(), second_hex=second.hex(), first_seq=a, second_seq=b,
                    pack_alone_advances_sequence=False))
try:
    common.MAVLink_timesync_message(0,100000000,target_system=9,target_component=1)
except TypeError as exc:
    results.append(dict(case='missing-target-fields',refused='TypeError',error=str(exc)))
else:
    raise AssertionError('unavailable target fields accepted')
after = {str(p): digest(p) for p in files}
save('codec-results.json',dict(results=results,after=after,source_hashes_stable=before==after,
    cases=len(results),network_authorized=False,fusion_qualified=False,live_convergence_qualified=False))
assert before == after
print(json.dumps(dict(cases=len(results),split_cases=len(split_rows),hashes_stable=True,
                     observed_only=True,no_socket=True)))
