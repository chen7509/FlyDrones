import inspect
from pathlib import Path
from pymavlink.dialects.v20 import common
out=Path(__file__).resolve().parent
for name in ('decode','parse_char','parse_buffer','send','check_signature'):
 text=inspect.getsource(getattr(common.MAVLink,name))
 with (out/('codec-'+name+'.py.txt')).open('x') as f:f.write(text)
 if name=='decode':
  lines=text.splitlines()
  for n,line in enumerate(lines):
   if 'sign' in line or 'incompat' in line or 'crc' in line or 'payload' in line:print(n,line)
