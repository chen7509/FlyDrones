# Independent read-only review

Reviewer: /root/review_owned_isolated_launch. Range45595af..3c77a74.
No reviewer code edits, tests, network or processes. Review examined code,
spec/plan and retained38-test/141-adjacent output.

3Important/P2:
1. MAX_EVENTS5 fills on send_attempt yet sink is called and return evidence lost;
   at6, swallowed reentrant refusal can consume the return slot. Fixed with
   pre-send capacity and separate regular/refusal counters. Two counterexamples
   are in review-red.txt then review-green.txt.
2. A clock KeyboardInterrupt after sink plus journal OSError masked primary
   interrupt. Fixed by retaining journal error separately and preserving primary
   interruption. One failing wrong-exception counterexample then GREEN.
3. User-defined exception str could throw before failure latch, permitting a
   later send. Fixed by initial latch before formatting and reused safe _error;
   other exception formatting sites hardened. One assert-failure then GREEN.

1Minor/P3 deferred: received_ns is fresh/not-future but not checked monotonic
across datagrams. This does not extend timeout windows. Local now() and request
identity are monotonic. Future receive-transport binding must resolve this;
current report does not claim all receive timestamps monotonic.

No Critical. Bad-last-frame/CRC/signature/source/request replay/authority paths
had no other actionable finding. Actual UDP/PX4 receipt/authentication and live
convergence are outside this review's evidence. They remain false/untested,
not waived. No automatic re-review requested after covering tests.
