import hashlib,importlib.metadata,inspect,json,sys
from pathlib import Path
from pymavlink.dialects.v20 import common
out=Path(__file__).resolve().parent
p=Path(common.__file__)
dist=importlib.metadata.distribution('pymavlink')
value=dict(python=sys.version,version=dist.version,license=dist.metadata.get('License'),path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),timesync_fields=common.MAVLink_timesync_message.fieldnames,timesync_signature=str(inspect.signature(common.MAVLink_timesync_message)),crc_extra=common.MAVLink_timesync_message.crc_extra,wire_version=common.WIRE_PROTOCOL_VERSION,source=inspect.getsource(common.MAVLink_timesync_message),parser_signature=str(inspect.signature(common.MAVLink.parse_char)),codec_only=True,network_opened=False)
with (out/'installed-codec.json').open('x') as f:json.dump(value,f,indent=2)
print(json.dumps({k:v for k,v in value.items() if k!='source'}))
