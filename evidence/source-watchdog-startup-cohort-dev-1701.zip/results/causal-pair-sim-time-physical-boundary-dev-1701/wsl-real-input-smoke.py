import json
import tempfile
from pathlib import Path

from tools.benchmark.audit_causal_pair_sim_time_physical_boundary import audit_boundary
from tools.benchmark.causal_pair_sim_time_physical_boundary import build_boundary

root = Path.cwd()
with tempfile.TemporaryDirectory() as name:
    temp = Path(name)
    head = temp / "head.txt"
    head.write_text("a" * 40 + "\n", encoding="utf-8")
    value = build_boundary(
        study=root / "results/estimator-physical-refusal-diagnosis-dev-1701/study-v18",
        package_audit=root / "results/causal-pair-sim-time-retry-preflight-dev-1701/study-v18-audit-v3-after-startup.json",
        startup_audit=root / "results/causal-pair-sim-time-retry-preflight-dev-1701/study-v18-startup-audit-v1.json",
        startup_dispatch=root / "results/estimator-physical-refusal-diagnosis-dev-1701/startup-preflight-v10-dispatch.json",
        startup_completion=root / "results/estimator-physical-refusal-diagnosis-dev-1701/startup-preflight-v10-completion.json",
        evidence_archive=root / "evidence/causal-pair-sim-time-retry-preflight-dev-1701.zip",
        expected_head="a" * 40,
        head_file=head,
        observed_git_head="a" * 40,
        dispatch=temp / "dispatch.json",
        completion=temp / "completion.json",
        output=temp / "output.txt",
        resources=[],
    )
    boundary = temp / "boundary.json"
    boundary.write_text(json.dumps(value), encoding="utf-8")
    audit = audit_boundary(boundary, resources=[], observed_git_head="a" * 40)
    print(json.dumps({"boundary": value["schema"], "audit": audit}, indent=2))
