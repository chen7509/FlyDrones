from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
diag = root / "results/causal-pair-sim-time-physical-boundary-dev-1701"
study = root / "results/estimator-physical-refusal-diagnosis-dev-1701/study-v18"
base = root / "results/estimator-physical-refusal-diagnosis-dev-1701"
archive_path = root / "evidence/source-watchdog-startup-cohort-dev-1701.zip"
manifest_path = diag / "manifest.json"

paths: set[Path] = set()
paths.update(path for path in study.rglob("*") if path.is_file())
paths.update(path for path in diag.rglob("*") if path.is_file() and path != manifest_path)
for name in (
    "current-head-for-physical-v9.txt",
    "physical-run-v9-boundary.json",
    "physical-run-v9-boundary-audit.json",
    "physical-run-v9-dispatch.json",
    "physical-run-v9-completion.json",
    "physical-run-v9-output.txt",
):
    paths.add(base / name)
paths.add(root / "evidence/causal-pair-sim-time-retry-preflight-dev-1701.zip")
for name in (
    "docs/ESTIMATOR_PHYSICAL_REFUSAL_DIAGNOSIS_REPORT.md",
    "docs/superpowers/specs/2026-10-07-causal-pair-sim-time-physical-boundary-design.md",
    "docs/superpowers/plans/2026-10-07-causal-pair-sim-time-physical-boundary.md",
    "docs/superpowers/specs/2026-10-07-source-watchdog-startup-cohort-design.md",
    "docs/superpowers/plans/2026-10-07-source-watchdog-startup-cohort.md",
    "tools/benchmark/causal_pair_sim_time_physical_boundary.py",
    "tools/benchmark/audit_causal_pair_sim_time_physical_boundary.py",
    "tools/benchmark/execute_causal_pair_sim_time_physical_boundary.py",
    "tools/benchmark/audit_source_watchdog_startup_cohort.py",
    "tools/benchmark/openvins_online_shadow.py",
    "tests/benchmark/test_causal_pair_sim_time_physical_boundary.py",
    "tests/benchmark/test_source_watchdog_startup_cohort.py",
):
    paths.add(root / name)
missing = [str(path) for path in paths if not path.is_file()]
if missing:
    raise FileNotFoundError(missing)

def entry(path: Path):
    data = path.read_bytes()
    return {
        "path": path.relative_to(root).as_posix(),
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
    }

members = [entry(path) for path in sorted(paths, key=lambda item: item.relative_to(root).as_posix())]
manifest = {
    "schema": "source-watchdog-startup-cohort-evidence-v1",
    "member_count_without_manifest": len(members),
    "members": members,
}
manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
if archive_path.exists():
    raise FileExistsError(archive_path)
with zipfile.ZipFile(archive_path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for item in members:
        archive.write(root / item["path"], item["path"])
    archive.write(manifest_path, manifest_path.relative_to(root).as_posix())
with zipfile.ZipFile(archive_path) as archive:
    names = archive.namelist()
    if archive.testzip() is not None or len(names) != len(set(names)):
        raise ValueError("zip integrity")
    stored = json.loads(archive.read(manifest_path.relative_to(root).as_posix()))
    if stored != manifest or set(names) != {item["path"] for item in members} | {manifest_path.relative_to(root).as_posix()}:
        raise ValueError("manifest mismatch")
    for item in members:
        data = archive.read(item["path"])
        if len(data) != item["bytes"] or hashlib.sha256(data).hexdigest() != item["sha256"]:
            raise ValueError(item["path"])
print(json.dumps({
    "archive": archive_path.relative_to(root).as_posix(),
    "members": len(names),
    "bytes": archive_path.stat().st_size,
    "sha256": hashlib.sha256(archive_path.read_bytes()).hexdigest(),
}, indent=2))
