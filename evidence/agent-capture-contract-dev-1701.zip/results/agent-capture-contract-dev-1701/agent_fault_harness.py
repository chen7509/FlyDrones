"""Inject a wrong-owner socket observation after spawning the real Agent."""

import json
from pathlib import Path

from tools.benchmark.agent_capture_runtime import agent_runtime_record, launch_capture_agent
from tools.benchmark.agent_owned_listener import ss
from tools.benchmark.disarmed_sensor_provenance import CaptureJournal

root = Path(__file__).parent
output = root / 'agent-wrong-owner-v1'
output.mkdir(exist_ok=False)
record = agent_runtime_record(root / 'agent-runtime.json')
result = dict(status='incomplete', errors=[], px4_started=False, fusion_qualified=False)
calls = []


def observed(port):
    calls.append(len(calls))
    if len(calls) == 1:
        return ''  # No pre-existing listener.
    if len(calls) == 2:
        return ('UNCONN 0 0 0.0.0.0:18888 0.0.0.0:* '
                'users:(("foreign",pid=9999,fd=3))\n')
    return ss(port)


with CaptureJournal(output, result) as journal:
    launch_capture_agent(record, journal, output, socket_query=observed,
                         on_stop=lambda summary: result.update(agent=summary))
    raise AssertionError('wrong owner unexpectedly accepted')

assert result['status'] == 'capture_failed'
assert 'owner mismatch' in str(result['errors'])
assert result['agent']['cleanup']['group_absent']
assert result['agent']['port_released']
assert not ss(18888).strip()
print(json.dumps({'status': result['status'], 'agent_pid': result['agent']['pid'],
                  'port_released': result['agent']['port_released'],
                  'px4_started': result['px4_started']}))
