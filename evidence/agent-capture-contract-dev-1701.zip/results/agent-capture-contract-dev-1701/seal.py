"""Seal fixed Agent-capture integration evidence and verify every member."""

import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
result = root / 'results/agent-capture-contract-dev-1701'
audit = json.loads((result / 'audit.json').read_text())
assert audit['port_released'] and audit['fault_rejected']
assert audit['px4_started'] is False and audit['fusion_qualified'] is False
paths = [
    'docs/OWNED_AGENT_CAPTURE_INTEGRATION_REPORT.md',
    'docs/superpowers/specs/2026-10-12-owned-agent-capture-design.md',
    'docs/superpowers/plans/2026-10-12-owned-agent-capture.md',
    'tools/benchmark/agent_capture_runtime.py',
    'tools/benchmark/agent_owned_listener.py',
    'tools/benchmark/capture_contract.py',
    'tools/benchmark/capture_disarmed_sensors.py',
    'tools/benchmark/runtime_resource_binding.py',
    'tests/benchmark/test_agent_capture_runtime.py',
    'tests/benchmark/test_capture_contract.py',
    'tests/benchmark/test_capture_runtime_runner.py',
]
paths.extend(str(path.relative_to(root)).replace('\\', '/') for path in result.rglob('*')
             if path.is_file() and '__pycache__' not in path.parts)
paths = sorted(set(paths))
manifest = {
    'schema': 'agent-capture-contract-evidence-v1',
    'verified_scope': 'Agent files/lifecycle and synthetic capture integration',
    'px4_dds_fusion_qualified': False,
    'members': {name: {'sha256': hashlib.sha256((root / name).read_bytes()).hexdigest(),
                       'bytes': (root / name).stat().st_size} for name in paths},
}
archive_path = root / 'evidence/agent-capture-contract-dev-1701.zip'
with zipfile.ZipFile(archive_path, 'x', zipfile.ZIP_DEFLATED) as archive:
    for name in paths:
        archive.write(root / name, name)
    archive.writestr('manifest.json', json.dumps(manifest, sort_keys=True, indent=2))
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for name, record in manifest['members'].items():
        payload = archive.read(name)
        assert len(payload) == record['bytes']
        assert hashlib.sha256(payload).hexdigest() == record['sha256']
print(json.dumps({'archive': str(archive_path), 'members': len(paths) + 1,
                  'sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest()}))
