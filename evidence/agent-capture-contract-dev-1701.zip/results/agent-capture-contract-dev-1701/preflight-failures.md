# Preserved setup failures

1. First real-package contract check exited 1 with `ValueError: libmicroxrcedds_agent.so fixed SHA256 mismatch`. The binary/bundle identities were correct; a handwritten library constant did not match the SHA in the prior sealed build. The test rejected it before starting a process. The constant was corrected from the sealed `bundle-sha256.txt`, then all 16 selected paths validated.
2. The first Agent-only harness command exited 1 during Python import with `ModuleNotFoundError: No module named 'flydrones'`. No output directory or process had been created. The corrected invocation used `PYTHONPATH=.:src`; it did not alter any Agent/PX4 source.
3. `agent-only-v1` is the first successful lifecycle fixture before final review fixes. `agent-only-v2` is the separate successful run on final source. `agent-wrong-owner-v1` is an expected `capture_failed` fault run. None is a PX4/DDS physical capture.
