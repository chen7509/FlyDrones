"""One unarmed Agent-only lifecycle check for the capture integration path."""

import json
import sys
from pathlib import Path

from tools.benchmark.agent_capture_runtime import agent_runtime_record, launch_capture_agent
from tools.benchmark.disarmed_sensor_provenance import CaptureJournal

root = Path(__file__).parent
if len(sys.argv) != 2 or sys.argv[1] not in {'agent-only-v1', 'agent-only-v2'}:
    raise SystemExit('explicit fresh attempt name required')
output = root / sys.argv[1]
output.mkdir(exist_ok=False)
record = agent_runtime_record(root / 'agent-runtime.json')
(output / 'runtime-record.json').write_text(json.dumps(record, indent=2))
result = dict(status='incomplete', errors=[], px4_started=False, fusion_qualified=False)
with CaptureJournal(output, result) as journal:
    agent = launch_capture_agent(
        record, journal, output, on_stop=lambda summary: result.update(agent=summary),
    )
    agent.check(force=True)
    result['status'] = 'capture_completed'
assert result['status'] == 'capture_completed', result
assert result['agent']['cleanup']['graceful_group_cleanup_verified']
assert result['agent']['port_released']
assert result['px4_started'] is False and result['fusion_qualified'] is False
print(json.dumps({'status': result['status'], 'pid': agent.process.pid,
                  'socket_checks': result['agent']['socket_checks'],
                  'port_released': result['agent']['port_released']}))
