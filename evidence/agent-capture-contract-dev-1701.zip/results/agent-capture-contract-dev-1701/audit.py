"""Independent read of the fixed Agent-capture contract and retained attempts."""

import json
import subprocess
from pathlib import Path

from tools.benchmark.agent_capture_runtime import agent_runtime_record
from tools.benchmark.agent_owned_listener import ss

root = Path(__file__).parent
expected = agent_runtime_record(root / 'agent-runtime.json')
normal = root / 'agent-only-v2'
assert json.loads((normal / 'runtime-record.json').read_text()) == expected
capture = json.loads((normal / 'result.json').read_text())
agent = json.loads((normal / 'agent-result.json').read_text())
assert capture['status'] == 'capture_completed'
assert capture['agent'] == agent and capture['px4_started'] is False
assert agent['socket_checks'] == 2 and agent['exit_code'] == -15
assert agent['cleanup']['graceful_group_cleanup_verified']
assert agent['cleanup']['group_absent'] and not agent['cleanup']['sigkill_dispatched']
assert agent['port_released'] and agent['typed_dds_provenance'] is False
group = [json.loads(line) for line in (normal / 'agent-group-events.jsonl').read_text().splitlines()]
assert group == agent['cleanup']['events']
socket_rows = [json.loads(line) for line in (normal / 'agent-socket.jsonl').read_text().splitlines()]
assert len(socket_rows) == 2 and all(row['pid'] == agent['pid'] for row in socket_rows)
assert all(f'pid={agent["pid"]},' in row['row'] for row in socket_rows)
assert not (normal / 'agent-after-ss.txt').read_text().strip()

fault = root / 'agent-wrong-owner-v1'
failed = json.loads((fault / 'result.json').read_text())
assert failed['status'] == 'capture_failed' and not failed['px4_started']
assert any('UDP socket owner mismatch' in item for item in failed['errors'])
assert failed['agent']['cleanup']['group_absent'] and failed['agent']['port_released']
assert failed['agent']['typed_dds_provenance'] is False
assert not (fault / 'agent-after-ss.txt').read_text().strip()
assert not ss(18888).strip()
assert not subprocess.run(['pgrep', '-x', 'MicroXRCEAgent'], capture_output=True).stdout.strip()
tests = (root / 'targeted-tests.txt').read_text()
assert '163 passed, 2 skipped' in tests
assert 'All checks passed!' in (root / 'ruff.txt').read_text()
audit = dict(schema='agent-capture-contract-audit-v1', normal_pid=agent['pid'],
             normal_group_absent=True, fault_pid=failed['agent']['pid'],
             fault_rejected=True, port_released=True, selected_paths=len(expected['selected_paths']),
             targeted_passed=163, skipped=2, px4_started=False,
             typed_dds_provenance=False, fusion_qualified=False)
(root / 'audit.json').write_text(json.dumps(audit, indent=2))
print(json.dumps(audit))
