import json
from pathlib import Path

from tools.benchmark.agent_capture_runtime import agent_runtime_record

record = agent_runtime_record(Path(__file__).with_name('agent-runtime.json'))
assert len(record['selected_paths']) == 16
assert record['authority'] is False
print(json.dumps({'schema': record['schema'], 'selected_files': len(record['selected_paths']),
                  'binary_sha256': record['files'][1]['sha256'], 'fusion_qualified': record['fusion_qualified']}))
