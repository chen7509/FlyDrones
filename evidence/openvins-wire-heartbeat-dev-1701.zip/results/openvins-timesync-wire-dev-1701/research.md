# TIMESYNC installed wire research

Read-only research; no aircraft, PX4, simulator, socket, training or package installation.
Initial14-case probe retained unchanged. It proves installed codec behavior,
not a transmitted packet or deployed PX4 interoperability.

## Reuse and provenance

|Component|Version/license|Maintenance evidence|Interface/resources/choice|
|---|---|---|---|
|pymavlink|2.4.49; tag2a500b8acfb507255d02ed8257b6eb132e5b86d7; COPYING generator(L)GPLv3 with generated-outputMIT exception, distributionLGPLv3|fresh GitHub metadata nonarchived, pushed2026-10-06T23:56:46Z; GitHub license auto-detectionOther|existing WSL commonv20 import, encode/decode; noinstall, noestimator, bounded4096byte/64frame buffers. Adopt fixed bytes/CRC implementation.|
|PX4|d6f12ad1c4f70ad3230afd7d86e971421e02fef4;BSD3|prior retained metadata, no fresh maintenance claim|reuse existing pinned handler/filter evidence; no modification or launch|
|Python|installed WSL3.12.3, distributionPSF|installed version only|stdlibunittest avoids installingpytest; Windows cannot verify this installedcodec|

Installed generatedcommon.py hash a7c6b23d908322134d19cb94b937c1ea6b1f5d5ffa9d1b0ad139174bf8d75809.
Do not equate fixed Python package tag with proof of every installed generated
source's upstream byte equality. Source hash binds this installed implementation.

Current official [TIMESYNC service documentation](https://mavlink.io/en/services/timesync.html)
describes target fields added by servicev2. Installed constructor only takes
tc1/ts1; fixed PX4 handler does not filter targets. MAVLink2 framing does not
mean TIMESYNC servicev2. No target field is invented by the adapter.

Exact [pymavlink COPYING](https://github.com/ArduPilot/pymavlink/blob/2a500b8acfb507255d02ed8257b6eb132e5b86d7/COPYING)
is retained in APIbase64 and decodedbytes. Initial wrong tag2.4.49 lookup404 is
preserved before correctv2.4.49. Web API fetch failed; ghAPI supplied metadata.

## Installed experiment observations

- Real trimmed MAVLink2 TIMESYNC request is24bytes, not always28.
- Onecodec handles v1framing, v2framing and concatenated messages.
- Across23split positions streamparser buffers partial frames; truncation alone
  returnsNone rather than refusal. New datagram profile rejects incomplete input.
- CRC corruption is refused if MAVLINK_IGNORE_CRC remainsfalse.
- Negative timestamps decode; int64overflow cannot pack. Semantic validation is separate.
- With no signingkey, valid or tampered signedframes both decode without verified
  signature. Configured fixturekey rejects tampering. New unsignedstudy profile
  refuses all flaggedframes; it does not claim cryptographic authentication.
- pack does not advance senderseq; send advances but discards write result.
  Adapter uses explicit wrapping sequence and accounts for sink return separately.

Not adopted: hand-codedpayload/CRC, targetfield upgrade, unsignedcallback signing
bypass, cross-datagram repair, and oldframe replay for throughput. No new VIO
algorithm or statistical method; prior OpenVINS paper/estimation configuration
is unchanged. Future socket and stream-interval ACK transport need their own
real boundary validation; these in-memory results cannot open that gate.

## Research limits

4096bytes/64frames and complete datagrams are predeclared adapter constraints,
not an observed normal-PX4-traffic guarantee. Known nontimesync frames are
recorded but ignored; a future real capture may reveal unsupported dialects.
Peer/sysid equality cannot establish soleproducer, ownership or authentication.
No source clock truth is fed into VIO. Supplied observed simulation time is
an outer provenance responsibility, not inferred from requestts1.
