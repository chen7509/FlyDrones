# Shared-reader source research

Current capture uses mavutil.recv_match(type=HEARTBEAT). Installed mavfile.recv_match calls recv_msg and continues for nonmatching messages. mavudp.recv consumes from its socket port.recvfrom. The exact installed methods and whole mavutil bytes are retained in installed-receive.json and mavutil-installed.py.txt, SHA256 da6f010fed963a63d4b819e734a938c0db84293ccf12e6a427882bfd19b8593b. Inspection only imported/read source: it created no socket or process.

| Dependency | Version/license | Maintenance | Interface/cost/choice |
|---|---|---|---|
| pymavlink | installed2.4.49/tag2a500b8acfb507255d02ed8257b6eb132e5b86d7; generator(L)GPLv3, generated-outputMIT exception, distributionLGPLv3 | reuse prior nonarchived metadata/push2026-10-06T23:56:46Z, no new maintenance observation | reuse existing PinnedCodec once per datagram, optional callback; no second parser/reader/worker/install |
| PX4 | d6f12ad1c4f70ad3230afd7d86e971421e02fef4 BSD3 | reuse existing fixed source evidence | unchanged9/1 endpoint contract and health observation, no new aircraft execution |
| Python | installedWSL3.12.3 PSF | local installed version | callbacks and copied event dictionaries; outer supervisor must bound arbitrary blocking callback |

Official sources read: https://mavlink.io/en/services/timesync.html (current servicev2, not proof that installed generated codec supports target fields); https://mavlink.io/en/messages/common.html#MAV_CMD_SET_MESSAGE_INTERVAL; https://docs.python.org/3.12/library/socket.html#socket.socket.recvfrom (rolling3.12.15). Bytes/header/CRC parsing stays with installed generated common codec. Successful call/return does not prove durable journal or authenticated sender.

Default-rate feasibility is already documented by OPENVINS_TIMESYNC_STARTUP_REPORT and OPENVINS_TIMESYNC_INTERVAL_REPORT. FixedPX4 defaults10Hz; proposed100Hz requires a still-missing actual ACK/readback/restore adapter. No repeat feasibility experiment or actual mutation was done. Future lifecycle integration must have one reader, heartbeat routing, clock registration, rate transaction and completion handoff; this stage supplies only the missing heartbeat route in the existing composition.

Alternative rejected: parallel mavutil recv_match and DatagramReceiver.recvmsg would consume/discard each other's packets. A second codec would duplicate validation and custody. Extra socket/process supervision is outside this change. No new VIO, covariance, learning algorithm or paper method; existing research remains applicable. Callback CPU/queue costs are unmeasured and source equality is not ownership proof.
