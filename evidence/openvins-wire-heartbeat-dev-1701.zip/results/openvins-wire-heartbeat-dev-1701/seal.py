import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[2]
stage = Path(__file__).resolve().parent
archive = root / 'evidence/openvins-wire-heartbeat-dev-1701.zip'
manifest = root / 'evidence/openvins-wire-heartbeat-seal.json'
assert not archive.exists() and not manifest.exists()
refs = ['evidence/openvins-observed-wire-session-dev-1701.zip',
        'results/openvins-timesync-wire-dev-1701/research.md',
        'results/openvins-timesync-wire-dev-1701/COPYING-pinned.txt']
def digest(raw):
    return hashlib.sha256(raw).hexdigest()
with (stage / 'source-references.json').open('x', encoding='utf-8') as target:
    json.dump({p: digest((root / p).read_bytes()) for p in refs}, target, indent=2)
files = [p for p in stage.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
files += [root / p for p in refs if not p.endswith('.zip')]
files += list((root / '.superpowers/sdd/2026-10-08-wire-heartbeat-dispatch').glob('*.md'))
files += [root / p for p in [
    'docs/OPENVINS_WIRE_HEARTBEAT_REPORT.md',
    'docs/superpowers/specs/2026-10-08-wire-heartbeat-dispatch-design.md',
    'docs/superpowers/plans/2026-10-08-wire-heartbeat-dispatch.md',
    'tools/benchmark/openvins_timesync_wire.py',
    'tools/benchmark/openvins_wire_bootstrap.py',
    'tools/benchmark/openvins_observed_wire_session.py',
    'tools/benchmark/openvins_datagram_receive.py',
    'tools/benchmark/openvins_simulation_clock.py',
    'tools/benchmark/openvins_ekf2_disarmed_preflight.py',
    'tools/benchmark/capture_disarmed_sensors.py',
    'tests/benchmark/test_openvins_wire_heartbeat.py',
    'tests/benchmark/test_openvins_timesync_wire.py',
    'tests/benchmark/test_openvins_observed_wire_session.py',
    'tests/benchmark/test_openvins_wire_bootstrap.py',
    'tests/benchmark/check_openvins_owned_bootstrap.py',
]]
members = {}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as sealed:
    for path in sorted(set(files)):
        name = path.relative_to(root).as_posix()
        raw = path.read_bytes()
        sealed.writestr(name, raw)
        members[name] = dict(bytes=len(raw), sha256=digest(raw))
with zipfile.ZipFile(archive) as sealed:
    assert sealed.testzip() is None
    assert len(sealed.namelist()) == len(members)
    for name, expected in members.items():
        assert digest(sealed.read(name)) == expected['sha256']
value = dict(archive=archive.name, sha256=digest(archive.read_bytes()), bytes=archive.stat().st_size,
             members=members, production_commit='3944962d3ee6611db9e542179c8579d1b8923337',
             source_copy_basis='post-test current bytes; selected export pre/post hashes separate',
             network_authorized=False, fusion_qualified=False)
with manifest.open('x', encoding='utf-8') as target:
    json.dump(value, target, indent=2)
print(json.dumps({k: v for k, v in value.items() if k != 'members'}))
print('members', len(members))
