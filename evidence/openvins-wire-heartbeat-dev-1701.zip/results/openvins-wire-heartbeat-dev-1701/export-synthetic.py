import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root))
from tests.benchmark.test_openvins_wire_heartbeat import HeartbeatTests
from pymavlink.dialects.v20 import common

out = Path(__file__).resolve().parent / 'synthetic-v1'
out.mkdir(exist_ok=False)
cases = ['test_mixed_frames_decode_once_and_dispatch_before_send',
         'test_existing_capture_dispatch_receives_exact_same_event',
         'test_armed_refused_before_dispatch_or_mixed_reply',
         'test_return_evidence_slot_required_before_callback',
         'test_failure_after_callback_is_not_rolled_back_or_retried']
files = ['tools/benchmark/openvins_timesync_wire.py', 'tools/benchmark/openvins_wire_bootstrap.py',
         'tools/benchmark/openvins_observed_wire_session.py', 'tools/benchmark/capture_disarmed_sensors.py',
         'tests/benchmark/test_openvins_wire_heartbeat.py',
         'tests/benchmark/test_openvins_observed_wire_session.py',
         'tests/benchmark/test_openvins_wire_bootstrap.py',
         'tests/benchmark/check_openvins_owned_bootstrap.py']
def hashes():
    paths = {p: root / p for p in files}
    paths.update(exporter=Path(__file__), installed_codec=Path(common.__file__))
    return {k: hashlib.sha256(v.read_bytes()).hexdigest() for k, v in paths.items()}
def save(name, value):
    with (out / name).open('x', encoding='utf-8') as target:
        json.dump(value, target, indent=2, sort_keys=True)

pre = hashes()
save('predeclared.json', dict(cases=cases, source_hashes=pre, producer_commit=sys.argv[1],
                            synthetic_owner_clock_socket=True, actual_network=False, fusion=False))
rows = []
for name in cases:
    fixture = HeartbeatTests(name)
    fixture.setUp()
    outcome = 'incomplete'
    try:
        getattr(fixture, name)()
        outcome = 'assertions_passed'
    except BaseException as exc:
        outcome = type(exc).__name__ + ':' + str(exc)
        raise
    finally:
        f = fixture.f
        save(name + '.json', dict(outcome=outcome, delivered=fixture.delivered,
                                 session=f.obj.evidence, forwarded=f.events,
                                 synthetic_sends=[dict(raw_hex=raw.hex(), flags=flags, peer=peer)
                                                  for raw, flags, peer in f.sock.sent]))
        rows.append(dict(case=name, outcome=outcome, delivered=len(fixture.delivered), sends=len(f.sock.sent)))
post = hashes()
save('post.json', dict(source_hashes=post, stable=pre == post, cases=rows))
assert pre == post
print(json.dumps(rows))
