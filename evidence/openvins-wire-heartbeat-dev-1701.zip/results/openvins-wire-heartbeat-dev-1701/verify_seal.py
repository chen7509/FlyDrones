import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[2]
m = json.loads((root / 'evidence/openvins-wire-heartbeat-seal.json').read_text())
p = root / 'evidence' / m['archive']
assert hashlib.sha256(p.read_bytes()).hexdigest() == m['sha256']
with zipfile.ZipFile(p) as z:
    assert z.testzip() is None and set(z.namelist()) == set(m['members'])
    for name, row in m['members'].items():
        raw = z.read(name)
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
    prefix = 'results/openvins-wire-heartbeat-dev-1701/synthetic-v1/'
    pre = json.loads(z.read(prefix + 'predeclared.json'))
    post = json.loads(z.read(prefix + 'post.json'))
    assert pre['source_hashes'] == post['source_hashes'] and post['stable']
    assert [r['case'] for r in post['cases']] == pre['cases']
    assert [(r['delivered'], r['sends']) for r in post['cases']] == [(1,1), (1,0), (0,0), (0,0), (1,0)]
    for row in post['cases']:
        sample = json.loads(z.read(prefix + row['case'] + '.json'))
        assert sample['outcome'] == row['outcome'] == 'assertions_passed'
        assert len(sample['delivered']) == row['delivered']
        assert len(sample['synthetic_sends']) == row['sends']
        assert not sample['session']['network_authorized'] and not sample['session']['fusion_qualified']
print('CRC/members and five synthetic cases verified:', len(m['members']))
