import hashlib
import inspect
import json
from pathlib import Path
from pymavlink import mavutil

out = Path(__file__).resolve().parent
path = Path(mavutil.__file__)
source = path.read_bytes()
with (out / 'mavutil-installed.py.txt').open('xb') as f:
    f.write(source)
items = {name: inspect.getsource(value) for name, value in {
    'mavfile.recv_match': mavutil.mavfile.recv_match,
    'mavfile.recv_msg': mavutil.mavfile.recv_msg,
    'mavudp.recv': mavutil.mavudp.recv,
    'mavudp.__init__': mavutil.mavudp.__init__,
}.items()}
with (out / 'installed-receive.json').open('x') as f:
    json.dump(dict(path=str(path), sha256=hashlib.sha256(source).hexdigest(), methods=items,
                   socket_created=False, packet_received=False), f, indent=2)
print(json.dumps(dict(sha256=hashlib.sha256(source).hexdigest(), methods=list(items))))
