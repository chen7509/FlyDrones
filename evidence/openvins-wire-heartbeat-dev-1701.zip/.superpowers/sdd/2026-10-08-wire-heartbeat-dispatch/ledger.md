# SDD ledger — plan: docs/superpowers/plans/2026-10-08-wire-heartbeat-dispatch.md

Base62b19fa476fcc7c82de8fdca98a0e93023fd7bee. Implementation3944962d3ee6611db9e542179c8579d1b8923337.
Initial17 RED errors are missing keyword API, not behavioral assertion failures; initial17 GREEN actual-codec composition. Expanded21 yielded one real capacity assertion failure (callback delivered with no return-log slot); fixed by reserving capacity before callback. Related WSL111OK. Windows115passed/4codec skips. Changed Ruff/diff pass.
Installed source capture confirms recv_match discards unmatched frames; no socket/process/physics instantiated. Current worker unchanged; actual single-reader mode is not yet bound.
Independent reviewer /root/review_wire_heartbeat active under executing-plans one-review requirement.
Ruling: preserve historical/current evidence workspace — explicit user requirement overrides cleanup — cost retained disk space.
Ruling: run related boundary/codec regressions instead of unrelated whole repository — developer requires testing appropriate to change — cost no new unrelated full-suite result.

Final review completed: no Critical/Important. Independent21OK, diffcheck pass. No re-review needed.
Final: minor (deferred): actual dispatch_heartbeat test covers queued writer, not JournaledHeartbeatFanout; report makes scope explicit; fanout integration test is next dependency before actual capture mode.
Five predeclared synthetic exports passed with selected source/codec pre/post hashes identical; mixed1/1, writer1/0, armed0/0, capacity0/0, partial return failure1/0 delivery/send counts. No actual sockets/process/physics.
