"""Seal the opt-in startup observer handshake evidence."""

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "evidence/live-wire-px4-startup-handshake-dev-1701.zip"
FILES = (
    "docs/LIVE_WIRE_FIRST_ACTIVATION_REPORT.md",
    "tools/benchmark/observe_px4_startup.py",
    "tests/benchmark/test_px4_startup_observer.py",
    "results/live-wire-px4-startup-handshake-dev-1701/posix_probe.py",
    "results/live-wire-px4-startup-handshake-dev-1701/targeted-tests.txt",
    "results/live-wire-px4-startup-handshake-dev-1701/wsl-posix-probe.txt",
    "results/live-wire-px4-startup-handshake-dev-1701/seal.py",
)

raw = {name: (ROOT / name).read_bytes() for name in FILES}
manifest = {
    "schema": "flydrones-px4-startup-handshake-evidence-v1",
    "members": [
        {"path": name, "bytes": len(raw[name]), "sha256": hashlib.sha256(raw[name]).hexdigest()}
        for name in sorted(raw)
    ],
    "physical_run": False,
    "observer_integrated_with_capture": False,
}
with zipfile.ZipFile(OUT, "x", compression=zipfile.ZIP_DEFLATED) as archive:
    for name in sorted(raw):
        archive.writestr(name, raw[name])
    archive.writestr("MANIFEST.json", json.dumps(manifest, indent=2, sort_keys=True) + "\n")
with zipfile.ZipFile(OUT) as archive:
    assert archive.testzip() is None
    for member in manifest["members"]:
        value = archive.read(member["path"])
        assert len(value) == member["bytes"]
        assert hashlib.sha256(value).hexdigest() == member["sha256"]
print(json.dumps({"archive": str(OUT), "members": len(raw) + 1,
                  "bytes": OUT.stat().st_size,
                  "sha256": hashlib.sha256(OUT.read_bytes()).hexdigest()}))
