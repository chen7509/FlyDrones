"""Bounded WSL-only handshake check; starts no PX4 or simulator."""

import json
import tempfile
from pathlib import Path

from tools.benchmark.observe_px4_startup import observe_px4_startup


with tempfile.TemporaryDirectory(prefix="flydrones-startup-handshake-") as directory:
    root = Path(directory)
    log = root / "px4.log"
    output = root / "observed.json"
    ready = []

    def on_ready():
        assert not log.exists()
        ready.append(True)
        log.write_text("INFO Startup script returned successfully\n", encoding="utf8")

    result = observe_px4_startup(log, output, max_wall_ns=1_000_000_000, on_ready=on_ready)
    assert ready == [True]
    assert result["status"] == "startup_completed"
    assert json.loads(output.read_text(encoding="utf8")) == result
    print("wsl_posix_handshake_passed")
