"""Live sensor evidence primitives; no estimator, flight commands or fusion permission."""

from __future__ import annotations

import hashlib
import json
import math
import os
import queue
import re
import subprocess
import threading
import time
from collections import Counter
from pathlib import Path

import numpy as np

from flydrones.benchmark.camera_info_capture import CameraInfoRecorder
from flydrones.benchmark.rgb_capture import RgbFrameRecorder
from tools.benchmark.capture_contract import materialize_launch_environment, validate_launch_environment
from tools.benchmark.declared_runtime_snapshot import write_manifest


def validate_event(event, *, allow_legacy_info=False):
    common = {"kind", "arrival_monotonic_ns", "observed_sim_ns"}
    fields = {
        "imu": {"sample_ns", "gyro_flu", "accel_flu"},
        "rgb": {"sample_ns", "width", "height"},
        "depth": {"sample_ns", "width", "height"},
        "info": {"camera_info", "sample_ns"},
        "heartbeat": {"system_id", "base_mode", "custom_mode"},
    }
    kind = event.get("kind")
    if allow_legacy_info and kind == "info" and "sample_ns" not in event:
        fields["info"] = {"camera_info"}
    if kind not in fields or set(event) != common | fields[kind]:
        raise ValueError("unexpected sensor event fields")
    for key in ["arrival_monotonic_ns", "observed_sim_ns"] + (["sample_ns"] if "sample_ns" in event else []):
        if type(event[key]) is not int or event[key] < (0 if key == "observed_sim_ns" else 1):
            raise ValueError("invalid event clock")
    result = dict(event)
    if "sample_ns" in event:
        result["sim_age_at_callback_ns"] = event["observed_sim_ns"] - event["sample_ns"]
    if kind == "imu":
        for source, target in [("gyro_flu", "gyro_frd"), ("accel_flu", "accel_frd")]:
            values = event[source]
            if (
                not isinstance(values, (list, tuple))
                or len(values) != 3
                or any(type(v) not in (int, float) or not math.isfinite(v) for v in values)
            ):
                raise ValueError("invalid IMU vector")
            result[source] = list(values)
            result[target] = [values[0], -values[1], -values[2]]
    if kind in ("rgb", "depth") and (event["width"] != 160 or event["height"] != 120):
        raise ValueError("unexpected sensor resolution")
    if kind == "heartbeat":
        if any(type(event[k]) is not int for k in ("system_id", "base_mode", "custom_mode")):
            raise ValueError("invalid heartbeat")
        if event["base_mode"] & 128:
            raise ValueError("armed heartbeat during disarmed capture")
    return result


def verify_depth_manifest(output):
    """Check exact in-root depth source bytes; do not interpret or qualify pixels."""
    output = Path(output)

    def unique(pairs):
        row = {}
        for key, value in pairs:
            if key in row:
                raise ValueError("duplicate depth manifest key")
            row[key] = value
        return row

    manifest_path = output / "depth-payload-manifest.json"
    if manifest_path.is_symlink() or not manifest_path.is_file():
        raise ValueError("depth manifest missing or linked")
    if manifest_path.stat().st_size > 262_144:
        raise ValueError("depth manifest too large")
    value = json.loads(manifest_path.read_text(encoding="utf-8"), object_pairs_hook=unique)
    if (type(value) is not dict or value.keys() != {"schema", "frames"}
            or value["schema"] != "flydrones-depth-payload-v1"
            or type(value["frames"]) is not list or len(value["frames"]) > 512):
        raise ValueError("depth manifest schema invalid")
    directory = output / "depth-messages"
    if directory.is_symlink() or (directory.exists() and not directory.is_dir()):
        raise ValueError("depth directory invalid")
    selected = set()
    last = -1
    for frame in value["frames"]:
        if type(frame) is not dict or frame.keys() != {"sample_ns", "path", "bytes", "sha256"}:
            raise ValueError("depth frame schema invalid")
        stamp, length, digest = frame["sample_ns"], frame["bytes"], frame["sha256"]
        if (type(stamp) is not int or stamp <= last
                or frame["path"] != f"depth-messages/{stamp}.pb"
                or type(length) is not int or not 0 < length <= 131_072
                or type(digest) is not str or re.fullmatch(r"[0-9a-f]{64}", digest) is None):
            raise ValueError("depth frame identity invalid")
        file = output / frame["path"]
        if file.is_symlink() or file.parent.is_symlink() or not file.is_file():
            raise ValueError("depth frame missing or linked")
        if file.stat().st_size != length:
            raise ValueError("depth frame size changed")
        payload = file.read_bytes()
        if len(payload) != length or hashlib.sha256(payload).hexdigest() != digest:
            raise ValueError("depth frame bytes changed")
        selected.add(file.name)
        last = stamp
    actual = {item.name for item in directory.iterdir()} if directory.exists() else set()
    if actual != selected:
        raise ValueError("depth directory has missing or undeclared files")
    events_path = output / "events.jsonl"
    if events_path.is_symlink() or not events_path.is_file():
        raise ValueError("sensor event journal missing or linked")
    recorded = []
    with events_path.open(encoding="utf-8") as stream:
        while True:
            line = stream.readline(1_048_577)
            if not line:
                break
            if len(line) > 1_048_576 or not line.endswith("\n"):
                raise ValueError("invalid sensor event journal line")
            row = json.loads(line, object_pairs_hook=unique)
            if type(row) is not dict:
                raise ValueError("invalid sensor event row")
            if row.get("kind") == "depth":
                base = {key: item for key, item in row.items() if key != "source_sequence"}
                audit_event_records([base], required_kinds=[])
                recorded.append(dict(sample_ns=row["sample_ns"], path=row.get("payload_path"),
                                     bytes=row.get("payload_bytes"), sha256=row.get("payload_sha256")))
    if recorded != value["frames"]:
        raise ValueError("depth events differ from payload manifest")
    return value


class CaptureWriter:
    def __init__(
        self,
        output,
        *,
        capacity=4096,
        start_worker=True,
        on_record=None,
        on_idle=None,
        idle_period_s=0.05,
        sequence_records=False,
        record_depth_payload=False,
    ):
        if type(capacity) is not int or capacity < 1:
            raise ValueError("invalid queue capacity")
        if on_idle is not None and (
            not callable(on_idle)
            or type(idle_period_s) not in (int, float)
            or not math.isfinite(idle_period_s)
            or idle_period_s <= 0
        ):
            raise ValueError("invalid idle callback configuration")
        self.output = output
        self.stream = (output / "events.jsonl").open("x", encoding="utf8")
        self.rgb = RgbFrameRecorder(output)
        self.info = CameraInfoRecorder(output, topic="/benchmark/rgbd/camera_info")
        self.queue = queue.Queue(capacity)
        self.lock = threading.Lock()
        self.delivery_lock = threading.Lock()
        self.last = {}
        self.written = Counter()
        self.error = None
        self.closed = False
        self.thread = None
        self.max_queue = 0
        self.on_record = on_record
        self.on_idle = on_idle
        self.idle_period_s = idle_period_s
        self.sequence_records = sequence_records
        self.record_depth_payload = record_depth_payload
        self.depth_frames = []
        self.source_sequence = 0
        if start_worker:
            self.start()

    def start(self):
        if self.thread is not None:
            raise RuntimeError("writer already started")
        self.thread = threading.Thread(target=self._worker, daemon=True)
        self.thread.start()

    def latch_failure(self, exc):
        """Stop future source delivery and wait for any already active delivery."""
        with self.lock:
            if self.error is None:
                self.error = repr(exc)
            try:
                self.queue.put_nowait(None)
            except queue.Full:
                pass
        with self.delivery_lock:
            pass

    def submit(self, event, payload=None):
        row = validate_event(event)
        if row["kind"] == "rgb" and (not isinstance(payload, bytes) or len(payload) != 160 * 120 * 3):
            raise ValueError("invalid RGB payload")
        if row["kind"] == "info" and (not isinstance(payload, bytes) or not payload):
            raise ValueError("invalid camera info payload")
        if row["kind"] == "depth":
            if self.record_depth_payload:
                if type(payload) is not bytes or not 0 < len(payload) <= 131_072:
                    raise ValueError("invalid depth payload")
            elif payload is not None:
                raise ValueError("unexpected depth payload")
        with self.lock:
            if self.closed or self.error:
                raise RuntimeError("writer unavailable: " + str(self.error))
            kind = row["kind"]
            if "sample_ns" in row and row["sample_ns"] <= self.last.get(kind, -1):
                raise ValueError("duplicate/regressed " + kind + " timestamp")
            try:
                self.queue.put_nowait((row, payload))
            except queue.Full as exc:
                raise RuntimeError("capture queue overflow") from exc
            if "sample_ns" in row:
                self.last[kind] = row["sample_ns"]
            self.max_queue = max(self.max_queue, self.queue.qsize())

    def _write_event(self, row, payload):
        if self.sequence_records:
            row["source_sequence"] = self.source_sequence
            self.source_sequence += 1
        row["writer_begin_monotonic_ns"] = time.monotonic_ns()
        if row["kind"] == "rgb":
            accepted = self.rgb.add(row["sample_ns"], np.frombuffer(payload, dtype=np.uint8).reshape(120, 160, 3))
            if not accepted:
                raise ValueError("RGB recorder rejected frame")
        if row["kind"] == "info":
            self.info.add(row["camera_info"], payload)
            directory = self.output / "camera-info-messages"
            directory.mkdir(exist_ok=True)
            relative = "camera-info-messages/" + str(row["sample_ns"]) + ".pb"
            with (self.output / relative).open("xb") as stream:
                stream.write(payload)
            row["payload_path"] = relative
            row["payload_sha256"] = hashlib.sha256(payload).hexdigest()
        if row["kind"] == "depth" and self.record_depth_payload:
            directory = self.output / "depth-messages"
            if directory.is_symlink() or (directory.exists() and not directory.is_dir()):
                raise ValueError("depth directory linked or invalid")
            directory.mkdir(exist_ok=True)
            if directory.is_symlink() or directory.resolve().parent != self.output.resolve():
                raise ValueError("depth directory escaped output root")
            relative = "depth-messages/" + str(row["sample_ns"]) + ".pb"
            with (self.output / relative).open("xb") as stream:
                if stream.write(payload) != len(payload):
                    raise OSError("short depth payload write")
                stream.flush()
            row["payload_path"] = relative
            row["payload_bytes"] = len(payload)
            row["payload_sha256"] = hashlib.sha256(payload).hexdigest()
            self.depth_frames.append(dict(sample_ns=row["sample_ns"], path=relative,
                                          bytes=len(payload), sha256=row["payload_sha256"]))
        # This is record preparation time, not filesystem durability or sensor-generation wall time.
        row["recorded_monotonic_ns"] = time.monotonic_ns()
        encoded = json.dumps(row, allow_nan=False) + "\n"
        if self.stream.write(encoded) != len(encoded):
            raise OSError("short sensor event write")
        self.written[row["kind"]] += 1
        if self.on_record is not None:
            self.stream.flush()
            with self.delivery_lock:
                if self.error:
                    raise RuntimeError("writer failed before source delivery: " + self.error)
                self.on_record(dict(row), None if row["kind"] == "depth" else payload)

    def _worker(self):
        try:
            while True:
                try:
                    item = self.queue.get(timeout=self.idle_period_s if self.on_idle is not None else None)
                except queue.Empty:
                    # Holding the submit lock makes this an observed empty FIFO boundary.
                    # The callback runs on the same single-owner thread as on_record.
                    with self.lock:
                        if not self.closed and not self.error and self.queue.empty():
                            self.on_idle(time.monotonic_ns())
                    continue
                if item is None:
                    break
                if self.error:
                    break
                self._write_event(*item)
        except BaseException as exc:
            if self.error is None:
                self.error = repr(exc)
        finally:
            try:
                self.stream.close()
            except OSError as exc:
                if self.error is None:
                    self.error = repr(exc)

    def finish(self):
        with self.lock:
            self.closed = True
        if self.thread is None:
            self.start()
        deadline = time.monotonic() + 30
        while not self.error:
            try:
                self.queue.put(None, timeout=0.1)
                break
            except queue.Full:
                if time.monotonic() >= deadline:
                    raise TimeoutError("writer drain timeout") from None
        self.thread.join(timeout=30)
        if self.thread.is_alive():
            raise TimeoutError("writer did not finish")
        if self.error:
            raise RuntimeError(self.error)
        rgb, info = self.rgb.finish(), self.info.finish()
        summary = {
            "written": dict(self.written),
            "max_queue_depth": self.max_queue,
            "rgb": rgb,
            "camera_info": info,
            "timing_scope": "callback arrival to record preparation, not end-to-end latency",
        }
        if self.record_depth_payload:
            depth = {"schema": "flydrones-depth-payload-v1", "frames": self.depth_frames}
            encoded = json.dumps(depth, indent=2) + "\n"
            with (self.output / "depth-payload-manifest.json").open("x", encoding="utf-8") as stream:
                if stream.write(encoded) != len(encoded):
                    raise OSError("short depth manifest write")
                stream.flush()
            verify_depth_manifest(self.output)
            summary["depth_payload"] = depth
        return summary


def compare_imu(imu_rows, px4_us, px4_gyro, px4_accel):
    """Nearest raw-time diagnostic only. No timestamp offset fitting or equivalence grant."""
    raw_us = np.array([r["sample_ns"] / 1000 for r in imu_rows])
    px4_us = np.asarray(px4_us)
    gyro, accel = np.asarray(px4_gyro), np.asarray(px4_accel)
    if (
        len(raw_us) < 2
        or len(px4_us) < 2
        or gyro.shape != (len(px4_us), 3)
        or accel.shape != gyro.shape
        or not np.isfinite(gyro).all()
        or not np.isfinite(accel).all()
        or not np.all(np.diff(raw_us) > 0)
        or not np.all(np.diff(px4_us) > 0)
    ):
        raise ValueError("invalid IMU comparison inputs")
    indices = np.searchsorted(raw_us, px4_us)
    indices = np.clip(indices, 1, len(raw_us) - 1)
    before = indices - 1
    use_before = abs(raw_us[before] - px4_us) <= abs(raw_us[indices] - px4_us)
    nearest = np.where(use_before, before, indices)
    valid = (px4_us >= raw_us[0]) & (px4_us <= raw_us[-1] + 4000) & (abs(px4_us - raw_us[nearest]) <= 4000)
    if not np.any(valid):
        raise ValueError("no temporally overlapping IMU samples")
    paired = nearest[valid]
    raw_g = np.array([r["gyro_flu"] for r in imu_rows]) * [1, -1, -1]
    raw_a = np.array([r["accel_flu"] for r in imu_rows]) * [1, -1, -1]
    g_error, a_error = abs(gyro[valid] - raw_g[paired]), abs(accel[valid] - raw_a[paired])
    return {
        "paired_samples": int(valid.sum()),
        "unpaired_px4_samples": int((~valid).sum()),
        "reused_raw_indices": int(len(paired) - len(set(paired))),
        "median_px4_minus_gz_us": float(np.median(px4_us[valid] - raw_us[paired])),
        "gyro_absolute_error_max": float(g_error.max()),
        "accel_absolute_error_max": float(a_error.max()),
        "gyro_absolute_error_median": float(np.median(g_error)),
        "accel_absolute_error_median": float(np.median(a_error)),
        "source_equivalence_qualified": False,
        "method": "nearest sample timestamp within4ms; no offset fitting; PX4 callback timestamp/integration differ",
    }


def audit_event_records(rows, *, required_kinds, allow_legacy_info=False):
    """Recheck recorded clocks, transforms and completeness before using diagnostics."""
    generated = {
        "gyro_frd",
        "accel_frd",
        "sim_age_at_callback_ns",
        "writer_begin_monotonic_ns",
        "recorded_monotonic_ns",
        "payload_path",
        "payload_bytes",
        "payload_sha256",
    }
    counts = Counter()
    last_sample = {}
    last_recorded = 0
    for row in rows:
        base = {k: v for k, v in row.items() if k not in generated}
        expected = validate_event(base, allow_legacy_info=allow_legacy_info)
        if row["kind"] == "info" and "sample_ns" in row:
            digest = row.get("payload_sha256", "")
            if not isinstance(digest, str) or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
                raise ValueError("invalid camera info payload digest")
            expected.update(payload_path="camera-info-messages/" + str(row["sample_ns"]) + ".pb", payload_sha256=digest)
        if row["kind"] == "depth" and any(k in row for k in ("payload_path", "payload_bytes", "payload_sha256")):
            digest, length = row.get("payload_sha256"), row.get("payload_bytes")
            if (row.get("payload_path") != f"depth-messages/{row['sample_ns']}.pb"
                    or type(length) is not int or not 0 < length <= 131_072
                    or type(digest) is not str or re.fullmatch(r"[0-9a-f]{64}", digest) is None):
                raise ValueError("invalid depth payload identity")
            expected.update(payload_path=row["payload_path"], payload_bytes=length,
                            payload_sha256=digest)
        begin, end = row.get("writer_begin_monotonic_ns"), row.get("recorded_monotonic_ns")
        if (
            type(begin) is not int
            or type(end) is not int
            or begin < row["arrival_monotonic_ns"]
            or end < begin
            or begin < last_recorded
        ):
            raise ValueError("recorded wall-clock ordering invalid")
        expected.update(writer_begin_monotonic_ns=begin, recorded_monotonic_ns=end)
        if expected != row:
            raise ValueError("changed derived fields or unexpected record data")
        kind = row["kind"]
        if "sample_ns" in row:
            if row["sample_ns"] <= last_sample.get(kind, -1):
                raise ValueError("duplicate/regressed recorded sample")
            last_sample[kind] = row["sample_ns"]
        last_recorded = end
        counts[kind] += 1
    if not set(required_kinds) <= set(counts):
        raise ValueError("required sensor stream missing")
    return dict(counts)


class CaptureJournal:
    """Run all registered owned-resource cleanups and attempt a terminal result."""

    def __init__(self, output, result):
        self.output, self.result = output, result
        self.callbacks = []

    def __enter__(self):
        return self

    def cleanup(self, label, callback, *, priority):
        self.callbacks.append((priority, label, callback))

    def __exit__(self, kind, value, traceback):
        def describe(exc):
            try:
                return repr(exc)
            except BaseException:
                return '<unprintable exception>'

        interruption = value if value is not None and not isinstance(value, Exception) else None
        if value is not None:
            self.result["errors"].append(describe(value))
        for _, label, callback in sorted(self.callbacks, key=lambda item: item[0]):
            try:
                callback()
            except BaseException as exc:
                self.result["errors"].append(label + ": " + describe(exc))
                if interruption is None and not isinstance(exc, Exception):
                    interruption = exc
        if self.result["errors"] or self.result["status"] != "capture_completed":
            self.result["status"] = "capture_failed"
        try:
            with (self.output / "result.json").open("x") as stream:
                json.dump(self.result, stream, indent=2)
        except BaseException as exc:
            self.result['status'] = 'capture_failed'
            self.result['errors'].append('terminal result: ' + describe(exc))
            if interruption is not None:
                raise interruption from exc
            raise
        if interruption is not None:
            raise interruption
        return value is not None


def terminate_owned_group(worker):
    """Only the supervisor's registered, unreaped leader authorizes group cleanup."""
    evidence = getattr(worker, "_owned_group_evidence", None)
    if evidence is None:
        raise ValueError("unregistered owned process group")
    return evidence.terminate()


def record_supervisor_environment(output, launch_environment, execution_contract):
    declared = validate_launch_environment(launch_environment)
    materialized = materialize_launch_environment(declared)
    contract = Path(execution_contract).resolve(strict=True)
    before = contract.stat()
    payload = contract.read_bytes()
    after = contract.stat()
    if before != after:
        raise ValueError("execution contract changed while recording launch environment")
    record = {
        "schema": "supervisor-launch-environment-v1",
        "declared": declared,
        "materialized": materialized,
        "execution_contract": {
            "path": str(contract), "bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest(),
        },
        "ambient_inherited": False,
        "runtime_environment_qualified": False,
        "physics_qualified": False,
        "fusion_eligible": False,
    }
    output = Path(output)
    write_manifest(output.with_name(output.name + ".supervisor-environment.json"), record)
    return materialized


def supervise_worker(command, output, *, timeout_s=300, spawn=None, terminate=None,
                     launch_environment=None, execution_contract=None):
    if output.exists():
        raise FileExistsError(output)
    real = spawn is None and terminate is None
    if (spawn is None) != (terminate is None):
        raise ValueError("synthetic spawn and terminate must be paired")
    if spawn is None:
        if os.name != "posix":
            raise RuntimeError("physical capture supervisor requires POSIX process groups")

        def spawn(command, **kwargs):
            return subprocess.Popen(command, start_new_session=True, **kwargs)

    terminate = terminate or terminate_owned_group
    evidence, stream = None, None
    if real:
        from tools.benchmark.owned_group_evidence import GroupEvidence

        output.parent.mkdir(parents=True, exist_ok=True)
        stream = output.with_name(output.name + ".supervisor-events.jsonl").open("x")
    if (launch_environment is None) != (execution_contract is None):
        if stream:
            stream.close()
        raise ValueError("launch environment and execution contract required together")
    child_environment = None
    if launch_environment is not None:
        try:
            child_environment = record_supervisor_environment(output, launch_environment, execution_contract)
        except Exception:
            if stream:
                stream.close()
            raise
    try:
        worker = spawn(command, **({"env": child_environment} if child_environment is not None else {}))
    except Exception:
        if stream:
            stream.close()
        raise
    if real:
        evidence = GroupEvidence(worker, stream)
        worker._owned_group_evidence = evidence
    status = "worker_exited"
    supervisor_errors = []
    if evidence:
        from tools.benchmark.owned_group_evidence import finish_owned_worker

        observed = finish_owned_worker(worker, evidence, timeout_s)
        status, code = observed["status"], observed["worker_exit"]
        supervisor_errors, cleanup = observed["errors"], observed["cleanup"]
    else:
        try:
            code = worker.wait(timeout=timeout_s)
        except subprocess.TimeoutExpired:
            status = "supervisor_timeout"
            terminate(worker)
            code = worker.wait(timeout=5)
        else:
            terminate(worker)
        cleanup = dict(scope="synthetic injected lifecycle", graceful_group_cleanup_verified=False)
    output.mkdir(parents=True, exist_ok=True)
    summary = {
        "status": status,
        "worker_pid": worker.pid,
        "worker_exit": code,
        "timeout_s": timeout_s,
        "cleanup": cleanup,
        "errors": supervisor_errors,
        "event_journal": "../" + output.name + ".supervisor-events.jsonl" if real else None,
    }
    if not (output / "result.json").exists():
        with (output / "result.json").open("x") as stream:
            json.dump(
                {
                    "status": "capture_failed",
                    "errors": [status + ": worker left no terminal result"],
                    "estimator_run": False,
                    "eligible_for_px4_fusion": False,
                },
                stream,
                indent=2,
            )
    try:
        summary["capture_status"] = json.loads((output / "result.json").read_text())["status"]
    except Exception as exc:
        summary["capture_status"] = "invalid_result"
        summary["errors"].append(repr(exc))
    with (output / "supervisor.json").open("x") as stream:
        encoded = json.dumps(summary, indent=2, allow_nan=False)
        if stream.write(encoded) != len(encoded):
            raise OSError("short supervisor summary write")
        stream.flush()
    return summary
