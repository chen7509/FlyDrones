Read-only listener transport

Design98cc705; implementationbf2c9dd. Existing ordinary fixtures only; no live PX4 authority.
Initial import-error RED then31pass. Three own behavioral boundary REDs fixed before34pass. Independent review3Important produced5RED then39pass; follow-up event-capacity race produced2RED then41pass in a8790ce. Re-review and private7case fixture pending; full regression/report/seal pending.

Final review: no Critical/Important/Minor. Kernel producerd593a8b7cases completed3success4expected refusal, all7owned servers exit0/no signals, selected source/fixture/Python hashes stable. Journal/in-memory equality checked. Full3166passed/3skipped/2existing warnings336.46s exit0. Changed Ruff/diff passed. Post-run source exports match prospective hashes. Report/evidence separately reviewed read-only. Seal/publication pending. Overall goal active; live/fusion gate false.
