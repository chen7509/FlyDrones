import hashlib
import json
import re
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
sha=lambda data:hashlib.sha256(data).hexdigest()
archive=ROOT/'evidence/openvins-listener-transport-dev-1701.zip'
external=archive.with_name('openvins-listener-transport-dev-1701-manifest.json')
assert not archive.exists() and not external.exists()
assert (OUT/'full-tests-exit.txt').read_text().strip()=='0'
assert re.search(r'3166 passed, 3 skipped, 2 warnings in',(OUT/'full-tests.txt').read_text())
assert sha((ROOT/'evidence/owned-daemon-connection-dev-1701.zip').read_bytes())=='5e55873197951f6d83e912c60dfa01519e346f1252c4152d6b8e47e4e8e00f40'
matrix=json.loads((OUT/'kernel-v1/summary.json').read_text())
assert matrix['complete'] and matrix['files_stable'] and len(matrix['results'])==7
assert sum(x['evidence']['transport_complete'] for x in matrix['results'])==3
for case in matrix['results']:
    proof=case['evidence']
    assert not any(proof[k] for k in ('network_authorized','fusion_qualified','live_listener_qualified'))
    assert case['harness_error'] is None and case['cleanup']['exit']==0 and case['cleanup']['signals']==[]
    server=json.loads((OUT/'kernel-v1'/case['case']/'server.json').read_text())
    assert server['eof'] and server['error'] is None
    events=[json.loads(p.read_text()) for p in sorted((OUT/'kernel-v1'/case['case']).glob('event-*.json'))]
    assert events==proof['events']
prospective=json.loads((OUT/'kernel-v1/prospective.json').read_text())
assert prospective['files']==json.loads((OUT/'kernel-v1/post-hashes.json').read_text())
paths=sorted(p for p in OUT.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
paths += [ROOT/p for p in (
    'tools/benchmark/openvins_listener_transport.py',
    'tests/benchmark/test_openvins_listener_transport.py','tests/benchmark/check_openvins_listener_transport.py',
    'docs/OPENVINS_LISTENER_TRANSPORT_REPORT.md',
    'docs/superpowers/specs/2026-10-08-readonly-listener-transport-design.md',
    'docs/superpowers/plans/2026-10-08-readonly-listener-transport.md',
    '.superpowers/sdd/2026-10-08-readonly-listener-transport/progress.md')]
payload={p.relative_to(ROOT).as_posix():p.read_bytes() for p in paths}
assert len(paths)==len(payload)
manifest=dict(schema='evidence-members-v1',producer='d593a8b',
    members=[dict(path=name,bytes=len(data),sha256=sha(data)) for name,data in sorted(payload.items())],
    physical_network_qualified=False,fusion_qualified=False,
    scope='private ordinary AF_UNIX listener command fixtures; no actual PX4/MAVLink')
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in payload.items():z.writestr(name,data)
    z.writestr('member-manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for member in manifest['members']:
        data=z.read(member['path'])
        assert len(data)==member['bytes'] and sha(data)==member['sha256']
    count=len(z.namelist())
result=dict(archive=archive.relative_to(ROOT).as_posix(),sha256=sha(archive.read_bytes()),
    bytes=archive.stat().st_size,members=count,crc_verified=True,member_hashes_verified=True,
    historical_archive_unchanged=True)
with external.open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
print(json.dumps(result))
