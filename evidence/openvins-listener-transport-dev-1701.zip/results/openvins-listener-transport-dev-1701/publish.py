import json
import re
import subprocess
from pathlib import Path

out=Path(__file__).resolve().parent
root=out.parents[1]
seal=json.loads((root/'evidence/openvins-listener-transport-dev-1701-manifest.json').read_text())
body=json.loads((out/'pr-before.json').read_text(encoding='utf-8-sig'))['body'].replace('\r\n','\n')
marker='## Startup gate remains open'
addition='''The owned read-only listener transport is now implemented and tested against ordinary private AF_UNIX servers. It sends only pinned snapshot/stream listener commands on the same verified descriptor and requires zero exit trailer plus EOF. One prospectively frozen seven-case fixture completed3 normal cases and4 expected refusals, retained exact command/raw output, stable selected hashes and seven child exits0 without signals. It is not actual PX4 output, a MAVLink responder, live500-update proof or fusion authorization. Source-derived framing, return-time checks and bounded I/O evidence are in `docs/OPENVINS_LISTENER_TRANSPORT_REPORT.md`.

'''
assert marker in body
body=body.replace(marker,addition+marker)
pattern=r'Latest full regression \(owned daemon connection gate\):.*?(?=\n\nIndependent review found delayed refusal)'
replacement='''Latest full regression (owned read-only listener transport): **3166 passed, 3 skipped, 2 existing warnings**, exit0. The interface suite has **41 passing tests**. Independent review found3 Important issues, fixed after5 behavioral REDs; a follow-up concurrency/capacity boundary was fixed after2 more REDs. Final code/harness and subsequent runtime-evidence/report reviews found no remaining actionable issues. Changed Ruff and Git whitespace checks passed; no whole-repository lint pass is claimed. Kernel fixture producer d593a8b uses the final production fixes; no actual PX4/Gazebo/OpenVINS or MAVLink experiment ran. Full pytest includes existing temporary CLI smoke fixtures.'''
body,n=re.subn(pattern,replacement,body,flags=re.S)
assert n==1
body=body.replace('Latest archive:','Preceding archive:',1)
record=(f'\n- `docs/OPENVINS_LISTENER_TRANSPORT_REPORT.md`\n\nLatest archive: `{seal["archive"]}`, '
        f'SHA256 `{seal["sha256"]}`, {seal["members"]} members, CRC/member hashes verified. '
        'Kernel fixture producer d593a8b. All network/fusion/live-listener authorization flags remain false.\n')
body=body.replace('## Reports and evidence\n','## Reports and evidence\n'+record)
with (out/'pr-body.txt').open('x',encoding='utf-8',newline='\n') as f:f.write(body)
subprocess.run(['gh','pr','edit','65','--repo','chen7509/FlyDrones','--body-file',str(out/'pr-body.txt')],check=True)
raw=subprocess.check_output(['gh','pr','view','65','--repo','chen7509/FlyDrones','--json','body,headRefOid,isDraft'],text=True,encoding='utf-8')
with (out/'pr-after.json').open('x',encoding='utf-8',newline='\n') as f:f.write(raw)
actual=json.loads(raw)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert actual['headRefOid']==head and actual['isDraft'] is True
assert actual['body'].replace('\r\n','\n')==body
print('PR65 exact normalized body/draft/head verified: '+head)
