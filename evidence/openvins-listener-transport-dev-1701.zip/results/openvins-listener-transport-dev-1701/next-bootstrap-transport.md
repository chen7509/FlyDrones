Next dependency: compose owned listener transport with ColdTimesyncBootstrap under ordinary local fixtures.

Read pinned source already retained and existing state-machine/interval-transaction code. Use one prospectively fixed server owner and separate sequential snapshot/stream connections, each peer-checked on its actual descriptor. Stream must stay open across serialized updates. Every consumed row is provisional until command trailer and EOF. Feed raw stdout to existing strict decoder/bootstrap, retain frame clocks and reply intent versus actual send observations separately. No opaque token may replace kernel identity.

First define and test empty snapshot -> first reserved reply -> first snapshot -> exact latest replay counted once ->500 total accepted updates -> clean EOF. Existing8s total/2s progress bounds must be shared, not recreated per command. A local fixture can simulate status production but cannot prove actual PX4 filter updates, source/channel exclusivity, MAVLink transmission or live rate. Do not install/launch actual PX4/Gazebo/OpenVINS or modify interval/parameters at this stage. No new general process-governance work.

Missing live responder and correlated interval transaction require separate concrete design, selected dependencies and authorization. Preserve all failures and no synthetic pass can open the live/fusion gate.
