#include <px4_platform_common/module.h>
#include "topic_listener.hpp"
orb_metadata topic{"timesync_status"};
int pipes[2]; unsigned sample=0;
int orb_exists(orb_id_t, int i) { return i==0 ? 0 : -1; }
int orb_subscribe(orb_id_t) { return pipes[0]; }
int orb_subscribe_multi(orb_id_t, int) { return pipes[0]; }
int orb_unsubscribe(int) { return 0; }
int orb_set_interval(int, unsigned) { return 0; }
int listener_print_topic(orb_id_t, int fd) {
  char ch; if (read(fd,&ch,1)!=1) return -1;
  unsigned t=102000 + 20000*sample++;
  printf(" timesync_status\n    timestamp: %u (0.000001 seconds ago)\n"
    "    remote_timestamp: %u\n    observed_offset: -1000\n"
    "    estimated_offset: -1000\n    round_trip_time: 2000\n"
    "    source_protocol: 0\n\n",t,t);
  return 0;
}
void listener(const orb_id_t &, unsigned, int, unsigned);
int main(int argc,char **argv) {
  if(argc!=3) return 2;
  setvbuf(stdout,nullptr,_IONBF,0); // chosen buffering in fixture, not PX4 proof
  if(pipe(pipes)!=0 || write(pipes[1],"ab",2)!=2) return 3;
  const orb_id_t id=&topic;
  listener(id,atoi(argv[1]),atoi(argv[2]),0);
  close(pipes[0]); close(pipes[1]); return 0;
}
