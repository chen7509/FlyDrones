#pragma once
#include <uORB/topics/uORBTopics.hpp>
int orb_exists(orb_id_t, int);
int orb_subscribe(orb_id_t);
int orb_subscribe_multi(orb_id_t, int);
int orb_unsubscribe(int);
int orb_set_interval(int, unsigned);
int listener_print_topic(orb_id_t, int);
