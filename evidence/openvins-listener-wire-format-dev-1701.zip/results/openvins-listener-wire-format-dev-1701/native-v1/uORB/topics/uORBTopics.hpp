#pragma once
struct orb_metadata { const char *o_name; };
using orb_id_t = const orb_metadata *;
constexpr int ORB_MULTI_MAX_INSTANCES=4;
extern orb_metadata topic;
inline const orb_metadata *const *orb_get_topics() { static const orb_metadata *p=&topic; return &p; }
inline unsigned orb_topics_count() { return 1; }
