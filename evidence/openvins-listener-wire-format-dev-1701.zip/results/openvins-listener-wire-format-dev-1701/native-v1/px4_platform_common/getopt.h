#pragma once
inline int px4_getopt(int, char **, const char *, int *, const char **) { return -1; }
