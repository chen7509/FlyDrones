#pragma once
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#define __EXPORT
#define PX4_OK 0
#define PX4_INFO_RAW(...) printf(__VA_ARGS__)
#define PX4_ERR(...) fprintf(stderr, __VA_ARGS__)
#define PRINT_MODULE_DESCRIPTION(...) ((void)0)
#define PRINT_MODULE_USAGE_NAME(...) ((void)0)
#define PRINT_MODULE_USAGE_ARG(...) ((void)0)
#define PRINT_MODULE_USAGE_PARAM_INT(...) ((void)0)
