import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT/'src')]
from tools.benchmark.openvins_timesync_listener import TimesyncListenerDecoder

OUT = Path(__file__).resolve().parent
results = []
for name, count, profile, expect in [
    ('explicit-two', 2, 'plain-v1', False),
    ('explicit-two', 2, 'px4-d6f12ad-multi-v1', True),
    ('explicit-one', 1, 'plain-v1', True),
    ('implicit-one', 1, 'plain-v1', False),
]:
    raw = (OUT/f'native-v1/{name}.stdout').read_bytes()
    parser = TimesyncListenerDecoder(0, count, 0, output_profile=profile)
    row = dict(case=name, profile=profile, raw_sha256=hashlib.sha256(raw).hexdigest(),
               raw_bytes=len(raw), accepted=False, failure=None, fixture_only=True,
               physical_qualified=False, fusion_qualified=False)
    try:
        records = parser.feed(raw, 1)
        row.update(accepted=True, records=records, terminal=parser.finish(2, 0))
    except ValueError as exc:
        row['failure'] = str(exc)
    assert row['accepted'] is expect
    results.append(row)
with (OUT/'capture-adaptation.json').open('x',encoding='utf-8') as f:
    json.dump(results,f,indent=2)
print([(r['case'],r['profile'],r['accepted']) for r in results])
