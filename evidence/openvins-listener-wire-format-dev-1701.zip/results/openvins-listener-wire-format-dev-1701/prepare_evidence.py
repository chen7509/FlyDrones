import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
fixture = root / 'tests/fixtures/timesync/pinned-listener-two.bin'
source = out / 'native-v1/listener_main.cpp'
assert sha(fixture.read_bytes()) == 'e3b3453862a2a4e219f3c5b96c717a82e5de37e9bd0df7f452764ac64cc854f9'
assert fixture.read_bytes() == (out/'native-v1/explicit-two.stdout').read_bytes()
archive = root/'evidence/openvins-timesync-listener-dev-1701.zip'
assert sha(archive.read_bytes()) == '999eef9ccca35343fcec547a6e0fbefe70401221846eadc62bc9cd2dbae3dc40'
with zipfile.ZipFile(archive) as z:
    matches = [n for n in z.namelist() if n.endswith('/reused/src/systemcmds/topic_listener/listener_main.cpp')]
    assert len(matches) == 1 and z.read(matches[0]) == source.read_bytes()
    old_member = matches[0]
provenance = dict(px4_commit='d6f12ad1c4f70ad3230afd7d86e971421e02fef4',
    source_url='https://raw.githubusercontent.com/PX4/PX4-Autopilot/d6f12ad1c4f70ad3230afd7d86e971421e02fef4/src/systemcmds/topic_listener/listener_main.cpp',
    license='BSD-3-Clause', source_sha256=sha(source.read_bytes()),
    fixture_sha256=sha(fixture.read_bytes()), fixture_bytes=len(fixture.read_bytes()),
    native_record='results/openvins-listener-wire-format-dev-1701/native-v1',
    reused_archive_sha256=sha(archive.read_bytes()), reused_member=old_member,
    stubbed=['uORB', 'field printer', 'subscription readiness', 'unbuffered stdout selection'],
    unchanged=['listener_main.cpp control-prefix and record-header branches'],
    actual_px4=False, live_listener_qualified=False, fusion_qualified=False)
with fixture.with_suffix('.json').open('x', encoding='utf-8') as f:
    json.dump(provenance,f,indent=2)
metadata = json.loads((root/'results/openvins-timesync-channel-dev-1701/px4-metadata.json').read_text())
research = dict(provenance=provenance,
    reused_maintenance_observation=dict(archived=metadata['archived'],pushed_at=metadata['pushed_at'],
        note='Prior channel observation, not a new fetch or installed patch equivalence'),
    official_docs=['https://mavlink.io/en/services/timesync.html','https://docs.px4.io/main/en/middleware/uorb'],
    decision='Keep pinned PX4; explicit exact framing profile, no ANSI sanitization or upstream modification.',
    interface='TimesyncListenerDecoder(..., output_profile=px4-d6f12ad-multi-v1)',
    cost='One bounded cursor and per-byte parsing; no added runtime dependencies. Actual throughput unqualified.',
    current_docs_vs_pin='Current MAVLink v2 guide has targeting; pinned receiver remains authoritative and lacks that filtering.',
    paper_scope='Protocol/framing correction only; no algorithm or estimator/paper-derived model changed.')
with (out/'research.json').open('x',encoding='utf-8') as f:
    json.dump(research,f,indent=2)
print(json.dumps(provenance))
