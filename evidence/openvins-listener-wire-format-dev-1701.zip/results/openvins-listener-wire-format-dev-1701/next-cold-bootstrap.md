# Next cold bootstrap: source-derived snapshot before sustained stream

Do not repeat completed namespace process harness or native framing probe.
Pinned listener main has a distinct implicit single snapshot: no instances emits
`never published\n`; one instance prints an unnumbered header and subscribes
default instance0; more than one prints a count and separate Instance headers.
Thus do not feed all-instance discovery through explicit multirecord decoder or
infer channel index from output. Whether a strict before/after snapshot can
associate the first reserved reply is the next design question.

Require actual fresh owned PX4 epoch, command-socket/cwd/source/runtime binding
and exclusively controlled responders before treating a pre-reply no-publication
snapshot as meaningful. After exactly one reply, with subsequent replies withheld,
bound a full snapshot plus clean exit and match remote timestamp, RTT/offset and
cold filter estimate. Unknown/ambiguous/multiple/old/default-instance mismatch
must fail; do not invent a nonce or status generation. Keep external launch
provenance and pure numerical association separate, and every live authorityfalse.

When switching to explicit multi listener, use the new pinned profile, real
unbuffering selection, raw journaling and process/session checks. Restarted
listener ordinals reset and first replay of latest sample must not count as a new
accepted filter update. Plan that handoff rather than silently incrementingordinal.
Do not relax500accepted/8s/25s/2s. No actual PX4/ODOMETRY/parameter/stream mutation
authorized in current offline work. If a live gate eventually needs authorization,
finish the concrete reviewable preflight first and continue independent goal work.
