"""Compile unchanged pinned listener against explicit non-uORB stubs."""
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
src = ROOT / 'results/openvins-timesync-listener-dev-1701/reused/src/systemcmds/topic_listener/listener_main.cpp'
installed = Path('/home/yuchen7509/PX4-Autopilot/src/systemcmds/topic_listener/listener_main.cpp')
assert src.read_bytes() == installed.read_bytes()
build = OUT / 'native-v1'
build.mkdir()
def write(name, data):
    path = build / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as f:
        f.write(data.encode() if isinstance(data, str) else data)
write('listener_main.cpp', src.read_bytes())
write('px4_platform_common/module.h', '''#pragma once
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#define __EXPORT
#define PX4_OK 0
#define PX4_INFO_RAW(...) printf(__VA_ARGS__)
#define PX4_ERR(...) fprintf(stderr, __VA_ARGS__)
#define PRINT_MODULE_DESCRIPTION(...) ((void)0)
#define PRINT_MODULE_USAGE_NAME(...) ((void)0)
#define PRINT_MODULE_USAGE_ARG(...) ((void)0)
#define PRINT_MODULE_USAGE_PARAM_INT(...) ((void)0)
''')
write('px4_platform_common/getopt.h', '''#pragma once
inline int px4_getopt(int, char **, const char *, int *, const char **) { return -1; }
''')
write('uORB/topics/uORBTopics.hpp', '''#pragma once
struct orb_metadata { const char *o_name; };
using orb_id_t = const orb_metadata *;
constexpr int ORB_MULTI_MAX_INSTANCES=4;
extern orb_metadata topic;
inline const orb_metadata *const *orb_get_topics() { static const orb_metadata *p=&topic; return &p; }
inline unsigned orb_topics_count() { return 1; }
''')
write('topic_listener.hpp', '''#pragma once
#include <uORB/topics/uORBTopics.hpp>
int orb_exists(orb_id_t, int);
int orb_subscribe(orb_id_t);
int orb_subscribe_multi(orb_id_t, int);
int orb_unsubscribe(int);
int orb_set_interval(int, unsigned);
int listener_print_topic(orb_id_t, int);
''')
write('stub.cpp', '''#include <px4_platform_common/module.h>
#include "topic_listener.hpp"
orb_metadata topic{"timesync_status"};
int pipes[2]; unsigned sample=0;
int orb_exists(orb_id_t, int i) { return i==0 ? 0 : -1; }
int orb_subscribe(orb_id_t) { return pipes[0]; }
int orb_subscribe_multi(orb_id_t, int) { return pipes[0]; }
int orb_unsubscribe(int) { return 0; }
int orb_set_interval(int, unsigned) { return 0; }
int listener_print_topic(orb_id_t, int fd) {
  char ch; if (read(fd,&ch,1)!=1) return -1;
  unsigned t=102000 + 20000*sample++;
  printf(" timesync_status\\n    timestamp: %u (0.000001 seconds ago)\\n"
    "    remote_timestamp: %u\\n    observed_offset: -1000\\n"
    "    estimated_offset: -1000\\n    round_trip_time: 2000\\n"
    "    source_protocol: 0\\n\\n",t,t);
  return 0;
}
void listener(const orb_id_t &, unsigned, int, unsigned);
int main(int argc,char **argv) {
  if(argc!=3) return 2;
  setvbuf(stdout,nullptr,_IONBF,0); // chosen buffering in fixture, not PX4 proof
  if(pipe(pipes)!=0 || write(pipes[1],"ab",2)!=2) return 3;
  const orb_id_t id=&topic;
  listener(id,atoi(argv[1]),atoi(argv[2]),0);
  close(pipes[0]); close(pipes[1]); return 0;
}
''')
compiler = Path('/usr/bin/g++').resolve()
inputs = {str(p): sha(p.read_bytes()) for p in sorted(build.rglob('*')) if p.is_file()}
inputs[str(compiler)] = sha(compiler.read_bytes())
command = [str(compiler), '-std=c++17', '-Wall', '-Wextra', '-I', str(build),
           str(build/'listener_main.cpp'), str(build/'stub.cpp'), '-o', str(build/'probe')]
(build/'pre.json').write_text(json.dumps(dict(inputs=inputs, command=command,
    compiler_version=subprocess.check_output([str(compiler),'--version'],text=True),
    installed_listener_equal=True, fixture_uorb=True, actual_px4=False),indent=2))
run = subprocess.run(command,capture_output=True,timeout=30)
(build/'compile.stdout').write_bytes(run.stdout)
(build/'compile.stderr').write_bytes(run.stderr)
assert run.returncode == 0
results = []
for name, count, instance in [('explicit-two',2,0),('explicit-one',1,0),('implicit-one',1,-1)]:
    run = subprocess.run([str(build/'probe'),str(count),str(instance)],stdin=subprocess.DEVNULL,capture_output=True,timeout=3)
    (build/f'{name}.stdout').write_bytes(run.stdout)
    (build/f'{name}.stderr').write_bytes(run.stderr)
    results.append(dict(case=name,returncode=run.returncode,bytes=len(run.stdout),sha256=sha(run.stdout)))
assert all(sha(Path(p).read_bytes()) == digest for p,digest in inputs.items())
(build/'post.json').write_text(json.dumps(dict(inputs_unchanged=True,binary_sha256=sha((build/'probe').read_bytes()),cases=results),indent=2))
print(json.dumps(results))
