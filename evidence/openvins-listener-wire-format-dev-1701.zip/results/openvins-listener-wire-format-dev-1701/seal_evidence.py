import hashlib
import json
import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
archive = ROOT/'evidence/openvins-listener-wire-format-dev-1701.zip'
external = archive.with_name('openvins-listener-wire-format-dev-1701-manifest.json')
assert not archive.exists() and not external.exists()
full = (OUT/'full-tests.txt').read_text(encoding='utf-8')
assert re.search(r'3018 passed, 3 skipped, 2 warnings in', full)
fixture = ROOT/'tests/fixtures/timesync/pinned-listener-two.bin'
assert sha(fixture.read_bytes()) == 'e3b3453862a2a4e219f3c5b96c717a82e5de37e9bd0df7f452764ac64cc854f9'
for file, digest in [
    ('openvins-timesync-listener-dev-1701.zip','999eef9ccca35343fcec547a6e0fbefe70401221846eadc62bc9cd2dbae3dc40'),
    ('owned-isolated-launch-dev-1701.zip','8987976232e6e840b0dcabae506bd987bde7c44118242dad099ef6340466725b')]:
    assert sha((ROOT/'evidence'/file).read_bytes()) == digest
paths = sorted(p for p in OUT.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
paths += [ROOT/p for p in (
    'tools/benchmark/openvins_timesync_listener.py',
    'tests/benchmark/test_openvins_listener_wire_format.py',
    'tests/fixtures/timesync/pinned-listener-two.bin',
    'tests/fixtures/timesync/pinned-listener-two.json',
    'tests/fixtures/timesync/.gitattributes',
    'docs/OPENVINS_LISTENER_WIRE_FORMAT_REPORT.md',
    'docs/superpowers/specs/2026-10-08-listener-wire-format-design.md',
    'docs/superpowers/plans/2026-10-08-listener-wire-format.md',
    '.superpowers/sdd/2026-10-08-listener-wire-format/progress.md',
)]
payload={p.relative_to(ROOT).as_posix():p.read_bytes() for p in paths}
assert len(paths)==len(payload)
manifest={'schema':'evidence-members-v1','members':[
    dict(path=name,bytes=len(data),sha256=sha(data)) for name,data in sorted(payload.items())],
    'production_commit':'598017a','fixture_attributes_commit':'ca5cd98',
    'native_probe':'unchanged pinned listener with explicit stub uORB/field printer',
    'live_listener_qualified':False,'network_authorized':False,'fusion_qualified':False}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in payload.items():
        z.writestr(name,data)
    z.writestr('member-manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for member in manifest['members']:
        data=z.read(member['path'])
        assert len(data)==member['bytes'] and sha(data)==member['sha256']
    count=len(z.namelist())
result=dict(archive=archive.relative_to(ROOT).as_posix(),sha256=sha(archive.read_bytes()),
    members=count,bytes=archive.stat().st_size,crc_verified=True,
    member_hashes_verified=True,historical_archives_unchanged=True)
with external.open('x',encoding='utf-8') as f:
    json.dump(result,f,indent=2)
print(json.dumps(result))
