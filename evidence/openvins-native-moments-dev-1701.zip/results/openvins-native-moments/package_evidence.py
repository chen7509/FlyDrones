"""Package one immutable native-moments research replay with per-file hashes."""

from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
STEM = "openvins-native-moments-dev-1701"
FILES = [
    "docs/OPENVINS_NATIVE_MOMENTS_REPORT.md",
    "docs/superpowers/specs/2026-10-03-openvins-native-moments-replay.md",
    "docs/superpowers/plans/2026-10-03-openvins-native-moments-replay.md",
    "tools/benchmark/openvins_native_moments_probe.cpp",
    "tools/benchmark/audit_openvins_native_moments.py",
    "tests/benchmark/test_openvins_native_moments.py",
    "evidence/openvins-native-moments-dev-1701-provenance.json",
    "results/openvins-native-moments/package_evidence.py",
    "results/openvins-native-moments/runner-v1/build-attempt-1.txt",
    "results/openvins-native-moments/runner-v1/openvins_native_moments_probe",
    "results/openvins-native-moments/replay-v1/states.csv",
    "results/openvins-native-moments/replay-v1/moments.csv",
    "results/openvins-native-moments/replay-v1/audit.json",
    "results/openvins-native-moments/replay-v1/audit-reviewed-v2.json",
    "results/openvins-native-moments/replay-v1/stdout.txt",
    "results/openvins-native-moments/replay-v1/stderr.txt",
    "results/openvins-native-moments/replay-v1/resources.txt",
    "results/openvins-texture-dev/config-v2/estimator_config.yaml",
    "results/openvins-delayed-feed/input-v1/manifest.json",
    "results/openvins-delayed-feed/input-v1/imu.csv",
    "results/openvins-delayed-feed/input-v1/frames.csv",
]


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    archive_path = ROOT / "evidence" / f"{STEM}.zip"
    index_path = ROOT / "evidence" / f"{STEM}.sha256.json"
    if archive_path.exists() or index_path.exists():
        raise FileExistsError("refusing to overwrite native-moments evidence")
    members = {name: digest((ROOT / name).read_bytes()) for name in FILES}
    with zipfile.ZipFile(archive_path, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for name in FILES:
            archive.write(ROOT / name, arcname=name)
    with zipfile.ZipFile(archive_path) as archive:
        if archive.namelist() != FILES:
            raise ValueError("archive member order changed")
        for name, expected in members.items():
            if digest(archive.read(name)) != expected:
                raise ValueError(f"archive member changed: {name}")
    index = {"schema": "flydrones-native-moments-archive-index-v1",
             "archive_sha256": digest(archive_path.read_bytes()), "members": members}
    with index_path.open("x", encoding="utf-8") as stream:
        json.dump(index, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({"archive": str(archive_path), "archive_sha256": index["archive_sha256"],
                      "member_count": len(members)}, indent=2))


if __name__ == "__main__":
    main()
