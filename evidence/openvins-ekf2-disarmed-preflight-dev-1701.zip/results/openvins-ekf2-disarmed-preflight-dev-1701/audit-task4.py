import hashlib
import json
from pathlib import Path

ROOT = Path(r"C:\Users\yuche\.codex\worktrees\FlyDrones\track-eligibility")
OUT = ROOT / "results/openvins-ekf2-disarmed-preflight-dev-1701"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def windows_path(value):
    if value.startswith("/mnt/c/"):
        return Path("C:/" + value[len("/mnt/c/") :])
    return Path(value)


preflight = json.loads((OUT / "preflight.json").read_text())
failures = []
for key in ("physical_destination_present", "network_odometry", "px4_parameter_access", "ekf2_fusion", "arming"):
    if preflight.get(key) is not False:
        failures.append(key)
if preflight["endpoint"] != {
    "companion_udp_port": 14548,
    "model": "gz_x500_benchmark",
    "network_enabled": False,
    "px4_instance": 8,
    "px4_udp_port": 14588,
    "sender_component": 191,
    "sender_system": 254,
    "target_component": 1,
    "target_system": 9,
}:
    failures.append("endpoint")
if preflight["timesync"]["convergence_samples"] != 500:
    failures.append("timesync_convergence")
if preflight["baseline"]["EKF2_EV_CTRL"] != 0 or preflight["baseline"]["MAV_SYS_ID"] != 9:
    failures.append("baseline")
if preflight["ev_reference_body_frd_m"] != preflight["imu_reference_body_frd_m"]:
    failures.append("lever_arm")
for record in preflight["implementation"]["files"]:
    path = Path(record["path"])
    if path.stat().st_size != record["bytes"] or sha(path) != record["sha256"]:
        failures.append("implementation:" + path.name)
ulog = windows_path(preflight["source_ulog"]["path"])
if ulog.stat().st_size != preflight["source_ulog"]["bytes"] or sha(ulog) != preflight["source_ulog"]["sha256"]:
    failures.append("ulog")
for line in (OUT / "source-snapshot-hashes.txt").read_text().splitlines():
    name, size, digest = line.split()
    path = OUT / "source-snapshots" / name
    if path.stat().st_size != int(size) or sha(path) != digest:
        failures.append("snapshot:" + name)
targeted = (OUT / "targeted-tests.txt").read_text()
full = (OUT / "full-tests.txt").read_text()
if "21 passed" not in targeted:
    failures.append("targeted_tests")
if "1967 passed, 3 skipped, 2 warnings" not in full:
    failures.append("full_tests")

result = {
    "schema": "openvins-ekf2-disarmed-preflight-terminal-audit-v1",
    "implementation_commit": preflight["implementation"]["commit"],
    "failures": failures,
    "task4_qualified": not failures,
    "physical_destination_present": False,
    "network_odometry": False,
    "px4_parameter_access": False,
    "ekf2_fusion": False,
    "arming": False,
    "task5_authorized": False,
}
(OUT / "terminal-audit.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
print(json.dumps(result, indent=2, sort_keys=True))
raise SystemExit(0 if not failures else 2)
