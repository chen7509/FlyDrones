import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

root = Path(r"C:\Users\yuche\.codex\worktrees\FlyDrones\track-eligibility")
source = root / "results/openvins-ekf2-disarmed-preflight-dev-1701"
archive_path = root / "evidence/openvins-ekf2-disarmed-preflight-dev-1701.zip"
publication_path = root / "evidence/openvins-ekf2-disarmed-preflight-dev-1701-manifest.json"
if archive_path.exists() or publication_path.exists():
    raise SystemExit("refusing to overwrite sealed Task 4 evidence")


def identity(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


paths = list(source.rglob("*"))
paths += [
    root / "results/openvins-ekf2-fast-grid-physical-dev-1701/development-seed-27601/capture-v1/runtime-binding-pre.json",
    root / "results/openvins-ekf2-fast-grid-physical-dev-1701/development-seed-27601/capture-v1/px4-ulog/log/2026-10-07/17_45_07.ulg",
    root / "tools/benchmark/openvins_ekf2_disarmed_preflight.py",
    root / "tools/benchmark/prepare_openvins_ekf2_disarmed_preflight.py",
    root / "tools/benchmark/extract_px4_ulog_parameter_baseline.py",
    root / "tests/benchmark/test_openvins_ekf2_disarmed_preflight.py",
    root / "tests/benchmark/test_extract_px4_ulog_parameter_baseline.py",
    root / "docs/superpowers/specs/2026-10-08-openvins-ekf2-disarmed-preflight-design.md",
    root / "docs/superpowers/plans/2026-10-07-openvins-ekf2-shadow-integration.md",
    root / "docs/OPENVINS_EKF2_DISARMED_PREFLIGHT_REPORT.md",
    root / "evidence/openvins-ekf2-file-shadow-dev-1701-manifest.json",
    Path(__file__),
]
files = sorted({path.resolve() for path in paths if path.is_file()})
members = {}
for path in files:
    if path.is_relative_to(source):
        name = "results/openvins-ekf2-disarmed-preflight-dev-1701/" + path.relative_to(source).as_posix()
    else:
        name = path.relative_to(root).as_posix()
    members[name] = {"source": str(path), **identity(path)}

head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
manifest = {
    "schema": "openvins-ekf2-disarmed-preflight-evidence-v1",
    "created_at": "2026-10-08",
    "head": head,
    "members": members,
    "member_count_excluding_manifest": len(members),
    "task4_qualified": True,
    "task5_authorized": False,
    "physical_destination_present": False,
    "network_odometry": False,
    "px4_parameter_access": False,
    "ekf2_fusion": False,
    "arming": False,
}
manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
with zipfile.ZipFile(archive_path, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, record in members.items():
        info = zipfile.ZipInfo(name, date_time=(2026, 10, 8, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, Path(record["source"]).read_bytes(), compresslevel=9)
    info = zipfile.ZipInfo("MANIFEST.json", date_time=(2026, 10, 8, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o100644 << 16
    archive.writestr(info, manifest_bytes, compresslevel=9)

with zipfile.ZipFile(archive_path) as archive:
    bad = archive.testzip()
    archived = json.loads(archive.read("MANIFEST.json"))
    for name, record in archived["members"].items():
        data = archive.read(name)
        if len(data) != record["bytes"] or hashlib.sha256(data).hexdigest() != record["sha256"]:
            raise SystemExit("archive identity mismatch: " + name)
    names = archive.namelist()

publication = {
    "schema": "openvins-ekf2-disarmed-preflight-publication-v1",
    "archive": archive_path.name,
    **identity(archive_path),
    "member_count": len(names),
    "crc_check": bad,
    "embedded_manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
    "head": head,
    "task4_qualified": True,
    "task5_authorized": False,
    "physical_destination_present": False,
    "network_odometry": False,
    "px4_parameter_access": False,
    "ekf2_fusion": False,
    "arming": False,
}
publication_path.write_text(json.dumps(publication, indent=2, sort_keys=True) + "\n")
print(json.dumps(publication, indent=2, sort_keys=True))
