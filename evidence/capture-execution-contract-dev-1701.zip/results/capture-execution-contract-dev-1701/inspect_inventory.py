import sys,json,subprocess,importlib,hashlib,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(root),str(root/'src')]
from tools.benchmark.declared_runtime_snapshot import snapshot,write_manifest,verify_unchanged,parse_ldd
from tools.benchmark.capture_disarmed_sensors import active_resources
out=Path(__file__).resolve().parent
assert active_resources()==[]
modules=['gz.math7','gz.sim8','gz.transport13','gz.msgs10.camera_info_pb2','gz.msgs10.image_pb2','gz.msgs10.imu_pb2']
for name in modules:importlib.import_module(name)
# Import only. No TestFixture, Server, Node or native estimator instance.
loaded={name:str(Path(m.__file__).absolute()) for name,m in list(sys.modules.items()) if name.startswith('gz.') and getattr(m,'__file__',None)}
write_manifest(out/'installed-bindings.json',loaded)
px4=Path.home()/'PX4-Autopilot';build=px4/'build/px4_sitl_default';lib=Path('/usr/lib/x86_64-linux-gnu')
inv={};seen=set()
def add(role,paths):
 paths=list(paths)
 if not paths:raise ValueError('empty intended category '+role)
 rows=[]
 for p in paths:
  p=Path(p).absolute()
  if str(p) not in seen:rows.append(p);seen.add(str(p))
 if rows:inv[role]=rows
add('python_bindings',loaded.values())
add('px4_binary',[build/'bin/px4'])
add('px4_startup_explicit',[build/'rootfs/gz_env.sh',build/'etc/init.d-posix/rcS',px4/'src/modules/simulation/gz_bridge/server.config'])
add('px4_startup_tree',[p for p in (build/'etc').rglob('*') if not p.is_dir()])
prior=root/'results/openvins-online-shadow-dev-1701'
add('openvins',[prior/'online_probe',*[prior/'raw-model-zero-bias-diffusion-v1'/n for n in ['estimator_config.yaml','kalibr_imu_chain.yaml','kalibr_imucam_chain.yaml','freeze.json']]])
ref=root/'results/native-reference-probe-dev-1701/production-build/_fly_native_reference.cpython-312-x86_64-linux-gnu.so'
assert hashlib.sha256(ref.read_bytes()).hexdigest()=='303b575e29d44bf50850ad03e3d3b865207a225e366418ec5733ed5292cc18ce'
add('native_reference',[ref])
for role,pattern in [('sim','libgz-sim8.so*'),('transport','libgz-transport13.so*'),('sensor','libgz-sensors8*.so*'),('physics','libgz-physics7*.so*'),('dart','libdart*.so*'),('rendering','libgz-rendering8*.so*'),('physics_plugins','gz-physics-7/engine-plugins/*.so*'),('sim_plugins','gz-sim-8/plugins/*.so*')]:add(role,sorted(lib.glob(pattern)))
add('models',[root/'assets/gazebo/models/x500_benchmark/model.sdf',px4/'Tools/simulation/gz/models/x500/model.sdf',px4/'Tools/simulation/gz/models/x500_base/model.sdf'])
add('capture_source',[root/'tools/benchmark/capture_disarmed_sensors.py',root/'tools/benchmark/capture_contract.py',root/'tools/benchmark/declared_runtime_snapshot.py'])
# Resolve dependencies of selected installed binaries/extensions/plugins, dedup requested paths.
commands=[];dependencies=[];resolved_elf=set()
for paths in list(inv.values()):
 for p in paths:
  with p.open('rb') as f:elf=f.read(4)==b'\x7fELF'
  if not elf or str(p.resolve()) in resolved_elf:continue
  resolved_elf.add(str(p.resolve()))
  result=subprocess.run(['ldd',str(p)],capture_output=True,text=True,timeout=15)
  commands.append(dict(path=str(p),returncode=result.returncode,stdout=result.stdout,stderr=result.stderr))
  dependencies.extend(parse_ldd(result.stdout,result.returncode))
write_manifest(out/'dependency-commands.json',commands)
add('elf_dependencies',dependencies)
write_manifest(out/'declared-inventory.json',{k:[str(p) for p in v] for k,v in inv.items()})
before=snapshot(inv);write_manifest(out/'snapshot-before.json',before)
after=snapshot(inv);write_manifest(out/'snapshot-after.json',after);verify_unchanged(before,after)
# Real POSIX aliases and retargeting; Windows tests cannot create symlinks here.
with tempfile.TemporaryDirectory(prefix='fly-snapshot-') as d:
 d=Path(d);(d/'a').mkdir();(d/'b').mkdir();(d/'a/file').write_bytes(b'same');(d/'b/file').write_bytes(b'same');(d/'alias').symlink_to('a',target_is_directory=True)
 old=snapshot({'alias':[d/'alias/file']});assert old['files'][0]['links'][0]['target']=='a'
 (d/'alias').unlink();(d/'alias').symlink_to('b',target_is_directory=True)
 try:verify_unchanged(old,snapshot({'alias':[d/'alias/file']}))
 except ValueError:pass
 else:raise AssertionError('retarget accepted')
resources=active_resources();assert resources==[]
summary=dict(files=len(before['files']),roles={k:len(v) for k,v in inv.items()},elf_queries=len(commands),unchanged=True,posix_parent_link_retarget_refused=True,resources=resources,physics_run=False,estimator_run=False,runtime_closure_qualified=False,remaining=['generated world and textures at future run','actual loaded renderer/sensor plugin closure','environment resolution and copies at launch'])
write_manifest(out/'inventory-summary.json',summary);print(json.dumps(summary))
