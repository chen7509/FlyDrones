import hashlib,json
from pathlib import Path
root=Path.cwd();raw=root/'results/sequence-feature-stream-dev-1701'
expected=[
('results/static-v4-executor-completion-dev-1701/reviewed-recipe.frame',232184,'546c9ae91346ea647591fe04c5f8568bc64b2b3eb6636334bf8909b50ae442a2'),
('evidence/flydrones-pr65-history-through-linear-sequence-dev-1701.md',65389,'06cff545124b5a19439799eca0d1385a7ad7113a19bf55014ab717bd8a121836'),
('evidence/membrane-dynamics-production-retention-correction.json',6546,'802f6402c44f72b4b565e8cff5ef31a1525c027da0edb9877502161db99e0152'),
('evidence/role-comparison-production-postseal-progress-correction.json',1053,'d9334ebe173e58f3c69c7d045dbb37a69e8c77e87245504fa417b71616caabf7'),
('evidence/px4-firmware-scope-entry-review-count-correction.json',1829,'90ed8b5c2667badcd8e60c6ae94f9be31eedd33dcf5368f5ac2022d6d2537208')]
rows=[]
for name,size,digest in expected:
 b=(root/name).read_bytes();assert (len(b),hashlib.sha256(b).hexdigest())==(size,digest)
 rows.append(dict(path=name,bytes=size,sha256=digest))
before=json.loads((raw/'pr-before.stdout').read_bytes());assert before['headRefOid']=='22fd786ad9401a77aaff6db9bdafde8578b78496' and before['isDraft']
with (raw/'previous-pr-body.md').open('xb') as f:f.write(before['body'].encode())
with (raw/'additional-context-preservation.json').open('xb') as f:f.write(json.dumps(dict(pins=rows,prior_PR_body_characters=len(before['body']),prior_PR_body_sha256=hashlib.sha256(before['body'].encode()).hexdigest(),goal_read_only_status='blocked',inspection_only_failures=['Get-Content docs/NEXT_PHASE.md path absent; read actual results/px4-firmware-scope-entry-dev-1701/NEXT_PHASE.md successfully afterward','Get-Content previous preserve-v2.py path absent; no such helper assumed in actual preservation'],scope='No old files rewritten; historical correction limitations remain, no global pristine claim. Initial baseline281trackedZIPs distinguished from full305 later stream ledger.'),indent=2).encode())
print(json.dumps(dict(pins=len(rows),prior_body_characters=len(before['body']))))
