"""Exclusive software evidence seal; later publication files stay outside."""
import hashlib,json,os,zipfile
from pathlib import Path
root=Path.cwd();root=Path('\\\\?\\'+str(root)) if os.name=='nt' else root
raw=root/'results/sequence-feature-stream-dev-1701'
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes())
privacy=load(raw/'refused-attempt-preservation.json')['private_excluded']
private=load(root/'results/target-bearing-runtime-freeze-v4-dev-1701/LOCAL_UNPUBLISHED-admission-1.json')
rows=private['windows']+private['linux']['rows'];triples=[];needles=set();empty=0
for row in rows:
 cmd=row.get('cmdline');command=cmd if isinstance(cmd,str) else ' '.join(cmd or [])
 digest=sha(command.encode());triples.append(dict(pid=row['pid'],name=row['name'],argv_sha256=digest,cmdline=cmd))
 if command:needles.add(digest.encode())
 else:empty+=1
explicit={r['path'] for r in load(raw/'review-package.json')['pins']}
explicit.update(r['path'] for r in load(raw/'baseline.json')['context'])
explicit.update(['docs/SEQUENCE_FEATURE_STREAM_PRODUCTION_REPORT.md','evidence/flydrones-pr65-history-through-linear-sequence-dev-1701.md',
'evidence/px4-firmware-scope-entry-review-count-correction.json','evidence/membrane-dynamics-production-retention-correction.json',
'evidence/role-comparison-production-postseal-progress-correction.json','evidence/static-v4-executor-completion-release.frame',
'results/static-v4-attempt-dev-1701/preflight.json','results/static-v4-attempt-dev-1701/cli-completion.json',
'results/static-v4-attempt-dev-1701/admission-refusal-audit.json','results/target-bearing-runtime-freeze-v4-dev-1701/run-static-preparation-v4.py',
'results/target-bearing-runtime-freeze-v4-dev-1701/firstfacts.json','results/target-bearing-runtime-freeze-v4-dev-1701/completion.json'])
files={root/p for p in explicit}|{p for p in raw.rglob('*') if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo')}
assert not files & {root/r['path'] for r in privacy}
members=[];json_scanned=0
for p in sorted(files):
 b=p.read_bytes();name=p.relative_to(root).as_posix();assert not any(n in b for n in needles),name
 try:pending=[json.loads(b.decode('utf-8-sig'))];json_scanned+=1
 except (ValueError,UnicodeError):pending=[]
 while pending:
  value=pending.pop()
  if isinstance(value,dict):
   for keys in (('pid','name','argv_sha256'),('pid','name','cmdline')):
    if set(keys)<=value.keys():assert not any(all(value.get(k)==r.get(k) for k in keys) for r in triples),name
   pending.extend(value.values())
  elif isinstance(value,list):pending.extend(value)
 members.append(dict(path=name,bytes=len(b),sha256=sha(b)))
archive=root/'evidence/sequence-feature-stream-dev-1701.zip';mapping=archive.with_suffix('.sha256.json')
payload=dict(schema='sequence-feature-stream-map-v1',members=members,private_excluded=privacy,private_saved_rows=len(rows),private_empty_commands=empty,nonempty_private_argv_hashes=len(needles),json_scanned=json_scanned,retained_symlinks=[dict(path=p.relative_to(root).as_posix(),target=os.readlink(p)) for p in raw.rglob('*') if p.is_symlink()],scope='Actual production canonical file row reduction and tiny CPU software equality only; not native/source/fulllearning/scientificfair/flight qualification; no resource collection. Plan2done/publicationpending.')
with mapping.open('xb') as f:f.write(json.dumps(payload,indent=2).encode())
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for row in members:z.write(root/row['path'],row['path'])
 z.write(mapping,mapping.relative_to(root).as_posix())
receipt=dict(archive=archive.relative_to(root).as_posix(),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),members=len(members)+1,mapped_members=len(members),uncompressed_bytes=sum(r['bytes'] for r in members),mapped_payload_bytes=sum(r['bytes'] for r in members),manifest_bytes=mapping.stat().st_size,manifest_sha256=sha(mapping.read_bytes()),zip_expanded_bytes=sum(r['bytes'] for r in members)+mapping.stat().st_size,preseal_exact_set=[r['path'] for r in members],scope='uncompressed_bytes is mapped-only alias; whole expanded includes manifest. All mapped bytes immutable after seal except separately ledgered one final plan checkbox byte. Postseal receipt/audits/stage/publication/PR/automation/NEXT_PHASE remain outside.')
with (raw/'seal-receipt.json').open('xb') as f:f.write(json.dumps(receipt,indent=2).encode())
print(json.dumps({k:v for k,v in receipt.items() if k!='preseal_exact_set'}))
