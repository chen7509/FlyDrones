import difflib,hashlib,json
from pathlib import Path
root=Path.cwd();raw=root/'results/sequence-feature-stream-dev-1701'
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes())
def save(name,value):
 with (raw/name).open('xb') as f:f.write(json.dumps(value,indent=2).encode())
package=load(raw/'review-package.json');review=load(raw/'independent-sequence-feature-stream-review.json')
assert review['grade']=='C0/I3/M1'
review_md=(raw/'independent-sequence-feature-stream-review.md').read_bytes()
assert sha(review_md)=='f851701784e70be5a19c1fccd32c168500c553b6b338bd0401616028d983f12c'
assert review['original_review']==review_md.decode().rstrip('\n')
fixed=['src/flydrones/connectome_training/feature_sequence.py','tests/connectome_training/test_sequence_feature_stream.py']
changed=[r['path'] for r in package['pins'] if sha((root/r['path']).read_bytes())!=r['sha256']]
assert set(changed)==set(fixed)
assert load(raw/'final-stream.json')['exit']==0 and b'53 passed, 1 warning in 9.00s' in (raw/'final-stream.stdout').read_bytes()
assert load(raw/'final-lint.json')['exit']==load(raw/'final-diffcheck.json')['exit']==0
dispositions=[
('Actual full MaleCNS/GPU/peak/reserves/throughput','Remain unqualified; no runs or gates borrowed from tiny CPU equality.','Resource and full-learning costs remain unknown.'),
('Native SDK/compiler/sim/physics/measured calibration/flight','Outside this software change; all original gates/budgets/tombstones remain.','Native/source/calibration blockers remain, no dispatch authorization.'),
('Source authority/training-success/fair-upstream/equal-effort','No authority or scientific fairness granted by hashes/counters.','A future actual controlled comparison is still required.'),
('Hostile concurrent FS/atomic snapshot/check-use races','Explicitly unauthenticated ordinary byte checks; static malformed archives fixed separately.','Hostile race/mount/FFI can evade ordinary checks.'),
('Whole-epoch rollback','No rollback added; a damaged sequence returns nothing before optimizer, earlier updates stand.','Partial epoch can retain earlier actual updates.'),
('Crashsafe recorder/writer atomicity/transaction durability','No claim or change to prior writer/journal; prospective retained streams only.','Kill/output failure/power loss can lose evidence, never reconstruct it.'),
('Arbitrary third-party NPY/layout/dtype/platform encodings','Canonical writer NPY1/2 and native numeric dtypes only, no eager fallback.','Other encodings require separate conversion/design.'),
('Compression compatibility/performance','Explicitly retain only STORED/DEFLATED and refuse other methods before member open; independent bounded true-length/CRC/terminator pass.','Extra full decompression and IO/seek cost; no speed/decoder total-memory claim.'),
('Constant total memory/legitimate frame bounds/caller retention','Only production-owned image rows reduced; full tensors/model and external retained objects remain.','No certified RSS/minimum RAM or constant-total bound.'),
('New terminal/clearance/horizon semantics','Reuse existing validator, including unused horizon finite/mask checks.','Existing semantic policy limitations remain; no new target authority.'),
('Deep immutability/authenticated caller SequenceFeatures','Ordinary mutable CPU tensors validated for profile/type/shape/finite values at consumption.','Caller-crafted finite values are not source-authenticated.'),
('Independent model/trainer math requalification','Changed integration checked by exact tiny gradients/Adam/metrics/effort; unchanged trainer/math byte-pinned.','No new fullmodel/physical mathematical certification.'),
('Legacy eager loader hardening','Leave existing eager API policy unchanged; full curriculum selects strict row reader.','Legacy third-party callers keep previous eager policy and memory behavior.'),
('Adversarial Python/FFI/collection sandbox','Default test-body guard only; host imports and tiny native CPU/zlib operations real.','Collection and FFI are not sandboxed or proof of resource reserve.'),
('Final report/ZIP/history/PR/automation delivery','Perform separate integrity-only delivery after source fix; original source grades remain.','Delivery can detect evidence/publishing issues, cannot reapprove source/native.')]
executor=dict(original_review_grade='C0/I3/M1',original_review_md_sha256=sha(review_md),original_review_json_sha256=sha((raw/'independent-sequence-feature-stream-review.json').read_bytes()),executor_gate_grade='C0/I4/M0',regrade_reason='M1 static absurd dimensions can reach reduced allocations/read APIs before rejection, violating expected preallocation parser boundary. Regrade by shipped effect; do not alter original grades/hash.',single_bounded_fix=True,no_second_source_review=True,deferred_minor=[],findings=[
 dict(id='I1',grade='Important',effect='NUL original-name normalization admitted noncanonical archive',fix='orig_filename must equal canonical filename before member open/output allocation',red='DIDNOTRAISE in test_review_original_zip_names_refuse_before_output'),
 dict(id='I2',grade='Important',effect='logical size cropping concealed decoded/compressed tail or unterminated DEFLATE',fix='independent64KiB chunk pass verifies true decoded length/CRC/DEFLATE eof/no unused compressed data, before outputs; supports STORED/DEFLATED only',red='3 DIDNOTRAISE in test_review_compressed_integrity_refuses'),
 dict(id='I3',grade='Important',effect='public NumPy parser requested advertised1,000,000,000-byte header before limit',fix='preflight encoded header length<=10000 then bounded in-memory public parser; no huge fixture/read allocated',red='Budgeted actual parser read sentinel AssertionError, not observed OOM'),
 dict(id='M1',executor_grade='Important',effect='ZIP64 metadata allowed a nonrepresentable row byte size',fix='explicit sys.maxsize/np.intp dimension/element/byte checks and reduced-output byte checks before allocation/read',red='DIDNOTRAISE for tiny forged header metadata; no large allocation')],red='6fail44deselected0.82s; real software parser failures, no native target',green='50pass9.99s EXACT1CSRwarning; 3 further direct coverage tests not RED; final53pass9.00s EXACT1CSRwarning after format, Ruff0/diff0',declined_judgments=[dict(behavior=b,disposition=d,cost=c) for b,d,c in dispositions],pins_unchanged_before_plan=len(package['pins'])-len(fixed))
save('executor-fix-pass.json',executor)
text='# Executor single bounded fix pass\n\nOriginal C0/I3/M1 remains exact. Executor C0/I4/M0; M1 regraded by preallocation effect. No deferred source minor.\n\n'
text+='Six true parser REDs0.82s →50pass9.99s1CSR; final53pass9.00s1CSR/Ruff0/diff0 after format. Only new reader/test differ from original15pins;13total remain identical before plan checkboxes. No second source/native review.\n\n'
for r in executor['findings']:text+=f"- {r['id']}: {r['effect']}. Fix: {r['fix']}. Evidence: {r['red']}.\n"
text+='\nAll declined judgments, executor disposition and costs:\n\n'
for b,d,c in dispositions:text+=f'- Ruling: {b} — {d} Cost: {c}\n'
with (raw/'executor-fix-pass.md').open('xb') as f:f.write(text.encode())
patch=''
for name in fixed:
 before=(raw/'review-source'/name).read_text(encoding='utf-8').splitlines(True);after=(root/name).read_text(encoding='utf-8').splitlines(True)
 patch+=''.join(difflib.unified_diff(before,after,fromfile='review/'+name,tofile='final/'+name))
with (raw/'single-fix.patch').open('xb') as f:f.write(patch.encode())
commands=[];payload=[]
for p in sorted(raw.glob('*-start.json')):
 label=p.name[:-11];record=load(raw/(label+'.json'));inventory=load(raw/(label+'-fixtures.json'))
 commands.append(dict(label=label,argv=record['argv'],exit=record['exit'],exception=record['exception']))
 payload.extend(row for row in inventory['retained_payload'] if 'bytes' in row)
stats=dict(command_inventories=len(commands),pytest_records=sum(r['argv'][1:3]==['-m','pytest'] for r in commands),retained_regular_entries=len(payload),retained_regular_bytes=sum(r['bytes'] for r in payload),declared_sources=19,initial_absent=[r['path'] for r in load(raw/'stream-red-start.json')['source_before'] if r.get('absent')],scope='Actual retained post-run owned payloads, no intermediate-version/crashsafe/full-environment claim; baseline covers undeclared affected corpus test rather than backfilling declared sources.')
save('verification-summary.json',dict(**stats,commands=commands))
report=root/'docs/SEQUENCE_FEATURE_STREAM_PRODUCTION_REPORT.md';body=report.read_text(encoding='utf-8')
old='The unique whole-source review is pending at this report draft. It uses15 exact pins in `review-package.json`; original review and grades will be retained with executor rulings and at most one bounded fix pass. Independent delivery audits integrity/honesty only, not renewed source/native approval. Final verification and canonical seal details will be recorded before this report is sealed; publication artifacts then remain outside that sealed boundary.'
assert body.count(old)==1
new='The unique whole-source review used15 exact pins: original C0/I3/M1 remains byte-exact (review JSON SHA49e653045bb66151171a22642982332c69219011f919cafc5b33dc9f24b28d85). Executor regraded the dimension-bound finding by actual preallocation effect to C0/I4/M0. One bounded fix pass addressed all four: six genuine parser REDs0.82s (five DIDNOTRAISE and one oversized-read request sentinel, not OOM/native) →50pass9.99s; three extra codec/chunk tests are direct coverage, not invented RED. Final ordinary53pass9.00s EXACT1CSR beta warning, Ruff0/dedicated diff0 after formatting. Final import fix1 and format2newfiles/3same are retained. Only new reader/test changed from the original15pins:13TOTAL unchanged before plan checkboxes,12atseal. No second whole-source/native review; no deferred source minor. All15 declined judgments have explicit executor disposition/reason/cost in executor-fix-pass.md/json.'
new+='\n\nFixes require unnormalized ZIP original names; preflight header length<=10000 before public NumPy parsing; explicit dimension/element/byte representability; independent actual compressed-payload validation before reduced output allocation. STORED/DEFLATED only, unsupported methods refuse before member open. The integrity pass bounds raw and decoded chunks to64KiB and verifies actual decoded size/CRC, true DEFLATE termination and no unused compressed tail. It deliberately adds one full decompression pass and IO/CPU cost. This is not a throughput or total-memory bound. Original member row lifetimes remain; final row tests separately account for two bounded NPY-header reads.'
new+='\n\nRetained recorder totals: '+json.dumps(stats,ensure_ascii=False)+'. Independent delivery audits integrity/honesty only; canonical ZIP/map and outside seal-receipt bind exact sizes/hashes. This report and mapped raw/source remain immutable after seal. Later receipt/audits/helpers/stage/PR/automation/NEXT_PHASE and the separately ledgered final plan checkbox stay outside the sealed boundary.'
body=body.replace(old,new)
report.write_text(body,encoding='utf-8',newline='\n')
plan=root/'docs/superpowers/plans/2026-10-17-sequence-feature-stream.md';b=plan.read_bytes()
for task in (b'Task1:',b'Task2:'):
 old=b'- [ ] '+task;assert b.count(old)==1;b=b.replace(old,b'- [x] '+task,1)
plan.write_bytes(b)
same=[r['path'] for r in package['pins'] if sha((root/r['path']).read_bytes())==r['sha256']];assert len(same)==12
save('review-to-seal-join.json',dict(original_pins=15,fix_files=fixed,unchanged_before_plan=13,unchanged_at_seal=12,unchanged_paths=same,additional_delta='plan first2checkboxes only',original_review_grade='C0/I3/M1',executor_gate_grade='C0/I4/M0'))
software=fixed+[f'src/flydrones/connectome_training/{name}' for name in ('features.py','sequence_corpus.py','curriculum_session.py')]+['docs/superpowers/specs/2026-10-17-sequence-feature-stream-design.md','docs/superpowers/plans/2026-10-17-sequence-feature-stream.md','docs/SEQUENCE_FEATURE_STREAM_PRODUCTION_REPORT.md']
save('software-files.json',dict(paths=software,count=len(software)))
with (raw/'progress.md').open('a',encoding='utf-8') as f:
 f.write('\nTask2: source/fix/final verification complete; seal/delivery follows. Original15pins C0/I3/M1, executor C0/I4/M0 oneboundedfix six genuine RED→50green→final53pass9.00s1CSR/Ruff0/diff0.13total unchanged beforeplan;12atsealing.\n')
 f.write('Ruling: use verification-before-completion and finishing-a-development-branch with existing personal draftPR65 authorization; no menu/full native suite/worktree cleanup. Cost: no unrelated/native regression authority; preserve evidence rather than delete workspace.\n')
 f.write('Ruling: features.py actually belongs to original382, current evolvedset7; oldsix is historical, snapshots/request/release untouched/stale. Cost: next native path requires complete fresh source/receipt, not inherited oldpins.\n')
 f.write(text+'\nFinal note beforeseal: no further mapped progress/report/raw/source append after this point, sole final plan publication checkbox separately ledgered.\n')
print(json.dumps(dict(**stats,software_files=len(software),review_unchanged_at_seal=len(same))))
