### Scope and evidence

Read-only review of the 15 pinned files and their `review-source` snapshots against base `22fd786ad9401a77aaff6db9bdafde8578b78496`, including `review-tracked.patch`, the design, plan, and progress rulings. No product/test imports, tests, native operations, resource queries, or mutations were performed.

All 15 working files and snapshots matched their declared byte counts and SHA-256 pins. The 13 implementation/test/recorder files also matched both source inventories surrounding the recorded final test run. That record reports **55 passed, one CSR warning, 11.02 seconds**; the retained Ruff output reports success. The initial missing-module failures, genuine four-call eager-route failure, and later fixture failures remain distinguishable in the evidence.

**Grades: Critical 0; Important 3; Minor 1.**

### Strengths

- The actual full-components route resolves the feature profile before constructing its corpora and explicitly selects the row reader. The default `_sequence_directories` path preserves eager compatibility.
- Reduced sequences enter the existing tensor interface without changes to trainer, loss, recurrent windows, clipping, optimizer steps, or effort accounting.
- The reader validates every target row through the existing validator, including unused horizon values, and checks time ordering across rows. It returns only after completing the sequence and post-read drift checks.
- `ExitStack` correctly owns opened member streams through header, row, and CRC failures.
- Tests exercise all three schemas, both feature profiles, NPY1/2 compatibility, image-row lifetimes, production routing, late-invalid-row refusal, and actual tiny CPU gradients, metrics, Adam parameter trajectories, and effort equality across COO and CSR.

### Issues

#### Critical — none

#### Important I1 — Validate original ZIP member names before normalization

**Location:** [feature_sequence.py:97](C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/src/flydrones/connectome_training/feature_sequence.py:97)

The membership check uses `ZipInfo.filename`, which is a normalized name. Python’s ZIP reader truncates this attribute at the first NUL while preserving the complete name in `orig_filename`. Consequently, a raw member named `rgb.npy\0suffix` can satisfy the required `rgb.npy` membership check. `archive.open(info)` does not reject it when the local and central directory original names agree.

This permits an ambiguous, noncanonical archive to reach training despite the explicit exact-name refusal requirement. The ordinary duplicate-name test does not exercise this normalization case.

**Fix:** Require every original name to equal its canonical expected name, and reject any normalization difference before opening members. Add a small archive regression that changes an equal-length marker to NUL in both raw filenames; ordinary `writestr` construction can sanitize the name before the test reaches the reader. Assert refusal before output allocation and optimizer entry.

#### Important I2 — Logical ZIP EOF does not establish complete member integrity

**Location:** [feature_sequence.py:55](C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/src/flydrones/connectome_training/feature_sequence.py:55) and [feature_sequence.py:166](C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/src/flydrones/connectome_training/feature_sequence.py:166)

Both payload-length validation and the final `read(1)` rely on the ZIP directory’s declared uncompressed size. The installed `ZipExtFile` implementation crops decompressed output to that size, marks logical EOF when it reaches the size, and computes CRC over the cropped bytes.

A compressed member containing a valid canonical NPY followed by extra data can therefore pass when its directory length and CRC describe only the canonical prefix. The NPY header matches the declared size, returned rows are valid, and the final read returns EOF despite hidden trailing output. A logical EOF also does not independently establish that the DEFLATE stream reached its proper terminator.

The current trailing-payload test writes an honest ZIP length, so it catches the simpler header/length mismatch rather than this integrity gap. This is static malformed-file handling, not the excluded hostile concurrent-filesystem scenario.

**Fix:** Add bounded member-integrity validation that establishes actual decoded length and true compression-stream completion independently of `ZipExtFile`’s logical size limit. Reject excess decoded bytes, incomplete termination, and unconsumed compressed payload. Preserve row-bounded decoding; do not materialize complete image members. Add regressions with a canonical prefix plus hidden trailing output and a malformed compression ending, checking refusal and stream closure.

#### Important I3 — Bound NPY header reads before calling the public parser

**Location:** [feature_sequence.py:45](C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/src/flydrones/connectome_training/feature_sequence.py:45)

The public NumPy header readers used here do not enforce their default maximum header size before reading. In the installed NumPy implementation, they read the advertised header, decode it, and only then compare its length with `max_header_size`.

A highly compressible oversized NPY2 header can therefore cause a large allocation and decompression during catalog construction before it is rejected. The default NumPy limit does not provide the intended pre-allocation refusal boundary. This is avoidable parser behavior for malformed input, rather than a request to certify total RSS or legitimate large-frame capacity.

**Fix:** Preflight the encoded header length or wrap header reads with a strict byte budget before invoking NumPy’s public header parser. Keep support for ordinary canonical NPY1/2 headers. Add a small regression proving an excessive advertised header length is refused before an oversized read request; it need not allocate a large fixture or run a memory benchmark.

#### Minor M1 — Explicit representability checks are missing for row sizes

**Location:** [feature_sequence.py:53](C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/src/flydrones/connectome_training/feature_sequence.py:53), [feature_sequence.py:127](C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/src/flydrones/connectome_training/feature_sequence.py:127), and [feature_sequence.py:136](C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/src/flydrones/connectome_training/feature_sequence.py:136)

`math.prod` correctly avoids integer wraparound, but equality with a ZIP64 uncompressed size does not prove that a row’s dimensions or byte count are representable by NumPy and the underlying read/decompression APIs. For example, a float32 depth shape `(1, 1, 2**61)` has a row byte count exceeding signed 64-bit size while its declared member size still fits ZIP64.

Such metadata can pass header checks and reach the three reduced-output allocations before failing at a later read or shape operation. Invalid input still ultimately fails, so this is lower severity, but the explicit “overflowing dimensions refuse before allocations” boundary is not implemented.

**Fix:** Check dimensions, row byte counts, and reduced-output element/byte products against the relevant integer-size bounds before allocation or row reads. Add a tiny forged-metadata regression with allocation/read sentinels rather than a large payload.

### Recommendations

Use the single bounded fix pass for these parser boundaries and focused regressions. Keep the existing valid-file parity and production-route tests as the compatibility check. No additional native, full-model, GPU, calibration, or performance evidence is needed to address these software findings.

### Declined to judge

- Actual full MaleCNS training, GPU behavior, peak memory, resource reserves, or production throughput: prohibited in this review and not established by tiny CPU fixtures.
- Native SDK/compiler integration, simulator/physics fidelity, measured calibration, or flight readiness: outside this input-lifecycle change; their qualifications remain false.
- Source authority, training-success qualification, fair-upstream comparison, or equal-effort claims: hashes and software call counters do not establish these.
- Hostile concurrent filesystem mutation, atomic snapshot authentication, and residual check/use races: explicitly excluded by the design. This exclusion does not cover the static malformed archives reported above.
- Whole-epoch rollback after a later sequence fails: the contract prevents updates for the damaged sequence; it does not undo earlier valid sequence updates.
- Crash-safe recording, writer atomicity, and transaction durability: the writer and journal design are unchanged.
- Arbitrary third-party NPY versions, dtypes, layouts, or cross-platform encodings: canonical writer compatibility is the stated boundary; refusal is intentional.
- Independent compression-method compatibility and its performance characteristics: no broader codec promise or total decoder-buffer bound is made. Any retained codec still needs the integrity checks in I2.
- Constant total memory, bounded individual legitimate frame size, and caller-retained outputs: expressly outside the row-ownership claim.
- New semantic rules such as terminal-only-on-last-row or new clearance/horizon policy: this change intentionally reuses the existing dataset validator; it does not redefine target semantics.
- Deep immutability or authentication of caller-constructed `SequenceFeatures`: the object is explicitly unauthenticated, and tensor/profile validation occurs at consumption.
- Independent requalification of unchanged model/trainer mathematics: assessed for integration and the supplied parity evidence, not as a new mathematical or physical validation.
- Hardening the legacy eager loader against the new reader’s rejected encodings: preserving that API is intentional; changing its policy is outside this patch.
- An adversarial Python/FFI or collection-time sandbox: the inert fixture documents a narrower software-test boundary.
- Final sealed report/ZIP integrity, historical preservation reconciliation, PR publication, and automation suffix correctness: these are subsequent independent delivery tasks, not source-review approval.

### Exact pins checked

Each listed working file and corresponding `review-source` snapshot matched both the byte count and full SHA-256 below.

| File | Bytes | SHA-256 |
|---|---:|---|
| [feature_sequence.py](C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/src/flydrones/connectome_training/feature_sequence.py) | 7413 | `2188d3b1bc9b6f0f0ac0ac40e02a7c2b2758d32b1081bba73075ae7c9bef2b86` |
| [features.py](C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/src/flydrones/connectome_training/features.py) | 7069 | `a57f1b3e956ea77a8e03ce5f8e4bb9875c876be38860320b27a4a167d887c1d5` |
| [sequence_corpus.py](C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/src/flydrones/connectome_training/sequence_corpus.py) | 3482 | `6e73c4aed6e3a2801b5dc83e68156865dd4df9cda5f91b3cfd13288436a6ab24` |
| [curriculum_session.py](C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/src/flydrones/connectome_training/curriculum_session.py) | 21342 | `62c818ba10ce7d06cbaf17ee301892f26e850738d46588b2fff1f9b66a1e8542` |
| [dataset.py](C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/src/flydrones/connectome_training/dataset.py) | 11618 | `c8a1d338d31fa2690d710b724e5a7f5ece6bd08861032b8218fbbe0174d53021` |
| [trainer.py](C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/src/flydrones/connectome_training/trainer.py) | 8020 | `1ccae6dd5c08f64260ccf316a433b60dbc021e12657146424f8432660ee84eaa` |
| [losses.py](C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/src/flydrones/connectome_training/losses.py) | 1957 | `d46724e8750efdc8d86afaf164c304485111d09ab461a6ecd53bc390c0789eaa` |
| [model.py](C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/src/flydrones/connectome_training/model.py) | 16377 | `ad284023e9c71b3af82ea5cf036b38b5b6214cfb944a299e9ae7515a9b198892` |
| [test_sequence_feature_stream.py](C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/tests/connectome_training/test_sequence_feature_stream.py) | 16348 | `86e8ed050b6668a6472df370ff1f49ee08cb57e9ccf4907f75f0cfb7ee446dd2` |
| [conftest.py](C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/tests/connectome_training/conftest.py) | 1260 | `6a163e598e4011dd4efac9b8c896e5bafda4244112deaf7467125be479844ae1` |
| [test_learning_roles.py](C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/tests/connectome_training/test_learning_roles.py) | 13177 | `459545136510f34112f7ccad56d59ab7f9b426d2f05f59dac11844f4134baaef` |
| [software_process_boundary.py](C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/tools/benchmark/software_process_boundary.py) | 1737 | `1aced69a1cd810728c0bf557cc272a5bd43a94ababc31bb6ba33de791fd139a1` |
| [Design](C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/docs/superpowers/specs/2026-10-17-sequence-feature-stream-design.md) | 3827 | `2cbc0c348168ece2c63ddde05472b5e23284e7ef18b005eceee6dd23694c2f51` |
| [Plan](C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/docs/superpowers/plans/2026-10-17-sequence-feature-stream.md) | 2745 | `83d1687e0556b6e4b20515157a4bbe6ff751e4863d52d07a494eb21c3349e7cb` |
| [verify.py](C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/results/sequence-feature-stream-dev-1701/verify.py) | 4141 | `2ec5334ad282b5b07951dbadbbcdb2ba65b63532c2ee586ca811bf7202e11fc0` |

### Assessment

**Ready to merge? With fixes.**

The production routing, row ownership, and unchanged-training integration are well supported, but canonical-name and compressed-member integrity checks currently admit malformed archives, and header parsing lacks a pre-allocation size boundary. These are software correctness findings; all eight qualifications/readiness flags, including actual native/source/calibration/fair/full-model/flight eligibility, remain false.