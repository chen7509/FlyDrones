import hashlib,json,subprocess
from pathlib import Path
root=Path.cwd();raw=root/'results/sequence-feature-stream-dev-1701'
paths=[
'src/flydrones/connectome_training/'+name for name in
('feature_sequence.py','features.py','sequence_corpus.py','curriculum_session.py','dataset.py','trainer.py','losses.py','model.py')]
paths += ['tests/connectome_training/'+name for name in ('test_sequence_feature_stream.py','conftest.py','test_learning_roles.py')]
paths += ['tools/benchmark/software_process_boundary.py','docs/superpowers/specs/2026-10-17-sequence-feature-stream-design.md','docs/superpowers/plans/2026-10-17-sequence-feature-stream.md','results/sequence-feature-stream-dev-1701/verify.py']
rows=[]
for name in paths:
 b=(root/name).read_bytes();dest=raw/'review-source'/name;dest.parent.mkdir(parents=True,exist_ok=True)
 with dest.open('xb') as f:f.write(b)
 rows.append(dict(path=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
diff=subprocess.run(['git','diff','--','src/flydrones/connectome_training'],capture_output=True,check=True).stdout
with (raw/'review-tracked.patch').open('xb') as f:f.write(diff)
package=dict(base='22fd786ad9401a77aaff6db9bdafde8578b78496',head='working-source snapshot; no commit yet',pins=rows,
scope='One read-only whole-source review. No executing/importing tests/native/resource queries. New source/test are untracked, included in exact pins and snapshots. Report/evidence seal is later independent integrity, not source approval.',
verification={'stream-red':'4 missing-module failures plus genuine existing eager route four calls: total5fail0.82s','stream-green':'5pass0.77s',
'stream-coverage':'4 fixture failures (effort dict and CSR deepcopy)29pass10.39s1CSRwarning; actual tiny updates occurred',
'stream-coverage-fixed':'2 remaining fixture KeyErrors from counts wrapper,37pass9.61s1CSRwarning',
'stream-affected':'44new+11necessarycorpus=55pass11.02s1CSRwarning after format; Ruff0; gitdiffcheck0'},
review_focus=['Duplicate/ambiguous ZIP names, unexpected array encodings or overflowing dimensions must refuse before allocations or training.',
'Unused target fields still validated; late damaged rows cannot reach optimizer for that sequence.',
'Truncated/trailing/CRC data, profile mismatch and drift must close all streams and refuse.',
'Actual full-components selects the row loader, while legacy eager APIs remain compatible.',
'Digest, shape/dtype, tiny-model raw gradients, metrics and Adam updates must equal canonical eager loading.'])
with (raw/'review-package.json').open('xb') as f:f.write(json.dumps(package,indent=2).encode())
with (raw/'progress.md').open('a',encoding='utf-8') as f:f.write('\nTask1: complete; actual full route v1/v3 tiny fixture runs two epochs; 44new+11affected corpus55pass11.02s EXACT1CSRwarning; Ruff0/diffcheck0. No fullmodel/resource/native target.\nRuling: NPZ row loader supports canonical writer encodings only; refuse others with no eager fallback. Cost: noncanonical third-party archives require separate conversion.\nRuling: Necessary corpus11 checks cover the changed shared corpus interface, not repeated old work as progress. Cost: one affected regression run.\nRuling: New tests initially assumed effort flat object/dict and CSR deepcopy support. Correct test to public counts wrapper and fresh identical cores; production unchanged. Failures retained, actual earlier tiny updates not rolled back. Cost: fixture correction only.\n')
print(json.dumps({'pins':len(rows),'package':str(raw/'review-package.json')}))
