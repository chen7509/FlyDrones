"""Post-software byte preservation; no native prepin/resource collection."""
import hashlib,json
from pathlib import Path
root=Path.cwd();raw=root/'results/sequence-feature-stream-dev-1701';prior=root/'results/px4-firmware-scope-entry-dev-1701'
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes())
def save(n,v):
 with (raw/n).open('xb') as f:f.write(json.dumps(v,indent=2).encode())
def stream(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block);n+=len(block)
 return n,h.hexdigest()
baseline=load(raw/'baseline.json')
old=load(prior/'historical-archives-postsoftware.json')['members']+[dict(path='evidence/px4-firmware-scope-entry-dev-1701.zip',bytes=2388532,sha256='700c8a1f2af728c8e64026a7e5ac6f834d31174514ae0d75c45d744e6c2c8580')]
assert len(old)==305 and {r['path'] for r in old}=={p.relative_to(root).as_posix() for p in (root/'evidence').glob('*.zip')}
assert all(stream(root/r['path'])==(r['bytes'],r['sha256']) for r in old)
save('historical-archives-postsoftware.json',dict(members=old,count=len(old),bytes=sum(r['bytes'] for r in old),scope='305 full-stream POSTsoftware preservation; initial baseline listed281 Git-tracked ZIPs only, this ledger explicitly includes all305 from prior ledger+prior ZIP. Not native prepins.'))
changed=[r['path'] for r in baseline['products'] if stream(root/r['path'])!=(r['bytes'],r['sha256'])]
expected=['src/flydrones/connectome_training/curriculum_session.py','src/flydrones/connectome_training/features.py','src/flydrones/connectome_training/sequence_corpus.py']
assert sorted(changed)==sorted(expected)
save('product-preservation-postsoftware.json',dict(count=len(baseline['products']),changed=changed,unchanged=len(baseline['products'])-len(changed),new_product=['src/flydrones/connectome_training/feature_sequence.py','tests/connectome_training/test_sequence_feature_stream.py'],all_consumed_version_sources_byte_same=True,scope='Original consumed source modules unchanged; only three current curriculum software modules evolved. No target attempt.'))
p=load(prior/'refused-attempt-preservation.json');parent=root/'results/target-bearing-runtime-freeze-v4-dev-1701'
assert all(stream(root/r['path'])==(r['bytes'],r['sha256']) for r in p['private_excluded'])
assert {q.name for q in parent.iterdir()}=={'run-static-preparation-v4.py','firstfacts.json','completion.json',*[Path(r['path']).name for r in p['private_excluded']]}
assert load(parent/'completion.json')['state']=='REFUSED_UNCONSUMED' and not load(parent/'completion.json')['consumed']
sources=load(root/'results/static-v4-attempt-dev-1701/preflight.json')['sources']
assert len(sources)==382 and sources==load(root/'results/static-v4-attempt-dev-1701/cli-completion.json')['source_after']
for row in sources:assert sha((root/'results/static-v4-attempt-dev-1701/source-before'/row['path']).read_bytes())==row['sha256']
evolved=[r['path'] for r in sources if sha((root/r['path']).read_bytes())!=r['sha256']]
assert set(evolved)==set(p['current_source_evolved'])|{'src/flydrones/connectome_training/features.py'}
assert sha((root/'evidence/static-v4-executor-completion-release.frame').read_bytes())==p['release_sha256']
assert all(stream(root/r['path'])==(r['bytes'],r['sha256']) for r in baseline['context'])
for row in p['histories']:
 assert stream(root/row['path'])==(row['bytes'],row['sha256'])
 value=load(root/row['path']);assert isinstance(value['prompt'],str) and value['prompt']
p.update(prior_six_evolved_preserved_as_historical_fact=p['current_source_evolved'],current_source_evolved=evolved,current_phase_changed_outside_original382=['src/flydrones/connectome_training/sequence_corpus.py'],current_phase_new_source=['src/flydrones/connectome_training/feature_sequence.py','tests/connectome_training/test_sequence_feature_stream.py'],scope='Actual current seven evolved: features.py now changes and belongs to original382. Original snapshots remain exact; no missing predisptach pins fabricated, oldrequest/release remain stale. This does not rewrite historical six-evolved facts.')
save('refused-attempt-preservation.json',p)
print(json.dumps(dict(old_archives=len(old),archive_bytes=sum(r['bytes'] for r in old),old_products=len(baseline['products']),changed=changed,current_original382_evolved=len(evolved))))
