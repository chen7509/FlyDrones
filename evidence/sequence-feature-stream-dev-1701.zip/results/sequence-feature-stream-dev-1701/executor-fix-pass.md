# Executor single bounded fix pass

Original C0/I3/M1 remains exact. Executor C0/I4/M0; M1 regraded by preallocation effect. No deferred source minor.

Six true parser REDs0.82s →50pass9.99s1CSR; final53pass9.00s1CSR/Ruff0/diff0 after format. Only new reader/test differ from original15pins;13total remain identical before plan checkboxes. No second source/native review.

- I1: NUL original-name normalization admitted noncanonical archive. Fix: orig_filename must equal canonical filename before member open/output allocation. Evidence: DIDNOTRAISE in test_review_original_zip_names_refuse_before_output.
- I2: logical size cropping concealed decoded/compressed tail or unterminated DEFLATE. Fix: independent64KiB chunk pass verifies true decoded length/CRC/DEFLATE eof/no unused compressed data, before outputs; supports STORED/DEFLATED only. Evidence: 3 DIDNOTRAISE in test_review_compressed_integrity_refuses.
- I3: public NumPy parser requested advertised1,000,000,000-byte header before limit. Fix: preflight encoded header length<=10000 then bounded in-memory public parser; no huge fixture/read allocated. Evidence: Budgeted actual parser read sentinel AssertionError, not observed OOM.
- M1: ZIP64 metadata allowed a nonrepresentable row byte size. Fix: explicit sys.maxsize/np.intp dimension/element/byte checks and reduced-output byte checks before allocation/read. Evidence: DIDNOTRAISE for tiny forged header metadata; no large allocation.

All declined judgments, executor disposition and costs:

- Ruling: Actual full MaleCNS/GPU/peak/reserves/throughput — Remain unqualified; no runs or gates borrowed from tiny CPU equality. Cost: Resource and full-learning costs remain unknown.
- Ruling: Native SDK/compiler/sim/physics/measured calibration/flight — Outside this software change; all original gates/budgets/tombstones remain. Cost: Native/source/calibration blockers remain, no dispatch authorization.
- Ruling: Source authority/training-success/fair-upstream/equal-effort — No authority or scientific fairness granted by hashes/counters. Cost: A future actual controlled comparison is still required.
- Ruling: Hostile concurrent FS/atomic snapshot/check-use races — Explicitly unauthenticated ordinary byte checks; static malformed archives fixed separately. Cost: Hostile race/mount/FFI can evade ordinary checks.
- Ruling: Whole-epoch rollback — No rollback added; a damaged sequence returns nothing before optimizer, earlier updates stand. Cost: Partial epoch can retain earlier actual updates.
- Ruling: Crashsafe recorder/writer atomicity/transaction durability — No claim or change to prior writer/journal; prospective retained streams only. Cost: Kill/output failure/power loss can lose evidence, never reconstruct it.
- Ruling: Arbitrary third-party NPY/layout/dtype/platform encodings — Canonical writer NPY1/2 and native numeric dtypes only, no eager fallback. Cost: Other encodings require separate conversion/design.
- Ruling: Compression compatibility/performance — Explicitly retain only STORED/DEFLATED and refuse other methods before member open; independent bounded true-length/CRC/terminator pass. Cost: Extra full decompression and IO/seek cost; no speed/decoder total-memory claim.
- Ruling: Constant total memory/legitimate frame bounds/caller retention — Only production-owned image rows reduced; full tensors/model and external retained objects remain. Cost: No certified RSS/minimum RAM or constant-total bound.
- Ruling: New terminal/clearance/horizon semantics — Reuse existing validator, including unused horizon finite/mask checks. Cost: Existing semantic policy limitations remain; no new target authority.
- Ruling: Deep immutability/authenticated caller SequenceFeatures — Ordinary mutable CPU tensors validated for profile/type/shape/finite values at consumption. Cost: Caller-crafted finite values are not source-authenticated.
- Ruling: Independent model/trainer math requalification — Changed integration checked by exact tiny gradients/Adam/metrics/effort; unchanged trainer/math byte-pinned. Cost: No new fullmodel/physical mathematical certification.
- Ruling: Legacy eager loader hardening — Leave existing eager API policy unchanged; full curriculum selects strict row reader. Cost: Legacy third-party callers keep previous eager policy and memory behavior.
- Ruling: Adversarial Python/FFI/collection sandbox — Default test-body guard only; host imports and tiny native CPU/zlib operations real. Cost: Collection and FFI are not sandboxed or proof of resource reserve.
- Ruling: Final report/ZIP/history/PR/automation delivery — Perform separate integrity-only delivery after source fix; original source grades remain. Cost: Delivery can detect evidence/publishing issues, cannot reapprove source/native.
