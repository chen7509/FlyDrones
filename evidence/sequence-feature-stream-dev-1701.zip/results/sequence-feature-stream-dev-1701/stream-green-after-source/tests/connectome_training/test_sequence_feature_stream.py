import copy
import io
import json
import zipfile
from dataclasses import replace
from hashlib import sha256

import numpy as np
import pytest
import torch
from test_learning_roles import config as config
from test_learning_roles import inert_backends as inert_backends

from flydrones.connectome_training import curriculum_session as sessions
from flydrones.connectome_training.dataset import load_sequence, write_sequence
from flydrones.connectome_training.features import FEATURE_NAMES, MASKED_FEATURE_NAMES, sequence_tensors


def sequence_file(tmp_path, config, version=1, *, split="train", seed=1101, name="sequence"):
    value = sessions._synthetic_sequence(config.stages[0], split, seed)
    if version >= 2:
        for target in value.targets:
            target.horizon_valid = np.ones(len(target.horizon_enu), dtype=bool)
    if version == 3:
        for frame in value.frames:
            frame.depth_m[0, 0] = np.nan
            frame.depth_valid = np.isfinite(frame.depth_m)
    return write_sequence(tmp_path / name, value)


def streamed(path, profile="legacy-v1"):
    from flydrones.connectome_training.feature_sequence import load_feature_sequence
    return load_feature_sequence(path, profile=profile)


@pytest.mark.parametrize("version", [1, 2, 3])
def test_canonical_tensor_and_digest_bytes_equal_eager(tmp_path, config, version):
    path = sequence_file(tmp_path, config, version)
    profile = "depth-mask-v3" if version == 3 else "legacy-v1"
    eager, reduced = load_sequence(path), streamed(path, profile)
    assert reduced.sample_count == len(eager.frames)
    assert reduced.provenance == eager.provenance
    assert not hasattr(reduced, "frames")
    for actual, expected in zip(sequence_tensors(reduced, profile=profile), sequence_tensors(eager, profile=profile), strict=True):
        assert actual.dtype == expected.dtype == torch.float32
        assert torch.equal(actual, expected)
    assert sessions._dataset_digest({"s": ([eager], [eager])}, profile) == sessions._dataset_digest({"s": ([reduced], [reduced])}, profile)


def test_actual_full_components_does_not_call_eager_image_loader(tmp_path, config, tiny_artifacts, monkeypatch):
    train = sequence_file(tmp_path, config)
    val = sequence_file(tmp_path, config, split="val", seed=2101, name="validation")
    stage = replace(config.stages[0], train_paths=(str(train),), validation_paths=(str(val),), train_seeds=(1101,), validation_seeds=(2101,))
    source, folder, _, parameters = tiny_artifacts()
    # Explicit tiny fixture exercises production routing, never full-MaleCNS qualification.
    parameters.identity = replace(parameters.identity, label="full-male-cns")
    monkeypatch.setattr(sessions, "load_parameter_set", lambda _: parameters)
    calls = []
    original = sessions.load_sequence
    monkeypatch.setattr(sessions, "load_sequence", lambda path: (calls.append(path), original(path))[1])
    _, _, datasets = sessions._full_components(replace(config, stages=(stage,)), source, folder)
    assert calls == []
    partition = datasets[stage.id][0]
    assert partition.frame_count == 8
    assert next(iter(partition)).sample_count == 8


def rewrite(path, mutate):
    with zipfile.ZipFile(path / "samples.npz") as archive:
        entries = [(info.filename, archive.read(info)) for info in archive.infolist()]
    entries = mutate(entries)
    with zipfile.ZipFile(path / "samples.npz", "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, payload in entries:
            archive.writestr(name, payload)
    manifest = json.loads((path / "manifest.json").read_bytes())
    manifest["samples_sha256"] = sha256((path / "samples.npz").read_bytes()).hexdigest()
    (path / "manifest.json").write_text(json.dumps(manifest))


def array_payload(value):
    output = io.BytesIO()
    np.save(output, value, allow_pickle=False)
    return output.getvalue()


def test_reader_never_uses_whole_member_numpy_loader(tmp_path, config, monkeypatch):
    path = sequence_file(tmp_path, config)
    monkeypatch.setattr(np.lib.npyio.NpzFile, "__getitem__", lambda *args: pytest.fail("eager member decode"))
    assert streamed(path).sample_count == 8
