import hashlib,json,zipfile
from pathlib import Path
root=Path.cwd();raw=root/'results/target-bearing-loader-context-research-dev-1701'
required=[raw/'independent-design-followup.json',raw/'independent-design-followup.md',raw/'product-source-current-audit.json']
assert all(p.is_file() for p in required)
review=json.loads(required[0].read_text(encoding='utf8'))
# Review verdict checked separately before invocation; no source/native command occurs here.
excluded={'initial-admission-observation.json','archive-seal-receipt.json','independent-archive-review.json','independent-archive-review.md'}
paths=[p for p in raw.rglob('*') if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts]
paths += [root/p for p in ['docs/TARGET_BEARING_LOADER_CONTEXT_RESEARCH_REPORT.md','docs/superpowers/specs/2026-10-15-target-bearing-entry-dependency-production-design.md','docs/superpowers/plans/2026-10-15-target-bearing-entry-dependency-production.md','evidence/flydrones-history-through-admitted-executor-dev-1701.json']]
paths=sorted(set(paths));records=[]
for p in paths:
 data=p.read_bytes();records.append({'path':p.relative_to(root).as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest=root/'evidence/target-bearing-loader-context-research-dev-1701.sha256.json'
assert not manifest.exists()
manifest.write_bytes(json.dumps({'schema':'sealed-working-byte-map-v1','scope':'read-only failure research and prospective production design; no implementation/native entry trace/capture','members':records,'private_original':{'path':str((raw/'initial-admission-observation.json').relative_to(root).as_posix()),'sha256':hashlib.sha256((raw/'initial-admission-observation.json').read_bytes()).hexdigest(),'publication':'LOCAL_UNPUBLISHED'},'qualification':{k:False for k in ['source','clock','measured_calibration','accuracy','teacher','fusion','training','flight']}},indent=2).encode())
zip_path=root/'evidence/target-bearing-loader-context-research-dev-1701.zip'
with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
 for p in paths:archive.write(p,p.relative_to(root).as_posix())
 archive.write(manifest,manifest.relative_to(root).as_posix())
with zipfile.ZipFile(zip_path) as archive:
 assert archive.testzip() is None
 assert len(archive.namelist())==len(records)+1
 for row in records:
  data=archive.read(row['path']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
receipt={'path':zip_path.relative_to(root).as_posix(),'bytes':zip_path.stat().st_size,'members':len(records)+1,'mapped_members':len(records),'sha256':hashlib.sha256(zip_path.read_bytes()).hexdigest()}
(raw/'archive-seal-receipt.json').write_bytes(json.dumps(receipt,indent=2).encode());print(json.dumps(receipt))
