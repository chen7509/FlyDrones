import datetime,hashlib,json,pathlib,subprocess
paths=['/usr/lib/x86_64-linux-gnu/gz-rendering-8/engine-plugins/libgz-rendering8-ogre2.so.8.2.3',
'/usr/lib/x86_64-linux-gnu/OGRE-2.3/libOgreNextHlmsPbs.so.2.3.1',
'/usr/lib/x86_64-linux-gnu/OGRE-2.3/libOgreNextPlanarReflections.so.2.3.1',
'/usr/lib/x86_64-linux-gnu/OGRE-2.3/libOgreNextMain.so.2.3.1',
'/usr/lib/x86_64-linux-gnu/libgz-rendering8.so.8.2.3','/lib/x86_64-linux-gnu/libgz-plugin2-loader.so.2']
def record(path):
 p=pathlib.Path(path);real=p.resolve(strict=True);s=real.stat();h=hashlib.sha256()
 with real.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(requested=path,resolved=str(real),bytes=s.st_size,sha256=h.hexdigest(),device=s.st_dev,inode=s.st_ino,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
rows=[]
for path in paths:
 row=dict(path=path,start_utc=datetime.datetime.now(datetime.UTC).isoformat())
 try:
  row['before']=record(path);argv=['/usr/bin/timeout','--kill-after=2s','10s','/usr/bin/readelf','-d',path]
  row['argv']=argv
  p=subprocess.run(argv,capture_output=True,timeout=13,env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8'})
  row.update(exit=p.returncode,stdout_hex=p.stdout[:2*1024**2].hex(),stderr_hex=p.stderr[:2*1024**2].hex(),output_exceeded=max(len(p.stdout),len(p.stderr))>2*1024**2,after=record(path))
 except Exception as exc:row['error']=repr(exc)
 row['end_utc']=datetime.datetime.now(datetime.UTC).isoformat();rows.append(row)
qargv=['dpkg-query','-W','libc6','libgz-rendering8','libgz-plugin2','libogre-next-2.3.1']
q=subprocess.run(qargv,capture_output=True,timeout=10,env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8'})
print(json.dumps(dict(files=rows,packages=dict(argv=qargv,exit=q.returncode,stdout_hex=q.stdout.hex(),stderr_hex=q.stderr.hex()),native_libraries_loaded=False,qualification=False)))
