# Independent loader-context research and production-design review

Verdict: ready to seal and publish this research/design deliverable on onlypersonal. Critical 0 / Important 0 / Minor 1. This verdict does not admit a production/static-v2/renderer/physical attempt or qualify any sensor, calibration, accuracy, teacher, fusion, training or flight result. All eight flags remain false.

Reviewed current HEAD 2d040c694c5f42a008c88707e4714082a39f3a87. Read-only review used retained documents, source, JSON/hex joins and file/Git-blob hashing. No source script was executed, and no ldd/readelf/SDK/native target/test/resource observation/Git mutation ran. Only this review markdown and sibling JSON were written.

## Strengths and verified evidence

- The old producer explicitly promotes runtime:dependencies into sorted independent roots (prepare_calibration_capture.py:24-35,150). All 86 retained query JSON records match the aggregate; final HlmsPbs exit0 still contains the two not-found names under PATH/LANG only. This is an independent-entry preparation failure, not an established renderer failure or earlier-file absence. Original candidate declarations include Main and Planar.
- All 115 old evidence hashes from the independent actual-failure review and all 364 old current product-source hashes still match. The canonical original ZIP remains c68d7ea30ef376dad088720296a6f7c4446497920ab7ba619193b88032036a14. Old report/raw/input/source bytes were read only.
- All six new ELF records retain exit0, unchanged before/after requested/resolved/byte/hash/device/inode/timestamps and no output cap exceeded. The outer stdout JSON mirrors elf-metadata.json; outer stderr is retained. Renderer declares the OGRE RUNPATH and direct Main/Pbs/Unlit/Overlay/Planar dependencies; Pbs has no RUNPATH/RPATH and directly needs Planar/Main.
- Four full official commit/tree joins have 1478/245/6025/20266 entries and truncated=false. All 13 retained source/license files independently recompute to their declared SHA256 and Git blob IDs. glibc dl-load.c:1958-1996 reuses loaded SONAMEs and :2086-2092 uses requesting-object RUNPATH; dl-deps.c:172-177,222-247 builds the breadth-first dependency list. Gz RenderEngineManager.cc:487-510 passes the selected library path to Loader; Loader.cc:440-449 uses RTLD_LAZY|RTLD_LOCAL with optional NODELETE. This supports the explicitly limited inference, without claiming inherited RUNPATH, installed-source build matching or an actual successful current load.
- Missing upstream Ogre LICENSE and plugin detail/Loader.cc are retained as exact-tree observations; actual Ogre COPYING is blob-verified. All five separate installed copyright files match their raw bytes/hash. The nonexistent package spelling and /lib alias ownership query exit1 remain, followed by independently timed corrected observations. Tool SHA/version are expressly post-only. Native target-load false is correctly limited by the metadata addendum; Python/readelf/dpkg interpreter dependencies are not denied.
- The new production bill preserves every candidate file identity without independent leaf invocation, requires complete selected entry traces and mandatory renderer Main/Pbs/Planar coverage, and rejects unresolved/nonzero/timeout/output-cap/mutation/extra-member cases. Candidate-only is not current mapping proof. Future mapping phases remain mandatory.
- The concrete v2 lifecycle names new producer/study files and literal paths, preserves consumed v1, seals entry bill/source/tool/environment/full SDK graph/prepared inputs, retains the fixed exclusive physical attempt, and keeps original workloads, dual4GiB physical and dual2GiB PNG limits, fail-closed safety/ownership gates and all eight false qualifications. All 13 implementation-plan checkboxes are pending; research does not silently count as implementation/testing/static or physical success.

## Findings

Critical: none. Important: none.

Minor M1: elf-metadata-return.json:17 records Windows end_utc 19:51:51.046941, earlier than the first WSL row start_utc 19:51:51.531521. No cross-clock synchronization or monotonic elapsed proof is retained. This does not invalidate command/output/file identity observations; it means these wall timestamps cannot establish strict nesting or elapsed duration. An additive clock-domain limitation would make this explicit. Preserve original timestamps; future actual v2 budget records should retain per-clock monotonic elapsed facts. Nonblocking for this research/design publication.

## Declined to judge

- Actual production implementation/tests: the deliverable explicitly leaves Tasks1-4 pending.
- Actual entry dependency trace/SDK graph/static freeze, renderer/engine initialization and native consumer success: outside this metadata/design phase.
- Physical measurement/calibration/full learning/flight and continuous runtime closure: outside this phase; unchanged admission and all false qualifications remain necessary.
- Later archive/seal and PR publication: not present at this review point; final archive/publication identity checks remain separate.
- Windows/WSL temporal nesting or elapsed duration: not certified by the retained independent wall clocks.

## Exact reviewed hashes

The sibling JSON contains every reviewed new raw/source file path, byte size and SHA256, the selected historical evidence hashes, fixed upstream commit/tree identities and the document hashes below. It is an audit of these exact bytes, not future edits.

| Document | SHA256 |
|---|---|
| docs/TARGET_BEARING_LOADER_CONTEXT_RESEARCH_REPORT.md | 7478612916c3553034147b60c0702635b23630fd21b18b9b3f9e6de9c4d8659c |
| docs/superpowers/specs/2026-10-15-target-bearing-entry-dependency-production-design.md | f1128a6f2ddd12e6f2426ba474c313221e2c46b235d081e3535223e2d4eac836 |
| docs/superpowers/plans/2026-10-15-target-bearing-entry-dependency-production.md | f872e9963278deb09ece300bdd6b3ea4c8241b19322ca3a2213d74cd32fc50ce |
