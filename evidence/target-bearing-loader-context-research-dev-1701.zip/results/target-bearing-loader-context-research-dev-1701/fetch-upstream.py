import datetime,hashlib,json,urllib.request
from pathlib import Path
out=Path('results/target-bearing-loader-context-research-dev-1701');up=out/'upstream';up.mkdir()
repos=[('gazebosim/gz-rendering','gz-rendering8_8.2.3',['src/RenderEngineManager.cc','ogre2/src/CMakeLists.txt','ogre2/src/Ogre2RenderEngine.cc','LICENSE']),('gazebosim/gz-plugin','gz-plugin2_2.0.4',['loader/src/Loader.cc','loader/src/detail/Loader.cc','LICENSE']),('OGRECave/ogre-next','v2.3.1',['OgreMain/src/OgreDynLib.cpp','OgreMain/src/OgreRoot.cpp','LICENSE']),('bminor/glibc','glibc-2.39',['elf/dl-load.c','elf/dl-deps.c','COPYING','COPYING.LIB'])]
records=[]
def fetch(url):
 req=urllib.request.Request(url,headers={'User-Agent':'FlyDrones-fixed-loader-research'})
 with urllib.request.urlopen(req,timeout=20) as r:return r.read()
for repo,tag,names in repos:
 row=dict(repo=repo,tag=tag,start_utc=datetime.datetime.now(datetime.UTC).isoformat(),files=[])
 try:
  refraw=fetch('https://api.github.com/repos/'+repo+'/git/ref/tags/'+tag);ref=json.loads(refraw);obj=ref['object'];tagobjects=[]
  while obj['type']=='tag':
   raw=fetch(obj['url']);d=json.loads(raw);tagobjects.append(d);obj=d['object']
  assert obj['type']=='commit'
  commitraw=fetch(obj['url']);commit=json.loads(commitraw)
  treeraw=fetch('https://api.github.com/repos/'+repo+'/git/trees/'+commit['tree']['sha']+'?recursive=1');tree=json.loads(treeraw)
  assert tree.get('truncated') is False
  package=up/repo.replace('/','__');package.mkdir()
  (package/'official-ref.json').write_bytes(refraw);(package/'official-commit.json').write_bytes(commitraw);(package/'official-tree.json').write_bytes(treeraw)
  row.update(commit=obj['sha'],tree=commit['tree']['sha'],tree_entries=len(tree['tree']),truncated=False,tag_objects=tagobjects)
  for name in names:
   entry=next((x for x in tree['tree'] if x['path']==name),None)
   if entry is None:
    row['files'].append(dict(path=name,official_path_absent=True));continue
   assert entry['mode']=='100644' and entry['type']=='blob'
   url='https://raw.githubusercontent.com/'+repo+'/'+obj['sha']+'/'+name
   data=fetch(url);blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
   assert blob==entry['sha'] and len(data)==entry['size']
   p=package/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
   row['files'].append(dict(path=name,url=url,git_blob=blob,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
 except Exception as exc:row['error']=repr(exc)
 records.append(row)
 (out/'upstream-fetch-records.json').write_text(json.dumps(records,indent=2),encoding='utf8')
print(json.dumps([{k:v for k,v in r.items() if k not in ['files','tag_objects']} for r in records]))
