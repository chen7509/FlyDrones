// Synthetic fixed-source filter probe: no actual uORB, PX4 process or transport.
#include "Timesync.hpp"
#include <iostream>
uint64_t fixture_now = 0;
timesync_status_s fixture_status{};

int main() {
    Timesync filter;
    for (int i = 0; i < 520; ++i) {
        const uint64_t request = 1000000 + i * 20000;
        const uint64_t rtt = i == 510 ? 10000 : 2000;
        const uint64_t remote = request + rtt / 2 + 1000 + (i >= 500 ? (i - 499) : 0);
        fixture_now = request + rtt + 7;
        filter.update(request + rtt, remote * 1000, request * 1000);
        const auto& s = fixture_status;
        std::cout << i << '\t' << request * 1000 << '\t' << remote * 1000
                  << '\t' << s.timestamp << '\t' << s.remote_timestamp
                  << '\t' << s.observed_offset << '\t' << s.estimated_offset
                  << '\t' << s.round_trip_time << '\t' << int(s.source_protocol)
                  << '\t' << filter.sync_converged() << '\n';
    }
}
