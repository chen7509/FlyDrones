#include "Timesync.hpp"
#include <iostream>
uint64_t fixture_now = 0;
timesync_status_s fixture_status{};
int main() {
    const uint64_t requests[] = {4503599627370498ULL, 1ULL};
    const uint64_t remotes[] = {1ULL, 4503599627370499ULL};
    for (int i = 0; i < 2; ++i) {
        Timesync filter;
        fixture_now = requests[i] + 1;
        filter.update(fixture_now, remotes[i] * 1000, requests[i] * 1000);
        std::cout << fixture_status.observed_offset << '\t'
                  << fixture_status.estimated_offset << '\n';
    }
}
