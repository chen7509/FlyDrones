#pragma once
#include <cstdint>
struct timesync_status_s {
    static constexpr uint8_t SOURCE_PROTOCOL_UNKNOWN = 0;
    uint64_t timestamp{};
    uint8_t source_protocol{};
    uint64_t remote_timestamp{};
    int64_t observed_offset{};
    int64_t estimated_offset{};
    uint32_t round_trip_time{};
};
extern timesync_status_s fixture_status;
