#pragma once
#include <cstdint>
#include <ctime>
namespace time_literals {
constexpr uint64_t operator"" _ms(unsigned long long value) { return value * 1000; }
}
extern uint64_t fixture_now;
inline uint64_t hrt_absolute_time() { return fixture_now; }
#define PX4_DEBUG(...) ((void)0)
