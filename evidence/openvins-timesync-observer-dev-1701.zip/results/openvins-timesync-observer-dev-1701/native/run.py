"""Compile unchanged pinned filter with explicit synthetic clock/uORB stubs."""
import hashlib
import json
import subprocess
from pathlib import Path

out = Path(__file__).resolve().parent
sources = out.parent / "installed/src/lib/timesync"
binary = out / "filter-probe"
if binary.exists():
    raise FileExistsError(binary)
files = [*sorted((out / "stubs").rglob("*.h")), *sorted((out / "stubs").rglob("*.hpp")),
         out / "main.cpp", sources / "Timesync.cpp", sources / "Timesync.hpp", Path(__file__)]
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
before = {str(f): sha(f) for f in files}
cmd = ["g++", "-std=c++17", "-O2", "-I" + str(out / "stubs"), "-I" + str(sources),
       str(out / "main.cpp"), str(sources / "Timesync.cpp"), "-o", str(binary)]
result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
with (out / "compile.json").open("x") as f:
    json.dump({"command": cmd, "returncode": result.returncode, "stdout": result.stdout,
               "stderr": result.stderr, "compiler_version": subprocess.check_output(["g++", "--version"], text=True),
               "source_hashes_before": before}, f, indent=2)
result.check_returncode()
run = subprocess.run([str(binary)], capture_output=True, text=True, timeout=10)
run.check_returncode()
with (out / "status.tsv").open("x") as f:
    f.write(run.stdout)
assert before == {str(f): sha(f) for f in files}
with (out / "run.json").open("x") as f:
    json.dump({"binary_sha256": sha(binary), "source_hashes_unchanged": True,
               "stdout_lines": len(run.stdout.splitlines()), "synthetic_clock_and_uorb": True,
               "actual_px4_execution": False}, f, indent=2)
print("Native fixed-source filter emitted", len(run.stdout.splitlines()), "synthetic statuses")
