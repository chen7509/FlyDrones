"""Replay newly captured synthetic C++ status into the pure observer only."""
import hashlib
import json
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root))
from tools.benchmark.openvins_timesync_observer import SerialTimesyncObserver  # noqa: E402

out = Path(__file__).parent
path = out / "native/status.tsv"
observer = SerialTimesyncObserver("native-synthetic-a", 2)
changed_casts = 0
for count, line in enumerate(path.read_text().splitlines(), 1):
    index, request, remote, stamp, remote_us, observed, estimated, rtt, protocol, converged = map(int, line.split())
    observer.reserve_reply(request, remote, index * 20_000_000)
    status = dict(instance=2, ordinal=index + 1, timestamp=stamp, remote_timestamp=remote_us,
                  observed_offset=observed, estimated_offset=estimated, round_trip_time=rtt, source_protocol=protocol)
    result = observer.observe_status(status, index * 20_000_000 + 100_000)
    assert result["observed_model_converged"] == bool(converged)
    if index < 500 and estimated != -1000:
        changed_casts += 1
assert count == 520 and result["modeled_accepted_samples"] == 519
files = [Path(__file__), path, root / "tools/benchmark/openvins_timesync_observer.py",
         root / "tools/benchmark/openvins_ekf2_disarmed_preflight.py"]
summary = {"rows_matched": count, "accepted": 519, "constant_input_different_integer_cast_rows": changed_casts,
           "live_convergence_qualified": False, "synthetic_clock_and_uorb": True,
           "file_sha256": {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
with Path(sys.argv[1]).open("x") as f:
    json.dump(summary, f, indent=2)
print(json.dumps(summary, indent=2))
