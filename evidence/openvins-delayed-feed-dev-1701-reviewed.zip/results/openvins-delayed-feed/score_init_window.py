"""Save the EKF2 reference window at the delayed replay's actual init time."""

import csv
import json
from pathlib import Path

from pyulog import ULog

from tools.benchmark.audit_openvins_imu_init import score_ekf_init_velocity

root = Path(__file__).resolve().parent
episode = root.parent / "openvins-stationary-prelude/episode-v1"
result = json.loads((episode / "result.json").read_text(encoding="utf-8"))
ulog = episode / result["px4_ulogs"][0]["path"]
rows, summary = score_ekf_init_velocity(
    ULog(str(ulog)).get_dataset("vehicle_local_position").data, 31.5, 33.5)
summary["reference"] = "PX4 EKF2 fusion estimate, not independent ground truth"
summary["window_start_s"] = 31.5
summary["initialization_s"] = 33.5
out = root / "replay-v1"
with (out / "init_velocity_window.csv").open("x", newline="", encoding="utf-8") as stream:
    writer = csv.DictWriter(stream, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)
with (out / "init_velocity_summary.json").open("x", encoding="utf-8") as stream:
    json.dump(summary, stream, indent=2, sort_keys=True)
    stream.write("\n")
print(json.dumps(summary, indent=2))
