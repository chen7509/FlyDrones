"""Score the original replay on the delayed replay's exact common interval."""

import csv
import json
from pathlib import Path

from tools.benchmark.analyze_openvins_trajectory import analyze

root = Path(__file__).resolve().parent
prior = root.parent / "openvins-stationary-prelude/replay-v1"
episode_result = root.parent / "openvins-stationary-prelude/episode-v1/result.json"
with (prior / "states.csv").open(newline="", encoding="utf-8") as stream:
    source = list(csv.DictReader(stream))
rows = [row for row in source if int(row["image_ns"]) >= 33_500_000_000]
out = root / "replay-v1"
subset = out / "baseline-common-window.csv"
with subset.open("x", newline="", encoding="utf-8") as stream:
    writer = csv.DictWriter(stream, fieldnames=source[0].keys())
    writer.writeheader()
    writer.writerows(rows)
score = analyze(subset, episode_result)
result = out / "baseline-common-window-audit.json"
with result.open("x", encoding="utf-8") as stream:
    json.dump(score, stream, indent=2)
    stream.write("\n")
print(json.dumps({key: score[key] for key in ("truth_overlap_frames", "aligned_ate_rmse_m",
                                                "aligned_endpoint_error_m", "vio_speed_p95_mps")}, indent=2))
