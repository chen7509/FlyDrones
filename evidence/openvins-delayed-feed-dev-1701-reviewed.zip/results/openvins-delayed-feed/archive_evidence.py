"""Build non-overwriting evidence for the single delayed OpenVINS replay."""

import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
directory = root / "results/openvins-delayed-feed"
previous = root / "evidence/openvins-stationary-prelude-dev-1701-reviewed.zip"
archive = root / "evidence/openvins-delayed-feed-dev-1701.zip"
index = archive.with_suffix(".sha256.json")
if archive.exists() or index.exists():
    raise SystemExit("delayed replay evidence already exists")
previous_sha = hashlib.sha256(previous.read_bytes()).hexdigest()
if previous_sha != "20200cd589e4bf9c6b88cc1c9b9ba0a8673466405d0509a8ef305226b1a88d30":
    raise SystemExit("source episode evidence changed")
paths = sorted(path for path in directory.rglob("*") if path.is_file())
paths.extend(root / name for name in (
    "docs/OPENVINS_DELAYED_FEED_REPORT.md",
    "docs/superpowers/specs/2026-10-03-openvins-delayed-feed-diagnostic.md",
    "docs/superpowers/plans/2026-10-03-openvins-delayed-feed-diagnostic.md",
    "tools/benchmark/prepare_openvins_delayed_feed.py",
    "tools/benchmark/analyze_openvins_trajectory.py",
    "tools/benchmark/audit_openvins_imu_init.py",
    "tests/benchmark/test_openvins_delayed_feed.py",
    "results/openvins-stationary-prelude/episode-v1/result.json",
    "results/openvins-stationary-prelude/episode-v1/px4-ulog-manifest.json",
    "results/openvins-stationary-prelude/episode-v1/rgb-capture-manifest.json",
    "results/openvins-stationary-prelude/episode-v1/camera-info.json",
    "results/openvins-stationary-prelude/input-v1/manifest.json",
    "results/openvins-stationary-prelude/replay-v1/states.csv",
    "results/openvins-stationary-prelude/replay-v1/trajectory-audit.json",
    "results/openvins-offline-1701/runner-v3/offline_probe",
    "results/openvins-offline-1701/runner-v3/offline_probe.cpp",
    "results/openvins-texture-dev/config-v2/estimator_config.yaml",
    "results/openvins-texture-dev/config-v2/kalibr_imu_chain.yaml",
    "results/openvins-texture-dev/config-v2/kalibr_imucam_chain.yaml",
    "results/openvins-clone-motion/instrumentation.patch",
    "results/openvins-clone-motion/metadata.json",
    "results/openvins-clone-motion/REPRODUCE.md",
))
paths = sorted(set(paths))
if not paths or any(not path.is_file() or path.is_symlink() or not path.resolve().is_relative_to(root)
                    for path in paths):
    raise SystemExit("missing or invalid delayed replay archive input")
archive.parent.mkdir(parents=True, exist_ok=True)
manifest = {}
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED,
                     compresslevel=6, allowZip64=True) as bundle:
    for path in paths:
        name = path.relative_to(root).as_posix()
        payload = path.read_bytes()
        manifest[name] = {"bytes": len(payload),
                          "sha256": hashlib.sha256(payload).hexdigest()}
        bundle.writestr(name, payload)
with archive.open("rb") as stream:
    digest = hashlib.file_digest(stream, "sha256").hexdigest()
index.write_text(json.dumps({"schema": "flydrones-archive-index-v1",
                             "prior_episode_archive_sha256": previous_sha,
                             "archive_bytes": archive.stat().st_size,
                             "archive_sha256": digest,
                             "files": manifest}, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps({"members": len(manifest), "archive_sha256": digest,
                  "archive_bytes": archive.stat().st_size}))
