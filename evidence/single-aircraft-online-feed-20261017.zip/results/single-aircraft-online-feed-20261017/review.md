# Source review: owned online estimate feed

Original reviewed revision: base/HEAD `43e94e91c32173dd4a5b701253c795f60c5cb2e4` plus the six exact files in `review-source`, pinned in `review-package.json`. This is the single fresh review of that uncommitted software delta. All six byte counts and SHA-256 hashes, and the retained diff hash, matched the package. The unchanged Python transport and both native protocol source hashes matched `source-before.json`.

Review was static only: no tests, product imports, native execution, resource/process queries, or Git/index/source changes. The retained verification output says **84 passed in 1.72s**, with empty stderr; retained Ruff output says **All checks passed!** These are executor records, not reviewer executions. The protocol fixture defect below limits what those passing tests establish.

## Strengths

- The actual capture factory selects the managed subclass, and `--online-estimate-feed` is forwarded to the worker and included in the exact execution declaration. A declaration without the opt-in cannot silently admit the new workload. Fault/restart combinations are refused at argument and contract validation.
- The file drain is bounded, refuses duplicate JSON fields, compares path/descriptor identities, detects truncation, and rejects missing, partial, additional, oversized or inconsistent predictions. The actual `ShadowInput` delivery loop sees a raised failure; both that owner and the new client latch before subsequent delivery.
- The 20 ms ceiling grid and strict target-before-current-IMU condition match `openvins_online_probe.cpp:26-28,173-191`. The native source flushes fast output before constructing/sending its acknowledgement. Camera events and fast predictions have separate event types and counters; no camera acknowledgement is relabeled as a 50 Hz propagation.
- The opt-in preserves raw native arrays and explicitly keeps controller/fusion eligibility false. It adds no wire sender or flight authority. The legacy factory branch still constructs `NativeClient` with the same command, directory and callback. Filesystem/callback cancellation limitations are stated honestly.

## Issues — Critical

None identified in the reviewed software delta. This is not a flight or runtime qualification.

## Issues — Important

### I1 / P1 — Use the native writer's JSON null before the first camera

**Location:** `tools/benchmark/capture_online_estimates.py:45,106`; misleading fixture at `tests/benchmark/test_capture_online_estimates.py:208-228`. Unchanged protocol evidence: `tools/benchmark/openvins_fast_probe.h:28-30` and `tools/benchmark/openvins_online_probe.cpp:137,173-191`.

The client initializes `_last_camera` to `-1` and requires the row value to equal it. The C++ writer receives a negative sentinel internally but explicitly serializes it as JSON **null**, not `-1`. With valid IMUs at 4, 8, 12, 16, 20 and 24 ms and no camera yet, the first actual 20 ms prediction therefore fails `native prediction identity/state mismatch`. The client and `ShadowInput` then permanently refuse further input. The purported real-native-sentinel test passes only because it fabricates the wrong wire representation.

**Fix:** Represent the no-camera wire state as `None` (or compare against an explicit conversion of the internal sentinel), retaining strict equality once a real camera has been delivered. Replace the fixture's `-1` with `None`; record a genuine failing test against the original consumer before correcting it. Keep a rejection check for a negative integer on the wire so the test cannot regress to the same misunderstanding. Do not modify the consumed native adapter.

### I2 / P2 — Bind the acknowledgement sample to the input before accepting its output

**Location:** `tools/benchmark/capture_online_estimates.py:147-148` and `104-106`. Unchanged dependency evidence: `tools/benchmark/openvins_online_shadow.py:233-239,419-427`.

The inherited acknowledgement validator checks sequence, kind and clock ordering, but never checks `sample_ns` against the action. The new consumer compares `available_imu_ns` only to that unchecked acknowledgement sample. Thus an action at 24 ms can accept an acknowledgement at 28 ms and a fast row with `available_imu_ns=28 ms`, while its grid/last-IMU bookkeeping advances from the 24 ms action. With otherwise matching sequence and call clocks this path is accepted and journaled, so a coordinated mismatched acknowledgement/output is incorrectly joined to the requested input. Non-prediction IMU and camera acknowledgements likewise have no new sample binding.

**Fix:** Immediately after the inherited send returns, require an integer acknowledgement sample equal to the requested sample, before file consumption or event acceptance. Test both an acknowledgement/fast-row pair that agree with one another but disagree with the action, and a camera or non-target IMU acknowledgement mismatch; verify that the next request is never sent. Keep this validation in the opt-in client if preserving the unchanged transport is required.

### I3 / P2 — Preserve the parent exception when the new cleanup also fails

**Location:** `tools/benchmark/capture_online_estimates.py:205-211`; the same masking pattern exists in constructor rollback at `56-58`. Existing test coverage: `tests/benchmark/test_capture_online_estimates.py:247-258`.

The nested `finally` blocks do attempt both new resource closes after `super().finish()` raises, but either `os.close()` or `_events.close()` can raise and replace that original exception. In particular, a journal flush/close error after an earlier failed write, combined with a parent exit/cleanup error, causes the caller to receive only the secondary close error. `CaptureJournal` cannot retain the promised primary cause from `repr(exc)` once it is replaced. The current test exercises only a parent failure with successful extra closes.

**Fix:** Capture the primary construction/finish exception, attempt each owned close independently, and re-raise the primary while retaining secondary cleanup errors separately or as exception notes. If there was no primary error, surface cleanup errors instead of suppressing them. Add a combined parent-failure plus descriptor/journal-close-failure test that asserts both close attempts and preservation of the original exception.

## Issues — Minor

None promoted. The test fixture problem is part of I1, not an additional cosmetic finding.

## Recommendations

1. Use the authorized single bounded executor fix pass for I1-I3. Preserve this original review and its original grades; record a separate executor ruling for every finding and every declined judgment below.
2. Extend the constructed protocol boundary only where needed for these defects. Use the actual emitted null representation, action/ack mismatch cases and simultaneous cleanup failures. Retain genuine RED-to-GREEN evidence without launching native code, importing product runtimes or polling resources.
3. Retain the existing opt-in, raw/unqualified labels, exact workload declaration, bounded file drain and mandatory outer supervision. The software feed remains one downstream prerequisite; no result here establishes a calibrated controller source or completes the mission.

## Declined to judge

Each entry is a separate exclusion/ruling for the executor; none is an implicit approval.

- **D1 — Native estimator mathematics, numerical accuracy and covariance calibration.** Only adapter source was read; no estimator execution or measurements were permitted. Array shape/finiteness checks do not establish mathematical correctness.
- **D2 — Current native binary/build correspondence, installation, successful process startup and end-to-end sensor capture.** Unchanged source hashes were checked, but no binary, native process or live product runtime was exercised.
- **D3 — Physical resource admission below 4 GiB, memory headroom, RTF and end-to-end timing budgets.** Resource/process queries and runtime attempts were forbidden; static bounded reads are insufficient evidence for physical admission.
- **D4 — Hard cancellation of filesystem/logging operations and the inherited first-ack callback.** The specification expressly excludes that guarantee and requires outer supervision. I found no new contrary hard real-time claim to grade as a defect.
- **D5 — Measured camera/IMU calibration, nonzero temporal offset support, calibrated image-time optical pose and a usable EstimatedControllerState.** These remain explicit downstream work; this raw feed supplies none of their evidence.
- **D6 — Actual PX4 fusion, source/reset evidence, source authentication and live health qualification.** The reviewed outputs stay unqualified. PID/file/sequence association is not proof of those properties.
- **D7 — Wire publication, flight-control/mission orchestration, planner completeness, flight grant or completion of the overall mission.** None is implemented by this delta and none is authorized by this review.
- **D8 — Original histories, consumed studies, native/prepin approval and unchanged baseline correctness beyond the read dependencies.** Those were expressly outside this review. Existing constructor/registration ownership gaps in surrounding capture code are not newly introduced findings here.
- **D9 — Hostile concurrent same-inode modification, directory replacement and a full filesystem provenance/security audit.** The declared scope is an owned newly created output, not source authentication; the reviewed identity checks do not justify a stronger guarantee, and no demonstrated added exploit was graded.
- **D10 — A closed-schema/type-hardening finding for all optional/raw JSON members.** The validator is not a complete exact-key schema, but the allowed sources did not establish an additional concrete normal-path failure or new authority from that observation. This does not excuse the specific action/ack identity defect in I2.
- **D11 — Post-fix correctness or readiness.** This review and verdict apply only to the original pinned files. One executor fix pass follows; no second source review or automatic upgrade of this verdict is implied.

## Assessment

**Changes requested — 0 Critical, 3 Important, 0 Minor.** The integration is narrow and structurally connected to the actual capture path, but the native null-sentinel mismatch prevents a valid startup sequence, the acknowledgement join has a missing source-sample check, and simultaneous cleanup failures can erase the primary exception. The retained passing software tests do not override those source findings. No native/runtime/resource, calibration, controller, fusion or flight qualification is granted; the overall mission remains incomplete.
