# Executor disposition

Original C0/I3/M0 and six pins remain. One bounded fix pass, no second review/native grant. Seven genuine software counterexamples failed2.26s; final23new+67necessary=90passed1.61s, no warnings/Ruff0/diff0.

I1: use emitted JSON null (not native internal -1); prior fixture misunderstanding is preserved, not native RED. I2: exact integer ack/action sample join. I3: preserve primary failure with secondary cleanup notes/attribute; a failed close is not certified closure. No deferred minors.

D1: Native estimator mathematics, accuracy and covariance calibration. Ruling: No mathematical/covariance qualification; retain raw native values only. Cost if wrong: Treating finite arrays as accuracy would admit unsafe estimates.

D2: Binary/build correspondence, installation, startup and end-to-end capture. Ruling: No binary/startup/capture claim; future current-source/build/runtime admission is required. Cost if wrong: An incompatible or unqualified binary could be mistaken for verified input.

D3: Physical 4 GiB admission, memory headroom, RTF and total timing budgets. Ruling: Keep original dual4GiB gates and original budgets; no polling or runtime dispatch. Cost if wrong: Unsafe memory/RTF/time admission.

D4: Hard cancellation of filesystem/logging and first-ack callback. Ruling: Require outer supervision; do not claim hard cancellation of filesystem or inherited callback. Cost if wrong: Blocking I/O could stall a future controller.

D5: Measured calibration, nonzero offset, image-time optical pose and EstimatedControllerState. Ruling: Calibrated optical/body pose and measured nonzero-offset consumer remain mandatory downstream; not synthesized here. Cost if wrong: Wrong frames/timestamps could command the wrong direction.

D6: Actual PX4 fusion, source/reset evidence, source authentication and live health qualification. Ruling: PID/file joins are unverified lifecycle data; actual source/clock/reset/fusion checks remain mandatory. Cost if wrong: False process/source continuity or fusion readiness.

D7: Wire publication, controller/mission/planner, flight grant and overall mission completion. Ruling: No new sender/controller mission authority; legacy truth CLI remains unsuitable. Cost if wrong: Software journals could otherwise be mistaken for autonomous flight.

D8: Original histories, consumed studies, native/prepin approvals and broader unchanged baseline correctness. Ruling: Preserve all original consumed/failure/history/prepin limitations; new source delta only, no baseline reapproval. Existing broader registration gap blocks no new claim of live readiness. Cost if wrong: Unchanged lifecycle defects or missing prepins could be silently carried into a live run.

D9: Hostile same-inode mutation, directory replacement and complete filesystem provenance/security. Ruling: Only ordinary owned-file identity checks; no adversarial mount/concurrent overwrite/source authentication grant. Cost if wrong: Hostile same-inode or directory races can evade point-in-time checks.

D10: General exact-key/type-hardening finding for every raw JSON member. Ruling: Keep raw projection unqualified and selective semantic checks; no exact-key/schema-authentication assertion. Concrete action/ack sample mismatch is fixed under I2. Cost if wrong: Future protocol fields/types may need a separately evidenced consumer change.

D11: Post-fix correctness or readiness. Ruling: Original C0/I3/M0 stays pinned; executor7RED then23/90GREEN verifies one bounded fix pass, not second source approval. Cost if wrong: Overstating source/native readiness after fixes.

