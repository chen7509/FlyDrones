"""Postseal software publication commands, exclusive argv/streams/metadata."""
import datetime
import json
from pathlib import Path
import subprocess
import time

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent

def command(label, argv):
    stamp=OUT/(label+'.command.json')
    record={'argv':argv,'cwd':str(ROOT),'utc_start':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    with stamp.open('x',encoding='utf-8') as f:
        json.dump(record,f,indent=2)
    start=time.monotonic()
    with (OUT/(label+'.stdout')).open('xb') as stdout,(OUT/(label+'.stderr')).open('xb') as stderr:
        child=subprocess.Popen(argv,cwd=ROOT,stdout=stdout,stderr=stderr)
        code=child.wait(timeout=60)
    record.update(exit=code,elapsed_s=time.monotonic()-start,utc_finish=datetime.datetime.now(datetime.timezone.utc).isoformat())
    with (OUT/(label+'.completion.json')).open('x',encoding='utf-8') as f:
        json.dump(record,f,indent=2)
    if code:
        raise RuntimeError(label+' exit '+str(code))
    return (OUT/(label+'.stdout')).read_bytes()

if __name__=='__main__':
    import sys
    command(sys.argv[1],sys.argv[2:])
