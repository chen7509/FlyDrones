"""Software integration only: constructed child protocol, real bounded files."""

import copy
import json
import os
import socket
import subprocess
from types import SimpleNamespace

import pytest

from tools.benchmark import capture_disarmed_sensors as capture
from tools.benchmark import capture_contract as contract
from tools.benchmark import openvins_online_shadow as shadow


@pytest.fixture(autouse=True)
def no_native(monkeypatch):
    def denied(*args, **kwargs):
        raise AssertionError("native/process/network forbidden in software test body")
    monkeypatch.setattr(subprocess, "Popen", denied)
    monkeypatch.setattr(socket, "socket", denied)
    monkeypatch.setattr(os, "system", denied)


def selected(tmp_path):
    return capture.parse_capture_args([
        "--output", str(tmp_path / "capture"), "--online-estimate-feed",
        "--shadow-binary", str(tmp_path / "native"),
        "--shadow-config", str(tmp_path / "estimator_config.yaml"),
        "--execution-contract", str(tmp_path / "execution.json"),
        "--runtime-binding", str(tmp_path / "binding.json"),
    ])


def prediction():
    return dict(target_ns=20_000_000, last_camera_ns=12_000_000,
                available_imu_ns=24_000_000, filter_time_s=.012,
                camera_imu_offset_s=0.0, internal_initialized=True,
                public_initialized=True, success=True, filter_unchanged=True,
                propagation_wall_s=.0001,
                state13=[0., 0., 0., 1., 1., 2., 3., 4., 5., 6., 0., 0., 0.],
                covariance12=[[1. if i == j else 0. for j in range(12)] for i in range(12)],
                trigger_sequence=6, native_begin_ns=110, native_end_ns=120,
                fusion_eligible=False, quality=None, reset_counter=None)


def controlled_native(tmp_path, monkeypatch):
    calls = []
    rows = []
    def init(self, command, output, **kwargs):
        self.output = output
        self.process = SimpleNamespace(pid=9182, poll=lambda: None)
        self.closed, self.failed, self.sequence = False, None, 0
        (output / "fast.jsonl").write_bytes(b"")
    def send(self, action, pixels=None):
        calls.append(copy.deepcopy(action))
        if rows:
            with (self.output / "fast.jsonl").open("ab") as f:
                f.write(rows.pop(0))
        result = dict(sequence=self.sequence, kind={"imu":"I", "camera":"C"}[action["kind"]],
                      sample_ns=action["sample_ns"], source_arrival_ns=80,
                      dispatch_ns=90, receive_ns=100, start_ns=105, end_ns=125,
                      acknowledged_ns=130, fusion_eligible=False, quality=None, reset_counter=None)
        if action["kind"] == "camera":
            result.update(imu_state=[0.] * 16, imu_covariance15=[[0.] * 15 for _ in range(15)],
                          internal_initialized=False, public_initialized=False)
        self.sequence += 1
        return result
    def finish(self):
        self.closed = True
        return dict(exit=0, accepted=self.sequence, failure=self.failed)
    monkeypatch.setattr(shadow.NativeClient, "__init__", init)
    monkeypatch.setattr(shadow.NativeClient, "send", send)
    monkeypatch.setattr(shadow.NativeClient, "finish", finish)
    client = capture.make_capture_native_client(selected(tmp_path), tmp_path, on_first_ack=None)
    return client, calls, rows


def prime(client):
    for sample in (4, 8, 12, 16):
        client.send(dict(kind="imu", sample_ns=sample * 1_000_000))
    client.send(dict(kind="camera", sample_ns=12_000_000), b"pixels")
    client.send(dict(kind="imu", sample_ns=20_000_000))


def test_live_capture_consumes_real_file_at_matching_imu_ack(tmp_path, monkeypatch):
    # Break caught: returning only the IMU ack/discarding the native fast output.
    client, calls, rows = controlled_native(tmp_path, monkeypatch)
    prime(client)
    rows.append((json.dumps(prediction()) + "\n").encode())
    ack = client.send(dict(kind="imu", sample_ns=24_000_000))
    assert ack["sequence"] == 6
    summary = client.finish()
    records = [json.loads(line) for line in (tmp_path / "online-estimates.jsonl").read_text().splitlines()]
    fast = [r for r in records if r["event"] == "fast_prediction"]
    assert len(fast) == 1
    assert fast[0]["prediction"] == prediction()
    assert fast[0]["camera_ack_sequence"] == 4
    assert fast[0]["native_pid"] == 9182
    assert fast[0]["ack"]["sample_ns"] == 24_000_000
    assert fast[0]["fusion_eligible"] is False
    assert summary["online_estimates"]["fast_predictions"] == 1
    assert summary["online_estimates"]["controller_ready"] is False
    assert len(calls) == 7


@pytest.mark.parametrize("fault", ["missing", "truncated", "extra", "trigger", "sample", "camera", "clock", "oversized"])
def test_bad_native_output_latches_before_next_delivery(tmp_path, monkeypatch, fault):
    # Break caught: old/malformed/foreign native rows reach downstream as new estimates.
    client, calls, rows = controlled_native(tmp_path, monkeypatch)
    prime(client)
    row = prediction()
    if fault == "trigger": row["trigger_sequence"] = 5
    if fault == "sample": row["available_imu_ns"] = 28_000_000
    if fault == "camera": row["last_camera_ns"] = 8_000_000
    if fault == "clock": row["native_end_ns"] = 126
    data = (json.dumps(row) + "\n").encode()
    if fault == "missing": data = b""
    if fault == "truncated": data = data[:-1]
    if fault == "extra": data += data
    if fault == "oversized": data = b" " * 16_385
    rows.append(data)
    with pytest.raises((ValueError, RuntimeError)):
        client.send(dict(kind="imu", sample_ns=24_000_000))
    delivered = len(calls)
    with pytest.raises(RuntimeError):
        client.send(dict(kind="imu", sample_ns=28_000_000))
    assert len(calls) == delivered
    assert client.finish()["online_estimates"]["failure"]


def test_new_workload_is_forwarded_and_bound_to_exact_declaration(tmp_path):
    # Break caught: supervisor drops selection or an old declaration accepts it silently.
    args = selected(tmp_path)
    assert "--online-estimate-feed" in contract.worker_options(args)
    actual = contract.execution_contract(args, {"PATH":"fixture"})
    assert actual["online_estimate_feed"]["profile"] == "native-ack-fast-output-v1"
    old = copy.deepcopy(actual)
    old.pop("online_estimate_feed")
    args.execution_contract.write_text(json.dumps(old), encoding="utf-8")
    with pytest.raises(ValueError, match="differs"):
        contract.validate_declaration(args, {"PATH":"fixture"})


def test_old_output_is_rejected_before_child_construction(tmp_path, monkeypatch):
    # Break caught: a fresh label reuses a consumed native fast file.
    (tmp_path / "fast.jsonl").write_bytes(b"old\n")
    selected_args = selected(tmp_path)
    with pytest.raises(FileExistsError):
        capture.make_capture_native_client(selected_args, tmp_path, on_first_ack=None)
    assert not (tmp_path / "online-estimates.jsonl").exists()


def test_profile_requires_bound_native_capture_before_effects(tmp_path):
    with pytest.raises(SystemExit):
        capture.parse_capture_args(["--output", str(tmp_path), "--online-estimate-feed"])
    assert list(tmp_path.iterdir()) == []
