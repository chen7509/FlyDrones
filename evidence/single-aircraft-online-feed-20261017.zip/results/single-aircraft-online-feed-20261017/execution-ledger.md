# SDD ledger — plan: docs/superpowers/plans/2026-10-17-capture-online-estimates.md

BASE43e94e91c32173dd4a5b701253c795f60c5cb2e4. Existing branch/worktree reused; tracked clean at entry. Goal untouched/blocked, automation untouched/ACTIVE.

Using brainstorming, writing-plans, executing-plans, TDD for this inline software integration. Human explicitly authorized continued software and no staged approvals. Heartbeat quiet rule suppresses skill announcements outside this ledger.

Full-history prerequisite: root read entire latest63952-character prompt in [0,22000),[22000,44000),[44000,63952) tool outputs; three focused read-only agents read all62986/62676/63552 characters of original three histories in complete chunks and returned binding constraints. All4 original file hashes match. No claim root independently reread older3 or new source/native approval. No historical product/native/test/resource execution.

Ruling: Implement the necessary live native output leg inside actual capture first, retaining disarmed/unqualified labels — current fast output is only a flushed file and discarded by Python live path; replacing it with retrospective replay would not bind availability — cost if wrong: additional capture overhead; source/calibration/fusion/flight remain pending.

Ruling: Reuse current native protocol/real fast file rather than change consumed C++ or rebuild — only newly owned fresh capture outputs are read after matching acknowledgements; no old native study is run — cost if wrong: native protocol drift must refuse, not retry or reinterpret.

Ruling: No whole repository tests/native launch/resource queries; only new tests and necessary capture neighbors, with test-body process/network traps. These do not certify native estimator behavior.

Ruling: No hard cancellation claim for filesystem or inherited first-ack binding callback; elapsed/deadline checks and bounded file reads are software fail-closed checks, outer process supervision remains required. This feature cannot grant real-time flight authority.

Pre-flight: One task; capture factory selects new client, worker options and execution declaration preserve same opt-in; no new wire sender or controller authority. Source copies and future recorder are prospective.

Task1 RED11failed/1passed2.22s: missing CLI interface, not behavior/native RED. First implementation run9failed/3passed2.85s: controlled parent fixture omitted actual NativeClient.timeout_s; fixture corrected only. Protocol run2failed/13passed1.44s: real pre-camera native sentinel mismatch plus Windows-open-file rename fixture refusal. Separate modeled lstat replacement counterexample1DIDNOTRAISE/14deselected1.21s. Fixed actual -1 native sentinel and path inode/truncation revalidation. 15passed1.21s. Added actual ShadowInput delivery/failure integration and elapsed-budget GREEN coverage, not fake RED. Necessary17new+67capture-contract=84passed1.86s then format/import final84passed1.72s, no warnings/Ruff0/diff0. InitialRuff9errors=1import+8one-line-if; format2new/import1fix. Ordinary Python/NumPy/owned Windows files/recorder subprocess real; native owner/process and protocol payload constructed, no estimator math/source/native/fusion qualification.

Source6pins frozen in review-package.json; ONE fresh review dispatched. No code changes while review underway. Current runtime binding explicitly requires new producer module before native construction; exact declaration and worker opt-in prevent accidental workload change. Parent source/CPP unchanged; no archive/history rescans.

Final source review originalC0/I3/M0/6pins. Executor accepts all3Important by actual effect. I1 revealed native writer serializes its internal -1 as null; the earlier pre-camera test and its prior RED/GREEN were a protocol-fixture misunderstanding, NOT native behavior verification. Raw snapshots retained. One bounded fix pass7genuine software RED2.26s: emitted-null refusal, invalid -1 accepted,3coordinated ack mismatch acceptances,2primary error masking. All3 fixed,23passed1.18s; final format1newtest/1same,23new+67necessary=90passed1.61s/no warning/Ruff0/diff0. No second source/native review. All11 exclusions individually ruled with cost in executor-disposition. No deferred minor.
