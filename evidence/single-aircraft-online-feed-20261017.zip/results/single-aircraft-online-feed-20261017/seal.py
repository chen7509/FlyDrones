"""Exclusive software evidence archive; no native/source approval."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
ARCHIVE=ROOT/'evidence/single-aircraft-online-feed-20261017.zip'
MAP=ROOT/'evidence/single-aircraft-online-feed-20261017.sha256.json'
SOFTWARE=['tools/benchmark/capture_online_estimates.py','tools/benchmark/capture_disarmed_sensors.py','tools/benchmark/capture_contract.py','tests/benchmark/test_capture_online_estimates.py','docs/superpowers/specs/2026-10-17-capture-online-estimates-design.md','docs/superpowers/plans/2026-10-17-capture-online-estimates.md','docs/SINGLE_AIRCRAFT_ONLINE_FEED_PROGRESS.md']

def digest(b): return hashlib.sha256(b).hexdigest()

def main():
    if ARCHIVE.exists() or MAP.exists():raise FileExistsError('canonical archive/map exists')
    final=json.loads((OUT/'fixed-final/completion.json').read_bytes())
    for name in SOFTWARE[:4]:
        b=(ROOT/name).read_bytes()
        assert final['source_after'][name]['sha256']==digest(b),name
    files={name:ROOT/name for name in SOFTWARE}
    for p in sorted(OUT.rglob('*')):
        if p.is_symlink():raise ValueError('unexpected evidence symlink')
        if p.is_file():files[p.relative_to(ROOT).as_posix()]=p
    rows=[]
    for name,p in sorted(files.items()):
        b=p.read_bytes();rows.append(dict(path=name,bytes=len(b),sha256=digest(b)))
    manifest=json.dumps({'schema':'single-aircraft-online-feed-software-manifest-v1','scope':'software raw and owned constructed fixtures only; no native/calibration/fusion/flight approval; postseal publication/handoff excluded','files':rows},indent=2).encode()
    with zipfile.ZipFile(ARCHIVE,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        z.writestr('manifest.json',manifest)
        for row in rows:
            b=files[row['path']].read_bytes();assert len(b)==row['bytes'] and digest(b)==row['sha256'];z.writestr(row['path'],b)
    with zipfile.ZipFile(ARCHIVE) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(rows)+1
        for row in rows:assert digest(z.read(row['path']))==row['sha256']
    b=ARCHIVE.read_bytes()
    record={'archive':ARCHIVE.relative_to(ROOT).as_posix(),'bytes':len(b),'sha256':digest(b),'members':len(rows)+1,'mapped_members':len(rows),'mapped_payload_bytes':sum(r['bytes'] for r in rows),'manifest_bytes':len(manifest),'manifest_sha256':digest(manifest),'whole_expanded_bytes':sum(r['bytes'] for r in rows)+len(manifest),'files':rows,'scope':'Executor CRC/member/hash verification only, not independent source/native/archive reapproval; no old global scan'}
    with MAP.open('x',encoding='utf-8') as f:json.dump(record,f,indent=2)
    print(json.dumps({k:v for k,v in record.items() if k!='files'}))

if __name__=='__main__':main()
