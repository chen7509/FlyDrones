import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

root = Path.cwd()
study = root / 'results/mission-clock-refusal-dev-1701'
verified = json.loads((study / 'annotation-verification.json').read_text(encoding='utf-8-sig'))
assert all(verified[name] == 0 for name in ('exit_code', 'ruff_exit', 'diff_exit'))
assert '109 passed in 0.39s' in (study / 'annotation-green.txt').read_text(encoding='utf-8-sig')
assert '20 failed' in (study / 'red.txt').read_text(encoding='utf-8-sig')
old = {
    'evidence/mission-clock-refusal-dev-1701.zip': '16edeb07b102fd8dbb8b7a57c6482e27707f5e55634cef6e77da2a9cfcb35def',
    'evidence/mission-state-safety-dev-1701.zip': 'b9995fbb09ce57724328885a24cbfa67e530dc7fbf690f1b97b19e19a85d3ea7',
    'evidence/curriculum-evaluation-integrity-dev-1701.zip': 'edaa6b69cb169e07628d9fddda443673bb340918602e9e4200c4a30a9334bbe3',
    'evidence/ego-build-v3-oom-dev-1701.zip': '28400eb8776984a10530e0f6fa5835938c68fa77bc21da306b7340fc3394a3bb',
    'evidence/ego-build-whitespace-dev-1701.zip': 'de9511745154b703f59235a4194ea626d469833712dac9b2b937fc98512acd17',
}
for name, digest in old.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest
assert '2 failed' in (study / 'precision-red.txt').read_text(encoding='utf-8-sig')
files = {}
for p in study.rglob('*'):
    assert not p.is_symlink()
    if p.is_file() and p.name not in {'seal-v2.json', 'pr65-before.json', 'pr65-body.md'}:
        files[p.relative_to(root).as_posix()] = p.read_bytes()
for rel in [
    'src/flydrones/mission_agent.py', 'src/flydrones/task_consensus.py',
    'src/flydrones/mission_stress.py', 'src/flydrones/task_udp.py',
    'src/flydrones/mission_contract.py', 'src/flydrones/peer_udp.py',
    'tests/test_mission_agent.py', 'tests/test_task_consensus.py',
    'tests/test_mission_contract.py', 'tests/test_task_udp.py',
    'docs/MISSION_CLOCK_REFUSAL_REPORT.md',
    'docs/superpowers/plans/2026-10-14-mission-clock-refusal.md',
]:
    files[rel] = (root / rel).read_bytes()
manifest = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
            for name, data in sorted(files.items())}
archive = root / 'evidence/mission-clock-refusal-dev-1701-v2.zip'
with ZipFile(archive, 'x', ZIP_DEFLATED) as z:
    for name, data in sorted(files.items()):
        z.writestr(name, data)
    z.writestr('manifest.json', json.dumps(manifest, indent=2))
with ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(set(z.namelist()))
    for name, entry in manifest.items():
        data = z.read(name)
        assert len(data) == entry['bytes']
        assert hashlib.sha256(data).hexdigest() == entry['sha256']
        assert data == (root / name).read_bytes()
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
archive.with_suffix('.sha256').open('x').write(digest + '  ' + archive.name + '\n')
record = {'sha256': digest, 'members': len(manifest) + 1, 'bytes': archive.stat().st_size,
          'crc_member_hash_current_verified': True, 'prior_archive_hashes_unchanged': old,
          'tests_passed': 109, 'complete_model_trained': False,
          'continuous_clock_calibrated': False, 'physical_verified': False}
(study / 'seal-v2.json').open('x').write(json.dumps(record, indent=2))
print(json.dumps(record))
