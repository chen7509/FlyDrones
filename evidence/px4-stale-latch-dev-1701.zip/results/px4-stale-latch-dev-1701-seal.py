"""Seal the bounded PX4 source-loss regression evidence."""

from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PREFIX = "px4-stale-latch-dev-1701"
ARCHIVE = ROOT / "evidence" / f"{PREFIX}.zip"


def main() -> None:
    files = [
        ROOT / "src/flydrones/connectome_training/px4_odometry_adapter.py",
        ROOT / "tests/connectome_training/test_px4_odometry_causal_adapter.py",
        ROOT / "docs/PX4_STALE_SOURCE_LATCH_REPORT.md",
        *sorted((ROOT / "results").glob(f"{PREFIX}-*")),
    ]
    files = sorted((p for p in files if p.is_file()), key=lambda p: p.relative_to(ROOT).as_posix())
    names = [p.relative_to(ROOT).as_posix() for p in files]
    if len(names) != len(set(names)) or len(files) < 7 or ARCHIVE.exists():
        raise RuntimeError("evidence members missing, duplicated or already sealed")
    manifest = {
        "schema": "px4-stale-latch-evidence-v1",
        "scope": "synthetic and file-level source-loss refusal; no live PX4 capture",
        "members": [
            {"path": name, "bytes": p.stat().st_size,
             "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
            for name, p in zip(names, files, strict=True)
        ],
    }
    ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ARCHIVE, "x") as archive:
        for name, p in zip(names, files, strict=True):
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 10, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, p.read_bytes())
        info = zipfile.ZipInfo("evidence-manifest.json", date_time=(2026, 10, 10, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, json.dumps(manifest, indent=2).encode() + b"\n")
    print(json.dumps({"members": len(files) + 1,
                      "sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()}))


if __name__ == "__main__":
    main()
