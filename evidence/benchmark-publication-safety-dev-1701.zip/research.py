import hashlib
import json
import urllib.request
from pathlib import Path

base = Path(__file__).parent
target = base / 'research-v1'
target.mkdir(exist_ok=False)
url = 'https://raw.githubusercontent.com/ArduPilot/pymavlink/v2.4.49/mavutil.py'
record = {'url': url, 'version': 'v2.4.49', 'license': 'LGPL-3.0-or-later',
          'installed_equivalence_verified': False, 'maintenance': 'not newly verified',
          'interface': 'post_message message_hooks before recv_match type filtering',
          'cost': 'one owned synchronous decode callback; no new dependency or sensor load',
          'choice': 'reuse official hook; reject cache renewal and a second competing socket reader',
          'initial_web_url_without_v_prefix': '404 retained in tool history; corrected tag prefix',
          'protocol_docs': ['https://mavlink.io/en/messages/common.html#SET_POSITION_TARGET_LOCAL_NED',
                            'https://docs.px4.io/main/en/flight_modes/offboard'],
          'paper_boundary': 'No algorithm or estimator change. Protocol-source safety is not validated by VIO papers.'}
try:
    with urllib.request.urlopen(url, timeout=15) as response:
        data = response.read()
    (target / 'mavutil-v2.4.49.py.txt').write_bytes(data)
    record['source_sha256'] = hashlib.sha256(data).hexdigest()
    record['source_bytes'] = len(data)
    record['download_status'] = 'success'
except Exception as error:
    record['download_status'] = 'failed'
    record['error'] = repr(error)
(target / 'record.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
print(json.dumps(record, indent=2))
