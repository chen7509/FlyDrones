import hashlib
import importlib.metadata
import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
base = Path(__file__).parent
execution = json.loads((base / 'final-v2/execution.json').read_text())
assert execution['source_unchanged'] and all(item['exit_code'] == 0 for item in execution['commands'])
for name, digest in execution['source_after'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest
    dest = base / 'final-source' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root / name, dest)
for name in ['docs/BENCHMARK_PUBLICATION_SAFETY_REPORT.md',
             'docs/superpowers/specs/2026-10-12-benchmark-publication-safety-design.md',
             'docs/superpowers/plans/2026-10-12-benchmark-publication-safety.md']:
    dest = base / 'documents' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root / name, dest)
baseline = subprocess.run(['git', 'show', 'b281d4a:src/flydrones/benchmark/gateway.py'],
                          cwd=root, stdout=subprocess.PIPE, check=True).stdout
(base / 'baseline-gateway-postexport.py.txt').write_bytes(baseline)
versions = {'python': sys.version, 'executable': sys.executable,
            'baseline': 'b281d4a', 'baseline_export': 'post-run Git export, not pre-run capture',
            'numpy': importlib.metadata.version('numpy'),
            'pytest': importlib.metadata.version('pytest'),
            'ruff': importlib.metadata.version('ruff'),
            'physics_training_hardware_network_executed': False,
            'source_clock_arrival_health_flight_qualified': False,
            'full_repository_rerun': False}
(base / 'versions.json').write_text(json.dumps(versions, indent=2), encoding='utf-8')
files = sorted(path for path in base.rglob('*') if path.is_file() and path.suffix != '.pyc'
               and path.name not in ('seal.json', 'pr65-before.json'))
members = {path.relative_to(base).as_posix(): {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
           'bytes': path.stat().st_size} for path in files}
target = root / 'evidence/benchmark-publication-safety-dev-1701.zip'
with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in files:
        assert not path.is_symlink()
        archive.write(path, path.relative_to(base).as_posix())
    archive.writestr('member-hashes.json', json.dumps(members, indent=2))
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(members) | {'member-hashes.json'}
    for name, expected in members.items():
        raw = archive.read(name)
        assert hashlib.sha256(raw).hexdigest() == expected['sha256'] and len(raw) == expected['bytes']
digest = hashlib.sha256(target.read_bytes()).hexdigest()
with target.with_suffix('.sha256').open('x', encoding='ascii') as stream:
    stream.write(digest + '  ' + target.name + '\n')
record = {'sha256': digest, 'members': len(members)+1, 'bytes': target.stat().st_size,
          'all_member_hashes_and_crc_verified': True, 'targeted': 31, 'affected_regression': 221,
          'source_clock_arrival_health_flight_qualified': False}
with (base / 'seal.json').open('x', encoding='utf-8') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record, indent=2))
