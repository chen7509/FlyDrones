import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[2]
base = Path(__file__).parent
out = base / 'final-v2'
out.mkdir(exist_ok=False)
sources = ['src/flydrones/benchmark/gateway.py', 'tests/benchmark/test_publication_safety.py',
           'src/flydrones/drones/mavlink.py', 'src/flydrones/benchmark/clock.py']
def hashes():
    return {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in sources}
before = hashes()
env = os.environ.copy()
env['PYTHONPATH'] = str(root / 'src') + os.pathsep + str(root)
commands = [
    [sys.executable, '-m', 'pytest', 'tests/benchmark/test_publication_safety.py',
     'tests/benchmark/test_clock.py', 'tests/test_mavlink_position_freshness.py',
     'tests/benchmark/test_stationary_prelude.py',
     'tests/benchmark/test_rgb_capture.py', 'tests/benchmark/test_camera_info_capture.py',
     'tests/benchmark/test_ulog_capture.py', 'tests/benchmark/test_ulog_health.py',
     'tests/benchmark/test_ekf2_heading_probe.py',
     'tests/benchmark/test_disarmed_sensor_provenance.py',
     'tests/connectome_training/test_capture_input_gate.py', '-q'],
    [sys.executable, '-m', 'ruff', 'check', sources[0], sources[1]],
    ['git', 'diff', '--check'],
]
results = []
for index, command in enumerate(commands):
    result = subprocess.run(command, cwd=root, env=env, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, timeout=120)
    (out / f'command-{index}.txt').write_bytes(result.stdout)
    results.append({'command': command, 'exit_code': result.returncode})
after = hashes()
record = {'source_before': before, 'source_after': after,
          'source_unchanged': before == after, 'commands': results,
          'scope': 'pure fake links, servers and bounded Python threads; no native or socket jobs'}
(out / 'execution.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
print(json.dumps(record, indent=2))
if before != after or any(item['exit_code'] for item in results):
    raise SystemExit(1)
