from pathlib import Path
b=Path(__file__).resolve().parent;root=b.parents[1]
s=(root/'results/native-runtime-refusal-dev-1701/seal_evidence.py').read_text()
start=s.index('files = ');end=s.index('\nfor name in files:',start)
files=['tools/benchmark/owned_group_evidence.py','tools/benchmark/disarmed_sensor_provenance.py','tools/benchmark/capture_disarmed_sensors.py','tests/benchmark/test_owned_group_evidence.py','tests/benchmark/check_owned_groups.py','docs/OWNED_GROUP_EVIDENCE_REPORT.md','docs/superpowers/specs/2026-10-06-owned-group-evidence.md','docs/superpowers/plans/2026-10-06-owned-group-evidence.md','.superpowers/sdd/2026-10-06-owned-group-evidence/progress.md']
s=s[:start]+'files = '+repr(files)+s[end:]
s=s.replace('7a2271d..dc23e19','27c9897..95dc10a').replace('dc23e19..HEAD','95dc10a..HEAD').replace('evidence/native-runtime-refusal-dev-1701.zip','evidence/owned-group-evidence-dev-1701.zip')
with (b/'seal_evidence.py').open('x') as f:f.write(s)
