from pathlib import Path
import json,re,subprocess
b=Path(__file__).resolve().parent;root=b.parents[1]
log=(b/'regression-final.txt').read_text(encoding='utf-8-sig')
assert re.search(r'941 passed, 2 warnings in [\d.]+s',log),log[-500:]
p=root/'docs/OWNED_GROUP_EVIDENCE_REPORT.md';s=p.read_text(encoding='utf-8').replace('Initial full regression937 passed; final regression and publication are recorded below at closure.','Initial full regression937 passed; final full regression941 passed with two existing loader warnings. Changed Ruff passes; whole-repository lint retains50 errors in32 unchanged files. The lifecycle report does not claim whole-repository lint success.');p.write_text(s,encoding='utf-8')
p=root/'docs/superpowers/plans/2026-10-06-owned-group-evidence.md';s=p.read_text(encoding='utf-8').replace('- [ ]','- [x]');s+='\nThis stage validates bounded process-group mechanics. Actual PX4 integration and escaped descendants are not certified; retain these boundaries in publication.\n';p.write_text(s,encoding='utf-8')
p=root/'.superpowers/sdd/2026-10-06-owned-group-evidence/progress.md';s=p.read_text(encoding='utf-8').replace('finalregressionpendingaftercaptureULogguard','final941fullregressionpass/2existingwarningsaftercaptureULogguard');p.write_text(s,encoding='utf-8')
r=subprocess.run(['wsl','-d','Ubuntu','--cd','/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility','python3','-c','from tools.benchmark.capture_disarmed_sensors import active_resources; print(active_resources())'],capture_output=True)
assert r.returncode==0 and r.stdout.strip()==b'[]',r.stdout
with (b/'final-resource-check.json').open('x') as f:json.dump(dict(exit=r.returncode,filtered_resources=[],scope='read-only filtered simulator/training inventory; real group absence separately in runtime-v1 evidence',stderr=r.stderr.decode('utf-8',errors='replace')),f,indent=2)
print('941 regression confirmed, final resource check empty')
