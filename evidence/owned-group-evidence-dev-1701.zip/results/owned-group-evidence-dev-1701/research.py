import hashlib,json,urllib.request,shutil
from pathlib import Path
b=Path(__file__).resolve().parent;root=b.parents[1];d=b/'sources';d.mkdir(exist_ok=False)
prior=root/'results/native-runtime-refusal-dev-1701/next-sources-v2'
for p in prior.iterdir():shutil.copyfile(p,d/p.name)
urls={'waitid.html':'https://man7.org/linux/man-pages/man2/waitid.2.html','kill.html':'https://man7.org/linux/man-pages/man2/kill.2.html','proc_stat.html':'https://man7.org/linux/man-pages/man5/proc_pid_stat.5.html','cpython-maintenance.json':'https://api.github.com/repos/python/cpython'}
rows=[]
for name,url in urls.items():
 try:
  data=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'FlyDrones-evidence'}),timeout=30).read();(d/name).write_bytes(data);rows.append(dict(name=name,url=url,sha256=hashlib.sha256(data).hexdigest()))
 except Exception as exc:rows.append(dict(name=name,url=url,error=repr(exc)))
(d/'additional-manifest.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows))
