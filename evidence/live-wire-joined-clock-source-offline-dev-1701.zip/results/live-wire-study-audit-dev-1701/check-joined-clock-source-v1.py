"""Retain a partial synthetic integration bundle; never launch a simulator."""
import hashlib
import json
import sys
from pathlib import Path

from tests.benchmark.live_wire_joined_fixture import (
    DAEMON, add_joined_sources, build_joined_wire_physics, read_joined_fixture,
)
from tools.benchmark import audit_live_wire_study as audit
from tools.benchmark import audit_live_wire_coverage, audit_live_wire_resources, audit_live_wire_safety
from tools.benchmark.audit_live_wire_workload import audit_source_native_records

root = Path(__file__).resolve().parents[2]
output = root / "results/live-wire-study-audit-dev-1701/joined-clock-source-v1"
output.mkdir()

def code_snapshot():
    records = {}
    for module in list(sys.modules.values()):
        path = getattr(module, "__file__", None)
        if path is None:
            continue
        path = Path(path).resolve()
        if path.suffix == ".py" and path.is_relative_to(root):
            raw = path.read_bytes()
            records[str(path.relative_to(root))] = dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    return records

before = code_snapshot()
for name in before:
    destination = output / "producer" / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes((root / name).read_bytes())
(output / "producer-before.json").write_text(json.dumps(before, indent=2))
generated = build_joined_wire_physics(output / "capture")
add_joined_sources(generated)
del generated
e = read_joined_fixture(output / "capture")
checks = dict(
    protocol=audit.audit_wire_protocol_records(records=e["records"], clock=e["clock"],
        clock_attempts=e["clock_attempts"], context=e["context"]),
    interval=audit.audit_wire_interval_records(e["records"], e["context"]),
    listener=audit.audit_owned_listener_records(records=e["records"], context=e["context"], daemon_path=DAEMON),
    physical=audit.audit_physical_coverage_records(**e["physical"]),
    source=audit_source_native_records(**e["source"]),
    camera=audit.audit_camera_info_records(**e["camera"]),
    health=audit.audit_health_coverage_records(**e["health"]),
    source_health=audit.audit_source_health_records(**e["source_health"]),
)
after = code_snapshot()
assert all(after[name] == record for name, record in before.items())
result = dict(schema="joined-offline-check-v1", checks=checks, consumed_files=e["consumed_files"],
    producer_before=before, producer_after=after, predeclared_loaded_sources_stable=True,
    late_imports=sorted(set(after)-set(before)), full_runtime_freeze_qualified=False,
    synthetic_provenance=True, whole_study_qualified=False, physical_execution_qualified=False,
    live_qualified=False, fusion_qualified=False)
(output / "audit.json").write_text(json.dumps(result, indent=2))
print(json.dumps(dict(checks=list(checks), consumed_files=len(e["consumed_files"]),
                     producer_sources=len(before), late_imports=result["late_imports"],
                     synthetic_provenance=True, whole_study_qualified=False)))
