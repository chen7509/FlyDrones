"""Verify fixed EGO headers and the preceding commit-tree audit archive."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).resolve().parent
UPSTREAM_COMMIT = "23a8d5a191711dd65633df689bd00f55d4dea8f9"
PREVIOUS_ARCHIVE_SHA256 = "cb460e46c77cdff13a42a201bff2743384256ece9a687d580ed095e815e0aa14"
HEADERS = {
    "grid_map.h": ("src/planner/plan_env/include/plan_env/grid_map.h",
                   "cd238a41db291c0e70e19d4cd9a34ed6031fd74e"),
    "ego_replan_fsm.h": ("src/planner/plan_manage/include/ego_planner/ego_replan_fsm.h",
                         "ed914627d3722474c8d9e884a9ace0384b426035"),
    "planner_manager.h": ("src/planner/plan_manage/include/ego_planner/planner_manager.h",
                          "74b61788a4140fa32f03e3dc0ed0c812d1368481"),
}


def main() -> None:
    previous = (ROOT / "evidence/ego-causal-provenance-dev-1701.zip").read_bytes()
    if hashlib.sha256(previous).hexdigest() != PREVIOUS_ARCHIVE_SHA256:
        raise ValueError("previous upstream audit archive changed")
    files = {}
    for name, (upstream_path, git_blob_sha1) in HEADERS.items():
        data = (STAGE / "pinned-headers" / name).read_bytes()
        blob = b"blob " + str(len(data)).encode("ascii") + b"\0" + data
        if hashlib.sha1(blob).hexdigest() != git_blob_sha1:
            raise ValueError(f"pinned upstream header changed: {name}")
        files[name] = {
            "upstream_path": upstream_path,
            "git_blob_sha1": git_blob_sha1,
            "sha256": hashlib.sha256(data).hexdigest(),
            "bytes": len(data),
        }
    manifest = {
        "upstream_commit": UPSTREAM_COMMIT,
        "prior_audit_archive_sha256": PREVIOUS_ARCHIVE_SHA256,
        "headers": files,
        "runtime_build_verified": False,
    }
    (STAGE / "header-provenance.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"verified_headers": len(files), "prior_archive_verified": True}))


if __name__ == "__main__":
    main()
