"""Seal the offline-only EGO causal join contract stage."""

import hashlib
import json
import zipfile
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
STAGE = "results/ego-causal-join-dev-1701"
OUT = ROOT / "evidence/ego-causal-join-dev-1701.zip"
FILES = [
    "src/flydrones/benchmark/ego_causal_join.py",
    "tests/benchmark/test_ego_causal_join.py",
    "docs/EGO_CAUSAL_JOIN_CONTRACT_REPORT.md",
    "results/ego-causal-provenance-dev-1701/source/LICENSE",
    *[f"{STAGE}/pinned-headers/{name}" for name in (
        "ego_replan_fsm.h", "grid_map.h", "planner_manager.h")],
    *[f"{STAGE}/{name}" for name in (
        "audit_headers.py", "header-provenance.json", "header-audit-output.txt",
        "red.txt", "red-path-fixed.txt", "red-hash-binding.txt", "red-boundary.txt",
        "green-v1.txt", "green-hash-binding.txt", "green-boundary.txt",
        "adjacent-tests-final.txt", "ruff-final.txt", "diff-check.txt",
        "seal-failure.txt", "seal-partial-v1.zip", "seal.py")],
]


def main() -> None:
    if OUT.exists():
        raise FileExistsError(OUT)
    entries = {}
    with zipfile.ZipFile(OUT, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for relative in FILES:
            data = (ROOT / relative).read_bytes()
            archive.writestr(relative, data)
            entries[relative] = {
                "bytes": len(data),
                "sha256": hashlib.sha256(data).hexdigest(),
                "crc32": format(zlib.crc32(data) & 0xFFFFFFFF, "08x"),
            }
        archive.writestr("MANIFEST.json", json.dumps(entries, indent=2, sort_keys=True))
    with zipfile.ZipFile(OUT) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == set(FILES) | {"MANIFEST.json"}
        for relative, expected in entries.items():
            data = archive.read(relative)
            assert len(data) == expected["bytes"]
            assert hashlib.sha256(data).hexdigest() == expected["sha256"]
            assert format(zlib.crc32(data) & 0xFFFFFFFF, "08x") == expected["crc32"]
    print(json.dumps({"zip": str(OUT), "members": len(entries) + 1,
                      "sha256": hashlib.sha256(OUT.read_bytes()).hexdigest()}, sort_keys=True))


if __name__ == "__main__":
    main()
