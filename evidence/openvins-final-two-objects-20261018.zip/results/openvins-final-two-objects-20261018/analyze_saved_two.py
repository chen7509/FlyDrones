"""Derive this two-selection evidence only from saved Windows bytes."""
import collections
import hashlib
import json
from pathlib import Path
import posixpath
import struct

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
c=json.loads((OUT/'selection-contract.json').read_bytes())
f=json.loads((OUT/'current-files.json').read_bytes())
done=json.loads((OUT/'collection-completion.json').read_bytes())
build=c['build_root']


def save(name,value):
    with (OUT/name).open('x',encoding='utf-8') as s:json.dump(value,s,indent=2,ensure_ascii=True)


def data(row):
    raw=(OUT/row['blob']).read_bytes()
    assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
    return raw


def elf_object(raw, source):
    if raw[:6] != b'\x7fELF\x02\x01' or len(raw) < 64:
        raise ValueError('only complete ELF64 little endian observations supported')
    etype, machine = struct.unpack_from('<HH', raw, 16)
    shoff = struct.unpack_from('<Q', raw, 40)[0]
    entsize, count, namesidx = struct.unpack_from('<HHH', raw, 58)
    if entsize != 64 or count == 0 or namesidx == 65535:
        raise ValueError('unsupported extended section indexing')
    if count > 65534 or shoff+count*64 > len(raw) or namesidx >= count:
        raise ValueError('invalid section table')
    sections = [struct.unpack_from('<IIQQQQIIQQ', raw, shoff+i*64) for i in range(count)]
    ns = sections[namesidx]
    if ns[4]+ns[5] > len(raw):
        raise ValueError('invalid section name bytes')
    names = raw[ns[4]:ns[4]+ns[5]]
    selected = {}
    for s in sections:
        end = names.index(b'\0', s[0])
        name = names[s[0]:end].decode('ascii', errors='backslashreplace')
        if s[1] != 8 and s[4]+s[5] > len(raw):
            raise ValueError('section outside retained object')
        if name in ('.comment', '.debug_line_str', '.debug_str', '.debug_info', '.text', '.symtab'):
            selected[name] = dict(offset=s[4], bytes=s[5], flags=s[2])
    result = dict(elf_class=64, little_endian=True, e_type=etype, machine=machine,
                  section_count=count, selected_sections=selected, executed_or_loaded=False,
                  source_to_object_proven=False, object_to_library_proven=False)
    comment = selected.get('.comment')
    if comment:
        result['comment_strings'] = [x.decode('utf-8', errors='backslashreplace')
            for x in raw[comment['offset']:comment['offset']+comment['bytes']].split(b'\0') if x]
    line = selected.get('.debug_line_str')
    if line and not line['flags'] & 2048:
        text = raw[line['offset']:line['offset']+line['bytes']]
        strings = text.split(b'\0')
        result['debug_line_string_observations'] = dict(
            exact_source_path_present=source.encode() in strings,
            source_basename_present=posixpath.basename(source).encode() in strings,
            build_path_present=build.encode() in strings,
            note='String-table occurrences only; not DWARF DIE/path/relocation attribution or source digest.')
    return result


bindings={};objects={}
selected={r['object']:r for r in c['associations']}
assert set(f)<=set(selected) and set(f).isdisjoint(c['previously_acquired_paths'])
assert set(f).isdisjoint(c['known_overcap_paths_not_reprobed'])
for name,row in f.items():
    if row['status']=='observed':
        raw=data(row);assert row['before']==row['after']
        bindings[name]=dict(**row,linux_native_identity_verified=False,native_admission=False)
        try:objects[name]=elf_object(raw,selected[name]['source'])
        except (ValueError,IndexError,struct.error) as exc:objects[name]=dict(parse_error=repr(exc),source_to_object_proven=False)
save('file-bindings.json',dict(schema='openvins-two-object-file-observations-v1',files=bindings,
    current_library_sha256=None,all_qualifications=False,source_to_existing_library_proven=False))
save('object-static-observations.json',dict(schema='openvins-two-object-static-v1',objects=objects,
    note='ELF and strings from actual retained objects only. No load/execution, ABI, compiler identity or historical source content proof.'))
prior={}
for r in c['prior_manifest_references']:
    raw=(ROOT/r['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['sha256']
    prior.update(json.loads(raw))
units=[]
for a in c['all_associations']:
    n=a['object'];entry=dict(source=a['source'],object=n,depfile=a['depfile'],
        source_to_object_proven=False,object_to_library_proven=False,historical_same_build_session_proven=False)
    if n in f:
        row=f[n];entry.update(this_collection_status=row['status'],metadata_this_collection=row.get('before'))
        if row.get('blob'):entry['retained_observation']=dict(phase='results/openvins-two-objects-20261018',
            blob=row['blob'],bytes=row['bytes'],sha256=row['sha256'],build_time_input_bytes_proven=False)
    elif n in c['previously_acquired_paths']:
        entry['this_collection_status']='excluded_previously_acquired'
        entry['retained_observation']=dict(**c['previously_acquired_paths'][n],build_time_input_bytes_proven=False)
    elif n in c['known_overcap_paths_not_reprobed']:
        entry['this_collection_status']='known_overcap_skipped_without_stat_open_read'
        entry['previous_overcap_observation']=c['known_overcap_paths_not_reprobed'][n]
    else:entry['this_collection_status']='not_attempted_after_stop'
    d=prior.get(a['depfile'])
    if d and d.get('blob'):entry['prior_depfile_observation']=dict(phase='results/openvins-build-provenance-20261018',
        blob=d['blob'],bytes=d['bytes'],sha256=d['sha256'],historical_input_content_proven=False)
    units.append(entry)
save('object-union-bindings.json',dict(schema='openvins-two-selection-union-v1',units=units,
    note='Actual object observations across different times, referenced to prior34TU/depfile/link names; not atomic build snapshot or proof these bytes were linked.',
    atomic_snapshot=False,historical_build_session_proven=False,source_to_existing_library_proven=False))
unknown=[e for e in units if 'retained_observation' not in e]
summary=dict(schema='openvins-two-selection-summary-v1',authorized_object_paths=len(selected),attempted_paths=len(f),
    status_counts=dict(collections.Counter(r['status'] for r in f.values())),new_objects_observed=len(bindings),
    deduplicated_blobs=len({r['sha256'] for r in bindings.values()}),actual_payload_bytes_read=done['payload_bytes_read'],
    new_payload_bytes=sum(r['bytes'] for r in bindings.values()),prior_acquired_exclusion_paths=len(c['previously_acquired_paths']),
    prior_acquired_path_overlap=len(set(f)&set(c['previously_acquired_paths'])),
    known_overcap_paths_reprobed=len(set(f)&set(c['known_overcap_paths_not_reprobed'])),
    new_static_rel_x86_64=sum(r.get('e_type')==1 and r.get('machine')==62 for r in objects.values()),
    object_parse_errors={n:r for n,r in objects.items() if 'parse_error' in r},
    total_objects_with_retained_bytes=sum('retained_observation' in e for e in units),total_declared_objects=len(units),objects_remaining_unknown=len(unknown),
    current_known_overcap_objects=sum(e['this_collection_status'] in ('file_cap','known_overcap_skipped_without_stat_open_read') for e in units),
    unacquired_not_confirmed_overcap=sum(e['this_collection_status'] in ('aggregate_cap','not_attempted_after_stop') for e in units),
    no_log_search=True,no_directory_enumeration=True,acquisition_complete=done['complete'],stop_reason=done.get('stop_reason'),
    current_library_sha256=None,source_to_existing_library_proven=False,native_admission=False,all_qualifications=False,
    native_commands=False,resource_queries=False,tests_run=False,linux_writes=False)
save('analysis-summary.json',summary)
save('missing-evidence.json',dict(schema='openvins-two-selection-missing-evidence-v1',unobserved_objects=unknown,
    current_library_sha256=None,source_to_existing_library_proven=False,
    gaps=['Two objects remain unobserved: previously confirmed DynamicInitializer81,028,080B and Propagator81,915,872B exceed64MiB; neither was stat/open/read again.',
        'Known overcap DynamicInitializer and old291717384B library not stat/open/read. No strip/chunk reassembly/rebuild/replace or higher cap.',
        'No new log search or directory enumeration in this narrow authorization; prior bounded log searches do not prove logs absent everywhere.',
        '32/34 object bytes across multiple observations are not a build-time snapshot or authenticated main compile/link execution receipt.',
        'Original source/header/tool input content, compiler identity, build-session and object-to-library association remain unproven.',
        'Linux native identity/links/permissions, full current sourcebuild/tool/header/library/package/loader/ABI closure and remaining original runtime gates unproven.',
        'All qualification/readiness/dispatch flags remainfalse; no native experiment/resource query/old test executed.']))
print(json.dumps(summary))
