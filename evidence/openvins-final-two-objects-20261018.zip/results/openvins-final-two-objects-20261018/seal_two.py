"""New exact-two evidence integrity only, not source provenance or native approval."""
import ast
import hashlib
import json
from pathlib import Path
import zipfile

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
POST=OUT/'postseal'
FILES=['docs/OPENVINS_FINAL_TWO_OBJECTS_PROGRESS.md','docs/superpowers/plans/2026-10-18-openvins-final-two-objects.md']
FILES+=['results/openvins-final-two-objects-20261018/'+n+'-v2.json' for n in (
    'file-bindings','object-static-observations','object-union-bindings','analysis-summary','missing-evidence')]


def sha(raw):return hashlib.sha256(raw).hexdigest()


s=json.loads((OUT/'analysis-summary-v2.json').read_bytes())
c=json.loads((OUT/'selection-contract.json').read_bytes())
f=json.loads((OUT/'current-files.json').read_bytes())
assert s['status_counts']==dict(observed=2) and s['authorized_object_paths']==len(f)==2
assert set(f).isdisjoint(c['previously_acquired_paths']) and set(f).isdisjoint(c['known_overcap_paths_not_reprobed'])
assert s['new_static_rel_x86_64']==2 and not s['object_parse_errors']
assert s['actual_payload_bytes_read']==s['new_payload_bytes']==76493424<201326592
assert s['total_objects_with_retained_bytes']==32 and s['objects_remaining_unknown']==2
assert s['current_known_overcap_objects']==2 and s['unacquired_not_confirmed_overcap']==0
assert s['acquisition_complete'] and not s['source_to_existing_library_proven']
assert s['current_library_sha256'] is None and s['native_admission'] is False
for row in f.values():
    raw=(OUT/row['blob']).read_bytes()
    assert row['status']=='observed' and len(raw)==row['bytes']<=67108864
    assert sha(raw)==row['sha256'] and row['before']==row['after']
v1=json.loads((OUT/'object-union-bindings.json').read_bytes())
v2=json.loads((OUT/'object-union-bindings-v2.json').read_bytes())
assert json.loads(json.dumps(v1).replace('results/openvins-two-objects-20261018','results/openvins-final-two-objects-20261018'))==v2
assert sum(u.get('retained_observation',{}).get('phase')=='results/openvins-final-two-objects-20261018' for u in v2['units'])==2
for unit in v2['units']:
    if 'retained_observation' in unit:
        r=unit['retained_observation'];assert (ROOT/r['phase']/r['blob']).is_file()
for name in ('file-bindings','object-static-observations','analysis-summary','missing-evidence'):
    assert json.loads((OUT/(name+'.json')).read_bytes())==json.loads((OUT/(name+'-v2.json')).read_bytes())
for p in OUT.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'),filename=str(p))
with (OUT/'self-check.json').open('x',encoding='utf-8') as stream:
    json.dump(dict(scope='Executor newbytes/JSON/helperAST and v2 saved reference paths only; no old payload rehash/archive/tests/source/native/delivery review.',
        new_files_verified=2,new_objects_static_rel_x86_64=2,prior_path_overlap=0,known_overcap_paths_reprobed=0,
        exact_two_collection_complete=True,total_retained_objects=32,objects_unknown=2,
        v1_to_v2_new_phase_label_only=True,v1_retained=True,all_v2_retained_blob_references_exist=True,
        current_library_sha256=None,source_to_existing_library_proven=False,
        native_commands=False,resource_queries=False,tests_run=False,all_qualifications=False),stream,indent=2)
paths=set(FILES)
for p in OUT.rglob('*'):
    if 'postseal' in p.relative_to(OUT).parts or '__pycache__' in p.parts or p.suffix=='.pyc':continue
    if p.is_file() and not p.is_symlink():paths.add(p.relative_to(ROOT).as_posix())
mapping={};archive=ROOT/'evidence/openvins-final-two-objects-20261018.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as output:
    for name in sorted(paths):
        raw=(ROOT/name).read_bytes();mapping[name]=dict(bytes=len(raw),sha256=sha(raw))
        entry=zipfile.ZipInfo(name,(2026,10,18,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;entry.external_attr=0o100600<<16
        output.writestr(entry,raw)
    manifest=json.dumps(dict(schema='openvins-final-two-evidence-archive-v1',mapping=mapping,
        note='Only two new actual object payloads; v1 phase-label error retained and additivev2 canonical; old library provenance/native admission unproven.'),sort_keys=True,indent=2).encode()
    output.writestr('manifest.json',manifest)
with zipfile.ZipFile(archive) as source:
    assert source.testzip() is None and len(source.namelist())==len(mapping)+1
    for name,row in mapping.items():assert sha(source.read(name))==row['sha256']
receipt=dict(schema='openvins-final-two-seal-v1',archive=archive.relative_to(ROOT).as_posix(),bytes=archive.stat().st_size,
    sha256=sha(archive.read_bytes()),members=len(mapping)+1,mapped=len(mapping),
    mapped_payload_bytes=sum(r['bytes'] for r in mapping.values()),manifest_bytes=len(manifest),
    whole_expanded_bytes=sum(r['bytes'] for r in mapping.values())+len(manifest),software_files=FILES,
    source_to_existing_library_proven=False,native_admission=False,all_qualifications=False)
with archive.with_suffix('.sha256.json').open('x',encoding='utf-8') as stream:json.dump(dict(**receipt,mapping=mapping),stream,indent=2)
POST.mkdir(exist_ok=False)
with (POST/'seal-receipt.json').open('x',encoding='utf-8') as stream:json.dump(receipt,stream,indent=2)
print(json.dumps({k:v for k,v in receipt.items() if k!='software_files'}))
