## Task 3: Actual CLI evidence and review

Files: docs/CONNECTOME_INFERENCE_PROBE_REPORT.md;
results/connectome-inference-probe-dev-1701 and corresponding evidence ZIP.

- [ ] After idle check and source commit, once call actual full CLI against existing
  full initialization; preserve resource refusal if <4GiB, never force allocation.
  Run separate tiny fixture invocation; never label it full or trained performance.
- [ ] Full pytest, changed Ruff/diff, one independent review. Important findings
  get behavioral RED/GREEN; minor coverage honestly labeled.
- [ ] Record source/config/version/input hashes, report actual outcomes/limits,
  seal member hashes/CRC, commit locally; retain remote publication constraint.

## Review focus

No spawned model when memory unavailable; no successful result after timeout;
no callback I/O inside measured step; no camera timestamp fabrication on reuse;
no tiny/initialization evidence promoted into trained full or flight performance.
