## Task 2: Parent and actual worker

Files: tools/connectome_training/profile_inference.py;
tests/connectome_training/test_inference_probe.py.
Consumes Task1 hook and previous real loader/controller. Produces `ProbeSpec`,
`available_memory_bytes()`, `run_probe(spec, output)`, private worker entry and CLI.

- [ ] RED strict fields/checkpoint pairing, low/unknown RAM refuses before spawn,
  exclusive directory, request/input drift, retained errors, actual tiny worker
  lifecycle and camera reuse, timeout cleanup/partial logs, no false full gate.
- [ ] Implement fixed worker command, stdlib preflight, request digest, direct-child
  bounded ownership, worker recheck, profiler journaling and reports per spec.
- [ ] Run `python -m pytest tests/connectome_training/test_inference_probe.py
  tests/connectome_training/test_profiling.py tests/connectome_training/test_inference.py
  tests/connectome_training/test_inference_artifact.py -q`; commit.

