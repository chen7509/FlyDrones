## Task 1: Streaming external timing

Files: src/flydrones/connectome_training/profiling.py;
tests/connectome_training/test_profiling.py.
Produces `profile_controller(controller, observations, *, on_sample=None)`.

- [ ] RED callback is after measured finish; receives raw timestamps and defensive
  copy; exception aborts after preserving earlier rows. Existing stats unchanged.
- [ ] Implement optional callback, no change to default behavior or timing boundary.
- [ ] Run `python -m pytest tests/connectome_training/test_profiling.py
  tests/connectome_training/test_profile_baseline.py -q`; commit.

