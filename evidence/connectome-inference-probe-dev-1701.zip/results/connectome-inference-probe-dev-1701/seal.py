"""Seal post-verification copies; no model execution or historical rewrite."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path(__file__).resolve().parents[2]
results = Path(__file__).resolve().parent
archive = root / 'evidence/connectome-inference-probe-dev-1701.zip'
request = json.loads((results / 'tiny-attempt-v1/request.json').read_text())
paths = set()
for entry in request['input_hashes'].values():
    path = Path(entry['path'])
    if hashlib.sha256(path.read_bytes()).hexdigest() != entry['sha256']:
        raise ValueError(f'Input drift: {path}')
    paths.add(path)
paths.update(p for p in results.rglob('*') if p.is_file() and p.name != 'seal-result.json')
paths.update(p for p in (root / '.superpowers/sdd/2026-10-09-connectome-inference-probe').rglob('*') if p.is_file())
paths.update(root / p for p in [
    'docs/CONNECTOME_INFERENCE_PROBE_REPORT.md',
    'docs/superpowers/specs/2026-10-09-connectome-inference-probe-design.md',
    'docs/superpowers/plans/2026-10-09-connectome-inference-probe.md',
    'tests/connectome_training/test_profiling.py',
    'tests/connectome_training/test_inference_probe.py',
    'results/connectome-training/stage-a/baseline_profile.json',
])
baseline = root / 'results/connectome-training/stage-a/baseline_profile.json'
if hashlib.sha256(baseline.read_bytes()).hexdigest() != '40b9765ba77ad9efd6d87e926831824e969ab876b4ffe9dc02f2c407169a6534':
    raise ValueError('Historical baseline drift')
payload = {p.relative_to(root).as_posix(): p.read_bytes() for p in paths}
manifest = {
    'schema': 'flydrones-inference-probe-evidence-v1',
    'git_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'snapshot_basis': 'post-verification source/document copies; tiny selected inputs checked against actual request; not full runtime closure',
    'full_model_executed': False,
    'tiny_model_executed': True,
    'flight_eligible': False,
    'training_success_verified': False,
    'members': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in sorted(payload.items())},
}
payload['MANIFEST.json'] = json.dumps(manifest, indent=2, sort_keys=True).encode() + b'\n'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as bundle:
    for name, data in sorted(payload.items()):
        bundle.writestr(name, data)
with zipfile.ZipFile(archive) as bundle:
    if bundle.testzip() is not None or len(bundle.namelist()) != len(set(bundle.namelist())):
        raise ValueError('CRC or duplicate failure')
    if set(bundle.namelist()) != set(payload):
        raise ValueError('Member set mismatch')
    for name, data in payload.items():
        if bundle.read(name) != data:
            raise ValueError(f'Member mismatch: {name}')
result = {
    'archive': archive.relative_to(root).as_posix(),
    'members': len(payload), 'bytes': archive.stat().st_size,
    'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'crc_verified': True, 'all_member_hashes_verified': True,
}
with (results / 'seal-result.json').open('x', encoding='utf-8') as output:
    json.dump(result, output, indent=2)
print(json.dumps(result))
