"""Persistent synthetic 16-neuron artifact for CLI instrumentation, not training."""
from hashlib import sha256
from pathlib import Path
import numpy as np
from scipy import sparse
from flydrones.brain.connectome import Connectome
from flydrones.connectome_training.features import FEATURE_NAMES
from flydrones.connectome_training.parameters import build_structure_identity, initial_parameter_set, save_parameter_set

destination = Path(__file__).resolve().parent / 'tiny-artifact-v1'
destination.mkdir(exist_ok=False)
weights = np.zeros((16, 16), np.float32)
weights[0, 1], weights[1, 0] = .5, -1.
connectome = Connectome('tiny-probe-fixture', sparse.csc_matrix(weights), np.array(['A'] * 16), np.array(['L'] * 16))
source = destination / 'model.npz'
connectome.save(source)
identity = build_structure_identity(connectome, sha256(source.read_bytes()).hexdigest())
parameters = initial_parameter_set(identity, FEATURE_NAMES, ('vx', 'vy', 'vz', 'yaw_rate'), np.array([0, 1, 2, 3]))
parameters.readout[:] = np.diag([.3, -.2, .4, .1])
save_parameter_set(destination / 'parameters', parameters)
print(source)
