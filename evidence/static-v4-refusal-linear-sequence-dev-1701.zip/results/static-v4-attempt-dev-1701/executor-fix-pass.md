# Single bounded executor fixture fix pass

Original independent-sequence-review remains C0/I1/M0: product loader accepted in source, Important destructor-reachable close spy retained self and could resurrect/retain archive objects. Actual expanded software run3221225477 access violation at closing -> NpzFile.__del__ -> monkeypatch.undo is retained; six dots are not a passing session, exact native cause UNKNOWN.

Only the test close protocol changed to an explicit context manager proxy around the real archive, delegating actual __exit__ and recording a bool. No global close/__del__ monkeypatch or stored self. The reviewer accepted that bounded delta in source (status pending executor validation), without a second whole-product review. Corrected6passed0.28s, then45required core neighbors0.85s; product SHA unchangedc8a1d338.... All schemas/count/ownership/safety contracts unchanged. This is software fixture repair, not a product RED/GREEN or native target reattempt.

The later broad corpus-index neighbor attempt hit the recorder120s timeout; parent recorder exit1/TimeoutExpired, partial stdio and completion unavailable, source/start/fixtures retained. No reconstruction. New verify-v2 persists future timeout streams and12declared pins; original recorder4pins/byteSHA is preserved. Narrow valid54-job integration plus manifest-drift case is the necessary remaining test, not a repeated fullsuite/gate. No budget for native target/physics was relaxed.

Final:45core neighbors passed0.85s,2narrowed54-job corpus/index source-drift checks passed104.96s (23unselected), Ruff0/dedicateddiff0. Existing120s full-adjacent timeout and actualWindowsAV remain failed; neither is called nativeSDKfailure or erased. Original review source hashes unchanged through these final tests.
