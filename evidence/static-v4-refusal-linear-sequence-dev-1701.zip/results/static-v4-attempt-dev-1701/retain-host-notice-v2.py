from pathlib import Path
import hashlib,json,importlib.metadata
raw=Path(__file__).resolve().parent;dist=importlib.metadata.distribution('numpy')
files=[p for p in dist.files if str(p).endswith('.dist-info/LICENSE.txt')]
assert len(files)==1
source=dist.locate_file(files[0]);b=source.read_bytes()
with (raw/'host-numpy-LICENSE.txt').open('xb') as f:f.write(b)
with (raw/'host-numpy-notice.json').open('x') as f:json.dump(dict(package='numpy',version=dist.version,origin=str(source),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),scope='Full installed notice retained for Windows NpzFile source excerpt;not Linux toolchain/transitive-license certification'),f,indent=2)
print(json.dumps(dict(host_notice_retained=True,bytes=len(b))))
