from pathlib import Path
p=Path('src/flydrones/connectome_training/dataset.py');s=p.read_text();a=s.index('    with np.load(samples, allow_pickle=False) as arrays:',s.index('def load_sequence('));b=s.index('        frames = [',a)
s=s[:a]+'''    with np.load(samples, allow_pickle=False) as compressed:
        if set(compressed.files) != required:
            raise ValueError("samples.npz keys do not match the student/teacher contract")
        times = compressed["sim_ns"]
        sample_count = int(times.shape[0])
        if manifest["samples"] != sample_count:
            raise ValueError("sequence sample count mismatch")
        # NpzFile does not cache decoded members: per-frame indexing would
        # decompress a complete image stack once for every frame. Decode each
        # member once, retain owned rows, then release its full stack before
        # decoding the next member. This still materializes the whole sequence.
        arrays = {"sim_ns": times}
        for name in sorted(required - {"sim_ns"}):
            values = compressed[name]
            arrays[name] = [row.copy() for row in values]
            del values
'''+s[b:]
a=s.index('        frames = [',a);b=s.index('    sequence = TrainingSequence(',a);segment=s[a:b].replace('[i].copy()','[i]');s=s[:a]+segment+s[b:];p.write_text(s)
# Import-effects correction before canonical seal. Package __init__ eagerly imports torch.
for name in ('docs/superpowers/specs/2026-10-15-linear-sequence-decode-design.md','docs/superpowers/plans/2026-10-15-linear-sequence-decode.md'):
 p=Path(name);s=p.read_text(encoding='utf-8-sig').replace('no torch/optimizer/full model','no neural model/optimizer/full-model execution').replace('no torch/neural network/optimizer/full model','no neural-model/optimizer/full-model execution');s+='\nImport boundary: existing connectome_training.__init__ eagerly imports NumPy/SciPy/PyTorch and other host modules during the ordinary Windows test import. No no-Torch-import or no-native-host-library claim is made. No model is instantiated or executed; no optimizer/training/full MaleCNS/target SDK/Linux metadata was run by these tests.\n';p.write_text(s,encoding='utf8',newline='\n')
