# Independent linear sequence source review

Original review: **C0 / I1 / M0**. No actionable production-loader defect was found. I1 is preserved below; the one bounded executor fix addresses it in source, pending executor runtime verification. This is one source review plus one fix-delta check, not a second whole-code review.

Baseline context: `a8c717bd9f31846b35a77b69a35bb4d982a4c62f`; comparison used the retained pre-change dataset snapshot `results/static-v4-attempt-dev-1701/source-before/src/flydrones/connectome_training/dataset.py`. Source preceding `load_sequence` is identical after CRLF normalization.

## Original important finding I1

`tests/connectome_training/test_sequence_decode_once.py:151–156` (original SHA-256 `c6a704e2f09659c23ed348344ca9687b2c56a7c359520faea09cea92f37bfab6`): the globally patched `NpzFile.close` callback appended strong archive-instance references to `closed`, coupling cleanup observation to retention and destructor/monkeypatch teardown. The executor reported actual host exit `3221225477` after six dots, with stack entries through the spy, NumPy `NpzFile.__del__`, and `monkeypatch.undo`. The exact native cause is unknown. Correct this fixture and verify the focused checks before delivery; preserve the original failure and source. This is a host fixture failure, separate from production decode-count RED results and any target-native consumer failure.

**Bounded resolution:** corrected lines 143–165 wrap actual `np.load` in `FailureContext`, delegate actual archive `__exit__`, and record only a Boolean closed state. They do not replace `NpzFile.close` or `__del__`; the observer list no longer retains archive instances. The test prefix before the corrected function is unchanged after newline normalization. Corrected test SHA-256: `419c7aa5ee7c12e3966e863607866017893d63f4ed6dfa7f3fe91fc675760681`. Source resolution accepted; runtime validation belongs to the executor and was not run by this reviewer. Original severity counts stay C0/I1/M0.

## Production and compatibility assessment

- `dataset.py:220–245`: schema, exact member allowlist, hash-before-load, and sample-count refusal before non-time members are preserved.
- `dataset.py:242–254`: `sim_ns` is read once. Every remaining required member is read once, copied into owned rows, and its full decoded reference is deleted before the next decode. The time array is intentionally retained. The comprehension iteration state does not escape.
- `dataset.py:255–288`: field mappings, scalar conversions, masks and padded horizons, v1 all-valid horizon synthesis, provenance, eager return structure and final validation are preserved. Array fields reuse the owned rows.
- `test_sequence_decode_once.py:78–135`: actual tiny compressed fixtures check all three schema decode counts, representative roundtrip/NaN/mask behavior, row isolation, count refusal before images, and release of the previous decoded member via weak reference.
- `curriculum_session.py:231` calls the changed loader for production curriculum sequence selection. This improves actual learning-input materialization cost.

## Boundaries

This review used file/source bytes only: no tests, project imports, shell/native commands, network, resource observations, SDK, Linux or physical study. No latency, peak-memory, full-model, optimizer, training eligibility or target-native qualification is asserted. Eager whole-sequence storage remains. Ordinary package imports may eagerly load host NumPy/SciPy/Torch.

The prior actual v4 decision remains REFUSED_UNCONSUMED; the older 382-source release is stale after dataset evolution. No private identity inspection, resource polling, competitor action, native observer/SDK study or v4 rerun was performed.

## Byte pins

| Input | Bytes | SHA-256 |
| --- | ---: | --- |
| `docs/superpowers/specs/2026-10-15-linear-sequence-decode-design.md` | 3063 | `7d3647a5383593058045079869849dfbbfb4c3d1affd1bd2c5051f59ddf8e511` |
| `docs/superpowers/plans/2026-10-15-linear-sequence-decode.md` | 1733 | `747f1c9023d94b3fc6e9f90ab2e5fb56598e6556ca5bc94306ca41d59e6de2e4` |
| `src/flydrones/connectome_training/dataset.py` | 11618 | `c8a1d338d31fa2690d710b724e5a7f5ece6bd08861032b8218fbbe0174d53021` |
| `tests/connectome_training/test_sequence_decode_once.py` | 5437 | `c6a704e2f09659c23ed348344ca9687b2c56a7c359520faea09cea92f37bfab6` |
| `results/static-v4-attempt-dev-1701/source-before/src/flydrones/connectome_training/dataset.py` | 10844 | `efd5f5fc36a07a99d793d1f53f75764d42d996cf78a2578e43514f7bd2c11bb8` |
| `tests/connectome_training/test_dataset.py` | 3396 | `7240da8a4717a2989410362533adee16c9f2ab1d16ecd884ad4284561c8e35ca` |
| `tests/connectome_training/test_depth_validity.py` | 8280 | `6797718c972c81d3ea5282597efc62216ae412eb235dd62b0ecc24ef4c71bcd5` |
| `tests/connectome_training/test_corpus_horizon.py` | 4129 | `8f01871b84269e6855a0b74394024137e951a101bb766c66851aa53956f2e7fa` |
| `src/flydrones/connectome_training/features.py` | 5625 | `6c1881e9ff5a060d9af842f7c60601b62e22576ca16c61baf0545cd9ff6dd6f1` |
| `src/flydrones/connectome_training/curriculum_session.py` | 16234 | `493816d42d6e74ed90d9e2da7aa618a806e7717203d4cb152592043370cc3cdf` |
| `tools/benchmark/software_process_boundary.py` | 1737 | `1aced69a1cd810728c0bf557cc272a5bd43a94ababc31bb6ba33de791fd139a1` |
| Corrected `tests/connectome_training/test_sequence_decode_once.py` | 5761 | `419c7aa5ee7c12e3966e863607866017893d63f4ed6dfa7f3fe91fc675760681` |
