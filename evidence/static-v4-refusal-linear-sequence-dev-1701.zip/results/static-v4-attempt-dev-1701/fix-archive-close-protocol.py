from pathlib import Path
p=Path('tests/connectome_training/test_sequence_decode_once.py');s=p.read_text();a=s.index('def test_member_decode_error_closes_actual_archive(');s=s[:a]+'''def test_member_decode_error_closes_actual_archive(tmp_path, monkeypatch):
    path = write_sequence(tmp_path / "sequence", sequence(3))
    original = np.load
    closed = []

    class FailureContext:
        def __init__(self, archive):
            self.archive = archive
            self.files = archive.files

        def __enter__(self):
            self.archive.__enter__()
            return self

        def __exit__(self, *error):
            result = self.archive.__exit__(*error)
            closed.append(self.archive.zip is None)
            return result

        def __getitem__(self, key):
            if key == "rgb":
                raise ValueError("actual decode failure protocol")
            return self.archive[key]

    monkeypatch.setattr(np, "load", lambda *a, **k: FailureContext(original(*a, **k)))
    with pytest.raises(ValueError, match="actual decode failure protocol"):
        load_sequence(path)
    assert closed == [True]
''';p.write_text(s)
