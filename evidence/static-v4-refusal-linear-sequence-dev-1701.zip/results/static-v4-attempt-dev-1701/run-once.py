import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent;literal=root/'results/target-bearing-runtime-freeze-v4-dev-1701/run-static-preparation-v4.py'
def sha(b):return hashlib.sha256(b).hexdigest()
def save(n,b):
 with (raw/n).open('xb') as f:f.write(b)
pre=json.loads((raw/'preflight.json').read_bytes());assert all(sha((root/r['path']).read_bytes())==r['sha256'] for r in pre['sources'])
assert sorted(p.name for p in literal.parent.iterdir())==[literal.name]
assert 'PYTEST_CURRENT_TEST' not in os.environ and 'pytest' not in sys.modules
argv=[sys.executable,str(literal),'--execute-once'];record=dict(argv=argv,cwd=str(root),recorder_sha256=sha(Path(__file__).read_bytes()),source_count=len(pre['sources']),literal_sha256=sha(literal.read_bytes()),environment_subset={k:os.environ.get(k) for k in ('PATH','PYTHONPATH','VIRTUAL_ENV','PYTHONHOME')},started_utc=datetime.datetime.now(datetime.UTC).isoformat(),started_monotonic_ns=time.monotonic_ns(),scope='Actual standalone Windows coordinator;its first resource refusal is not a native attempt')
save('cli-start.json',json.dumps(record,indent=2).encode())
with (raw/'cli.stdout').open('xb') as out,(raw/'cli.stderr').open('xb') as err:
 p=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err)
 save('cli-owned-popen.json',json.dumps(dict(pid=p.pid,argv=argv,cwd=str(root),clock_host='Windows',utc=datetime.datetime.now(datetime.UTC).isoformat()),indent=2).encode())
 code=p.wait()
record.update(exit=code,waited=True,ended_utc=datetime.datetime.now(datetime.UTC).isoformat(),ended_monotonic_ns=time.monotonic_ns(),source_after=[dict(path=r['path'],bytes=len(b:=(root/r['path']).read_bytes()),sha256=sha(b)) for r in pre['sources']])
save('cli-completion.json',json.dumps(record,indent=2).encode())
print(json.dumps(dict(exit=code,waited=True,local_elapsed_ns=record['ended_monotonic_ns']-record['started_monotonic_ns'],source_stable=all(r['sha256']==pre['sources'][i]['sha256'] for i,r in enumerate(record['source_after'])),stdout_bytes=(raw/'cli.stdout').stat().st_size,stderr_bytes=(raw/'cli.stderr').stat().st_size)))
