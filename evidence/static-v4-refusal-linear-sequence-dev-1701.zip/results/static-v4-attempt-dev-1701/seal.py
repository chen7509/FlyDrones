import hashlib,json,zipfile
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent;parent=root/'results/target-bearing-runtime-freeze-v4-dev-1701'
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,v):
 with p.open('xb') as f:f.write(json.dumps(v,ensure_ascii=False,indent=2).encode())
audit=json.loads((raw/'admission-refusal-audit.json').read_bytes());privacy=audit['private_excluded'];excluded={root/r['path'] for r in privacy};inv=json.loads((parent/'LOCAL_UNPUBLISHED-admission-1.json').read_bytes());rows=inv['windows']+inv['linux']['rows'];needles=set();triples=[]
for r in rows:
 cmd=r.get('cmdline');command=cmd if isinstance(cmd,str) else ' '.join(cmd or [])
 if command:
  digest=sha(command.encode());needles.add(digest.encode());triples.append(dict(pid=r['pid'],name=r['name'],argv_sha256=digest,cmdline=cmd))
for r in privacy:
 b=(root/r['path']).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256']
explicit=['src/flydrones/connectome_training/dataset.py','tests/connectome_training/test_sequence_decode_once.py','tests/connectome_training/test_dataset.py','tests/connectome_training/test_depth_validity.py','tests/connectome_training/test_corpus_horizon.py','tests/connectome_training/test_recorder.py','tests/connectome_training/test_corpus_index.py','src/flydrones/connectome_training/curriculum_session.py','src/flydrones/connectome_training/features.py','src/flydrones/connectome_training/__init__.py','tools/benchmark/software_process_boundary.py','tools/benchmark/run_openvins_dataset_consumer.py','docs/STATIC_V4_ADMISSION_AND_SEQUENCE_DECODE_REPORT.md','docs/superpowers/specs/2026-10-15-linear-sequence-decode-design.md','docs/superpowers/plans/2026-10-15-linear-sequence-decode.md','docs/superpowers/plans/2026-10-15-loader-selected-path-production.md','evidence/flydrones-history-through-admitted-executor-dev-1701.json','evidence/flydrones-history-through-loader-path-research-dev-1701.json','evidence/static-v4-executor-completion-publication.json','evidence/static-v4-executor-completion-release.frame','results/static-v4-preflight-once-helper.py']
files={root/p for p in explicit}|{p for p in raw.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo')}|{p for p in parent.iterdir() if p.is_file() and p not in excluded}
assert not files&excluded
members=[];scanned=0
for p in sorted(files):
 b=p.read_bytes();path=p.relative_to(root).as_posix();assert not any(n in b for n in needles),path
 if p.suffix=='.json':
  try:stack=[json.loads(b.decode('utf-8-sig'))];scanned+=1
  except (ValueError,UnicodeError):stack=[]
  while stack:
   v=stack.pop()
   if isinstance(v,dict):
    for keys in (('pid','name','argv_sha256'),('pid','name','cmdline')):
     if set(keys)<=v.keys():assert not any(all(v.get(k)==r.get(k) for k in keys) for r in triples),path
    stack.extend(v.values())
   elif isinstance(v,list):stack.extend(v)
 members.append(dict(path=path,bytes=len(b),sha256=sha(b)))
archive=root/'evidence/static-v4-refusal-linear-sequence-dev-1701.zip';mapping=archive.with_suffix('.sha256.json')
save(mapping,dict(schema='static-v4-refusal-linear-sequence-exact-map-v1',members=members,private_excluded=privacy,nonempty_private_argv_hashes=len(needles),private_triples=len(triples),json_scanned=scanned,scope='Actual first resource REFUSED_UNCONSUMED/no targetmetadataSDK;independent production linear decode/software failures retained;publicationpending'))
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for row in members:z.write(root/row['path'],row['path'])
 z.write(mapping,mapping.relative_to(root).as_posix())
receipt=dict(archive=archive.relative_to(root).as_posix(),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),members=len(members)+1,mapped_members=len(members),uncompressed_bytes=sum(r['bytes'] for r in members),manifest_sha256=sha(mapping.read_bytes()),preseal_exact_set=[r['path'] for r in members],scope='Linear production plan first2done/publicationpending;staticTask5allpending;rawWindowsAV+softwaretimeoutgap retained;postsealreceipt/delivery/stage/publication/PR/automation outside')
save(raw/'seal-receipt.json',receipt)
print(json.dumps({k:v for k,v in receipt.items() if k!='preseal_exact_set'}))
