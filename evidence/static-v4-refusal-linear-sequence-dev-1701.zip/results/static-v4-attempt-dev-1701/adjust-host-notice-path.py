from pathlib import Path
raw=Path(__file__).resolve().parent
s=(raw/'retain-host-notice.py').read_text(encoding='utf-8-sig').replace("'.dist-info/licenses/LICENSE.txt'","'.dist-info/LICENSE.txt'")
with (raw/'retain-host-notice-v2.py').open('x',encoding='utf8') as f:f.write(s)
