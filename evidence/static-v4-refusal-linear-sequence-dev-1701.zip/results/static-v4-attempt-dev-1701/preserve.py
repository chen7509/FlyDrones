import ast,hashlib,json
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent;parent=root/'results/target-bearing-runtime-freeze-v4-dev-1701'
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes().decode('utf-8-sig'))
def save(n,v):
 with (raw/n).open('x',encoding='utf8') as f:json.dump(v,f,indent=2)
private=[]
for p in sorted(parent.glob('LOCAL_UNPUBLISHED-*')):
 b=p.read_bytes();private.append(dict(path=p.relative_to(root).as_posix(),bytes=len(b),sha256=sha(b)))
assert len(private)==3
facts=load(parent/'firstfacts.json');completion=load(parent/'completion.json');inventory=load(parent/'LOCAL_UNPUBLISHED-admission-1.json');meta=load(parent/'LOCAL_UNPUBLISHED-metadata-001.json');observed=ast.literal_eval(bytes.fromhex(meta['stdout_hex']).decode())
assert observed==inventory['linux'] and meta['exit']==0 and meta['error'] is None and meta['cleanup']['waited'] and meta['reader_complete']
assert facts['private_bytes']==private[[r['path'].endswith('admission-1.json') for r in private].index(True)]['bytes'] and facts['private_sha256']==sha((parent/'LOCAL_UNPUBLISHED-admission-1.json').read_bytes())
source=root/'tools/benchmark/run_openvins_dataset_consumer.py';tree=ast.parse(source.read_bytes());node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='heavy_process');namespace={};exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),namespace)
rows=inventory['windows']+inventory['linux']['rows'];count=sum(bool(namespace['heavy_process'](r)) for r in rows);assert count==facts['competitor_count']==1
assert facts['windows_available']==inventory['windows_memory']['available']==1620271104 and facts['wsl_available']==observed['available']==6851129344
assert completion==dict(state='REFUSED_UNCONSUMED',consumed=False,child_exit=None,escaped_closure='UNKNOWN')
assert set(p.name for p in parent.iterdir())=={'run-static-preparation-v4.py','firstfacts.json','completion.json',*[Path(r['path']).name for r in private]}
save('admission-refusal-audit.json',dict(state='REFUSED_UNCONSUMED',windows_available=facts['windows_available'],wsl_available=facts['wsl_available'],dual1GiB_memory_pass=True,classified_competitor_count=count,docker_exit=facts['docker_exit'],docker_empty=facts['docker_empty'],private_excluded=private,private_total_rows=len(rows),windows_clock=facts['windows_clock'],linux_clock=facts['linux_clock'],own_CLI_waited=load(raw/'cli-completion.json')['waited'],metadata_or_SDK_attempt=False,physical_attempt=False,native_runtime_graph_frozen=False,resource_snapshot_count=1,gate_rerun=False,scope='actual first coordinator resource refusal;only own resource/Docker host queries;no selected target metadata,source,clock or calibration qualification;clocks separate'))
old=load(root/'results/static-v4-executor-completion-dev-1701/historical-archives-postsoftware.json')['members'];old.append(dict(path='evidence/static-v4-executor-completion-dev-1701.zip',bytes=4923342,sha256='0b537fde25153f704efb39a7283a4836b8e699c493009ccfe14255156cbf28de'))
assert len(old)==294 and {r['path'] for r in old}=={p.relative_to(root).as_posix() for p in (root/'evidence').glob('*.zip')}
for row in old:
 h=hashlib.sha256();n=0
 with (root/row['path']).open('rb') as f:
  while block:=f.read(1048576):h.update(block);n+=len(block)
 assert h.hexdigest()==row['sha256'] and n==row['bytes'],row['path']
save('historical-archives-postsoftware.json',dict(members=old,count=len(old),bytes=sum(r['bytes'] for r in old),scope='POSTrefusal/software preservation only'))
expected={r['path']:r for r in load(root/'results/static-v4-executor-completion-dev-1701/product-before.json')};mapping={r['path']:r for r in load(root/'evidence/static-v4-executor-completion-dev-1701.sha256.json')['members']}
for name in ('tools/benchmark/static_v4_identity.py','tools/benchmark/static_v4_bootstrap.py','tools/benchmark/static_v4_executor.py','tests/benchmark/test_calibration_static_v4_executor.py','tools/benchmark/static_v4_recipe.py'):expected[name]=mapping[name]
changed=[name for name,row in expected.items() if sha((root/name).read_bytes())!=row['sha256']];assert changed==['src/flydrones/connectome_training/dataset.py']
save('product-preservation-postsoftware.json',dict(count=len(expected),changed=changed,new_product=['tests/connectome_training/test_sequence_decode_once.py'],all_other_old_product_byte_same=True,all_consumed_version_sources_byte_same=True))
save('source-evolution-after-refusal.json',dict(original382_dispatch_snapshot_unchanged=True,current_changed_source=[dict(path=name,dispatch_sha256=next(r['sha256'] for r in load(raw/'preflight.json')['sources'] if r['path']==name),current_sha256=sha((root/name).read_bytes())) for name in changed],old_release_preserved_sha256=sha((root/'evidence/static-v4-executor-completion-release.frame').read_bytes()),old_release_current_source_compatible=False,v4_decision='REFUSED_UNCONSUMED;no rerun/poll/delete/rename;future routing needs independent source/receipt design'))
print(json.dumps(dict(first_refused_unconsumed=True,competing_count=count,private_files=len(private),old_zip_count=len(old),old_zip_bytes=sum(r['bytes'] for r in old),old_product_count=len(expected),only_dataset_changed=True)))
