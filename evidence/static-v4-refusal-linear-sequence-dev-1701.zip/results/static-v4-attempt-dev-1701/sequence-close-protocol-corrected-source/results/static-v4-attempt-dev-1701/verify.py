import hashlib,json,os,subprocess,sys,time,datetime
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent;label=sys.argv[1];argv=sys.argv[2:]
paths=['src/flydrones/connectome_training/dataset.py','tests/connectome_training/test_sequence_decode_once.py','tests/connectome_training/test_dataset.py','results/static-v4-attempt-dev-1701/verify.py']
sha=lambda b:hashlib.sha256(b).hexdigest()
def pins():return [dict(path=p,bytes=len(b:=(root/p).read_bytes()),sha256=sha(b)) for p in paths if (root/p).exists()]
def save(n,b):
 with (raw/n).open('xb') as f:f.write(b)
before=pins();snap=raw/(label+'-source');snap.mkdir()
for r in before:
 p=snap/r['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/r['path']).read_bytes())
env=os.environ.copy();env['PYTHONPATH']=str(root)+os.pathsep+str(root/'src')
if argv[1:3]==['-m','pytest']:argv+=['--basetemp',str(raw/(label+'-fixtures'))]
r=dict(argv=argv,cwd=str(root),environment_subset={k:env.get(k) for k in ('PYTHONPATH','PATH','VIRTUAL_ENV','PYTHONHOME')},before=before,started_utc=datetime.datetime.now(datetime.UTC).isoformat(),started_monotonic_ns=time.monotonic_ns())
save(label+'-start.json',json.dumps(r,indent=2).encode());p=subprocess.run(argv,cwd=root,env=env,capture_output=True,timeout=120);r.update(exit=p.returncode,after=pins(),ended_utc=datetime.datetime.now(datetime.UTC).isoformat(),ended_monotonic_ns=time.monotonic_ns());save(label+'.stdout',p.stdout);save(label+'.stderr',p.stderr);save(label+'.json',json.dumps(r,indent=2).encode());print(json.dumps(dict(label=label,exit=p.returncode,stdout=p.stdout.decode(errors='replace')[-5000:],stderr=p.stderr.decode(errors='replace')[-1000:])))
