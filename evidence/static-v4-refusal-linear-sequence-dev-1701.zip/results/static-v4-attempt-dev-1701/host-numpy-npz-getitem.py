    def __getitem__(self, key):
        try:
            key = self._files[key]
        except KeyError:
            raise KeyError(f"{key} is not a file in the archive") from None
        else:
            with self.zip.open(key) as bytes:
                magic = bytes.read(len(format.MAGIC_PREFIX))
                bytes.seek(0)
                if magic == format.MAGIC_PREFIX:
                    # FIXME: This seems like it will copy strings around
                    #   more than is strictly necessary.  The zipfile
                    #   will read the string and then
                    #   the format.read_array will copy the string
                    #   to another place in memory.
                    #   It would be better if the zipfile could read
                    #   (or at least uncompress) the data
                    #   directly into the array memory.
                    return format.read_array(
                        bytes,
                        allow_pickle=self.allow_pickle,
                        pickle_kwargs=self.pickle_kwargs,
                        max_header_size=self.max_header_size
                    )
                else:
                    return bytes.read()
