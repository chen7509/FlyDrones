from pathlib import Path
import json
raw=Path(__file__).resolve().parent
v=dict(schema='software-recorder-timeout-retention-gap-v1',label='sequence-neighbors-corrected',retained_start='sequence-neighbors-corrected-start.json',retained_source='sequence-neighbors-corrected-source',observed_parent_exit=1,observed_exception='subprocess.TimeoutExpired after120s',child_exit=None,completion_record_exists=False,partial_stdout_retained=False,partial_stderr_retained=False,scope='Original subprocess.run timeout escaped recorder;tool traceback retained in conversation only. No lost stdout/stderr reconstructed. Exclusive partial fixtures/source/argv/env/start retained. Not GREEN or target-native failure. New recorder will persist future timeout exception streams.',native_SDK_or_scope=False)
with (raw/'software-timeout-retention-gap.json').open('x') as f:json.dump(v,f,indent=2)
s=(raw/'verify.py').read_text(encoding='utf-8-sig');a=s.index('paths=');b=s.index('\nsha=',a)
paths=['src/flydrones/connectome_training/dataset.py','tests/connectome_training/test_sequence_decode_once.py','tests/connectome_training/test_dataset.py','tests/connectome_training/test_depth_validity.py','tests/connectome_training/test_recorder.py','tests/connectome_training/test_corpus_index.py','tests/connectome_training/test_corpus_horizon.py','src/flydrones/connectome_training/features.py','src/flydrones/connectome_training/curriculum_session.py','src/flydrones/connectome_training/__init__.py','results/static-v4-attempt-dev-1701/verify.py','results/static-v4-attempt-dev-1701/verify-v2.py']
s=s[:a]+'paths='+repr(paths)+s[b:];a=s.index("save(label+'-start.json'")
s=s[:a]+'''save(label+'-start.json',json.dumps(r,indent=2).encode())
try:
    p=subprocess.run(argv,cwd=root,env=env,capture_output=True,timeout=120)
    r.update(exit=p.returncode,timed_out=False);out,err=p.stdout,p.stderr
except subprocess.TimeoutExpired as exc:
    r.update(exit=None,timed_out=True,error=repr(exc),scope='Own software subprocess.run timeout;its automatic kill/wait is not separate recorded Popen ownership proof')
    out,err=exc.stdout or b'',exc.stderr or b''
r.update(after=pins(),ended_utc=datetime.datetime.now(datetime.UTC).isoformat(),ended_monotonic_ns=time.monotonic_ns())
save(label+'.stdout',out);save(label+'.stderr',err);save(label+'.json',json.dumps(r,indent=2).encode())
print(json.dumps(dict(label=label,exit=r['exit'],timed_out=r['timed_out'],stdout=out.decode(errors='replace')[-5000:],stderr=err.decode(errors='replace')[-1000:])))
'''
with (raw/'verify-v2.py').open('x',encoding='utf8') as f:f.write(s)
