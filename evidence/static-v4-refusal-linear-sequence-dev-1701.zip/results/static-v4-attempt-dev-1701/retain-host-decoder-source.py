import ast,hashlib,json,sys,inspect
from pathlib import Path
import numpy as np
from numpy.lib._npyio_impl import NpzFile
root=Path.cwd();raw=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
code=inspect.getsource(NpzFile.__getitem__).encode();path=Path(inspect.getsourcefile(NpzFile));whole=path.read_bytes()
for n,b in [('host-numpy-npz-getitem.py',code),('host-numpy-npz-source.json',json.dumps(dict(numpy_version=np.__version__,interpreter=sys.executable,origin=str(path),source_file_bytes=len(whole),source_file_sha256=sha(whole),selected_getitem_bytes=len(code),selected_getitem_sha256=sha(code),scope='Windows installed software implementation only;not Linux target import or source/build authentication'),indent=2).encode())]:
 with (raw/n).open('xb') as f:f.write(b)
print(json.dumps(dict(host_numpy=np.__version__,method_source_saved=True,Linux_target_import=False)))
