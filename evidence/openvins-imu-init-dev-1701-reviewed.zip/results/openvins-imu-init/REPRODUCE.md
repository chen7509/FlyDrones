# Reproduce the frozen IMU and initialization audit

Verify the adjacent archive index and each ZIP member hash first. The original
PX4 ULog is in `evidence/openvins-texture-dev-1701.zip` and has SHA-256
`5f7cbc3c11ca53e92a64a6d58aed957f6ecf3034618756bc95f0912fac125e55`.
The clone replay is indexed by `evidence/openvins-clone-motion-dev-1701-reviewed.zip`.
The local paths and expected file digests are fixed in the audit module.

From the repository root on a Python installation with NumPy and pyulog 1.2.4:

```sh
python3 -m tools.benchmark.audit_openvins_imu_init \
  --output-dir results/openvins-imu-init/audit-reproduction
```

The output directory must not already exist. The audit refuses changed inputs,
compares all 15,107 ULog/CSV IMU rows, and rejects missing/invalid/reset or
more than 20 ms gaps in PX4 EKF2 velocity in the 2-second pre-initialization
window, including samples bracketing both endpoints. Velocity at an unsampled
initialization time is interpolated component-wise before taking its norm.
EKF2 is an offline reference, not true motion or a VIO input. No
simulation, estimator replay, learning, or safety controller is run.
