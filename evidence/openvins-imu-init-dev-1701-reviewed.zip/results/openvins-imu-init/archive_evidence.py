"""Build a non-overwriting indexed archive of the frozen IMU audit."""

from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "evidence/openvins-imu-init-dev-1701-reviewed.zip"
INDEX = OUT.with_suffix(".sha256.json")
BASE = ROOT / "results/openvins-imu-init"

FILES = [
    "results/openvins-imu-init/archive_evidence.py",
    "results/openvins-imu-init/REPRODUCE.md",
    "results/openvins-imu-init/audit-v3/summary.json",
    "results/openvins-imu-init/audit-v3/velocity_window.csv",
    "results/openvins-imu-init/metadata.json",
    "results/openvins-texture-dev/input-v1/imu.csv",
    "results/openvins-offline-1701/runner-v3/offline_probe.cpp",
    "results/openvins-texture-dev/config-v2/kalibr_imu_chain.yaml",
    "results/openvins-texture-dev/config-v2/estimator_config.yaml",
    "results/openvins-clone-motion/replay-v1/stdout.txt",
    "results/openvins-clone-motion/replay-v1/states.csv",
    "tools/benchmark/audit_openvins_imu_init.py",
    "tests/benchmark/test_openvins_imu_init.py",
    "docs/OPENVINS_IMU_INIT_REPORT.md",
    "docs/superpowers/specs/2026-10-03-openvins-imu-init-audit.md",
    "docs/superpowers/plans/2026-10-03-openvins-imu-init-audit.md",
]


def digest(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main() -> None:
    if OUT.exists() or INDEX.exists():
        raise SystemExit("evidence output already exists; preserve prior evidence")
    metadata = {
        "schema": "flydrones-openvins-imu-init-evidence-v1",
        "scope": "frozen development IMU/export/static-init diagnosis, EKF2 offline reference",
        "openvins_upstream_commit": "69488123ed9362dd44b6f28e7f4680abbff1442b",
        "openvins_license": "GPL-3.0",
        "pyulog_version": "1.2.4",
        "original_ulog_sha256": "5f7cbc3c11ca53e92a64a6d58aed957f6ecf3034618756bc95f0912fac125e55",
        "original_ulog_in_archive": False,
        "prior_texture_archive_sha256": digest(ROOT / "evidence/openvins-texture-dev-1701.zip"),
        "prior_clone_archive_sha256": digest(ROOT / "evidence/openvins-clone-motion-dev-1701-reviewed.zip"),
        "new_px4_or_vio_replay": False,
    }
    (BASE / "metadata.json").write_text(
        json.dumps(metadata, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    entries = {}
    with zipfile.ZipFile(OUT, "x", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for name in FILES:
            data = (ROOT / name).read_bytes()
            archive.writestr(name, data)
            entries[name] = {"sha256": hashlib.sha256(data).hexdigest(),
                             "bytes": len(data)}
    with zipfile.ZipFile(OUT) as archive:
        if set(archive.namelist()) != set(FILES):
            raise RuntimeError("ZIP member list differs")
        for name in FILES:
            data = archive.read(name)
            if hashlib.sha256(data).hexdigest() != entries[name]["sha256"]:
                raise RuntimeError(f"ZIP digest mismatch: {name}")
            if len(data) != entries[name]["bytes"]:
                raise RuntimeError(f"ZIP byte count mismatch: {name}")
    index = {"schema": "flydrones-archive-index-v1",
             "archive_sha256": digest(OUT), "archive_bytes": OUT.stat().st_size,
             "files": entries}
    INDEX.write_text(json.dumps(index, indent=2, sort_keys=True) + "\n",
                     encoding="utf-8")
    print(json.dumps({"archive": str(OUT), "sha256": digest(OUT),
                      "file_count": len(entries), "bytes": OUT.stat().st_size}, indent=2))


if __name__ == "__main__":
    main()
