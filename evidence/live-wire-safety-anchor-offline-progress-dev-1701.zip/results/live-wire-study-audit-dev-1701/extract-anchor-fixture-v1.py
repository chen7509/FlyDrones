"""Extract a named small, original-record fixture; not a full capture."""
import hashlib
import json
from pathlib import Path

base = Path('results/openvins-health-physical-dev-1701-v2/development-seed-27201/capture-v1')
names = ['readiness-anchor.json', 'events.jsonl', 'source-fanout.jsonl',
         'heartbeat-observations.jsonl', 'estimator-readiness.jsonl', 'shadow/native-acks.jsonl']
raw = {name:(base/name).read_bytes() for name in names}
rows = {name:[json.loads(line) for line in data.splitlines()] for name,data in raw.items() if name.endswith('.jsonl')}
anchor = json.loads(raw['readiness-anchor.json'])
proof = anchor['proof']
hb = next(r for r in rows['heartbeat-observations.jsonl'] if r['event']=='heartbeat_observed'
          and r['arrival_monotonic_ns']==proof['records']['heartbeat']['arrival_monotonic_ns'])
reconciled = next(r for r in rows['heartbeat-observations.jsonl'] if r['event']=='heartbeat_reconciled'
                  and r['observation_sequence']==hb['observation_sequence'])
ids = {proof['records'][kind]['source_sequence'] for kind in ('imu','info','rgb')}
ids.add(proof['estimator_internal']['source_sequence'])
ids.add(reconciled['source_sequence'])
data = dict(anchor=anchor,
    sources=[r for r in rows['events.jsonl'] if r['source_sequence'] in ids],
    fanout=[r for r in rows['source-fanout.jsonl'] if r['source_sequence'] in ids],
    heartbeat_records=[hb,reconciled],
    estimator_records=[r for r in rows['estimator-readiness.jsonl']
                       if r['native_sequence']==proof['estimator_internal']['native_sequence']],
    acknowledgements=[r for r in rows['shadow/native-acks.jsonl']
                      if r['sequence']==proof['estimator_internal']['native_sequence']])
out = Path('tests/benchmark/fixtures/live_wire/retained-anchor-subset.json')
with out.open('x') as stream:
    json.dump(data, stream, indent=2)
record = dict(scope='original selected records; deliberately incomplete capture, no live qualification',
    source_root=str(base), source_sha256={name:hashlib.sha256(data).hexdigest() for name,data in raw.items()},
    fixture_sha256=hashlib.sha256(out.read_bytes()).hexdigest(), source_sequences=sorted(ids))
with Path('results/live-wire-study-audit-dev-1701/anchor-fixture-provenance-v1.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record, indent=2))
