"""Recorded safety constraints and offline scoring; no runtime authorization."""

from __future__ import annotations

import io
import json

from tools.benchmark.audit_live_wire_study import _equal, _integer, _shape
from tools.benchmark.motion_intent_gate import MotionIntentGate
from tools.benchmark.openvins_online_shadow import SourceWatchdog, project_motion_intent_ack
from tools.benchmark.readiness_anchor import AnchoredPolicy, anchored_profile
from tools.benchmark.supported_excitation import MASSES
from tools.benchmark.trajectory_gauge_contract import (
    audit_trajectory,
    trajectory_contract,
    validate_trajectory_gauge_policy,
)

END, STEP = 25_000_000_000, 1_000_000


def _presteps(trace):
    if type(trace) is not list or len(trace) != 50000:
        raise ValueError('incomplete safety callback trace')
    previous = 0
    for index in range(25000):
        ns = (index+1)*STEP
        pre, post = trace[index*2:index*2+2]
        for row, phase in ((pre, 'pre'), (post, 'post')):
            _equal(row['phase'], phase, 'safety callback phase')
            _equal(row['sim_ns'], ns, 'safety callback epoch')
            _integer(row['wall_ns'], previous, 2**63-1, 'safety callback clock')
            previous = row['wall_ns']
        yield pre, post


def audit_source_health_records(*, sources, trace, terminal, capture_start_ns, watchdog_failure):
    """Recompute arrival constraints, explicitly not a journal of check() calls.

    Per-source arrival order is known. Cross-source callbacks can contend for a
    lock, so this chronological replay is a conservative recorded-time analysis,
    not an assertion about the precise runtime lock acquisition order.
    """
    _equal(watchdog_failure, None, 'source watchdog failure')
    _shape(terminal, ('started_ns', 'ready_ns', 'last_arrivals', 'startup_timeout_ns',
                      'operational_timeout_ns'), 'source watchdog snapshot')
    _equal(terminal['startup_timeout_ns'], 10_000_000_000, 'source startup limit')
    _equal(terminal['operational_timeout_ns'], 2_000_000_000, 'source operational limit')
    _integer(capture_start_ns, 1, 2**63-1, 'capture start')
    steps = list(_presteps(trace))
    start = terminal['started_ns']
    _integer(start, capture_start_ns, steps[0][0]['wall_ns'], 'source watchdog start')
    counts, previous, events = dict(imu=0, rgb=0, info=0), {}, []
    if type(sources) is not list:
        raise ValueError('invalid source records')
    for row in sources:
        kind = row['kind']
        if kind not in counts:
            continue
        now = row['arrival_monotonic_ns']
        _integer(now, max(start, previous.get(kind, start-1)+1), 2**63-1, 'source arrival order')
        previous[kind] = now
        counts[kind] += 1
        events.append((now, 0, kind))
    _equal(counts, dict(imu=6251, rgb=251, info=251), 'source watchdog input coverage')
    events.extend((pre['wall_ns'], 1, None) for pre, _ in steps)
    events.sort()
    guard = SourceWatchdog(startup_timeout_ns=10_000_000_000)
    guard.start(start)
    try:
        for now, _, kind in events:
            # Check before an arrival can hide a preceding >2s silence. At equal
            # timestamps the arrival and pre-step do not create a positive gap.
            guard.check(now)
            if kind is not None:
                guard.observe(kind, now)
    except (TimeoutError, ValueError) as exc:
        raise ValueError('recorded source interval violates watchdog: '+str(exc)) from exc
    _equal(guard.snapshot(), terminal, 'recorded source watchdog snapshot')
    if terminal['ready_ns'] is None:
        raise ValueError('source readiness never established')
    return dict(source_counts=counts, physical_presteps_checked=len(steps),
                recorded_arrival_constraints_passed=True, ready_ns=terminal['ready_ns'],
                every_runtime_watchdog_call_observed=False, cross_source_lock_order_proven=False,
                live_qualified=False, fusion_qualified=False)


def audit_motion_records(*, anchor, profile, forces, trace, intent_records, requests,
                         acknowledgements, intent_terminal, motion_terminal, session_id):
    """Join one native intent and every recorded force to the frozen time policy.

    Full source/estimator proof attribution at anchor and subsequent readiness
    calls is a separate check. A source string is never authenticated PX4 control.
    These are external unarmed fixture forces, not a learned flight controller.
    """
    _equal(profile, anchored_profile(), 'frozen force profile')
    _shape(anchor, ('anchor_ns', 'selected_sim_ns', 'proof', 'profile', 'eligible_for_px4_fusion'), 'anchor')
    _equal(anchor['profile'], profile, 'anchor force profile')
    _equal(anchor['eligible_for_px4_fusion'], False, 'anchor fusion flag')
    selected = anchor['selected_sim_ns']
    _integer(selected, STEP, 8_000_000_000-STEP, 'readiness selection time')
    if selected % STEP:
        raise ValueError('anchor selection outside physical step')
    _equal(anchor['anchor_ns'], selected+200_000_000, 'immutable future anchor')
    if type(forces) is not list or type(intent_records) is not list or len(intent_records) != 4:
        raise ValueError('incomplete normal motion evidence')
    heartbeat = anchor['proof']['records']['heartbeat']
    _equal(heartbeat['system_id'], 9, 'anchor heartbeat identity')
    _integer(heartbeat['base_mode'], 0, 127, 'unarmed anchor heartbeat')
    steps = list(_presteps(trace))
    selection_pre, selection_post = steps[selected//STEP-1]
    _integer(anchor['proof']['checked_wall_ns'], selection_pre['wall_ns'], selection_post['wall_ns'], 'anchor proof time')
    raw_requests = [r for r in requests if r['action']['kind'] == 'motion_intent']
    raw_acks = [r for r in acknowledgements if r['kind'] == 'M']
    if len(raw_requests) != 1 or len(raw_acks) != 1:
        raise ValueError('one native motion-intent request/ack required')
    request, ack = raw_requests[0], raw_acks[0]
    _equal(request['sequence'], ack['sequence'], 'motion native request sequence')
    for row, event in zip(intent_records, ('estimator_state_observed', 'motion_intent_requested',
                                          'motion_intent_applied', 'motion_intent_finish'), strict=True):
        _equal(row['event'], event, 'motion event order')
    command = intent_records[1]['command']
    issued = command['issued_monotonic_ns']
    _integer(issued, anchor['proof']['checked_wall_ns'], selection_post['wall_ns'], 'motion issue time')
    expected_command = dict(session_id=session_id, clock_id='gazebo-sim+linux-monotonic', command_sequence=0,
                            effective_sim_ns=anchor['anchor_ns'], issued_monotonic_ns=issued,
                            unarmed=True, safety_authorized=True, velocity_setpoint_frd_m_s=[0., 0., -.2],
                            yaw_rate_setpoint_rad_s=0., source='px4-safe-setpoint-supervisor')
    _equal(command, expected_command, 'frozen fixture motion command')
    seq = intent_records[0]['native_sequence']
    cameras = [r for r in acknowledgements if r['kind'] == 'C' and r['sequence'] == seq]
    if len(cameras) != 1:
        raise ValueError('motion estimator state missing exact native camera')
    camera = cameras[0]
    estimator = dict(kind='C', native_sequence=seq, sample_ns=camera['sample_ns'],
                     acknowledged_ns=camera['acknowledged_ns'], internal_initialized=camera['internal_initialized'],
                     has_moved_since_zupt=camera['has_moved_since_zupt'], reset_counter=camera['reset_counter'])
    output, now = io.StringIO(), [issued]
    gate = MotionIntentGate(session_id=session_id, clock_id='gazebo-sim+linux-monotonic', stream=output,
                            clock=lambda: now[0], native_adapter_integrated=True)
    gate.observe_estimator(estimator)
    action = gate.request(command)
    _equal(request['action'], action, 'native motion action')
    projected = project_motion_intent_ack(ack, action)
    now[0] = projected['acknowledged_ns']
    _integer(now[0], issued, selection_post['wall_ns'], 'native motion completed in anchor selection step')
    gate.acknowledge(projected)
    _equal(gate.authorize_step(anchor['anchor_ns']), True, 'replayed motion gate')
    expected_terminal = gate.finish()
    _equal(intent_records, [json.loads(line) for line in output.getvalue().splitlines()], 'motion journal replay')
    _equal(intent_terminal, expected_terminal, 'motion gate terminal')
    current, persisted = [0], []
    policy = AnchoredPolicy(lambda: anchor['proof'] if current[0] >= selected else None, persisted.append)
    cursor = 0
    for pre, post in steps:
        ns = current[0] = pre['sim_ns']
        force = policy.step(ns, STEP, unarmed_wall_ns=pre['wall_ns'], wall_ns=pre['wall_ns'])
        if not any(force):
            continue
        if cursor >= len(forces):
            raise ValueError('missing recorded physical force')
        row = forces[cursor]
        _shape(row, ('sim_ns', 'dt_ns', 'force_world_n', 'per_link', 'call_returned', 'wall_ns'), 'force record')
        _equal(row['sim_ns'], ns, 'force epoch')
        _equal(row['dt_ns'], STEP, 'force step')
        _equal(row['force_world_n'], force, 'frozen force waveform')
        _equal(row['call_returned'], True, 'force API completion')
        _integer(row['wall_ns'], max(pre['wall_ns'], now[0]), post['wall_ns'], 'force after native authorization')
        if type(row['per_link']) is not list or len(row['per_link']) != len(MASSES):
            raise ValueError('incomplete distributed force')
        names = set()
        for link in row['per_link']:
            _shape(link, ('name', 'force_world_n', 'call_returned'), 'link force')
            name = link['name']
            if name not in MASSES or name in names:
                raise ValueError('unknown/duplicate force link')
            names.add(name)
            _equal(link['call_returned'], True, 'link force completion')
            _equal(link['force_world_n'], [v*MASSES[name]/sum(MASSES.values()) for v in force], 'link force distribution')
        cursor += 1
    _equal(cursor, len(forces), 'no extra physical force')
    _equal(persisted, [anchor], 'single immutable anchor')
    expected_motion = dict(policy.finish(), motion_intent_prepared=True, close_errors=[],
                           recorded_commands=cursor, last_attempt=forces[-1])
    for key, value in expected_motion.items():
        _equal(motion_terminal[key], value, 'motion terminal '+key)
    return dict(anchor_ns=anchor['anchor_ns'], support_steps=cursor, lateral_steps=policy.active_steps,
                motion_intent_replayed=True, all_recorded_forces_match_profile=True,
                anchor_source_attribution_qualified=False, per_step_readiness_calls_observed=False,
                flight_controller_authenticated=False, live_qualified=False, fusion_qualified=False)


def audit_gauge_records(*, states, reference, policy, anchor, motion_profile, health_terminal, result):
    """Reuse the prospective gauge without clipping startup or choosing an origin."""
    validate_trajectory_gauge_policy(policy)
    _equal(motion_profile, anchored_profile(), 'gauge motion profile')
    contract = trajectory_contract(anchor_ns=anchor['anchor_ns'],
        total_duration_ns=motion_profile['total_duration_ns'],
        lateral_start_offset_ns=motion_profile['lateral_start_after_anchor_ns'])
    truth = []
    for row in reference:
        _equal(row['truth_for_abort_audit_only'], True, 'isolated truth scope')
        truth.append(dict(row, sim_ns=row['post_ns'], truth_for_fixture_audit_only=True))
    session = dict(session_id=health_terminal['session_id'], reset_counter=health_terminal['reset_counter'],
                   reset_observed=health_terminal['reset_total'] != 0, quality=health_terminal['last_quality'],
                   covariance_calibrated=False)
    scored = audit_trajectory(states, truth, session,
        dict(status=result['status'], end_sim_ns=result['end_sim_ns']), contract)
    return dict(scored, live_qualified=False, fusion_qualified=False)
