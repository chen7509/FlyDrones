import hashlib,json,zipfile
from pathlib import Path
root=Path('results/live-wire-study-audit-dev-1701')
target=Path('evidence/live-wire-safety-anchor-offline-progress-dev-1701.zip')
paths=[Path(p) for p in ['.gitattributes','tools/benchmark/audit_live_wire_safety.py','tools/benchmark/audit_live_wire_study.py','tools/benchmark/estimator_aware_readiness.py','tools/benchmark/readiness_anchor.py','tools/benchmark/ready_shadow_fanout.py','tools/benchmark/journaled_heartbeat_lane.py','tools/benchmark/trajectory_gauge_contract.py','tools/benchmark/motion_intent_gate.py','tests/benchmark/test_live_wire_safety_audit.py','tests/benchmark/test_live_wire_anchor_audit.py','tests/benchmark/test_live_wire_study_entry.py','tests/benchmark/fixtures/live_wire/retained-anchor-subset.json','tests/benchmark/fixtures/live_wire/README.md','docs/LIVE_WIRE_RAW_EVIDENCE_MAP.md','docs/LIVE_WIRE_STUDY_PREPARATION_REPORT.md','docs/superpowers/plans/2026-10-08-live-wire-study.md','docs/superpowers/specs/2026-10-08-live-wire-study-design.md','.superpowers/sdd/2026-10-08-live-wire-study/progress.md']]
for p in root.iterdir():
    if p.is_file() and p.name.startswith(('safety-','anchor-','check-safety-','check-anchor-','extract-anchor-','seal-safety-')):
        paths.append(p)
for folder in ['safety-fixed-v1','anchor-fixed-v1']:
    paths.extend(p for p in (root/folder).rglob('*') if p.is_file())
members={str(p).replace('\\','/'):p.read_bytes() for p in paths}
assert len(members)==len(paths)
manifest=dict(producer_commit='53e64ea',core_commit='588c5fb',scope='partial offline safety and anchor; Task2/3 unfinished',live_qualified=False,fusion_qualified=False,remote_published=False,members={n:dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in members.items()})
members['manifest.json']=json.dumps(manifest,sort_keys=True,indent=2).encode()
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in members.items(): z.writestr(name,data)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and len(z.namelist())==len(members)
    for name,data in members.items(): assert z.read(name)==data
record=dict(path=str(target),members=len(members),bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),crc_and_all_members_verified=True)
with (root/'safety-anchor-seal-v1.json').open('x') as f: json.dump(record,f,indent=2)
print(json.dumps(record,indent=2))
