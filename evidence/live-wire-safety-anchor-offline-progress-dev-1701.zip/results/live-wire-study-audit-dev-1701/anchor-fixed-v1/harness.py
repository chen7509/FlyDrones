import json
from pathlib import Path
from tools.benchmark.audit_live_wire_study import StudyEvidenceReader
from tools.benchmark.audit_live_wire_safety import audit_anchor_records
out = Path('results/live-wire-study-audit-dev-1701/anchor-fixed-v1')
out.mkdir()
reader = StudyEvidenceReader()
producer = out/'producer'
producer.mkdir()
for name in ['audit_live_wire_safety.py','audit_live_wire_study.py','estimator_aware_readiness.py','readiness_anchor.py','ready_shadow_fanout.py']:
    raw = reader.raw(Path('tools/benchmark')/name)
    (producer/name).write_bytes(raw)
(out/'harness.py').write_bytes(Path(__file__).read_bytes())
root=Path('results/openvins-health-physical-dev-1701-v2/development-seed-27201/capture-v1')
failures=[]
checks={}
try:
    checks=audit_anchor_records(anchor=reader.document(root/'readiness-anchor.json'),sources=reader.lines(root/'events.jsonl'),fanout=reader.lines(root/'source-fanout.jsonl'),heartbeat_records=reader.lines(root/'heartbeat-observations.jsonl'),estimator_records=reader.lines(root/'estimator-readiness.jsonl'),acknowledgements=reader.lines(root/'shadow/native-acks.jsonl'))
except Exception as exc:
    failures.append(repr(exc))
finally:
    reader.finish()
    result=dict(checks=checks,failures=failures,consumed_files=reader.files,simulator_run=False,estimator_run=False,live_qualified=False,fusion_qualified=False)
    with (out/'audit.json').open('x') as f: json.dump(result,f,indent=2,allow_nan=False)
    print(json.dumps(dict(checks=checks,failures=failures),indent=2))
if failures: raise SystemExit(2)
