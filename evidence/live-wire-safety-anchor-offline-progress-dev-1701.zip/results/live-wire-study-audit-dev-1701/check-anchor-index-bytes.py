import hashlib, subprocess
path='tests/benchmark/fixtures/live_wire/retained-anchor-subset.json'
raw=subprocess.run(['git','show', ':'+path],check=True,capture_output=True).stdout
actual=hashlib.sha256(raw).hexdigest()
print('Git index SHA256:',actual)
assert actual=='421c15f47dc7ff9e91891369df69ccbc08a8c1f5bc25ce894899dba93e0117d5', 'Git normalization changed retained fixture bytes'
