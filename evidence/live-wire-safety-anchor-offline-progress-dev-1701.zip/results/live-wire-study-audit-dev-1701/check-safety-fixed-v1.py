"""New read-only safety joins on retained development records, never a replay."""
import hashlib
import json
from pathlib import Path

from tools.benchmark.audit_live_wire_study import (
    StudyEvidenceReader, audit_gauge_records, audit_motion_records, audit_source_health_records,
)
from tools.benchmark.trajectory_gauge_contract import trajectory_gauge_policy

root = Path('results/live-wire-study-audit-dev-1701/safety-fixed-v1')
root.mkdir()
capture = Path('results/openvins-health-physical-dev-1701-v2/development-seed-27201/capture-v1')
reader, checks, failures = StudyEvidenceReader(), {}, []
producer = root/'producer'
producer.mkdir()
for name in ['audit_live_wire_safety.py', 'audit_live_wire_study.py', 'motion_intent_gate.py',
             'openvins_online_shadow.py', 'readiness_anchor.py', 'supported_excitation.py',
             'trajectory_gauge_contract.py', 'disarmed_motion_probe.py']:
    raw = reader.raw(Path('tools/benchmark')/name)
    with (producer/name).open('xb') as stream:
        stream.write(raw)
with (root/'harness.py').open('xb') as stream:
    stream.write(Path(__file__).read_bytes())
stage = 'read'
try:
    result = reader.document(capture/'result.json')
    trace = reader.lines(capture/'physics-substeps.jsonl', maximum_rows=50000)
    stage = 'source_health'
    checks[stage] = audit_source_health_records(sources=reader.lines(capture/'events.jsonl'), trace=trace,
        terminal=result['source_health'], capture_start_ns=result['source_health']['started_ns'],
        watchdog_failure=result.get('source_watchdog_failure'))
    stage = 'motion'
    anchor = reader.document(capture/'readiness-anchor.json')
    profile = reader.document(capture/'motion-profile.json')
    session = reader.document(capture/'shadow/native-session.json')
    checks[stage] = audit_motion_records(anchor=anchor, profile=profile,
        forces=reader.lines(capture/'motion-force.jsonl'), trace=trace,
        intent_records=reader.lines(capture/'motion-intent.jsonl'),
        requests=reader.lines(capture/'shadow/native-requests.jsonl'),
        acknowledgements=reader.lines(capture/'shadow/native-acks.jsonl'),
        intent_terminal=result['motion_intent'], motion_terminal=result['motion'],
        session_id='online-native-'+str(session['pid']))
    stage = 'gauge'
    checks[stage] = audit_gauge_records(states=reader.lines(capture/'shadow/states.jsonl'),
        reference=reader.lines(capture/'native-reference.jsonl'), policy=trajectory_gauge_policy(),
        anchor=anchor, motion_profile=profile, health_terminal=reader.document(capture/'shadow/health-result.json'),
        result=result)
except Exception as exc:
    failures.append(dict(stage=stage, reason=repr(exc)))
finally:
    try:
        reader.finish()
    except Exception as exc:
        failures.append(dict(stage='input_drift', reason=repr(exc)))
    value = dict(checks=checks, failures=failures, consumed_files=reader.files,
        start_boundary_from_guard_snapshot=True, independent_start_boundary_proven=False,
        simulator_run=False, estimator_run=False, live_qualified=False, fusion_qualified=False,
        harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    with (root/'audit.json').open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
    print(json.dumps({k:v for k,v in value.items() if k != 'consumed_files'}, indent=2))
if failures:
    raise SystemExit(2)
