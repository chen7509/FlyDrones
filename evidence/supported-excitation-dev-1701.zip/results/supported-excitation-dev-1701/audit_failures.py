import hashlib
import json
from pathlib import Path
from pyulog import ULog
import numpy as np
p=Path(__file__).resolve().parent
out=[]
for name in ['capture-v1','capture-v2']:
    d=p/name;r=json.loads((d/'result.json').read_text())
    assert r['status']=='capture_failed' and not r['estimator_run'] and not r['eligible_for_px4_fusion']
    assert r['motion']['recorded_commands']==0 and r['motion']['support_steps']==0
    assert not (d/'motion-force.jsonl').read_text()
    ev=[json.loads(s) for s in (d/'events.jsonl').read_text().splitlines()]
    counts={k:sum(x['kind']==k for x in ev) for k in ['imu','rgb','info','depth','heartbeat']}
    ulogs=[]
    for meta in r['px4_ulogs']:
        path=d/meta['path'];assert hashlib.sha256(path.read_bytes()).hexdigest()==meta['sha256']
        try:
            states=ULog(str(path)).get_dataset('vehicle_status').data['arming_state']
            assert np.all(states!=2)
            ulogs.append(dict(meta,arming_records=len(states),arming_values=[int(x) for x in np.unique(states)]))
        except KeyError:
            ulogs.append(dict(meta,arming_records=0,arming_values=[],scope='no vehicle_status dataset; cannot claim arming evidence'))
    out.append(dict(capture=name,end_sim_ns=r['end_sim_ns'],errors=r['errors'],counts=counts,trace_rows=r['physics_trace']['records'],clearance_rows=r['motion']['clearance_records'],commands=0,ulogs=ulogs,eligible_for_px4_fusion=False))
with (p/'failure-audit.json').open('x') as f:json.dump(out,f,indent=2)
print(json.dumps(out,indent=2))
