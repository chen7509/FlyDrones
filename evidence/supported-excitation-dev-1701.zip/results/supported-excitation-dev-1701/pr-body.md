The previous physics trace exposed temporal undersampling during ground-level excitation. This adds a separate time-only external support fixture that distributes forces at all six link COMs while retaining the body, gravity, sensor rates, physics step, disarmed gate and independent bounds.

Both physical attempts stopped before any force: the first exposed a C++/Python binding mismatch; the corrected second had no accepted unarmed heartbeat by the scheduled2s start. All failed inputs, partial traces and the second ULog are retained. This is implementation and safety-refusal evidence only; sensor consistency, online VIO and EKF2 remain unverified. No noise/force/threshold tuning or estimator/training run occurred.

Validation:845full regression tests and129targeted tests; one independent review with oneImportant/twoMinor fixed in one pass. Checked truth writes and retained cleanup errors have synthetic regression coverage; physical captures used earlier frozen producers. Changed-file Ruff passes; whole-repository50errors in32unchanged files remain disclosed.

Stacked on#39. See docs/SUPPORTED_EXCITATION_REPORT.md and evidence/supported-excitation-dev-1701.zip. Next dependency is prospectively designed readiness-anchored scheduling; no runtime gate is relaxed. No merge or arming requested.
