from pathlib import Path
import urllib.request
import hashlib
import json
p=Path(__file__).resolve().parent
url='https://raw.githubusercontent.com/gazebosim/gz-sim/446a44335a45b704b4d36dabcc5508ee34eeb3d8/python/src/gz/sim/Link.cc'
data=urllib.request.urlopen(url).read()
(p/'sources/python-Link.cc').write_bytes(data)
(p/'sources/binding-manifest.json').write_text(json.dumps(dict(url=url,sha256=hashlib.sha256(data).hexdigest())))
s=(p/'run_capture.py').read_text()
for a,b in [('capture-v1','capture-v2'),('producer-before','producer-v2-before'),('producer-after','producer-v2-after'),('installed-packages.txt','installed-packages-v2.txt'),('prospective-profile.json','prospective-profile-v2.json'),('launch.json','launch-v2.json'),('exit.json','exit-v2.json')]:
    s=s.replace(a,b)
s=s.replace("px4 / 'build/px4_sitl_default/bin/px4'","px4 / 'build/px4_sitl_default/bin/px4', px4 / 'Tools/simulation/gz/models/x500/model.sdf'")
with (p/'run_capture_v2.py').open('x') as f:f.write(s)
