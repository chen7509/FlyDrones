from pathlib import Path
p=Path(__file__).resolve().parent
s=(p.parent/'physics-substep-trace-dev-1701/audit_trace.py').read_text().replace("p=base/'capture-v1'","p=base/'capture-v2'")
s=s.replace('[(5000000000,5100000000),(5000000000,6600000000),(8000000000,9000000000)]','[(5000000000,5100000000),(5000000000,6600000000),(8000000000,9000000000),(2000000000,4000000000)]')
s=s.replace("assert len(commands)==1601", "assert len(commands)==23001")
s=s.replace('list(range(5000000000,6601000000,1000000))','list(range(2000000000,25001000000,1000000))')
s=s.replace('assert np.sum(force)==0 and abs(np.sum(abs(force))*.001-41.6)<1e-10', "assert abs(np.sum(force[:,1]))<1e-9 and abs(np.sum(abs(force[:,1]))*.001-41.6)<1e-10\nfor c in commands:\n    assert len(c['per_link'])==6 and all(x['call_returned'] for x in c['per_link'])\n    assert np.allclose(np.sum([x['force_world_n'] for x in c['per_link']],axis=0),c['force_world_n'],rtol=0,atol=1e-12)")
s=s.replace("with (base/'audit.json').open('x')", "clearance=read('support-clearance.jsonl')\nassert len(clearance)==25000 and [r['sim_ns'] for r in clearance]==list(range(1000000,25001000000,1000000))\nmin_clearance=min(r['ground_clearance_m'] for r in clearance if r['sim_ns']>=4000000000)\nassert min_clearance>=.1\nsummary['minimum_ground_clearance_after_4s_m']=min_clearance\nsummary['new_development_consistency_pass']=windows[0]['raw_actual_phase']['trapezoid_error_norm_m_s']<=.02 and windows[1]['raw_actual_phase']['trapezoid_error_norm_m_s']<=.05\nsummary['support_steps']=len(commands)\nwith (base/'audit.json').open('x')")
with (p/'audit_supported.py').open('x') as f:f.write(s)
