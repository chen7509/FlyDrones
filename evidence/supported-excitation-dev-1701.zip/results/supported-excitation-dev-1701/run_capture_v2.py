import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(root), str(root / 'src')]
from tools.benchmark.capture_disarmed_sensors import active_resources
from tools.benchmark.supported_excitation import supported_profile as profile

out = Path(__file__).resolve().parent
assert active_resources() == []
px4 = Path('/home/yuchen7509/PX4-Autopilot')
paths = list((root / 'tools/benchmark').glob('*.py'))
paths += list((root / 'src/flydrones/benchmark').glob('*.py'))
paths += list((root / 'assets/gazebo/models').glob('*/model.sdf'))
paths += [px4 / 'Tools/simulation/gz/models/x500_base/model.sdf', px4 / 'build/px4_sitl_default/bin/px4', px4 / 'Tools/simulation/gz/models/x500/model.sdf']
for pattern in ['libgz-physics*.so*', 'libdart*.so*', 'gz-physics-7/engine-plugins/*.so*']:
    paths += list(Path('/usr/lib/x86_64-linux-gnu').glob(pattern))
paths = sorted(set(p.resolve() for p in paths if p.is_file()))
def snapshot(name):
    dest = out / name
    dest.mkdir(exist_ok=False)
    hashes = []
    for n, p in enumerate(paths):
        data = p.read_bytes()
        hashes.append(dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
        if p.suffix in ['.py', '.sdf']:
            (dest / (str(n) + '-' + p.name)).write_bytes(data)
    (dest / 'manifest.json').write_text(json.dumps(hashes, indent=2))
    return hashes
packages = subprocess.run(['dpkg-query', '-W', '-f=${Package}\t${Version}\n', '*gz-physics*', '*dart*', '*gz-sim*'], capture_output=True, text=True)
with (out / 'installed-packages-v2.txt').open('x') as f:
    f.write(packages.stdout + packages.stderr)
with (out / 'prospective-profile-v2.json').open('x') as f:
    json.dump(dict(name='substep-supported-v1', motion=profile(), estimator_run=False, performance_comparison=False, frozen_wall_ns=time.time_ns(), producer_commit=sys.argv[1]), f, indent=2)
before = snapshot('producer-v2-before')
command = [sys.executable, str(root / 'tools/benchmark/capture_disarmed_sensors.py'), '--output', str(out / 'capture-v2'), '--motion-profile', 'supported-lateral-v1', '--physics-trace-profile', 'substep-supported-v1']
with (out / 'launch-v2.json').open('x') as f:
    json.dump(dict(command=command, wall_ns=time.time_ns(), resources=active_resources()), f, indent=2)
with (out / 'capture-v2-console.txt').open('x') as log:
    done = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
after = snapshot('producer-v2-after')
result = dict(exit=done.returncode, unchanged=before == after, resources=active_resources(), wall_ns=time.time_ns())
with (out / 'exit-v2.json').open('x') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
