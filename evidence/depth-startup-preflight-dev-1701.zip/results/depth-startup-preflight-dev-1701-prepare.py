"""Prepare an exclusive startup-only probe from study-v5; launch nothing."""

import copy
import json
from pathlib import Path

from tools.benchmark.capture_contract import derive_launch_environment, validate_declaration
from tools.benchmark.capture_disarmed_sensors import active_resources, parse_capture_args
from tools.benchmark.declared_runtime_snapshot import file_record, write_manifest

root = Path(__file__).resolve().parents[1]
source = root / "results/depth-physical-development-preflight-dev-1701/study-v5"
output = root / "results/depth-startup-preflight-dev-1701/study-v5-startup-v1"
if output.exists():
    raise FileExistsError(output)
resources = active_resources()
if resources:
    raise ValueError("competing resources present")
manifest = json.loads((source / "study-manifest.json").read_text())
binding = json.loads((source / "runtime-binding-v3.json").read_text())
if manifest.get("physical_run_completed") is not False or manifest.get("fusion_eligible") is not False:
    raise ValueError("source study is not an undispatched closed-fusion declaration")
command = copy.deepcopy(manifest["command"])
if command.count("--output") != 1 or "--startup-preflight" in command:
    raise ValueError("invalid source command")
position = command.index("--output")
command[position + 1] = str((output / "capture-v1").resolve())
command.append("--startup-preflight")
args = parse_capture_args(command[2:])
contract = validate_declaration(args, derive_launch_environment(binding))
if not args.startup_preflight or not args.record_depth_payload or contract != manifest["execution_contract"]:
    raise ValueError("startup-only command differs from frozen source declaration")
output.mkdir(parents=True)
record = {
    "schema": "depth-startup-binding-probe-v1",
    "source_manifest": file_record(source / "study-manifest.json"),
    "source_runtime_binding": file_record(source / "runtime-binding-v3.json"),
    "preparer": file_record(__file__),
    "command": command,
    "destination": str((output / "capture-v1").resolve()),
    "resources_before": resources,
    "startup_preflight_only": True,
    "physical_run": False,
    "fusion_eligible": False,
    "flight_ready": False,
}
write_manifest(output / "probe-manifest.json", record)
print(json.dumps({"manifest": str(output / "probe-manifest.json"), "command": command}, indent=2))
