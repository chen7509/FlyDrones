"""Independently grade only the saved depth startup probe, never physics."""

import json
from pathlib import Path

from tools.benchmark.audit_capture_startup_preflight import FORBIDDEN
from tools.benchmark.capture_contract import _typed_equal
from tools.benchmark.declared_runtime_snapshot import file_record, write_manifest

root = Path(__file__).resolve().parents[1]
study = root / "results/depth-startup-preflight-dev-1701/study-v5-startup-v1"
source = root / "results/depth-physical-development-preflight-dev-1701/study-v5"
probe = json.loads((study / "probe-manifest.json").read_text())
dispatch = json.loads((study / "probe-dispatch.json").read_text())
completion = json.loads((study / "probe-completion.json").read_text())
destination = Path(probe["destination"])
result = json.loads((destination / "result.json").read_text())
supervisor = json.loads((destination / "supervisor.json").read_text())
cleanup = supervisor.get("cleanup", {})
binding = result.get("runtime_binding", {})
events = [json.loads(line) for line in destination.with_name(
    destination.name + ".supervisor-events.jsonl").read_text().splitlines() if line]
failures = []


def require(condition, label):
    if not condition:
        failures.append(label)


source_manifest = json.loads((source / "study-manifest.json").read_text())
expected_command = list(source_manifest["command"])
expected_command[expected_command.index("--output") + 1] = probe["destination"]
expected_command.append("--startup-preflight")
require(probe.get("schema") == "depth-startup-binding-probe-v1", "probe schema")
require(probe.get("source_manifest") == file_record(source / "study-manifest.json"), "source identity")
require(probe.get("source_runtime_binding") == file_record(source / "runtime-binding-v3.json"), "binding identity")
require(probe.get("command") == expected_command, "exact startup command")
require(probe.get("startup_preflight_only") is True and probe.get("physical_run") is False, "probe scope")
require(dispatch.get("schema") == "depth-startup-probe-dispatch-v1", "dispatch schema")
require(dispatch.get("probe_manifest") == file_record(study / "probe-manifest.json"), "dispatch identity")
require(dispatch.get("resources_before") == [] and dispatch.get("physical_run") is False, "dispatch resources/scope")
require(completion.get("schema") == "depth-startup-probe-completion-v1", "completion schema")
require(completion.get("returncode") == 0 and completion.get("launcher_error") is None, "completion return")
require(completion.get("resources_after") == [] and completion.get("physical_run") is False, "completion resources/scope")
require(result.get("status") == "capture_completed" and result.get("errors") == [], "capture result")
require(result.get("startup_preflight_only") is True and result.get("startup_preflight_completed") is True, "startup flags")
require(binding.get("pre_recorded") is True and binding.get("declared_files_stable") is True, "binding baseline")
require(binding.get("local_file_graph_verified") is True and binding.get("errors") == [], "resource graph")
require(binding.get("phases") == ["postgraph", "bootstrap"], "startup phases")
require(binding.get("owned_phases") == {"px4": [], "openvins": []}, "owned phases")
require(binding.get("runtime_mapping_coverage_verified") is False and binding.get("runtime_closure_qualified") is False, "runtime scope")
require(supervisor.get("worker_exit") == 0 and supervisor.get("errors") == [], "supervisor result")
require(_typed_equal(events, cleanup.get("events")), "supervisor event journal")
require(cleanup.get("group_absent") is True and cleanup.get("no_executing_members") is True, "owned cleanup")
require(cleanup.get("sigkill_dispatched") is False and cleanup.get("all_descendant_cleanup_qualified") is False, "cleanup scope")
require(all(not (destination / name).exists() for name in FORBIDDEN), "physical artifact absence")
require(all(result.get(name) is False for name in (
    "physical_execution_qualified", "vio_accuracy_qualified", "estimator_health_qualified",
    "fusion_eligible", "flight_ready", "eligible_for_vio_input", "eligible_for_px4_fusion",
)), "downstream closed")
audit = {
    "schema": "depth-startup-binding-probe-audit-v1",
    "failures": failures,
    "startup_binding_qualified": not failures,
    "physical_execution_qualified": False,
    "depth_capture_qualified": False,
    "fusion_eligible": False,
    "flight_ready": False,
    "scope": "startup binding, resource graph and owned worker only; no PX4/Gazebo steps",
}
write_manifest(study / "probe-audit.json", audit)
print(json.dumps(audit, indent=2))
raise SystemExit(0 if not failures else 2)
