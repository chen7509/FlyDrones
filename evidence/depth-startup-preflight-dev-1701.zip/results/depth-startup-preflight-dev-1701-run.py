"""Run the one predeclared startup-only probe once, retaining every outcome."""

import json
import os
import subprocess
import time
from pathlib import Path

from tools.benchmark.capture_disarmed_sensors import active_resources
from tools.benchmark.declared_runtime_snapshot import file_record, write_manifest

root = Path(__file__).resolve().parents[1]
study = root / "results/depth-startup-preflight-dev-1701/study-v5-startup-v1"
path = study / "probe-manifest.json"
record = json.loads(path.read_text())
source = root / "results/depth-physical-development-preflight-dev-1701/study-v5/study-manifest.json"
if (record.get("schema") != "depth-startup-binding-probe-v1"
        or record.get("startup_preflight_only") is not True
        or record.get("physical_run") is not False
        or record.get("fusion_eligible") is not False
        or file_record(source) != record["source_manifest"]
        or file_record(record["source_runtime_binding"]["requested"])
        != record["source_runtime_binding"]
        or file_record(record["preparer"]["requested"]) != record["preparer"]):
    raise ValueError("startup probe identity changed")
original = json.loads(source.read_text())["command"]
expected = list(original)
expected[expected.index("--output") + 1] = record["destination"]
expected.append("--startup-preflight")
if record["command"] != expected or "--startup-preflight" not in record["command"]:
    raise ValueError("startup probe command changed")
dest = Path(record["destination"])
dispatch = study / "probe-dispatch.json"
completion = study / "probe-completion.json"
stdout = study / "probe-output.txt"
if any(os.path.lexists(path) for path in (dest, dispatch, completion, stdout)):
    raise FileExistsError("startup probe already dispatched or output present")
before = active_resources()
if before:
    raise ValueError("competing resources present")
write_manifest(dispatch, {
    "schema": "depth-startup-probe-dispatch-v1",
    "probe_manifest": file_record(path),
    "runner": file_record(__file__),
    "resources_before": before,
    "started_wall_ns": time.time_ns(),
    "physical_run": False,
    "fusion_eligible": False,
})
code = 125
error = None
try:
    with stdout.open("xb") as stream:
        code = subprocess.run(record["command"], cwd=root, stdout=stream,
                              stderr=subprocess.STDOUT, check=False).returncode
except Exception as exc:
    error = repr(exc)
after = active_resources()
write_manifest(completion, {
    "schema": "depth-startup-probe-completion-v1",
    "returncode": code,
    "launcher_error": error,
    "destination_exists": dest.exists(),
    "resources_after": after,
    "ended_wall_ns": time.time_ns(),
    "physical_run": False,
    "fusion_eligible": False,
})
print(json.dumps({"returncode": code, "launcher_error": error, "resources_after": after}))
raise SystemExit(code)
