"""Seal the startup-only evidence without modifying the source physical study."""

from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PREFIX = "depth-startup-preflight-dev-1701"
ARCHIVE = ROOT / "evidence" / f"{PREFIX}.zip"


def selected_files() -> list[Path]:
    documents = [
        ROOT / "docs" / "DEPTH_STARTUP_PREFLIGHT_REPORT.md",
        ROOT / "docs" / "superpowers" / "specs" / "2026-10-10-depth-startup-preflight-design.md",
        ROOT / "docs" / "superpowers" / "plans" / "2026-10-10-depth-startup-preflight.md",
    ]
    result_files = sorted((ROOT / "results").glob(f"{PREFIX}-*"))
    result_files += sorted((ROOT / "results" / PREFIX).rglob("*"))
    files = documents + [item for item in result_files if item.is_file()]
    if len({item.relative_to(ROOT).as_posix() for item in files}) != len(files):
        raise RuntimeError("duplicate evidence member")
    if any(not item.is_file() for item in documents):
        raise RuntimeError("missing required report or plan")
    return sorted(files, key=lambda item: item.relative_to(ROOT).as_posix())


def main() -> None:
    files = selected_files()
    manifest = {
        "schema": "depth-startup-preflight-evidence-manifest-v1",
        "scope": "one startup-only attempt; no physical capture",
        "members": [
            {
                "path": item.relative_to(ROOT).as_posix(),
                "bytes": item.stat().st_size,
                "sha256": hashlib.sha256(item.read_bytes()).hexdigest(),
            }
            for item in files
        ],
    }
    if ARCHIVE.exists():
        raise RuntimeError(f"evidence archive already exists: {ARCHIVE}")
    ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ARCHIVE, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for item in files:
            name = item.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 10, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, item.read_bytes())
        info = zipfile.ZipInfo("evidence-manifest.json", date_time=(2026, 10, 10, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, json.dumps(manifest, indent=2).encode() + b"\n")
    print(json.dumps({"path": str(ARCHIVE), "members": len(files) + 1, "sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()}))


if __name__ == "__main__":
    main()
