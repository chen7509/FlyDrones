"""Assemble non-dispatch plan, receipt requirements and static integrity checks."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent


def save(name, value):
    with (OUT / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)


bindings = {
    name: None for name in (
        'deployed_repo', 'upstream_source_tree', 'current_linux_source_manifest',
        'toolchain_file', 'toolchain_receipt', 'pinned_cmake', 'pinned_gxx', 'pinned_make',
        'openvins_library_dir', 'openvins_library_file', 'openvins_library_sha256', 'library_source_build_receipt',
        'eigen_config_dir', 'opencv4_config_dir', 'boost_config_dir', 'ceres_config_dir',
        'header_package_manifest', 'elf_recursive_closure', 'python_sdk_runtime_closure',
        'exclusive_build_dir', 'new_binary', 'new_binary_build_receipt', 'new_binary_sha256',
        'exclusive_capture_output', 'estimator_config', 'managed_source_config', 'managed_source_sha256',
        'signed_measured_offset_ns', 'measured_calibration_noise_receipt', 'execution_contract',
        'runtime_binding', 'wire_config', 'reference_module', 'reference_sha256', 'agent_runtime_config',
        'trajectory_gauge_policy', 'launch_environment', 'scope_identity', 'fresh_build_firstfacts',
        'fresh_run_firstfacts', 'one_native_admission_review', 'prefeed_identity_barrier_receipt',
        'once_coordinator_source_receipt', 'pinned_python', 'capture_script')
}
flags = [
    '--online-estimate-feed', '--native-estimate-profile', 'offset-reset-v2', '--disarmed-odometry',
    '--consume-disarmed-odometry-evidence', '--record-owned-ulog', '--logger-diagnostic-profile', 'disarmed-receipt-v2',
    '--source-fanout-profile', 'ready-shadow-heartbeat-estimator-v1', '--motion-profile', 'supported-ready-v1',
    '--physics-trace-profile', 'substep-ready-v1'
]
paths = {
    '--output': 'exclusive_capture_output', '--shadow-binary': 'new_binary', '--shadow-config': 'estimator_config',
    '--managed-source-config': 'managed_source_config', '--managed-source-sha256': 'managed_source_sha256',
    '--execution-contract': 'execution_contract', '--runtime-binding': 'runtime_binding', '--wire-config': 'wire_config',
    '--reference-module': 'reference_module', '--reference-sha256': 'reference_sha256', '--agent-runtime-config': 'agent_runtime_config',
    '--trajectory-gauge-policy': 'trajectory_gauge_policy'
}
capture_argv = ['${pinned_python}', '${capture_script}']
for flag, binding in paths.items():
    capture_argv.extend((flag, '${' + binding + '}'))
capture_argv += flags
configure = [
    '${pinned_cmake}', '-S', '${deployed_repo}/tools/benchmark/native_offset_reset_v2', '-B', '${exclusive_build_dir}',
    '-G', 'Unix Makefiles', '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_CXX_COMPILER=${pinned_gxx}',
    '-DCMAKE_MAKE_PROGRAM=${pinned_make}', '-DCMAKE_CXX_FLAGS_RELEASE=-O2', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
    '-DCMAKE_TOOLCHAIN_FILE=${toolchain_file}', '-DOPENVINS_SOURCE_DIR=${upstream_source_tree}',
    '-DOPENVINS_LIBRARY_DIR=${openvins_library_dir}', '-DOV_MSCKF=${openvins_library_file}',
    '-DEigen3_DIR=${eigen_config_dir}', '-DOpenCV_DIR=${opencv4_config_dir}', '-DBoost_DIR=${boost_config_dir}',
    '-DCeres_DIR=${ceres_config_dir}', '-DCMAKE_FIND_USE_PACKAGE_REGISTRY=OFF', '-DCMAKE_FIND_USE_SYSTEM_PACKAGE_REGISTRY=OFF'
]
plan = dict(
    schema='openvins-offset-reset-v2-once-review-plan-v1', dispatchable=False, admission_granted=False,
    attempt_state='PLAN_ONLY_NOT_REQUESTED_NOT_CONSUMED', target='openvins_offset_reset_v2',
    fixed_upstream_commit='69488123ed9362dd44b6f28e7f4680abbff1442b', cxx_standard=17,
    bindings=bindings, configure_argv_template=configure,
    build_argv_template=['${pinned_cmake}', '--build', '${exclusive_build_dir}', '--target', 'openvins_offset_reset_v2', '--parallel', '1'],
    production_capture_argv_template=capture_argv,
    exact_command_producer='tools.benchmark.capture_contract.declared_command(args, python, capture_script, launch_environment)',
    native_argv_owner='make_capture_native_client -> OffsetResetNativeClient -> NativeClient owned pipe/pass_fds',
    native_argv_template=['${new_binary}', '${estimator_config}', '${exclusive_states_path}', '${exclusive_fast_path}', '${fresh_64hex_nonce}', '${signed_measured_offset_ns}', '${owned_child_ack_fd}'],
    one_case=dict(children=1, fixed_nonzero_integral_ns_offset=True, max_abs_offset_ns=1_000_000_000,
        other_sign_covered=False, actual_reset_branch_covered=False, auto_restart=False, old_executable_fallback=False),
    budget=dict(
        future_reserve_each_host_bytes=4*1024**3, resource_facts_observed_this_turn=False,
        preserved_png_compile_reserve_bytes=2*1024**3,
        compile=dict(memory_bytes=1024**3, swap_bytes=0, cpu_percent=100, tasks=64, parallel=1, optimization='O2', combined_configure_build_inner_s=300, outer_s=330, upstream_rebuild=False),
        capture=dict(memory_bytes=4*1024**3, swap_bytes=0, cpu_percent=100, tasks=256, worker_s=300, inner_s=315, kill_after_s=10, scope_wait_s=330, outer_s=360, simulation_ns=25_000_000_000),
        query=dict(each_stream_bytes=2*1024**2, timeout_s=10, term_s=5, kill_s=5),
        native=dict(one_inflight_deadline_s=2, ack_max_bytes=8192, rgb_bytes=57600, fast_line_max_bytes=16384, finish_wait_s=3, finish_kill_wait_s=3),
        causal=dict(imu_gap_max_ns=4_000_000, camera_lag_max_ns=200_000_000, pending_max_ns=250_000_000, fast_grid_ns=20_000_000),
        terminal=dict(ulog_max_bytes=64*1024**2, max_sends=4096, hard_cancel_proven=False, inside_original_total_deadline=True)),
    receipt_requirements={
        'toolchain': ['resolved paths/SHA/package/version', 'compiler specs/sysroot/startfiles/implicit standard headers', 'CMake module/config/imported target bytes', 'make/as/ld/ar/ranlib helper identities'],
        'build': ['firstfacts before configure', 'exclusive consumed record', 'all actual argv/environment/cwd', 'compile_commands.json', 'CMakeCache and selected configs', 'depfiles/response files/linker input closure', 'source/tool/library before-after', 'output ELF identity/dynamic/version metadata', 'scope limits/identity/raw/exits/cleanup'],
        'runtime': ['exact new execution and runtime binding', 'new measured managed10file input closure', 'actual child PID/nonce/startticks/executable', 'prefeed and declared phase maps/recursive ELF closure', 'native request/ack/states/fast and real sample joins', 'sole wire full/short/no-return outcomes', 'owned ULog association and receiver/disabled-EV aid evidence', 'firstfacts/exits/source drift/resource counters/owned cleanup/UNKNOWN']},
    software_remaining=['v2 prefeed readiness/maps barrier if required by admission', 'bound once coordinator and current build receipt producer', 'separate design for other sign and reachable upstream reset evidence'],
    external_remaining=['actual current Linux tool/header/library/package/build-receipt bytes', 'future fresh original resource/no-competitor/cgroup/pidfd conditions', 'measured signed offset/calibration/noise and new runtime inputs', 'actual configure/link/load/ABI/propagation/receipt/performance/cleanup observations'],
    deny_if=['any prerequisite of the current stage null/unfrozen; later outputs are not earlier prerequisites', 'missing software entrypoint or review', 'stale/unknown/failed original gates', 'source/tool/library/input/clock/session drift', 'unknown mapping/scope/pidfd', 'native/channel/causal/receiver/ULog violation or budget exhausted'],
    no_actions_this_turn=['configure', 'compile', 'native target or SDK execution', 'resource refresh', 'old tests', 'old consumed attempts'],
    qualification={key: False for key in ('source', 'clock', 'measured_calibration', 'accuracy', 'teacher', 'fusion', 'training', 'flight', 'controller_ready', 'runtime_graph_frozen', 'physical_dispatch_ready')}
)
save('run-plan.json', plan)

# Current input checks only: never import product, run a test, compiler or native tool.
current = json.loads((OUT / 'current-source-manifest.json').read_bytes())
for name, row in current['files'].items():
    raw = (ROOT / name).read_bytes()
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
upstream = json.loads((OUT / 'upstream-build-source-manifest.json').read_bytes())
for name, row in upstream['files'].items():
    raw = (OUT / 'upstream-source' / name).read_bytes()
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
    assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == row['git_blob_sha1']
assert not plan['dispatchable'] and not plan['admission_granted'] and all(v is None for v in bindings.values())
result = subprocess.run(['git', 'diff', '--check'], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=15)
for label, data in [('stdout', result.stdout), ('stderr', result.stderr)]:
    with (OUT / ('static-diff-check.' + label)).open('xb') as stream:
        stream.write(data)
assert result.returncode == 0
save('static-check.json', dict(scope='New plan/source byte/JSON/blob integrity and git diff-check only, not test/build/native verification.',
    current_files=len(current['files']), upstream_files=len(upstream['files']), bindings_unresolved=len(bindings),
    cxx17_static_conflict_resolved=True, diff_check_exit=result.returncode, native_abi_verified=False,
    old_tests_executed=False, resource_queried=False, native_configure_compile_run=False))
print(json.dumps(dict(current_files=len(current['files']), upstream_files=len(upstream['files']), unresolved_bindings=len(bindings), diff_check=0, dispatchable=False)))
