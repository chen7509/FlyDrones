"""Static source graph only. No imports of product modules, tools or tests."""
import ast
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
before = json.loads((OUT / 'integration-before.json').read_bytes())
upstream = json.loads((OUT / 'upstream-build-source-manifest.json').read_bytes())
assert upstream['selected_build_source_complete'] is True


def identity(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def save(name, value):
    with (OUT / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)


def local_module(module):
    base = ROOT / ('src/' if module.startswith('flydrones') else '') / module.replace('.', '/')
    for path in (base.with_suffix('.py'), base / '__init__.py'):
        if path.is_file():
            return path.relative_to(ROOT).as_posix()
    return None


pending = set(before['files'])
records, imports, dynamic, external = {}, [], [], set()
while pending:
    name = min(pending)
    pending.remove(name)
    if name in records:
        continue
    path = ROOT / name
    raw = path.read_bytes()
    records[name] = identity(raw)
    destination = OUT / 'integration-current' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open('xb') as stream:
        stream.write(raw)
    if path.suffix != '.py':
        continue
    tree = ast.parse(raw, filename=name)
    module = name.removeprefix('src/').removesuffix('.py').replace('/', '.')
    package = module.rsplit('.', 1)[0]
    for node in ast.walk(tree):
        targets = []
        if isinstance(node, ast.Import):
            targets = [alias.name for alias in node.names]
        elif isinstance(node, ast.ImportFrom):
            prefix = node.module or ''
            if node.level:
                parents = package.split('.')
                prefix = '.'.join(parents[:len(parents)-node.level+1] + ([prefix] if prefix else []))
            targets = [prefix] + [prefix + '.' + alias.name for alias in node.names if alias.name != '*']
        elif isinstance(node, ast.Call) and isinstance(node.func, (ast.Name, ast.Attribute)):
            expression = ast.unparse(node.func)
            if expression in ('__import__', 'importlib.import_module', 'import_module', 'spec_from_file_location', 'importlib.util.spec_from_file_location'):
                dynamic.append(dict(file=name, line=node.lineno, expression=ast.unparse(node)[:500]))
        for target in targets:
            if not target:
                continue
            if target.split('.')[0] not in ('tools', 'flydrones'):
                external.add(target.split('.')[0])
                continue
            resolved = local_module(target)
            if resolved:
                imports.append(dict(source=name, line=node.lineno, module=target, path=resolved))
                pending.add(resolved)
                parts = target.split('.')
                for index in range(1, len(parts)):
                    parent = local_module('.'.join(parts[:index]))
                    if parent:
                        pending.add(parent)

changed = [name for name, old in before['files'].items() if records[name] != {key: old[key] for key in ('bytes', 'sha256')}]
assert changed == ['tools/benchmark/native_offset_reset_v2/CMakeLists.txt']
recipe = (ROOT / changed[0]).read_text(encoding='utf-8')
header = (ROOT / 'tools/benchmark/exclusive_probe_output.h').read_text(encoding='utf-8')
assert 'set(CMAKE_CXX_STANDARD 17)' in recipe and '#include <filesystem>' in header
save('current-source-manifest.json', dict(base_head=before['head'], files=records, selected_roots=list(before['files']),
    static_local_import_edges=imports, dynamic_import_sites=dynamic, external_module_names=sorted(external),
    changed_from_before=changed, scope='Targeted current local AST-visible import closure, not proof of dynamic imports/full Python environment or old382 membership.',
    native_compile_or_run_verified=False, static_cxx_standard_requirement_reconciled=True))

base = OUT / 'upstream-source'
core = sorted(p for p in (base / 'ov_core/src').rglob('*.cpp') if p.name not in ('test_profile.cpp', 'test_webcam.cpp', 'test_tracking.cpp'))
init = sorted(p for p in (base / 'ov_init/src').rglob('*.cpp') if p.name not in ('test_dynamic_init.cpp', 'test_dynamic_mle.cpp', 'test_simulation.cpp', 'Simulator.cpp'))
explicit = [
    'src/dummy.cpp', 'src/sim/Simulator.cpp', 'src/state/State.cpp', 'src/state/StateHelper.cpp',
    'src/state/Propagator.cpp', 'src/core/VioManager.cpp', 'src/core/VioManagerHelper.cpp',
    'src/update/UpdaterHelper.cpp', 'src/update/UpdaterMSCKF.cpp', 'src/update/UpdaterSLAM.cpp', 'src/update/UpdaterZeroVelocity.cpp']
msckf = [base / 'ov_msckf' / name for name in explicit]
assert all(path.is_file() for path in msckf)
sources = [path.relative_to(base).as_posix() for path in [*core, *init, *msckf]]
save('upstream-no-ros-library-sources.json', dict(commit=upstream['commit'], tree=upstream['tree'],
    basis='Static expansion of pinned ov_msckf/cmake/ROS1.cmake with ENABLE_ROS=OFF. Not CMake configure output.',
    translation_units=sources, counts=dict(ov_core=len(core), ov_init=len(init), ov_msckf=len(msckf), total=len(sources)),
    ros_visualizers_excluded=True, upstream_rebuild_authorized=False,
    library_build_receipt=None, current_library=None, abi_qualified=False))
print(json.dumps(dict(local_current_files=len(records), static_import_edges=len(imports), dynamic_sites=len(dynamic),
    external_module_names=sorted(external), upstream_translation_units=len(sources), cxx_standard=17)))
