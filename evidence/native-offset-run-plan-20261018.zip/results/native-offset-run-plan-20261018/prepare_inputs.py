"""Read-only source preparation, never configure/build/load/execute native code."""
import datetime
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
import urllib.request

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
COMMIT = '69488123ed9362dd44b6f28e7f4680abbff1442b'
SELECTED = [
    'tools/benchmark/openvins_online_probe_v2.cpp',
    'tools/benchmark/openvins_fast_probe_v2.h',
    'tools/benchmark/exclusive_probe_output.h',
    'tools/benchmark/native_offset_reset_v2/CMakeLists.txt',
    'tools/benchmark/offset_reset_native_source.py',
    'tools/benchmark/managed_capture_source.py',
    'tools/benchmark/openvins_online_shadow.py',
    'tools/benchmark/capture_online_estimates.py',
    'tools/benchmark/capture_disarmed_sensors.py',
    'tools/benchmark/capture_contract.py',
    'tools/benchmark/runtime_resource_binding.py',
    'tools/benchmark/calibration_capture_scope.py',
    'tools/benchmark/native_consumer_scope.py',
    'tools/benchmark/native_entry_dependencies.py',
    'tools/benchmark/openvins_causal_input.py',
    'tools/benchmark/disarmed_odometry_receiver.py',
    'tools/benchmark/openvins_observed_wire_session.py',
    'tools/benchmark/px4_disarmed_receipts.py',
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(name, value):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)


def store(name, raw):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)


def git(label, *args):
    command = ['git', *args]
    result = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=15)
    store('commands/' + label + '.stdout', result.stdout)
    store('commands/' + label + '.stderr', result.stderr)
    save('commands/' + label + '.json', dict(argv=command, exit=result.returncode))
    if result.returncode:
        raise ValueError('read-only Git command failed: ' + label)
    return result.stdout


def fetch(label, url, limit):
    save('network/' + label + '-start.json', dict(url=url, max_bytes=limit, timeout_seconds=30,
        utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), scope='Public pinned source only, no resource/native/environment query'))
    request = urllib.request.Request(url, headers={'User-Agent': 'FlyDrones-source-plan', 'Accept': 'application/vnd.github+json'})
    with urllib.request.urlopen(request, timeout=30) as response:
        raw = response.read(limit + 1)
        metadata = dict(status=response.status, url=response.url, headers=dict(response.headers), bytes=len(raw), sha256=sha(raw))
    if len(raw) > limit:
        raise ValueError('bounded source response exceeded: ' + label)
    store('network/' + label + '.bin', raw)
    save('network/' + label + '-completion.json', metadata)
    return raw


save('preparation-start.json', dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope='Current Windows integration source and fetched pinned upstream source candidate; NOT current Linux tools/libraries or execution admission.',
    selected_sources=SELECTED, no_native_build_run_or_resource_query=True, old_tests_rerun=False))
try:
    head = git('head', 'rev-parse', 'HEAD').decode().strip()
    branch = git('branch', 'branch', '--show-current').decode().strip()
    assert head == 'ddcf0a5c1ce56f88eac312190d3c91205c2a9278'
    assert branch == 'codex/estimator-aware-physical-diagnosis'
    current = {}
    for index, name in enumerate(SELECTED):
        raw = (ROOT / name).read_bytes()
        store('integration-before/' + name, raw)
        blob = git('blob-' + str(index), 'show', head + ':' + name)
        current[name] = dict(bytes=len(raw), sha256=sha(raw), git_blob_bytes=len(blob), git_blob_sha256=sha(blob),
                             same_after_crlf_normalization=raw.replace(b'\r\n', b'\n') == blob)
    save('integration-before.json', dict(head=head, branch=branch, files=current, linux_source_identity_verified=False))
    commit = json.loads(fetch('upstream-commit', 'https://api.github.com/repos/rpng/open_vins/git/commits/' + COMMIT, 1024**2))
    assert commit['sha'] == COMMIT
    tree = json.loads(fetch('upstream-tree', 'https://api.github.com/repos/rpng/open_vins/git/trees/' + commit['tree']['sha'] + '?recursive=1', 4*1024**2))
    assert tree['sha'] == commit['tree']['sha'] and tree['truncated'] is False
    assert not any(row['type'] == 'commit' for row in tree['tree']), 'unresolved gitlink dependency'
    expected = {row['path']: row for row in tree['tree'] if row['type'] == 'blob'}
    archive = fetch('upstream-archive', 'https://codeload.github.com/rpng/open_vins/tar.gz/' + COMMIT, 32*1024**2)
    mapping = {}
    total = 0
    with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as source:
        for member in source:
            if member.isdir():
                continue
            parts = PurePosixPath(member.name).parts
            if len(parts) < 2 or parts[0] != 'open_vins-' + COMMIT or '..' in parts:
                raise ValueError('unexpected archive path')
            name = '/'.join(parts[1:])
            if name not in expected or name in mapping or not member.isfile():
                raise ValueError('unexpected/nonregular/duplicate source member ' + name)
            total += member.size
            if total > 128*1024**2 or len(mapping) >= 8192:
                raise ValueError('source archive expanded bound')
            raw = source.extractfile(member).read(member.size + 1)
            blob_sha = hashlib.sha1(b'blob ' + str(len(raw)).encode('ascii') + b'\0' + raw).hexdigest()
            assert len(raw) == member.size and blob_sha == expected[name]['sha']
            mapping[name] = dict(bytes=len(raw), sha256=sha(raw), git_blob_sha1=blob_sha, git_mode=expected[name]['mode'])
            # Extract source/config/build/license text only; entire original archive is preserved.
            if name.endswith(('.cpp', '.h', '.hpp', '.cc', '.c', '.cmake', '.yaml', '.yml', '.xml')) or PurePosixPath(name).name in ('CMakeLists.txt', 'LICENSE', 'LICENSE.txt', 'LICENSE.md'):
                store('upstream-source/' + name, raw)
    assert set(mapping) == set(expected)
    save('upstream-source-manifest.json', dict(commit=COMMIT, tree=tree['sha'], source_files=len(mapping),
        total_bytes=total, archive_bytes=len(archive), archive_sha256=sha(archive), files=mapping,
        candidate_source_complete_against_github_tree=True, current_linux_checkout_or_library_verified=False,
        tool_library_or_abi_verified=False, native_attempt_consumed=False))
    save('preparation-completion.json', dict(success=True, head=head, selected=len(current), upstream_files=len(mapping),
        native_configure_build_run=False, resource_query=False, old_tests_rerun=False))
    print(json.dumps(dict(selected=len(current), upstream_files=len(mapping), total_bytes=total, archive_bytes=len(archive))))
except BaseException as exc:
    save('preparation-failure.json', dict(error=repr(exc), native_executed=False, resource_query=False,
        scope='Preparation failure only, retain original bytes, do not retry a consumed native version'))
    raise
