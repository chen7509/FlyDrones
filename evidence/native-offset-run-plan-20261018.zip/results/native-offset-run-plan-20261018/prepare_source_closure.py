"""Fetch exact build-source subtrees, not the rejected whole repository dataset."""
import concurrent.futures
import datetime
import hashlib
import json
from pathlib import Path
import urllib.request

OUT = Path(__file__).resolve().parent
COMMIT = '69488123ed9362dd44b6f28e7f4680abbff1442b'
tree = json.loads((OUT / 'network/upstream-tree.bin').read_bytes())
selected = [row for row in tree['tree'] if row['type'] == 'blob' and (
    row['path'].split('/')[0] in ('ov_core', 'ov_init', 'ov_msckf') or row['path'] in ('LICENSE', 'ReadMe.md'))]
assert len(selected) == 143 and sum(row['size'] for row in selected) < 8*1024**2
assert all(row['mode'] in ('100644', '100755') for row in selected)


def save(name, value):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)


save('source-closure-request.json', dict(commit=COMMIT, tree=tree['sha'], selected=selected,
    scope='Entire three build-source subtrees plus license/readme; not full repository data/config, Linux checkout, tools/libraries or binary receipt.',
    aggregate_limit_bytes=8*1024**2, single_response_limit_bytes=512*1024, max_parallel_downloads=6,
    prior_archive_refusal='Whole repository includes ov_data394016623B. Original32MiB+1 response was read but not retained; failure JSON/start retained. Not native input/runtime evidence. No larger archive retry.',
    native_execution=False, resource_query=False))


def fetch(row):
    name = row['path']
    url = 'https://raw.githubusercontent.com/rpng/open_vins/' + COMMIT + '/' + name
    record = dict(url=url, expected_git_blob=row['sha'], utc_start=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save('source-fetch/' + name + '.start.json', record)
    try:
        request = urllib.request.Request(url, headers={'User-Agent': 'FlyDrones-source-plan'})
        with urllib.request.urlopen(request, timeout=20) as response:
            raw = response.read(512*1024 + 1)
            record.update(status=response.status, resolved_url=response.url, headers=dict(response.headers))
        # Preserve the received bytes even if refused; never execute extracted content.
        path = OUT / 'upstream-source' / name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(raw)
        digest = hashlib.sha1(b'blob ' + str(len(raw)).encode('ascii') + b'\0' + raw).hexdigest()
        record.update(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(), git_blob_sha1=digest)
        if len(raw) != row['size'] or len(raw) > 512*1024 or digest != row['sha']:
            raise ValueError('source size/hash mismatch')
        record['verified'] = True
    except BaseException as exc:
        record.update(verified=False, error=repr(exc))
    record['utc_finish'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save('source-fetch/' + name + '.completion.json', record)
    return name, record


with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
    records = dict(pool.map(fetch, selected))
success = all(row['verified'] for row in records.values())
save('upstream-build-source-manifest.json', dict(commit=COMMIT, tree=tree['sha'], files=records,
    selected_files=len(records), total_bytes=sum(row.get('bytes', 0) for row in records.values()),
    selected_build_source_complete=success, full_repository_dataset_or_runtime_config=False,
    current_linux_checkout_verified=False, dependency_binaries_or_abi_verified=False,
    native_attempt_consumed=False, configure_build_run_performed=False))
print(json.dumps(dict(verified=success, selected=len(records), bytes=sum(row.get('bytes', 0) for row in records.values()), failures=[name for name, row in records.items() if not row['verified']])))
if not success:
    raise SystemExit(2)
