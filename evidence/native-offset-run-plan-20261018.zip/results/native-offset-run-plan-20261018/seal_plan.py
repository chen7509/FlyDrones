"""Seal new source/plan materials only; executor integrity, no admission review."""
import hashlib
import json
import os
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[2]
if os.name == 'nt' and not str(ROOT).startswith('\\\\?\\'):
    ROOT = Path('\\\\?\\' + str(ROOT))
PHASE = ROOT / 'results/native-offset-run-plan-20261018'
POST = PHASE / 'postseal'
POST.mkdir(exist_ok=False)
FILES = [
    'tools/benchmark/native_offset_reset_v2/CMakeLists.txt',
    'docs/superpowers/specs/2026-10-18-native-offset-once-plan.md',
    'docs/superpowers/plans/2026-10-18-native-offset-once-plan.md',
    'docs/NATIVE_OFFSET_RUN_PLAN_PROGRESS.md',
]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


plan = json.loads((PHASE / 'run-plan.json').read_bytes())
assert plan['dispatchable'] is False and plan['admission_granted'] is False
assert len(plan['bindings']) == 45 and all(value is None for value in plan['bindings'].values())
assert 'current stage' in plan['deny_if'][0] and 'stage_binding_policy' in plan
assert all(value is False for value in plan['qualification'].values())
current = json.loads((PHASE / 'current-source-manifest.json').read_bytes())
recipe_name = FILES[0]
assert sha((ROOT / recipe_name).read_bytes()) == current['files'][recipe_name]['sha256']
# These are new plan self-checks, not rerun pytest/native or old archive checks.
facts = dict(schema='native-offset-plan-self-check-v1', source_snapshot=current['base_head'],
    current_source_files=len(current['files']), dynamic_sites=len(current['dynamic_import_sites']),
    upstream_files=143, library_translation_units=34, unbound_receipts=len(plan['bindings']),
    per_stage_prerequisites_explicit=True, dispatchable=False, native_admission_review_performed=False,
    configure_compile_native_or_resource_query=False, old_tests_rerun=False,
    original_reviews_unchanged=True,
    console_only_notes=['Initial web API retrieval was unavailable through web tool; direct bounded official API reads succeeded and are retained.',
        'Early filename discovery emitted excessive legacy raw filenames; no old archives/private475/history were audited.',
        'Whole source tar response exceeded32MiB and body was not retained; original failure/start and narrow-subtree rationale retained.',
        'A multi-file apply_patch stage-clarification attempt failed matching the long Markdown line before mutation; corrected literal patch applied. No native consequence.'])
with (PHASE / 'self-check.json').open('x', encoding='utf-8') as stream:
    json.dump(facts, stream, indent=2)
paths = set(FILES)
for path in PHASE.rglob('*'):
    if 'postseal' in path.relative_to(PHASE).parts or '__pycache__' in path.parts or path.suffix == '.pyc':
        continue
    if path.is_file() and not path.is_symlink():
        paths.add(path.relative_to(ROOT).as_posix())
payloads = {name: (ROOT / name).read_bytes() for name in sorted(paths)}
mapping = {name: dict(bytes=len(raw), sha256=sha(raw)) for name, raw in payloads.items()}
manifest = json.dumps(dict(schema='native-offset-run-plan-archive-v1', mapping=mapping,
    scope='New current source and reviewable non-dispatch plan only, not complete current Linux/tool/library/runtime evidence or native admission.'),
    ensure_ascii=False, sort_keys=True, indent=2).encode('utf-8')
archive = ROOT / 'evidence/native-offset-run-plan-20261018.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for name, raw in [*payloads.items(), ('manifest.json', manifest)]:
        entry = zipfile.ZipInfo(name, (2026, 10, 18, 0, 0, 0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        entry.external_attr = 0o100600 << 16
        output.writestr(entry, raw)
with zipfile.ZipFile(archive) as source:
    assert source.testzip() is None and len(source.namelist()) == len(mapping)+1
    for name, row in mapping.items():
        assert sha(source.read(name)) == row['sha256']
receipt = dict(schema='native-offset-run-plan-seal-v1', archive=archive.relative_to(ROOT).as_posix(),
    bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()), members=len(mapping)+1, mapped=len(mapping),
    mapped_payload_bytes=sum(row['bytes'] for row in mapping.values()), manifest_bytes=len(manifest),
    whole_expanded_bytes=sum(row['bytes'] for row in mapping.values())+len(manifest),
    audit='executor new ZIP CRC/member/hash only, no source/admission/native/delivery review',
    software_files=FILES, dispatchable=False, all_qualifications=False)
with archive.with_suffix('.sha256.json').open('x', encoding='utf-8') as stream:
    json.dump(dict(**receipt, mapping=mapping), stream, ensure_ascii=False, indent=2)
with (POST / 'seal-receipt.json').open('x', encoding='utf-8') as stream:
    json.dump(receipt, stream, indent=2)
print(json.dumps(receipt))
