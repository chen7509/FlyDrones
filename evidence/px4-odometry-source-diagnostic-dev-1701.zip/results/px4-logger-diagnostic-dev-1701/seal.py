"""Seal the fixed offline PX4 logger diagnostic evidence without replacing it."""

from __future__ import annotations

import hashlib
import json
import zipfile
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DESTINATION = ROOT / "evidence/px4-odometry-source-diagnostic-dev-1701.zip"
MEMBERS = (
    ".gitattributes",
    "config/px4/source-diagnostic-v1/logger_topics.txt",
    "config/px4/source-diagnostic-v1/profile.json",
    "src/flydrones/connectome_training/px4_logger_diagnostic_profile.py",
    "tools/connectome/audit_px4_logger_diagnostic.py",
    "tests/connectome_training/test_px4_logger_diagnostic_profile.py",
    "docs/superpowers/specs/2026-10-10-px4-odometry-source-diagnostic-design.md",
    "docs/superpowers/plans/2026-10-10-px4-odometry-source-diagnostic.md",
    "docs/PX4_ODOMETRY_SOURCE_DIAGNOSTIC_REPORT.md",
    "results/px4-logger-diagnostic-dev-1701/canonical-exit.txt",
    "results/px4-logger-diagnostic-dev-1701/canonical.json",
    "results/px4-logger-diagnostic-dev-1701/legacy-ulog-exit.txt",
    "results/px4-logger-diagnostic-dev-1701/legacy-ulog.json",
    "results/px4-logger-diagnostic-dev-1701/mutated-exit.txt",
    "results/px4-logger-diagnostic-dev-1701/mutated-topics.txt",
    "results/px4-logger-diagnostic-dev-1701/mutated.json",
    "results/px4-logger-diagnostic-dev-1701/targeted-tests.txt",
    "results/px4-logger-diagnostic-dev-1701/targeted-tests-v2.txt",
    "results/px4-logger-diagnostic-dev-1701/targeted-tests-v3.txt",
    "results/px4-logger-diagnostic-dev-1701/argument-red.txt",
    "results/px4-logger-diagnostic-dev-1701/adjacent-tests.txt",
    "results/px4-logger-diagnostic-dev-1701/ruff.txt",
    "results/px4-logger-diagnostic-dev-1701/ruff-v2.txt",
    "results/px4-logger-diagnostic-dev-1701/seal.py",
)


def main() -> None:
    if DESTINATION.exists():
        raise FileExistsError(DESTINATION)
    payload = {}
    manifest = {"schema": "flydrones.evidence_manifest.v1", "members": {}}
    for member in MEMBERS:
        path = ROOT / member
        if path.is_symlink() or not path.is_file():
            raise FileNotFoundError(path)
        raw = path.read_bytes()
        payload[member] = raw
        manifest["members"][member] = {
            "sha256": hashlib.sha256(raw).hexdigest(),
            "bytes": len(raw),
            "crc32": f"{zlib.crc32(raw):08x}",
        }
    manifest_raw = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    DESTINATION.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DESTINATION, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for member, raw in payload.items():
            archive.writestr(member, raw)
        archive.writestr("manifest.json", manifest_raw)
    with zipfile.ZipFile(DESTINATION) as archive:
        if archive.testzip() is not None:
            raise ValueError("ZIP CRC failed")
        sealed = json.loads(archive.read("manifest.json"))
        if set(archive.namelist()) != set(MEMBERS) | {"manifest.json"}:
            raise ValueError("ZIP member set changed")
        for member, expected in sealed["members"].items():
            raw = archive.read(member)
            if (len(raw) != expected["bytes"]
                    or hashlib.sha256(raw).hexdigest() != expected["sha256"]
                    or f"{zlib.crc32(raw):08x}" != expected["crc32"]):
                raise ValueError(f"ZIP member changed: {member}")
    print(json.dumps({
        "path": str(DESTINATION),
        "sha256": hashlib.sha256(DESTINATION.read_bytes()).hexdigest(),
        "members": len(MEMBERS) + 1,
        "crc_and_hash_verified": True,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
