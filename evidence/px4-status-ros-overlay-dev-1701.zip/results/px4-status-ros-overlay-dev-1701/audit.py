"""Independently compare byte-verified ROS parent and status-overlay input."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PARENT = ROOT / "results/px4-ros2-full-byte-build-dev-1701/source-v1"
DERIVED = ROOT / "results/px4-status-ros-overlay-dev-1701/source-v2"
STATUS = "src/px4_msgs/msg/EstimatorStatus.msg"
FIXED_PX4 = ROOT / "tests/fixtures/px4_status_transport/EstimatorStatus.d6f12ad.msg"


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    parent = json.loads((PARENT / "build-source-profile.json").read_bytes())
    derived = json.loads((DERIVED / "build-source-profile.json").read_bytes())
    names = set(parent["files"])
    if names != set(derived["files"]) or len(names) != 260:
        raise ValueError("file set/count differs")
    changed = []
    for name in sorted(names):
        before, after = (PARENT / name).read_bytes(), (DERIVED / name).read_bytes()
        if sha(before) != parent["files"][name] or sha(after) != derived["files"][name]:
            raise ValueError(f"manifest byte mismatch: {name}")
        if before != after:
            changed.append(name)
    if changed != [STATUS] or (DERIVED / STATUS).read_bytes() != FIXED_PX4.read_bytes():
        raise ValueError("derived source differs outside pinned status replacement")
    if ((DERIVED / "parent-build-source-profile.json").read_bytes()
            != (PARENT / "build-source-profile.json").read_bytes()):
        raise ValueError("embedded parent profile differs")
    result = {
        "schema": "flydrones.px4_status_ros_overlay_independent_audit.v1",
        "parent_file_count": len(names),
        "derived_file_count": len(names),
        "changed_files": changed,
        "parent_profile_sha256": sha((PARENT / "build-source-profile.json").read_bytes()),
        "derived_profile_sha256": sha((DERIVED / "build-source-profile.json").read_bytes()),
        "parent_status_sha256": parent["files"][STATUS],
        "derived_status_sha256": derived["files"][STATUS],
        "compiled_or_live_verified": False,
        "capture_qualified": False,
    }
    (Path(__file__).parent / "audit.json").write_text(
        json.dumps(result, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
