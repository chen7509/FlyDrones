"""Seal source-only ROS status overlay evidence without overwriting an archive."""

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
STUDY = "results/px4-status-ros-overlay-dev-1701"
ARCHIVE = ROOT / "evidence/px4-status-ros-overlay-dev-1701.zip"
FILES = [
    "docs/PX4_STATUS_ROS_SOURCE_OVERLAY_REPORT.md",
    "docs/superpowers/specs/2026-10-12-px4-status-ros-source-overlay-design.md",
    "docs/superpowers/plans/2026-10-12-px4-status-ros-source-overlay.md",
    "src/flydrones/connectome_training/px4_ros2_build_source.py",
    "tests/connectome_training/test_px4_status_ros_source_overlay.py",
    "tests/fixtures/px4_status_transport/EstimatorStatus.d6f12ad.msg",
    "results/px4-ros2-full-byte-build-dev-1701/source-v1/build-source-profile.json",
    "results/px4-ros2-full-byte-build-dev-1701/source-v1/build-source-profile.sha256",
    "results/px4-ros2-full-byte-build-dev-1701/source-v1/src/px4_msgs/msg/EstimatorStatus.msg",
    f"{STUDY}/audit.py",
    f"{STUDY}/audit.json",
    f"{STUDY}/review.txt",
    f"{STUDY}/old-v1-profile.json",
    f"{STUDY}/seal.py",
]
FILES += [
    path.relative_to(ROOT).as_posix()
    for path in sorted((ROOT / f"{STUDY}/source-v2").rglob("*"))
    if path.is_file()
]
FILES += [
    path.relative_to(ROOT).as_posix()
    for path in sorted((ROOT / "results").glob("px4-status-ros-overlay-dev-1701-*.txt"))
    if path.is_file()
]


def main() -> None:
    if ARCHIVE.exists():
        raise FileExistsError(ARCHIVE)
    if len(FILES) != len(set(FILES)) or len(FILES) < 275:
        raise ValueError("evidence member list invalid")
    for name in FILES:
        path = ROOT / name
        if not path.is_file() or path.is_symlink():
            raise ValueError(f"missing or linked evidence member: {name}")
    manifest = {
        "schema": "flydrones.px4_status_ros_overlay_evidence.v1",
        "source_only": True,
        "compiled_or_live_verified": False,
        "training_eligible": False,
        "files": {},
    }
    ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ARCHIVE, "x", zipfile.ZIP_DEFLATED) as archive:
        for name in FILES:
            data = (ROOT / name).read_bytes()
            manifest["files"][name] = {
                "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            }
            archive.writestr(name, data)
        archive.writestr("manifest.json", json.dumps(manifest, sort_keys=True, indent=2))
    with zipfile.ZipFile(ARCHIVE) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("ZIP CRC check failed")
        for name, expected in manifest["files"].items():
            data = archive.read(name)
            if len(data) != expected["bytes"] or hashlib.sha256(data).hexdigest() != expected["sha256"]:
                raise RuntimeError(f"evidence member drift: {name}")
    seal = {
        "archive": str(ARCHIVE),
        "sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
        "member_count": len(FILES) + 1,
        "crc_and_hash_verified": True,
    }
    (ROOT / STUDY / "seal.json").write_text(
        json.dumps(seal, sort_keys=True, indent=2) + "\n", encoding="utf-8",
    )
    print(json.dumps(seal, sort_keys=True))


if __name__ == "__main__":
    main()
