"""Export actual local component journals; transport and time remain synthetic."""
import hashlib
import json
import shutil
from pathlib import Path

from tests.benchmark.test_openvins_wire_fanout_integration import FanoutIntegrationTests

root = Path(__file__).resolve().parent
out = root / 'exports-v1'
out.mkdir(exist_ok=False)
cases = [
    'test_actual_estimator_fanout_journal_queue_and_reconcile',
    'test_queue_full_retains_observation_but_refuses_mixed_reply',
    'test_reconcile_tamper_latches_and_next_wire_operation_refuses',
]
paths = [Path('tests/benchmark/test_openvins_wire_fanout_integration.py'),
         Path('tests/benchmark/test_openvins_wire_heartbeat.py'),
         Path('tools/benchmark/capture_disarmed_sensors.py'),
         Path('tools/benchmark/journaled_heartbeat_lane.py'),
         Path('tools/benchmark/estimator_aware_readiness.py'),
         Path('tools/benchmark/openvins_online_shadow.py'),
         Path('tools/benchmark/disarmed_sensor_provenance.py')]
def hashes():
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)

before = hashes()
save(out / 'declaration.json', dict(cases=cases, sources=before, synthetic_transport=True,
                                   synthetic_clock=True, physical=False, native_estimator=False))
for name in cases:
    case = FanoutIntegrationTests(name)
    case.setUp()
    target = out / name
    target.mkdir()
    try:
        getattr(case, name)()
        case.finish_pipeline()
        case.shadow.finish()
        for path in case.root.iterdir():
            if path.is_file():
                shutil.copyfile(path, target / path.name)
        save(target / 'wire.json', case.f.obj.evidence)
        save(target / 'outcome.json', dict(assertions_pass=True, terminal=case.terminal,
                                         native_calls=case.native.calls, native_delivered=case.shadow.delivered,
                                         fusion=False, live_lifecycle_verified=False))
    finally:
        case.doCleanups()
after = hashes()
save(out / 'after.json', dict(sources=after, unchanged=after == before))
if after != before:
    raise RuntimeError('export source drift')
print('3 synthetic integration exports retained; selected source hashes unchanged')
