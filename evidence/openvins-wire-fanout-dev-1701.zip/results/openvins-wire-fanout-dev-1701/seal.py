import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
stage = Path(__file__).resolve().parent
archive = root / 'evidence/openvins-wire-fanout-dev-1701.zip'
manifest = root / 'evidence/openvins-wire-fanout-seal.json'
assert not archive.exists() and not manifest.exists()
def digest(raw):
    return hashlib.sha256(raw).hexdigest()
old = root / 'evidence/openvins-wire-heartbeat-dev-1701.zip'
assert digest(old.read_bytes()) == '5fe96b567181e1e0c485ae307c39767f43a30958bfa37fed2ea0c9edf32e60d4'
with (stage / 'references.json').open('x') as stream:
    json.dump({str(old.relative_to(root)): digest(old.read_bytes())}, stream, indent=2)
files = [p for p in stage.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
declaration = json.loads((stage / 'exports-v1/declaration.json').read_text())
files += [root / p for p in declaration['sources']]
files += [root / 'docs/OPENVINS_WIRE_FANOUT_REPORT.md']
members = {}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as target:
    for path in sorted(set(files)):
        raw = path.read_bytes()
        name = path.relative_to(root).as_posix()
        target.writestr(name, raw)
        members[name] = dict(bytes=len(raw), sha256=digest(raw))
with zipfile.ZipFile(archive) as target:
    assert target.testzip() is None
    assert len(target.namelist()) == len(members)
    for name, expected in members.items():
        assert digest(target.read(name)) == expected['sha256']
result = dict(archive=archive.name, bytes=archive.stat().st_size,
              sha256=digest(archive.read_bytes()), members=members, test_commit='bd04203',
              source_copy_basis='post-test copies; export selected pre/post hashes retained separately',
              actual_transport=False, physical=False, fusion=False)
with manifest.open('x') as stream:
    json.dump(result, stream, indent=2)
print(json.dumps({k: v for k, v in result.items() if k != 'members'}))
print('members', len(members))
