"""Independent read-only Git-blob check of the prepared official source tree."""

import json
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[2]
repo = root / "results/px4-ros2-source-dev-1701/upstream-px4_msgs"
workspace_name = sys.argv[1] if len(sys.argv) == 2 else "workspace-v3"
prepared = root / "results/px4-ros2-byte-bound-dev-1701" / workspace_name / "src/px4_msgs"
commit = "148bdb4b8214a4d8de83029777fe8d334c74db6f"
tree = subprocess.run(
    ["git", "-C", str(repo), "ls-tree", "-rz", "--full-tree", commit],
    check=True, capture_output=True,
).stdout
count = 0
for raw in tree.split(b"\0"):
    if not raw:
        continue
    metadata, path_bytes = raw.split(b"\t", 1)
    mode, kind, object_id = metadata.split()
    assert mode in (b"100644", b"100755") and kind == b"blob"
    path = prepared / path_bytes.decode("utf-8")
    actual = subprocess.run(
        ["git", "hash-object", "--no-filters", str(path)],
        check=True, capture_output=True,
    ).stdout.strip()
    assert actual == object_id, path
    count += 1
assert count == 255
print(json.dumps({"git_commit": commit, "workspace": workspace_name, "raw_blob_matches": count, "byte_equal": True}))
