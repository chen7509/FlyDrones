"""Seal only this stage's source, specification, report and test outputs."""

import hashlib
import json
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
ARCHIVE = ROOT / "evidence/connectome-csr-compact-dev-1701.zip"
FILES = (
    "src/flydrones/connectome_training/model.py",
    "tests/connectome_training/test_model.py",
    "docs/CONNECTOME_CSR_COMPACT_BACKEND_REPORT.md",
    "docs/superpowers/specs/2026-10-10-connectome-csr-compact-backend-design.md",
    "docs/superpowers/plans/2026-10-10-connectome-csr-compact-backend.md",
    "results/connectome-csr-feasibility-dev-1701/probe.py",
    "results/connectome-csr-feasibility-dev-1701/probe.json",
    "results/connectome-csr-feasibility-dev-1701/model-red.txt",
    "results/connectome-csr-feasibility-dev-1701/model-green.txt",
    "results/connectome-csr-feasibility-dev-1701/review-red.txt",
    "results/connectome-csr-feasibility-dev-1701/review-green.txt",
    "results/connectome-csr-feasibility-dev-1701/connectome-tests.txt",
    "results/connectome-csr-feasibility-dev-1701/inference-probe-env-retry.txt",
    "results/connectome-csr-feasibility-dev-1701/connectome-tests-corrected-env.txt",
    "results/connectome-csr-feasibility-dev-1701/connectome-tests-final.txt",
    "results/connectome-csr-feasibility-dev-1701/model-artifact-final.txt",
    "results/connectome-csr-feasibility-dev-1701/ruff-final.txt",
    "results/connectome-csr-feasibility-dev-1701/diff-check-final.txt",
    "results/connectome-csr-feasibility-dev-1701/versions.json",
    "results/connectome-csr-feasibility-dev-1701/resource-observation.json",
    "results/connectome-csr-feasibility-dev-1701/seal_evidence.py",
)


def main() -> None:
    manifest = {"schema": "flydrones.connectome_csr_compact_evidence.v1", "files": {}}
    ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ARCHIVE, "w", zipfile.ZIP_DEFLATED) as archive:
        for name in FILES:
            data = (ROOT / name).read_bytes()
            manifest["files"][name] = {
                "sha256": hashlib.sha256(data).hexdigest(),
                "bytes": len(data),
            }
            archive.writestr(name, data)
        archive.writestr("manifest.json", json.dumps(manifest, sort_keys=True, indent=2))
    with zipfile.ZipFile(ARCHIVE) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("evidence ZIP CRC verification failed")
        for name, expected in manifest["files"].items():
            data = archive.read(name)
            if hashlib.sha256(data).hexdigest() != expected["sha256"]:
                raise RuntimeError(f"evidence hash mismatch: {name}")
    seal = {
        "archive": str(ARCHIVE),
        "sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
        "member_count": len(FILES) + 1,
        "verified": True,
    }
    (Path(__file__).parent / "seal.json").write_text(
        json.dumps(seal, sort_keys=True, indent=2), encoding="utf-8"
    )
    print(json.dumps(seal, sort_keys=True))


if __name__ == "__main__":
    main()
