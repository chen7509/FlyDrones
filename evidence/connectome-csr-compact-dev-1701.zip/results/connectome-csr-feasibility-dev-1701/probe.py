"""Small CPU CSR/COO parity probe; never load or train the full MaleCNS."""

from __future__ import annotations

import json
from copy import deepcopy

import numpy as np
import torch
from scipy import sparse

from flydrones.brain.connectome import Connectome
from flydrones.connectome_training.model import ConnectomeConstrainedCore
from flydrones.connectome_training.parameters import (
    FULL_CONNECTIONS,
    FULL_NEURONS,
    build_structure_identity,
    initial_parameter_set,
)


def fixture() -> ConnectomeConstrainedCore:
    weights = sparse.csc_matrix(
        np.array([[0, 2, 0], [-3, 0, 1], [0, 0, 0]], np.float32)
    )
    connectome = Connectome(
        "tiny",
        weights,
        np.array(["A", "B", "A"]),
        np.array(["L", "R", "L"]),
    )
    identity = build_structure_identity(connectome, "a" * 64)
    params = initial_parameter_set(
        identity, ("depth", "goal_x"), ("vx", "yaw_rate"), np.array([1, 2])
    )
    return ConnectomeConstrainedCore(connectome, params)


coo_core = fixture()
csr_core = deepcopy(coo_core)
coo = coo_core.fixed_topology
csr64 = coo.to_sparse_csr()
csr32 = torch.sparse_csr_tensor(
    csr64.crow_indices().to(torch.int32),
    csr64.col_indices().to(torch.int32),
    csr64.values(),
    size=csr64.shape,
    check_invariants=True,
)
csr_core.fixed_topology = csr32
assert csr_core.fixed_topology.layout == torch.sparse_csr
assert csr_core.fixed_topology.crow_indices().dtype == torch.int32
assert csr_core.fixed_topology.col_indices().dtype == torch.int32
assert torch.equal(coo.to_dense(), csr32.to_dense())

features = torch.tensor(
    [[[0.25, -0.5], [1.0, 0.3], [-0.1, 0.7], [0.8, -0.2], [0.0, 0.1]]],
    dtype=torch.float32,
)
coo_commands, coo_state = coo_core.forward_sequence(features, truncate_steps=2)
csr_commands, csr_state = csr_core.forward_sequence(features, truncate_steps=2)
assert torch.allclose(coo_commands, csr_commands, atol=1e-7, rtol=0)
assert torch.allclose(coo_state.voltage, csr_state.voltage, atol=1e-7, rtol=0)
coo_commands.square().sum().backward()
csr_commands.square().sum().backward()
grad_differences = {}
for name, parameter in coo_core.named_parameters():
    other = dict(csr_core.named_parameters())[name]
    assert parameter.grad is not None and other.grad is not None
    difference = float((parameter.grad - other.grad).abs().max())
    assert difference <= 1e-7, (name, difference)
    grad_differences[name] = difference

e = FULL_CONNECTIONS
n = FULL_NEURONS
current_fixed_buffer_bytes = (
    2 * 8 * e  # COO indices
    + 4 * e  # COO values
    + 2 * 8 * e  # edge_row and edge_column
    + 2 * 4 * e  # edge_sign and edge_magnitude
)
candidate_fixed_buffer_bytes = 4 * (n + 1) + 4 * e + 4 * e
result = {
    "schema": "flydrones.connectome_csr_feasibility.v1",
    "torch_version": torch.__version__,
    "fixture_neurons": 3,
    "fixture_connections": int(coo._nnz()),
    "csr_indices_dtype": str(csr32.col_indices().dtype),
    "commands_equal_within_1e-7": True,
    "recurrent_state_equal_within_1e-7": True,
    "max_parameter_gradient_difference": grad_differences,
    "full_neurons": n,
    "full_connections": e,
    "current_fixed_buffers_estimated_bytes": current_fixed_buffer_bytes,
    "csr_only_fixed_buffer_estimated_bytes": candidate_fixed_buffer_bytes,
    "static_fixed_buffer_estimated_savings_bytes": (
        current_fixed_buffer_bytes - candidate_fixed_buffer_bytes
    ),
    "full_model_constructed": False,
    "full_model_training_verified": False,
    "peak_build_memory_verified": False,
    "inference_latency_verified": False,
}
print(json.dumps(result, indent=2, sort_keys=True))
