import hashlib, json, pathlib, zipfile
root = pathlib.Path.cwd()
stage = root / 'results/estimator-heartbeat-routing-dev-1701'
archive = root / 'evidence/estimator-heartbeat-routing-dev-1701.zip'
base = root / 'results/estimator-physical-refusal-diagnosis-dev-1701/study-v11'
paths = []
paths += [p for p in base.rglob('*') if p.is_file()]
paths += [p for p in stage.rglob('*') if p.is_file()]
paths += [root / 'evidence/causal-pair-retry-preflight-dev-1701.zip']
for rel in [
    'docs/ESTIMATOR_PHYSICAL_REFUSAL_DIAGNOSIS_REPORT.md',
    'docs/superpowers/specs/2026-10-07-causal-pair-physical-attempt-design.md',
    'docs/superpowers/plans/2026-10-07-causal-pair-physical-attempt.md',
    'docs/superpowers/specs/2026-10-07-estimator-heartbeat-routing-design.md',
    'docs/superpowers/plans/2026-10-07-estimator-heartbeat-routing.md',
    'tools/benchmark/estimator_aware_readiness.py',
    'tools/benchmark/audit_estimator_heartbeat_routing.py',
    'tests/benchmark/test_estimator_aware_readiness.py',
    'tests/benchmark/test_audit_estimator_heartbeat_routing.py',
]: paths.append(root / rel)
paths = sorted(set(p.resolve() for p in paths))
for p in paths:
    if not p.is_file(): raise SystemExit(f'missing: {p}')
members=[]
for p in paths:
    data=p.read_bytes()
    rel=p.relative_to(root).as_posix()
    members.append({'path': rel, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
manifest={'schema':'flydrones-evidence-manifest-v1','stage':'estimator-heartbeat-routing-dev-1701','members':members,'member_count':len(members)}
archive.parent.mkdir(parents=True, exist_ok=True)
if archive.exists(): raise SystemExit(f'exists: {archive}')
prefix='estimator-heartbeat-routing-dev-1701/'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p,m in zip(paths,members): z.writestr(prefix+m['path'],p.read_bytes())
    z.writestr(prefix+'manifest.json',json.dumps(manifest,indent=2,sort_keys=True)+'\n')
with zipfile.ZipFile(archive) as z:
    bad=z.testzip()
    if bad: raise SystemExit(f'bad crc: {bad}')
    if len(z.namelist()) != len(paths)+1: raise SystemExit('member count mismatch')
print(json.dumps({'path':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(paths)+1},indent=2))
