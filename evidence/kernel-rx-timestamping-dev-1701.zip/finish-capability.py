"""Audit completed compile output after wrapper schema refusal; never rebuild."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.benchmark.kernel_rx_timestamping import KernelRXTimestamping

BASE = Path(__file__).parent
OLD = BASE / "capability-v1"
OUT = BASE / "capability-completion-v1"
OUT.mkdir()
before = json.loads((OLD / "inputs-before.json").read_text())
after = {}
for name, expected in before.items():
    path = Path(name)
    resolved = path.resolve(strict=True)
    stat = resolved.stat()
    after[name] = {"requested": str(path), "resolved": str(resolved),
                   "sha256": hashlib.sha256(resolved.read_bytes()).hexdigest(), "bytes": stat.st_size,
                   "device": stat.st_dev, "inode": stat.st_ino, "mtime_ns": stat.st_mtime_ns}
    assert after[name] == expected
raw = (OLD / "abi.stdout").read_bytes()
digest = hashlib.sha256(raw).hexdigest()
profile = KernelRXTimestamping(raw, digest)
probe = OLD / "kernel_rx_timestamping_abi"
assert probe.is_file() and not probe.is_symlink()
result = subprocess.run(["/usr/bin/ldd", str(probe)], capture_output=True, timeout=10)
(OUT / "probe-ldd.stdout").write_bytes(result.stdout)
(OUT / "probe-ldd.stderr").write_bytes(result.stderr)
assert result.returncode == 0
(OUT / "abi.json").write_bytes(raw)
record = {"compile_repeated": False, "probe_execution_repeated": False,
          "wrapper_failure": "ABI output invalid: reused driver still expected timestampns schema",
          "post_snapshot_collected_after_wrapper_refusal": True,
          "inputs_before": before, "inputs_after": after, "inputs_stable_over_extended_interval": before == after,
          "probe_sha256": hashlib.sha256(probe.read_bytes()).hexdigest(), "abi_sha256": digest,
          "abi": json.loads(raw), "profile_evidence": profile.evidence,
          "runtime_closure_qualified": False, "socket_started": False, "pid": os.getpid()}
(OUT / "completion.json").write_text(json.dumps(record, indent=2))
print(json.dumps({"probe_sha256": record["probe_sha256"], "abi_sha256": digest,
                  "compile_repeated": False, "inputs_stable": before == after}))
