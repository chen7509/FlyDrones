import hashlib
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).parent
verified = json.loads((BASE / "final-v1/execution.json").read_text())
assert verified["selected_source_unchanged"] and all(row["exit_code"] == 0 for row in verified["commands"])
for name, expected in verified["source_after"].items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected
capability = json.loads((BASE / "capability-completion-v1/completion.json").read_text())
assert capability["inputs_stable_over_extended_interval"]
assert not capability["compile_repeated"] and not capability["probe_execution_repeated"]
assert not capability["socket_started"]
assert hashlib.sha256((BASE / "capability-v1/kernel_rx_timestamping_abi").read_bytes()).hexdigest() == capability["probe_sha256"]
assert hashlib.sha256((BASE / "capability-completion-v1/abi.json").read_bytes()).hexdigest() == capability["abi_sha256"]
for name in ["docs/KERNEL_RX_TIMESTAMPING_REPORT.md",
             "docs/superpowers/specs/2026-10-12-rx-generated-timestamp-design.md",
             "docs/superpowers/plans/2026-10-12-rx-generated-timestamp.md"]:
    target = BASE / "documents" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / name, target)
old = ROOT / "evidence/kernel-datagram-arrival-dev-1701.zip"
oldsha = hashlib.sha256(old.read_bytes()).hexdigest()
assert oldsha == "e2f6e7a2052a15f78aad6a6d15faaee0fa459880504752744543cd4c1f378325"
with (BASE / "previous-stage-reference.json").open("x") as stream:
    json.dump({"archive_sha256": oldsha, "rerun": False, "trial_still_failed": True,
               "old_archive_consumed_members": [], "reference_only": True}, stream, indent=2)
files = sorted(path for path in BASE.rglob("*") if path.is_file() and path.suffix != ".pyc")
members = {str(path.relative_to(BASE)).replace("\\", "/"): {
    "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size} for path in files}
target = ROOT / "evidence/kernel-rx-timestamping-dev-1701.zip"
with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED) as archive:
    for path in files:
        archive.write(path, str(path.relative_to(BASE)).replace("\\", "/"))
    archive.writestr("member-hashes.json", json.dumps(members, indent=2))
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(members) | {"member-hashes.json"}
    for name, expected in members.items():
        raw = archive.read(name)
        assert hashlib.sha256(raw).hexdigest() == expected["sha256"] and len(raw) == expected["bytes"]
digest = hashlib.sha256(target.read_bytes()).hexdigest()
with target.with_suffix(".sha256").open("x", encoding="ascii") as stream:
    stream.write(digest + "  " + target.name + "\n")
record = {"sha256": digest, "members": len(members) + 1, "bytes": target.stat().st_size,
          "all_members_hash_and_crc_verified": True, "software_and_installed_ABI_only": True,
          "RX_real_socket_trial_executed": False, "arrival_source_clock_fusion_training_qualified": False}
with (BASE / "seal.json").open("x") as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record, indent=2))
