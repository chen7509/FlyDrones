"""Seal this bounded capture-gate change without copying historical failures away."""

from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ARCHIVE = ROOT / "evidence/teacher-inspection-binding-dev-1701.zip"
MEMBERS = (
    "docs/EGO_TEACHER_IMAGE_INSPECTION_REPORT.md",
    "src/flydrones/connectome_training/capture_input.py",
    "src/flydrones/connectome_training/teacher_image.py",
    "tests/connectome_training/test_capture_input_gate.py",
    "results/teacher-inspection-binding-dev-1701/targeted-tests.txt",
    "results/teacher-inspection-binding-dev-1701/real-record-verification.json",
    "results/teacher-inspection-binding-dev-1701/seal.py",
    "results/ego-image-inspection-dev-1701-v3/inspection.json",
)


def main() -> None:
    data = {}
    for name in MEMBERS:
        path = ROOT / name
        if not path.is_file() or path.is_symlink():
            raise ValueError("missing or linked member: " + name)
        data[name] = path.read_bytes()
    manifest = {
        "schema": "flydrones-teacher-inspection-binding-evidence-v1",
        "members": [
            {"path": name, "bytes": len(data[name]), "sha256": hashlib.sha256(data[name]).hexdigest()}
            for name in sorted(data)
        ],
        "teacher_trajectory_produced": False,
        "student_capture_authorized": False,
        "physical_run": False,
    }
    with zipfile.ZipFile(ARCHIVE, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for name in sorted(data):
            archive.writestr(name, data[name])
        archive.writestr("MANIFEST.json", json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    with zipfile.ZipFile(ARCHIVE) as archive:
        if archive.testzip() is not None:
            raise ValueError("ZIP CRC invalid")
        for row in manifest["members"]:
            raw = archive.read(row["path"])
            if len(raw) != row["bytes"] or hashlib.sha256(raw).hexdigest() != row["sha256"]:
                raise ValueError("sealed member mismatch: " + row["path"])
    print(json.dumps({"archive": str(ARCHIVE), "bytes": ARCHIVE.stat().st_size,
                      "sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
                      "members": len(manifest["members"]) + 1}))


if __name__ == "__main__":
    main()
