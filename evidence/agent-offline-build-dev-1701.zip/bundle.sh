#!/usr/bin/env bash
set -euo pipefail

repo=/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility
result="$repo/results/agent-offline-build-dev-1701"
linux_root=/tmp/flydrones-agent-offline-1701-v4
build="$linux_root/build"
bundle="$linux_root/runtime-bundle"
verify="$linux_root/runtime-bundle-verify"
test ! -e "$bundle"
test ! -e "$verify"
mkdir -p "$bundle/bin" "$bundle/lib" "$verify"
cp -a "$build/MicroXRCEAgent" "$bundle/bin/"
cp -a "$build"/libmicroxrcedds_agent.so* "$bundle/lib/"
cp -a "$build/temp_install/fastrtps-2.14/lib"/libfastrtps.so* "$bundle/lib/"
cp -a "$build/temp_install/fastcdr-2.2.0/lib"/libfastcdr.so* "$bundle/lib/"
cp -a "$build/temp_install/microxrcedds_client-2.4.3/lib"/libmicroxrcedds_client.so* "$bundle/lib/"
cp -a "$build/temp_install/microcdr-2.0.1/lib"/libmicrocdr.so* "$bundle/lib/"
tar -czf "$result/runtime-bundle.tar.gz" -C "$bundle" bin lib
tar -xzf "$result/runtime-bundle.tar.gz" -C "$verify"
LD_LIBRARY_PATH="$verify/lib" ldd "$verify/bin/MicroXRCEAgent" > "$result/bundle-ldd.txt"
if grep -q 'not found' "$result/bundle-ldd.txt"; then
    echo 'bundle has unresolved runtime libraries' >&2
    exit 1
fi
for soname in libmicroxrcedds_agent libfastrtps libfastcdr libmicroxrcedds_client libmicrocdr; do
    grep -q "$soname.*$verify/lib" "$result/bundle-ldd.txt"
done
set +e
timeout 5s env LD_LIBRARY_PATH="$verify/lib" "$verify/bin/MicroXRCEAgent" udp4 --help \
    > "$result/bundle-help.stdout" 2> "$result/bundle-help.stderr"
code=$?
set -e
printf '%s\n' "$code" > "$result/bundle-help.exit"
test "$code" -eq 0
sha256sum "$verify/bin/MicroXRCEAgent" "$verify/lib"/lib*.so.* > "$result/bundle-sha256.txt"
printf 'bundle verified\n'
