#!/usr/bin/env bash
set -euo pipefail

repo=/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility
result="$repo/results/agent-offline-build-dev-1701"
linux_root=/tmp/flydrones-agent-offline-1701-v4
cd "$linux_root"
export GIT_CONFIG_GLOBAL="$linux_root/gitconfig"
export GIT_CONFIG_NOSYSTEM=1
export GIT_ALLOW_PROTOCOL=file
export GIT_TERMINAL_PROMPT=0
export HTTPS_PROXY=http://127.0.0.1:9
export HTTP_PROXY=http://127.0.0.1:9
export ALL_PROXY=http://127.0.0.1:9
export CMAKE_BUILD_PARALLEL_LEVEL=1

date --iso-8601=seconds > "$result/build-start-time.txt"
set +e
timeout 1500s cmake --build "$linux_root/build" --parallel 1 2>&1 | tee "$result/build.log"
code=${PIPESTATUS[0]}
set -e
printf '%s\n' "$code" > "$result/build.exit"
date --iso-8601=seconds > "$result/build-end-time.txt"
printf 'build exit=%s\n' "$code"
exit "$code"
