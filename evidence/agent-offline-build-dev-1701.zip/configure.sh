#!/usr/bin/env bash
set -euo pipefail

repo=/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility
result="$repo/results/agent-offline-build-dev-1701"
linux_root=/tmp/flydrones-agent-offline-1701-v4
cd "$linux_root"
export GIT_CONFIG_GLOBAL="$linux_root/gitconfig"
export GIT_CONFIG_NOSYSTEM=1
export GIT_ALLOW_PROTOCOL=file
export GIT_TERMINAL_PROMPT=0
export HTTPS_PROXY=http://127.0.0.1:9
export HTTP_PROXY=http://127.0.0.1:9
export ALL_PROXY=http://127.0.0.1:9

set +e
timeout 120s cmake -S "$linux_root/agent-src" -B "$linux_root/build" -G Ninja \
    -DCMAKE_BUILD_TYPE=Release -DUAGENT_SUPERBUILD=ON -DUAGENT_BUILD_TESTS=OFF \
    > "$result/configure.stdout" 2> "$result/configure.stderr"
code=$?
set -e
printf '%s\n' "$code" > "$result/configure.exit"
printf 'configure exit=%s\n' "$code"
exit "$code"
