#!/usr/bin/env bash
set -euo pipefail

repo=/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility
result="$repo/results/agent-offline-build-dev-1701"
linux_root=/tmp/flydrones-agent-offline-1701-v4
build="$linux_root/build"
binary="$build/MicroXRCEAgent"
cd "$linux_root"

test "$(cat "$result/configure.exit")" = 0
test "$(cat "$result/build.exit")" = 0
test -x "$binary"
file "$binary" > "$result/binary-file.txt"
sha256sum "$binary" "$build/libmicroxrcedds_agent.so.2.4.3" \
    "$build/temp_install/fastrtps-2.14/lib/libfastrtps.so.2.14.7" \
    "$build/temp_install/fastcdr-2.2.0/lib/libfastcdr.so.2.2.8" \
    > "$result/binary-library-sha256.txt"
readelf -d "$binary" > "$result/binary-dynamic.txt"
ldd "$binary" > "$result/binary-ldd.txt"

{
    printf 'Agent copied build-policy source SHA256: '
    sha256sum "$linux_root/agent-src/cmake/SuperBuild.cmake"
    printf 'XRCE Client: '
    git -C "$build/microxrcedds_client/src/microxrcedds_client" rev-parse HEAD
    printf 'Micro-CDR: '
    git -C "$build/microxrcedds_client/src/microxrcedds_client-build/microcdr/src/microcdr" rev-parse HEAD
    printf 'Fast-CDR direct: '
    git -C "$build/fastcdr/src/fastcdr" rev-parse HEAD
    printf 'Fast-DDS: '
    git -C "$build/fastdds/src/fastdds" rev-parse HEAD
    printf 'Foonathan memory: '
    git -C "$build/foonathan_memory/src/foonathan_memory" rev-parse HEAD
    printf 'spdlog: '
    git -C "$build/spdlog/src/spdlog" rev-parse HEAD
    printf 'Fast-DDS submodules:\n'
    git -C "$build/fastdds/src/fastdds" submodule status
} > "$result/source-commits.txt"

cp "$build/CMakeCache.txt" "$result/agent-top-cache.txt"
cp "$build/fastdds/src/fastdds-build/CMakeCache.txt" "$result/fastdds-cache.txt"
cp "$build/fastcdr/src/fastcdr-build/CMakeCache.txt" "$result/fastcdr-cache.txt"
cp "$build/microxrcedds_client/src/microxrcedds_client-build/CMakeCache.txt" "$result/xrce-client-cache.txt"
cp "$build/microxrcedds_client/src/microxrcedds_client-build/microcdr/src/microcdr-build/CMakeCache.txt" "$result/microcdr-cache.txt"

set +e
timeout 5s "$binary" --help > "$result/help.stdout" 2> "$result/help.stderr"
code=$?
set -e
printf '%s\n' "$code" > "$result/help.exit"
printf 'help exit=%s\n' "$code"
