# Retained second offline preparation failure

The corrected shallow-object import successfully staged the two Fast-CDR commits and four more direct repositories from fixed local pin refs. It stopped at Micro-CDR because the sealed `micro_cdr.git` contains only `refs/flydrones/pins/source` for audited commit `3d1b17703c7cf4f22def2910bc845bdb5152d7b5`; it has no local `refs/tags/v2.0.1`. The XRCE Client's fixed CMake uses `GIT_TAG v2.0.1`. Attempting to fetch that missing local tag failed. No CMake build ran. The failed scratch directory is `/tmp/flydrones-agent-offline-1701-v2`.

The next attempt may create an explicitly labeled **build-only lightweight alias** `v2.0.1` to the previously audited commit in a new staging repository. That alias is not evidence that the original upstream tag object was fetched. The object ID, not the synthetic tag object identity, is the build-source constraint.
