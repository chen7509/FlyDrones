#!/usr/bin/env bash
set -euo pipefail

repo=/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility
result="$repo/results/agent-offline-build-dev-1701"
linux_root=/tmp/flydrones-agent-offline-1701-v4
direct="$repo/results/px4-agent-dependency-objects-dev-1701"
children="$repo/results/fastdds-gitlink-objects-dev-1701"
source="$repo/results/px4-agent-v243-pinned-source-dev-1701/source-v4"

test ! -e "$linux_root"
mkdir -p "$linux_root"
cd "$linux_root"

stage_repo() {
    local name="$1" input="$2" commit="$3" output="$linux_root/$1.git"
    git init --bare -q "$output"
    git --git-dir="$output" fetch --no-tags --update-shallow "$input" "refs/flydrones/pins/source:refs/heads/pinned"
    test "$(git --git-dir="$output" rev-parse refs/heads/pinned)" = "$commit"
    git --git-dir="$output" symbolic-ref HEAD refs/heads/pinned
}

stage_repo fast_cdr_combined "$direct/fast_cdr.git" 757d5e422253568c487ad97c22e44680fc1ddbaf
git --git-dir="$linux_root/fast_cdr_combined.git" fetch --no-tags --update-shallow "$children/fastcdr_gitlink.git" refs/flydrones/pins/source:refs/heads/gitlink
git --git-dir="$linux_root/fast_cdr_combined.git" cat-file -e '757d5e422253568c487ad97c22e44680fc1ddbaf^{commit}'
git --git-dir="$linux_root/fast_cdr_combined.git" cat-file -e '1bc9c919311ffce555b445560bf7ae062a4e1c72^{commit}'
if git --git-dir="$linux_root/fast_cdr_combined.git" cat-file -e 'deadbeefdeadbeefdeadbeefdeadbeefdeadbeef^{commit}' 2>/dev/null; then
    echo 'wrong object unexpectedly accepted' >&2
    exit 1
fi

stage_repo fast_dds "$direct/fast_dds.git" 575d045b55c16be1074ccd9eebf95e3e4274fe61
stage_repo foonathan_memory "$direct/foonathan_memory.git" 0f0775770fd1c506fa9c5ad566bd6ba59659db66
stage_repo xrce_client "$direct/xrce_client.git" d44dc3fa0c488376e34d26ed92853f1c66dcb670
stage_repo spdlog "$direct/spdlog.git" eb3220622e73a4889eee355ffa37972b3cac3df5
stage_repo micro_cdr "$direct/micro_cdr.git" 3d1b17703c7cf4f22def2910bc845bdb5152d7b5
git --git-dir="$linux_root/micro_cdr.git" tag v2.0.1 3d1b17703c7cf4f22def2910bc845bdb5152d7b5
test "$(git --git-dir="$linux_root/micro_cdr.git" rev-parse 'v2.0.1^{commit}')" = 3d1b17703c7cf4f22def2910bc845bdb5152d7b5
stage_repo android_ifaddrs "$children/android_ifaddrs.git" 7b1ce82817226e481d3cda0a5d06b66ebcc211f8
stage_repo asio "$children/asio.git" ed6aa8a13d51dfc6c00ae453fc9fb7df5d6ea963
stage_repo tinyxml2 "$children/tinyxml2.git" 8c8293ba8969a46947606a93ff0cb5a083aab47a

cfg="$linux_root/gitconfig"
touch "$cfg"
git config --file "$cfg" protocol.file.allow always
git config --file "$cfg" "url.file://$linux_root/fast_cdr_combined.git.insteadOf" https://github.com/eProsima/Fast-CDR.git
git config --file "$cfg" "url.file://$linux_root/fast_dds.git.insteadOf" https://github.com/eProsima/Fast-DDS.git
git config --file "$cfg" "url.file://$linux_root/foonathan_memory.git.insteadOf" https://github.com/foonathan/memory.git
git config --file "$cfg" "url.file://$linux_root/xrce_client.git.insteadOf" https://github.com/eProsima/Micro-XRCE-DDS-Client.git
git config --file "$cfg" "url.file://$linux_root/spdlog.git.insteadOf" https://github.com/gabime/spdlog.git
git config --file "$cfg" "url.file://$linux_root/micro_cdr.git.insteadOf" https://github.com/eProsima/Micro-CDR.git
git config --file "$cfg" "url.file://$linux_root/android_ifaddrs.git.insteadOf" https://github.com/michalsrb/android-ifaddrs.git
git config --file "$cfg" "url.file://$linux_root/asio.git.insteadOf" https://github.com/chriskohlhoff/asio.git
git config --file "$cfg" "url.file://$linux_root/tinyxml2.git.insteadOf" https://github.com/leethomason/tinyxml2.git

export GIT_CONFIG_GLOBAL="$cfg"
export GIT_CONFIG_NOSYSTEM=1
export GIT_ALLOW_PROTOCOL=file
export GIT_TERMINAL_PROMPT=0
export HTTPS_PROXY=http://127.0.0.1:9
export HTTP_PROXY=http://127.0.0.1:9
export ALL_PROXY=http://127.0.0.1:9
git ls-remote https://github.com/eProsima/Fast-DDS.git HEAD > "$result/rewritten-positive.txt"
if git ls-remote https://example.invalid/unbound.git > "$result/unbound.stdout" 2> "$result/unbound.stderr"; then
    echo 'unbound HTTPS URL unexpectedly accepted' >&2
    exit 1
fi

cp -a "$source" "$linux_root/agent-src"
python3 - "$linux_root/agent-src/cmake/SuperBuild.cmake" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
original = path.read_text()
needle = '                -DTHIRDPARTY:BOOL=ON\n'
assert original.count(needle) == 1
patched = original.replace(
    needle,
    needle
    + '                -DTHIRDPARTY_Asio:STRING=FORCE\n'
    + '                -DTHIRDPARTY_TinyXML2:STRING=FORCE\n'
    + '                -DTHIRDPARTY_fastcdr:STRING=OFF\n'
    + '                -DTHIRDPARTY_UPDATE:BOOL=OFF\n',
)
path.write_text(patched)
PY
diff -u "$source/cmake/SuperBuild.cmake" "$linux_root/agent-src/cmake/SuperBuild.cmake" > "$result/build-policy.diff" || test "$?" -eq 1
sha256sum "$source/cmake/SuperBuild.cmake" "$linux_root/agent-src/cmake/SuperBuild.cmake" > "$result/build-policy-sha256.txt"
git config --file "$cfg" --list > "$result/gitconfig-observed.txt"
cp "$cfg" "$result/gitconfig.copy"
printf '%s\n' "$linux_root" > "$result/linux-build-root.txt"
printf 'prepared\n'
