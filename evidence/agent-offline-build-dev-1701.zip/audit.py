"""Independent checks of the fixed offline Agent build and portable bundle."""

import hashlib
import json
import re
import tarfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
EXPECTED = {
    "XRCE Client": "d44dc3fa0c488376e34d26ed92853f1c66dcb670",
    "Micro-CDR": "3d1b17703c7cf4f22def2910bc845bdb5152d7b5",
    "Fast-CDR direct": "757d5e422253568c487ad97c22e44680fc1ddbaf",
    "Fast-DDS": "575d045b55c16be1074ccd9eebf95e3e4274fe61",
    "Foonathan memory": "0f0775770fd1c506fa9c5ad566bd6ba59659db66",
    "spdlog": "eb3220622e73a4889eee355ffa37972b3cac3df5",
}
SUBMODULES = {
    "thirdparty/android-ifaddrs": "7b1ce82817226e481d3cda0a5d06b66ebcc211f8",
    "thirdparty/asio": "ed6aa8a13d51dfc6c00ae453fc9fb7df5d6ea963",
    "thirdparty/fastcdr": "1bc9c919311ffce555b445560bf7ae062a4e1c72",
    "thirdparty/tinyxml2": "8c8293ba8969a46947606a93ff0cb5a083aab47a",
}


def read(name: str) -> str:
    return (ROOT / name).read_text(encoding="utf-8-sig")


def main() -> None:
    assert read("configure.exit").strip() == "0"
    assert read("build.exit").strip() == "0"
    assert read("help.exit").strip() == "1"  # top-level --help usage, retained
    assert read("bundle-help.exit").strip() == "0"
    assert "Usage:" in read("bundle-help.stdout")
    assert "fatal: transport 'https' not allowed" in read("unbound.stderr")
    assert read("rewritten-positive.txt").split()[0] == EXPECTED["Fast-DDS"]
    assert "No such file" not in read("build.log")

    source = read("source-commits.txt")
    for name, commit in EXPECTED.items():
        assert re.search(rf"(?m)^{re.escape(name)}: {commit}$", source), name
    for path, commit in SUBMODULES.items():
        assert re.search(rf"(?m)^ {commit} {re.escape(path)} ", source), path

    fastdds = read("fastdds-cache.txt")
    agent = read("agent-top-cache.txt")
    for line in (
        "THIRDPARTY_Asio:STRING=FORCE",
        "THIRDPARTY_TinyXML2:STRING=FORCE",
        "THIRDPARTY_fastcdr:STRING=OFF",
        "THIRDPARTY_UPDATE:BOOL=OFF",
        "FIND_PACKAGE_MESSAGE_DETAILS_TinyXML2:INTERNAL=[/tmp/flydrones-agent-offline-1701-v4/build/fastdds/src/fastdds/thirdparty/tinyxml2]",
        "fastcdr_DIR:PATH=/tmp/flydrones-agent-offline-1701-v4/build/temp_install/fastcdr-2.2.0/",
    ):
        assert line in fastdds, line
    assert "TinyXML2_DIR:PATH=/usr/lib/x86_64-linux-gnu/cmake/tinyxml2" in agent
    assert "fastrtps_DIR:PATH=/tmp/flydrones-agent-offline-1701-v4/build/temp_install/fastrtps-2.14/" in agent

    ldd = read("bundle-ldd.txt")
    assert "not found" not in ldd
    for name in ("libmicroxrcedds_agent", "libfastrtps", "libfastcdr", "libmicroxrcedds_client", "libmicrocdr"):
        assert re.search(rf"{name}[^\n]*runtime-bundle-verify/lib/{name}", ldd), name
    original_binary_hash = read("binary-library-sha256.txt").split()[0]
    bundle = ROOT / "runtime-bundle.tar.gz"
    with tarfile.open(bundle, "r:gz") as archive:
        data = archive.extractfile("bin/MicroXRCEAgent").read()
        assert hashlib.sha256(data).hexdigest() == original_binary_hash
        assert any(member.name == "lib/libfastrtps.so.2.14.7" for member in archive)
    result = {
        "schema": "flydrones.agent_offline_build_audit.v1",
        "fixed_commits_verified": True,
        "fastdds_nested_selection_verified": True,
        "isolated_build_exit_zero": True,
        "bundle_help_exit_zero": True,
        "bundle_dynamic_libraries_resolve": True,
        "agent_sha256": original_binary_hash,
        "bundle_sha256": hashlib.sha256(bundle.read_bytes()).hexdigest(),
        "px4_dds_publisher_authenticated": False,
        "vio_to_ekf2_fusion_verified": False,
    }
    (ROOT / "audit.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
