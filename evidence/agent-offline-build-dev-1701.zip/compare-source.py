"""Run under WSL to compare sealed Agent source to the build-owned copy."""

import hashlib
import json
from pathlib import Path


REPO = Path("/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility")
ORIGINAL = REPO / "results/px4-agent-v243-pinned-source-dev-1701/source-v4"
COPY = Path("/tmp/flydrones-agent-offline-1701-v4/agent-src")
OUTPUT = REPO / "results/agent-offline-build-dev-1701/source-compare.json"


def inventory(root: Path) -> dict[str, str]:
    return {
        p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in root.rglob("*")
        if p.is_file()
    }


before, after = inventory(ORIGINAL), inventory(COPY)
added = sorted(after.keys() - before.keys())
missing = sorted(before.keys() - after.keys())
changed = sorted(path for path in before.keys() & after.keys() if before[path] != after[path])
result = {
    "schema": "flydrones.agent_copy_source_compare.v1",
    "original_count": len(before),
    "copy_count": len(after),
    "added": added,
    "missing": missing,
    "changed": changed,
    "original_policy_sha256": before["cmake/SuperBuild.cmake"],
    "copy_policy_sha256": after["cmake/SuperBuild.cmake"],
}
OUTPUT.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
assert len(before) == len(after) == 214
assert added == missing == []
assert changed == ["cmake/SuperBuild.cmake"]
