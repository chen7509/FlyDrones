"""Seal bounded Agent build evidence with member hashes and CRC verification."""

import hashlib
import json
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DEST = ROOT.parents[1] / "evidence" / "agent-offline-build-dev-1701.zip"


def main() -> None:
    files = sorted(path for path in ROOT.rglob("*") if path.is_file())
    manifest = [
        {
            "path": path.relative_to(ROOT).as_posix(),
            "size": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        }
        for path in files
    ]
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, path.relative_to(ROOT).as_posix())
        archive.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
    with zipfile.ZipFile(DEST) as archive:
        assert archive.testzip() is None
        for item in manifest:
            assert hashlib.sha256(archive.read(item["path"])).hexdigest() == item["sha256"]
    print(
        json.dumps(
            {
                "zip": str(DEST),
                "members": len(manifest) + 1,
                "sha256": hashlib.sha256(DEST.read_bytes()).hexdigest(),
            }
        )
    )


if __name__ == "__main__":
    main()
