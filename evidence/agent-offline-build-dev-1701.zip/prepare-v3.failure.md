# Retained third offline preparation failure

All nine build-owned bare repositories were staged from audited shallow commit objects, including both Fast-CDR commits and a build-only Micro-CDR `v2.0.1` alias to the audited commit. The next Git command (`git ls-remote` for the URL rewrite) exited before network access with `not a git repository` pointing to this Windows worktree's `.git/worktrees` path. The WSL process inherited the Windows current directory, whose Git pointer is not a valid WSL Git directory. This is a caller working-directory error, not evidence that an object or rewrite was wrong. No CMake build ran. The failed scratch directory is `/tmp/flydrones-agent-offline-1701-v3`.

The next isolated attempt must change to its own Linux scratch directory before any standalone Git command while preserving the exact object and URL assertions.
