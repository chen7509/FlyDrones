# Reproduce the clone motion diagnosis

This is a development-world offline replay. Verify this ZIP's adjacent
`.sha256.json` index and the preceding texture and track-geometry evidence
ZIP hashes in `metadata.json`. The texture ZIP contains the original RGB,
PX4 ULog, and runner. The track-geometry ZIP contains the earlier post-clean
trace and EKF2 audit. The current ZIP retains the full clone instrumentation
patch, logs, states, 183-row comparison, source, fixed config, and report.

Use a separate checkout of upstream GPL-3.0 OpenVINS commit
`69488123ed9362dd44b6f28e7f4680abbff1442b`. Apply the full
`instrumentation.patch` from the repository root, build the ROS-free
`ov_msckf_lib` target (`cmake --build ov_msckf/build --target ov_msckf_lib -j2`),
and run the saved `runner-v3/offline_probe` with this library ahead of its
original RUNPATH in `LD_LIBRARY_PATH`. The roughly 293 MB shared library is
not in Git; its exact hash and size are in `metadata.json`. The first attempt
to compile the new logger failed because the upstream `ClonePose` accessors
are non-const; the archived patch is the corrected, successfully built version.

Replaying the 604 RGB frames and frozen IMU CSV must produce `states.csv`
SHA-256 `f0f1966527c80bc49a5d219053a3e9c282aeb04eab7439dccd0fe3d265f8740f`.
The 183 feature attempts, 1001 post-clean observations and 1001 clone pose
records must match one-to-one. With NumPy and pyulog available, score a *new*
output directory from the repository root:

```sh
python3 -m tools.benchmark.audit_openvins_clone_motion \
  --trace results/openvins-clone-motion/replay-v1/stderr.txt \
  --ulog results/openvins-texture-dev/episode-v1/px4-ulog/log/2026-10-03/01_28_24.ulg \
  --config results/openvins-texture-dev/config-v2/kalibr_imucam_chain.yaml \
  --state-csv results/openvins-clone-motion/replay-v1/states.csv \
  --original-state-csv results/openvins-texture-dev/openvins-run-v2/states.csv \
  --prior-attempts-csv results/openvins-track-geometry/audit-v3/attempts.csv \
  --output-dir results/openvins-clone-motion/audit-reproduction
```

The scorer refuses to overwrite previous outputs or accept changed state,
calibration, ULog, or prior EKF2 audit CSV hashes. Camera clone poses are
OpenVINS estimates and EKF2 poses are an offline sensor-fusion reference;
neither is ground truth and neither is fed back to the controller or VIO.
