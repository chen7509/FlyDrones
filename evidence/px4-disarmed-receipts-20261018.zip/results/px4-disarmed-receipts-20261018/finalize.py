"""Executor disposition/retention for this software phase only; no old audit."""
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if os.name == 'nt' and not str(ROOT).startswith('\\\\?\\'):
    ROOT = Path('\\\\?\\' + str(ROOT))
OUT = ROOT / 'results/px4-disarmed-receipts-20261018'


def identity(data):
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(name, value):
    with (OUT / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)


review = json.loads((OUT / 'review.json').read_bytes())
assert review['counts'] == dict(C=0, I=1, M=0)
# Selected source support for the proven finding, not a historical archive scan.
support = [
    'results/openvins-timesync-observer-dev-1701/installed/src/modules/mavlink/mavlink_timesync.h',
    'results/openvins-timesync-observer-dev-1701/installed/src/lib/timesync/Timesync.hpp',
    'results/openvins-ekf2-disarmed-preflight-dev-1701/source-snapshots/px4-Timesync.cpp',
    'results/openvins-ekf2-disarmed-preflight-dev-1701/source-snapshots/px4-TimesyncStatus.msg',
    'tools/benchmark/openvins_timesync_observer.py',
]
copies = {}
for name in support:
    data = (ROOT / name).read_bytes()
    destination = OUT / 'I1-static-source' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open('xb') as stream:
        stream.write(data)
    copies[name] = identity(data)
save('I1-static-source.json', dict(files=copies, native_validation=False))

individual = {
    'D1': ('Accepted decline: no authentication/convergence grant exists; retained owned witness and exact field correlation have explicitly limited meaning.', 'Separate admitted identity/clock experiment required; no additional grant.'),
    'D2': ('Accepted decline: actual hook is terminal cleanup, not a live intervention path.', 'A live monitor needs its own transport and safety lifecycle; no substitute here.'),
    'D3': ('Accepted decline: retain exact whole-log/instance/bracketing/offset restrictions and their conservative refusals.', 'A relaxed correlation rule needs separate evidence and native verification; not implemented.'),
    'D4': ('Accepted decline: missing aid publication remains an error, never fabricated zero or positive fusion.', 'Only an admitted native capture can establish actual topic publication.'),
    'D5': ('Accepted decline: original deadline point checks are real, synchronous filesystem/parser hard cancellation is explicitly unproven.', 'A cancellation architecture would add new scope and verification; original outer watchdog budget remains.'),
    'D6': ('Accepted decline: stable priority sorting places consumer before later-registered end clocks and after association.', 'Cosmetic priority renumbering is unnecessary; retain original timing semantics.'),
    'D7': ('Accepted decline: stable same-byte buffer and owned source association are ordinary evidence, not hostile filesystem/full environment attestation.', 'Broader sandbox/dependency authentication would be a separate project; limitations stay explicit.'),
    'D8': ('Accepted decline: aid observations are independent sampled facts, positive counts explicitly partial, no causal positive-fusion/continuous-runtime grant.', 'Full positive-fusion causal coverage requires a distinct admitted experiment.'),
    'D9': ('Accepted decline: real Python parser/codec/files and injected process protocols prove software behavior only.', 'Native binary/ABI/transport validation remains gated and unexecuted.'),
    'D10': ('Accepted decline: no additional proven source defect; do not broaden formatting, legacy tests or old profile changes.', 'Extra churn/testing would exceed this bounded fix; only new tests executed.'),
}
declined = []
for row in review['declined_judgments']:
    reason, cost = individual[row['id']]
    declined.append(dict(**row, executor_ruling='declined', executor_reason=reason, executor_cost=cost, deferred_source_minor=False))

runs = []
fixtures = []
for path in sorted(OUT.glob('*/completion.json')):
    value = json.loads(path.read_bytes())
    label = path.parent.name
    runs.append(dict(label=label, exit=value['exit'], elapsed_s=value['elapsed_s'], pytest=value['argv'][1:3] == ['-m', 'pytest'], before=len(value['source_before']), after=len(value['source_after'])))
    for row in value.get('retained_regular_fixtures', []):
        data = (path.parent / row['path']).read_bytes()
        assert identity(data) == {key: row[key] for key in ('bytes', 'sha256')}
        fixtures.append(dict(run=label, **row))
stats = dict(schema='px4-disarmed-receipts-owned-retention-v1', command_runs=runs,
             pytest_runs=sum(row['pytest'] for row in runs), inventories=2*len(runs),
             retained_regular_fixtures=len(fixtures), retained_fixture_bytes=sum(row['bytes'] for row in fixtures), fixtures=fixtures,
             scope='Phase-owned declared basetemp payload only; no legacy TemporaryDirectory/full inherited environment/FFI/crash-safe preservation claim. v1 and additive v2 declarations remain separate, never backfilled.')
save('owned-retention.json', stats)

append = '''

Final software disposition (2026-10-18): original ONE source review C0/I1/M0 over10 frozen files remains unchanged. I1 was source-proven: pinned MavlinkTimesync owns default-constructed Timesync, whose source is UNKNOWN0; published status retains0. The original new fixture fabricated1 and masked rejection of intended pinned logs. ONE bounded executor fix changes only the new consumer and test: require exact0, explicitly disclaim authentication, use0 in the analytic fixture, regress0/1/2. Two true behavior REDs (0 rejected,1 accepted) plus1pass/34deselected in1.26s precede the fix. No PX4 patch or time/RTT/ownership/gate relaxation. Ten declined judgments are individually ruled with reason/cost in executor-disposition.json; no deferred source Minor or second source/native/delivery review.

Final verification executes only this new test file:37pass2.61s, no pytest warnings; Ruff0 across all5 affected Python files, git diff --check exit0 (existing CRLF-to-LF advisories retained, not claimed warning-free Git). Earlier34pass2.28s and Ruff0 remain pre-review evidence. Other direct coverage was not retroactively labelled RED. Final I1 support is retained as five selected static source copies, not a full old archive scan or native build receipt.

Selected pyulog1.2.4 installation retains package sources/metadata and pip-generated Windows entry-point wrappers; wrappers were not run. Existing owned pymavlink source is reused, not repackaged as full environment closure. Recorder v1 declared17 paths, additive v2 declares33; original missing-file/null declarations and all command before/after states remain untouched. Retention counts/identities are in owned-retention.json. Owned basetemp fixtures are retained; external legacy temporary payloads, collection/import/FFI sandboxing, complete scientific dependencies and crash-safe channels are not claimed. Initial package-missing metadata query and read-only rg wildcard/no-file diagnostics occurred before recording and remain console-only evidence; no native impact.

Seal/publication contains this new software delta and its raw evidence only. Original native target is still uncompiled/unconfigured/unrun and no real PX4 ULog, delivery, TIMESYNC convergence, disabled-EV aid publication, innovations/reset/source-loss/ACKLAND or positive fusion was verified. Receiver-only disabled-EV matching is not active EKF2 fusion. All qualifications/readiness remain false. Original full history/UNKNOWN/CONSUMED/AV/recorder-gap/retention limits and resource/sensor/precision/speed/RTF/once/cleanup budgets remain binding; no resource refresh or competing-process action occurred.
'''
report = ROOT / 'docs/PX4_DISARMED_RECEIPTS_PROGRESS.md'
with report.open('ab') as stream:
    stream.write(append.encode('utf-8'))
plan = ROOT / 'docs/superpowers/plans/2026-10-18-px4-disarmed-receipts.md'
before = plan.read_bytes()
assert before.count(b'- [ ]') == 5
plan.write_bytes(before.replace(b'- [ ]', b'- [x]', 4))

comparison = {}
for row in review['files']:
    name = row['path']
    original = dict(bytes=row['original_bytes'], sha256=row['original_sha256'])
    assert identity((OUT / 'review-inputs' / name).read_bytes()) == original
    final = identity((ROOT / name).read_bytes())
    comparison[name] = dict(original=original, final=final, changed=original != final, original_grade=row['original_grade'])
changed = {name for name, row in comparison.items() if row['changed']}
assert changed == {'tools/benchmark/px4_disarmed_receipts.py', 'tests/benchmark/test_px4_disarmed_receipts.py', 'docs/PX4_DISARMED_RECEIPTS_PROGRESS.md', 'docs/superpowers/plans/2026-10-18-px4-disarmed-receipts.md'}
save('executor-disposition.json', dict(schema='px4-disarmed-receipts-executor-v1', original_counts=review['counts'],
     bounded_fix_passes=1, findings=[dict(id='I1', status='fixed', reason='Verified retained pinned constructor/publisher and existing observer; exact0 compatibility, no authentication.',
     red='review-I1-red:2fail1pass1.26s', final='final-software:37pass2.61s', native_verified=False)],
     declined_judgments=declined, reviewed_to_seal=comparison, changed=len(changed), unchanged=10-len(changed),
     second_source_review=False, native_run=False, delivery_review=False, all_qualifications=False, runtime_graph_frozen=False, physical_dispatch_ready=False))
print(json.dumps(dict(runs=len(runs), pytest_runs=stats['pytest_runs'], inventories=stats['inventories'], fixtures=len(fixtures), fixture_bytes=stats['retained_fixture_bytes'], reviewed_changed=len(changed), reviewed_unchanged=10-len(changed))))
