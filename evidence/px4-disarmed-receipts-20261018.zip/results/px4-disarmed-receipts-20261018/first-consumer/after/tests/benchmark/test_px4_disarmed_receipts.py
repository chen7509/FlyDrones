"""Real analytic ULog/codec and production cleanup; no native/network dispatch."""
import hashlib
import json
import os
import socket
import struct
import subprocess
import time
from types import SimpleNamespace

import numpy as np
import pytest

@pytest.fixture(autouse=True)
def inert(monkeypatch):
    def denied(*args,**kwargs):
        raise AssertionError("native/network forbidden")
    monkeypatch.setattr(subprocess,"Popen",denied)
    monkeypatch.setattr(socket,"socket",denied)
    monkeypatch.setattr(os,"system",denied)


def record(kind,payload):
    return struct.pack("<HB",len(payload),ord(kind))+payload


def material():
    from tools.benchmark.disarmed_odometry_receiver import DisarmedOdometryReceiver
    from tools.benchmark.openvins_ekf2_disarmed_preflight import RemoteMonotonicClock
    from tools.benchmark.openvins_timesync_wire import PinnedCodec
    codec=PinnedCodec();clock=RemoteMonotonicClock("wire",sim_origin_ns=0,remote_origin_ns=1_000_000)
    state=dict(sample_ns=120_000_000,reset_counter=0,reset_total=0,native_profile="offset-reset-v2",
               native_state13=[0.,0.,0.,1.,1.,2.,3.,4.,5.,6.,0.,0.,.5],native_covariance12=np.eye(12).tolist(),
               native_session="a"*64,native_pid=42,quality=None)
    receiver=DisarmedOdometryReceiver(SimpleNamespace(wire_snapshot=lambda sim:dict(state,sample_ns=sim)))
    receiver.response_ns=100
    sends=[];rows=[]
    for index,ns in enumerate((120_000_000,140_000_000)):
        raw=receiver.odometry(codec,clock,index,101,ns,disarmed=True)
        receiver.send_events[-1]["bytes_returned"]=len(raw)
        wire=codec.decode_datagram(raw)[0]["fields"]
        rows.append(dict(timestamp=wire["time_usec"]+501000,timestamp_sample=wire["time_usec"]+500000,
                         pose_frame=2,velocity_frame=3,position=[wire[k] for k in ("x","y","z")],q=wire["q"],
                         velocity=[wire[k] for k in ("vx","vy","vz")],angular_velocity=[wire[k] for k in ("rollspeed","pitchspeed","yawspeed")],
                         position_variance=[wire["pose_covariance"][i] for i in (0,6,11)],
                         orientation_variance=[wire["pose_covariance"][i] for i in (15,18,20)],
                         velocity_variance=[wire["velocity_covariance"][i] for i in (0,6,11)],reset_counter=0,quality=0))
    sends=receiver.send_events
    columns={"vehicle_visual_odometry":[("uint64_t","timestamp","Q"),("uint64_t","timestamp_sample","Q"),
              ("uint8_t","pose_frame","B"),("uint8_t","velocity_frame","B")]+[(f"float[{n}]",name,f"{n}f") for name,n in
              [("position",3),("q",4),("velocity",3),("angular_velocity",3),("position_variance",3),("orientation_variance",3),("velocity_variance",3)]]+
              [("uint8_t","reset_counter","B"),("int8_t","quality","b")],
              "timesync_status":[("uint64_t","timestamp","Q"),("uint8_t","source_protocol","B"),("uint64_t","remote_timestamp","Q"),("int64_t","estimated_offset","q"),("uint32_t","round_trip_time","I")],
              "vehicle_status":[("uint64_t","timestamp","Q"),("uint8_t","arming_state","B")],
              "actuator_armed":[("uint64_t","timestamp","Q"),("bool","armed","B")],
              "estimator_status":[("uint64_t","timestamp","Q"),("uint32_t","filter_fault_flags","I")],
              "estimator_selector_status":[("uint64_t","timestamp","Q"),("uint8_t","primary_instance","B")],
              "estimator_status_flags":[("uint64_t","timestamp","Q")]+[("bool",k,"B") for k in ("cs_ev_pos","cs_ev_vel","cs_ev_hgt","cs_ev_yaw")]}
    data={"vehicle_visual_odometry":rows,"timesync_status":[dict(timestamp=t,source_protocol=1,remote_timestamp=t-500000,estimated_offset=500000,round_trip_time=1000) for t in (610000,630000)],
          "vehicle_status":[dict(timestamp=t,arming_state=1) for t in (600000,700000)],
          "actuator_armed":[dict(timestamp=t,armed=0) for t in (600000,700000)],
          "estimator_status":[dict(timestamp=t,filter_fault_flags=0) for t in (600000,700000)],
          "estimator_selector_status":[dict(timestamp=t,primary_instance=0) for t in (600000,700000)],
          "estimator_status_flags":[dict(timestamp=t,cs_ev_pos=0,cs_ev_vel=0,cs_ev_hgt=0,cs_ev_yaw=0) for t in (600000,700000)]}
    for topic,n in (("estimator_aid_src_ev_pos",2),("estimator_aid_src_ev_vel",3),("estimator_aid_src_ev_hgt",1)):
        cols=[("uint64_t","timestamp","Q"),("uint64_t","timestamp_sample","Q"),("uint8_t","estimator_instance","B"),("uint64_t","time_last_fuse","Q"),("bool","fused","B"),("bool","innovation_rejected","B")]
        vector_names=("observation","observation_variance","innovation","innovation_variance","test_ratio")
        cols += [("float" if n==1 else f"float[{n}]",k,"f" if n==1 else f"{n}f") for k in vector_names]
        columns[topic]=cols
        data[topic]=[dict(timestamp=r["timestamp"],timestamp_sample=r["timestamp_sample"],estimator_instance=0,time_last_fuse=0,fused=0,innovation_rejected=0,
                           **{k:(0.1 if n==1 else [0.1]*n) for k in vector_names}) for r in rows]
    return sends,columns,data


def encode(columns,data,ev=0):
    raw=b"ULog\x01\x12\x35\x01"+struct.pack("<Q",1)+record("B",bytes(40))
    for name,cols in columns.items():raw+=record("F",(name+":"+"".join(t+" "+k+";" for t,k,_ in cols)).encode())
    key=b"int32_t EKF2_EV_CTRL";raw+=record("P",bytes([len(key)])+key+struct.pack("<i",ev))
    for index,(name,cols) in enumerate(columns.items()):
        raw+=record("A",struct.pack("<BH",0,index)+name.encode())
        for row in data[name]:
            payload=struct.pack("<H",index)
            for _,k,fmt in cols:
                values=row[k] if isinstance(row[k],list) else [row[k]]
                payload+=struct.pack("<"+fmt,*values)
            raw+=record("D",payload)
    return raw


def test_complete_real_bytes_receipt_is_distinct_from_disabled_fusion():
    from tools.benchmark.px4_disarmed_receipts import analyze_log
    sends,columns,data=material()
    facts=analyze_log(encode(columns,data),sends)
    assert facts["matched_receipts"]==2 and facts["receiver_fields_correlated"] is True
    assert facts["disabled_ev_observed"] is True and facts["positive_fusion_samples"]==0
    assert facts["fusion_verified"] is False and facts["flight_eligible"] is False


@pytest.mark.parametrize("fault",["armed","offset","reset","field","short","missing","fused","dropout","parameter"])
def test_actual_evidence_faults_do_not_gain_acceptance(fault):
    from tools.benchmark.px4_disarmed_receipts import analyze_log
    sends,columns,data=material()
    if fault=="armed":data["vehicle_status"][1]["arming_state"]=2
    if fault=="offset":data["timesync_status"][0]["estimated_offset"]+=100
    if fault=="reset":data["vehicle_visual_odometry"][1]["reset_counter"]=1
    if fault=="field":data["vehicle_visual_odometry"][1]["position"][0]+=1
    if fault=="short":sends[0]["bytes_returned"]=2
    if fault=="missing":del columns["estimator_aid_src_ev_vel"]
    if fault=="fused":data["estimator_aid_src_ev_pos"][0]["fused"]=1
    raw=encode(columns,data,ev=1 if fault=="parameter" else 0)
    if fault=="dropout":raw+=record("O",b"\x01\x00")
    try:
        facts=analyze_log(raw,sends)
    except ValueError:
        return
    assert facts["errors"] and facts["receiver_only_evidence_complete"] is False
    assert facts["fusion_verified"] is False


def test_cleanup_consumes_after_collection_and_association_without_native(tmp_path,monkeypatch):
    from tools.benchmark import capture_disarmed_sensors as capture
    from tools.benchmark.disarmed_sensor_provenance import CaptureJournal
    from tools.benchmark import px4_disarmed_receipts as receipt
    events=[]
    monkeypatch.setattr(capture,"collect_ulogs",lambda *args:events.append("collect") or [])
    class Source:
        def __init__(self,*args,**kwargs):pass
        def finish(self,records):
            events.append("associate")
            return dict(errors=[],all_logs_associated=True)
    monkeypatch.setattr("tools.benchmark.owned_ulog_source.OwnedUlogSource",Source)
    monkeypatch.setattr(receipt,"consume_capture",lambda *args,**kwargs:events.append("consume") or dict(errors=[],fusion_verified=False))
    result=dict(status="capture_completed",errors=[])
    with CaptureJournal(tmp_path,result) as journal:
        capture.prepare_owned_ulog_collection(dict(owned_ulog_source={},disarmed_receipt_evidence={}),tmp_path,tmp_path,"a"*64,result,journal,deadline_ns=time.monotonic_ns()+1_000_000_000)
    assert events==["collect","associate","consume"]
    assert result["disarmed_receipt_evidence"]["fusion_verified"] is False
