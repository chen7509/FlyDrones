from pathlib import Path
b=Path(__file__).resolve().parent;root=b.parents[1]
s=(root/'results/readiness-anchor-dev-1701/run_capture.py').read_text()
s=s.replace("paths = list((root / 'tools/benchmark').glob('*.py'))","paths = list((root / 'tools/benchmark').glob('*.py')) + list((root / 'tools/benchmark').glob('*.cc'))\nbuild_reference = json.loads((out / 'production-build/build.json').read_text())\npaths += [Path(build_reference['binary'])]")
s=s.replace("name='substep-ready-v1', motion=profile()","name='supported-ready-native-reference-v1', motion=profile(), reference_binary_sha256=build_reference['binary_sha256']")
s=s.replace("'--physics-trace-profile', 'substep-ready-v1']","'--physics-trace-profile', 'substep-ready-v1', '--reference-module', build_reference['binary'], '--reference-sha256', build_reference['binary_sha256']]")
s=s.replace("['.py', '.sdf']","['.py', '.sdf', '.cc']")
with (b/'run_capture.py').open('x') as f:f.write(s)
