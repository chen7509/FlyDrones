import hashlib,json,urllib.request
from pathlib import Path
base=Path(__file__).resolve().parent;dest=base/'sources';dest.mkdir(exist_ok=False)
rev='446a44335a45b704b4d36dabcc5508ee34eeb3d8'
urls={
 'TestFixture-binding.cc':f'https://raw.githubusercontent.com/gazebosim/gz-sim/{rev}/python/src/gz/sim/TestFixture.cc',
 'TestFixture.cc':f'https://raw.githubusercontent.com/gazebosim/gz-sim/{rev}/src/TestFixture.cc',
 'Physics.cc':f'https://raw.githubusercontent.com/gazebosim/gz-sim/{rev}/src/systems/physics/Physics.cc',
 'pybind11-v2.11.1-LICENSE':'https://raw.githubusercontent.com/pybind/pybind11/v2.11.1/LICENSE',
 'pybind11-metadata.json':'https://api.github.com/repos/pybind/pybind11',
 'gz-sim-metadata.json':'https://api.github.com/repos/gazebosim/gz-sim',
 'pybind11-v2.11.1-misc.rst':'https://raw.githubusercontent.com/pybind/pybind11/v2.11.1/docs/advanced/misc.rst',
 'OpenVINS-ICRA2020.pdf':'https://pgeneva.com/downloads/papers/Geneva2020ICRA.pdf',
}
manifest=[]
for name,url in urls.items():
    data=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'FlyDrones-evidence'}),timeout=30).read()
    (dest/name).write_bytes(data);manifest.append(dict(name=name,url=url,sha256=hashlib.sha256(data).hexdigest()))
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(len(manifest))
