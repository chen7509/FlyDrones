import hashlib,json,sys
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation
from pyulog import ULog
base=Path(__file__).resolve().parent;root=base.parents[1];sys.path[:0]=[str(root),str(root/'src')]
from tools.benchmark.physics_substep_trace import phase_closures,_state
from tools.benchmark.disarmed_sensor_provenance import audit_event_records
p=base/'capture-v1'
read=lambda n:[json.loads(x) for x in (p/n).read_text().splitlines()]
result=json.loads((p/'result.json').read_text());exitdata=json.loads((base/'exit.json').read_text())
assert result['status']=='capture_completed' and not result['estimator_run'] and not result['errors']
assert exitdata['unchanged'] and not exitdata['resources']
nr=result['native_reference'];assert nr['complete'] and nr['pre_count']==nr['post_count']==25000
fresh=read('native-reference.jsonl');old=read('physics-substeps.jsonl');events=read('events.jsonl');commands=read('motion-force.jsonl')
assert len(fresh)==25000 and len(old)==50000
for i,r in enumerate(fresh,1):
    assert r['pre_ns']==r['post_ns']==i*1000000 and r['canary_overwritten'] is True
    assert (r['parent_entity'],r['child_entity'])==(fresh[0]['parent_entity'],fresh[0]['child_entity'])
    assert r['truth_for_abort_audit_only'] and not r['eligible_for_px4_fusion'];_state(r)
    if i>1:assert r['wall_ns']>=fresh[i-2]['wall_ns']
for i,r in enumerate(old):assert r['phase']==['pre','post'][i%2] and r['sim_ns']==(i//2+1)*1000000
counts=audit_event_records(events,required_kinds={'imu','rgb','info','depth','heartbeat'})
assert counts['imu']==6251 and all(counts[k]==251 for k in ['rgb','info','depth'])
schedule=json.loads((p/'readiness-anchor.json').read_text());anchor=schedule['anchor_ns']
assert anchor==schedule['selected_sim_ns']+200000000 and schedule['selected_sim_ns']<8000000000
for entry in schedule['proof']['records'].values():
    original={k:v for k,v in entry.items() if k!='journal_ack_monotonic_ns'};assert original in events
    assert entry['arrival_monotonic_ns']<=entry['recorded_monotonic_ns']<=entry['journal_ack_monotonic_ns']<=schedule['proof']['checked_wall_ns']
assert [c['sim_ns'] for c in commands]==list(range(anchor,25001000000,1000000))
assert all(c['call_returned'] and len(c['per_link'])==6 and all(v['call_returned'] for v in c['per_link']) for c in commands)
lateral=[c for c in commands if c['force_world_n'][1]];assert len(lateral)==1600 and sum(c['force_world_n'][1] for c in lateral)==0
assert lateral[0]['sim_ns']==anchor+3000000000 and lateral[-1]['sim_ns']==anchor+4599000000
clearance=read('support-clearance.jsonl');assert len(clearance)==25000
assert [r['sim_ns'] for r in clearance]==list(range(1000000,25001000000,1000000))
minimum=min(r['ground_clearance_m'] for r in clearance if r['sim_ns']>=anchor+2000000000);assert minimum>=.1
derived=[dict(r,phase='post',sim_ns=r['post_ns'],available=True) for r in fresh]
by_time={r['post_ns']:r for r in fresh};old_post={r['sim_ns']:r for r in old if r['phase']=='post'}
windows=[]
for name,start,end in [('lateral_first100ms',anchor+3000000000,anchor+3100000000),('lateral_full',anchor+3000000000,anchor+4600000000),('settled',anchor+6000000000,anchor+7000000000),('lift',anchor,anchor+2000000000)]:
    w=dict(name=name,child=phase_closures(derived,start,end),parent=phase_closures(old,start,end))
    raw=[r for r in events if r['kind']=='imu' and start<=r['sample_ns']<=end]
    times=np.array([r['sample_ns'] for r in raw],dtype=np.int64);assert np.all(np.diff(times)==4000000)
    a=np.array([Rotation.from_quat(by_time[r['sample_ns']]['quaternion_xyzw']).apply(r['accel_flu'])+[0,0,-9.81] for r in raw])
    dv=np.array(by_time[int(times[-1])]['velocity_world'])-by_time[int(times[0])]['velocity_world'];dt=np.diff(times)[:,None]*1e-9
    w['raw']=dict(start_ns=int(times[0]),end_ns=int(times[-1]),samples=len(raw),phase_ns=int(times[0]%4000000),
        right_error_norm_m_s=float(np.linalg.norm(np.sum(a[1:]*dt,axis=0)-dv)),
        trapezoid_error_norm_m_s=float(np.linalg.norm(np.sum(.5*(a[1:]+a[:-1])*dt,axis=0)-dv)))
    windows.append(w)
comparison={}
for key in ['position','velocity_world','accel_world','angular_world']:
    d=[float(np.linalg.norm(np.array(r[key])-old_post[r['post_ns']][key])) for r in fresh]
    index=int(np.argmax(d));comparison[key]=dict(max_norm=d[index],sim_ns=fresh[index]['post_ns'])
ulogs=[]
for m in result['px4_ulogs']:
    path=p/m['path'];assert hashlib.sha256(path.read_bytes()).hexdigest()==m['sha256']
    arming=ULog(str(path)).get_dataset('vehicle_status').data['arming_state'];assert len(arming) and np.all(arming==1)
    ulogs.append(dict(m,arming_records=len(arming),arming_values=[int(x) for x in np.unique(arming)]))
build=json.loads((base/'production-build/build.json').read_text())
assert hashlib.sha256(Path(build['binary']).read_bytes()).hexdigest()==build['binary_sha256']
summary=dict(counts=counts,anchor_ns=anchor,native_steps=len(fresh),support_steps=len(commands),ground_clearance_min_m=minimum,
    windows=windows,old_new_comparison=comparison,ulogs=ulogs,native_binary_sha256=build['binary_sha256'],
    raw_criteria_pass=windows[0]['raw']['trapezoid_error_norm_m_s']<=.02 and windows[1]['raw']['trapezoid_error_norm_m_s']<=.05,
    canary_overwrite_observed=True,eligible_for_px4_fusion=False,estimator_run=False,
    diagnostic_scope='Native independent child overwrite and consistency; source-specific experiment, not VIO certification',
    examples=[dict(sim_ns=t,child=by_time[t],parent=old_post[t]) for t in [anchor+4600000000,anchor+6000000000,anchor+7000000000]])
with (base/'audit.json').open('x') as f:json.dump(summary,f,indent=2,allow_nan=False)
print(json.dumps({k:v for k,v in summary.items() if k not in ['windows','examples']},indent=2))
for w in windows:print(w['name'],w['child']['full']['right_error_norm_m_s'],w['parent']['full']['right_error_norm_m_s'],w['raw'])
