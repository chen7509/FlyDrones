#include <pybind11/pybind11.h>
#include <gz/sim/EntityComponentManager.hh>
PYBIND11_MODULE(fly_ecm_abi_probe,m) {
  m.def("count",[](const gz::sim::EntityComponentManager &ecm){return ecm.EntityCount();});
}
