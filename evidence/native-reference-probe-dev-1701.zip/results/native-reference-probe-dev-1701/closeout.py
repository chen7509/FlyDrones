import json
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent
plan = root / 'docs/superpowers/plans/2026-10-06-native-reference-probe.md'
text = plan.read_text(encoding='utf-8')
text = text.replace('- [ ] Tests first', '- [x] Tests first').replace('- [ ] Implement native', '- [x] Implement native').replace('- [ ] Freeze binary', '- [x] Freeze binary')
plan.write_text(text, encoding='utf-8')
ledger = root / '.superpowers/sdd/2026-10-06-native-reference-probe/progress.md'
text = ledger.read_text(encoding='utf-8').replace('- Full regression underway; seal/publication pending.', '- Full regression 895 passed / 2 existing warnings in 215.98s. Changed Ruff passes; whole Ruff retains 50 errors in 32 unchanged files. Native tracked runner nine cases rerun successfully. Second review Minor narrows writer-error timing guarantee; both Minor resolved, no producer changes. Final process check empty; seal/publication next.')
ledger.write_text(text, encoding='utf-8')
checks = {}
commands = {
 'changed_ruff': ['python', '-m', 'ruff', 'check', 'tools/benchmark/native_reference_probe.py', 'tools/benchmark/build_native_reference.py', 'tools/benchmark/capture_disarmed_sensors.py', 'tests/benchmark/test_native_reference_probe.py', 'tests/native/native_reference_synthetic.py'],
 'tracked_native_synthetic': ['wsl', '-d', 'Ubuntu', '--cd', '/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility', 'python3', 'tests/native/native_reference_synthetic.py', 'results/native-reference-probe-dev-1701/test-build/_fly_native_reference_test.cpython-312-x86_64-linux-gnu.so'],
 'processes': ['wsl', '-d', 'Ubuntu', '--cd', '/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility', 'python3', '-c', 'from tools.benchmark.capture_disarmed_sensors import active_resources; print(active_resources())'],
}
for key, cmd in commands.items():
 p = subprocess.run(cmd, cwd=root, capture_output=True)
 checks[key] = dict(command=cmd, exit_code=p.returncode, stdout=p.stdout.decode('utf-8', errors='replace'), stderr=p.stderr.decode('utf-8', errors='replace'))
 assert p.returncode == 0, checks[key]
checks['review'] = dict(reviewer='/root/review_native_reference', critical=0, important=0, minor=2, disposition=['Persist native runner in tests/native, verified nine synthetic cases', 'Scope per-step writer guarantee to native-reference journal; existing sensor writer outer-chunk polling explicitly retained'], capture_producer='e28fcc3', capture_rerun=False, real_runtime_injected_fault_cleanup_tested=False)
with (base / 'closeout-checks.json').open('x', encoding='utf-8') as f:
 json.dump(checks, f, indent=2)
print(json.dumps({k: v.get('exit_code', v) for k, v in checks.items()}))
