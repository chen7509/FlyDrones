import json,sys
from pathlib import Path
base=Path(__file__).resolve().parent;root=base.parents[1];sys.path[:0]=[str(root),str(root/'src')]
from tools.benchmark.native_reference_probe import load_module
import gz.sim8 as sim
build=json.loads((base/'production-build/build.json').read_text());assert build['exit']==0
m=load_module(Path(build['binary']),build['binary_sha256']);p=m.Probe()
assert not m.TESTING and not hasattr(p,'inject') and not hasattr(m,'fixture')
try:p.pre(sim.EntityComponentManager(),1000000,1000000)
except RuntimeError as e:reason=str(e)
else:raise AssertionError('missing parent accepted')
assert p.status()['failed']
out=dict(binary_sha256=build['binary_sha256'],test_mutation_exports_absent=True,missing_parent_refused=reason)
with (base/'production-check.json').open('x') as f:json.dump(out,f,indent=2)
print(json.dumps(out))
