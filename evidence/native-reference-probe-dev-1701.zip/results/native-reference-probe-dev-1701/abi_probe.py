import hashlib,importlib.util,json,subprocess,sysconfig
from pathlib import Path
import gz.sim8 as sim
base=Path(__file__).resolve().parent
out=base/('fly_ecm_abi_probe'+sysconfig.get_config_var('EXT_SUFFIX'))
flags=subprocess.check_output(['pkg-config','--cflags','--libs','gz-sim8'],text=True).split()
includes=subprocess.check_output(['python3-config','--includes'],text=True).split()
cmd=['g++','-std=c++17','-O1','-shared','-fPIC',str(base/'abi_probe.cc'),'-o',str(out),*includes,*flags]
p=subprocess.run(cmd,capture_output=True,text=True,timeout=90)
r=dict(command=cmd,exit=p.returncode,stdout=p.stdout,stderr=p.stderr)
if p.returncode==0:
    spec=importlib.util.spec_from_file_location('fly_ecm_abi_probe',out);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    r['empty_ecm_count']=mod.count(sim.EntityComponentManager());r['sha256']=hashlib.sha256(out.read_bytes()).hexdigest()
with (base/'abi.json').open('x') as f:json.dump(r,f,indent=2)
print(json.dumps(r))
