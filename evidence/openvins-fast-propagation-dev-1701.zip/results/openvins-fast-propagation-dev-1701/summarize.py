import hashlib
import json
from pathlib import Path

import numpy as np

stage = Path(__file__).resolve().parent
raw = [json.loads(line) for line in (stage / 'replay-v1/fast.jsonl').read_text().splitlines()]
ready = [r for r in raw if r['success']]
prearm = [r for r in ready if 15_680_000_000 <= r['target_ns'] <= 19_700_000_000]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(stage / 'replay-v1/states.csv') == '2b5ce9c343e63f3178a74e8a02c889beba3bfbc02ddf9eaf4e1c526f94a6f550'
def quantiles(values):
    return dict(zip(['min', 'median', 'p95', 'max'], np.quantile(values, [0, .5, .95, 1]).tolist()))
summary = {
    'original_camera_csv_sha256_parity': sha(stage / 'replay-v1/states.csv'),
    'fast_sha256': sha(stage / 'replay-v1/fast.jsonl'),
    'successful_targets': len(ready), 'prearm_targets': len(prearm),
    'propagation_api_seconds': quantiles([r['propagation_wall_s'] for r in ready]),
    'prearm_body_speed_m_s': quantiles([np.linalg.norm(r['state13'][7:10]) for r in prearm]),
    'visual_age_ms': quantiles([(r['target_ns'] - r['last_camera_ns']) / 1e6 for r in ready]),
    'imu_boundary_lookahead_ms': quantiles([(r['available_imu_ns'] - r['target_ns']) / 1e6 for r in ready]),
    'distinct_prearm_states': len({tuple(r['state13']) for r in prearm}),
    'filter_unchanged_targets': sum(r['filter_unchanged'] for r in raw),
    'timing_scope': 'upstream API call only, excludes feed/decode/invariance/serialization; single offline run, no online arrival evidence',
    'all_failed_target_times_ns': [r['target_ns'] for r in raw if not r['success']],
}
with (stage / 'summary-v1.json').open('x') as stream:
    json.dump(summary, stream, indent=2, allow_nan=False)
print(json.dumps({k: v for k, v in summary.items() if k != 'all_failed_target_times_ns'}, indent=2))
