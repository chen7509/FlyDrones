# Execution ledger

- Frozen-input prerequisite: PR31 completed; clean branch793296b. No running PX4/Gazebo/training/replay found before work.
- Spec/plan b33025d committed before implementation. User standing approval applies; inline implementation.
- Initial Python RED: missing new audit module, auditor-red.txt. GREEN:20passed, auditor-green-v1.txt. New optional interface rejected by old probe, usage recorded in optional-interface-red.txt; no estimator launched in this check.
- Build succeeds against unchanged pinned GPL library; hashes/compiler/ldd recorded. Verified482 prior source files. New input, library or sensor configuration not substituted.
- Ruling: use integer-ns IMU cutoff in new fast mode; original default mode retains original float comparison. Intended to prevent cutoff rounding; fixed replay demonstrates exact original cameraCSV parity.
- One estimator replay, exit0, 6.02s/RSS68512KB.2136targets,2030initialized successful predictions,106initial targets explicitly unavailable. No post-initialization propagation failures. No second estimator run.
- Native camera audit still41prearm frames, internaltrue/publicfalse. Fast audit202prearm targets/publicfalse/fusionfalse. Every fast call checks unchanged base filter.
- Ten offline corruptions rejected; not online sensor fault/recovery evidence.
- Full regression627passed/2existingwarnings/181.47s. Ruff passed. Independent read-only source/evidence review found no Critical/Important/Minor; reviewer did not run tests or estimator. Final report separately supplied for review.
- First copied process checker listed state_probe but omitted new fast_probe name; second checker adds it but reports its own renamed inspection process. Third checker excludes its own PID explicitly and finds no relevant process. All three records retained, none overwritten; no process killed.
- Final report read-only review confirms all numbers and scope, including completed627test log. No findings.
- Deferred by dependency: frame/covariance/message conversion, live arrival and reset/quality semantics, disarmed shadow, VIO→EKF2 injection. Previous fly collision,370msdecision andfive-cameraRTF0.873 failures remain.
