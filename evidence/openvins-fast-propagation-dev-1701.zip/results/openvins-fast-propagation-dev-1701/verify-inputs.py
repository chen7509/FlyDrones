import hashlib
import json
from pathlib import Path

base=Path(__file__).resolve().parent
root=base.parents[1]
index=json.loads((root/'evidence/openvins-board-pattern-dev-1701-reviewed.sha256.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(root/index['archive'])==index['archive_sha256']
prefix='results/openvins-board-pattern-dev-1701/'
names=[name for name in index['members'] if any(name.startswith(prefix+p) for p in
       ['episode-v2/','input-v1/','dependencies-v1/config-v2/','replay-v1/states.csv'])]
for name in names:
    assert sha(root/name)==index['members'][name]['sha256'],name
with (base/'verified-inputs.json').open('x') as stream:
    json.dump({'source_archive_sha256':index['archive_sha256'],'verified_files':len(names),
               'members':{name:index['members'][name] for name in names}},stream,indent=2)
print(len(names))
