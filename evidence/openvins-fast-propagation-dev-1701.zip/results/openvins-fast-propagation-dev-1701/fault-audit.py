import copy
import csv
import json
from pathlib import Path

from tools.benchmark.audit_openvins_fast_propagation import audit_records

stage = Path(__file__).resolve().parent
source = stage.parent / 'openvins-board-pattern-dev-1701/input-v1'
raw = [json.loads(line) for line in (stage / 'replay-v1/fast.jsonl').read_text().splitlines()]
with (source / 'frames.csv').open() as stream:
    cameras = [int(r['timestamp_ns']) for r in csv.DictReader(stream)]
with (source / 'imu.csv').open() as stream:
    imu = [int(r['timestamp_us']) * 1000 for r in csv.DictReader(stream)]
start, end = 15_680_000_000, 19_700_000_000
index = next(i for i, r in enumerate(raw) if r['target_ns'] == start)
cases = {}
for name in ['missing_prearm_end', 'future_camera', 'stale_filter', 'nonfinite_velocity',
             'negative_covariance', 'missing_imu_boundary', 'lost_initialization',
             'nonzero_time_offset', 'propagation_failure', 'filter_mutated']:
    rows = copy.deepcopy(raw)
    row = rows[index]
    if name == 'missing_prearm_end':
        rows = [r for r in rows if r['target_ns'] != end]
    elif name == 'future_camera': row['last_camera_ns'] += 100_000_000
    elif name == 'stale_filter': row['filter_time_s'] -= .2
    elif name == 'nonfinite_velocity': row['state13'][7] = float('nan')
    elif name == 'negative_covariance': row['covariance12'][0][0] = -1
    elif name == 'missing_imu_boundary': row['available_imu_ns'] -= 4_000_000
    elif name == 'lost_initialization': row['internal_initialized'] = False
    elif name == 'nonzero_time_offset': row['camera_imu_offset_s'] = .001
    elif name == 'propagation_failure': row.update(success=False, state13=None, covariance12=None)
    elif name == 'filter_mutated': row['filter_unchanged'] = False
    try:
        result = audit_records(rows, cameras, imu, start, end)
        assert not result['prearm_screen_passed'] and not result['eligible_for_px4_fusion'], name
        cases[name] = {'rejected': True, 'mode': 'window_screen_failed'}
    except ValueError as error:
        cases[name] = {'rejected': True, 'mode': 'invalid_stream', 'reason': str(error)}
with (stage / 'fault-audit-v1.json').open('x') as stream:
    json.dump({'scope': 'offline corruptions of in-memory copies; not live sensor fault injection', 'cases': cases}, stream, indent=2)
print(f'{len(cases)} offline fault cases rejected; original JSONL unchanged')
