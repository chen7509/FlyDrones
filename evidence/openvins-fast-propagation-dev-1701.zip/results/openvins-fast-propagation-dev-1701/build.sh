#!/bin/bash
set -euo pipefail
cd /mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility
out=results/openvins-fast-propagation-dev-1701
upstream=/home/yuchen7509/flydrones-upstream/open_vins_vio_init_probe
test ! -e "$out/fast_probe"
test "$(sha256sum "$upstream/ov_msckf/build/libov_msckf_lib.so" | cut -d' ' -f1)" = 532ae57a6a952a0137cc1de291bc47ad556d419c7524fbb23b7a90c00addab5b
g++ -std=c++17 -O2 -DENABLE_ARUCO_TAGS=1 -DROS_AVAILABLE=0 -I"$upstream/ov_msckf/src" -I"$upstream/ov_core/src" -I"$upstream/ov_init/src" -I/usr/include/eigen3 tools/benchmark/openvins_state_probe.cpp -L"$upstream/ov_msckf/build" -Wl,-rpath,"$upstream/ov_msckf/build" -lov_msckf_lib $(pkg-config --cflags --libs opencv4) -lboost_thread -lboost_system -lboost_filesystem -o "$out/fast_probe" > "$out/build.log" 2>&1
{
 git -C "$upstream" rev-parse HEAD
 sha256sum "$out/fast_probe" "$upstream/ov_msckf/build/libov_msckf_lib.so" tools/benchmark/openvins_state_probe.cpp tools/benchmark/openvins_fast_probe.h tools/benchmark/exclusive_probe_output.h
 ldd "$out/fast_probe"
 g++ --version
} > "$out/build-provenance.txt"
