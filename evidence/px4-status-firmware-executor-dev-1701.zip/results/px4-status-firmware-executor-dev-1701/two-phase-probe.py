"""Two real read-only admission snapshots; never dispatch a build."""

import json
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root))
from tools.connectome.run_px4_status_firmware_build import (  # noqa: E402
    audit_two_phase_dispatch,
    collect_admission_facts,
)

profile = json.loads((root / "configs/px4/estimator-status-firmware-build-profile.json").read_text())
first = collect_admission_facts(profile)
second = collect_admission_facts(profile)
decision = audit_two_phase_dispatch(profile, first, second)
print(json.dumps({"first": first, "second": second, "decision": decision},
                 indent=2, sort_keys=True))
raise SystemExit(0 if decision["dispatch_permitted"] else 1)
