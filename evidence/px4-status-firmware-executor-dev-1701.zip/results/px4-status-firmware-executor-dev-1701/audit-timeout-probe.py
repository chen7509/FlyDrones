"""Audit exact timeout-probe evidence as owned-scope cleanup only."""

import hashlib
import json
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root))
from tools.connectome.run_px4_status_firmware_build import audit_owned_scope_cleanup  # noqa: E402

source = root / "results/px4-status-firmware-executor-dev-1701/scope-timeout-probe-v1.json"
probe = json.loads(source.read_text(encoding="utf-8"))


def parse(text):
    return {key.lower().replace("state", "_state").replace("group", "_group"): value
            for key, value in (line.split("=", 1) for line in text.splitlines())}


facts = {
    "unit": probe["unit"],
    "during": parse(probe["during"]["stdout"]),
    "post": parse(probe["post"]["stdout"]),
    "cgroup_members_during": probe["during_members"]["stdout"].splitlines(),
    "cgroup_read_exit": probe["during_members"]["exit"],
    "stop_exit": probe["stop"]["exit"],
    "cgroup_exists_after": probe["cgroup_exists_after"],
    "cgroup_after_test_exit": probe["cgroup_after_test_exit"],
    "launcher_alive_after": probe["launcher_exit"] is None,
}
audit = audit_owned_scope_cleanup(facts, expected_unit=probe["unit"])
print(json.dumps({"probe_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
                  "facts": facts, "audit": audit}, indent=2))
raise SystemExit(0 if audit["owned_scope_released"] and not audit["graceful_scope_exit"] else 1)
