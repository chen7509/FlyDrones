"""Seal selected executor-stage evidence without touching historical attempts."""

import hashlib
import json
import subprocess
import sys
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
here = Path(__file__).resolve().parent
test_log = here / "targeted-final-v2.txt"
ruff_log = here / "ruff-final-v2.txt"
diff_log = here / "diff-check-final-v2.txt"

checks = [
    (test_log, [sys.executable, "-c",
                "import sys,pytest;sys.path.insert(0,'src');raise SystemExit(pytest.main("
                "['-q','tests/connectome_training/test_px4_status_firmware_build.py',"
                "'tests/connectome_training/test_px4_status_firmware.py']))"]),
    (ruff_log, [sys.executable, "-m", "ruff", "check",
                "tools/connectome/run_px4_status_firmware_build.py",
                "tests/connectome_training/test_px4_status_firmware_build.py"]),
    (diff_log, ["git", "diff", "--check"]),
]
for path, command in checks:
    completed = subprocess.run(command, cwd=root, capture_output=True, text=True, timeout=60)
    path.open("x", encoding="utf-8").write(
        json.dumps({"command": command, "exit_code": completed.returncode}, sort_keys=True)
        + "\n" + completed.stdout + completed.stderr
    )
    if completed.returncode:
        raise SystemExit(f"check failed; preserved {path}")

members = [
    "tools/connectome/run_px4_status_firmware_build.py",
    "tests/connectome_training/test_px4_status_firmware_build.py",
    "docs/superpowers/plans/2026-10-12-px4-estimator-status-firmware.md",
    "docs/PX4_STATUS_FIRMWARE_EXECUTOR_PROTOCOL_REPORT.md",
]
members += [str(path.relative_to(root)).replace("\\", "/") for path in sorted(here.iterdir())
            if path.is_file() and path.name != "seal-v1.py"]
members.append(str(Path(__file__).resolve().relative_to(root)).replace("\\", "/"))
archive = root / "evidence/px4-status-firmware-executor-dev-1701.zip"
manifest = {"schema": "flydrones.px4_status_firmware_executor_evidence.v1", "members": {}}
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as output:
    for relative in members:
        content = (root / relative).read_bytes()
        manifest["members"][relative] = {"sha256": hashlib.sha256(content).hexdigest(),
                                          "size": len(content)}
        output.writestr(relative, content)
    output.writestr("manifest.json", json.dumps(manifest, indent=2, sort_keys=True) + "\n")
with zipfile.ZipFile(archive) as sealed:
    if sealed.testzip() is not None:
        raise SystemExit("zip CRC mismatch")
    published = json.loads(sealed.read("manifest.json"))
    if set(sealed.namelist()) != set(published["members"]) | {"manifest.json"}:
        raise SystemExit("zip member set mismatch")
    for relative, record in published["members"].items():
        content = sealed.read(relative)
        if len(content) != record["size"] or hashlib.sha256(content).hexdigest() != record["sha256"]:
            raise SystemExit(f"zip member hash mismatch: {relative}")
print(json.dumps({"archive": str(archive), "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
                  "members": len(manifest["members"]), "crc_and_hash_verified": True}, indent=2))
