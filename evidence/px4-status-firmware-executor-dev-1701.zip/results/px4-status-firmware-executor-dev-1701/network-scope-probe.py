"""Harmless capability probe for a network-denied transient user scope."""

import json
import subprocess

unit = "flydrones-px4-status-network-probe-v1"
prefix = ["wsl.exe", "--distribution", "Ubuntu", "--exec"]
command = prefix + [
    "systemd-run", "--user", "--scope", "--unit=" + unit,
    "--property=MemoryMax=4G", "--property=CPUQuota=100%",
    "--property=IPAddressDeny=any", "python3", "-c", "print('no-network-scope')",
]
run = subprocess.run(command, capture_output=True, text=True, timeout=15)
post = subprocess.run(prefix + ["systemctl", "--user", "show", unit + ".scope",
                                "--property=LoadState,ActiveState,IPAddressDeny"],
                      capture_output=True, text=True, timeout=8)
print(json.dumps({"command": command, "exit": run.returncode,
                  "stdout": run.stdout, "stderr": run.stderr[-1000:],
                  "post_exit": post.returncode, "post_stdout": post.stdout,
                  "post_stderr": post.stderr[-400:]}, indent=2))
