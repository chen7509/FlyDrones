"""Harmless one-second execution of the exact build scope prefix, no make."""

import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root))
from tools.connectome.run_px4_status_firmware_build import build_scope_command  # noqa: E402

unit = "flydrones-px4-status-command-probe-v1"
command = build_scope_command()
command[command.index("--unit=flydrones-px4-status-build-v1")] = "--unit=" + unit
command[-3:] = [
    "python3", "-c",
    "import os; print('probe=' + str(os.getpid())); "
    "print('namespace=' + str(os.environ.get('PX4_UXRCE_DDS_NS'))); "
    "print('git_protocol=' + os.environ['GIT_CONFIG_VALUE_0'])",
]
run = subprocess.run(command, capture_output=True, text=True, timeout=10)
post = subprocess.run(
    ["wsl.exe", "--distribution", "Ubuntu", "--exec", "systemctl", "--user", "show",
     unit + ".scope", "--property=LoadState,ActiveState,ControlGroup"],
    capture_output=True, text=True, timeout=8,
)
print(json.dumps({
    "schema": "flydrones.px4_status_build_command_probe.v1", "unit": unit,
    "command": command, "exit": run.returncode, "stdout": run.stdout,
    "stderr": run.stderr[-800:], "post_exit": post.returncode,
    "post_stdout": post.stdout, "post_stderr": post.stderr[-400:],
    "builder_sha256": hashlib.sha256(
        (root / "tools/connectome/run_px4_status_firmware_build.py").read_bytes()
    ).hexdigest(),
    "build_dispatched": False, "firmware_compiled_verified": False,
}, indent=2))
raise SystemExit(run.returncode)
