"""Harmless user-scope property observation; no PX4 or external network."""

import json
import subprocess
import time

prefix = ["wsl.exe", "--distribution", "Ubuntu", "--exec"]
unit = "flydrones-px4-status-network-probe-v2.scope"
command = prefix + [
    "systemd-run", "--user", "--scope", "--unit=" + unit.removesuffix(".scope"),
    "--property=MemoryMax=4G", "--property=CPUQuota=100%",
    "--property=IPAddressDeny=any", "python3", "-c",
    "import socket,time; s=socket.socket();\n"
    "try: s.connect(('127.0.0.1',9)); print('connected')\n"
    "except OSError as e: print('socket_errno',e.errno)\n"
    "time.sleep(3)",
]
process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
time.sleep(1)
state = subprocess.run(prefix + ["systemctl", "--user", "show", unit,
                                 "--property=LoadState,ActiveState,IPAddressDeny"],
                       capture_output=True, text=True, timeout=10)
stdout, stderr = process.communicate(timeout=10)
print(json.dumps({"command": command, "launcher_exit": process.returncode,
                  "launcher_stdout": stdout.decode(errors="replace"),
                  "launcher_stderr_tail": stderr.decode(errors="replace")[-600:],
                  "active_property_exit": state.returncode,
                  "active_property": state.stdout}, indent=2))
