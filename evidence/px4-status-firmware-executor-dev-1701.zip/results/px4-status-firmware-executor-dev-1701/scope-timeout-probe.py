"""Bounded failure injection against one uniquely owned, harmless WSL scope."""

import json
import subprocess
import time

UNIT = "flydrones-px4-status-timeout-probe-v1.scope"
PREFIX = ["wsl.exe", "--distribution", "Ubuntu", "--exec"]


def call(*args, timeout=8):
    proc = subprocess.run(PREFIX + list(args), capture_output=True, text=True, timeout=timeout)
    return {"exit": proc.returncode, "stdout": proc.stdout.strip()[-600:],
            "stderr": proc.stderr.strip()[-600:]}


pre = call("systemctl", "--user", "show", UNIT,
           "--property=LoadState,ActiveState,ControlGroup")
if "ActiveState=active" in pre["stdout"]:
    raise SystemExit("named scope already active")
script = (
    "import os,signal,subprocess,time;"
    "signal.signal(signal.SIGTERM,signal.SIG_IGN);"
    "child=subprocess.Popen(['python3','-c',"
    "'import os,signal,time;signal.signal(signal.SIGTERM,signal.SIG_IGN);"
    "print(os.getpid(),flush=True);time.sleep(30)']);"
    "print(os.getpid(),child.pid,flush=True);time.sleep(30)"
)
cmd = PREFIX + [
    "systemd-run", "--user", "--scope", "--unit=flydrones-px4-status-timeout-probe-v1",
    "--property=MemoryMax=4G", "--property=CPUQuota=100%",
    "--property=TimeoutStopSec=2s",
    "--working-directory=/home/yuchen7509/px4-status-worktrees/firmware-v1",
    "python3", "-c", script,
]
process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
started = time.monotonic()
try:
    time.sleep(0.7)
    during = call("systemctl", "--user", "show", UNIT,
                  "--property=LoadState,ActiveState,ControlGroup,TimeoutStopUSec")
    groups = [row.partition("=")[2] for row in during["stdout"].splitlines()
              if row.startswith("ControlGroup=")]
    if len(groups) != 1 or not groups[0].endswith(UNIT):
        raise RuntimeError("owned cgroup unverified")
    group_path = "/sys/fs/cgroup" + groups[0]
    during_members = call("cat", group_path + "/cgroup.procs")
    stop = call("systemctl", "--user", "stop", UNIT, timeout=10)
    stdout, stderr = process.communicate(timeout=10)
except Exception:
    call("systemctl", "--user", "kill", "--signal=SIGKILL", UNIT)
    process.kill()
    process.communicate(timeout=8)
    raise
post = call("systemctl", "--user", "show", UNIT,
            "--property=LoadState,ActiveState,ControlGroup")
after_path = call("test", "-e", group_path)
print(json.dumps({
    "schema": "flydrones.px4_status_timeout_scope_probe.v1", "unit": UNIT,
    "pre": pre, "during": during, "during_members": during_members,
    "stop": stop, "post": post, "cgroup_path": group_path,
    "cgroup_exists_after": after_path["exit"] == 0,
    "cgroup_after_test_exit": after_path["exit"],
    "launcher_exit": process.returncode, "launcher_stdout": stdout.strip()[-600:],
    "launcher_stderr": stderr.strip()[-600:],
    "elapsed_s": time.monotonic() - started,
    "build_dispatched": False, "firmware_compiled_verified": False,
}, indent=2))
