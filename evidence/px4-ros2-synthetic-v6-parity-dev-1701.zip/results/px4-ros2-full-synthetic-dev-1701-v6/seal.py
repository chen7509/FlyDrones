"""Seal synthetic v6 inputs, code, result, and verification exactly once."""

from __future__ import annotations

import hashlib
import json
import zipfile
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DESTINATION = ROOT / "evidence/px4-ros2-synthetic-v6-parity-dev-1701.zip"
MEMBERS = (
    "docs/superpowers/specs/2026-10-10-px4-synthetic-sixth-attempt-design.md",
    "docs/superpowers/plans/2026-10-10-px4-synthetic-sixth-attempt.md",
    "docs/PX4_ROS2_SYNTHETIC_V6_PARITY_REPORT.md",
    "tools/connectome/run_full_odometry_synthetic.py",
    "tools/connectome/check_full_odometry_cdr_parity.py",
    "tests/connectome_training/test_full_odometry_synthetic_runner.py",
    "results/px4-ros2-full-synthetic-dev-1701-v5/preflight.json",
    "results/px4-ros2-full-synthetic-dev-1701-v5/result.json",
    "results/px4-ros2-full-synthetic-v6-console.txt",
    "results/px4-ros2-full-synthetic-dev-1701-v6/preflight.json",
    "results/px4-ros2-full-synthetic-dev-1701-v6/launch.json",
    "results/px4-ros2-full-synthetic-dev-1701-v6/result.json",
    "results/px4-ros2-full-synthetic-dev-1701-v6/synthetic-v2.jsonl",
    "results/px4-ros2-full-synthetic-dev-1701-v6/parity.json",
    "results/px4-ros2-full-synthetic-dev-1701-v6/container.log",
    "results/px4-ros2-full-synthetic-dev-1701-v6/publisher.log",
    "results/px4-ros2-full-synthetic-dev-1701-v6/subscriber.log",
    "results/px4-ros2-full-synthetic-dev-1701-v6/audit.py",
    "results/px4-ros2-full-synthetic-dev-1701-v6/audit.json",
    "results/px4-ros2-full-synthetic-dev-1701-v6/targeted-tests.txt",
    "results/px4-ros2-full-synthetic-dev-1701-v6/ruff.txt",
    "results/px4-ros2-full-synthetic-dev-1701-v6/diff-check.txt",
    "results/px4-ros2-full-synthetic-dev-1701-v6/seal.py",
)


def main() -> None:
    if DESTINATION.exists():
        raise FileExistsError(DESTINATION)
    payload = {}
    manifest = {"schema": "flydrones.evidence_manifest.v1", "members": {}}
    for member in MEMBERS:
        path = ROOT / member
        if path.is_symlink() or not path.is_file():
            raise FileNotFoundError(path)
        raw = path.read_bytes()
        payload[member] = raw
        manifest["members"][member] = {
            "sha256": hashlib.sha256(raw).hexdigest(),
            "bytes": len(raw),
            "crc32": f"{zlib.crc32(raw):08x}",
        }
    manifest_raw = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    DESTINATION.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DESTINATION, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for member, raw in payload.items():
            archive.writestr(member, raw)
        archive.writestr("manifest.json", manifest_raw)
    with zipfile.ZipFile(DESTINATION) as archive:
        if archive.testzip() is not None:
            raise ValueError("ZIP CRC failed")
        sealed = json.loads(archive.read("manifest.json"))
        if set(archive.namelist()) != set(MEMBERS) | {"manifest.json"}:
            raise ValueError("ZIP member set changed")
        for member, expected in sealed["members"].items():
            raw = archive.read(member)
            if (len(raw) != expected["bytes"]
                    or hashlib.sha256(raw).hexdigest() != expected["sha256"]
                    or f"{zlib.crc32(raw):08x}" != expected["crc32"]):
                raise ValueError(f"ZIP member changed: {member}")
    print(json.dumps({
        "path": str(DESTINATION),
        "sha256": hashlib.sha256(DESTINATION.read_bytes()).hexdigest(),
        "members": len(MEMBERS) + 1,
        "crc_and_hash_verified": True,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
