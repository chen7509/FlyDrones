"""Recheck sealed synthetic v6 output without rerunning ROS or Docker."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def read(name: str) -> dict:
    return json.loads((HERE / name).read_text(encoding="utf-8"))


def sha(name: str) -> str:
    return hashlib.sha256((HERE / name).read_bytes()).hexdigest()


def main() -> None:
    preflight, launch, result, parity = (
        read(name) for name in ("preflight.json", "launch.json", "result.json", "parity.json")
    )
    rows = [json.loads(row) for row in (HERE / "synthetic-v2.jsonl").read_text(
        encoding="utf-8"
    ).splitlines()]
    assert preflight["free_kib"] >= preflight["minimum_free_kib"] == 900_000
    assert preflight["running_containers"] == preflight["competing_processes"] == []
    assert preflight["build_binary_sha256"] == "31ad3958028660bf4ed468ddcbd25e7d5ca3e994b7729e4538ebe383a46ecf7f"
    assert preflight["installed_message_sha256"] == "a528b3d0b4c1a9083a71b32c367bad71a900e959efd82b9d03a9eb0e99fe6017"
    assert len(rows) == 2 and rows[0]["kind"] == "sample"
    assert rows[1]["kind"] == "finish" and rows[1]["samples"] == 1
    assert rows[1]["status"] == "complete"
    assert sha("synthetic-v2.jsonl") == result["journal_sha256"] == parity["journal_sha256"]
    assert hashlib.sha256(bytes.fromhex(rows[0]["cdr_hex"])).hexdigest() == (
        rows[0]["cdr_sha256"]
    ) == parity["cdr_sha256"]
    assert sha("parity.json") == result["parity_sha256"]
    assert parity["fields_checked"] == 7 and parity["scalar_fields_checked"] == 6
    assert parity["synthetic_only"] is True
    assert result["status"] == "synthetic_passed" and result["docker_exit"] == 0
    assert result["owned_container_remaining"] == ""
    assert result["eligible_for_live_capture"] is False
    args = launch["arguments"]
    assert args[args.index("--cpus") + 1] == "1"
    assert args[args.index("--memory") + 1] == "512m"
    assert args[args.index("--memory-swap") + 1] == "512m"
    assert args[args.index("--network") + 1] == "none"
    print(json.dumps({
        "schema": "flydrones.synthetic_v6_audit.v1",
        "one_complete_sample": True,
        "journal_sha256": sha("synthetic-v2.jsonl"),
        "parity_sha256": sha("parity.json"),
        "live_source_qualified": False,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
