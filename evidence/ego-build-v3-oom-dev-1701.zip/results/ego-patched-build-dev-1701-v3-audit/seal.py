import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

root = Path.cwd()
study = root / 'results/ego-patched-build-dev-1701-v3'
audit = root / 'results/ego-patched-build-dev-1701-v3-audit'
read = lambda name: json.loads((study / name).read_text(encoding='utf-8-sig'))
definition = read('prospective.json')
before = read('admission-v2/parent-before.json')
after = read('admission-v2/parent-after.json')
completion = read('completion.json')
inspect = read('admission-v2/container-inspect-observed.json')[0]
assert before['available_windows_mib'] == 2885
assert read('preflight.json')['available_windows_mib'] == 2848
assert after['outer_exit_code'] == 1
assert completion['docker_exit_code'] == 2
assert completion['container_state'] == 'true 2'
assert completion['committed_image_id'] == ''
assert read('cleanup.json')['remaining_owned_container'] == []
assert inspect['Id'] == '6479e44788f5bd2c7ad2447c6d8b3d6a4a5eb1ac121ed4edd1c7f96a9a5b1fb8'
assert inspect['Image'] == definition['base_image']
assert inspect['HostConfig']['Memory'] == 1536 * 1024 * 1024
assert inspect['HostConfig']['MemorySwap'] == 1536 * 1024 * 1024
assert inspect['HostConfig']['NanoCpus'] == 1000000000
assert inspect['HostConfig']['NetworkMode'] == 'none'
assert inspect['HostConfig']['PidsLimit'] == 128
assert not (study / 'binaries-after.txt').exists()
assert b'cc1plus' in (study / 'admission-v2/compile-processes-observed.txt').read_bytes()
assert b'Killed signal terminated program cc1plus' in (study / 'docker-stderr.txt').read_bytes()
assert b'0 packages finished' in (study / 'docker-stdout.txt').read_bytes()
assert hashlib.sha256((study / 'prospective.json').read_bytes()).hexdigest() == 'cb5f8a4a16731a845a120dafc1fb2005a3d1a4c1eda78abfa802c155a857bb22'
for item in after['inputs']:
    assert item['sha256'] == definition['inputs'][item['path']]
for item in before['inputs']:
    assert item['sha256'] == definition['inputs'][item['path']]
for path, digest in definition['inputs'].items():
    assert hashlib.sha256((root / path).read_bytes()).hexdigest() == digest
files = {p.relative_to(root).as_posix(): p.read_bytes() for p in study.rglob('*') if p.is_file()}
for rel in ['docs/EGO_BUILD_V3_OOM_REPORT.md', 'docs/superpowers/plans/2026-10-13-ego-build-whitespace.md', 'tools/benchmark/ego_causal_build_v3.sh', 'tools/benchmark/ego_causal_readonly_v2.patch', 'results/ego-patched-build-dev-1701-v3-audit/seal.py']:
    files[rel] = (root / rel).read_bytes()
manifest = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in sorted(files.items())}
archive = root / 'evidence/ego-build-v3-oom-dev-1701.zip'
with ZipFile(archive, 'x', ZIP_DEFLATED) as z:
    for name, data in sorted(files.items()):
        z.writestr(name, data)
    z.writestr('manifest.json', json.dumps(manifest, indent=2))
with ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(set(z.namelist()))
    for name, entry in manifest.items():
        data = z.read(name)
        assert len(data) == entry['bytes']
        assert hashlib.sha256(data).hexdigest() == entry['sha256']
        assert data == (root / name).read_bytes()
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
archive.with_suffix('.sha256').open('x').write(digest + '  ' + archive.name + '\n')
record = {'sha256': digest, 'members': len(manifest) + 1, 'bytes': archive.stat().st_size, 'crc_member_hash_current_bytes_verified': True, 'v3_attempted': True, 'cpp_compiler_observed': True, 'docker_oom_killed': True, 'docker_exit': 2, 'outer_exit': 1, 'new_binary_qualified': False, 'teacher_qualified': False, 'kernel_victim_selection_independently_verified': False}
(audit / 'seal.json').open('x').write(json.dumps(record, indent=2))
print(json.dumps(record))
