Adds a bounded causal input scheduler and an explicit raw-Gazebo IMU profile before native online OpenVINS integration. A camera is delivered only after its same-stamp CameraInfo and an actually consumed later IMU are available; clock/session changes, gaps, overflow and stale data fail closed. Per-sample noise and continuous-density candidates remain separate, uncalibrated and unapplied.

Hash-verified PR34 capturev2 retains6753 relevant inputs:6251 IMU deliveries,250 image deliveries and1 final image pending a later IMU. Six synthetic trace faults are refused. The recorded-arrival wait is not native processing or online VIO latency; no estimator, simulation or ODOMETRY was run.

See docs/OPENVINS_CAUSAL_INPUT_REPORT.md and evidence/openvins-causal-input-dev-1701.zip for tests, independent review, failures, source/license records, profile and complete schedule/index. Stacked on PR34. Existing collision/decision latency and five-camera RTF gates remain unchanged.
