import hashlib
import json
from pathlib import Path
import zipfile

stage = Path(__file__).resolve().parent
root = stage.parents[1]
archive = root / 'evidence/openvins-causal-input-dev-1701.zip'
paths = [p for p in stage.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
paths += [root/p for p in ['tools/benchmark/openvins_causal_input.py', 'tools/benchmark/check_openvins_causal_input.py',
    'tests/benchmark/test_openvins_causal_input.py', 'docs/OPENVINS_CAUSAL_INPUT_REPORT.md',
    'docs/superpowers/specs/2026-10-06-openvins-causal-input-design.md',
    'docs/superpowers/plans/2026-10-06-openvins-causal-input.md',
    '.superpowers/sdd/2026-10-06-openvins-causal-input/progress.md',
    '.superpowers/sdd/2026-10-06-openvins-causal-input/task-1-tests.log']]
manifest = {str(p.relative_to(root)).replace('\\','/'): {'sha256':hashlib.sha256(p.read_bytes()).hexdigest(), 'bytes':p.stat().st_size}
            for p in sorted(paths)}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as bundle:
    for name in manifest:
        bundle.write(root/name,name)
    bundle.writestr('SHA256-MANIFEST.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    for name,item in manifest.items():
        assert hashlib.sha256(bundle.read(name)).hexdigest()==item['sha256']
summary={'path':str(archive.relative_to(root)), 'members':len(manifest)+1,'bytes':archive.stat().st_size,
         'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
with archive.with_suffix('.seal.json').open('x') as f:
    json.dump(summary,f,indent=2)
print(json.dumps(summary,indent=2))
