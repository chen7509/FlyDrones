import hashlib
import json
from pathlib import Path

out = Path(__file__).resolve().parent / 'next-native-sources'
out.mkdir(exist_ok=False)
base = Path('/home/yuchen7509/flydrones-upstream/open_vins_vio_init_probe')
files = ['ov_msckf/src/core/VioManagerHelper.cpp', 'ov_msckf/src/core/VioManager.cpp', 'ov_msckf/src/core/VioManager.h']
hashes = {}
for name in files:
    data = (base/name).read_bytes()
    with (out/Path(name).name).open('xb') as f:
        f.write(data)
    hashes[name] = hashlib.sha256(data).hexdigest()
with (out/'hashes.json').open('x') as f:
    json.dump(hashes, f, indent=2)
