import base64
import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[2]
stage = Path(__file__).resolve().parent
dest = stage / 'sources'
dest.mkdir(exist_ok=False)
with zipfile.ZipFile(root / 'evidence/disarmed-sensor-provenance-dev-1701.zip') as z:
    prefix = 'results/disarmed-sensor-provenance-dev-1701/'
    for relative in ['next-source-snapshots/ROS1Visualizer.cpp', 'next-source-snapshots/Propagator.cpp',
                     'next-source-snapshots/kalibr_imu_chain.yaml', 'next-source-snapshots/kalibr_imucam_chain.yaml',
                     'source-snapshots/gazebo-LICENSE', 'producer-v2b-snapshot/10-model.sdf', 'research-provenance.json']:
        with (dest / Path(relative).name).open('xb') as f:
            f.write(z.read(prefix + relative))
for name in ['gaussian.cc', 'imu.cc']:
    with (dest / name).open('xb') as f:
        f.write((stage / name).read_bytes())
license_json = json.loads((stage / 'openvins-license.json').read_text())
with (dest / 'openvins-LICENSE').open('xb') as f:
    f.write(base64.b64decode(license_json['content']))
record = {'upstream_gz_tag': json.loads((stage/'gazebo-tag.json').read_text()),
          'openvins_maintenance': json.loads((stage/'openvins-maintenance.json').read_text()),
          'scope': 'source-tag noise semantics plus prior pinned native OpenVINS; no dependencies or estimator config changed',
          'hashes': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in dest.iterdir()}}
with (stage/'research.json').open('x') as f:
    json.dump(record, f, indent=2)
