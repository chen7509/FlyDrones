"""Seal this stage's existing evidence without changing any source run."""

import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
prefix = "results/depth-physical-development-preflight-dev-1701"
paths = [
    "tools/benchmark/prepare_depth_physical_development.py",
    "tests/benchmark/test_prepare_depth_physical_development.py",
    "docs/superpowers/specs/2026-10-10-depth-physical-development-preflight.md",
    "docs/superpowers/plans/2026-10-10-depth-physical-development-preflight.md",
    "docs/DEPTH_PHYSICAL_DEVELOPMENT_PREFLIGHT_REPORT.md",
]
paths += [str(path.relative_to(root)).replace("\\", "/") for path in sorted((root / prefix).rglob("*")) if path.is_file()]
paths += [str(path.relative_to(root)).replace("\\", "/") for path in sorted((root / "results").glob("depth-physical-development-preflight-dev-1701-*")) if path.is_file()]
paths = sorted(set(paths))
target = root / "evidence/depth-physical-development-preflight-dev-1701.zip"
if target.exists():
    raise FileExistsError(target)
records = []
with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name in paths:
        data = (root / name).read_bytes()
        info = zipfile.ZipInfo(name, (2026, 10, 10, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, data)
        records.append({"name": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    info = zipfile.ZipInfo("evidence-manifest.json", (2026, 10, 10, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    archive.writestr(info, json.dumps({"schema": "stage-evidence-v1", "members": records}, indent=2).encode())
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    for row in records:
        data = archive.read(row["name"])
        assert len(data) == row["bytes"]
        assert hashlib.sha256(data).hexdigest() == row["sha256"]
print(json.dumps({"archive": str(target), "members": len(records) + 1,
                  "sha256": hashlib.sha256(target.read_bytes()).hexdigest()}, sort_keys=True))
