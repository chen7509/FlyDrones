"""Read-only reconstruction of the capture's prebinding required file set."""

import json
import sys
from pathlib import Path

from tools.benchmark import capture_disarmed_sensors as cap
from tools.benchmark.capture_contract import derive_launch_environment
from tools.benchmark.runtime_resource_binding import estimator_inputs

root = Path(__file__).resolve().parents[1]
study = root / "results/depth-physical-development-preflight-dev-1701" / (
    sys.argv[1] if len(sys.argv) > 1 else "study-v3"
)
manifest = json.loads((study / "study-manifest.json").read_text())
binding = json.loads((study / "runtime-binding-v3.json").read_text())
args = cap.parse_capture_args(manifest["command"][2:])
cap.validate_declaration(args, derive_launch_environment(binding))
px4 = Path.home() / "PX4-Autopilot"
build = px4 / "build/px4_sitl_default"
required = [
    build / "bin/px4", build / "rootfs/gz_env.sh", build / "etc/init.d-posix/rcS",
    px4 / "src/modules/simulation/gz_bridge/server.config",
    cap.ROOT / "assets/gazebo/models/x500_benchmark/model.sdf",
    cap.ROOT / "assets/gazebo/models/OakD-Benchmark/model.sdf",
    px4 / "Tools/simulation/gz/models/x500/model.sdf",
    px4 / "Tools/simulation/gz/models/x500_base/model.sdf",
]
required += estimator_inputs(args.shadow_binary, args.shadow_config, args.reference_module)
required += [
    Path(module.__file__).resolve()
    for module in tuple(sys.modules.values())
    if getattr(module, "__file__", None)
    and Path(module.__file__).resolve().is_relative_to(cap.ROOT)
]
known = {path for row in binding["baseline"]["files"] for path in (row["requested"], row["resolved"])}
missing = sorted({str(Path(path).absolute()) for path in required} - known)
print(json.dumps({"required_count": len(required), "missing": missing}, indent=2))
