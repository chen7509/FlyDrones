"""No PX4: unchanged client over private synthetic AF_UNIX, real stdout pipe."""
import hashlib
import json
import os
from pathlib import Path
import select
import shutil
import socket
import subprocess
import tempfile
import time

out = Path(__file__).resolve().parent
sdk = out/'upstream/platforms/posix/src/px4/common/px4_daemon'
binary = out/'client-fixture'
compiler = Path(shutil.which('g++')).resolve()
stdbuf = Path(shutil.which('stdbuf')).resolve()
preload = Path('/usr/libexec/coreutils/libstdbuf.so')
sha = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files = [compiler,stdbuf,preload,Path(__file__),out/'client_fixture.cpp',
         out/'stubs/px4_platform_common/log.h',*[sdk/n for n in ('client.cpp','client.h','sock_protocol.h')]]
before = {str(p):sha(p) for p in files}
command = [str(compiler),'-std=c++17','-O2','-I'+str(out/'stubs'),'-I'+str(sdk),
           str(sdk/'client.cpp'),str(out/'client_fixture.cpp'),'-o',str(binary)]
if binary.exists():raise FileExistsError(binary)
compile_run = subprocess.run(command,capture_output=True,text=True,timeout=30)
with (out/'compile-client.json').open('x') as f:
    json.dump({'command':command,'returncode':compile_run.returncode,'stdout':compile_run.stdout,
      'stderr':compile_run.stderr,'before':before,'compiler':subprocess.check_output([str(compiler),'--version'],text=True),
      'packages':subprocess.check_output(['dpkg-query','-W','coreutils','libc6'],text=True)},f,indent=2)
compile_run.check_returncode()
block = (b'\nTOPIC: timesync_status instance 0 #1\n timesync_status\n'
         b'    timestamp: 102000 (0.000001 seconds ago)\n'
         b'    remote_timestamp: 102000\n    observed_offset: -1000\n'
         b'    estimated_offset: -1000\n    round_trip_time: 2000\n    source_protocol: 0\n\n')
results=[]
for name, unbuffered, payload, trailer in [
    ('default-pipe',False,block,b'\x00\x00'),
    ('unbuffered-pipe',True,block,b'\x00\x00'),
    ('missing-return-trailer',True,block,b''),
    ('truncated-frame-exit-zero',True,block[:-20],b'\x00\x00'),
]:
    folder=out/name
    folder.mkdir()
    with tempfile.TemporaryDirectory(prefix='flyd-listener-') as temporary:
        path=Path(temporary)/'test.sock'
        with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as server:
            server.bind(str(path));server.listen(1);server.settimeout(3)
            env=os.environ.copy();env['FLYDRONES_TEST_SOCKET']=str(path)
            command=([str(stdbuf),'-o0'] if unbuffered else [])+[str(binary)]
            p=subprocess.Popen(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            try:
                with server.accept()[0] as peer:
                    peer.settimeout(3)
                    request=b''
                    while not request or request[-1] not in (0,1):request+=peer.recv(1024)
                    start=time.monotonic_ns();peer.sendall(payload)
                    received=b'';first=None
                    deadline=start+2_050_000_000
                    while len(received)<len(payload):
                        left=(deadline-time.monotonic_ns())/1e9
                        if left<=0 or not select.select([p.stdout],[],[],left)[0]:break
                        chunk=os.read(p.stdout.fileno(),4096)
                        if not chunk:break
                        if first is None:first=time.monotonic_ns()
                        received+=chunk
                    before_exit=time.monotonic_ns()
                    peer.sendall(trailer)
                    peer.shutdown(socket.SHUT_WR)
                    remainder,stderr=p.communicate(timeout=3)
                stdout=received+remainder
                record={'case':name,'unbuffered':unbuffered,'request_hex':request.hex(),
                  'payload_bytes':len(payload),'bytes_before_exit':len(received),
                  'first_byte_after_send_ns':None if first is None else first-start,
                  'held_open_ns':before_exit-start,'returncode':p.returncode,
                  'stdout_matches_payload':stdout==payload,'stderr':stderr.decode(),
                  'actual_px4_or_listener':False,'private_synthetic_socket_only':True}
                with (folder/'stdout.bin').open('xb') as f:f.write(stdout)
                with (folder/'result.json').open('x') as f:json.dump(record,f,indent=2)
                results.append(record)
            finally:
                if p.poll() is None:p.kill();p.wait(timeout=3)
after={str(p):sha(p) for p in files}
summary={'cases':results,'before_after_stable':before==after,'after':after,'binary_sha256':sha(binary),
         'actual_px4':False,'network_odometry':False,'live_listener_qualified':False}
with (out/'client-summary.json').open('x') as f:json.dump(summary,f,indent=2)
assert before==after
assert results[0]['bytes_before_exit']==0 and results[0]['held_open_ns']>=2_000_000_000
assert results[1]['bytes_before_exit']==len(block) and results[1]['returncode']==0
assert results[2]['returncode']!=0 and results[3]['returncode']==0
assert all(r['stdout_matches_payload'] for r in results)
print(json.dumps([{k:r[k] for k in ('case','bytes_before_exit','returncode','first_byte_after_send_ns')} for r in results]))
