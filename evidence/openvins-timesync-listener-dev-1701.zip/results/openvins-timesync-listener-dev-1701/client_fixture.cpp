// Unchanged client.cpp linked with explicit private-path/log-only substitutes.
#include <cstdlib>
#include <string>
#include "client.h"
namespace px4_daemon {
std::string get_socket_path(int) {
    const char *path = std::getenv("FLYDRONES_TEST_SOCKET");
    if (!path || std::string(path).find("/tmp/flyd-listener-") != 0) std::abort();
    return path;
}
}
int main() {
    px4_daemon::Client client(8);
    const char *args[] = {"listener", "timesync_status", "-i", "0", "-n", "2", "-r", "0"};
    return client.process_args(8, args);
}
