# Next: compose a bounded cold/exclusive-channel bootstrap

Read installed/fixed client/server/raw-log and prior listener/DeviceNode sources
already sealed, not another SDK inventory. No network ODOMETRY/stream change or
PX4 launch is authorized by the completed byte decoder.

1. Define one prospective PX4 instance/lifecycle identity and explicitly selected
   MAVLink channel. Inspect fixed startup and MAVLink routing configuration to
   determine whether another peer could update the same MavlinkTimesync filter.
   source_protocol0, packet sender targeting and a new companion do not prove
   exclusive or cold state; no invented wire nonce or generation information.
2. Bootstrap first reserved reply before explicit-instance CLI can read a prior
   publication. Withhold other replies; require matching first complete status.
   Never-published/race/timeout/partial/diagnostic is refusal, not blind restart.
3. Future CLI wrapper needs pinned stdbuf/libstdbuf and selected runtime mapping,
   explicit non-PTY stdout, bounded raw-chunk journaling, stderr/exit/lifecycle
   checks, and decoder+observer failure composed into the one-reply gate. Existing
   code supplies none of the real wire/process adapter automatically.
4. Compose offline interval transaction with fresh bounded ACK/query adapter;
   no ACK command nonce exists. Lost ACK and cleanup evidence remain distinct.
   Preserve first primary failure and actual restore status.
5. Re-evaluate startup budget with actual owned schedules before a physical study:
   500 accepted samples,8s readiness,25s total,2s watchdogs unchanged.100Hz setting
   cannot itself qualify rate. If these are infeasible on current host, retain
   refusal/platform limitation and continue independent authorized work.

Native client fixture only observed forwarding of handwritten status text over a
private synthetic AF_UNIX server. It did not run uORB, a real daemon or listener.
Four fixture commands requested2 but supplied1; decoder refuses complete-stream
qualification for all, despite a successful first unbuffered frame match. Do not
rewrite this as a successful two-record listener run or actual latency result.
