"""Fixed synthetic-client captures to real decoder/observer, no client rerun."""
import hashlib
import json
import sys
from pathlib import Path

out = Path(__file__).resolve().parent
root = out.parents[1]
sys.path.insert(0,str(root))
from tools.benchmark.openvins_timesync_listener import TimesyncListenerDecoder
from tools.benchmark.openvins_timesync_observer import SerialTimesyncObserver

results=[]
for row in json.loads((out/'client-summary.json').read_text())['cases']:
    raw=(out/row['case']/'stdout.bin').read_bytes()
    decoder=TimesyncListenerDecoder(0,2,0)  # actual fixture requested -n 2
    observer=SerialTimesyncObserver('synthetic-client-'+row['case'],0)
    observer.reserve_reply(100000000,102000000,0)
    now=row['held_open_ns']
    decoded=[]; observations=[]; refusal=None
    try:
        decoded=decoder.feed(raw,now)
        for status in decoded:observations.append(observer.observe_status(status,now))
        decoder.finish(now+1,row['returncode'])
    except ValueError as exc:refusal=str(exc)
    result={'case':row['case'],'stdout_sha256':hashlib.sha256(raw).hexdigest(),
       'observed_feed_ns':now,'synthetic_fixture_time_origin':True,
       'decoded_records':decoded,'model_observations':observations,'refusal':refusal,
       'requested_records':2,'supplied_frames':1,'complete_stream_qualified':False,
       'live_listener_qualified':False,'fusion_qualified':False}
    results.append(result)
    assert refusal is not None
assert 'timeout' in results[0]['refusal']
assert len(results[1]['decoded_records'])==1 and results[1]['model_observations'][0]['accepted']
assert 'premature EOF' in results[1]['refusal']
assert 'nonzero' in results[2]['refusal']
assert not results[3]['decoded_records']
source=root/'tools/benchmark/openvins_timesync_listener.py'
with (out/'capture-adaptation.json').open('x') as f:
    json.dump({'cases':results,'decoder_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
               'native_client_not_reexecuted':True},f,indent=2)
print('Four retained captures correctly refuse full completion; unbuffered first frame matches observer')
