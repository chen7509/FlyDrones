#pragma once
#include <cstdio>
#define PX4_ERR(fmt, ...) fprintf(stderr, fmt "\n", ##__VA_ARGS__)
