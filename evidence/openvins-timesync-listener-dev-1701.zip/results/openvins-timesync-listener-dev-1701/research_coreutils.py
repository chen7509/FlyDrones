import hashlib
import json
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

out=Path(__file__).resolve().parent
entries=[]
for name in ('stdbuf.c','libstdbuf.c'):
    url=f'https://raw.githubusercontent.com/coreutils/coreutils/v9.4/src/{name}'
    with urllib.request.urlopen(url,timeout=25) as response:data=response.read()
    with (out/name).open('xb') as f:f.write(data)
    entries.append({'url':url,'name':name,'sha256':hashlib.sha256(data).hexdigest()})
request=urllib.request.Request('https://api.github.com/repos/coreutils/coreutils',headers={'User-Agent':'FlyDrones-readonly-research'})
with urllib.request.urlopen(request,timeout=25) as response:metadata=json.load(response)
copyright=Path('/usr/share/doc/coreutils/copyright').read_bytes()
with (out/'coreutils-copyright.txt').open('xb') as f:f.write(copyright)
with (out/'coreutils-research.json').open('x') as f:
    json.dump({'observed_utc':datetime.now(timezone.utc).isoformat(),'sources':entries,
     'metadata':{k:metadata.get(k) for k in ('html_url','archived','pushed_at','updated_at','license')},
     'installed_copyright_sha256':hashlib.sha256(copyright).hexdigest(),
     'install_patch_equivalence_proven':False,
     'official_manual_fetch':'web tool GNU manual timeout; fixed primary source fallback retained'},f,indent=2)
print('Fixed coreutils source, installed license and repository metadata retained')
