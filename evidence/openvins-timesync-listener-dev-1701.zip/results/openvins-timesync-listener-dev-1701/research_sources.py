"""Fetch fixed primary source and compare selected installed copies, without PX4."""
import difflib
import hashlib
import json
import urllib.request
from pathlib import Path

out = Path(__file__).resolve().parent
installed = Path('/home/yuchen7509/PX4-Autopilot')
pin = 'd6f12ad1c4f70ad3230afd7d86e971421e02fef4'
paths = [
 'platforms/common/uORB/uORB.cpp',
 'platforms/common/px4_log.cpp',
 'platforms/common/include/px4_platform_common/log.h',
 'platforms/posix/src/px4/common/px4_daemon/client.cpp',
 'platforms/posix/src/px4/common/px4_daemon/client.h',
 'platforms/posix/src/px4/common/px4_daemon/sock_protocol.h',
 'platforms/posix/src/px4/common/px4_daemon/server.cpp',
]
sha = lambda b: hashlib.sha256(b).hexdigest()
records = []
for path in paths:
    url = f'https://raw.githubusercontent.com/PX4/PX4-Autopilot/{pin}/{path}'
    local = (installed/path).read_bytes()
    with urllib.request.urlopen(url, timeout=25) as response:
        remote = response.read()
    for folder,data in [('installed',local), ('upstream',remote)]:
        target = out/folder/path
        target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as f:f.write(data)
    records.append({'path':path,'url':url,'installed_sha256':sha(local),
                    'upstream_sha256':sha(remote),'equal':local==remote})
    if local != remote:
        diff = ''.join(difflib.unified_diff(remote.decode().splitlines(True),local.decode().splitlines(True),fromfile='upstream',tofile='installed'))
        with (out/(Path(path).name+'.diff')).open('x') as f:f.write(diff)
with (out/'source-comparison.json').open('x') as f:json.dump(records,f,indent=2)
print(json.dumps([{'path':r['path'],'equal':r['equal']} for r in records]))
