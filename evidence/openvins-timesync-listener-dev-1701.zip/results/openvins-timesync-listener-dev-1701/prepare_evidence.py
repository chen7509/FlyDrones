import hashlib
import json
from pathlib import Path

out=Path(__file__).resolve().parent
root=out.parents[1]
sha=lambda data:hashlib.sha256(data).hexdigest()
old=root/'results/openvins-timesync-observer-dev-1701/installed'
paths=[
 'src/systemcmds/topic_listener/listener_main.cpp',
 'src/systemcmds/topic_listener/topic_listener.hpp',
 'platforms/common/uORB/uORBDeviceNode.cpp',
 'platforms/common/uORB/Subscription.hpp',
 'platforms/posix/src/px4/common/main.cpp',
 'build/px4_sitl_default/msg/topics_sources/timesync_status.cpp',
]
records=[]
for name in paths:
    data=(old/name).read_bytes()
    target=out/'reused'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as f:f.write(data)
    records.append({'from':str((old/name).relative_to(root)), 'sha256':sha(data)})
header=Path('/home/yuchen7509/PX4-Autopilot/build/px4_sitl_default/uORB/topics/timesync_status.h')
data=header.read_bytes()
with (out/'installed-timesync_status.h').open('xb') as f:f.write(data)
records.append({'from':str(header),'sha256':sha(data),'installed_generated_only':True})
with (out/'reused-source-provenance.json').open('x') as f:json.dump(records,f,indent=2)
module=root/'tools/benchmark/openvins_timesync_listener.py'
current=module.read_bytes()
guard=b'        if self._count == self._expected and self._partial:\n            self._fail("trailing bytes after expected records")\n'
assert current.count(guard)==1
old_bytes=current.replace(guard,b'')
expected=json.loads((out/'capture-adaptation.json').read_text())['decoder_sha256']
assert sha(old_bytes)==expected
with (out/'adaptation-producer-decoder.py').open('xb') as f:f.write(old_bytes)
with (out/'producer-note.json').open('x') as f:
    json.dump({'adaptation_producer_sha256':expected,'final_sha256':sha(current),
      'reconstructed_after_run_from_final_minus_guard':True,'not_contemporaneous_source_copy':True,
      'matches_retained_run_hash':True,'native_client_not_reexecuted':True},f,indent=2)
print('Reused source and pre-review adaptation producer preserved with hash checks')
