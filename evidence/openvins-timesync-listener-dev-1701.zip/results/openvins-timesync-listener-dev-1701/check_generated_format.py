"""Installed generated field evidence; no PX4 or decompressor invocation."""
import hashlib
import json
import re
from pathlib import Path

out=Path(__file__).resolve().parent
path=Path('/home/yuchen7509/PX4-Autopilot/build/px4_sitl_default/uORB/topics/uORBMessageFieldsGenerated.hpp')
data=path.read_bytes()
fields=re.findall(r'"([^"\n]*remote_timestamp[^"\n]*)"',data.decode())
assert len(fields)==1 and fields[0].endswith(r'\206[3] _padding0;')
with (out/'installed-uORBMessageFieldsGenerated.hpp').open('xb') as f:f.write(data)
with (out/'generated-format-check.json').open('x') as f:
    json.dump({'path':str(path),'sha256':hashlib.sha256(data).hexdigest(),
     'unique_remote_timestamp_format':fields[0],'includes_padding':True,
     'installed_generated_only':True,'actual_uorb_render':False},f,indent=2)
print(fields[0])
