"""Read-only checks plus one exclusive audit output for this correction."""

import hashlib
import json
from pathlib import Path
import zipfile


ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent


def digest(data):
    return hashlib.sha256(data).hexdigest()


def load(name):
    return json.loads((OUT / name).read_text(encoding="utf-8-sig"))


def main():
    failures = []

    def check(ok, reason):
        if not ok:
            failures.append(reason)

    research = load("research.json")
    old_zip = ROOT / research["old_archive"]["path"]
    check(digest(old_zip.read_bytes()) == research["old_archive"]["sha256"], "old_archive_changed")
    old_path = ROOT / research["old_preflight"]["path"]
    check(digest(old_path.read_bytes()) == research["old_preflight"]["sha256"], "old_preflight_changed")
    with zipfile.ZipFile(old_zip) as archive:
        check(archive.testzip() is None, "old_archive_crc")
        for ref in load("retained-input-members.json"):
            data = (OUT / ref["copy"]).read_bytes()
            check(data == archive.read(ref["member"]), "retained_member:" + ref["copy"])
            check(digest(data) == ref["sha256"] and len(data) == ref["bytes"], "input_identity:" + ref["copy"])

    preflight = load("preflight.json")
    for ref in preflight["implementation"]["files"]:
        data = Path(ref["path"]).read_bytes()
        check(digest(data) == ref["sha256"] and len(data) == ref["bytes"], "implementation:" + ref["path"])
    old = json.loads(old_path.read_text(encoding="utf8"))
    for key in ("resources", "baseline", "source_ulog", "endpoint", "receiver_only_parameters", "timesync", "ulog"):
        check(preflight[key] == old[key], "scope_drift:" + key)
    for key in ("network_odometry", "px4_parameter_access", "physical_destination_present", "ekf2_fusion", "arming"):
        check(preflight[key] is False, "side_effect:" + key)
    for ref in load("source-manifest.json"):
        data = (OUT / ref["file"]).read_bytes()
        check(digest(data) == ref["sha256"] and len(data) == ref["bytes"], "source_identity:" + ref["file"])
    for case in load("synthetic-transaction-events.json"):
        result = case["result"]
        check(result["qualified"] is False, "false_qualification:" + case["fault"])
        check(result["baseline"] == result["final_values"], "restore_failed:" + case["fault"])
        check(result["rollback_failures"] == [], "rollback_error:" + case["fault"])
        check(case["writes"][-2:] == [["EKF2_EV_DELAY", 0], ["EKF2_EV_QMIN", 0]], "reverse_attempt_order")
    for filename, expected in (
        ("red.txt", "11 failed"),
        ("review-red.txt", "1 failed"),
        ("review-green.txt", "33 passed"),
        ("full-tests-final.txt", "1979 passed, 3 skipped, 2 warnings"),
        ("ruff-final.txt", "All checks passed!"),
    ):
        check(expected in (OUT / filename).read_text(encoding="utf-8-sig"), "test_log:" + filename)
    result = {
        "schema": "openvins-parameter-rollback-correction-audit-v1",
        "failures": failures,
        "synthetic_rollback_correction_qualified": not failures,
        "implementation_commit": preflight["implementation"]["commit"],
        "superseded_preflight": research["old_preflight"],
        "physical_study": False,
        "network_odometry": False,
        "live_parameter_access": False,
        "ekf2_fusion": False,
        "arming": False,
        "task5_authorized": False,
    }
    with (OUT / "terminal-audit.json").open("x", encoding="utf8") as f:
        json.dump(result, f, indent=2)
    print(json.dumps(result, indent=2))
    return 2 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
