"""Seal one synthetic, explicitly unattested EGO bridge byte-journal stage."""

from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
names = [
    "tools/benchmark/ego_node.py",
    "tools/benchmark/ego_bridge_cdr_journal.py",
    "tools/benchmark/ego_bridge_cdr_audit.py",
    "tests/benchmark/test_ego_bridge_cdr_journal.py",
    "tests/benchmark/test_ego_bridge_cdr_audit.py",
    "tests/benchmark/test_ego_wire_observation.py",
    "docs/EGO_BRIDGE_CDR_JOURNAL_REPORT.md",
    "docs/superpowers/specs/2026-10-10-ego-causal-provenance-design.md",
    "docs/superpowers/plans/2026-10-10-ego-causal-provenance.md",
    "results/ego-bridge-cdr-journal-dev-1701/targeted-tests.txt",
    "results/ego-bridge-cdr-journal-dev-1701/ruff.txt",
    "results/ego-bridge-cdr-journal-dev-1701/diff-check.txt",
    "results/ego-bridge-cdr-journal-dev-1701/seal.py",
]
target = root / "evidence/ego-bridge-cdr-journal-dev-1701.zip"
manifest = {
    "stage": "synthetic_optin_bridge_byte_journal_only",
    "ros_runtime_verified": False,
    "source_attested": False,
    "teacher_qualified": False,
    "members": {},
}
with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED) as archive:
    for name in names:
        payload = (root / name).read_bytes()
        archive.writestr(name, payload)
        manifest["members"][name] = {
            "size": len(payload),
            "sha256": hashlib.sha256(payload).hexdigest(),
        }
    archive.writestr("manifest.json", json.dumps(manifest, sort_keys=True, indent=2) + "\n")
with zipfile.ZipFile(target) as archive:
    if archive.testzip() is not None:
        raise RuntimeError("ZIP CRC failure")
    for name, entry in manifest["members"].items():
        if hashlib.sha256(archive.read(name)).hexdigest() != entry["sha256"]:
            raise RuntimeError(f"member mismatch: {name}")
print(target)
print(hashlib.sha256(target.read_bytes()).hexdigest())
print(len(names) + 1)
