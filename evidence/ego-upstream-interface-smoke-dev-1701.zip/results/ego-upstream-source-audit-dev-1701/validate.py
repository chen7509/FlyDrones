"""Check the bounded EGO-Swarm source and ROS topic probe evidence."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
source_path = HERE / "pinned-source-audit-v2.json"
probe_path = HERE / "ros-topics-probe.txt"
source = json.loads(source_path.read_text(encoding="utf-8"))
probe = probe_path.read_text(encoding="utf-8")

assert source["commit"] == "23a8d5a191711dd65633df689bd00f55d4dea8f9"
assert source["tree_truncated"] is False
files = {row["path"]: row for row in source["files"]}
assert len(files) == 4
grid = files["src/planner/plan_env/src/grid_map.cpp"]["selected_lines"]
assert any("TYPE_32FC1" in row["text"] for row in grid)
assert any("convertTo" in row["text"] and "CV_16UC1" in row["text"] for row in grid)
traj = files["src/planner/plan_manage/src/traj_server.cpp"]["selected_lines"]
assert any('"/position_cmd"' in row["text"] for row in traj)
for expected in (
    "/benchmark/ego/position_cmd [quadrotor_msgs/msg/PositionCommand]",
    "/benchmark/ego/depth [sensor_msgs/msg/Image]",
    "/benchmark/ego/camera_pose [geometry_msgs/msg/PoseStamped]",
    "/benchmark/ego/odom [nav_msgs/msg/Odometry]",
    "/drone_0_ego_planner_node",
    "/drone_0_traj_server",
    "[Traj server]: ready.",
):
    assert any(expected in line for line in probe.splitlines()), expected


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


result = {
    "upstream_commit": source["commit"],
    "source_audit_sha256": sha256(source_path),
    "ros_probe_sha256": sha256(probe_path),
    "launch_sha256": sha256(ROOT / "tools/benchmark/ego.launch.py"),
    "bridge_sha256": sha256(ROOT / "tools/benchmark/ego_node.py"),
    "interface_startup_verified": True,
    "depth_32fc1_upstream_conversion_source_verified": True,
    "trajectory_generated": False,
    "px4_gazebo_run": False,
    "teacher_fairness_qualified": False,
}
with (HERE / "validation.json").open("x", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps(result, sort_keys=True))
