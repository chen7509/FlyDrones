"""Read pinned upstream EGO sources without building or running the planner."""

import base64
import hashlib
import json
import re
import subprocess
from pathlib import Path

COMMIT = "23a8d5a191711dd65633df689bd00f55d4dea8f9"
REPO = "ZJU-FAST-Lab/ego-planner-swarm"
TARGETS = (
    "src/planner/plan_manage/src/ego_replan_fsm.cpp",
    "src/planner/plan_manage/src/traj_server.cpp",
    "src/planner/plan_env/src/grid_map.cpp",
    "src/planner/plan_manage/launch/single_run_in_sim.launch.py",
)
PATTERN = re.compile(
    r"odom_world|grid_map/(odom|pose|depth|cloud)|planning/bspline|"
    r"position_cmd|traj_start_trigger|create_subscription|create_publisher|"
    r"traj_server/time_forward|use_sim_time|depth_filter|pose_type|"
    r"TYPE_32FC1|convertTo|k_depth_scaling_factor_",
    re.IGNORECASE,
)


def api(path):
    return json.loads(subprocess.check_output(["gh", "api", path]))


tree = api(f"repos/{REPO}/git/trees/{COMMIT}?recursive=1")
by_path = {row["path"]: row for row in tree["tree"]}
if tree.get("truncated") or any(path not in by_path for path in TARGETS):
    raise ValueError("pinned upstream tree incomplete")
records = []
for path in TARGETS:
    row = by_path[path]
    if row["type"] != "blob":
        raise ValueError("selected upstream item is not a file")
    blob = api(f"repos/{REPO}/git/blobs/{row['sha']}")
    if blob["encoding"] != "base64" or blob["sha"] != row["sha"]:
        raise ValueError("upstream blob identity differs")
    raw = base64.b64decode("".join(blob["content"].split()), validate=True)
    lines = raw.decode("utf8").splitlines()
    selected = [
        {"line": index, "text": line.strip()}
        for index, line in enumerate(lines, 1)
        if PATTERN.search(line)
    ]
    records.append({
        "path": path,
        "git_blob_sha1": row["sha"],
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "selected_lines": selected,
    })
result = {
    "repository": f"https://github.com/{REPO}.git",
    "commit": COMMIT,
    "tree_truncated": False,
    "read_only": True,
    "planner_executed": False,
    "files": records,
}
output = Path(__file__).with_name("pinned-source-audit-v2.json")
with output.open("x", encoding="utf8") as stream:
    json.dump(result, stream, indent=2, ensure_ascii=False)
    stream.write("\n")
print(json.dumps({"commit": COMMIT, "files": len(records),
                  "matching_lines": sum(len(row["selected_lines"]) for row in records)}))
