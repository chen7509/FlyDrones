"""Seal this bounded source and ROS topic check without overwriting evidence."""

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
ARCHIVE = ROOT / "evidence/ego-upstream-interface-smoke-dev-1701.zip"
FILES = (
    ROOT / "docs/EGO_UPSTREAM_INTERFACE_SMOKE_REPORT.md",
    HERE / "inspect.py",
    HERE / "pinned-source-audit.json",
    HERE / "pinned-source-audit-v2.json",
    HERE / "ros-topics-probe.txt",
    HERE / "validate.py",
    HERE / "validation.json",
    HERE / "seal.py",
)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


entries = {}
for path in FILES:
    content = path.read_bytes()
    entries[path.relative_to(ROOT).as_posix()] = {
        "bytes": len(content),
        "sha256": digest(content),
    }
manifest = json.dumps({"members": entries}, indent=2).encode("utf-8") + b"\n"
ARCHIVE.parent.mkdir(exist_ok=True)
with ARCHIVE.open("xb") as target:
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in FILES:
            archive.write(path, path.relative_to(ROOT).as_posix())
        archive.writestr("manifest.json", manifest)

with zipfile.ZipFile(ARCHIVE) as archive:
    assert archive.testzip() is None
    sealed = json.loads(archive.read("manifest.json"))
    assert sealed["members"] == entries
    for name, metadata in entries.items():
        payload = archive.read(name)
        assert len(payload) == metadata["bytes"]
        assert digest(payload) == metadata["sha256"]

print(json.dumps({"archive": str(ARCHIVE), "bytes": ARCHIVE.stat().st_size,
                  "sha256": digest(ARCHIVE.read_bytes()),
                  "members": len(entries) + 1}, sort_keys=True))
