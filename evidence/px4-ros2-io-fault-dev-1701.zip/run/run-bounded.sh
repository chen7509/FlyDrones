#!/usr/bin/env bash
source /opt/ros/humble/setup.bash
source /workspace/install/setup.bash
set -u
export RMW_IMPLEMENTATION=rmw_cyclonedds_cpp
export ROS_DOMAIN_ID=219
export ROS_HOME=/fault/ros-home
export HOME=/fault/home
mkdir -p "$ROS_HOME" "$HOME"
gcc -O2 -shared -fPIC -o /fault/libjournal_fault.so /fault/journal_fault.c -ldl
sha256sum /fault/libjournal_fault.so > /fault/shim.sha256
binary=/workspace/install/flydrones_px4_ros2_source/lib/flydrones_px4_ros2_source/px4_odometry_source
sha256sum "$binary" > /fault/subscriber.sha256
for mode in normal partial_then_eio fsync_eio close_eio; do
  mkdir -p "/fault/$mode" "/fault/roslog-$mode"
  export ROS_LOG_DIR="/fault/roslog-$mode"
  if [[ "$mode" == normal ]]; then
    timeout 15s "$binary" "/fault/$mode/source.jsonl" "io-fault-$mode" 1 8 > "/fault/$mode/subscriber.log" 2>&1
  else
    timeout 15s env FAULT_MODE="$mode" FAULT_TARGET="/fault/$mode/source.jsonl" LD_PRELOAD=/fault/libjournal_fault.so \
      "$binary" "/fault/$mode/source.jsonl" "io-fault-$mode" 1 8 > "/fault/$mode/subscriber.log" 2>&1
  fi
  printf '%s\n' "$?" > "/fault/$mode/subscriber.exit"
done
