"""Read-only audit of the predeclared local ROS source-journal I/O faults."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from flydrones.connectome_training.px4_ros2_source_journal import audit_source_journal

root = Path(__file__).resolve().parent
profile = json.loads((root / "profile.json").read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert profile["schema"] == "flydrones.px4_ros2_journal_io_fault.v1"
assert sha256(root / "journal_fault.c") == profile["shim_source_sha256"]
assert sha256(root / "run-bounded.sh") == profile["runner_sha256"]
assert (root / "subscriber.sha256").read_text().split()[0] == profile["subscriber_sha256"]
assert (root / "shim.sha256").read_text().split()[0] == sha256(root / "libjournal_fault.so")
assert (root / "docker.exit").read_text().strip() == "0"

expected_errors = {
    "partial_then_eio": "journal write failed",
    "fsync_eio": "journal fsync failed",
    "close_eio": "journal close failed",
}
results = {}
for mode, expected_exit in profile["expected_exits"].items():
    mode_dir = root / mode
    exit_code = int((mode_dir / "subscriber.exit").read_text().strip())
    assert exit_code == expected_exit, (mode, exit_code, expected_exit)
    log = (mode_dir / "subscriber.log").read_text(encoding="utf-8")
    if mode in expected_errors:
        assert expected_errors[mode] in log, (mode, log)
    else:
        assert "PX4 source journal failed" not in log

    journal = mode_dir / "source.jsonl"
    if mode == "partial_then_eio":
        try:
            audit_source_journal(journal)
        except ValueError as exc:
            assert "truncated or oversized" in str(exc), str(exc)
            audit_result = "rejected_truncated_journal"
        else:
            raise AssertionError("partial write unexpectedly audited")
    else:
        audit = audit_source_journal(journal)
        assert audit.run_id == f"io-fault-{mode}"
        assert audit.samples == 0
        assert not audit.completed
        assert not audit.eligible_for_live_capture
        assert "writer_exit_and_durability_not_verified" in audit.missing_qualification
        audit_result = "parsed_failed_no_messages_ineligible"
    results[mode] = {
        "subscriber_exit": exit_code,
        "journal_sha256": sha256(journal),
        "journal_bytes": journal.stat().st_size,
        "audit": audit_result,
        "source_samples": 0,
        "live_capture_eligible": False,
    }

output = {
    "schema": "flydrones.px4_ros2_journal_io_fault_audit.v1",
    "run_id": profile["run_id"],
    "harness_exit": 0,
    "cases": results,
    "scope": "local_no_publisher_syscall_fault_injection_only",
    "px4_or_ekf2_validated": False,
}
print(json.dumps(output, indent=2, sort_keys=True))
