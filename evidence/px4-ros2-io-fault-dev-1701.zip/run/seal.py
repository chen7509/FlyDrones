"""Seal the local no-publisher I/O-fault observations without replacing old evidence."""

from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path


repo = Path(__file__).resolve().parents[2]
run = Path(__file__).resolve().parent
destination = repo / "evidence" / "px4-ros2-io-fault-dev-1701.zip"
if destination.exists():
    raise SystemExit(f"evidence already exists: {destination}")

members: dict[str, bytes] = {}
for path in sorted(run.rglob("*")):
    if path.is_file():
        members[f"run/{path.relative_to(run).as_posix()}"] = path.read_bytes()
for relative in (
    "docs/PX4_ROS2_IO_FAULT_REPORT.md",
    "docs/superpowers/plans/2026-10-10-px4-ros2-source-journal.md",
    "src/flydrones/connectome_training/px4_ros2_source_journal.py",
    "tools/connectome/px4_ros2_source/px4_odometry_source.cpp",
    "results/px4-ros2-build-dev-1701/install/flydrones_px4_ros2_source/lib/flydrones_px4_ros2_source/px4_odometry_source",
):
    members[f"reference/{relative}"] = (repo / relative).read_bytes()

manifest = {
    "schema": "flydrones.px4_ros2_io_fault_evidence.v1",
    "run_id": "px4-ros2-io-fault-dev-1701",
    "members": {
        name: {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}
        for name, data in sorted(members.items())
    },
    "live_capture_eligible": False,
}
members["MANIFEST.json"] = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
destination.parent.mkdir(parents=True, exist_ok=True)
with destination.open("xb") as stream, zipfile.ZipFile(
    stream, mode="w", compression=zipfile.ZIP_DEFLATED
) as archive:
    for name, data in sorted(members.items()):
        archive.writestr(name, data)

with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(members)
    retained = json.loads(archive.read("MANIFEST.json"))
    for name, record in retained["members"].items():
        data = archive.read(name)
        assert len(data) == record["bytes"]
        assert hashlib.sha256(data).hexdigest() == record["sha256"]

digest = hashlib.sha256(destination.read_bytes()).hexdigest()
(run / "archive.sha256").write_text(f"{digest}  {destination.name}\n", encoding="ascii")
print(json.dumps({"archive": str(destination), "sha256": digest, "members": len(members)}))
