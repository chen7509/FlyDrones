import hashlib
import json
from pathlib import Path
import urllib.request

OUT = Path(__file__).resolve().parent
PIN = 'd6f12ad1c4f70ad3230afd7d86e971421e02fef4'
urls = {
    'GZBridge.cpp': f'https://raw.githubusercontent.com/PX4/PX4-Autopilot/{PIN}/src/modules/simulation/gz_bridge/GZBridge.cpp',
    'drv_hrt.cpp': f'https://raw.githubusercontent.com/PX4/PX4-Autopilot/{PIN}/platforms/posix/src/px4/common/drv_hrt.cpp',
    'UpdateInfo.html': 'https://gazebosim.org/api/sim/8/structgz_1_1sim_1_1UpdateInfo.html',
    'px4-metadata.json': 'https://api.github.com/repos/PX4/PX4-Autopilot',
    'gazebo-metadata.json': 'https://api.github.com/repos/gazebosim/gz-sim',
}
rows = []
for name, url in urls.items():
    request = urllib.request.Request(url, headers={'User-Agent': 'FlyDrones-clock-research'})
    data = urllib.request.urlopen(request, timeout=30).read()
    with (OUT / name).open('xb') as stream:
        stream.write(data)
    old = OUT.parent / 'journaled-heartbeat-lane-dev-1701' / 'sources' / name
    rows.append(dict(name=name, url=url, sha256=hashlib.sha256(data).hexdigest(),
                     bytes=len(data), previous_equal=old.read_bytes() == data if old.exists() else None))
with (OUT / 'research-manifest.json').open('x') as stream:
    json.dump(rows, stream, indent=2)
print(json.dumps(rows, indent=2))
