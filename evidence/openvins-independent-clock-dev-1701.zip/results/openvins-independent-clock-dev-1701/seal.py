import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).resolve().parent
ARCHIVE = ROOT / 'evidence/openvins-independent-clock-dev-1701.zip'
META = ROOT / 'evidence/openvins-independent-clock-seal.json'
sha = lambda data: hashlib.sha256(data).hexdigest()
previous = ROOT / 'evidence/openvins-datagram-receive-dev-1701.zip'
assert sha(previous.read_bytes()) == 'ce664a6c131bcfe2ba35abce5bf710641691a1d9061f3f3c1e0bb4732bca8cb0'
extra = [
    'tools/benchmark/openvins_simulation_clock.py',
    'tests/benchmark/test_openvins_simulation_clock.py',
    'docs/OPENVINS_INDEPENDENT_CLOCK_REPORT.md',
    'docs/superpowers/specs/2026-10-08-independent-simulation-clock-design.md',
    'docs/superpowers/plans/2026-10-08-independent-simulation-clock.md',
    '.superpowers/sdd/2026-10-08-independent-simulation-clock/progress.md',
]
files = sorted(p for p in STAGE.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
files += [ROOT / name for name in extra]
members = {}
with zipfile.ZipFile(ARCHIVE, 'x', zipfile.ZIP_DEFLATED) as archive:
    for path in files:
        name = path.relative_to(ROOT).as_posix()
        assert name not in members
        data = path.read_bytes()
        archive.writestr(name, data)
        members[name] = dict(bytes=len(data), sha256=sha(data))
with zipfile.ZipFile(ARCHIVE) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(members)
    for name, row in members.items():
        assert sha(archive.read(name)) == row['sha256']
metadata = dict(archive=ARCHIVE.name, sha256=sha(ARCHIVE.read_bytes()), bytes=ARCHIVE.stat().st_size,
                member_count=len(members), members=members,
                source_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
                production_commit='dcc54fb', previous_archive_unchanged=True,
                runtime_source_proven=False, network_authorized=False, fusion_qualified=False)
with META.open('x', encoding='utf-8') as stream:
    json.dump(metadata, stream, indent=2)
print(json.dumps({k: v for k, v in metadata.items() if k != 'members'}, indent=2))
