"""Read-only value-type capability; no TestFixture/Server/Node is created."""
import hashlib
import json
from pathlib import Path
import subprocess
import gz.sim8 as sim

value = sim.UpdateInfo()
out = dict(scope='default UpdateInfo value only; no simulator instance or stepping',
           fields={name: dict(type=type(getattr(value, name)).__name__, value=str(getattr(value, name)))
                   for name in ('sim_time', 'dt', 'iterations', 'paused')},
           module_file=sim.__file__,
           source_files=[])
root = Path('/home/yuchen7509/PX4-Autopilot')
for name in ('src/modules/simulation/gz_bridge/GZBridge.cpp', 'platforms/posix/src/px4/common/drv_hrt.cpp'):
    data = (root / name).read_bytes()
    out['source_files'].append(dict(path=str(root / name), sha256=hashlib.sha256(data).hexdigest()))
out['px4_head'] = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip()
print(json.dumps(out, indent=2))
