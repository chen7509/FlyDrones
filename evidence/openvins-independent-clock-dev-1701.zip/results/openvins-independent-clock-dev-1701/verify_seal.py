import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[2]
meta = json.loads((root / 'evidence/openvins-independent-clock-seal.json').read_text())
path = root / 'evidence' / meta['archive']
assert hashlib.sha256(path.read_bytes()).hexdigest() == meta['sha256']
with zipfile.ZipFile(path) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == meta['member_count']
    for name, row in meta['members'].items():
        data = archive.read(name)
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    for name in ('tools/benchmark/openvins_simulation_clock.py', 'tests/benchmark/test_openvins_simulation_clock.py'):
        assert (root / name).read_bytes() == archive.read(name)
    prefix = 'results/openvins-independent-clock-dev-1701/'
    def log(name):
        return archive.read(prefix + name).decode('utf-8-sig')
    assert '44 passed' in log('review-green.txt')
    assert '2 failed, 42 passed' in log('review-deterministic-red.txt')
    assert '133 passed, 2 skipped' in log('dependency-final.txt')
    assert 'Ran 67 tests' in log('wsl-wire-regression.txt') and 'OK' in log('wsl-wire-regression.txt')
print('Clock archive SHA/members/CRC, final production sources, failures and passing evidence verified')
