import hashlib,json,pathlib,zipfile
root=pathlib.Path.cwd()
stage=root/'results/estimator-heartbeat-retry-preflight-dev-1701'
base=root/'results/estimator-physical-refusal-diagnosis-dev-1701'
archive=root/'evidence/estimator-heartbeat-retry-preflight-dev-1701.zip'
paths=[]
for study in ('study-v12','study-v13'):
    paths += [p for p in (base/study).rglob('*') if p.is_file()]
for pattern in (
    'study-v12-audit-v*.json','study-v13-audit-v*.json','startup-preflight-v6-*',
    'current-head-for-startup-v6.txt',
):
    paths += [p for p in base.glob(pattern) if p.is_file()]
paths += [p for p in stage.rglob('*') if p.is_file()]
paths += [root/'evidence/estimator-heartbeat-routing-dev-1701.zip']
for rel in (
    'docs/ESTIMATOR_PHYSICAL_REFUSAL_DIAGNOSIS_REPORT.md',
    'docs/superpowers/specs/2026-10-07-estimator-heartbeat-retry-preflight-design.md',
    'docs/superpowers/plans/2026-10-07-estimator-heartbeat-retry-preflight.md',
    'tools/benchmark/estimator_heartbeat_retry_preflight.py',
    'tools/benchmark/audit_estimator_heartbeat_retry_preflight.py',
    'tests/benchmark/test_estimator_heartbeat_retry_preflight.py',
): paths.append(root/rel)
paths=sorted(set(p.resolve() for p in paths))
for p in paths:
    if not p.is_file(): raise SystemExit(f'missing {p}')
members=[]
for p in paths:
    data=p.read_bytes(); rel=p.relative_to(root).as_posix()
    members.append({'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema':'flydrones-evidence-manifest-v1','stage':'estimator-heartbeat-retry-preflight-dev-1701','member_count':len(members),'members':members}
archive.parent.mkdir(parents=True,exist_ok=True)
if archive.exists(): raise SystemExit(f'exists {archive}')
prefix='estimator-heartbeat-retry-preflight-dev-1701/'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p,m in zip(paths,members): z.writestr(prefix+m['path'],p.read_bytes())
    z.writestr(prefix+'manifest.json',json.dumps(manifest,indent=2,sort_keys=True)+'\n')
with zipfile.ZipFile(archive) as z:
    if z.testzip() is not None: raise SystemExit('crc failure')
    if len(z.namelist()) != len(paths)+1: raise SystemExit('count failure')
print(json.dumps({'path':str(archive),'members':len(paths)+1,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},indent=2))
