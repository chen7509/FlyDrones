import json,pathlib
from tools.benchmark.estimator_heartbeat_retry_preflight import _same_destination
r=pathlib.Path('results/estimator-physical-refusal-diagnosis-dev-1701/study-v11/capture-v1').resolve()
d=json.load(open(r/'result.json')); a=json.load(open('results/estimator-heartbeat-routing-dev-1701/study-v11-audit.json')); c=json.load(open('results/estimator-physical-refusal-diagnosis-dev-1701/physical-run-v5-completion.json'))
f=d.get('source_fanout',{}); l=f.get('last_disposition',{}); h=f.get('heartbeat',{}); m=d.get('motion',{}); u=d.get('px4_ulogs'); claims=a.get('claims',{})
vals={
'status':d.get('status'),'end':d.get('end_sim_ns'),'profile':d.get('source_fanout_profile'),'failure':f.get('failure'),'seq':l.get('source_sequence'),'disp':l.get('dispositions'),'hb':(h.get('observed'),h.get('reconciled')),'motion':(m.get('anchor_ns'),m.get('active_steps'),m.get('support_steps'),m.get('recorded_commands')),'eligible':(d.get('eligible_for_vio_input'),d.get('eligible_for_px4_fusion')),'px4':d.get('px4_exit_code'),'ulogs':u,'audit':(a.get('schema'),a.get('failures'),a.get('failure_classification_qualified'),a.get('classification'),claims),'completion':(c,_same_destination(c.get('destination'),r))}
print(json.dumps(vals,indent=2))
