"""Seal source-only PX4 EstimatorStatus transport evidence without overwrite."""

import hashlib
import json
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
ARCHIVE = ROOT / "evidence/px4-estimator-status-transport-dev-1701.zip"
FILES = (
    ".gitattributes",
    "configs/px4/estimator-status-dds-candidate.yaml",
    "docs/PX4_ESTIMATOR_STATUS_TRANSPORT_REPORT.md",
    "docs/superpowers/specs/2026-10-12-px4-estimator-status-transport-design.md",
    "docs/superpowers/plans/2026-10-12-px4-estimator-status-transport.md",
    "src/flydrones/connectome_training/px4_status_transport.py",
    "tests/connectome_training/test_px4_status_transport.py",
    "tests/fixtures/px4_status_transport/dds_topics.d6f12ad.yaml",
    "tests/fixtures/px4_status_transport/EstimatorStatus.d6f12ad.msg",
    "tests/fixtures/px4_status_transport/EstimatorStatus.newer-px4-msg.msg",
    "results/px4-estimator-status-transport-dev-1701-red.txt",
    "results/px4-estimator-status-transport-dev-1701-green-v1.txt",
    "results/px4-estimator-status-transport-dev-1701-red-malformed.txt",
    "results/px4-estimator-status-transport-dev-1701-focused-final.txt",
    "results/px4-estimator-status-transport-dev-1701-full-tests.txt",
    "results/px4-estimator-status-transport-dev-1701-local-source.json",
    "results/px4-estimator-status-transport-dev-1701-existing-ros-refusal.json",
    "results/px4-estimator-status-transport-dev-1701-ruff-final.txt",
    "results/px4-estimator-status-transport-dev-1701/diff-check.txt",
    "results/px4-estimator-status-transport-dev-1701/candidate.diff",
    "results/px4-estimator-status-transport-dev-1701/review.txt",
    "results/px4-estimator-status-transport-dev-1701/seal.py",
)


def main() -> None:
    if ARCHIVE.exists():
        raise FileExistsError("evidence archive already exists")
    missing = [name for name in FILES if not (ROOT / name).is_file()]
    if missing:
        raise FileNotFoundError(f"evidence members missing before seal: {missing}")
    manifest = {
        "schema": "flydrones.px4_estimator_status_transport_evidence.v1",
        "pinned_px4_commit": "d6f12ad1c4f70ad3230afd7d86e971421e02fef4",
        "firmware_compiled_verified": False,
        "live_source_authenticated": False,
        "training_eligible": False,
        "files": {},
    }
    ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ARCHIVE, "x", zipfile.ZIP_DEFLATED) as archive:
        for name in FILES:
            data = (ROOT / name).read_bytes()
            manifest["files"][name] = {
                "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            }
            archive.writestr(name, data)
        archive.writestr("manifest.json", json.dumps(manifest, sort_keys=True, indent=2))
    with zipfile.ZipFile(ARCHIVE) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("ZIP CRC check failed")
        for name, expected in manifest["files"].items():
            data = archive.read(name)
            if (len(data) != expected["bytes"]
                    or hashlib.sha256(data).hexdigest() != expected["sha256"]):
                raise RuntimeError(f"evidence member drift: {name}")
    seal = {
        "archive": str(ARCHIVE),
        "sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
        "member_count": len(FILES) + 1,
        "crc_and_hash_verified": True,
    }
    (Path(__file__).parent / "seal.json").write_text(
        json.dumps(seal, sort_keys=True, indent=2) + "\n", encoding="utf-8",
    )
    print(json.dumps(seal, sort_keys=True))


if __name__ == "__main__":
    main()
