"""Seal the exact-field, non-authorizing odometry cross-check evidence."""

import hashlib
import json
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
ARCHIVE = ROOT / "evidence/px4-odometry-ulog-crosscheck-dev-1701.zip"
FILES = (
    "docs/PX4_ODOMETRY_ULOG_CROSSCHECK_REPORT.md",
    "docs/superpowers/specs/2026-10-12-px4-odometry-ulog-crosscheck-design.md",
    "docs/superpowers/plans/2026-10-12-px4-odometry-ulog-crosscheck.md",
    "src/flydrones/connectome_training/px4_ulog_odometry_crosscheck.py",
    "tests/connectome_training/test_px4_ulog_odometry_crosscheck.py",
    "results/px4-odometry-ulog-crosscheck-dev-1701/historical-ulog-refusal.json",
    "results/px4-odometry-ulog-crosscheck-dev-1701/historical-ulog-stderr.txt",
    "results/px4-odometry-ulog-crosscheck-dev-1701/full-tests.txt",
    "results/px4-odometry-ulog-crosscheck-dev-1701/ruff-final.txt",
    "results/px4-odometry-ulog-crosscheck-dev-1701/diff-check-final.txt",
    "results/px4-odometry-ulog-crosscheck-dev-1701/review-and-failures.txt",
    "results/px4-odometry-ulog-crosscheck-dev-1701/seal.py",
)


def main() -> None:
    if ARCHIVE.exists():
        raise FileExistsError("evidence archive already exists")
    missing = [name for name in FILES if not (ROOT / name).is_file()]
    if missing:
        raise FileNotFoundError(f"evidence members missing before seal: {missing}")
    manifest = {
        "schema": "flydrones.px4_odometry_ulog_crosscheck_evidence.v1",
        "matching_samples_authenticate_source": False,
        "real_same_episode_positive_pair_tested": False,
        "files": {},
    }
    ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ARCHIVE, "x", zipfile.ZIP_DEFLATED) as archive:
        for name in FILES:
            data = (ROOT / name).read_bytes()
            manifest["files"][name] = {
                "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            }
            archive.writestr(name, data)
        archive.writestr("manifest.json", json.dumps(manifest, sort_keys=True, indent=2))
    with zipfile.ZipFile(ARCHIVE) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("ZIP CRC check failed")
        for name, expected in manifest["files"].items():
            data = archive.read(name)
            if (len(data) != expected["bytes"]
                    or hashlib.sha256(data).hexdigest() != expected["sha256"]):
                raise RuntimeError(f"evidence member drift: {name}")
    seal = {
        "archive": str(ARCHIVE),
        "sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
        "member_count": len(FILES) + 1,
        "crc_and_hash_verified": True,
    }
    (Path(__file__).parent / "seal.json").write_text(
        json.dumps(seal, sort_keys=True, indent=2) + "\n", encoding="utf-8",
    )
    print(json.dumps(seal, sort_keys=True))


if __name__ == "__main__":
    main()
