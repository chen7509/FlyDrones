import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

root=Path.cwd()
study=root/'results/ego-build-whitespace-dev-1701'
v2=root/'results/ego-patched-build-dev-1701-v2'
v3=root/'results/ego-patched-build-dev-1701-v3'
state=json.loads((v2/'completion.json').read_text(encoding='utf-8-sig'))
assert state['docker_exit_code']==2 and state['container_state']=='false 2' and not state['committed_image_id']
assert not json.loads((v2/'cleanup.json').read_text(encoding='utf-8-sig'))['remaining_owned_container']
assert (v2/'docker-stdout.txt').read_bytes().count(b'trailing whitespace.')==54
prospective=json.loads((v3/'prospective.json').read_text())
for path,digest in prospective['inputs'].items():
    assert hashlib.sha256((root/path).read_bytes()).hexdigest()==digest
assert prospective['windows_min_mib']==2500 and prospective['memory_cap_mib']==1536
assert not (v3/'command.json').exists() and not (v3/'completion.json').exists()
final=json.loads((study/'verification-exits-final.json').read_text(encoding='utf-8-sig'))
assert all(final[k]==0 for k in ['pytest_exit','ruff_exit','diff_exit'])
files={}
for directory in [study,v2,v3]:
    for path in directory.rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts and path.name not in {'seal.json','pr65-before.json','pr65-body.md'}:
            files[str(path.relative_to(root)).replace('\\','/')]=path.read_bytes()
for rel in ['tools/benchmark/ego_causal_build_v3.sh','tools/benchmark/ego_causal_readonly_v2.patch',
            'tests/benchmark/test_ego_build_whitespace.py','docs/EGO_BUILD_WHITESPACE_REPORT.md',
            'docs/superpowers/specs/2026-10-13-ego-build-whitespace-design.md',
            'docs/superpowers/plans/2026-10-13-ego-build-whitespace.md',
            'results/ego-causal-patch-v2-dev-1701/patch-manifest.json',
            'results/ego-causal-patch-v2-dev-1701/upstream/traj_server.cpp',
            'results/ego-causal-patch-v2-dev-1701/upstream/ego_replan_fsm.h',
            'results/ego-causal-patch-v2-dev-1701/overlay/traj_server.cpp',
            'results/ego-causal-patch-v2-dev-1701/overlay/ego_replan_fsm.h']:
    files[rel]=(root/rel).read_bytes()
manifest={rel:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for rel,data in files.items()}
archive=root/'evidence/ego-build-whitespace-dev-1701.zip'
with ZipFile(archive,'x',ZIP_DEFLATED) as zipped:
    for rel,data in files.items(): zipped.writestr(rel,data)
    zipped.writestr('manifest.json',json.dumps(manifest,indent=2))
with ZipFile(archive) as zipped:
    assert zipped.testzip() is None
    for rel,expected in manifest.items():
        data=zipped.read(rel)
        assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
with archive.with_suffix('.sha256').open('x') as stream: stream.write(digest+'  '+archive.name+'\n')
record={'sha256':digest,'members':len(manifest)+1,'bytes':archive.stat().st_size,'crc_member_hash_verified':True,
        'focused_passed':6,'affected_passed':76,'v2_actual_exit':2,'v3_actual_build_attempted':False,'teacher_qualified':False}
(study/'seal.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record))
