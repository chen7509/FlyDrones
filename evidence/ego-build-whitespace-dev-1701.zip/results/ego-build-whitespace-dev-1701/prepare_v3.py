import hashlib
import json
from pathlib import Path

root = Path.cwd()
old = root/'results/ego-patched-build-dev-1701-v2'
new = root/'results/ego-patched-build-dev-1701-v3'
new.mkdir(exist_ok=False)
patch = root/'tools/benchmark/ego_causal_readonly_v2.patch'
assert hashlib.sha256(patch.read_bytes()).hexdigest() == 'bcf739842f3868fb082efce4a9a82609a7d5eb0833dea6c39e80ed9c57433fe9'
previous = (old/'build.sh').read_bytes()
selected = (root/'tools/benchmark/ego_causal_build_v3.sh').read_bytes()
expected = previous.replace(b'git -C "$source_dir" diff --check',
    b'git -C "$source_dir" -c core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol diff --check')
assert selected == expected
(new/'build.sh').write_bytes(selected)
old_runner = (old/'run.ps1').read_bytes()
runner = old_runner.replace(b'fly-ego-causal-v2-build-1701-v2',b'fly-ego-causal-v2-build-1701-v3').replace(
    b'fly-ego-benchmark:causal-v2',b'fly-ego-benchmark:causal-v3')
assert runner != old_runner
(new/'run.ps1').write_bytes(runner)
profile = {'study':'fixed-ego-crlf-recognition-build-v3','source_commit':'23a8d5a191711dd65633df689bd00f55d4dea8f9',
    'base_image':'sha256:a4dae62b38bc01a01d084be7b68db83ec804fef7673604e1a9c986a4baa88a6a',
    'patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),
    'inputs':{str(p.relative_to(root)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest()
              for p in [patch,new/'build.sh',new/'run.ps1',root/'tools/benchmark/ego_causal_build_v3.sh']},
    'minimal_changes':'build.sh one whitespace recognition command; run.ps1 only isolated container/image names',
    'windows_min_mib':2500,'memory_cap_mib':1536,'cpu':1,'network':'none','timeout_seconds':1200,
    'original_v2_preserved':True,'old_compiler_started':False,'teacher_qualified':False}
(new/'prospective.json').write_text(json.dumps(profile,indent=2),encoding='utf-8')
print(json.dumps(profile))
