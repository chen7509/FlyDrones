"""Actual pinned codecs and synthetic ULogs; no PX4 or transport."""
import contextlib
import io
import json
import pathlib
import socket
import struct
import sys
from unittest.mock import patch

ROOT = pathlib.Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT/'tests/benchmark')]
from receiver_ulog_fixture import receiver_log, record
from tools.benchmark.audit_openvins_receiver_parity import main

BASE = pathlib.Path(__file__).resolve().parent
phase = sys.argv[1]
out = BASE / ('ulog-boundary-' + phase)
out.mkdir(exist_ok=False)
rows = [pair[1] for pair in json.loads((BASE/'analytic-fixtures.json').read_text())]
definitions, subscription, records = receiver_log(rows)
normal = definitions + subscription + b''.join(records)
variants = {
    'normal': normal,
    'short_header': normal + b'\x04',
    'short_payload': normal + b'\x04\x00Iab',
    'reused_subscription': definitions + subscription + records[0] + subscription + b''.join(records),
    'definition_struct_error': normal[:59] + record('I', b'\x0buint64_t x'),
    'unknown_incompat': normal[:28] + b'\x01' + normal[29:],
    'empty_logging': normal + record('L', b''),
    'empty_tagged_logging': normal + record('C', b''),
    'empty_info': normal + record('I', b''),
    'short_scalar_info': normal + record('I', b'\x0auint64_t x'),
    'empty_multi_info': normal + record('M', b''),
    'empty_parameter': normal + record('P', b''),
    'empty_default_parameter': normal + record('Q', b''),
    'recursive_format': definitions + record('F', b'cycle:cycle self;')
                        + subscription + b''.join(records) + record('A', b'\x00\x01\x00cycle'),
}
results = []
with patch.object(socket, 'socket', side_effect=AssertionError('network forbidden')):
    for name, data in variants.items():
        path = out / (name+'.ulg')
        path.write_bytes(data)
        audit_path = out / (name+'.json')
        console = io.StringIO()
        try:
            with contextlib.redirect_stdout(console):
                rc = main(['--packets',str(BASE/'synthetic-packets.json'),
                           '--clock',str(BASE/'synthetic-clock.json'), '--ulog',str(path),
                           '--output',str(audit_path)])
            entry = {'case':name,'rc':rc,'artifact':audit_path.exists(),
                     'pass':json.loads(audit_path.read_text())['field_parity_pass']}
        except (struct.error, NotImplementedError, RecursionError) as exc:
            entry = {'case':name,'escaped':type(exc).__name__,'artifact':audit_path.exists()}
        (out/(name+'-console.txt')).write_text(console.getvalue())
        entry['expectation_pass'] = (entry.get('rc') == (0 if name=='normal' else 2)
                                      and entry['artifact'])
        results.append(entry)
(out/'summary.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
if not all(r['expectation_pass'] for r in results):
    raise SystemExit(1)
