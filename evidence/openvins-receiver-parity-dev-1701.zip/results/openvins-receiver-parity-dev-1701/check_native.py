"""Real pinned codecs, synthetic wire fixtures, real retained negative ULog."""
import copy
import hashlib
import importlib.metadata
import json
import pathlib
import socket
import sys
from unittest.mock import patch

ROOT = pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.benchmark.openvins_receiver_parity import audit_pairs, decode_sent_packets
from tools.benchmark.audit_openvins_receiver_parity import main
from pymavlink.dialects.v20 import common

OUT = pathlib.Path(__file__).resolve().parent
fixtures = json.loads((OUT / 'analytic-fixtures.json').read_text())
records = []
for packet, _ in fixtures:
    fields = copy.deepcopy(packet['wire'])
    for key, value in fields.items():
        if isinstance(value, list):
            fields[key] = [float('nan') if x is None else x for x in value]
        elif value is None:
            fields[key] = float('nan')
    encoder = common.MAVLink(None, srcSystem=254, srcComponent=191)
    wire = common.MAVLink_odometry_message(**fields).pack(encoder)
    records.append({'id': packet['id'], 'packet_hex': wire.hex()})
with (OUT / 'synthetic-packets.json').open('x') as f:
    json.dump(records, f, indent=2)
with (OUT / 'synthetic-clock.json').open('x') as f:
    json.dump({'schema':'px4-receiver-parity-clock-v1','px4_minus_remote_us':10000}, f)

with patch.object(socket, 'socket', side_effect=AssertionError('network attempted')):
    decoded = decode_sent_packets(records)
    assert decoded == [pair[0] for pair in fixtures]
    result = audit_pairs(decoded, [pair[1] for pair in fixtures], px4_minus_remote_us=10000)
    assert result['field_parity_pass'] and not result['receiver_stage_qualified']
    errors = []
    for name, raw in [('crc', bytes.fromhex(records[0]['packet_hex'])) ,
                      ('trailing', bytes.fromhex(records[0]['packet_hex']) + b'\x00'),
                      ('duplicate_bytes', bytes.fromhex(records[0]['packet_hex']) * 2)]:
        if name == 'crc':
            raw = raw[:-1] + bytes([raw[-1] ^ 1])
        try:
            decode_sent_packets([{'id':'bad', 'packet_hex':raw.hex()}])
        except ValueError:
            errors.append(name)
        else:
            raise AssertionError('not refused: ' + name)
    ulog = ROOT / 'results/openvins-ekf2-fast-grid-physical-dev-1701/development-seed-27601/capture-v1/px4-ulog/log/2026-10-07/17_45_07.ulg'
    assert hashlib.sha256(ulog.read_bytes()).hexdigest() == 'bb84abacfecb838c1a21cec6c0dc9116a2a4a2216882ff519fb7799e87299c2c'
    rc = main(['--packets', str(OUT/'synthetic-packets.json'), '--clock', str(OUT/'synthetic-clock.json'),
               '--ulog', str(ulog), '--output', str(OUT/'retained-negative-audit.json')])
    assert rc == 2
summary = {'schema':'receiver-parity-native-check-v1', 'pymavlink':importlib.metadata.version('pymavlink'),
           'pyulog':importlib.metadata.version('pyulog'),'synthetic_roundtrips':3,'wire_refusals':errors,
           'field_audit':result,'negative_retained_ulog_exit':rc,'network_attempt_forbidden':True,
           'physical_receiver_qualified':False}
with (OUT/'native-check.json').open('x') as f:
    json.dump(summary,f,indent=2)
print(json.dumps(summary,indent=2))

dist = importlib.metadata.distribution('pyulog')
provenance = []
for member in dist.files:
    if str(member) not in ('pyulog/core.py', 'pyulog-1.2.4.dist-info/METADATA', 'pyulog-1.2.4.dist-info/licenses/LICENSE.md'):
        continue
    path = dist.locate_file(member)
    data = path.read_bytes()
    target = OUT / ('installed-pyulog-' + path.name)
    with target.open('xb') as f:
        f.write(data)
    provenance.append({'installed_path':str(path),'copy':target.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with (OUT/'pyulog-installed-provenance.json').open('x') as f:
    json.dump(provenance,f,indent=2)
