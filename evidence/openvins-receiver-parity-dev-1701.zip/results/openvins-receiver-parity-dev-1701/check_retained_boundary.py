"""Read-only raw-boundary check on the retained no-ODOMETRY physical log."""
import contextlib
import hashlib
import io
import json
import pathlib
import socket
import sys
from unittest.mock import patch

ROOT = pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from tools.benchmark.openvins_receiver_parity import validate_ulog_stream
from tools.benchmark.audit_openvins_receiver_parity import main
OUT = pathlib.Path(__file__).resolve().parent
log = ROOT/'results/openvins-ekf2-fast-grid-physical-dev-1701/development-seed-27601/capture-v1/px4-ulog/log/2026-10-07/17_45_07.ulg'
sources = [ROOT/'tools/benchmark/openvins_receiver_parity.py',ROOT/'tools/benchmark/audit_openvins_receiver_parity.py']
def hashes():
    return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [log,*sources]}
before=hashes()
assert before[str(log)]=='bb84abacfecb838c1a21cec6c0dc9116a2a4a2216882ff519fb7799e87299c2c'
with patch.object(socket,'socket',side_effect=AssertionError('network forbidden')):
    framing=validate_ulog_stream(log.read_bytes())
    console=io.StringIO()
    with contextlib.redirect_stdout(console):
        rc=main(['--packets',str(OUT/'synthetic-packets.json'),'--clock',str(OUT/'synthetic-clock.json'),
                 '--ulog',str(log),'--output',str(OUT/'retained-negative-final.json')])
    assert rc==2
after=hashes()
assert before==after
assert framing['receiver_data_count']==0
with (OUT/'retained-boundary-check.json').open('x') as f:
    json.dump({'raw_framing':framing,'negative_exit':rc,'before':before,'after':after,
               'physical_run_started':False,'receiver_stage_qualified':False},f,indent=2)
print(console.getvalue())
print(json.dumps(framing))
