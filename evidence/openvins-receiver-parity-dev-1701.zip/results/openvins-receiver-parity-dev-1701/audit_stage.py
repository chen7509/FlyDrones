"""Verify retained check outcomes and input identities before publication."""
import hashlib
import json
import pathlib
import re

ROOT=pathlib.Path(__file__).resolve().parents[2]
OUT=pathlib.Path(__file__).resolve().parent
green=json.loads((OUT/'ulog-boundary-recursion-green/summary.json').read_text())
assert len(green)==14 and all(x['expectation_pass'] for x in green)
for case in green:
    audit=json.loads((OUT/('ulog-boundary-recursion-green/'+case['case']+'.json')).read_text())
    for field in ('receiver_stage_qualified','timesync_convergence_qualified','ekf2_fusion_qualified','task5_authorized'):
        assert audit[field] is False
    assert audit['field_parity_pass']==(case['case']=='normal')
red=json.loads((OUT/'ulog-boundary-red/summary.json').read_text())
assert sum(not x['expectation_pass'] for x in red)==5
red_eof=json.loads((OUT/'ulog-boundary-eof-red/summary.json').read_text())
assert sum(not x['expectation_pass'] for x in red_eof)==7
red_cycle=json.loads((OUT/'ulog-boundary-recursion-red/summary.json').read_text())
assert sum(not x['expectation_pass'] for x in red_cycle)==1
full=(OUT/'full-tests-recursion-final.txt').read_text(encoding='utf-8-sig')
match=re.search(r'(\d+) passed, 3 skipped, 2 warnings',full)
assert match and 'failed' not in full
assert int(match[1])==2050
assert '71 passed' in (OUT/'recursion-unit-green.txt').read_text(encoding='utf-8-sig')
assert 'All checks passed!' in (OUT/'final-ruff-v2.txt').read_text(encoding='utf-8-sig')
review=json.loads((OUT/'independent-review.json').read_text())
for path,want in review['source_sha256'].items():
    assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==want
old={'evidence/openvins-ekf2-disarmed-preflight-dev-1701.zip':'e226c8ec4239804c31c9bdde62c8ee86103994fe097c166641178728a530e8b5',
     'evidence/openvins-parameter-rollback-dev-1701.zip':'299b64cc757b490711a04cf2fd91ad3295e46fd227372cfbfc4ee3c634c3bc79'}
for path,want in old.items():
    assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==want
result={'schema':'receiver-parity-prepublication-audit-v1','failures':[],
        'targeted_passed':71,'full_passed':int(match[1]),'full_skipped':3,'existing_warnings':2,
        'native_synthetic_normal':1,'native_refusals':13,'retained_behavioral_red':[5,7,1],
        'historical_archives_unchanged':old,'reviewed_source_hashes_unchanged':True,
        'receiver_stage_qualified':False,'timesync_convergence_qualified':False,
        'ekf2_fusion_qualified':False,'task5_authorized':False}
with (OUT/'terminal-audit.json').open('x') as f: json.dump(result,f,indent=2)
print(json.dumps(result,indent=2))
