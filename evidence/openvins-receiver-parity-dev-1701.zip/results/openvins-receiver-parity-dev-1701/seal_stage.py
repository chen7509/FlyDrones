"""Write-once archive assembly with independent CRC/member re-read checks."""
import hashlib
import json
import pathlib
import subprocess
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[2]
RESULTS = pathlib.Path(__file__).resolve().parent
ARCHIVE = ROOT/'evidence/openvins-receiver-parity-dev-1701.zip'
COMPANION = ARCHIVE.with_name(ARCHIVE.stem+'-manifest.json')
assert not ARCHIVE.exists() and not COMPANION.exists()
selected = [
    'tools/benchmark/openvins_receiver_parity.py',
    'tools/benchmark/audit_openvins_receiver_parity.py',
    'tests/benchmark/test_openvins_receiver_parity.py',
    'tests/benchmark/test_openvins_receiver_parity_cli.py',
    'tests/benchmark/test_receiver_ulog_boundary.py',
    'tests/benchmark/receiver_ulog_fixture.py',
    'docs/OPENVINS_RECEIVER_PARITY_REPORT.md',
    'docs/superpowers/plans/2026-10-07-openvins-ekf2-shadow-integration.md',
    '.superpowers/sdd/2026-10-07-openvins-ekf2-shadow-integration/progress.md',
]
files = [ROOT/p for p in selected]
files += [p for p in RESULTS.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
assert len(files)==len(set(files))
members = {p.relative_to(ROOT).as_posix():p.read_bytes() for p in sorted(files)}
manifest = {'schema':'openvins-receiver-parity-evidence-v1',
            'producer_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
            'physical_receiver_qualified':False,'fusion_qualified':False,
            'members':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
                       for name,data in members.items()}}
with zipfile.ZipFile(ARCHIVE,'x',compression=zipfile.ZIP_DEFLATED) as z:
    z.writestr('MANIFEST.json',json.dumps(manifest,indent=2))
    for name,data in members.items():
        z.writestr(name,data)
with zipfile.ZipFile(ARCHIVE) as z:
    assert z.testzip() is None
    assert set(z.namelist())==set(members)|{'MANIFEST.json'}
    decoded=json.loads(z.read('MANIFEST.json'))
    for name,entry in decoded['members'].items():
        data=z.read(name)
        assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
data=ARCHIVE.read_bytes()
summary={'archive':ARCHIVE.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(data).hexdigest(),
         'bytes':len(data),'members':len(members)+1,'crc_verified':True,
         'all_member_hashes_verified':True,'physical_receiver_qualified':False,
         'fusion_qualified':False,'task5_authorized':False}
with COMPANION.open('x') as f:
    json.dump(summary,f,indent=2)
print(json.dumps(summary,indent=2))
