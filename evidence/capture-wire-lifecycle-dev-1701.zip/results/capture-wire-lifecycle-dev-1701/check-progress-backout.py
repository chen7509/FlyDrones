"""Explicit backout check; initial scheduled RED actually ran after implementation.

Retain that GREEN output honestly. Temporarily omit only the new scalar getter,
run its test, and restore exact bytes in finally. No other process is running.
"""
import hashlib
import os
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[2]
source = root / 'tools/benchmark/openvins_timesync_interval.py'
before = source.read_bytes()
text = before.decode('utf-8')
start = text.index('    @property\n    def progress(self):', text.index('class IntervalExchange:'))
end = text.index('    @property\n    def evidence(self):', start)
env = dict(os.environ, PYTHONPATH=os.pathsep.join([str(root / 'src'), str(root)]))
try:
    source.write_bytes((text[:start] + text[end:]).encode('utf-8'))
    with (Path(__file__).resolve().parent / 'interval-progress-backout-red.txt').open('xb') as log:
        result = subprocess.run([sys.executable, '-m', 'pytest', 'tests/benchmark/test_openvins_interval_exchange.py',
                                 '-k', 'progress_has_no_history', '-q'], cwd=root, env=env,
                                stdout=log, stderr=subprocess.STDOUT, timeout=60)
    assert result.returncode == 1, result.returncode
finally:
    source.write_bytes(before)
assert source.read_bytes() == before
print('Backout test failed as expected; exact implementation bytes restored:', hashlib.sha256(before).hexdigest())
