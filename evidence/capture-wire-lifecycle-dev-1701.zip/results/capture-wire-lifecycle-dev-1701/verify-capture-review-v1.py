"""Verify serial capture driver with injected I/O; actual runner with injected external services; no CLI preparation or physical factories."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent / 'capture-review-final-v1'
out.mkdir(exist_ok=False)
pytests = ['test_openvins_interval_exchange', 'test_openvins_segmented_journal', 'test_openvins_timesync_continuation', 'test_capture_runtime_runner', 'test_capture_wire_contract', 'test_capture_startup_preflight_audit', 'test_readiness_anchor', 'test_capture_wire_hooks', 'test_disarmed_sensor_provenance', 'test_capture_contract',
           'test_runtime_resource_binding', 'test_physics_substep_trace', 'test_native_runtime_refusal',
           'test_ready_shadow_fanout', 'test_journaled_heartbeat_lane', 'test_estimator_aware_readiness']
wire = ['test_capture_wire_review_safety', 'test_openvins_timesync_wire', 'test_openvins_interval_codec', 'test_openvins_segmented_wire', 'test_openvins_segmented_receive', 'test_openvins_owned_maintenance', 'test_openvins_observed_maintenance', 'test_openvins_maintenance_transport', 'test_capture_runtime_wire_integration', 'test_capture_wire_owner', 'test_capture_wire_lifecycle', 'test_openvins_wire_maintenance', 'test_openvins_observed_wire_session', 'test_openvins_wire_fanout_integration', 'test_openvins_wire_heartbeat',
        'test_openvins_observed_interval', 'test_openvins_observed_restoration']
production = ['openvins_segmented_journal', 'openvins_listener_transport', 'openvins_timesync_bootstrap', 'openvins_timesync_maintenance', 'capture_wire_lifecycle', 'openvins_wire_bootstrap', 'openvins_owned_bootstrap', 'openvins_simulation_clock', 'capture_disarmed_sensors', 'disarmed_sensor_provenance', 'capture_contract',
              'openvins_observed_wire_session', 'openvins_timesync_wire', 'openvins_timesync_interval',
              'openvins_datagram_receive', 'journaled_heartbeat_lane', 'ready_shadow_fanout',
              'estimator_aware_readiness', 'runtime_resource_binding', 'openvins_online_shadow']
paths = [f'tools/benchmark/{p}.py' for p in production] + [f'tests/benchmark/{p}.py' for p in pytests + wire]

def hashes():
    return {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in paths}

def save(name, value):
    with (out / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)

commands = [
    [sys.executable, '-m', 'pytest', *[f'tests/benchmark/{p}.py' for p in pytests], '-q'],
    ['wsl', '-e', 'sh', '-c', 'cd /mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility && '
     'FLYDRONES_RUNNER_EVIDENCE=results/capture-wire-lifecycle-dev-1701/capture-review-final-v1/runner-records PYTHONPATH=src:. python3 -m unittest ' + ' '.join('tests.benchmark.' + p for p in wire) + ' -q'],
    [sys.executable, '-m', 'ruff', 'check', 'tools/benchmark/capture_disarmed_sensors.py',
     'tools/benchmark/capture_wire_lifecycle.py', 'tools/benchmark/capture_contract.py', 'tools/benchmark/openvins_timesync_maintenance.py', 'tests/benchmark/test_capture_wire_contract.py', 'tests/benchmark/test_capture_wire_owner.py', 'tests/benchmark/test_capture_wire_lifecycle.py', 'tests/benchmark/test_capture_wire_hooks.py',
     'tests/benchmark/test_openvins_wire_fanout_integration.py', 'tests/benchmark/test_capture_runtime_runner.py', 'tests/benchmark/test_capture_runtime_wire_integration.py', 'tests/benchmark/test_capture_wire_review_safety.py', 'tools/benchmark/openvins_segmented_journal.py', 'tools/benchmark/openvins_timesync_wire.py', 'tools/benchmark/openvins_timesync_interval.py'],
    ['git', 'diff', '--check'],
]
before = hashes()
save('before.json', dict(sources=before, commands=commands))
env = dict(os.environ, PYTHONPATH=os.pathsep.join([str(root / 'src'), str(root)]))
codes = []
for name, command in zip(['pytest.txt', 'wsl-unittest.txt', 'ruff.txt', 'diff.txt'], commands, strict=True):
    with (out / name).open('xb') as stream:
        completed = subprocess.run(command, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=180)
    codes.append(completed.returncode)
    print(name, completed.returncode, flush=True)
after = hashes()
save('after.json', dict(sources=after, unchanged=before == after, exit_codes=codes,
                       actual_capture=False, injected_production_runner=True, cli_preparation_executed=False, actual_network=False, physics=False, estimator=False, fusion=False))
if any(codes) or before != after:
    raise SystemExit('verification failed or selected source drift')
