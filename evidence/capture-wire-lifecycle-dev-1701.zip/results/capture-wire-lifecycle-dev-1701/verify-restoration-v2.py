"""Offline checkpoint; no real receive, subprocess estimator or simulation."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent / 'restoration-final-v2'
out.mkdir(exist_ok=False)
pytests = ['test_openvins_interval_exchange', 'test_openvins_timesync_interval', 'test_openvins_datagram_receive', 'test_openvins_segmented_journal']
wire = ['test_openvins_interval_codec', 'test_openvins_timesync_wire', 'test_openvins_wire_heartbeat',
        'test_openvins_wire_bootstrap', 'test_openvins_wire_maintenance', 'test_openvins_observed_wire_session', 'test_openvins_observed_interval', 'test_openvins_observed_maintenance', 'test_openvins_wire_fanout_integration', 'test_openvins_segmented_wire', 'test_openvins_observed_restoration']
production = ['openvins_timesync_interval', 'openvins_timesync_wire', 'openvins_wire_bootstrap',
              'openvins_observed_wire_session', 'openvins_owned_bootstrap', 'openvins_timesync_bootstrap',
              'openvins_timesync_maintenance', 'openvins_datagram_receive', 'openvins_simulation_clock',
              'openvins_ekf2_disarmed_preflight', 'owned_daemon_connection', 'openvins_segmented_journal']
paths = [f'tools/benchmark/{p}.py' for p in production] + [f'tests/benchmark/{p}.py' for p in pytests + wire]
def hashes():
    return {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in paths}
def save(name, data):
    with (out / name).open('x', encoding='utf-8') as stream:
        json.dump(data, stream, indent=2)
commands = [
    [sys.executable, '-m', 'pytest', *[f'tests/benchmark/{p}.py' for p in pytests], '-q'],
    ['wsl', '-e', 'sh', '-c', 'cd /mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility && '
     'PYTHONPATH=src:. python3 -m unittest ' + ' '.join('tests.benchmark.' + p for p in wire) + ' -q'],
    [sys.executable, '-m', 'ruff', 'check', 'tools/benchmark/openvins_timesync_interval.py',
     'tools/benchmark/openvins_timesync_wire.py', 'tests/benchmark/test_openvins_interval_exchange.py',
     'tests/benchmark/test_openvins_interval_codec.py', 'tests/benchmark/test_openvins_observed_interval.py', 'tools/benchmark/openvins_wire_bootstrap.py', 'tools/benchmark/openvins_observed_wire_session.py', 'tools/benchmark/openvins_datagram_receive.py', 'tests/benchmark/test_openvins_observed_restoration.py'],
    ['git', 'diff', '--check'],
]
before = hashes()
save('before.json', dict(sources=before, commands=commands))
env = dict(os.environ, PYTHONPATH=os.pathsep.join([str(root / 'src'), str(root)]))
codes = []
for name, command in zip(['pytest.txt', 'wsl-unittest.txt', 'ruff.txt', 'diff.txt'], commands, strict=True):
    with (out / name).open('xb') as stream:
        r = subprocess.run(command, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=120)
    codes.append(r.returncode)
    print(name, r.returncode, flush=True)
after = hashes()
save('after.json', dict(sources=after, unchanged=before == after, exit_codes=codes,
                       actual_network=False, physics=False, estimator=False, fusion=False))
if any(codes) or before != after:
    raise SystemExit('verification failed/source drift')
