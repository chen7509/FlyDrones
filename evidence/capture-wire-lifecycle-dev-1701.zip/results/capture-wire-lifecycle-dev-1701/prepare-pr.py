import json
from pathlib import Path

p = Path(__file__).resolve().parent
before = json.loads((p/'pr-before.json').read_text(encoding='utf-8-sig'))
assert before['draft']
body = '''## Continuous capture lifecycle — partial implementation

Commits3f6ba0f and3e728ab add a one-time transfer of the existing cold TIMESYNC observer/filter into maintenance, strict raw listener-boundary correlation and a bounded listener transport tied to that exact continuation. Bootstrap8s/500 and2s progress gates remain; legacy transport defaults stay unchanged. No filter/count reset or boundary-snapshot double counting is allowed.

The maintenance listener is single-claim and records partial subscription cancellation, pending/partial-byte state, primary/journal/close errors and whether the injected backend close returned. Cancellation is not a daemon-exit proof. All network/live convergence/fusion authority remains false. Actual capture reader/socket registration has not changed.

Current focused verification:512 passed with selected source pre/post hashes unchanged, installed-codec WSL74 OK, changed Ruff/diff pass. Initial missing-interface failures and six subsequent behavioral REDs are retained (four core cancellation/exhaustion, two transport double-attachment/cancelled-read); these are synthetic/in-process tests, not a live PX4 run. No fresh full-repository result is claimed.

Task1 of `docs/superpowers/plans/2026-10-08-capture-wire-lifecycle.md` remains open: OwnedBootstrap/OwnedWire/ObservedWire binding and segmented retention still need implementation, followed by the nonblocking interval exchange and actual capture registration. No final whole-plan independent implementation review or stage archive yet. Progress report: `docs/OPENVINS_CAPTURE_WIRE_LIFECYCLE_REPORT.md`. No actual UDP, physics, estimator, training, ODOMETRY, EKF2 or arming operation was executed.

'''
with (p/'pr-patch.json').open('x', encoding='utf-8') as stream:
    json.dump(dict(body=body+before['body']), stream)
