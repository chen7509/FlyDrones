"""Check current selected bytes against just-completed focused tests, no rerun."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[2]
evidence = Path(__file__).resolve().parent / 'restoration-final-v2'
before = json.loads((evidence / 'before.json').read_text())
after = json.loads((evidence / 'after.json').read_text())
assert before['sources'] == after['sources'] and after['unchanged']
assert after['exit_codes'] == [0, 0, 0, 0]
assert len(after['sources']) == 27
for path, expected in after['sources'].items():
    assert hashlib.sha256((root / path).read_bytes()).hexdigest() == expected, path
assert '128 passed' in (evidence / 'pytest.txt').read_text()
assert 'Ran 177 tests' in (evidence / 'wsl-unittest.txt').read_text(errors='replace')
assert 'All checks passed' in (evidence / 'ruff.txt').read_text()
print('Current27 source hashes match128 pytest/177 WSL tests and Ruff/diff; no duplicate test run.')
