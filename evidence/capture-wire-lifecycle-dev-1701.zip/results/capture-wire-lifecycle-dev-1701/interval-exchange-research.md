# Task2 pinned command exchange research

2026-10-08. No network datagrams, simulator or estimator was started.

Reuse PX4 d6f12ad1c4f70ad3230afd7d86e971421e02fef4 (BSD-3-Clause),
pymavlink2.4.49 (retained LGPL/generated-code provenance). Source hashes and
installed dialect fields are in interval-codec-inspection.json. Existing metadata
observations are reused, not refreshed: PX4 non-archived/push2026-10-07T16:06:37Z;
pymavlink non-archived/push2026-10-06T23:56:46Z. No claim of installed checkout
equivalence or future maintenance. Existing OpenVINS paper/algorithm unchanged;
this is a transport protocol change, not a new estimator or learning algorithm.

Sources read:
- https://github.com/PX4/PX4-Autopilot/blob/d6f12ad1c4f70ad3230afd7d86e971421e02fef4/src/modules/mavlink/mavlink_receiver.cpp
- https://github.com/PX4/PX4-Autopilot/blob/d6f12ad1c4f70ad3230afd7d86e971421e02fef4/src/modules/mavlink/mavlink_main.cpp
- https://mavlink.io/en/services/command.html (read again this turn)
- https://mavlink.io/en/messages/common.html#MESSAGE_INTERVAL

Receiver GET510 sends MESSAGE_INTERVAL244 directly; command processing separately
publishes ACK77 to uORB with original sender target. main.cpp drains those ACKs
only when target is known and transmit buffer is available. ACK target extensions
are copied to the outgoing message. GET ACK and interval arrival order therefore
must both be supported. SET511 defaults to ACCEPTED unless set handler returns
failure; independent readback is still required. Sender254/191, target9/1;
confirmation0 and unused parameters zero. GET param1=111; SET param1=111 and
param2=restorable positive interval. Query -1/0 cannot authorize mutation.

Adopt existing pinned codec instead of mavutil recv_match: one decoder/reader and
sequence owner can service heartbeat while awaiting command results. No dependency
installation; a bounded transaction has at most six commands and constant pending
state. Actual receive-owner composition is still required and not proved by codec
or exchange tests. Synchronous oracle remains unchanged.

ACK accepted is not completion. MESSAGE_INTERVAL has no transaction nonce, source
header equality is not authentication, and delayed responses crossing repeated
GET/SET operations cannot be perfectly attributed. Retain this limit, enforce
one pending operation and local receive-time gates, reject duplicates/unsolicited
or nonmatching replies, no ambiguous mutation retry. The generic protocol's resend
recommendation is intentionally not adopted by this fail-closed research profile.
Restoration is one separately recorded owned-baseline attempt, not a retry of the
candidate. General IN_PROGRESS/unsupported progress modes are refused here.

Implement bounded begin/feed/poll progression with per-operation2s and total8s.
Primary failure can enter one immutable10s restoration-only window. Caller still
must enforce owned process/descriptor/peer, stop ordinary traffic, and service
safety heartbeats; the helper alone cannot grant cleanup transport authority.
An armed/changed-owner guard aborts sends. No actual capture or physical claim.
