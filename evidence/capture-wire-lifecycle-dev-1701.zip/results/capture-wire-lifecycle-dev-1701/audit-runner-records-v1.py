from pathlib import Path
import collections,hashlib,json
root=Path('results/capture-wire-lifecycle-dev-1701/capture-runner-final-v1/runner-records')
summary=[]
for run in sorted(root.iterdir()):
 result=json.loads((run/'result.json').read_text());wire=json.loads((run/'wire-lifecycle.json').read_text())
 manifest=json.loads((run/'wire-segments/manifest.json').read_text())
 count=0;channels=collections.Counter()
 for member in manifest['segments']:
  data=(run/'wire-segments'/member['name']).read_bytes()
  assert len(data)==member['bytes'] and hashlib.sha256(data).hexdigest()==member['sha256']
  rows=[json.loads(r) for r in data.splitlines()]
  assert len(rows)==member['records']
  assert rows[0]['index']==member['first_index'] and rows[-1]['index']==member['last_index']
  for row in rows:
   assert row['index']==count
   assert row['source_index']==channels[row['source']]
   channels[row['source']]+=1;count+=1
 assert count==manifest['records'] and dict(channels)==manifest['channels']
 assert not wire['fusion_qualified'] and not wire['network_authorized']
 clocks=[json.loads(r) for r in (run/'wire-clock.jsonl').read_text().splitlines()]
 attempts=[r for r in clocks if r['kind']=='clock_observation_attempt']
 normal=run.name.startswith('test25s_')
 assert result['status']==('capture_completed' if normal else 'capture_failed')
 if normal:
  assert len(attempts)==25000 and attempts[-1]['sim_ns']==25_000_000_000
  assert wire['session']['maintenance_correlated_samples']==746
 summary.append(dict(run=run.name,status=result['status'],segments=len(manifest['segments']),records=count,clock_attempts=len(attempts),maintenance_pairs=None if wire['session'] is None else wire['session'].get('maintenance_correlated_samples'),errors=result['errors']))
with Path('results/capture-wire-lifecycle-dev-1701/capture-runner-final-v1/retained-record-audit.json').open('x') as f:json.dump(dict(runs=summary,segment_hashes_indices_verified=True,retained_copy_paths_not_original_tmp_paths=True,actual_physics=False,fusion=False),f,indent=2)
print([(r['run'],r['status'],r['records'],r['clock_attempts']) for r in summary])
p=Path('docs/OPENVINS_CAPTURE_WIRE_LIFECYCLE_REPORT.md');s=p.read_text().replace('restoration and745 maintenance','restoration and746 maintenance');p.write_text(s)
with Path('.superpowers/sdd/2026-10-08-capture-wire-lifecycle/progress.md').open('a') as f:f.write('\nTask4: new reviewer spawn failed thread limit; reused completed independent review_wire_heartbeat seat, explicitly not fresh-context. Review range2c4f044..bd28908 whole plan. Independent raw audit verified all8 run segment hashes/absolute and per-source indices, normal25k callbacks and746 maintenance pairs; prose745 off-by-one self-corrected, original ledger entry preserved. No rerun needed for prose.\n')
