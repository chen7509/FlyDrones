import hashlib
import inspect
import json
from pathlib import Path
from pymavlink.dialects.v20 import common as mav
from tools.benchmark.openvins_timesync_wire import PinnedCodec

codec = PinnedCodec()
result = {'dialect_sha256': hashlib.sha256(Path(mav.__file__).read_bytes()).hexdigest(),
          'network': False, 'physics': False, 'messages': {}, 'sources': {}}
for name in ('command_long', 'command_ack', 'message_interval'):
    cls = getattr(mav, 'MAVLink_' + name + '_message')
    result['messages'][name] = dict(id=cls.id, fields=cls.fieldnames,
        crc=cls.crc_extra, constructor=str(inspect.signature(cls)))
result['commands'] = {name: getattr(mav, name) for name in (
    'MAV_CMD_GET_MESSAGE_INTERVAL', 'MAV_CMD_SET_MESSAGE_INTERVAL', 'MAV_RESULT_ACCEPTED')}
for name in ('mavlink_main.cpp', 'mavlink_receiver.cpp'):
    path = Path('results/openvins-timesync-interval-dev-1701') / name
    result['sources'][str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
print(json.dumps(result, indent=2))
