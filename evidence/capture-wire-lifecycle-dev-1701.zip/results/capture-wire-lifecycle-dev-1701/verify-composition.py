"""Focused offline composition verification; never invokes a physical harness."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent / 'composition-final-v1'
out.mkdir(exist_ok=False)
modules = [
    'test_openvins_timesync_continuation', 'test_openvins_maintenance_transport',
    'test_openvins_timesync_bootstrap', 'test_openvins_timesync_observer',
    'test_openvins_timesync_listener', 'test_openvins_listener_transport',
    'test_openvins_owned_bootstrap', 'test_openvins_owned_maintenance',
    'test_openvins_datagram_receive', 'test_openvins_simulation_clock',
]
wire = [
    'test_openvins_wire_maintenance', 'test_openvins_observed_maintenance',
    'test_openvins_wire_bootstrap', 'test_openvins_observed_wire_session',
    'test_openvins_timesync_wire', 'test_openvins_wire_heartbeat',
    'test_openvins_wire_fanout_integration',
]
source_names = [
    'openvins_timesync_bootstrap', 'openvins_timesync_maintenance', 'openvins_timesync_observer',
    'openvins_timesync_listener', 'openvins_listener_transport', 'openvins_owned_bootstrap',
    'openvins_wire_bootstrap', 'openvins_timesync_wire', 'openvins_datagram_receive',
    'openvins_observed_wire_session', 'openvins_ekf2_disarmed_preflight',
    'owned_daemon_connection', 'openvins_simulation_clock',
]
paths = ([f'tools/benchmark/{name}.py' for name in source_names]
         + [f'tests/benchmark/{name}.py' for name in modules + wire])


def hashes():
    return {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in paths}


def save(name, value):
    with (out / name).open('x', encoding='utf-8') as target:
        json.dump(value, target, indent=2)


before = hashes()
command = [sys.executable, '-m', 'pytest', *[f'tests/benchmark/{name}.py' for name in modules], '-q']
wsl_root = '/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility'
wire_command = ['wsl', '-e', 'sh', '-c',
                f'cd {wsl_root} && PYTHONPATH=src:. python3 -m unittest '
                + ' '.join('tests.benchmark.' + name for name in wire) + ' -q']
save('before.json', dict(sources=before, commands=[command, wire_command],
                        source_state='working tree, not a clean commit claim'))
environment = dict(os.environ, PYTHONPATH=os.pathsep.join([str(root / 'src'), str(root)]))
results = []
for name, cmd in [('pytest.txt', command), ('wsl-unittest.txt', wire_command)]:
    with (out / name).open('xb') as log:
        result = subprocess.run(cmd, cwd=root, env=environment, stdout=log, stderr=subprocess.STDOUT, timeout=120)
    results.append(result.returncode)
    print(name, 'exit', result.returncode, flush=True)
after = hashes()
save('after.json', dict(sources=after, unchanged=before == after, exit_codes=results,
                       actual_network=False, physical=False, estimator=False, fusion=False))
if any(results) or before != after:
    raise SystemExit('verification failed or selected source drift')
