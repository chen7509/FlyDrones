# Capture registration dependencies: cleanup and heartbeat effects

Scope: Task3 of the existing capture-wire lifecycle plan, inspected at bae8e6f.
No new estimator, simulator, network protocol or dependency installation.

## Sources and selection

- Existing CaptureJournal in disarmed_sensor_provenance.py sorts callbacks by
  increasing priority. Actual capture currently registers owned PX4 at20,
  heartbeat at40, receiver at50 and ULog at100. A restoration owner must register
  before20, and join its reader before descriptor/PX4 teardown. Those new
  registrations are not yet implemented by this checkpoint.
- Python context-manager semantics:
  https://docs.python.org/3.12/reference/datamodel.html#object.__exit__
  and interruption hierarchy:
  https://docs.python.org/3.12/library/exceptions.html#KeyboardInterrupt
  were read before implementation. The rolling documentation identifies3.12.15;
  the previously observed WSL interpreter is3.12.3, PSF license. No new installed
  version or upstream maintenance metadata is asserted. The relevant semantics
  are exercised directly by injected exception tests on the existing interpreter.
- Reuse CaptureJournal rather than replace it with ExitStack or a process manager:
  it already owns cleanup ordering and terminal capture evidence. Catch each
  BaseException during registered cleanup, retain the first interruption, attempt
  the remaining registered owners and terminal result, then re-raise interruption.
  Ordinary body/cleanup exceptions keep the prior capture_failed behavior.
  Exceptions while callbacks block cannot be preempted by this code; outer
  supervisor limits remain necessary. No new global process governance.
- Reuse actual CaptureWriter, existing heartbeat journal/fanout and runtime binding.
  Extract the capture side effects into dispatch_capture_heartbeat used by the
  existing reader now and available to the future wire reader. Keep the supplied
  arrival timestamp instead of obtaining another clock reading. Failed mapping or
  dispatch must not leave an unarmed freshness grant. This is not network/PID
  attribution or native estimator health qualification.
- Fixed PX4 d6f12ad BSD-3-Clause and pymavlink2.4.49 codec research from Task2
  remains applicable. No protocol/API changes or fresh maintenance claim here.

Cost: no additional runtime thread, external service or network operation in
these hooks. Cleanup remains proportional to registered owners, and heartbeat
dispatch reuses the existing queue/fanout. Actual wall-time overhead is unmeasured.
New tests create local evidence files and injected callbacks; WSL composition
uses the real pinned codec and fanout with fake UDP/native transport.

## Observed failures and limits

At the initial test run, cleanup KeyboardInterrupt escaped the narrower
SystemExit expectation and interrupted pytest; retain that output. The test was
corrected to catch either interruption and assert the original object, yielding
all11 explicit failing cases. Eight covered existing cleanup bugs and three
asserted the missing extracted sink. After implementation all11 passed.
An additional assertion exposed terminal-write failure leaving completed status
in memory; fixed and all12 passed. This does not make an unwriteable terminal
file durable: prior files remain unchanged and the error still propagates.

Three added actual-codec/fanout cases are coverage, not initial RED fixes. One
initial expectation incorrectly assumed CaptureWriter.error latches queue-full;
the existing submit path raises synchronously and fanout records the failure.
Corrected the test to assert that failure and the preserved first queued record,
without changing writer behavior or hiding the earlier failed assertion.

Task3 complete injected capture runner, sole-reader selection, one PostUpdate
clock registration, maintenance and restoration-before-PX4-stop integration still
remain. These hooks alone do not fulfill those gates or authorize a live study.
