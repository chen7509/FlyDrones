from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path.cwd(); base=Path('results/capture-wire-lifecycle-dev-1701'); output=Path('evidence/capture-wire-lifecycle-dev-1701.zip')
a=json.loads((base/'capture-review-final-v2/after.json').read_text());assert a['unchanged'] and a['exit_codes']==[0,0,0,0]
for name,digest in a['sources'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
selected=set(p for p in base.rglob('*') if p.is_file())
selected.update(Path(p) for p in a['sources'])
selected.update([Path('docs/OPENVINS_CAPTURE_WIRE_LIFECYCLE_REPORT.md'),Path('docs/superpowers/specs/2026-10-08-capture-wire-lifecycle-design.md'),Path('docs/superpowers/plans/2026-10-08-capture-wire-lifecycle.md'),Path('.superpowers/sdd/2026-10-08-capture-wire-lifecycle/review-2c4f044..bd28908.diff')])
manifest={'producer_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'offline wire lifecycle; no CLI preparation/network/physics/native estimator/fusion','files':[]}
with zipfile.ZipFile(output,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(selected):
  raw=p.read_bytes();h=hashlib.sha256(raw).hexdigest();name=p.as_posix()
  z.writestr(name,raw);manifest['files'].append({'name':name,'bytes':len(raw),'sha256':h})
 z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(output) as z:
 assert z.testzip() is None
 assert set(z.namelist())=={m['name'] for m in manifest['files']}|{'manifest.json'}
 for m in manifest['files']:
  raw=z.read(m['name']);assert len(raw)==m['bytes'] and hashlib.sha256(raw).hexdigest()==m['sha256']
result={'path':output.as_posix(),'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'bytes':output.stat().st_size,'members':len(manifest['files'])+1,'all_member_hashes_and_crc_verified':True,'producer_commit':manifest['producer_commit']}
with (base/'stage-seal.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(result))
