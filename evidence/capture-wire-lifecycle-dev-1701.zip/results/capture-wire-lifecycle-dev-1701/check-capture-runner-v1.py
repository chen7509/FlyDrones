import hashlib,json
from pathlib import Path
p=Path('results/capture-wire-lifecycle-dev-1701/capture-runner-final-v1')
a=json.loads((p/'after.json').read_text());b=json.loads((p/'before.json').read_text())
assert a['unchanged'] and a['exit_codes']==[0,0,0,0]
assert a['sources']==b['sources']
for name,digest in a['sources'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
assert '315 passed' in (p/'pytest.txt').read_text()
assert 'Ran 129 tests' in (p/'wsl-unittest.txt').read_text(errors='replace')
print('Current39 hashes match completed315pytest/129WSL/Ruff/diff verification')
