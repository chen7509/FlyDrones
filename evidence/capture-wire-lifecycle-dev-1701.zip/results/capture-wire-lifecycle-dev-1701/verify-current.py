"""Bounded current Python contract regression; no physical or network harness."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent / 'final-v1'
out.mkdir(exist_ok=False)
modules = [
    'tests/benchmark/test_openvins_timesync_continuation.py',
    'tests/benchmark/test_openvins_maintenance_transport.py',
    'tests/benchmark/test_openvins_timesync_bootstrap.py',
    'tests/benchmark/test_openvins_timesync_observer.py',
    'tests/benchmark/test_openvins_timesync_listener.py',
    'tests/benchmark/test_openvins_listener_transport.py',
    'tests/benchmark/test_openvins_owned_bootstrap.py',
]
sources = modules + [
    'tools/benchmark/openvins_timesync_bootstrap.py',
    'tools/benchmark/openvins_timesync_maintenance.py',
    'tools/benchmark/openvins_timesync_observer.py',
    'tools/benchmark/openvins_timesync_listener.py',
    'tools/benchmark/openvins_listener_transport.py',
    'tools/benchmark/openvins_owned_bootstrap.py',
    'tools/benchmark/openvins_ekf2_disarmed_preflight.py',
    'tools/benchmark/owned_daemon_connection.py',
]
def hashes():
    return {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in sources}
def save(name, value):
    with (out / name).open('x', encoding='utf-8') as target:
        json.dump(value, target, indent=2)
before = hashes()
command = [sys.executable, '-m', 'pytest', *modules, '-q']
save('before.json', dict(sources=before, command=command, source_state='working tree, not a clean-commit claim'))
environment = dict(os.environ, PYTHONPATH=os.pathsep.join([str(root/'src'), str(root)]))
with (out/'pytest.txt').open('x', encoding='utf-8') as log:
    result = subprocess.run(command, cwd=root, env=environment, stdout=log, stderr=subprocess.STDOUT, timeout=120)
after = hashes()
save('after.json', dict(sources=after, unchanged=before == after, exit_code=result.returncode,
                        actual_network=False, physical=False, fusion=False))
print((out/'pytest.txt').read_text()[-500:])
if result.returncode or before != after:
    raise SystemExit('verification failed or selected source drift')
