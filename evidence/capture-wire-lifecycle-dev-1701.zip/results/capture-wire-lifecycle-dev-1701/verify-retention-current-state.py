"""Verify just-completed test evidence against unchanged selected source; no rerun."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[2]
evidence = Path(__file__).resolve().parent / 'retention-final-v1'
before = json.loads((evidence / 'before.json').read_text())
after = json.loads((evidence / 'after.json').read_text())
assert before['sources'] == after['sources'] and after['unchanged']
assert after['exit_codes'] == [0, 0, 0]
assert len(after['sources']) == 35
for path, expected in after['sources'].items():
    assert hashlib.sha256((root / path).read_bytes()).hexdigest() == expected, path
assert '643 passed' in (evidence / 'pytest.txt').read_text()
assert 'Ran 133 tests' in (evidence / 'wsl-unittest.txt').read_text(errors='replace')
assert (evidence.parent / 'full-capacity-v2/summary.json').is_file()
print('Current35 source hashes match just-completed643 pytest/133 WSL/full-quota results; no test rerun.')
