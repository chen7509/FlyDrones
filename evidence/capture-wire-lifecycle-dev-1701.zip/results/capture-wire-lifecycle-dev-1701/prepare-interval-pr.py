import json
from pathlib import Path

root = Path(__file__).resolve().parent
before = json.loads((root / 'pr-interval-before.json').read_text(encoding='utf-8-sig'))
assert before['draft'] and before['head'] == 'c9303e2ddcc58fbf2e59968f1e7291c89e1625a9'
old = before['body']
heading = '## Continuous capture lifecycle — Task1 complete, integration still incomplete'
assert old.startswith(heading)
new = '''## Continuous capture lifecycle — Task1 complete, Task2 partial

Latest c9303e2 checkpoint adds pinned GET/SET interval encoding, strict ACK/interval normalization, and a nonblocking IntervalExchange phase core. One pending operation, independent readbacks,2s operation/8s startup and one10s cleanup window retain ambiguous write ownership and primary/restoration failures. ACK and interval may arrive in either order. No command nonce/authentication is invented and no ambiguous mutation retry is allowed.

71 focused pytest and123 installed-codec WSL regression tests pass on20 unchanged pre/post source hashes; changed Ruff/diff pass. Tests include mixed heartbeat/response frames, lost ACK, partial replies, deadline crossing, changed identity, repeated stop, interruption and terminal failure evidence. Initial and subsequent failing cases are retained. These are injected transport/clock tests, not actual network or physics performance.

Task2 remains OPEN: actual Observed/Owned receive-owner binding must supply the shared sequence, identity/descriptor guards, heartbeat servicing and restricted cleanup transport. Task3 actual capture registration and Task4 final independent review/archive also remain open. The supplied phase core does not prove these missing integrations. No real UDP, PX4, Gazebo, estimator, ODOMETRY, EKF2, arming or training ran; fusion remains false.

### Earlier Task1 checkpoint
'''
with (root / 'pr-interval-patch.json').open('x', encoding='utf-8') as stream:
    json.dump({'body': new + old[len(heading):]}, stream)
