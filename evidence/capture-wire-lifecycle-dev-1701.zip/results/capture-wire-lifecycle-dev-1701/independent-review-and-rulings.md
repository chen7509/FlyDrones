# Whole-plan independent review

Review range: 2c4f044f3f4324177ca5b305b506a2cb3e7bb470..bd28908a7bddcf2742da880f8ca6506c7035ed80.
Requested new isolated reviewer failed with agent thread limit. Reused the completed
independent review_wire_heartbeat seat; do not call this a fresh-context review.
The reviewer inspected artifacts/read-only offline counterexamples and changed no files.

Verdict: no Critical, five Important, one Minor. Accepted all findings after code inspection
and local reproduction. Important counterexamples are retained in review-red-v1.txt;
this ran five tests with six assertion failures (the mixed-datagram case has two variants).
An additional duplicate-ACK batch failed in review-batch-red-v1.txt. The first focused
repair verification review-green-v1.txt ran six tests successfully. Later added clock and
other return-record cases are GREEN coverage, not claimed observed production REDs.

1. health_ready granted a correlated but rejected high-RTT maintenance sample.
   Fix: expose last-observer accepted state and require it, including during pending pairs.
2. Armed heartbeat refusal left cached unarmed restoration permission alive.
   Fix: revoke cached permission and latch safety refusal, preventing restoration sends.
3. Interval mode dispatched heartbeat and fed responses before checking mixed TIMESYNC.
   Fix: validate request identity/multiplicity/clock/encoding, heartbeat and response batch
   before dispatch. Batch preview reuses existing bounded feed state/rules and cannot send;
   actual feed still checks live time. A private clock preview does not consume its lane.
4. Ordinary segmented close failures returned/latching without capture failure.
   Fix: driver inspects terminal session failure; owner inspects retention failure and
   records it in capture errors before CaptureJournal writes terminal status.
5. Byte quota rejected a completed send_return before retaining its bounded failed record.
   Fix: retain the single in-flight record before byte quota refusal, without expanding
   quota or claiming successful persistence. Applied to all channel append return records.

Minor: report opening incorrectly said reader selection remained unchanged.
Fixed opening status and explicitly marked earlier sections historical. Self-audit also
corrected745 to746 maintenance pairs using actual retained normal records.

Declined-to-judge rulings: full CLI preparation, actual descriptor/process provenance,
ACK timing/rate, PX4 convergence, live sensor/native concurrency, physics, hardware and
flight are outside this offline implementation. Accept these exclusions only as unverified
future gates, not completion grants. Existing simulation-domain, hardware and swarm
limitations remain. No new actual UDP/PX4/Gazebo/OpenVINS/ODOMETRY/EKF2 operation.
