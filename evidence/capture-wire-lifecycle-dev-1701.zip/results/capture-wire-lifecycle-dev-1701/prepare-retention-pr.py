import json
from pathlib import Path

root = Path(__file__).resolve().parent
before = json.loads((root / 'pr-retention-before.json').read_text(encoding='utf-8-sig'))
assert before['draft'] and before['head']['sha'] == 'ad8a266a9f49e2d69200787e163904726283cce0'
marker = '## Heartbeat wire and journaled capture integration (offline)'
assert before['body'].count(marker) == 1
prefix = '''## Continuous capture lifecycle — Task1 complete, integration still incomplete

One supplied receive stack now continues from the finite cold TIMESYNC bootstrap into bounded maintenance without replacing its codec, sequence, filter, identities or independent clock. The original8s bootstrap and2s health gates remain; one4096-record maintenance subscription uses the exact prior boundary snapshot. Total capture remains bounded by original-start+300s. Legacy defaults are unchanged.

Opt-in shared segmented retention bounds ten evidence channels to64x8192 events and512MiB of JSONL record bytes. Completed members flush/close/hash-check; indexes and refusal records preserve partial writes and cleanup failures. No discarded history is counted as successful retention, no fsync or constant-memory claim is made for the entire application. Datagram drafts preserve actual returned bytes if clock/publication fails.

Validation at ad8a266:643 focused pytest,133 installed-codec WSL unittest, plus full quota tests (524288 records across64 members; separate535881392-byte case refusing the next record). All35 selected source/test hashes matched before/after. Changed Ruff and diff checks pass. These tests use injected transports and synthetic clocks, not actual network or simulation performance; no new whole-repository pass is claimed.

Task2 nonblocking interval mutation/restoration, Task3 actual capture registration and injected runner validation, and Task4 independent whole-plan review/archive remain open. Actual capture reader registration is unchanged. No actual UDP, physics, estimator, training, ODOMETRY, EKF2 or arming operation ran. Network/live/fusion authority remains false. See docs/OPENVINS_CAPTURE_WIRE_LIFECYCLE_REPORT.md and its linked plan.

'''
with (root / 'pr-retention-patch.json').open('x', encoding='utf-8') as stream:
    json.dump({'body': prefix + before['body'][before['body'].index(marker):]}, stream)
