import json
from pathlib import Path

root = Path(__file__).resolve().parent
before = json.loads((root / 'pr-composition-before.json').read_text(encoding='utf-8-sig'))
assert before['draft'] and before['head']['sha'] == 'd0ec0dcec8ca02ee49053d8777d465932bb3d43a'
old = before['body']
marker = '## Heartbeat wire and journaled capture integration (offline)'
assert old.startswith('## Continuous capture lifecycle') and old.count(marker) == 1
body = '''## Continuous capture lifecycle — partial implementation

The supplied receive stack can now explicitly continue after the finite cold TIMESYNC bootstrap instead of stopping at sample500. OwnedBootstrap, OwnedWireBootstrap, ObservedWireSession and the datagram receiver retain one codec/sequence, filter, request identities and independent simulation clock. The transition must finish inside the original8s; maintenance then has an absolute original-start+300s maximum and unchanged2s progress/source limits. Legacy terminal defaults remain unchanged.

One fourth,4096-record read-only listener requires the exact previous boundary snapshot without counting it as a new sample. Heartbeats can be delivered while a maintenance status is pending, but another TIMESYNC request cannot replace its reservation. Cancellation retains pending/partial-byte evidence and journal/close/interruption failures; cleanup journaling does not reopen ordinary I/O, and it is not proof of daemon exit. The caller retains ownership of the datagram socket.

Current focused validation for d0ec0dc:627 pytest passed and130 installed-codec WSL unittest passed;30 selected source/test hashes remained unchanged before/after, changed Ruff/diff pass. The observed integration case uses one injected receiver for505 TIMESYNC and5 heartbeat datagrams, preserves reply sequence after sample500, and crosses8s only after a valid handoff. Late/repeated transitions, lost status, stale source, replay, descriptor changes and partial cancellation are covered. These are real components/codecs with synthetic clocks and injected transport, not measured network/PX4 performance. Initial failures remain in the evidence directory; no fresh whole-repository pass is claimed.

Task1 remains open for lifecycle-only segmented retention. Nonblocking interval mutation/restoration, actual capture registration, injected runner end-to-end validation, final independent whole-plan review and the stage evidence archive remain outstanding. The actual capture reader/socket registration is unchanged. See `docs/OPENVINS_CAPTURE_WIRE_LIFECYCLE_REPORT.md` and `docs/superpowers/plans/2026-10-08-capture-wire-lifecycle.md`. No actual UDP, physics, estimator, training, ODOMETRY, EKF2 or arming operation was executed; network/live/fusion authority remains false.

'''
with (root / 'pr-composition-patch.json').open('x', encoding='utf-8') as stream:
    json.dump(dict(body=body + old[old.index(marker):]), stream)
