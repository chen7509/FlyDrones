import json
from pathlib import Path

root = Path(__file__).resolve().parent
before = json.loads((root / 'pr-observed-interval-before.json').read_text(encoding='utf-8-sig'))
assert before['draft'] and before['head'] == '8f388e25e4026286a5adfa57ceac77d5a0d55c05'
marker = '### Earlier Task1 checkpoint'
assert before['body'].count(marker) == 1
prefix = '''## Continuous capture lifecycle — normal receive-owner integration

Latest8f388e2 binds the interval phase core into the actual ObservedWireSession/OwnedWireBootstrap/TimesyncWireResponder composition through an opt-in constructor. Normal baseline/apply/readback,500 synchronized replies and restore/final readback share one receiver, codec, supplied socket and outgoing sequence. Listener completion alone does not grant readiness: restoration must finish within the original8s before maintenance. Heartbeats remain serviced during command and listener waits. Legacy defaults and the actual capture CLI/runner remain unchanged.

72 focused pytest and153 installed-codec WSL tests pass;24 selected production/test hashes match before/after, changed Ruff/diff pass. The normal injected-socket case sends six commands,500 bootstrap replies and one maintenance reply with contiguous modulo256 sequence, while delivering six heartbeats. Tests also cover phase wait behavior, unchanged one-pending-reply gate, invalid ACK/armed input, changed descriptor/owner, short/late sends and final readback mismatch. These are actual Python components/codecs with injected I/O, not real network or physical performance. Initial errors/failures are retained honestly, including the scalar-progress test that first ran GREEN and was subsequently verified by explicit backout.

Task2 is NOT complete: normal wrapper failures still close listeners/refuse I/O, so the phase core's10s cleanup semantics do not yet prove owner-bound restoration after source failure or startup expiry. That explicit restricted path must keep the original failure latched, allow only baseline restoration traffic on the same descriptor, enforce identity/clock/safety bounds and retain incomplete cleanup. Do not clear failures or enable a physical study based on normal-path tests. Task3 actual capture registration and Task4 final independent review/archive remain outstanding.

No actual UDP/PX4/Gazebo/OpenVINS, ODOMETRY/EKF2, arming or training ran; fusion remains false. See docs/OPENVINS_CAPTURE_WIRE_LIFECYCLE_REPORT.md and its linked spec/plan.

'''
with (root / 'pr-observed-interval-patch.json').open('x', encoding='utf-8') as stream:
    json.dump({'body': prefix + before['body'][before['body'].index(marker):]}, stream)
