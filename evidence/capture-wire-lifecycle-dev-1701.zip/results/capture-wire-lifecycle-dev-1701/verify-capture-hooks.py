"""Verify changed capture hooks without invoking capture main or physical factories."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent / 'capture-hooks-final-v1'
out.mkdir(exist_ok=False)
pytests = ['test_capture_wire_hooks', 'test_disarmed_sensor_provenance', 'test_capture_contract',
           'test_runtime_resource_binding', 'test_physics_substep_trace', 'test_native_runtime_refusal',
           'test_ready_shadow_fanout', 'test_journaled_heartbeat_lane', 'test_estimator_aware_readiness']
wire = ['test_openvins_wire_fanout_integration', 'test_openvins_wire_heartbeat',
        'test_openvins_observed_interval', 'test_openvins_observed_restoration']
production = ['capture_disarmed_sensors', 'disarmed_sensor_provenance', 'capture_contract',
              'openvins_observed_wire_session', 'openvins_timesync_wire', 'openvins_timesync_interval',
              'openvins_datagram_receive', 'journaled_heartbeat_lane', 'ready_shadow_fanout',
              'estimator_aware_readiness', 'runtime_resource_binding', 'openvins_online_shadow']
paths = [f'tools/benchmark/{p}.py' for p in production] + [f'tests/benchmark/{p}.py' for p in pytests + wire]

def hashes():
    return {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in paths}

def save(name, value):
    with (out / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)

commands = [
    [sys.executable, '-m', 'pytest', *[f'tests/benchmark/{p}.py' for p in pytests], '-q'],
    ['wsl', '-e', 'sh', '-c', 'cd /mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility && '
     'PYTHONPATH=src:. python3 -m unittest ' + ' '.join('tests.benchmark.' + p for p in wire) + ' -q'],
    [sys.executable, '-m', 'ruff', 'check', 'tools/benchmark/capture_disarmed_sensors.py',
     'tools/benchmark/disarmed_sensor_provenance.py', 'tests/benchmark/test_capture_wire_hooks.py',
     'tests/benchmark/test_openvins_wire_fanout_integration.py'],
    ['git', 'diff', '--check'],
]
before = hashes()
save('before.json', dict(sources=before, commands=commands))
env = dict(os.environ, PYTHONPATH=os.pathsep.join([str(root / 'src'), str(root)]))
codes = []
for name, command in zip(['pytest.txt', 'wsl-unittest.txt', 'ruff.txt', 'diff.txt'], commands, strict=True):
    with (out / name).open('xb') as stream:
        completed = subprocess.run(command, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=120)
    codes.append(completed.returncode)
    print(name, completed.returncode, flush=True)
after = hashes()
save('after.json', dict(sources=after, unchanged=before == after, exit_codes=codes,
                       actual_capture=False, actual_network=False, physics=False, estimator=False, fusion=False))
if any(codes) or before != after:
    raise SystemExit('verification failed or selected source drift')
