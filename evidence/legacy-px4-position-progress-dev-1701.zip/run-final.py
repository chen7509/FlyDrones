import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent / "final-run-v1"
out.mkdir()
files = [
    "src/flydrones/drones/mavlink.py", "src/flydrones/runtime.py", "src/flydrones/sitl_swarm.py",
    "tests/test_mavlink_position_freshness.py",
]
before = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in files}
for name in files:
    target = out / "sources" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root / name, target)
env = os.environ.copy()
env["PYTHONPATH"] = str(root / "src")
origins = subprocess.run([
    sys.executable, "-c",
    "import json,flydrones.drones.mavlink as m,flydrones.runtime as r,flydrones.sitl_swarm as s;"
    "print(json.dumps({'mavlink':m.__file__,'runtime':r.__file__,'swarm':s.__file__}))",
], cwd=root, env=env, check=True, capture_output=True, text=True).stdout
expected = [root / name for name in files[:3]]
if [Path(value).resolve() for value in json.loads(origins).values()] != expected:
    raise RuntimeError("wrong candidate imports")
(out / "module-origins.json").write_text(origins, encoding="utf-8")
commands = {
    "targeted": [sys.executable, "-m", "pytest", "-q", "tests/test_mavlink_position_freshness.py",
                 "tests/test_control.py", "tests/test_distributed_px4.py", "tests/test_sim_and_cli.py"],
    "ruff": [sys.executable, "-m", "ruff", "check", *files],
    "diff": ["git", "diff", "--check"],
}
records = []
for name, command in commands.items():
    started = time.monotonic()
    result = subprocess.run(command, cwd=root, env=env, capture_output=True, text=True, timeout=180)
    (out / f"{name}.txt").write_text(result.stdout + result.stderr, encoding="utf-8")
    records.append({"name": name, "command": command, "returncode": result.returncode,
                    "elapsed_wall_s": time.monotonic() - started})
    print(name, result.returncode, result.stdout.strip()[-1000:])
after = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in files}
record = {"base_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(),
          "python": sys.version, "pythonpath": env["PYTHONPATH"], "source_before": before,
          "source_after": after, "sources_unchanged": before == after, "commands": records,
          "physical_or_training_processes_started": False}
(out / "execution.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
if before != after or any(item["returncode"] for item in records):
    raise RuntimeError("candidate validation failed")
