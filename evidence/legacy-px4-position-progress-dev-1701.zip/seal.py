import hashlib
import json
from pathlib import Path
import shutil
import zipfile

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
execution = json.loads((out / "final-run-v1/execution.json").read_text())
if not execution["sources_unchanged"] or any(item["returncode"] for item in execution["commands"]):
    raise RuntimeError("failed final validation")
for name, digest in execution["source_after"].items():
    if hashlib.sha256((root / name).read_bytes()).hexdigest() != digest:
        raise RuntimeError("candidate drift after validation")
docs = ["docs/LEGACY_PX4_POSITION_PROGRESS_REPORT.md",
        "docs/superpowers/specs/2026-10-12-legacy-px4-position-progress-design.md",
        "docs/superpowers/plans/2026-10-12-legacy-px4-position-progress.md"]
for name in docs:
    target = out / "documents" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root / name, target)
members = {}
for path in sorted(out.rglob("*")):
    if not path.is_file():
        continue
    relative = path.relative_to(out)
    if relative.parts[0] == "baseline-tree" or path.name in ("seal.json", "pr65-before.json", "manifest.json"):
        continue
    if path.is_symlink():
        raise RuntimeError("linked evidence")
    members[relative.as_posix()] = path.read_bytes()
manifest = {name: {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)} for name, data in members.items()}
manifest_bytes = json.dumps({"schema": "flydrones-legacy-px4-position-progress-evidence-v1", "members": manifest}, indent=2).encode()
members["manifest.json"] = manifest_bytes
(out / "manifest.json").write_bytes(manifest_bytes)
archive = root / "evidence/legacy-px4-position-progress-dev-1701.zip"
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as contents:
    for name, data in members.items():
        contents.writestr(name, data)
with zipfile.ZipFile(archive) as contents:
    if contents.testzip() is not None or set(contents.namelist()) != set(members):
        raise RuntimeError("ZIP CRC/member mismatch")
    for name, data in members.items():
        if contents.read(name) != data:
            raise RuntimeError("ZIP member mismatch")
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
checksum = archive.with_suffix(".sha256")
with checksum.open("x", encoding="ascii") as handle:
    handle.write(f"{digest}  {archive.name}\n")
record = {"path": str(archive), "sha256": digest, "bytes": archive.stat().st_size,
          "members": len(members), "crc_verified": True, "all_member_bytes_verified": True,
          "source_hashes_match_final_validation": True}
(out / "seal.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
print(json.dumps(record, indent=2))
