import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
baseline = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
archive = out / "baseline-src.tar"
subprocess.run(["git", "archive", "--format=tar", f"--output={archive}", baseline, "src"], cwd=root, check=True)
destination = out / "baseline-tree"
destination.mkdir()
with tarfile.open(archive) as contents:
    for member in contents.getmembers():
        if member.name.startswith("/") or ".." in Path(member.name).parts or member.issym() or member.islnk():
            raise RuntimeError("unsafe baseline archive member")
    contents.extractall(destination, filter="data")
env = os.environ.copy()
env["PYTHONPATH"] = str(destination / "src")
origin = subprocess.run(
    ["python", "-c", "import flydrones.drones.mavlink as m;print(m.__file__)"],
    cwd=root, env=env, capture_output=True, text=True, check=True,
).stdout.strip()
if Path(origin).resolve() != (destination / "src/flydrones/drones/mavlink.py").resolve():
    raise RuntimeError("wrong baseline import")
command = ["python", "-m", "pytest", "-q", "tests/test_mavlink_position_freshness.py"]
result = subprocess.run(command, cwd=root, env=env, capture_output=True, text=True, timeout=60)
(out / "baseline-behavioral-red.txt").write_text(result.stdout + result.stderr, encoding="utf-8")
record = {
    "base_commit": baseline, "command": command, "pythonpath": env["PYTHONPATH"],
    "actual_module": origin, "returncode": result.returncode,
    "archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
    "tests_sha256": hashlib.sha256((root / command[-1]).read_bytes()).hexdigest(),
    "expected_failure": True, "physical_processes_started": False,
}
(out / "baseline-behavioral-red.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
print(json.dumps(record, indent=2))
if result.returncode != 1:
    raise RuntimeError("baseline did not produce expected behavioral failure")
