"""Offline consistency checks on the completed installed startup-only study."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
STUDY = HERE / 'study-v1'
CAPTURE = STUDY / 'startup-preflight-v1'
ROOT = HERE.parents[1]
load = lambda p: json.loads(p.read_text(encoding='utf-8'))
manifest = load(STUDY / 'study-manifest.json')
dispatch = load(STUDY / 'dispatch.json')
completion = load(STUDY / 'completion.json')
result = load(CAPTURE / 'result.json')
supervisor = load(CAPTURE / 'supervisor.json')
before = load(CAPTURE / 'runtime-binding-pre.json')
after = load(CAPTURE / 'runtime-binding-post.json')
binding = load(STUDY / 'runtime-binding-v3.json')
execution = load(STUDY / 'execution-contract.json')
launch = load(CAPTURE / 'launch.json')
source = ROOT / 'results/openvins-ekf2-fast-grid-physical-dev-1701/development-seed-27601'
source_execution = load(source / 'execution-contract.json')
assert dispatch['manifest']['sha256'] == hashlib.sha256((STUDY/'study-manifest.json').read_bytes()).hexdigest()
assert dispatch['executor']['sha256'] == hashlib.sha256((HERE/'execute_once.py').read_bytes()).hexdigest()
assert manifest['command'] == dispatch['command'] and dispatch['command'].count('--startup-preflight') == 1
assert '--worker' not in dispatch['command']
assert dispatch['head'] == manifest['implementation_head'] == '600ada0aab1cf12e84d7a9078d3f6295353dc388'
assert result['status'] == 'capture_completed' and result['errors'] == []
assert result['estimator_run'] is False and result['startup_preflight_completed'] is True
assert result['runtime_binding']['phases'] == ['postgraph', 'bootstrap']
assert result['runtime_binding']['owned_phases'] == {'px4': [], 'openvins': []}
assert before['files'] == after['files'] and len(before['files']) == 594
assert before['declaration'] == binding and len(binding['baseline']['files']) == 575
for row in before['files']:
    data = Path(row['requested']).read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
for record in manifest['files']:
    assert hashlib.sha256(Path(record['requested']).read_bytes()).hexdigest() == record['sha256']
for key in ('wall_budget_s', 'supervisor_s', 'simulation_duration_ns', 'physics_step_ns', 'imu_hz', 'rgbd_hz',
            'rgbd_size', 'profiles', 'inputs', 'reference_sha256', 'simulation_seed', 'launch_environment'):
    assert execution[key] == source_execution[key]
assert launch['execution_contract'] == execution
assert load(CAPTURE/'execution-environment-worker.json')['matches'] is True
assert load(CAPTURE/'trajectory-gauge-policy-worker.json')['matches_declaration'] is True
wire = load(STUDY/'wire-config.json')
assert execution['wire']['configuration'] == wire
assert execution['wire']['sha256'] == hashlib.sha256((STUDY/'wire-config.json').read_bytes()).hexdigest()
assert str(STUDY/'wire-config.json') in before['required_paths']
queries = [load(p) for p in sorted(CAPTURE.glob('resource-query-*.json'))]
assert len(queries) == 40 and all(q['returncode'] == 0 and q['error'] is None for q in queries)
assert all(q['command'][0] == binding['inventory']['graph:resolver'][0] for q in queries)
graph = load(CAPTURE/'resource-graph.json')
assert len(graph['edges']) == 46 and graph['errors'] == [] and graph['local_file_graph_verified'] is True
journal = [json.loads(line) for line in (STUDY/'startup-preflight-v1.supervisor-events.jsonl').read_text().splitlines()]
assert len(journal) == 7 and journal == supervisor['cleanup']['events']
assert not any(e['event'].startswith('signal') for e in journal)
assert supervisor['worker_exit'] == 0 and completion['returncode'] == 0 and completion['launcher_error'] is None
assert supervisor['cleanup']['group_absent'] is True
assert supervisor['cleanup']['no_executing_members'] is True
assert supervisor['cleanup']['sigkill_dispatched'] is False
assert dispatch['resources_before'] == [] and completion['resources_after'] == []
assert not any((CAPTURE/name).exists() for name in
               ('process.json','px4.log','events.jsonl','px4-ulog-manifest.json','simulation-random-seed.json','shadow','wire'))
for key in ('physical_execution_qualified','vio_accuracy_qualified','estimator_health_qualified',
            'fusion_eligible','flight_ready','eligible_for_vio_input','eligible_for_px4_fusion'):
    assert result[key] is False
assert load(STUDY/'audit.json')['failures'] == []
summary = dict(schema='installed-wire-startup-direct-check-v1', passed=True,
    declared_files=575, pre_post_files=594, checked_queries=40, resource_edges=46, supervisor_events=7,
    startup_wall_s=(completion['ended_wall_ns']-dispatch['started_wall_ns'])/1e9,
    installed_startup_preflight_qualified=True, live_wire_qualified=False,
    physical_execution_qualified=False, fusion_eligible=False, syscall_trace_available=False)
with (STUDY/'direct-check.json').open('x') as out:
    json.dump(summary,out,indent=2)
print(json.dumps(summary,indent=2))
