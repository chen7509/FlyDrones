"""One-off prospective installed preflight preparation; never starts a capture."""
import copy
import hashlib
import json
import shutil
import sys
import zipfile
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / 'src')]

from tools.benchmark import openvins_online_shadow  # noqa: F401,E402
from tools.benchmark.capture_contract import declared_command, derive_launch_environment, execution_contract, read_declaration  # noqa: E402
from tools.benchmark.capture_disarmed_sensors import active_resources, parse_capture_args  # noqa: E402
from tools.benchmark.declared_runtime_snapshot import file_record, snapshot, write_manifest  # noqa: E402
from tools.benchmark.estimator_aware_readiness_preflight import _add_missing  # noqa: E402
from tools.benchmark.runtime_resource_binding import validate_binding  # noqa: E402

HERE = Path(__file__).resolve().parent
SOURCE = ROOT / 'results/openvins-ekf2-fast-grid-physical-dev-1701/development-seed-27601'
ARCHIVE = ROOT / 'evidence/openvins-ekf2-file-shadow-dev-1701.zip'
ARCHIVE_SHA = 'd834874a46f8eedb6c2a0518036aa08dbe26a92ceeeacc8c1a8a9730bb77bdae'
STUDY = HERE / 'study-v1'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def prepare():
    if active_resources():
        raise ValueError('competing resources')
    STUDY.mkdir(exist_ok=False)
    version = read_declaration(HERE / 'committed-source.json')
    if version['tracked_worktree_clean'] is not True:
        raise ValueError('uncommitted tracked code')
    if digest(ARCHIVE) != ARCHIVE_SHA:
        raise ValueError('source archive changed')
    source_records = {}
    with zipfile.ZipFile(ARCHIVE) as sealed:
        if sealed.testzip() is not None:
            raise ValueError('source archive CRC')
        rows = {r['path']: r for r in json.loads(sealed.read('MANIFEST.json'))['members']}
        for name in ('runtime-binding-v3.json', 'execution-contract.json', 'study-manifest.json'):
            path = SOURCE / name
            member = str(path.relative_to(ROOT))
            data = path.read_bytes()
            if data != sealed.read(member) or hashlib.sha256(data).hexdigest() != rows[member]['sha256']:
                raise ValueError('source member changed: ' + name)
            source_records[name] = file_record(path)
    original = validate_binding(read_declaration(SOURCE / 'runtime-binding-v3.json'))
    source_execution = read_declaration(SOURCE / 'execution-contract.json')
    current = snapshot(original['inventory'])
    old = {r['requested']: r for r in original['baseline']['files']}
    changes = []
    for row in current['files']:
        prior = old[row['requested']]
        if row['sha256'] == prior['sha256'] and row['bytes'] == prior['bytes']:
            continue
        path = Path(row['requested'])
        relative = str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else None
        accepted = bool(relative and relative.endswith('.py') and relative in version['source_sha256']
                        and row['sha256'] == version['source_sha256'][relative])
        changes.append(dict(path=row['requested'], role=row['role'], before=prior['sha256'],
                            after=row['sha256'], accepted_committed_python_source=accepted))
    write_manifest(STUDY / 'source-drift.json', dict(changes=changes,
                   unexpected=[r for r in changes if not r['accepted_committed_python_source']]))
    if any(not r['accepted_committed_python_source'] for r in changes):
        raise ValueError('non-code input changed; no automatic rebaseline')
    policy = STUDY / 'trajectory-gauge-policy.json'
    source_policy = SOURCE / 'trajectory-gauge-policy.json'
    if digest(source_policy) != source_execution['trajectory_gauge_policy']['sha256']:
        raise ValueError('source trajectory policy changed')
    shutil.copy2(source_policy, policy)
    wire = STUDY / 'wire-config.json'
    write_manifest(wire, dict(schema='capture-wire-v1', session_id='installed-startup-v1-unused-clock',
                             sim_origin_ns=0, remote_origin_ns=0))
    declared = copy.deepcopy(original)
    loaded = sorted({str(Path(m.__file__).resolve()) for m in tuple(sys.modules.values())
                     if getattr(m, '__file__', None) and Path(m.__file__).resolve().is_relative_to(ROOT)})
    _add_missing(declared['inventory'], 'runtime:current-preflight-imports', loaded)
    _add_missing(declared['inventory'], 'runtime:preflight-wire-declaration', [wire])
    declared['baseline'] = snapshot(declared['inventory'])
    declared = validate_binding(declared)
    binding_path = STUDY / 'runtime-binding-v3.json'
    execution_path = STUDY / 'execution-contract.json'
    values = dict(output=STUDY / 'startup-preflight-v1', worker=False, startup_preflight=True,
                  execution_contract=execution_path, runtime_binding=binding_path,
                  trajectory_gauge_policy=policy, wire_config=wire,
                  simulation_seed=source_execution['simulation_seed'], reference_sha256=source_execution['reference_sha256'])
    values.update({k: Path(v) if v is not None else None for k, v in source_execution['inputs'].items()})
    values.update(source_execution['profiles'])
    args = SimpleNamespace(**values)
    launch_env = derive_launch_environment(declared)
    execution = execution_contract(args, launch_env)
    for key in ('wall_budget_s', 'supervisor_s', 'simulation_duration_ns', 'physics_step_ns', 'imu_hz', 'rgbd_hz', 'rgbd_size',
                'profiles', 'inputs', 'reference_sha256', 'simulation_seed', 'launch_environment'):
        if execution[key] != source_execution[key]:
            raise ValueError('unchanged execution field drift: ' + key)
    write_manifest(binding_path, declared)
    write_manifest(execution_path, execution)
    command = declared_command(args, '/usr/bin/python3', ROOT / 'tools/benchmark/capture_disarmed_sensors.py', launch_env)
    parsed = parse_capture_args(command[2:])
    if not parsed.startup_preflight or parsed.worker or parsed.wire_config != wire:
        raise ValueError('not an explicit parent startup-only command')
    manifest = dict(schema='installed-wire-startup-study-v1', prepare_only=True,
                    implementation_head=version['head'], source_archive_sha256=ARCHIVE_SHA,
                    source_files=source_records, command=command, destination=str(args.output),
                    source_drift=changes, files=[file_record(p) for p in
                    (policy, wire, binding_path, execution_path, Path(__file__), HERE / 'committed-source.json')],
                    installed_binary_hashes={role: [r['sha256'] for r in declared['baseline']['files'] if r['role']==role]
                        for role in ('runtime-root:px4', 'runtime-root:openvins', 'runtime-root:native-reference', 'graph:resolver')},
                    clock_mapping_scope='preflight parsing only; not used or qualified for a live session',
                    seed_scope='declaration only; no random generator/estimator/physics executed',
                    launch_limit_s=300, native_query_limit_s=10, graph_query_limit_s=60,
                    physical_run=False, network_enabled=False, estimator_run=False, fusion_eligible=False,
                    actual_installed_preflight_qualified=False, syscall_trace_available=False)
    write_manifest(STUDY / 'study-manifest.json', manifest)
    print(json.dumps(dict(prepared=str(STUDY), files=len(declared['baseline']['files']),
                         committed_code_changes=len(changes), physical_run=False), indent=2))


if __name__ == '__main__':
    try:
        prepare()
    except BaseException as exc:
        if STUDY.exists():
            write_manifest(STUDY / 'prepare-failed.json', dict(error=repr(exc), physical_run=False))
        raise
