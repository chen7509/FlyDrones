"""One-off execution of the already frozen, startup-only parent CLI command."""
import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / 'src')]
from tools.benchmark.capture_contract import _typed_equal, declared_command, derive_launch_environment, read_declaration  # noqa: E402
from tools.benchmark.capture_disarmed_sensors import active_resources, parse_capture_args  # noqa: E402
from tools.benchmark.declared_runtime_snapshot import file_record, snapshot, write_manifest  # noqa: E402
from tools.benchmark.audit_capture_startup_preflight import audit  # noqa: E402

HERE = Path(__file__).resolve().parent
STUDY = HERE / 'study-v1'
manifest = read_declaration(STUDY / 'study-manifest.json')
destination = Path(manifest['destination'])
dispatch, completion = STUDY / 'dispatch.json', STUDY / 'completion.json'
for path in (destination, dispatch, completion, STUDY / 'launch-output.txt', STUDY / 'audit.json',
             destination.with_name(destination.name + '.supervisor-events.jsonl'),
             destination.with_name(destination.name + '.supervisor-environment.json')):
    if path.exists():
        raise FileExistsError('one-shot output exists: ' + str(path))
if sys.argv[1:] != [manifest['implementation_head']]:
    raise ValueError('actual committed head differs')
for record in manifest['files']:
    if not _typed_equal(file_record(Path(record['requested'])), record):
        raise ValueError('prepared file drift: ' + record['requested'])
binding = read_declaration(STUDY / 'runtime-binding-v3.json')
if not _typed_equal(snapshot(binding['inventory'])['files'], binding['baseline']['files']):
    raise ValueError('prepared runtime baseline drift')
command = manifest['command']
args = parse_capture_args(command[2:])
if (command[:2] != ['/usr/bin/python3', str(ROOT / 'tools/benchmark/capture_disarmed_sensors.py')]
        or not args.startup_preflight or args.worker or args.output != destination
        or command != declared_command(args, command[0], command[1], derive_launch_environment(binding))
        or manifest['physical_run'] is not False or manifest['network_enabled'] is not False
        or manifest['estimator_run'] is not False):
    raise ValueError('not the frozen startup-only command')
before = active_resources()
if before:
    raise ValueError('competing resources')
write_manifest(dispatch, dict(schema='capture-startup-preflight-dispatch-v1', command=command,
    destination=str(destination), head=manifest['implementation_head'], resources_before=before,
    physical_run=False, network_enabled=False, manifest=file_record(STUDY / 'study-manifest.json'),
    executor=file_record(Path(__file__)), started_wall_ns=time.time_ns()))
error, code = None, None
try:
    with (STUDY / 'launch-output.txt').open('xb') as output:
        code = subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT, check=False).returncode
except Exception as exc:
    error = repr(exc)
finally:
    after = active_resources()
    write_manifest(completion, dict(schema='capture-startup-preflight-completion-v1',
        destination=str(destination), returncode=code, launcher_error=error,
        resources_after=after, physical_run=False, ended_wall_ns=time.time_ns()))
if (destination / 'result.json').exists() and (destination / 'supervisor.json').exists():
    result = audit(destination, dispatch, completion, expected_head=manifest['implementation_head'])
    write_manifest(STUDY / 'audit.json', result)
    print(json.dumps(result, indent=2))
else:
    print(json.dumps(dict(returncode=code, launcher_error=error, terminal_result_available=False)))
raise SystemExit(code if code is not None else 2)
