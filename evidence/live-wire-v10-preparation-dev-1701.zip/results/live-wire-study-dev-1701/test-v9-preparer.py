"""Small synthetic checks for inherited inventory role extension."""

import importlib.util
import tempfile
from pathlib import Path

module_path = Path(__file__).with_name("prepare-v9.py")
spec = importlib.util.spec_from_file_location("prepare_v9", module_path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

with tempfile.TemporaryDirectory() as directory:
    root = Path(directory)
    first, second = root / "first", root / "second"
    first.write_text("first")
    second.write_text("second")
    inventory = {"inherited": [str(first)]}
    module.extend_missing(inventory, "inherited", [first, second])
    assert inventory == {"inherited": sorted([str(first), str(second)])}
    module.extend_missing(inventory, "next", [second])
    assert "next" not in inventory
    try:
        module.extend_missing(inventory, "inherited", [root / "absent"])
    except FileNotFoundError:
        pass
    else:
        raise AssertionError("missing file was accepted")
print("v9 inherited-role tests passed")
