"""Bind the already written v10 preparer and installed package evidence to HEAD."""

import hashlib
import json
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
if subprocess.check_output([
    "git", "status", "--porcelain", "--untracked-files=no",
], cwd=ROOT).strip():
    raise ValueError("tracked worktree is not clean")
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
paths = subprocess.check_output(["git", "ls-files", "-z", "--", "*.py"], cwd=ROOT)
names = [Path(item.decode()) for item in paths.split(b"\0") if item]
source = {
    path.as_posix(): hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
    for path in names
}
preparer = HERE / "prepare-v10.py"
package_evidence = HERE / "package-provenance-v8.json"
version = {
    "head": head,
    "source_sha256": source,
    "tracked_worktree_clean": True,
    "preparer_sha256": hashlib.sha256(preparer.read_bytes()).hexdigest(),
    "package_provenance_sha256": hashlib.sha256(package_evidence.read_bytes()).hexdigest(),
}
with (HERE / "committed-source-v10.json").open("x", encoding="utf8") as output:
    json.dump(version, output, indent=2, sort_keys=True)
    output.write("\n")

print(json.dumps({"head": head, "tracked_python_sources": len(source),
                  "v10_preparer_sha256": version["preparer_sha256"]}))
