"""Record the five changed installed libraries before a prospective v8 freeze."""

import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root))
from tools.benchmark.declared_runtime_snapshot import file_record  # noqa: E402

here = Path(__file__).resolve().parent
audit = json.loads((root / "results/live-wire-v7-current-preflight-dev-1701/drift-audit.json").read_text())
packages = {
    "/lib/x86_64-linux-gnu/libpng16.so.16": "libpng16-16t64",
    "/usr/lib/x86_64-linux-gnu/libXpm.so.4.11.0": "libxpm4",
    "/usr/lib/x86_64-linux-gnu/libfreetype.so.6.20.1": "libfreetype6",
    "/usr/lib/x86_64-linux-gnu/libpoppler.so.134.0.0": "libpoppler134",
    "/usr/lib/x86_64-linux-gnu/libxml2.so.2.9.14": "libxml2",
}
observed = {row["path"]: row for row in audit["differences"] if row["path"] in packages}
if set(observed) != set(packages):
    raise ValueError("unexpected changed library set")


def run(*args):
    result = subprocess.run(args, text=True, capture_output=True, check=True)
    if result.stderr:
        raise ValueError("package tool stderr: " + result.stderr)
    return result.stdout.strip()


rows = []
for path, package in packages.items():
    record = file_record(path)
    if record["sha256"] != observed[path]["actual_sha256"]:
        raise ValueError("library changed since drift audit: " + path)
    owner = run("dpkg-query", "-S", record["resolved"])
    if not owner.startswith(package + ":amd64: "):
        raise ValueError("package ownership mismatch: " + path + ": " + owner)
    status_version = run("dpkg-query", "-W", "-f=${Status}\t${Version}", package)
    status, version = status_version.split("\t", 1)
    if status != "install ok installed" or not version:
        raise ValueError("package not installed: " + package)
    if run("dpkg", "-V", package):
        raise ValueError("package verification reported drift: " + package)
    rows.append({"package": package, "version": version, "file": record, "dpkg_verify_empty": True})

archive = root / "evidence/live-wire-v7-preparation-dev-1701.zip"
result = {
    "schema": "flydrones-v8-installed-package-provenance-v1",
    "source_v7_archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
    "libraries": rows,
    "proves_upstream_build_equivalence": False,
    "physical_run": False,
}
if result["source_v7_archive_sha256"] != "23d6887c557e1f8cad429d5da221ac0ad0ef41aeba63be61a2caec79a670f6df":
    raise ValueError("source v7 archive changed")
out = here / "package-provenance-v8.json"
with out.open("x", encoding="utf8") as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write("\n")
print(json.dumps({"libraries": len(rows), "versions": {row["package"]: row["version"] for row in rows}}))
