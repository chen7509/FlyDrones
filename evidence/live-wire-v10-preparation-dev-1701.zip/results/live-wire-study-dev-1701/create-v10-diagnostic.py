"""Select a companion read-only PX4 startup diagnostic for prepared v10."""

import hashlib
import json
from pathlib import Path, PurePosixPath


ROOT = Path(__file__).resolve().parents[2]
STUDY = Path(__file__).resolve().parent / "study-v10"
plan = json.loads((STUDY / "executor-binding.json").read_text(encoding="utf8"))
manifest = STUDY / "study-manifest.json"
selected_study = hashlib.sha256(manifest.read_bytes()).hexdigest()
if plan["study_manifest"]["sha256"] != selected_study:
    raise ValueError("prepared study manifest changed")
destination = PurePosixPath(plan["destination"])
if not destination.is_absolute() or ".." in destination.parts:
    raise ValueError("prepared destination invalid")
observer = ROOT / "tools/benchmark/observe_px4_startup.py"
runner = ROOT / "tools/benchmark/live_wire_startup_runner.py"
declaration = {
    "schema": "flydrones-live-wire-startup-diagnostic-declaration-v1",
    "study_id": plan["run_id"],
    "study_manifest_sha256": selected_study,
    "observer_source_sha256": hashlib.sha256(observer.read_bytes()).hexdigest(),
    "runner_source_sha256": hashlib.sha256(runner.read_bytes()).hexdigest(),
    "observer_deadline_ns": 60_000_000_000,
    "ready_timeout_s": 5,
    "log_path": str(destination / "px4.log"),
    "observation_path": str(destination.parent / "startup-observation.json"),
    "summary_path": str(destination.parent / "startup-summary.json"),
    "qualification_granted": False,
}
output = STUDY / "startup-diagnostic-declaration.json"
with output.open("x", encoding="utf8") as stream:
    json.dump(declaration, stream, sort_keys=True, indent=2)
    stream.write("\n")
selected_diagnostic = hashlib.sha256(output.read_bytes()).hexdigest()
selection = {
    "schema": "flydrones-live-wire-startup-diagnostic-selection-v1",
    "study_manifest_sha256": selected_study,
    "diagnostic_declaration_sha256": selected_diagnostic,
    "physical_run": False,
    "qualification_granted": False,
}
with (STUDY / "startup-diagnostic-selection.json").open("x", encoding="utf8") as stream:
    json.dump(selection, stream, sort_keys=True, indent=2)
    stream.write("\n")
print(json.dumps(selection, sort_keys=True))
