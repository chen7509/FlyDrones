"""Original frozen records must remain exact when a role gains new paths."""

import importlib.util
from pathlib import Path

module_path = Path(__file__).with_name("prepare-v10.py")
spec = importlib.util.spec_from_file_location("prepare_v10", module_path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

old = {"role": "runtime:prospective-policy", "requested": "/old", "sha256": "old"}
new = {"role": "runtime:prospective-policy", "requested": "/new", "sha256": "new"}
module.assert_original_selection_unchanged([old], [new, old])
for bad in ([new], [new, {**old, "sha256": "tampered"}], [new, old, old]):
    try:
        module.assert_original_selection_unchanged([old], bad)
    except ValueError:
        pass
    else:
        raise AssertionError("changed or duplicated old record accepted")
print("v10 original-selection tests passed")
