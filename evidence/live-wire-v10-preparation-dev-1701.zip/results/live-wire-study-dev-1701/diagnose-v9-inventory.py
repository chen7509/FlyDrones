"""Read-only reproduction of the v9 inherited-role comparison failure."""

import importlib.util
import json
from pathlib import Path

here = Path(__file__).resolve().parent
source = json.loads((here / "study-v7/runtime-binding-v3.json").read_text())
spec = importlib.util.spec_from_file_location("prepare_v9", here / "prepare-v9.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

inventory = source["inventory"]
prior = {path for paths in inventory.values() for path in paths}
future = {role: list(paths) for role, paths in inventory.items()}
policy = here / "study-v9/trajectory-gauge-policy.json"
wire = here / "study-v9/wire-config.json"
module.extend_missing(future, "runtime:prospective-policy", [policy, wire])
after = {path for paths in future.values() for path in paths}
new = sorted(after - prior)
result = {
    "schema": "flydrones-v9-inherited-role-failure-v1",
    "prior_unique_paths": len(prior),
    "after_unique_paths": len(after),
    "new_paths_under_old_role": new,
    "old_predicate_would_count_new_paths_as_original": bool(new),
    "physical_run": False,
}
out = here / "study-v9/inventory-diagnosis.json"
with out.open("x") as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write("\n")
print(json.dumps(result, sort_keys=True))
