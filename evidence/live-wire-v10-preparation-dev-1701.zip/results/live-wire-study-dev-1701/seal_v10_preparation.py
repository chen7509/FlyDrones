"""Seal v8/v9 failures and the distinct, offline-only v10 selection."""

import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
here = Path(__file__).resolve().parent
study = here / "study-v10"
target = root / "evidence/live-wire-v10-preparation-dev-1701.zip"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


selected = json.loads((study / "startup-diagnostic-selection.json").read_text())
if selected["study_manifest_sha256"] != sha((study / "study-manifest.json").read_bytes()):
    raise ValueError("selected v10 study changed")
if selected["diagnostic_declaration_sha256"] != sha((study / "startup-diagnostic-declaration.json").read_bytes()):
    raise ValueError("selected v10 diagnostic changed")
for name in (
    "capture-v1", "dispatch.json", "completion.json", "audit.json", "physical-output.txt",
    "activation-request.json", "startup-observation.json", "startup-summary.json",
):
    if (study / name).exists():
        raise ValueError("unexpected physical or diagnostic output: " + name)

paths = set()
for version in ("v8", "v9", "v10"):
    paths.update(path for path in (here / f"study-{version}").rglob("*") if path.is_file())
    for name in (f"create-{version}.py", f"prepare-{version}.py", f"create-{version}-diagnostic.py"):
        path = here / name
        if path.exists():
            paths.add(path)
paths.update(
    here / name for name in (
        "make-package-provenance-v8.py", "package-provenance-v8.json",
        "committed-source-v8.json", "committed-source-v9.json", "committed-source-v10.json",
        "test-v9-preparer.py", "test-v10-preparer.py", "diagnose-v9-inventory.py",
        "check-v10.py", "seal_v10_preparation.py",
    )
)
paths.add(root / "docs/LIVE_WIRE_V10_PREPARATION_REPORT.md")
payload = {path.relative_to(root).as_posix(): path.read_bytes() for path in sorted(paths)}
manifest = {
    "schema": "flydrones-live-wire-v10-preparation-evidence-v1",
    "source_commit": json.loads((here / "committed-source-v10.json").read_text())["head"],
    "selected_study_sha256": selected["study_manifest_sha256"],
    "selected_diagnostic_sha256": selected["diagnostic_declaration_sha256"],
    "physical_run": False,
    "fusion_eligible": False,
    "members": [
        {"path": name, "bytes": len(raw), "sha256": sha(raw)}
        for name, raw in sorted(payload.items())
    ],
}
with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, raw in sorted(payload.items()):
        archive.writestr(name, raw)
    archive.writestr("MANIFEST.json", json.dumps(manifest, indent=2, sort_keys=True) + "\n")
with zipfile.ZipFile(target) as archive:
    if archive.testzip() is not None:
        raise ValueError("evidence ZIP CRC")
    for row in manifest["members"]:
        raw = archive.read(row["path"])
        if len(raw) != row["bytes"] or sha(raw) != row["sha256"]:
            raise ValueError("evidence ZIP member mismatch")
print(json.dumps({"members": len(payload), "bytes": target.stat().st_size, "sha256": sha(target.read_bytes())}))
