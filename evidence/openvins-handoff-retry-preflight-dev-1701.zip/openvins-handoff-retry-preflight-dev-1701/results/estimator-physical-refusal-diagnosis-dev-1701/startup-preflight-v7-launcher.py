import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path("/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility")
sys.path[:0] = [str(ROOT), str(ROOT / "src")]

from tools.benchmark.capture_disarmed_sensors import active_resources

base = ROOT / "results/estimator-physical-refusal-diagnosis-dev-1701"
study = base / "study-v15"
destination = study / "startup-preflight-v1"
dispatch_path = base / "startup-preflight-v7-dispatch.json"
completion_path = base / "startup-preflight-v7-completion.json"
output_path = base / "startup-preflight-v7-output.txt"
head = (base / "current-head-for-startup-v7.txt").read_text(encoding="utf-8").strip()
manifest = json.loads((study / "study-manifest.json").read_text(encoding="utf-8"))
prepare_audit = json.loads((base / "study-v15-audit-v2-committed.json").read_text(encoding="utf-8"))
command = list(manifest["command"])
command[command.index("--output") + 1] = destination.as_posix()
command.append("--startup-preflight")

if head != "9730ed80e76838c94cac58e792a5c8fcdaeb9e14":
    raise SystemExit(f"unexpected committed head: {head}")
if destination.exists():
    raise SystemExit(f"refusing existing destination: {destination}")
if dispatch_path.exists() or completion_path.exists() or output_path.exists():
    raise SystemExit("refusing to overwrite startup-preflight-v7 evidence")
if prepare_audit.get("failures") or prepare_audit.get("prepare_qualified") is not True:
    raise SystemExit("prepare-only audit not qualified")
if manifest.get("future_destination") != (study / "capture-v1").as_posix():
    raise SystemExit("physical destination declaration changed")
resources_before = active_resources()
if resources_before:
    raise SystemExit(f"active resources before dispatch: {resources_before!r}")
dispatch = {
    "schema": "capture-startup-preflight-dispatch-v1",
    "command": command,
    "destination": destination.as_posix(),
    "head": head,
    "prepare_audit": (base / "study-v15-audit-v2-committed.json").as_posix(),
    "resources_before": resources_before,
    "physical_run": False,
    "started_wall_ns": time.time_ns(),
}
dispatch_path.write_text(json.dumps(dispatch, indent=2, sort_keys=True) + "\n", encoding="utf-8")
with output_path.open("wb") as stream:
    completed = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, check=False)
resources_after = active_resources()
completion = {
    "schema": "capture-startup-preflight-completion-v1",
    "returncode": completed.returncode,
    "destination": destination.as_posix(),
    "resources_after": resources_after,
    "ended_wall_ns": time.time_ns(),
    "physical_run": False,
}
completion_path.write_text(json.dumps(completion, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps(completion, indent=2, sort_keys=True))
raise SystemExit(completed.returncode)


