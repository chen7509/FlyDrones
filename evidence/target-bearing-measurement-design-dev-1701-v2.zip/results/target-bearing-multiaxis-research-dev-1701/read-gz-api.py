import hashlib
import json
import pathlib
import subprocess

out = pathlib.Path(__file__).parent
code = '''import gz.sim8 as s,json,pathlib,hashlib
p=pathlib.Path(s.__file__)
print(json.dumps({"Link_methods":[x for x in dir(s.Link) if "force" in x or "torque" in x or "wrench" in x],
"Link_wrench_doc":getattr(s.Link,"add_world_wrench",None).__doc__ if hasattr(s.Link,"add_world_wrench") else None,
"Link_force_doc":s.Link.add_world_force.__doc__,"module":str(p),"module_sha256":hashlib.sha256(p.read_bytes()).hexdigest()}))
'''
cmd = ['wsl','-d','Ubuntu','--','/usr/bin/python3','-c',code]
r = subprocess.run(cmd,capture_output=True)
(out/'gz-python-api.stdout').write_bytes(r.stdout)
(out/'gz-python-api.stderr').write_bytes(r.stderr)
(out/'gz-python-api.command.json').write_text(json.dumps({'argv':cmd,'exit':r.returncode,
    'scope':'API introspection only; no fixture/server/physics/plugin build',
    'script_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()},indent=2))
print(r.stdout.decode(errors='replace'))
print('exit',r.returncode)
assert r.returncode == 0
