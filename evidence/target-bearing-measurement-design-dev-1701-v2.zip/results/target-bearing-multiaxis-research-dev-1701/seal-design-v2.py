import hashlib
import json
from pathlib import Path
import zipfile

root = Path.cwd()
out = root/'results/target-bearing-multiaxis-research-dev-1701'
def sha(p):
    value = hashlib.sha256()
    with p.open('rb') as stream:
        for block in iter(lambda: stream.read(65536), b''):
            value.update(block)
    return value.hexdigest()
expected = json.loads((out/'historical-archives.json').read_text())['expected_sha256']
expected['evidence/target-bearing-measurement-design-dev-1701.zip'] = 'efe78c250ad5f3c88914000fe60b2f152e3e9182aa590522231297024246eb5c'
changes = [name for name, value in expected.items() if sha(root/name) != value]
assert not changes, changes
with (out/'historical-archives-v2.json').open('x') as stream:
    json.dump({'count':len(expected),'bytes':sum((root/name).stat().st_size for name in expected),
               'changed':changes,'expected_sha256':expected},stream,indent=2)
docs = [root/'docs/TARGET_BEARING_MEASUREMENT_DESIGN_REPORT.md',
        root/'docs/superpowers/specs/2026-10-15-target-bearing-measurement-capture.md',
        root/'docs/superpowers/plans/2026-10-15-target-bearing-measurement-capture.md']
excluded = {'docker-cache.stdout', 'seal-result.json', 'seal-result-v2.json'}
files = docs + sorted(p for p in out.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name not in excluded)
manifest = {'status':'design-research-only-production-pending','production_implemented':False,
            'publication_scope':'full Docker raw inventory retained locally; relevant name-query facts only',
            'unpublished_original_draft_sha256':'efe78c250ad5f3c88914000fe60b2f152e3e9182aa590522231297024246eb5c',
            'members':[{'path':p.relative_to(root).as_posix(),'size':p.stat().st_size,'sha256':sha(p)} for p in files]}
path = root/'evidence/target-bearing-measurement-design-dev-1701-v2.zip'
with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED) as archive:
    for p in files:
        archive.write(p,p.relative_to(root).as_posix())
    archive.writestr('MANIFEST.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(path) as archive:
    assert archive.testzip() is None
    for row in manifest['members']:
        data = archive.read(row['path'])
        assert len(data)==row['size'] and hashlib.sha256(data).hexdigest()==row['sha256']
        assert data==(root/row['path']).read_bytes()
result = {'path':path.relative_to(root).as_posix(),'sha256':sha(path),'bytes':path.stat().st_size,
          'members':len(files)+1,'mapped':len(files),'crc_size_sha_currentbyte_errors':0,
          'historical_count':len(expected),'historical_changed':changes,'production_implemented':False}
(out/'seal-result-v2.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
