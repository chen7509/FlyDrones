import hashlib
import json
from pathlib import Path
import urllib.request

out = Path(__file__).parent
pin = '1f60227442d25e36365ef5f72cd80b9666d73467'
url = 'https://api.github.com/repos/ethz-asl/kalibr/git/trees/'+pin+'?recursive=1'
with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent':'FlyDrones-source-research'}), timeout=30) as response:
    raw = response.read(4*1024**2+1)
assert len(raw) <= 4*1024**2
tree = json.loads(raw)
assert tree['sha'] == pin and tree.get('truncated') is False
(out/'official-tree.json').write_bytes(raw)
indexed = {r['path']: r for r in tree['tree']}
records = []
for ref in json.loads((out/'measurement-inputs.json').read_text()):
    if 'url' not in ref:
        continue
    path = ref['url'].split(pin+'/',1)[1]
    data = Path(ref['path']).read_bytes()
    blob = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    assert indexed[path]['sha'] == blob and indexed[path]['size'] == len(data)
    records.append({'path':path, 'git_blob':blob, 'size':len(data), 'sha256':hashlib.sha256(data).hexdigest()})
with (out/'pinned-references.json').open('x') as stream:
    json.dump({'tree_url':url,'pin':pin,'tree_sha256':hashlib.sha256(raw).hexdigest(),
               'references':records,'errors':0,'no_install_build_or_solve':True},stream,indent=2)
print(json.dumps({'references':len(records),'errors':0,'tree_bytes':len(raw)}))
