# Independent target-bearing measurement design review

Reviewed on 2026-10-15 Asia/Shanghai: `docs/TARGET_BEARING_MEASUREMENT_DESIGN_REPORT.md` and the corresponding `2026-10-15-target-bearing-measurement-capture.md` spec/plan. This was a read-only source, document and retained-evidence review. No tests, compiler, native/physics/optimizer process, admission resample, permission probe, installation, or old consumer rerun was performed. This review report is the only reviewer-created file.

## Assessment

**No Critical, Important, or Minor findings.** The documents accurately distinguish researched design from implementation, a frozen dispatchable load, actual sensor generation, and measured calibration. They are suitable for publication as pending research/design. They do not authorize dispatch before the original admission and final freeze requirements are satisfied, and do not establish runtime or calibration verification.

## Evidence and plan alignment

The retained Gazebo introspection command exited 0. Its saved stdout documents the actual installed methods: world wrench at link origin for one simulation step and force at link COM. The saved script hash matches the current research script, and the observed module SHA is `1369b99d39623f532dca9209066b6e6bd0bf94612f01d7ffd57bdd9e45bad01c`. The proposed zero-force/pure-torque excitation avoids the force-origin/COM moment ambiguity while keeping per-link COM support. The documents correctly disclaim invocation against an ECM, fixture or physics engine and disclose the earlier unrecorded quoting failure.

The five retained Kalibr reference files independently match their recorded SHA256/size and the Git blob identifiers/sizes in the retained untruncated 1907-entry official tree. Tree bytes match recorded SHA `821fb3e2dc19ac7f18ce5cf75e5f8b0c6f7f28df92ecd1ac1578882b9fd3da32`. Full root LICENSE is retained with the ASL/Skybotix advertising acknowledgement. These checks bind retained reference bytes; they do not establish a complete acquired toolchain, dependency licensing, installation or solver availability.

Pinned source inspection supports the documented CLI names and defaults, optional covariance recovery, temporal estimation, optimizer `max(1,cpu_count()-1)` thread default and block Cholesky selection. The documents appropriately separate these facts and analytical spline/target projection estimates from actual cost, detection, residuals and observability. The old AprilTag detector is not represented as an ASLAM/spline/backend solver.

Current capture source still requires native shadow/reference plus `supported-ready-v1` for source fan-out, and reads the sealed old board scene. Neither `capture_disarmed_sensors.py` nor `capture_contract.py` has a working diff. The proposed scene/contract/excitation files do not yet exist. A distinct raw measurement dependency graph with shared lifecycle ownership and unchanged old mode guards is therefore correctly specified as pending, rather than an already available path or permission to masquerade under an old profile.

The plan places merged semantic poses, full rig/rotor/camera inertia, visibility/collision evaluation, final coefficients, torque/angular/target-clearance bounds, exact hashes and independent design review before final load freeze and physical dispatch. Candidate 0.60 m stand-off, 0.4 m lift, eight-degree rotations and one-centimeter translations are clearly identified as design values. The polynomial pulse has zero value, first derivative and second derivative at both endpoints; this mathematical property does not establish achievable motion, return to rest or safe physical tracking.

The proposed truth boundary remains abort/audit only. Gravity, dynamics, collisions, disarmed state, old sensor workload and safety/RTF gates remain required. New data-only readiness must use successful actual sensor/writer/heartbeat/owned ULog evidence; it cannot be satisfied by fake native reference, copied geometry, synthesized IMU or permission fallbacks. Source rows and native internal rejection counts remain distinct.

The first retained read-only observation is Windows1635545088 / WSL7045931008 bytes, with admission false. The design reports this as below both existing 2 GiB PNG and 4 GiB physical reserves, without a new retry or dispatch claim. Physical work still requires fresh original dual-4-GiB admission and a complete freeze. Full Kalibr acquisition/build/solve costs, digests, transitive licenses, thread control and measured IMU assumptions require a separate completed specification; no small detector budget is substituted.

## Pending boundaries

Production graph implementation, exact final geometry/load, behavior integration, native callback/physics/render/detection, pidfd witness, actual multiaxis capture, full native toolchain, solve, virtual-IMU intrinsic/noise assumptions and residual/coverage/covariance/Jacobian/Schur assessment remain pending. Formal quantitative acceptance criteria must be finalized in the dispatch/solve freezes already required by the plan. An API return, finite transform/covariance, motion-energy estimate or solver exit cannot grant observability or source/clock/measured-calibration/accuracy/teacher/fusion/training/flight qualification.

The original unconsumed PNG study and all consumed cached OpenVINS/Kalibr/EGO attempts remain separate. This review grants no whole-drone completion and changes no physical authorization, threshold or historical evidence.

## Document bytes reviewed

| Document | SHA256 |
| --- | --- |
| Design report | `531c63c853059c5524ea4c293c85db8cd17bb1f111b669ca50930095bff21170` |
| Capture spec | `2293728d25ddaee43ae6e782f979aecc9cb987f6ee067fa947382c0aa9bc8984` |
| Capture plan | `16113afd10d9f017b3a02d3695a073958123bb0f1bf4cdd6a1fc8ec8c9012582` |

## Declined to judge

- Final physical scene, force/torque scales, collision/visibility guarantees and achievable motion: the complete merged rig design and coefficients have not yet been frozen.
- Actual source generation, writer/readiness/ULog ownership, callback ordering and cleanup: no implementation or admitted physical trial exists for the new graph.
- Complete licensing/cost/thread model and native solve quality: the full toolchain and separately admitted solve plan remain pending.
- Measured calibration and downstream qualification: require real process/source bindings and independent residual/observability evidence beyond this researched design.
