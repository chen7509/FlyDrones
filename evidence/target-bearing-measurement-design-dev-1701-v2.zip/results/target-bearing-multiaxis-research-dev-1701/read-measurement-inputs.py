import hashlib
import json
import pathlib
import subprocess
import urllib.request

out = pathlib.Path(__file__).parent
pin = '1f60227442d25e36365ef5f72cd80b9666d73467'
upstream = ['Dockerfile_ros1_20_04', 'LICENSE',
    'aslam_offline_calibration/kalibr/python/kalibr_imu_camera_calibration/IccCalibrator.py',
    'aslam_offline_calibration/kalibr/python/kalibr_imu_camera_calibration/IccSensors.py',
    'aslam_offline_calibration/kalibr/python/kalibr_calibrate_imu_camera']
records = []
for name in upstream:
    url = 'https://raw.githubusercontent.com/ethz-asl/kalibr/'+pin+'/'+name
    target = out/'references'/name
    target.parent.mkdir(parents=True, exist_ok=True)
    with urllib.request.urlopen(url, timeout=30) as response:
        data = response.read(512*1024+1)
    assert len(data) <= 512*1024
    with target.open('xb') as stream:
        stream.write(data)
    records.append({'url':url,'path':str(target),'size':len(data),
                    'sha256':hashlib.sha256(data).hexdigest(), 'scope':'research bytes; no installation'})
commands = [(['wsl','-d','Ubuntu','--','cat',
    '/home/yuchen7509/PX4-Autopilot/Tools/simulation/gz/models/x500_base/model.sdf'], 'x500-base'),
    (['wsl','-d','Ubuntu','--','dpkg-query','-W','libgz-sim8','python3-gz-sim8','libgz-sim8-dev'], 'gz-packages'),
    (['docker','images','--no-trunc','--format','{{json .}}'], 'docker-cache')]
for command, name in commands:
    result = subprocess.run(command,capture_output=True)
    (out/(name+'.stdout')).write_bytes(result.stdout)
    (out/(name+'.stderr')).write_bytes(result.stderr)
    records.append({'argv':command,'exit':result.returncode,'scope':'read-only limited inventory',
                    'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),
                    'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()})
with (out/'measurement-inputs.json').open('x') as stream:
    json.dump(records, stream, indent=2)
print(json.dumps(records, indent=2))
