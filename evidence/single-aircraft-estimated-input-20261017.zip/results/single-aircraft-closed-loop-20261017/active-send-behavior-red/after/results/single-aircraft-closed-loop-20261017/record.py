"""Prospective software-only command recorder; retained fixtures, no native grant."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SOURCES = (
    "src/flydrones/drones/mavlink.py",
    "src/flydrones/benchmark/contract.py", "src/flydrones/benchmark/gateway.py",
    "tools/benchmark/run_episode.py", "tests/benchmark/test_estimated_controller_input.py",
    "tests/benchmark/test_publication_safety.py", "tests/benchmark/test_stationary_prelude.py",
    "tests/benchmark/test_rgb_capture.py", "tests/benchmark/test_camera_info_capture.py",
    "results/single-aircraft-closed-loop-20261017/record.py",
)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def snapshot(destination):
    destination.mkdir()
    records = {}
    for name in SOURCES:
        path = ROOT / name
        if not path.is_file():
            records[name] = None
            continue
        data = path.read_bytes()
        target = destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        records[name] = {"bytes": len(data), "sha256": sha(data)}
    return records


label, *arguments = sys.argv[1:]
if arguments[:1] == ["--"]:
    arguments = arguments[1:]
run = OUT / label
run.mkdir(exist_ok=False)
pytest_run = arguments[:2] == ["-m", "pytest"]
if pytest_run:
    fixtures = run / "fixtures"
    spelling = str(fixtures.resolve())
    if os.name == "nt":
        spelling = "\\\\?\\" + spelling
    arguments.append("--basetemp=" + spelling)
argv = [sys.executable, *arguments]
env = os.environ.copy()
env.update(PYTHONPATH=str(ROOT / "src"), PYTEST_DISABLE_PLUGIN_AUTOLOAD="1", PYTHONDONTWRITEBYTECODE="1")
record = {
    "argv": argv, "cwd": str(ROOT), "utc_start": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "declared_env": {key: env[key] for key in ("PYTHONPATH", "PYTEST_DISABLE_PLUGIN_AUTOLOAD", "PYTHONDONTWRITEBYTECODE")},
    "source_before": snapshot(run / "before"), "recorder_sha256": sha(Path(__file__).read_bytes()),
    "scope": "ordinary software subprocess; no full inherited environment/collection or FFI sandbox, no native qualification",
}
(run / "start.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
start = time.monotonic()
with (run / "stdout").open("xb") as stdout, (run / "stderr").open("xb") as stderr:
    child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr)
    try:
        code = child.wait(timeout=60)
    except subprocess.TimeoutExpired:
        child.terminate()
        code = child.wait(timeout=5)
        record["timeout"] = True
record.update(exit=code, elapsed_s=time.monotonic() - start,
              utc_finish=datetime.datetime.now(datetime.timezone.utc).isoformat(), source_after=snapshot(run / "after"))
retained = []
if pytest_run and fixtures.exists():
    for path in sorted(fixtures.rglob("*")):
        if path.is_file() and not path.is_symlink():
            data = path.read_bytes()
            retained.append({"path": path.relative_to(run).as_posix(), "bytes": len(data), "sha256": sha(data)})
record["retained_regular_fixtures"] = retained
(run / "completion.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
print(json.dumps({"label": label, "exit": code, "elapsed_s": record["elapsed_s"], "fixtures": len(retained)}))
print((run / "stdout").read_text(encoding="utf-8", errors="replace")[-6000:])
print((run / "stderr").read_text(encoding="utf-8", errors="replace")[-1000:])
raise SystemExit(code)
