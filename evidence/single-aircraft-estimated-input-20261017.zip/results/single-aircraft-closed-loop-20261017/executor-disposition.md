# Executor disposition

Original source review C0/I3/M0 preserved, one bounded fix pass; no second review/native grant.

Four actual software counterexamples failed in1.75s; fixes verified by114 affected passes2.00s, no warnings, Ruff0/diff0.

I1 deterministic release-boundary modeled interleaving; I2 two callback clock assertions; I3 actual takeoff/wait logic with constructed ACK/link. None is a native/physical ARM observation.

## All reviewer exclusions, ruled individually

1. Actual simulation launch, live resource/memory admission: Keep all original runtime/resource gates; no native dispatch from this software API. Cost if wrong: Unsafe launch if treated as fresh resource admission.

2. Real OpenVINS/EKF2 producer and CLI selection: Concrete live producer and CLI remain the next integration task; supplied fixture is not that producer. Cost if wrong: Incomplete real sensor-to-flight loop.

3. Sensor-versus-truth authenticity and source/calibration/clock/fusion declarations: Treat every supplied callback/label as unverified; no authority or truth-authenticity grant. Cost if wrong: A dishonest or incorrect source could feed concealed truth or false readiness.

4. Measured calibration, raw IMU correctness, live ODOMETRY reception, disarmed fusion and real reset/loss behavior: Do not promote old covariance floors/static extrinsics to measured calibration or fusion evidence. Cost if wrong: Incorrect estimation/fusion could be admitted without real validation.

5. Semantic estimator/PX4 frame registration and physical goal/optical pose correctness: Require future actual source to establish frame registration and calibrated optical pose; explicit goal only prevents automatic world-goal fallback. Cost if wrong: Misregistered goals/camera rays could command the wrong path.

6. Transport delivery, ACKs, actual arming/motion, confirmed landing/disarm, hardware/HITL safety: Keep LAND requested distinct from landing confirmed; retain actual ACK/touchdown checks as mandatory before mission success. Cost if wrong: Aircraft might still be armed/moving after a request.

7. ArduPilot and arbitrary callbacks outside the backend PX4 simulation path: Document this readiness integration as the backend PX4 path only, with no new hardware CLI or ArduPilot guarantee. Cost if wrong: Other callers may incorrectly assume the callback guards their arm path.

8. Hard cancellation/watchdog for a callback that never returns: Do not admit a real source before its bounded lifecycle/watchdog is implemented and tested; current synchronous API has no hard cancellation. Cost if wrong: A hung callback could stall safety/control; real flight remains inadmissible.

9. Planner executable, obstacle mission, RTF, terminal phase scoring, held-out qualification, learning/model results: Keep actual planner build, mission and held-out execution pending. Existing conventional planning is not full MaleCNS learning. Cost if wrong: False autonomous/fair-learning/RTF qualification.

10. Whole historical branch, original 382 tests, old archives/failures, unchanged unrelated defects: Review this delta only; preserve old failures and immutable archives without another historical scan. Cost if wrong: Unrelated pre-existing defects remain outside this verdict.

11. Installed native identity/provenance and prior machine observations: Installed metadata snapshot is an observation, not native process/library/source authentication. Cost if wrong: A different runtime binary could be mistaken for the inspected checkout.

12. Independent reproduction of recorded test/lint/diff success: Use primary recorder results as software evidence; reviewer did not independently execute tests. Cost if wrong: Recorded tests can miss runtime issues; no independent reproduction claim.

13. Later progress report and automation changes: Later report/automation/publication are executor bookkeeping outside the source review pins; preserve exact predecessors. Cost if wrong: Publication state can drift after the reviewed source snapshot.

No deferred minors. Real source producer/CLI/calibration/fusion/mission remains pending.
