# Single-aircraft estimated-input source review

Verdict: **With fixes. Critical 0 / Important 3 / Minor 0.**

This is the one bounded, read-only source review of the new working delta relative to `1de044650aa590e9457652df50a0f6a574c48b40`. It does not certify native execution, calibration, fusion, flight, or the historical branch. No test, product import, simulator, model, network transport, ARM command, or native workload was run by this reviewer. Only read-only file/Git inspection and creation of these two exclusive review outputs were performed.

## Inputs and evidence

All seven working files and their `review-source/` copies matched the SHA-256 pins in `review-package.json` when inspected. The supplied immutable tracked-file diff is `review-working.diff`, SHA-256 `f85eee11a309157c883c48e903dd3ef37ac3ea03a2562830fbd766acfc0558db`. The new test, spec and plan are also reviewed from their pinned snapshots; they are not contained in the tracked-file diff. The complete seven pins are retained in `review.json`.

The supplied `final-affected/completion.json` and stdout record exit 0 and `109 passed in 1.81s`; `final-lint` records exit 0 / `All checks passed!`; `final-diff` records exit 0. These were inspected as existing software evidence, not independently rerun or treated as runtime qualification.

## Strengths

- The opt-in observation branch uses supplied estimated position, velocity, angular state and camera pose, requires an explicit estimator-frame goal, and leaves the independent scorer on Gazebo truth. The historical default keeps its truth labels.
- Image timestamp equality, finite immutable vector contents, unit camera quaternion, sample age/nonfuture checks, session/reset identity and sample monotonicity are validated. Reusing an RGB frame does not skip source validation.
- The backend adds checks after telemetry/heartbeat and before fixed-step admission, while PX4 takeoff adds a check after the mode switch and before the actual ARM call. Constructed-input tests exercise these actual methods and do not claim a real estimator or flight.

## Important findings

### I1. Publish estimate failure before releasing the serialization lock

Location: `src/flydrones/benchmark/gateway.py:998-1002` (validation lock at 960; sender at 772/776).

An exception from readiness, snapshot, or validation unwinds the `with self._estimate_lock` block before `_estimate_failure` is set. A waiting setpoint thread can acquire that lock in the gap, observe no failure, receive a successful subsequent source value, and finish its send before the original thread reacquires the lock and publishes the failure. A transient source exception can therefore be followed by motion even though this API promises a latched failure.

Keep exception capture and `_estimate_failure` assignment inside the same estimate critical section that runs source validation. Release that lock before calling `stop_motion`, retaining the existing avoidance of the MAVLink/estimate lock inversion. Add a controlled two-thread regression that makes a source check fail while a final-send check is waiting and verifies that the waiting check cannot be admitted. This is a source-level interleaving finding; no reproduction was executed in this review.

### I2. Revalidate sample/frame time after the final readiness callback returns

Location: `src/flydrones/benchmark/gateway.py:993-997` (time captured at 971 and validated at 972-975).

The last `require_ready(now_sim_ns)` is an external call made after all age/nonfuture checks. During continuous startup or takeoff, it can return successfully after simulation time advances, leaving the returned snapshot and camera frame older than the 100 ms limit. For example, both may be valid at 200 ms, then the final callback returns at 301 ms; the method still admits ARM or a send using the 200 ms validation. A clock regression during that call is likewise not checked. The callback can correctly validate readiness for its supplied 200 ms argument, so this does not require a dishonest source.

Read current simulation time again after that final callback and fail closed if the accepted body sample or frame is now stale/future or the clock regressed. Keep the source readiness contract aligned with the effective admission time. Add a constructed-source case that advances simulation time during the second readiness call and proves that no ARM/setpoint/physics effect follows.

### I3. Check readiness while ARM is pending, not only after armed status is observed

Location: `src/flydrones/drones/mavlink.py:125-126`; relevant existing flow at 153-183.

After `arducopter_arm()` is sent, `_wait_armed()` can keep sending zero body-frame setpoints for up to ten seconds, but `self.flying` remains false until `_wait_armed()` returns. Thus the new condition skips every readiness callback in that interval. If the estimator fails or resets while telemetry/heartbeat is being processed, the application continues keeping Offboard alive without invoking the estimate failure latch or takeoff LAND cleanup, including when the vehicle has already armed but its armed heartbeat has not yet been observed.

Treat an outstanding ARM request as an active phase for the final body-frame readiness check, or explicitly recheck in the armed-wait send path after heartbeat work. Preserve the neutral pre-arm priming behavior. Add a constructed pending-ARM case where the source loses readiness before an armed heartbeat is received and assert immediate refusal and LAND request rather than continued neutral publication.

## Declined to judge

Every behavior considered and set aside is listed here for the executor to rule on:

1. **Actual simulation launch, live resource admission or memory availability:** prohibited in this review; the unchanged dual 4 GiB gate and the supplied below-gate Windows observation remain constraints, not newly measured facts.
2. **A real OpenVINS/EKF2 producer or a CLI route selecting it:** explicitly downstream; this change provides a backend dependency interface and labels only.
3. **Whether supplied values come from sensors rather than truth, or whether source/calibration/clock/fusion declarations are authentic:** the supplied object is an intentional trust boundary and there is no live producer or measured rig evidence in this scope.
4. **Measured camera/IMU spatial, temporal and noise calibration; raw IMU correctness; live ODOMETRY reception; disarmed EKF2 fusion and real loss/reset response:** downstream runtime work, not established by tuple validation or successful callbacks.
5. **Actual estimator/PX4 frame registration and the physical correctness of an explicitly supplied goal/camera optical pose:** explicit goal selection and timestamp equality were checked in code; semantic correctness requires the future source and calibration evidence.
6. **MAVLink delivery, ACK behavior, actual arming, motor motion, confirmed LAND/touchdown/disarm, or safety of real hardware/HITL:** prohibited and unavailable; a recorded LAND request/return is not confirmed landing.
7. **ArduPilot behavior and arbitrary non-backend readiness callbacks outside the requested PX4 simulation integration:** not the requested product path; the constructor option does not authenticate a connection or grant hardware authority.
8. **Hard cancellation/watchdog behavior of a source callback that never returns:** no producer/deadline implementation is supplied from which to establish that behavior; this review identifies freshness failures for callbacks that do return, and grants no hung-source or real-time guarantee.
9. **Upstream planner executable/quality, obstacle avoidance, development mission success, RTF, terminal landing scoring and phase altitude rules, frozen held-out repeats, or full learning/model results:** explicitly downstream and unexecuted.
10. **Whole historical branch correctness, the original 382-test history, old failures/archives, and unrelated launch/cleanup defects unchanged by this delta:** outside the one new-phase source review; surrounding code was read only to determine the effects of these additions.
11. **Installed native dependency/binary identity, native source provenance, and the truth of prior machine observations:** supplied context only; no new native inspection or archival audit was requested.
12. **Independent reproduction of the 109-test/Ruff/diff results:** reviewer execution was prohibited; the recorded outputs and matching source pins were inspected without rerunning them.
13. **The later progress report and automation changes:** explicitly outside the seven-file pin package; neither was reviewed or certified.

## Assessment

The new routing and refusal checks are substantially aligned with the API-integration plan. Fix the three admission gaps before treating this delta as complete. The executor owns the one bounded fix pass and necessary software verification; this report does not request a second review or authorize any native/runtime work.