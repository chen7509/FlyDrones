import copy

import pytest
import torch

from flydrones.connectome_training.inference_artifact import load_inference_core
from flydrones.connectome_training.model import ConnectomeConstrainedCore
from test_learning_roles import inert_backends as _inert

inert_backends = _inert


def test_actual_loaded_core_reuses_frozen_coefficients(tiny_artifacts, monkeypatch):
    counters = {"gain": 0, "tau": 0}
    original_gain = ConnectomeConstrainedCore.input_gain
    original_tau = ConnectomeConstrainedCore.tau_m_ms

    def gain(core):
        counters["gain"] += 1
        return original_gain.fget(core)

    def tau(core):
        counters["tau"] += 1
        return original_tau.fget(core)

    monkeypatch.setattr(ConnectomeConstrainedCore, "input_gain", property(gain))
    monkeypatch.setattr(ConnectomeConstrainedCore, "tau_m_ms", property(tau))
    source, folder, _, _ = tiny_artifacts()
    loaded = load_inference_core(source, folder, mode="tiny-fixture")
    counters.update(gain=0, tau=0)
    features = torch.linspace(-0.3, 0.5, loaded.core.n_features).repeat(2, 1)
    state = loaded.core.initial_state(2)
    for _ in range(4):
        _, state = loaded.core.forward_step(features, state, 0.05)
    assert counters == {"gain": 0, "tau": 0}
    assert loaded.provenance["frozen_coefficients_prepared"] is True
    assert not loaded.provenance["training_success_verified"]
    assert not loaded.provenance["flight_eligible"]


@pytest.mark.parametrize("topology", ["coo_reference", "csr_compact_v1"])
@pytest.mark.parametrize("dynamics", ["clipped-euler-v1", "frozen-drive-exponential-v1"])
@pytest.mark.parametrize("dtype", [torch.float32, torch.float64])
def test_cached_actual_recurrent_states_outputs_and_serialization_match_reference(tiny_artifacts, topology, dynamics, dtype):
    source, folder, connectome, parameters = tiny_artifacts()
    loaded = load_inference_core(source, folder, mode="tiny-fixture", topology_format=topology, dynamics_format=dynamics)
    actual = loaded.core.to(dtype=dtype)
    reference = ConnectomeConstrainedCore(connectome, parameters, topology_format=topology, dynamics_format=dynamics).to(dtype=dtype).eval().requires_grad_(False)
    assert set(actual.state_dict()) == set(reference.state_dict())
    before = {n: p.detach().clone() for n, p in actual.named_parameters()}
    a, b = actual.initial_state(2), reference.initial_state(2)
    for i, dt in enumerate([0.05, 0.05, 0.003, 0.017, 0.05, 0.05]):
        features = torch.linspace(-0.7, 0.8, 2 * actual.n_features, dtype=dtype).reshape(2, -1) + i / 100
        ac, a = actual.forward_step(features, a, dt)
        bc, b = reference.forward_step(features, b, dt)
        assert torch.equal(ac, bc) and torch.equal(a.voltage, b.voltage)
    for n, p in actual.named_parameters():
        assert torch.equal(before[n], p)
    assert set(actual.state_dict()) == set(reference.state_dict())


@pytest.mark.parametrize("mutation", ["gain", "bias", "tau", "replacement", "input-index", "type-index", "dynamics"])
def test_ordinary_mutations_rebuild_derived_values(tiny_artifacts, mutation):
    source, folder, _, _ = tiny_artifacts()
    core = load_inference_core(source, folder, mode="tiny-fixture", dynamics_format="frozen-drive-exponential-v1").core
    # Add a second actual bias type for the index mutation protocol. The ordinary
    # core is mutable Python, not a hostile/source-authenticated boundary.
    with torch.no_grad():
        if mutation == "gain":
            core.raw_input_gain.add_(0.9)
        elif mutation == "bias":
            core.type_bias_mv.add_(0.7)
        elif mutation == "tau":
            core.raw_tau_m.add_(70.0)
        elif mutation == "replacement":
            core.raw_input_gain = torch.nn.Parameter(core.raw_input_gain + 0.8, requires_grad=False)
        elif mutation == "input-index":
            core.raw_input_gain.copy_(torch.linspace(0.1, 1.3, core.n_features))
            core.input_feature_index.copy_(core.input_feature_index.flip(0))
        elif mutation == "type-index":
            core.type_bias_mv = torch.nn.Parameter(torch.tensor([0.1, 0.6]), requires_grad=False)
            core.type_index[::2] = 1
        else:
            core.dynamics_format = "clipped-euler-v1"
    reference = copy.deepcopy(core)
    reference.clear_frozen_inference()
    features = torch.linspace(-0.4, 0.8, core.n_features).reshape(1, -1)
    for dt in [0.05, 0.002, 0.05]:
        a, sa = core.forward_step(features, core.initial_state(1), dt)
        b, sb = reference.forward_step(features, reference.initial_state(1), dt)
        assert torch.equal(a, b) and torch.equal(sa.voltage, sb.voltage)


@pytest.mark.parametrize("transition", ["train", "grad"])
def test_gradient_transition_uses_actual_differentiable_path(tiny_artifacts, transition):
    source, folder, _, _ = tiny_artifacts()
    actual = load_inference_core(source, folder, mode="tiny-fixture", dynamics_format="frozen-drive-exponential-v1").core
    reference = copy.deepcopy(actual)
    reference.clear_frozen_inference()
    actual.requires_grad_(True)
    reference.requires_grad_(True)
    if transition == "train":
        actual.train()
        reference.train()
    optimizers = [torch.optim.SGD(c.parameters(), lr=0.01) for c in (actual, reference)]
    for core, optimizer in zip((actual, reference), optimizers):
        x = torch.linspace(-0.5, 0.7, core.n_features).reshape(1, -1)
        command, state = core.forward_step(x, core.initial_state(1), 0.05)
        (command.square().sum() + state.voltage.square().mean()).backward()
        optimizer.step()
    for a, b in zip(actual.parameters(), reference.parameters()):
        assert a.grad is not None and torch.equal(a.grad, b.grad) and torch.equal(a, b)
    assert actual.frozen_inference_prepared is False


def test_inference_tensor_without_versions_falls_back_to_original_math(tiny_artifacts):
    source, folder, _, _ = tiny_artifacts()
    with torch.inference_mode():
        loaded = load_inference_core(source, folder, mode="tiny-fixture")
        assert loaded.provenance["frozen_coefficients_prepared"] is False
        features = torch.zeros(1, loaded.core.n_features)
        result, state = loaded.core.forward_step(features, loaded.core.initial_state(1), 0.05)
        assert torch.isfinite(result).all() and torch.isfinite(state.voltage).all()


def test_preparation_does_not_freeze_a_trainable_model(tiny_artifacts):
    _, _, connectome, parameters = tiny_artifacts()
    core = ConnectomeConstrainedCore(connectome, parameters)
    with pytest.raises(ValueError, match="frozen.*eval"):
        core.prepare_frozen_inference()
    assert core.training and all(p.requires_grad for p in core.parameters())


@pytest.mark.parametrize("case", ["features", "state", "dt", "dynamics"])
def test_cached_invalid_inputs_preserve_existing_rejection(tiny_artifacts, case):
    source, folder, _, _ = tiny_artifacts()
    core = load_inference_core(source, folder, mode="tiny-fixture").core
    features, state, dt = torch.zeros(1, core.n_features), core.initial_state(1), 0.05
    if case == "features":
        features[0, 0] = float("nan")
    elif case == "state":
        state = core.initial_state(2)
    elif case == "dt":
        dt = 0.0
    else:
        core.dynamics_format = "invalid"
    with pytest.raises(ValueError):
        core.forward_step(features, state, dt)
