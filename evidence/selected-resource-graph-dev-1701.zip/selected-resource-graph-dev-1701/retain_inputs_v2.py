import hashlib,json,shutil,subprocess
from pathlib import Path
p=Path(__file__).resolve().parent
d=json.loads((p/'fixed-v2/discovery-snapshot-pre.json').read_text())
out=p/'consumed-original-files-v2';out.mkdir(exist_ok=False)
copied=[]; changed=[]
for row in d['files']:
 path=Path(row['requested'])
 if path.suffix.lower() not in ('.sdf','.dae','.config','.material','.png','.py'):continue
 data=path.read_bytes();sha=hashlib.sha256(data).hexdigest()
 if sha!=row['sha256']:
  changed.append(dict(path=str(path),expected=row['sha256'],actual=sha,retained=False))
  continue
 name=sha+'-'+path.name
 (out/name).write_bytes(data)
 copied.append(dict(original=str(path),member=name,sha256=sha))
(out/'manifest.json').write_text(json.dumps(dict(copied=copied,changed=changed,claim='post-discovery retention, changed source not backfilled'),indent=2))
tools=[]
for name in ('g++','pkg-config'):
 path=Path(shutil.which(name));data=path.read_bytes()
 tools.append(dict(name=name,path=str(path),resolved=str(path.resolve()),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),
                   timing='post-build tool identity, not pre-build freeze'))
(p/'build-tool-identities.json').write_text(json.dumps(tools,indent=2))
headers=['/usr/include/gz/sim8/gz/sim/InstallationDirectories.hh','/usr/include/gz/sim8/gz/sim/SystemLoader.hh',
 '/usr/include/gz/common5/gz/common/SystemPaths.hh','/usr/include/gz/sdformat14/sdf/parser.hh']
for h in headers:
 path=Path(h);(p/'sources'/('installed-'+path.name)).write_bytes(path.read_bytes())
q=subprocess.run(['dpkg-query','-W','-f=${Package} ${Version}\n','libgz-sim8','libgz-common5','libsdformat14'],capture_output=True,text=True,timeout=10)
(p/'package-versions.json').write_text(json.dumps(dict(code=q.returncode,stdout=q.stdout,stderr=q.stderr),indent=2))
print('retained',len(copied),'original source/config/asset inputs')
