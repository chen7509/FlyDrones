import hashlib,json,subprocess,zipfile
from pathlib import Path
p=Path(__file__).resolve().parent
root=p.parents[1]
target=root/'evidence/selected-resource-graph-dev-1701.zip'
if target.exists():raise FileExistsError(target)
producer=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
payloads={}
for f in sorted(p.rglob('*')):
 if f.is_file() and '__pycache__' not in f.parts:
  payloads['selected-resource-graph-dev-1701/'+f.relative_to(p).as_posix()]=f.read_bytes()
sources=['tools/benchmark/selected_resource_graph.py','tools/benchmark/native/resource_resolver.cc',
 'tests/benchmark/test_selected_resource_graph.py','tests/native/run_resource_resolver_checks.py',
 'docs/SELECTED_RESOURCE_GRAPH_REPORT.md','docs/superpowers/specs/2026-10-06-selected-resource-graph.md',
 'docs/superpowers/plans/2026-10-06-selected-resource-graph.md']
for name in sources:payloads['repository/'+name]=(root/name).read_bytes()
manifest=dict(producer=producer,files=[dict(name=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in payloads.items()])
payloads['manifest.json']=json.dumps(manifest,indent=2).encode()
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in payloads.items():z.writestr(n,b)
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(payloads)
 for row in manifest['files']:
  assert hashlib.sha256(z.read(row['name'])).hexdigest()==row['sha256']
summary=dict(path=str(target),sha256=hashlib.sha256(target.read_bytes()).hexdigest(),bytes=target.stat().st_size,
 members=len(payloads),producer=producer,all_member_hashes_and_crc_verified=True)
(root/'evidence/selected-resource-graph-dev-1701-manifest.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
