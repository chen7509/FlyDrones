"""Explicit local candidate graph; URI semantics remain unqualified."""
import collections,hashlib,json,os,subprocess,sys,zipfile
from pathlib import Path

stage=Path(__file__).resolve().parent
root=stage.parents[1];sys.path.insert(0,str(root))
out=stage/'fixed-v2';out.mkdir(exist_ok=False)
from tools.benchmark.selected_resource_graph import references
from tools.benchmark.capture_disarmed_sensors import active_resources
from tools.benchmark.declared_runtime_snapshot import snapshot
assert not active_resources()
producer=sys.argv[1]
binary=stage/'resource_resolver'
px4=Path.home()/'PX4-Autopilot'
modelroots=[root/'assets/gazebo/models',px4/'Tools/simulation/gz/models']
env=dict(os.environ,GZ_SIM_RESOURCE_PATH=':'.join(map(str,modelroots)),GZ_SIM_SYSTEM_PLUGIN_PATH=os.environ.get('GZ_SIM_SYSTEM_PLUGIN_PATH',''))
queries=[]
def native(*args):
 p=subprocess.run([str(binary),*map(str,args)],env=env,capture_output=True,text=True,timeout=10)
 queries.append(dict(args=list(map(str,args)),code=p.returncode,stdout=p.stdout,stderr=p.stderr))
 if p.returncode:raise ValueError(p.stderr)
 return json.loads(p.stdout)
archive=root/'evidence/supported-online-vio-dev-1701.zip'
expected='07a2a247b87ff43304ec4c0fe787640264772ad12c272b354d5a5116cdecaeb2'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==expected
with zipfile.ZipFile(archive) as z:
 names=[n for n in z.namelist() if n.endswith('/world.sdf')]
 assert len(names)==1,names
 data=z.read(names[0]);member=names[0]
 consumed={}
 for texture in ('ground_albedo.png','board_albedo.png','obstacle_albedo.png'):
  n=member.rsplit('/',1)[0]+'/'+texture
  payload=z.read(n);(out/texture).write_bytes(payload)
  consumed[n]=hashlib.sha256(payload).hexdigest()
 (out/'texture-members.json').write_text(json.dumps(consumed,indent=2))
world=out/'original-world.sdf';world.write_bytes(data)
media=native('installation')
queue=[world,root/'assets/gazebo/models/x500_benchmark/model.sdf']
files={str(world),str(binary),str(root/'tools/benchmark/selected_resource_graph.py'),str(stage/'scan_fixed_inputs_v2.py')}
seen=set();edges=[];documents=[];selected_plugins={};selected_models={}
while queue:
 path=queue.pop(0).resolve(strict=True)
 if str(path) in seen:continue
 seen.add(str(path));files.add(str(path))
 raw=path.read_bytes()
 rows=references(raw,'dae' if path.suffix.lower()=='.dae' else 'sdf')
 documents.append(dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw)))
 for r in rows:
  r=dict(r,source=str(path),resolution_qualified=False)
  value=r['text'].strip()
  try:
   if r['kind']=='plugin':
    result=native('plugin',value);r.update(status='native-plugin-selection',native=result)
    selected_plugins[value]=result;files.add(result['selected'])
   elif r['kind']=='material-name':r['status']='material-name-only'
   elif value=='file://media/materials/scripts/gazebo.material':
    r.update(status='native-classic-material-installation',candidate=media['classic_material'])
    files.add(media['classic_material'])
   elif r['kind']=='unsupported':r['status']='unsupported'
   else:
    # Discovery only: no assertion that this implements runtime lookup order.
    if value.startswith('model://'):candidates=[p/value[8:] for p in modelroots]
    elif value.startswith('file://'):candidates=[Path(value[7:])]
    elif '://' in value:raise ValueError('remote or unknown URI forbidden')
    elif Path(value).is_absolute():candidates=[Path(value)]
    else:candidates=[path.parent/value,*[p/value for p in modelroots]]
    existing=sorted({str(p.resolve()) for p in candidates if p.exists()})
    r['candidate_attempts']=[str(p) for p in candidates]
    r['existing_candidates']=existing
    if len(existing)!=1:raise ValueError('missing or ambiguous local candidate')
    p=Path(existing[0])
    if r['kind']=='include' and p.is_dir():
     config=p/'model.config'
     if not config.is_file():raise ValueError('missing explicit model.config')
     files.add(str(config));result=native('model',p);selected_models[str(p)]=result
     p=Path(result['selected']);r['model_selection']=result
    if not p.is_file():raise ValueError('candidate nonregular')
    files.add(str(p));r.update(status='unique-local-candidate-not-runtime-proof',candidate=str(p))
    if p.suffix.lower() in ('.sdf','.dae'):queue.append(p)
  except Exception as e:r.update(status='unresolved',error=repr(e))
  edges.append(r)
inventory={'explicit-discovery-files':sorted(files)}
pre=snapshot(inventory)
post=snapshot(inventory)
packages=subprocess.run(['dpkg-query','-S',media['classic_material'],media['plugins']],capture_output=True,text=True,timeout=10)
summary=dict(producer=producer,input_archive_sha256=expected,member=member,member_sha256=hashlib.sha256(data).hexdigest(),
 environment={k:env.get(k) for k in ('GZ_SIM_RESOURCE_PATH','GZ_SIM_SYSTEM_PLUGIN_PATH','GZ_PLUGIN_PATH','HOME','GZ_HOMEDIR')},
 documents=documents,edges=edges,queries=queries,selected_plugins=selected_plugins,selected_models=selected_models,
 media=media,package_query=dict(returncode=packages.returncode,stdout=packages.stdout,stderr=packages.stderr),
 status_counts=dict(collections.Counter(e['status'] for e in edges)),files_stable=pre['files']==post['files'],
 snapshot_scope='two post-discovery snapshots; not a capture pre/post freeze',resource_graph_qualified=False,
 runtime_closure_qualified=False,physical_run=False,estimator_started=False,resources=active_resources())
(out/'fixed-discovery.json').write_text(json.dumps(summary,indent=2))
(out/'discovery-snapshot-pre.json').write_text(json.dumps(pre,indent=2))
(out/'discovery-snapshot-post.json').write_text(json.dumps(post,indent=2))
print(json.dumps({k:summary[k] for k in ('producer','status_counts','files_stable','resource_graph_qualified','resources')}))
