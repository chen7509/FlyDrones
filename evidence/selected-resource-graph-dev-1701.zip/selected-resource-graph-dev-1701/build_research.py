import hashlib,json,os,shlex,subprocess,urllib.request
from pathlib import Path

out=Path(__file__).resolve().parent
root=out.parents[1]
def command(args,name):
 p=subprocess.run(args,capture_output=True,text=True,timeout=90)
 (out/(name+'.json')).write_text(json.dumps(dict(args=args,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr),indent=2))
 if p.returncode: raise RuntimeError(name)
 return p.stdout
def digest(path):
 p=Path(path);return dict(path=str(p),resolved=str(p.resolve()),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
versions=command(['pkg-config','--modversion','gz-sim8','gz-common5','sdformat14'],'pkg-versions')
flags=shlex.split(command(['pkg-config','--cflags','--libs','gz-sim8','gz-common5','sdformat14'],'pkg-flags'))
command(['g++','--version'],'compiler-version')
binary=out/'resource_resolver'
source=root/'tools/benchmark/native/resource_resolver.cc'
command(['g++','-std=c++17','-Wall','-Wextra',str(source),'-o',str(binary),*flags],'compile')
ldd=command(['ldd',str(binary)],'ldd')
paths={str(binary),str(source)}
for line in ldd.splitlines():
 for word in line.split():
  if word.startswith('/') and Path(word).is_file(): paths.add(word)
(out/'build-manifest.json').write_text(json.dumps([digest(p) for p in sorted(paths)],indent=2))
command(['python3',str(root/'tests/native/run_resource_resolver_checks.py'),str(binary)],'native-checks')
sources=out/'sources';sources.mkdir(exist_ok=True)
fetches=[]
def fetch(url,name):
 try:
  data=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'FlyDrones-research'}),timeout=25).read()
  (sources/name).write_bytes(data)
  fetches.append(dict(url=url,name=name,sha256=hashlib.sha256(data).hexdigest()))
  return data
 except Exception as e:
  fetches.append(dict(url=url,name=name,error=repr(e)));return None
for repo,tag,files in [('gz-common','gz-common5_5.9.0',['src/SystemPaths.cc','LICENSE']),('sdformat','sdformat14_14.9.0',['src/parser.cc','src/SDF.cc','LICENSE'])]:
 meta=fetch(f'https://api.github.com/repos/gazebosim/{repo}/commits/{tag}',repo+'-commit.json')
 fetch(f'https://api.github.com/repos/gazebosim/{repo}',repo+'-maintenance.json')
 if meta:
  sha=json.loads(meta)['sha']
  for f in files:fetch(f'https://raw.githubusercontent.com/gazebosim/{repo}/{sha}/{f}',repo+'-'+Path(f).name)
for name in ['SystemLoader','ConfigLoader','SdfEntityCreator']:
 p=root/'results/runtime-resource-binding-dev-1701/sources'/f'{name}.cc'
 (sources/p.name).write_bytes(p.read_bytes())
fetch('https://raw.githubusercontent.com/gazebosim/gz-sim/446a44335a45b704b4d36dabcc5508ee34eeb3d8/src/Util.cc','gz-sim-Util.cc')
(sources/'fetch-manifest.json').write_text(json.dumps(fetches,indent=2))
print('compiled and native checks passed; source fetch outcomes recorded')
