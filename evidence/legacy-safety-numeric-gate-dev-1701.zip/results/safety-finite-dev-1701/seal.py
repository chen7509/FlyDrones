"""Seal the bounded, non-hardware SafetyGovernor verification."""

import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
stage = Path(__file__).resolve().parent
base = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
diff = subprocess.check_output(
    ["git", "diff", "--binary", "--", "src/flydrones/safety.py", "tests/test_control.py"],
    cwd=root,
)
(stage / "change.diff").write_bytes(diff)
(stage / "red-observations.json").write_text(
    json.dumps(
        {
            "schema": "flydrones-safety-finite-red-observations-v1",
            "base_commit": base,
            "record_kind": "transcription of observed terminal output, not captured raw stderr",
            "observations": [
                "NaN throttle and infinite forward produced moving 0.125/0.125 command without land request",
                "nonfinite command and telemetry tests: 2 failed before the guard",
                "negative/regressed control-time test: DID NOT REQUEST LAND",
                "battery-low landing latch test: returned forward=0.4",
                "10**1000 command: math.isfinite raised OverflowError before the safe fallback",
            ],
        },
        sort_keys=True,
        indent=2,
    ) + "\n",
    encoding="utf-8",
)
included = [
    root / "src/flydrones/safety.py",
    root / "tests/test_control.py",
    root / "docs/LEGACY_SAFETY_NUMERIC_GATE_REPORT.md",
    stage / "change.diff",
    stage / "test-output.txt",
    stage / "ruff-output.txt",
    stage / "diff-check.txt",
    stage / "red-observations.json",
    stage / "seal.py",
]
included.sort(key=lambda path: path.relative_to(root).as_posix())
manifest = {
    "schema": "flydrones-safety-finite-evidence-v1",
    "base_commit": base,
    "members": [
        {
            "path": path.relative_to(root).as_posix(),
            "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        }
        for path in included
    ],
}
target = root / "evidence/legacy-safety-numeric-gate-dev-1701.zip"
with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED) as archive:
    for path in included:
        archive.write(path, path.relative_to(root).as_posix())
    archive.writestr("manifest.json", json.dumps(manifest, sort_keys=True, indent=2) + "\n")
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    for item in manifest["members"]:
        assert hashlib.sha256(archive.read(item["path"])).hexdigest() == item["sha256"]
print(json.dumps({"sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "members": len(included)}))
