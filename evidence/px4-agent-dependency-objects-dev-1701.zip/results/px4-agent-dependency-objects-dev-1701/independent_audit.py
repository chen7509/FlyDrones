"""Read back the fixed bare Git stores without importing the production auditor."""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
PINS = {
    "fast_cdr": "757d5e422253568c487ad97c22e44680fc1ddbaf",
    "fast_dds": "575d045b55c16be1074ccd9eebf95e3e4274fe61",
    "foonathan_memory": "0f0775770fd1c506fa9c5ad566bd6ba59659db66",
    "spdlog": "eb3220622e73a4889eee355ffa37972b3cac3df5",
    "xrce_client": "d44dc3fa0c488376e34d26ed92853f1c66dcb670",
    "micro_cdr": "3d1b17703c7cf4f22def2910bc845bdb5152d7b5",
}
ENV = {**os.environ, "GIT_NO_REPLACE_OBJECTS": "1"}


def git(repo: Path, *args: str) -> bytes:
    return subprocess.check_output(["git", "-C", str(repo), *args], env=ENV,
                                   stderr=subprocess.PIPE)


def main() -> None:
    manifest = json.loads((HERE / "direct-objects-v4.json").read_text(encoding="utf-8"))
    records = {**manifest["dependencies"], **manifest["transitive_candidates"]}
    assert set(records) == set(PINS)
    tag_observation = (HERE / "micro_cdr-tag-observation.txt").read_bytes()
    expected_tag = f"{PINS['micro_cdr']}\trefs/tags/v2.0.1".encode()
    assert tag_observation.rstrip(b"\r\n") == expected_tag
    assert len(tag_observation.splitlines()) == 1
    assert records["micro_cdr"]["observed_ref"] == "refs/tags/v2.0.1"
    report = {}
    for name, expected in PINS.items():
        repo = HERE / f"{name}.git"
        row = records[name]
        assert row["commit"] == expected
        assert git(repo, "rev-parse", "refs/flydrones/pins/source").decode().strip() == expected
        assert git(repo, "rev-parse", "FETCH_HEAD").decode().strip() == expected
        assert git(repo, "cat-file", "-t", expected).strip() == b"commit"
        tree = git(repo, "rev-parse", f"{expected}^{{tree}}").decode().strip()
        assert row["tree"] == tree
        assert git(repo, "cat-file", "-t", tree).strip() == b"tree"
        license_raw = git(repo, "show", f"{expected}:LICENSE")
        assert hashlib.sha256(license_raw).hexdigest() == row["license_sha256"]
        assert len(license_raw) == row["license_bytes"]
        raw_tree = git(repo, "ls-tree", "-rz", expected)
        entries = [item for item in raw_tree.split(b"\0") if item]
        assert len(entries) == row["tree_entry_count"]
        gitlinks = []
        for item in entries:
            prefix, path = item.split(b"\t", 1)
            mode, kind, oid = prefix.split()
            if mode == b"160000":
                assert kind == b"commit"
                gitlinks.append({"path": path.decode(), "object": oid.decode()})
        assert sorted(gitlinks, key=lambda x: x["path"]) == row["gitlinks"]
        fsck = subprocess.run(["git", "-C", str(repo), "fsck", "--full", "--no-reflogs"],
                              env=ENV, capture_output=True)
        assert fsck.returncode == 0, (name, fsck.stderr.decode(errors="replace"))
        object_files = sorted(path for path in (repo / "objects").rglob("*") if path.is_file())
        assert object_files
        report[name] = {
            "commit": expected,
            "tree": tree,
            "license_sha256": row["license_sha256"],
            "tree_entries": len(entries),
            "gitlinks": gitlinks,
            "fsck_exit": fsck.returncode,
            "object_storage_sha256": {
                p.relative_to(repo).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in object_files
            },
        }
    print(json.dumps({"schema": "flydrones.agent_dependency_readback.v1",
                      "direct_count": 5, "transitive_candidate_count": 1,
                      "micro_cdr_tag_observation_sha256": hashlib.sha256(tag_observation).hexdigest(),
                      "all_local_git_objects_readback": True,
                      "transitive_source_closure_verified": False,
                      "agent_binary_built_or_run": False,
                      "repositories": report}, sort_keys=True))


if __name__ == "__main__":
    main()
