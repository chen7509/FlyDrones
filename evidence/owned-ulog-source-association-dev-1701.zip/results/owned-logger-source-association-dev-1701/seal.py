"""Exclusive seal of software evidence, not an actual PX4-source execution."""
import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
old = json.loads((root / 'results/openvins-cached-consumer-heartbeat-admission-dev-1701/eleven-original-archives-after.json').read_text())
old['evidence/openvins-cached-dataset-consumption-dev-1701.zip'] = 'ba7aef4a5236424ca45a387e52ff063be7144cbb2e38524b1933955d58dff71f'
for name, expected in old.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
with (out / 'twelve-original-archives-after.json').open('x', encoding='utf8') as stream:
    json.dump(old, stream, indent=2)
files = [root / name for name in (
    'tools/benchmark/owned_ulog_source.py', 'tools/benchmark/capture_contract.py',
    'tools/benchmark/capture_disarmed_sensors.py', 'tests/benchmark/test_owned_ulog_source.py',
    'tests/benchmark/test_owned_ulog_capture_integration.py', 'docs/OWNED_ULOG_SOURCE_ASSOCIATION_REPORT.md',
    'docs/superpowers/specs/2026-10-14-owned-logger-source-association.md',
    'docs/superpowers/plans/2026-10-14-owned-logger-source-association.md',
    'results/production-association-research-dev-1701/initial-admission.json')]
files += [p for p in out.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
files = sorted(set(files))
members = {}
for path in files:
    raw = path.read_bytes()
    members[path.relative_to(root).as_posix()] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
archive = root / 'evidence/owned-ulog-source-association-dev-1701.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for path in files:
        z.write(path, path.relative_to(root).as_posix())
    z.writestr('archive-members.json', json.dumps({'schema': 'software-evidence-seal-v1',
                 'actual_px4_source_execution': False, 'members': members}, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(set(z.namelist())) == len(members) + 1
    for name, row in members.items():
        raw = z.read(name)
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
record = {'archive': archive.relative_to(root).as_posix(), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
          'bytes': archive.stat().st_size, 'members': len(members) + 1,
          'report_sha256': members['docs/OWNED_ULOG_SOURCE_ASSOCIATION_REPORT.md']['sha256'],
          'prepublication_plan_sha256': members['docs/superpowers/plans/2026-10-14-owned-logger-source-association.md']['sha256'],
          'actual_px4_source_execution': False, 'actual_pidfd_duplication_executed': False}
with (root / 'evidence/owned-ulog-source-association-seal.json').open('x', encoding='utf8') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record))
