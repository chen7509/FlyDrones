import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
env = dict(os.environ, PYTHONPATH='src;.', PYTHONUTF8='1')
tests = ['test_owned_ulog_source', 'test_owned_ulog_capture_integration',
         'test_capture_runtime_runner', 'test_capture_contract', 'test_capture_runtime_wire_integration',
         'test_capture_wire_hooks', 'test_capture_wire_contract', 'test_px4_logger_runtime',
         'test_ulog_capture', 'test_disarmed_sensor_provenance']
commands = {
    'final-tests': [sys.executable, '-m', 'pytest', '-q',
                    *['tests/benchmark/' + t + '.py' for t in tests],
                    '--basetemp', str(out / 'final-fixtures')],
    'final-ruff': [sys.executable, '-m', 'ruff', 'check', 'tools/benchmark/owned_ulog_source.py',
                   'tools/benchmark/capture_contract.py', 'tools/benchmark/capture_disarmed_sensors.py',
                   'tests/benchmark/test_owned_ulog_source.py',
                   'tests/benchmark/test_owned_ulog_capture_integration.py'],
    'final-diff': ['git', 'diff', '--check'],
}
for name, argv in commands.items():
    record = {'argv': argv, 'cwd': str(root), 'environment_override': {'PYTHONPATH': 'src;.', 'PYTHONUTF8': '1'},
              'started_utc': datetime.now(timezone.utc).isoformat()}
    with (out / (name + '.txt')).open('xb') as stream:
        result = subprocess.run(argv, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=60)
    record.update(exit_code=result.returncode, completed_utc=datetime.now(timezone.utc).isoformat())
    with (out / (name + '.json')).open('x', encoding='utf8') as stream:
        json.dump(record, stream, indent=2)
    print(name, result.returncode)
