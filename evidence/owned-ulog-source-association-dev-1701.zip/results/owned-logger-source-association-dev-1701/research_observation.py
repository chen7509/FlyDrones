"""Post-implementation read-only toolchain/header observation; no syscall trial."""
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

out = Path(__file__).resolve().parent
rows = []
for name, command in [('architecture', ['uname', '-m']),
                      ('syscall-header', ['cat', '/usr/include/x86_64-linux-gnu/asm/unistd_64.h'])]:
    argv = ['wsl', '-d', 'Ubuntu', '--', *command]
    p = subprocess.run(argv, capture_output=True, timeout=15)
    for stream, data in [('stdout', p.stdout), ('stderr', p.stderr)]:
        (out / (name + '-' + stream + '.bin')).write_bytes(data)
    rows.append({'argv': argv, 'exit': p.returncode, 'stdout_sha256': hashlib.sha256(p.stdout).hexdigest(),
                 'stderr_sha256': hashlib.sha256(p.stderr).hexdigest()})
with (out / 'research-post-observation.json').open('x', encoding='utf8') as stream:
    json.dump({'observed_utc': datetime.now(timezone.utc).isoformat(), 'stage': 'post-implementation observation',
               'prior_unpersisted_tool_read_not_backfilled': True, 'pidfd_getfd_executed': False,
               'records': rows}, stream, indent=2)
print([(row['argv'][-1], row['exit']) for row in rows])
