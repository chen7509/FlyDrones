"""One-time, read-only WSL Docker identity observation; no capture occurs."""

from __future__ import annotations

import json
from pathlib import Path

from tools.connectome.xrce_typed_probe.daemon_identity import observe, validate_pair

HERE = Path(__file__).resolve().parent
OWNED_NAME = "flydrones-px4-source-1701"


def write_once(name: str, value: dict) -> None:
    with (HERE / name).open("x", encoding="utf-8") as output:
        json.dump(value, output, indent=2)


def main() -> None:
    before = observe(OWNED_NAME)
    write_once("before.json", before)
    after = observe(OWNED_NAME)
    write_once("after.json", after)
    pair = validate_pair(before, after, OWNED_NAME)
    pair["physical_capture_run"] = False
    pair["px4_or_agent_started"] = False
    pair["eligible_for_live_capture"] = False
    write_once("pair.json", pair)
    print(json.dumps(pair))


if __name__ == "__main__":
    main()
