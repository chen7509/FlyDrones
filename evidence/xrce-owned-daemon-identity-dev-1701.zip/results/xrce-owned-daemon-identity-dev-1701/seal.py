"""Seal the read-only daemon observation and prospective gate evidence."""

from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
OUTPUT = ROOT / "evidence/xrce-owned-daemon-identity-dev-1701.zip"
FILES = [
    "docs/XRCE_OWNED_DAEMON_IDENTITY_REPORT.md",
    "docs/superpowers/specs/2026-10-12-xrce-owned-daemon-identity-design.md",
    "docs/superpowers/plans/2026-10-12-xrce-owned-daemon-identity.md",
    "tools/connectome/xrce_typed_probe/daemon_identity.py",
    "tests/test_xrce_owned_daemon_identity.py",
]


def main() -> None:
    if OUTPUT.exists():
        raise FileExistsError(OUTPUT)
    paths = [ROOT / name for name in FILES]
    paths.extend(path for path in HERE.iterdir() if path.is_file()
                 and path.name not in {"seal-result.json"})
    members = {}
    for path in sorted(set(paths)):
        if path.is_symlink() or not path.is_file():
            raise ValueError("member is missing or symlink")
        name = path.relative_to(ROOT).as_posix()
        data = path.read_bytes()
        members[name] = {"sha256": hashlib.sha256(data).hexdigest(), "size": len(data)}
    with zipfile.ZipFile(OUTPUT, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for name in members:
            archive.write(ROOT / name, name)
        archive.writestr("MANIFEST.json", json.dumps({"members": members}, indent=2))
    with zipfile.ZipFile(OUTPUT) as archive:
        if archive.testzip() is not None:
            raise ValueError("CRC failure")
        for name, item in members.items():
            content = archive.read(name)
            if len(content) != item["size"] or hashlib.sha256(content).hexdigest() != item["sha256"]:
                raise ValueError("member mismatch: " + name)
    result = {"schema": "flydrones.xrce_daemon_evidence_seal.v1",
              "sha256": hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),
              "members": len(members) + 1,
              "all_members_verified": True,
              "physical_capture_run": False,
              "historical_capture_requalified": False}
    with (HERE / "seal-result.json").open("x", encoding="utf-8") as target:
        json.dump(result, target, indent=2)
    print(json.dumps(result))


if __name__ == "__main__":
    main()
