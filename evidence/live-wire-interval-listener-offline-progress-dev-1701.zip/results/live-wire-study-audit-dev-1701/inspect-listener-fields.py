import json,tempfile
from pathlib import Path
from collections import Counter
from tests.benchmark.test_live_wire_protocol_audit import ProtocolAuditTests
with tempfile.TemporaryDirectory() as d:
 e=ProtocolAuditTests.build_records(Path(d)/'segments')
 counts=Counter(); examples={}
 for row in e['records']:
  src=row['source']; event=row['event']
  if src not in ('owned','listener-0','listener-1','listener-2','listener-3','cold','maintenance'): continue
  kind=event.get('kind') or event.get('source')
  if src=='owned': kind+=':'+event['event']['kind']
  key=src+'/'+kind; counts[key]+=1
  if key not in examples: examples[key]=row
 print(json.dumps({'counts':dict(counts),'examples':examples},indent=2))
