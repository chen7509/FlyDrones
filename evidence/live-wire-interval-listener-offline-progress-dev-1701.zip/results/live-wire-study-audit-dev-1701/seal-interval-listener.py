from pathlib import Path
import hashlib,json,zipfile,subprocess
root=Path.cwd()
out=root/'evidence/live-wire-interval-listener-offline-progress-dev-1701.zip'
if out.exists(): raise FileExistsError(out)
base='results/live-wire-study-audit-dev-1701/'
files=[
 'tools/benchmark/audit_live_wire_study.py',
 'tools/benchmark/openvins_listener_transport.py','tools/benchmark/openvins_owned_bootstrap.py',
 'tools/benchmark/owned_daemon_connection.py','tools/benchmark/openvins_timesync_listener.py',
 'tools/benchmark/openvins_timesync_bootstrap.py','tools/benchmark/openvins_timesync_interval.py',
 'tools/benchmark/openvins_timesync_wire.py','tools/benchmark/openvins_observed_wire_session.py',
 'tests/benchmark/test_live_wire_interval_audit.py','tests/benchmark/test_live_wire_listener_audit.py',
 'tests/benchmark/test_live_wire_protocol_audit.py','tests/benchmark/test_openvins_observed_interval.py',
 'tests/benchmark/test_openvins_observed_wire_session.py','tests/benchmark/test_openvins_wire_bootstrap.py',
 'tests/benchmark/test_openvins_wire_maintenance.py','tests/benchmark/check_openvins_owned_bootstrap.py',
 'docs/LIVE_WIRE_RAW_EVIDENCE_MAP.md','docs/LIVE_WIRE_STUDY_PREPARATION_REPORT.md',
 'docs/superpowers/specs/2026-10-08-live-wire-study-design.md','docs/superpowers/plans/2026-10-08-live-wire-study.md',
]
files += [base+n for n in ('interval-red-v1.txt','interval-green-v1.txt','interval-regression-v2.txt',
 'listener-red-v1.txt','listener-green-v1.txt','listener-green-v2.txt','listener-bool-red-v1.txt',
 'listener-interval-regression-v1.txt','interval-listener-reader-regression-v1.txt',
 'listener-producer-regression-v1.txt','interval-listener-ruff-final.txt','interval-listener-diff-check.txt',
 'inspect-listener-fields.py','listener-fields.json')]
files.append(base+'seal-interval-listener.py')
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
rows=[]; blobs={}
for name in files:
 raw=(root/name).read_bytes(); blobs[name]=raw
 rows.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
manifest=dict(schema='offline-wire-progress-evidence-v1',producer_commit=commit,
 scope='synthetic interval/listener consistency and offline regression; Task2 incomplete',
 live_qualified=False,fusion_qualified=False,whole_package_review_complete=False,members=rows)
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for name,data in blobs.items(): z.writestr(name,data)
 z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(set(z.namelist()))==len(files)+1
 for row in rows:
  data=z.read(row['path'])
  assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
print(json.dumps(dict(path=str(out),members=len(files)+1,bytes=out.stat().st_size,
 sha256=hashlib.sha256(out.read_bytes()).hexdigest(),producer_commit=commit,crc_verified=True)))
