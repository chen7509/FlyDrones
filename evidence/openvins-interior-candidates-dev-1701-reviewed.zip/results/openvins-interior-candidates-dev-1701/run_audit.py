"""Audit all OpenVINS FAST candidates and selected new IDs on fixed input."""

import csv
import hashlib
import json
from collections import Counter
from pathlib import Path

from PIL import Image

from tools.benchmark.audit_openvins_detection_pruning import parse_detection_log
from tools.benchmark.audit_openvins_interior_candidates import is_interior, parse_candidate_log
from tools.benchmark.audit_openvins_init_feature_trace import parse_init_feature_trace
from tools.benchmark.audit_openvins_track_eligibility import parse_track_count_trace
from tools.benchmark.audit_openvins_track_lifetime import parse_track_log, validate_source_timeline


ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).parent
SOURCE = Path("C:/Users/yuche/.codex/worktrees/FlyDrones/prearm-target/results/openvins-prearm-board-dev-1701")
OUT = STAGE / "audit-v4"
EXPECTED_STATES = "1ccb4cd2eb55294e5130f052800d0bf83a962538ecba68c00c97e28c22af8975"
START, END = 15.618, 19.642


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


if OUT.exists():
    raise SystemExit("refusing existing audit output")
if digest(STAGE / "replay-v1/states.csv") != EXPECTED_STATES:
    raise SystemExit("candidate logging changed estimator states")
with Image.open(SOURCE / "episode-run-v3/rgb-frames/18000000000.ppm") as image:
    width, height = image.size
if (width, height) != (160, 120):
    raise SystemExit("camera dimensions changed")
with (SOURCE / "input-v1/frames.csv").open(newline="") as stream:
    source_timestamps = [int(row["timestamp_ns"]) for row in csv.DictReader(stream)]
with (ROOT / "results/openvins-track-eligibility-dev-1701/audit-v2/counts.csv").open(newline="") as stream:
    initializer_timestamps = [int(row["image_ns"]) for row in csv.DictReader(stream)]
text = (STAGE / "replay-v1/stdout.txt").read_text(errors="replace")
frames = parse_track_log(text)
validate_source_timeline(frames, source_timestamps, initializer_timestamps)
with (STAGE / "replay-v1/states.csv").open(newline="") as stream:
    state_rows = list(csv.DictReader(stream))
current_init_rows = parse_init_feature_trace(text, state_rows)
current_count_rows = parse_track_count_trace(text, current_init_rows)
if [int(row["image_ns"]) for row in current_count_rows] != initializer_timestamps:
    raise SystemExit("current initialization count times changed")
detections = parse_detection_log(text, frames)
records = parse_candidate_log(text, detections)
if len(records) != len(detections) or len(records) != len(frames) or len(records) != 608:
    raise SystemExit("candidate/frame pairing failed")
prearm = [record for record in records if START <= record.time <= END]
prearm_frames = [frame for frame in frames if START <= frame.time <= END]
prearm_detections = [record for record in detections if START <= record.time <= END]
if len(prearm) != len(prearm_frames) or len(prearm) != len(prearm_detections) or len(prearm) != 40:
    raise SystemExit("prearm frame window changed")
if any((row.input, row.edge, row.retained, row.candidates, row.added) != (18, 9, 9, 13, 9)
       for row in prearm_detections):
    raise SystemExit("prearm detector baseline changed")
drop_by_id = {drop.feature_id: (record.time, drop.reason) for record in detections for drop in record.drops}
prearm_writes = Counter(feature_id for frame in prearm_frames for feature_id in frame.ids)
singletons = {feature_id for feature_id, count in prearm_writes.items() if count == 1}
new_by_id = {point.feature_id: (record.time, point) for record in records for point in record.new}
if len(singletons) != 360 or not singletons.issubset(new_by_id):
    raise SystemExit("prearm singleton identities changed")
singleton_edge_next = {
    feature_id for feature_id in singletons
    if feature_id in drop_by_id and drop_by_id[feature_id][1] == "edge"
    and abs(drop_by_id[feature_id][0] - new_by_id[feature_id][0] - 0.1) < 1e-8
}
if len(singleton_edge_next) != 360:
    raise SystemExit("singleton ID to next-frame edge drop relation changed")

OUT.mkdir()
with (OUT / "frames.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(("image_ns", "candidates", "candidate_unique_coordinates", "candidate_interior", "candidate_border", "new", "new_interior", "new_border"))
    for record in records:
        ci = sum(is_interior(point.x, point.y, width, height) for point in record.candidates)
        ni = sum(is_interior(point.x, point.y, width, height) for point in record.new)
        writer.writerow((round(record.time * 1e9), len(record.candidates), len({(point.x, point.y) for point in record.candidates}), ci, len(record.candidates) - ci,
                         len(record.new), ni, len(record.new) - ni))
with (OUT / "candidates.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(("image_ns", "x_px", "y_px", "interior"))
    for record in records:
        for point in record.candidates:
            writer.writerow((round(record.time * 1e9), f"{point.x:.3f}", f"{point.y:.3f}",
                             int(is_interior(point.x, point.y, width, height))))
with (OUT / "new.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(("image_ns", "id", "x_px", "y_px", "interior", "prearm_singleton", "next_frame_drop"))
    for record in records:
        for point in record.new:
            next_drop = drop_by_id.get(point.feature_id)
            drop_reason = next_drop[1] if next_drop and abs(next_drop[0] - record.time - 0.1) < 1e-8 else ""
            writer.writerow((round(record.time * 1e9), point.feature_id, f"{point.x:.3f}", f"{point.y:.3f}",
                             int(is_interior(point.x, point.y, width, height)), int(point.feature_id in singletons),
                             drop_reason))

summary = {
    "schema": "flydrones-openvins-interior-candidates-audit-v1",
    "upstream": "rpng/open_vins@69488123ed9362dd44b6f28e7f4680abbff1442b",
    "source_manifest_sha256": digest(SOURCE / "input-v1/manifest.json"),
    "prior_pr28_archive_sha256": digest(ROOT / "evidence/openvins-detection-pruning-dev-1701.zip"),
    "states_sha256": digest(STAGE / "replay-v1/states.csv"),
    "image_size": [width, height],
    "frames": len(records),
    "paired_initializer_attempts": len(initializer_timestamps),
    "current_reparsed_initializer_counts": len(current_count_rows),
    "prearm_frames": len(prearm),
    "prearm_candidate_total": sum(len(record.candidates) for record in prearm),
    "prearm_candidate_unique_coordinate_count": len({(point.x, point.y) for record in prearm for point in record.candidates}),
    "prearm_candidate_unique_per_frame": sorted({len({(point.x, point.y) for point in record.candidates}) for record in prearm}),
    "prearm_candidate_interior": sum(is_interior(point.x, point.y, width, height) for record in prearm for point in record.candidates),
    "prearm_candidate_outside_image": sum(point.x < 0 or point.x >= width or point.y < 0 or point.y >= height
                                          for record in prearm for point in record.candidates),
    "prearm_new_total": sum(len(record.new) for record in prearm),
    "prearm_new_interior": sum(is_interior(point.x, point.y, width, height) for record in prearm for point in record.new),
    "prearm_new_border": sum(not is_interior(point.x, point.y, width, height) for record in prearm for point in record.new),
    "prearm_singletons": len(singletons),
    "prearm_singletons_edge_dropped_next_frame": len(singleton_edge_next),
    "prearm_singleton_new_interior": sum(is_interior(new_by_id[feature_id][1].x, new_by_id[feature_id][1].y, width, height)
                                        for feature_id in singletons),
}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
