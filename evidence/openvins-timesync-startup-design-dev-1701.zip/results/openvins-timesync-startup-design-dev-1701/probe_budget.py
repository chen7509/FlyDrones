"""Offline feasibility probe; synthetic exchanges never establish PX4 delivery."""

import hashlib
import json
import socket
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.benchmark.openvins_ekf2_disarmed_preflight import (  # noqa: E402
    BoundedTimesyncVerifier,
    TimesyncExchange,
)


def deny_network(*args, **kwargs):
    raise AssertionError("offline experiment must not open a socket")


socket.socket = deny_network
socket.create_connection = deny_network


def case(name, rate, count, first_s, bad_every=0):
    sync = BoundedTimesyncVerifier(name)
    first_ns = int(first_s * 1_000_000_000)
    period_ns = 1_000_000_000 // rate
    first_convergence_ns = None
    for index in range(count):
        request = first_ns + index * period_ns
        rtt = 10_000_000 if bad_every and (index + 1) % bad_every == 0 else 2_000_000
        receive = request + rtt
        remote = (request + receive) // 2 + 1_000_000_000
        result = sync.observe(TimesyncExchange(request, remote, receive))
        if result["converged"] and first_convergence_ns is None:
            first_convergence_ns = receive
    return {
        "name": name, "nominal_rate_hz": rate, "requests": count,
        "first_request_sim_s": first_s, "every_nth_rtt_at_rejection_boundary": bad_every,
        "accepted": sync.sequence, "model_converged": sync.converged,
        "model_first_convergence_sim_s": None if first_convergence_ns is None else first_convergence_ns / 1e9,
        "model_ready_by_8s": first_convergence_ns is not None and first_convergence_ns <= 8_000_000_000,
        "actual_px4_convergence_qualified": False,
    }


cases = [
    case("10hz_25s_window", 10, 250, 0.1),
    case("10hz_full_500", 10, 500, 0.1),
    case("100hz_500", 100, 500, 2.0),
    case("100hz_late_start", 100, 500, 4.0),
    case("100hz_every_rtt_rejected", 100, 500, 2.0, 1),
    case("100hz_500_one_in_five_rejected", 100, 500, 2.0, 5),
    case("100hz_625_one_in_five_rejected", 100, 625, 2.0, 5),
]
assert [row["accepted"] for row in cases] == [250, 500, 500, 500, 0, 400, 500]
assert [row["model_ready_by_8s"] for row in cases] == [False, False, True, False, False, False, False]
assert cases[1]["model_first_convergence_sim_s"] == 50.002
assert cases[2]["model_first_convergence_sim_s"] == 6.992
assert cases[3]["model_first_convergence_sim_s"] == 8.992
assert cases[6]["model_first_convergence_sim_s"] == 8.232
report = {
    "schema": "timesync-startup-feasibility-v1",
    "synthetic_only": True,
    "network_odometry": False,
    "px4_parameter_access": False,
    "physics_started": False,
    "cases": cases,
    "sha256": {
        str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in [Path(__file__), ROOT / "tools/benchmark/openvins_ekf2_disarmed_preflight.py"]
    },
}
with Path(sys.argv[1]).open("x", encoding="utf-8") as stream:
    json.dump(report, stream, indent=2)
print(json.dumps(report, indent=2))
