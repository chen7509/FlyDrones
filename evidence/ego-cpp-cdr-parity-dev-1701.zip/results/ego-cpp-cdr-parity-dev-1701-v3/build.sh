#!/usr/bin/env bash
set -Eeo pipefail
source /opt/ros/humble/setup.bash
source /ego_ws/install/setup.bash
set -u
test "$(git -C /ego_ws/src/ego-planner-swarm rev-parse HEAD)" = \
  23a8d5a191711dd65633df689bd00f55d4dea8f9
test -z "$(git -C /ego_ws/src/ego-planner-swarm status --porcelain=v1)"
test "$(sha256sum /ego_ws/install/quadrotor_msgs/share/quadrotor_msgs/msg/PositionCommand.msg | cut -d' ' -f1)" = \
  9e0e570fa796d18ea4170c569491d1ba6a63daa78007d0d12c3b7b208c597944
cmake -S /probe -B /tmp/ego-cdr-build -DCMAKE_BUILD_TYPE=Release
cmake --build /tmp/ego-cdr-build --parallel 1
sha256sum /tmp/ego-cdr-build/ego_cpp_cdr_probe
/tmp/ego-cdr-build/ego_cpp_cdr_probe
