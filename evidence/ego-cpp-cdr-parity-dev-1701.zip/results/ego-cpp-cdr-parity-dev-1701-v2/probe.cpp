#include <openssl/sha.h>
#include <quadrotor_msgs/msg/position_command.hpp>
#include <rclcpp/serialization.hpp>
#include <rclcpp/serialized_message.hpp>

#include <iomanip>
#include <iostream>
#include <sstream>

int main()
{
  quadrotor_msgs::msg::PositionCommand command;
  command.header.stamp.sec = 0;
  command.header.stamp.nanosec = 9000;
  command.header.frame_id = "world";
  command.position.z = 1.0;
  command.trajectory_id = 7;
  command.trajectory_flag =
      quadrotor_msgs::msg::PositionCommand::TRAJECTORY_STATUS_READY;

  rclcpp::Serialization<quadrotor_msgs::msg::PositionCommand> serializer;
  rclcpp::SerializedMessage serialized;
  serializer.serialize_message(&command, &serialized);
  const auto &raw = serialized.get_rcl_serialized_message();
  unsigned char digest[SHA256_DIGEST_LENGTH];
  SHA256(raw.buffer, raw.buffer_length, digest);
  std::ostringstream sha;
  std::ostringstream hex;
  sha << std::hex << std::setfill('0');
  hex << std::hex << std::setfill('0');
  for (unsigned char value : digest)
    sha << std::setw(2) << static_cast<unsigned int>(value);
  for (size_t index = 0; index < raw.buffer_length; ++index)
    hex << std::setw(2) << static_cast<unsigned int>(raw.buffer[index]);
  std::cout << "{\"schema\":\"flydrones-ego-cpp-cdr-probe-v1\","
            << "\"bytes\":" << raw.buffer_length << ","
            << "\"sha256\":\"" << sha.str() << "\","
            << "\"cdr_hex\":\"" << hex.str() << "\","
            << "\"trajectory_id\":7,\"trajectory_flag\":1}"
            << std::endl;
  return 0;
}
