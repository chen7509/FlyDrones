$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$image = 'sha256:a4dae62b38bc01a01d084be7b68db83ec804fef7673604e1a9c986a4baa88a6a'
$name = 'fly-ego-cpp-cdr-probe-1701-v2'
$available = [double](Get-Counter '\Memory\Available MBytes').CounterSamples[0].CookedValue
$actualImage = (& docker image inspect fly-ego-benchmark:humble --format '{{.Id}}').Trim()
$running = @(& docker ps --format '{{.Names}}')
$owned = @(& docker ps -a --filter "name=^/$name$" --format '{{.Names}}')
[ordered]@{
    schema = 'flydrones-ego-cpp-cdr-preflight-v1'
    timestamp_utc = [DateTime]::UtcNow.ToString('o')
    available_windows_mib = $available
    minimum_windows_mib = 1800
    memory_limit_mib = 768
    image_id = $actualImage
    expected_image_id = $image
    cpp_sha256 = (Get-FileHash -LiteralPath (Join-Path $root 'probe.cpp') -Algorithm SHA256).Hash.ToLowerInvariant()
    cmake_sha256 = (Get-FileHash -LiteralPath (Join-Path $root 'CMakeLists.txt') -Algorithm SHA256).Hash.ToLowerInvariant()
    build_sha256 = (Get-FileHash -LiteralPath (Join-Path $root 'build.sh') -Algorithm SHA256).Hash.ToLowerInvariant()
    running_containers = $running
    existing_owned_container = $owned
} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $root 'preflight.json') -Encoding utf8
if ($available -lt 1800 -or $actualImage -ne $image -or $running.Count -gt 0 -or $owned.Count -gt 0) {
    throw 'Bound EGO C++ CDR probe admission refused.'
}
$args = @(
    'run', '--rm', '--name', $name, '--pull', 'never', '--network', 'none',
    '--read-only', '--tmpfs', '/tmp:rw,size=256m', '--memory', '768m',
    '--memory-swap', '768m', '--cpus', '1', '--pids-limit', '64',
    '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges',
    '--mount', "type=bind,source=$root,target=/probe,readonly",
    '--entrypoint', '/bin/bash', $image, '-lc',
    'exec /usr/bin/timeout 180s bash /probe/build.sh'
)
[ordered]@{ executable = 'docker'; argv = $args } | ConvertTo-Json -Depth 5 |
    Set-Content -LiteralPath (Join-Path $root 'command.json') -Encoding utf8
try {
    & docker @args 1> (Join-Path $root 'stdout.txt') 2> (Join-Path $root 'stderr.txt')
    $code = $LASTEXITCODE
} finally {
    $remaining = @(& docker ps -a --filter "name=^/$name$" --format '{{.Names}}')
    [ordered]@{
        docker_exit_code = $code
        remaining_owned_container = $remaining
        available_windows_after_mib = [double](Get-Counter '\Memory\Available MBytes').CounterSamples[0].CookedValue
        timestamp_utc = [DateTime]::UtcNow.ToString('o')
    } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $root 'completion.json') -Encoding utf8
}
if ($code -ne 0 -or $remaining.Count -gt 0) {
    throw "Bound EGO C++ CDR probe failed: exit=$code"
}
