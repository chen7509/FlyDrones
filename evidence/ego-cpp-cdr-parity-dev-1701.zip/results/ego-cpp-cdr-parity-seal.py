import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
included = []
for name in (
    "ego-cpp-cdr-parity-dev-1701",
    "ego-cpp-cdr-parity-dev-1701-v2",
    "ego-cpp-cdr-parity-dev-1701-v3",
    "ego-cpp-cdr-parity-dev-1701-v4",
    "ego-cpp-cdr-parity-dev-1701-v5",
):
    included.extend(p for p in (root / "results" / name).rglob("*") if p.is_file())
included.append(root / "results" / "ego-patched-build-dev-1701" / "preflight.json")
included.append(root / "docs" / "EGO_CPP_CDR_PARITY_REPORT.md")
included.append(Path(__file__).resolve())
included.sort(key=lambda p: p.relative_to(root).as_posix())

manifest = {
    "schema": "flydrones-ego-cpp-cdr-parity-evidence-v1",
    "members": [
        {
            "path": p.relative_to(root).as_posix(),
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
            "bytes": p.stat().st_size,
        }
        for p in included
    ],
}
target = root / "evidence" / "ego-cpp-cdr-parity-dev-1701.zip"
target.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED) as archive:
    for p in included:
        archive.write(p, p.relative_to(root).as_posix())
    archive.writestr("manifest.json", json.dumps(manifest, sort_keys=True, indent=2) + "\n")

with zipfile.ZipFile(target) as archive:
    bad = archive.testzip()
    assert bad is None, bad
    for member in manifest["members"]:
        assert hashlib.sha256(archive.read(member["path"])).hexdigest() == member["sha256"]

print(json.dumps({"path": str(target), "sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "members": len(manifest["members"]), "zip_crc_ok": True}, sort_keys=True))
