"""Check the real bridge deserializer against retained DDS raw callback bytes."""

import base64
import hashlib
import json

from quadrotor_msgs.msg import PositionCommand
from rclpy.serialization import deserialize_message, serialize_message


with open("/dds.json", encoding="utf-8") as stream:
    trace = json.load(stream)
assert trace["schema"] == "flydrones-ego-ros-dds-loopback-v2"
row = trace["messages"]["position_command"]
raw = base64.b64decode(row["cdr_b64"], validate=True)
assert hashlib.sha256(raw).hexdigest() == row["sha256"]
command = deserialize_message(raw, PositionCommand)
canonical = serialize_message(command)
assert raw == canonical + b"\x00" * 3
print(json.dumps({
    "schema": "flydrones-ego-padded-command-deserialize-v1",
    "raw_bytes": len(raw),
    "raw_sha256": hashlib.sha256(raw).hexdigest(),
    "canonical_bytes": len(canonical),
    "canonical_sha256": hashlib.sha256(canonical).hexdigest(),
    "stamp_ns": command.header.stamp.nanosec,
    "trajectory_id": command.trajectory_id,
    "trajectory_flag": command.trajectory_flag,
    "bridge_deserializer_accepts_measured_padding": True,
    "actual_ego_planner_used": False,
    "source_authenticated": False,
    "teacher_qualified": False,
}, sort_keys=True, separators=(",", ":")))
