"""Seal this trial's files with per-member SHA-256 and zip CRC verification."""

import hashlib
import json
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DESTINATION = ROOT.parents[1] / "evidence" / "agent-configure-preflight-dev-1701.zip"


def main() -> None:
    files = sorted(path for path in ROOT.rglob("*") if path.is_file())
    manifest = [
        {
            "path": path.relative_to(ROOT).as_posix(),
            "size": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        }
        for path in files
    ]
    DESTINATION.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DESTINATION, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, path.relative_to(ROOT).as_posix())
        archive.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
    with zipfile.ZipFile(DESTINATION) as archive:
        assert archive.testzip() is None
        for item in manifest:
            assert hashlib.sha256(archive.read(item["path"])).hexdigest() == item["sha256"]
    print(json.dumps({"zip": str(DESTINATION), "members": len(manifest) + 1, "sha256": hashlib.sha256(DESTINATION.read_bytes()).hexdigest()}))


if __name__ == "__main__":
    main()
