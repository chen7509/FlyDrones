# Agent configure command record

Environment: `wsl -d Ubuntu`; source `/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/results/px4-agent-v243-pinned-source-dev-1701/source-v4`; build `/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/results/agent-configure-preflight-dev-1701/build`.

The first wrapper ran `timeout 90s cmake -S <source> -B <build> -G Ninja -DCMAKE_BUILD_TYPE=Release -DUAGENT_SUPERBUILD=ON -DUAGENT_BUILD_TESTS=OFF`, redirecting stdout and stderr to this directory. The wrapper's `code=$?`/`printf` segment lost the variable across PowerShell/WSL quoting; `configure.exit` is empty. Its stdout contains `Configuring done` and `Generating done`.

For exit verification the same CMake invocation was run directly through `wsl -d Ubuntu -- cmake ...`, with **no build**. The command tool reported process exit 0 and again `Configuring done`/`Generating done`. It took 13.45 seconds. Its output was tool-captured rather than saved into the initial redirected stdout file. `audit.py` verifies the resulting cache, graph, fixed checkout scripts, absent download/build stamps and source hashes.

Neither command invoked `cmake --build`, an ExternalProject target, PX4, Gazebo, OpenVINS or an Agent executable.
