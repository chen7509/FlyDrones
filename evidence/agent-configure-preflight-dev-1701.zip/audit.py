"""Independent, read-only checks of the bounded Agent CMake configuration."""

import hashlib
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parent
BUILD = ROOT / "build"
COMMITS = {
    "fastcdr": "757d5e422253568c487ad97c22e44680fc1ddbaf",
    "fastdds": "575d045b55c16be1074ccd9eebf95e3e4274fe61",
    "foonathan_memory": "0f0775770fd1c506fa9c5ad566bd6ba59659db66",
    "microxrcedds_client": "d44dc3fa0c488376e34d26ed92853f1c66dcb670",
    "spdlog": "eb3220622e73a4889eee355ffa37972b3cac3df5",
}


def main() -> None:
    before = json.loads((ROOT / "source-before.json").read_text(encoding="utf-8-sig"))
    after = json.loads((ROOT / "source-after.json").read_text(encoding="utf-8-sig"))
    cache = (BUILD / "CMakeCache.txt").read_text()
    ninja = (BUILD / "build.ninja").read_text()
    targets = []
    for name, commit in sorted(COMMITS.items()):
        clone = (BUILD / name / "tmp" / f"{name}-gitclone.cmake").read_text()
        stamps = BUILD / name / "src" / f"{name}-stamp"
        targets.append(
            {
                "name": name,
                "target_generated": bool(re.search(rf"(?m)^build {name}: phony", ninja)),
                "fixed_checkout_generated": f'checkout "{commit}"' in clone,
                "download_stamp_absent": not (stamps / f"{name}-download").exists(),
                "build_stamp_absent": not (stamps / f"{name}-build").exists(),
            }
        )
    fastdds_cache = (BUILD / "fastdds" / "tmp" / "fastdds-cache-Release.cmake").read_text()
    result = {
        "schema": "flydrones.agent_configure_preflight_audit.v2",
        "first_wrapper_exit_lost": (ROOT / "configure.exit").read_text().strip() == "",
        "direct_verification_command_exit_observed_in_tool": 0,
        "source_before_after_identical": before == after,
        "source_files": len(before),
        "cache_sha256": hashlib.sha256((BUILD / "CMakeCache.txt").read_bytes()).hexdigest(),
        "ninja_sha256": hashlib.sha256((BUILD / "build.ninja").read_bytes()).hexdigest(),
        "release_superbuild_tests_off": all(
            line in cache
            for line in (
                "CMAKE_BUILD_TYPE:STRING=Release",
                "UAGENT_SUPERBUILD:BOOL=ON",
                "UAGENT_BUILD_TESTS:BOOL=OFF",
            )
        ),
        "five_system_packages_not_found": all(
            f"{package}_DIR:PATH={package}_DIR-NOTFOUND" in cache
            for package in (
                "fastcdr",
                "fastrtps",
                "foonathan_memory",
                "microxrcedds_client",
                "spdlog",
            )
        ),
        "fastdds_nested_thirdparty_on_argument": 'set(THIRDPARTY "ON"' in fastdds_cache,
        "nested_fastdds_configured": False,
        "agent_binary_built": False,
        "targets": targets,
    }
    if not result["source_before_after_identical"] or result["source_files"] != 214:
        raise SystemExit("source byte inventory mismatch")
    if not result["release_superbuild_tests_off"] or not result["five_system_packages_not_found"]:
        raise SystemExit("unexpected top-level selection")
    if not result["fastdds_nested_thirdparty_on_argument"]:
        raise SystemExit("Fast-DDS CMake argument mismatch")
    if not all(all(v for k, v in t.items() if k != "name") for t in targets):
        raise SystemExit("an external target is missing, unpinned, or already executed")
    (ROOT / "audit.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
