"""Capture the exact isolated upstream diff and build identity once."""

import hashlib
import subprocess
from pathlib import Path


STAGE = Path(__file__).parent
UPSTREAM = "/home/yuchen7509/flydrones-upstream/open_vins_detection_pruning_probe"
LIBRARY = f"{UPSTREAM}/ov_msckf/build/libov_msckf_lib.so"
RUNNER = (Path("C:/Users/yuche/.codex/worktrees/FlyDrones/prearm-target")
          / "results/openvins-prearm-board-dev-1701/dependencies-v1/offline_probe")
COMMANDS = {
    "upstream-applied.patch": f"git -C {UPSTREAM} diff --binary HEAD",
    "upstream-head.txt": f"git -C {UPSTREAM} rev-parse HEAD",
    "upstream-status.txt": f"git -C {UPSTREAM} status --short",
    "upstream-diff-check.txt": f"git -C {UPSTREAM} diff --check",
    "library-sha256.txt": f"sha256sum {LIBRARY}",
    "library-bytes.txt": f"stat -c %s {LIBRARY}",
    "compiler.txt": "g++ --version | head -1",
    "opencv.txt": "pkg-config --modversion opencv4",
    "runner-ldd.txt": f"LD_LIBRARY_PATH={UPSTREAM}/ov_msckf/build ldd {RUNNER.as_posix().replace('C:/', '/mnt/c/').replace('/Users/', '/Users/')}",
}


for name in COMMANDS:
    if (STAGE / name).exists():
        raise SystemExit(f"refusing to overwrite {name}")
for name, command in COMMANDS.items():
    result = subprocess.run(["wsl", "-e", "bash", "-lc", command], capture_output=True, check=False)
    if result.returncode:
        raise SystemExit(f"{name}: exit={result.returncode} stderr={result.stderr.decode(errors='replace')}")
    (STAGE / name).write_bytes(result.stdout)
library_sha = (STAGE / "library-sha256.txt").read_text().split()[0]
if library_sha != "413e6adf693e3e5adff7ec66ced28fe641bb5312f009bd79219336188b5548e3":
    raise SystemExit("library identity changed")
if (STAGE / "upstream-head.txt").read_text().strip() != "69488123ed9362dd44b6f28e7f4680abbff1442b":
    raise SystemExit("upstream HEAD changed")
if (STAGE / "upstream-diff-check.txt").read_bytes():
    raise SystemExit("upstream diff whitespace check failed")
if "libov_msckf_lib.so => " + LIBRARY not in (STAGE / "runner-ldd.txt").read_text():
    raise SystemExit("runner resolved different OpenVINS library")
print("captured", len(COMMANDS), "build records; diff sha256", hashlib.sha256((STAGE / "upstream-applied.patch").read_bytes()).hexdigest())
