"""Audit one fixed-input OpenVINS detector removal trace and preserve every drop."""

import csv
import hashlib
import json
from collections import Counter
from pathlib import Path

from tools.benchmark.audit_openvins_detection_pruning import REASONS, parse_detection_log
from tools.benchmark.audit_openvins_track_lifetime import parse_track_log, validate_source_timeline


ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).parent
OUT = STAGE / "audit-v1"
PREVIOUS = ROOT / "results/openvins-track-lifetime-dev-1701"
SOURCE = Path("C:/Users/yuche/.codex/worktrees/FlyDrones/prearm-target/results/openvins-prearm-board-dev-1701")
START, END = 15.618, 19.642
EXPECTED_STATES = "1ccb4cd2eb55294e5130f052800d0bf83a962538ecba68c00c97e28c22af8975"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


if OUT.exists():
    raise SystemExit("refusing existing audit output")
if digest(STAGE / "replay-v1/states.csv") != EXPECTED_STATES:
    raise SystemExit("detector logging changed estimator states")
with (SOURCE / "input-v1/frames.csv").open(newline="") as stream:
    source_timestamps = [int(row["timestamp_ns"]) for row in csv.DictReader(stream)]
with (ROOT / "results/openvins-track-eligibility-dev-1701/audit-v2/counts.csv").open(newline="") as stream:
    initializer_timestamps = [int(row["image_ns"]) for row in csv.DictReader(stream)]
if len(initializer_timestamps) != 254:
    raise SystemExit("initializer attempt count changed")
text = (STAGE / "replay-v1/stdout.txt").read_text(errors="replace")
frames = parse_track_log(text)
validate_source_timeline(frames, source_timestamps, initializer_timestamps)
records = parse_detection_log(text, frames)
if len(records) != 608:
    raise SystemExit(f"unexpected detector record count: {len(records)}")

prearm_records = [record for record in records if START <= record.time <= END]
prearm_frames = [frame for frame in frames if START <= frame.time <= END]
if len(prearm_records) != 40 or len(prearm_frames) != 40:
    raise SystemExit("unexpected preunlock frame count")
all_drops = [(record.time, drop) for record in records for drop in record.drops]
drop_ids = [drop.feature_id for _, drop in all_drops]
if len(set(drop_ids)) != len(drop_ids):
    raise SystemExit("same ID dropped more than once")
drop_by_id = {drop.feature_id: (time, drop.reason) for time, drop in all_drops}
prearm_writes = Counter(feature_id for frame in prearm_frames for feature_id in frame.ids)
prearm_last_write = {feature_id: frame.time for frame in prearm_frames for feature_id in frame.ids}
singletons = {feature_id for feature_id, count in prearm_writes.items() if count == 1}
next_frame_edge = {
    feature_id for feature_id in singletons
    if feature_id in drop_by_id
    and drop_by_id[feature_id][1] == "edge"
    and abs(drop_by_id[feature_id][0] - prearm_last_write[feature_id] - 0.1) < 1e-8
}
if len(singletons) != 360 or len(next_frame_edge) != 360:
    raise SystemExit("singleton ID to next-frame border-drop matching failed")

OUT.mkdir()
with (OUT / "frames.csv").open("w", newline="") as stream:
    fields = ("image_ns", "input", *REASONS, "retained", "candidates", "added", "branch", "drop_count")
    writer = csv.DictWriter(stream, fieldnames=fields)
    writer.writeheader()
    for record in records:
        writer.writerow({"image_ns": round(record.time * 1e9), "input": record.input,
                         **{reason: getattr(record, reason) for reason in REASONS},
                         "retained": record.retained, "candidates": record.candidates,
                         "added": record.added, "branch": record.branch, "drop_count": len(record.drops)})
with (OUT / "drops.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(("image_ns", "id", "reason", "x_px", "y_px", "prearm_singleton", "next_frame_edge"))
    for time, drop in all_drops:
        writer.writerow((round(time * 1e9), drop.feature_id, drop.reason, f"{drop.x:.3f}", f"{drop.y:.3f}",
                         int(drop.feature_id in singletons), int(drop.feature_id in next_frame_edge)))

report = {
    "schema": "flydrones-openvins-detection-pruning-audit-v1",
    "upstream": "rpng/open_vins@69488123ed9362dd44b6f28e7f4680abbff1442b",
    "source_manifest_sha256": digest(SOURCE / "input-v1/manifest.json"),
    "prior_lifetime_archive_sha256": digest(ROOT / "evidence/openvins-track-lifetime-dev-1701.zip"),
    "states_sha256": digest(STAGE / "replay-v1/states.csv"),
    "tracker_frames": len(frames),
    "detector_records": len(records),
    "paired_initializer_attempts": len(initializer_timestamps),
    "all_drop_reasons": dict(Counter(drop.reason for _, drop in all_drops)),
    "prearm_window_s": [START, END],
    "prearm_frames": len(prearm_frames),
    "prearm_input_total": sum(record.input for record in prearm_records),
    "prearm_retained_total": sum(record.retained for record in prearm_records),
    "prearm_added_total": sum(record.added for record in prearm_records),
    "prearm_drop_reasons": dict(Counter(drop.reason for record in prearm_records for drop in record.drops)),
    "prearm_unique_written_ids": len(prearm_writes),
    "prearm_singleton_ids": len(singletons),
    "prearm_singletons_dropped_by_edge_next_frame": len(next_frame_edge),
}
(OUT / "summary.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
