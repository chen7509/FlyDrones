"""Pin source, patches, library, input and all replay/audit outputs."""

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).parent
SOURCE = Path("C:/Users/yuche/.codex/worktrees/FlyDrones/prearm-target/results/openvins-prearm-board-dev-1701")
OUT = STAGE / "provenance.json"


def digest(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


if OUT.exists():
    raise SystemExit("refusing existing provenance")
prior = json.loads((ROOT / "results/openvins-track-lifetime-dev-1701/provenance-v2.json").read_text())
files = {
    "new_logging_patch": ROOT / "tools/benchmark/openvins_detection_pruning.patch",
    "applied_upstream_diff": STAGE / "upstream-applied.patch",
    "prior_evidence_index": ROOT / "evidence/openvins-track-lifetime-dev-1701.sha256.json",
    "offline_runner": SOURCE / "dependencies-v1/offline_probe",
    "estimator_config": SOURCE / "dependencies-v1/config-v2/estimator_config.yaml",
    "source_input_manifest": SOURCE / "input-v1/manifest.json",
    "source_imu_csv": SOURCE / "input-v1/imu.csv",
    "source_frames_csv": SOURCE / "input-v1/frames.csv",
    "new_replay_states": STAGE / "replay-v1/states.csv",
    "new_replay_stdout": STAGE / "replay-v1/stdout.txt",
    "new_replay_stderr": STAGE / "replay-v1/stderr.txt",
    "new_audit_summary": STAGE / "audit-v1/summary.json",
    "new_audit_frames": STAGE / "audit-v1/frames.csv",
    "new_audit_drops": STAGE / "audit-v1/drops.csv",
}
hashes = {key: digest(path) for key, path in files.items()}
for key in ("offline_runner", "estimator_config", "source_input_manifest", "source_imu_csv", "source_frames_csv"):
    if hashes[key] != prior["sha256"][key]:
        raise SystemExit(f"source changed: {key}")
if hashes["new_replay_states"] != prior["sha256"]["new_replay_states"]:
    raise SystemExit("instrumented estimator states changed")
library_sha = (STAGE / "library-sha256.txt").read_text().split()[0]
library_bytes = int((STAGE / "library-bytes.txt").read_text().strip())
if "libov_msckf_lib.so => /home/yuchen7509/flydrones-upstream/open_vins_detection_pruning_probe/ov_msckf/build/libov_msckf_lib.so" not in (STAGE / "runner-ldd.txt").read_text():
    raise SystemExit("runner resolved different library")
data = {
    "schema": "flydrones-openvins-detection-pruning-provenance-v1",
    "upstream": "rpng/open_vins@" + (STAGE / "upstream-head.txt").read_text().strip(),
    "upstream_license": "GPL-3.0",
    "compiler": (STAGE / "compiler.txt").read_text().strip(),
    "opencv": (STAGE / "opencv.txt").read_text().strip(),
    "new_library_sha256": library_sha,
    "new_library_bytes": library_bytes,
    "library_archived": False,
    "prior_pr": "https://github.com/chen7509/FlyDrones/pull/27",
    "prior_evidence_zip_sha256": json.loads(files["prior_evidence_index"].read_text())["archive_sha256"],
    "sha256": hashes,
}
OUT.write_text(json.dumps(data, indent=2) + "\n")
print(json.dumps(data, indent=2))
