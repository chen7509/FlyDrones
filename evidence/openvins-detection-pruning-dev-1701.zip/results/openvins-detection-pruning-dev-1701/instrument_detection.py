"""Insert read-only old-feature removal reasons into fixed OpenVINS TrackKLT."""

from pathlib import Path
import sys


target = Path(sys.argv[1]) / "ov_core/src/track/TrackKLT.cpp"
source = target.read_text()
start = source.index("void TrackKLT::perform_detection_monocular(")
end = source.index("void TrackKLT::perform_detection_stereo(", start)
mono = source[start:end]


def replace_once(before: str, after: str) -> None:
    global mono
    if mono.count(before) != 1:
        raise SystemExit(f"expected one insertion point, found {mono.count(before)}: {before[:100]!r}")
    mono = mono.replace(before, after)


replace_once(
    "                                           std::vector<size_t> &ids0) {\n\n",
    "                                           std::vector<size_t> &ids0) {\n\n"
    "  const size_t input_count = ids0.size();\n"
    "  size_t drop_edge = 0, drop_close_bounds = 0, drop_grid_bounds = 0, drop_close_collision = 0, drop_mask = 0;\n\n",
)
for condition, reason, counter in (
    ("x < edge || x >= img0pyr.at(0).cols - edge || y < edge || y >= img0pyr.at(0).rows - edge", "edge", "drop_edge"),
    ("x_close < 0 || x_close >= size_close.width || y_close < 0 || y_close >= size_close.height", "close_bounds", "drop_close_bounds"),
    ("x_grid < 0 || x_grid >= size_grid.width || y_grid < 0 || y_grid >= size_grid.height", "grid_bounds", "drop_grid_bounds"),
    ("grid_2d_close.at<uint8_t>(y_close, x_close) > 127", "close_collision", "drop_close_collision"),
    ("mask0.at<uint8_t>(y, x) > 127", "mask", "drop_mask"),
):
    before = f"    if ({condition}) {{\n      it0 = pts0.erase(it0);\n"
    after = (
        f"    if ({condition}) {{\n"
        f'      PRINT_INFO("FD_DETECT_DROP id=%zu reason={reason} x=%.3f y=%.3f\\n", *it1, kpt.pt.x, kpt.pt.y);\n'
        f"      {counter}++;\n"
        "      it0 = pts0.erase(it0);\n"
    )
    replace_once(before, after)

replace_once(
    "  // First compute how many more features we need to extract from this image\n",
    "  const size_t retained = pts0.size();\n"
    "\n"
    "  // First compute how many more features we need to extract from this image\n",
)
replace_once(
    "  if (num_featsneeded < std::min(20, (int)(min_feat_percent * num_features)))\n"
    "    return;\n",
    "  if (num_featsneeded < std::min(20, (int)(min_feat_percent * num_features))) {\n"
    '    PRINT_INFO("FD_DETECT_SUMMARY input=%zu edge=%zu close_bounds=%zu grid_bounds=%zu close_collision=%zu mask=%zu retained=%zu candidates=0 added=0 branch=skip\\n",\n'
    "               input_count, drop_edge, drop_close_bounds, drop_grid_bounds, drop_close_collision, drop_mask, retained);\n"
    "    return;\n"
    "  }\n",
)
tail = "  for (size_t i = 0; i < pts0_new.size(); i++) {\n"
tail += "    // update the uv coordinates\n"
if mono.count(tail) != 1 or not mono.endswith("  }\n}\n\n"):
    raise SystemExit("unexpected monocular detector tail")
mono = mono[:-3] + (
    '  PRINT_INFO("FD_DETECT_SUMMARY input=%zu edge=%zu close_bounds=%zu grid_bounds=%zu close_collision=%zu mask=%zu retained=%zu candidates=%zu added=%zu branch=topoff\\n",\n'
    "             input_count, drop_edge, drop_close_bounds, drop_grid_bounds, drop_close_collision, drop_mask, retained,\n"
    "             pts0_ext.size(), pts0_new.size());\n"
    "}\n\n"
)
target.write_text(source[:start] + mono + source[end:])
