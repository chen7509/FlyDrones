import pytest
import torch
from test_learning_roles import config as _base_config
from test_learning_roles import inert_backends as _base_inert
from test_learning_roles import save_session

from flydrones.connectome_training import curriculum_session as sessions

config = _base_config
inert_backends = _base_inert


def session(config,format):
    return sessions.ConnectomeCurriculumSession(config,device='cpu',topology_format=format)


def test_production_uses_actual_compact_kernel_and_distinct_identity(config,tmp_path):
    csr=session(config,'csr_compact_v1')
    coo=session(config,'coo_reference')
    assert csr.model.fixed_topology.layout==torch.sparse_csr
    assert coo.model.fixed_topology.layout==torch.sparse_coo
    assert not hasattr(csr.model,'edge_row')
    assert csr.model_identity != coo.model_identity
    csr.train_batch(config.stages[0],1101)
    save_session(csr,tmp_path/'checkpoint')
    again=session(config,'csr_compact_v1')
    again.restore_checkpoint(tmp_path/'checkpoint')
    assert all(torch.equal(a,b) for a,b in zip(csr.model.parameters(),again.model.parameters()))
    before=[p.detach().clone() for p in coo.model.parameters()]
    with pytest.raises(ValueError,match='metadata mismatch'):
        coo.restore_checkpoint(tmp_path/'checkpoint')
    assert all(torch.equal(a,b) for a,b in zip(before,coo.model.parameters()))


@pytest.mark.parametrize('value',['invalid',None,[]])
def test_selection_rejects_before_data_model_effects(config,monkeypatch,value):
    monkeypatch.setattr(sessions,'_smoke_components',lambda *a:pytest.fail('data/model construction reached'))
    with pytest.raises(ValueError,match='topology format'):
        session(config,value)
