import hashlib,json
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent;prior=root/'results/sequence-corpus-production-dev-1701'
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes().decode('utf-8-sig'))
def save(n,v):
 with (raw/n).open('xb') as f:f.write(json.dumps(v,indent=2).encode())
old=load(prior/'historical-archives-postsoftware.json')['members']+[dict(path='evidence/sequence-corpus-production-dev-1701.zip',bytes=2111470,sha256='85f0b252c7fe02094d629262fc6fa5bba89b9445c6d5e279654751a85fc9b44a')]
assert len(old)==299 and {r['path'] for r in old}=={p.relative_to(root).as_posix() for p in (root/'evidence').glob('*.zip')}
for row in old:
 h=hashlib.sha256();n=0
 with (root/row['path']).open('rb') as f:
  while block:=f.read(1048576):h.update(block);n+=len(block)
 assert n==row['bytes'] and h.hexdigest()==row['sha256']
save('historical-archives-postsoftware.json',dict(members=old,count=len(old),bytes=sum(r['bytes'] for r in old),scope='POSTsoftware preservation,not native prepins'))
before=load(raw/'product-before.json');changed=[r['path'] for r in before if sha((root/r['path']).read_bytes())!=r['sha256']]
assert set(changed)=={'src/flydrones/connectome_training/model.py','src/flydrones/connectome_training/curriculum_session.py','src/flydrones/connectome_training/inference_artifact.py','src/flydrones/connectome_training/inference.py','tools/connectome_training/run_curriculum.py'}
save('product-preservation-postsoftware.json',dict(count=len(before),changed=changed,new_product=['tests/connectome_training/test_csr_runtime.py'],all_other_old_product_byte_same=True,all_consumed_version_sources_byte_same=True))
p=load(prior/'refused-attempt-preservation.json');parent=root/'results/target-bearing-runtime-freeze-v4-dev-1701'
for row in p['private_excluded']:
 b=(root/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
assert set(q.name for q in parent.iterdir())=={'run-static-preparation-v4.py','firstfacts.json','completion.json',*[Path(r['path']).name for r in p['private_excluded']]}
assert load(parent/'completion.json')['state']=='REFUSED_UNCONSUMED' and not load(parent/'completion.json')['consumed']
sources=load(root/'results/static-v4-attempt-dev-1701/preflight.json')['sources'];assert len(sources)==382 and sources==load(root/'results/static-v4-attempt-dev-1701/cli-completion.json')['source_after']
for row in sources:assert sha((root/'results/static-v4-attempt-dev-1701/source-before'/row['path']).read_bytes())==row['sha256']
evolved=[r['path'] for r in sources if sha((root/r['path']).read_bytes())!=r['sha256']];assert set(evolved)==set(p['current_source_evolved'])|{'src/flydrones/connectome_training/model.py'}
assert sha((root/'evidence/static-v4-executor-completion-release.frame').read_bytes())==p['release_sha256']
for row in p['histories']:assert sha((root/row['path']).read_bytes())==row['sha256']
p.update(current_phase_changed_outside_original382=sorted(set(changed)-{r['path'] for r in sources}),current_phase_new_source=False,current_source_evolved=evolved,scope='CSR production wiring;model joins six evolved original382;oldrelease remainsstale;no resource/native action')
save('refused-attempt-preservation.json',p)
pr=load(prior/'publication-readback.stdout');assert pr['headRefOid']=='49c374c60577350a10a5fc177f05ddf1487c69fc' and pr['isDraft']
with (raw/'previous-pr-body.md').open('xb') as f:f.write(pr['body'].encode())
save('previous-pr-body.json',dict(head=pr['headRefOid'],bytes=len(pr['body'].encode()),characters=len(pr['body']),sha256=sha(pr['body'].encode()),full_prior_history=load(root/'evidence/sequence-corpus-production-publication.json')['prior_PR_full_history']))
print(json.dumps(dict(old_archives=len(old),archive_bytes=sum(r['bytes'] for r in old),old_products=len(before),changed=changed)))
