import hashlib,json
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(name,text):
 with (raw/name).open('x',encoding='utf-8',newline='') as f:f.write(text)
review=json.loads((raw/'independent-csr-review.json').read_bytes())
assert review['counts']==dict(critical=0,important=0,minor=0,total=0)
assert all(sha((root/r['path']).read_bytes())==r['sha256'] for r in review['source_pins'])
save('executor-fix-pass.md','''# Single bounded executor verification pass

The original one independent whole-current-source review is C0/I0/M0. No actionable fix was requested, no code delta was made after review, and no artificial RED or second whole-source review was performed. All19 reviewed source hashes still match before plan checkbox publication changes.

One bounded final verification adds the necessary existing inference.py neighbor to the final19 CSR tests:48passed17.29s after all source formatting, one existing PyTorch CSR-beta warning. The earlier necessary77passed6.84s had two warnings (CSR beta and weights_only sparse invariant checking). Final six-file Ruff passed and dedicated git diff --check returned0/empty. Sources remain unchanged. Default CSR tests use the actual inert fixture; final neighbors use the explicit recorded plugin. These fixtures do not measure resource peaks or grant dispatch. TinyCPU actual sparse neural forward/backward/Adam/SGD executes; no fullMaleCNS, GPU, target SDK/Linux, resource query or physical attempt executes.

Initial4 failures were missing topology_format API TypeErrors, not behavior/native RED. Three later coherently rehashed contradictory COO checkpoint backend labels genuinely failed DIDNOTRAISE and drove the explicit pre-copy backend check. Original4/18pass, final48pass,11lint errors/format2/import2fix, exact argv/env/source snapshots and raw streams remain. Earlier native-host access violation and timeout evidence gaps are untouched.
''')
plan=root/'docs/superpowers/plans/2026-10-16-csr-runtime-production.md'
b=plan.read_bytes();assert b.count(b'- [ ]')==3
new=b.replace(b'- [ ]',b'- [x]',2);plan.write_bytes(new)
save('review-seal-plan-join.json',json.dumps(dict(review_plan_sha256=sha(b),sealed_plan_sha256=sha(new),changed_byte_offsets=[i for i,(x,y) in enumerate(zip(b,new)) if x!=y],scope='Only first two softwarecriteria checkbox spaces become x;no reviewed product source changes'),indent=2))
report='''# Explicit CSR topology in training and offline inference

The existing compact CSR core now has a real production route through CurriculumTrainingSession, checkpoint restore, load_inference_core, decision evidence and run_curriculum --topology-format. The fixed choices are coo_reference and csr_compact_v1. COO remains the default with its existing identity and constructor route. CSR actually builds the existing compact operator and adds a distinct model-identity suffix plus checkpoint/provenance backend metadata. This connects a previously isolated implementation; no new sparse kernel, normalization, neuron dynamics, loss, topology, learned degrees or default migration was introduced.

Invalid choices fail before session data/model work or offline reads. Session train/evaluate/save/restore checks both actual model backend label and sparse tensor layout. Restore rejects contradictory explicit metadata before parameter copy. Offline inference independently rebuilds selected topology from existing source/parameter artifacts, then applies existing coefficient/role/initialization checks. Legacy artifacts lacking a topology field mean COO. Explicit CSR legacy-style offline artifacts can still have unbound initialization: provenance learning_initialization is None and validation_baseline_verified remains false. Metadata does not authenticate hostile mutation or prove historical training. Other inference CLI surfaces were not expanded.

The four learned parameter groups and earlier role profiles/initialized coefficients/validation denominator checks remain. No full scientific experiment identity, optimizer/backend reproducibility proof, complete fair upstream baseline or source authentication is claimed. Training arrays/model remain eager as already documented; this selection is not a constant-memory, measured full-model peak, minimumRAM, speed, latency or GPU certificate.

## Actual software evidence

Raw results/csr-runtime-production-dev-1701 preserves exact argv, owned environment, recorder hash, source-before/after copies, exclusive fixtures and stdout/stderr. All21 initially declared paths exist, including the new test and recorder/plugin; initial missing API was not an absent source module. Whole827-product snapshot separately covers unchanged neighbors, without retroactively enlarging old declared pins.

| Record | Actual outcome |
| --- | --- |
| csr-red | 4failed .39s, missing session topology_format API TypeError; not behavioral/native RED |
| csr-green | 4passed4.07s, existing CSR-beta warning |
| csr-label-red | 3 genuine DIDNOTRAISE failures3.68s/4deselected: coherently rehashed COO checkpoints declared CSR/None/invalid |
| csr-coverage | 18passed5.21s, one CSR-beta warning; extra coverage directly passes, no fakeRED |
| lint/format/import | Initial11errors retained;2filesformatted/4unchanged;2importerrorsfixed |
| necessary neighbors | 77passed6.84s after formatting; CSR-beta and weights_only sparse-invariant warnings |
| final bounded pass | 48passed17.29s:19new CSR tests plus29 existing inference neighbors, one CSR-beta warning; finalRuff0/dedicateddiff0 |

Tests execute actual tiny16-neuron signed/irregular COO and CSR CPU operators, compare float64 outputs and raw preclip gradients, and perform two SGD updates at dt=.001 to avoid saturated tau gradients. Actual tiny curriculum Adam/checkpoint roundtrips and source-based offline CSR reconstruction also execute. CLI parse and main routing use an explicit inert session boundary, not a real CLI/fulltraining dispatch. Default tests apply the actual inert process/resource/CUDA fixture and neighbors use the explicit results plugin. Inert peak0/CUDAfalse are fixture protocol, not measured resources or a gate. HostNumPy/SciPy/Torch imports and host CPU sparse/native operators really run; no target SDK/Linux/native observer/fullMaleCNS/GPU/physical/calibration executes. Guard is not a collection/FFI authentication sandbox.

Original single independent whole-source review C0/I0/M0 and all19source pins are retained. No fix was needed; the single bounded executor pass only verifies final source and the relevant inference neighbor. No second whole-source review or invented fix/RED. Delivery audits are integrity/honesty checks, not code/native approval. No new crash/timeout; old decode-phase3221225477/6dots/exactcauseUNKNOWN and120srecorder missingpartial/completion gap remain unchanged and unfilled.

## Preservation and scope

299oldZIPs/887307756B fullystreamedunchanged POSTsoftware, not native prepins.827oldproducts change exactly five existing files: model,curriculum_session,inference_artifact,inference,run_curriculum;822same, newtest separate. Existing compact math/codec/windowtrainer/corpus/roleinitialization modules and all consumedversion-specific bytes remain unchanged. Original382 CLIbefore/after/copies remain exact; current six evolved original members are session,dataset,inference,inference_artifact,trainer and now model. CLI is outsideold382; training_roles/sequence_corpus are post382 namespaces. Missing historical pins are never invented.

All three complete histories remain exact and included:80946B SHA80dfb89ed0e51e639bd6b24b115cbcd3c444b967614e2e8334d55962c262b824;89359B SHAc88840b6f58dea4e7e4931683c4993b4fc3b8eb55887807994b6381ef6c2b989;81675B SHAdf122e1bc9d3b051b4b7606d2263d991b822a587c49758184b13449e4e5a97eb. The last embeds the full63552character prompt and its two older references; all original goals/failures/budgets remain mandatory. No new externalization or truncation is needed. Full64305character PRhistory is unchanged; immediate10681character PRbody is retained as verbatim suffix. Prior automation finalLF trimming correction remains additive history; this phase will prepend to the actual10445character saved prompt, preserving its exact suffix.

Saved475private rows including175empty/202nonemptyargvhashes are checked for both identity triples; private3 originals remain excluded without resource refresh. Originalv4 sixfile REFUSED_UNCONSUMED stays: Win1620271104/WSL6851129344B memorypass butcompetitor1/Docker0empty, ownedCLIexit0wait2.437s, refusal notfreeze/nativefailure. No preidentity-attempt/request/recipe/claim/sdk-start/study/SDKcommand/scope; physicalabsent/unconsumed. Originalrequest232184B/SHA546c... and release44826B/SHAf7ce... stay byte-exact/CURRENTSTALE. No rerun/rewrite/delete/rename/blindfolderretry/resourcepoll/competitorlookup/termination/manualmetadata/genericworker bypass. Future static requires new independent complete current source/receipt/routing design plus original fresh fullprepins/review/once, preserving refusal and all evolution.

All8source/clock/measuredcalibration/accuracy/teacher/fusion/training/flight qualifications and runtime_graph_frozen/physical_dispatch_ready remain false; goalblockedreadonly/automationACTIVE. V3CONSUMED_FAILED_UNADMITTED_HARNESS_ESCAPE and all v1/v2/JSONobserver/EGO/OpenVINS/Kalibr CONSUMEDUNKNOWN/fixtureMOCK/251pose185init/5agent.873RTF<.95 remain. Staticdual1GiB/no competition/Dockerempty/512MiBswap0CPU100tasks64/210scope180inner+10kill240launcher, metadata30+5/45outer/postidentity30/control15 and original input/framing/stream caps remain. Actualpreidentitymarker/observercommand conservativelyconsume. Physical/fullMaleCNS/PX4dual4GiB/4Gswap0CPU100tasks256/330scope315inner360outer300worker/25s1ms250Hz10Hz160x120near.2far19.1/anchor1mm1mrad and original precision/sensors/velocity/safetyRTF remain. Truthabort/auditonly, never VIO/teacher/training;pidfddeniedunsupportedfailclosed nofallback/sysctl/privilege. PNG/Kalibr/PX4/source/calibration/fulllearning/fairupstream/HITLflight goals remain pending; no tiny result/SHA/metadata replaces qualification.

Canonical archive seals firsttwo softwarecriteria done/publicationpending. Subsequent receipt/deliveryaudit/stage/Gitnormalizedidentities/publicationbyte/PR/automation/NEXT_PHASE are separate postseal evidence. Raw/source/ZIP are never backfilled. onlypersonal/draftPR65exactCRLFonly; software/resource/staticpending quiet.
'''
with (root/'docs/CSR_RUNTIME_PRODUCTION_REPORT.md').open('x',encoding='utf-8',newline='') as f:f.write(report)
print('preseal report/plan/executor pass complete;reviewed product hashes unchanged')
