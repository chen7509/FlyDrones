from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent
s=(root/'results/sequence-corpus-production-dev-1701/seal.py').read_text()
s=s.replace("explicit=['src/flydrones/connectome_training/sequence_corpus.py'","explicit=['tests/connectome_training/test_csr_runtime.py','src/flydrones/connectome_training/sequence_corpus.py'")
s=s.replace('docs/SEQUENCE_CORPUS_LIFECYCLE_PRODUCTION_REPORT.md','docs/CSR_RUNTIME_PRODUCTION_REPORT.md').replace('2026-10-15-sequence-corpus-lifecycle','2026-10-16-csr-runtime-production')
s=s.replace('evidence/learning-baseline-production-publication.json','evidence/sequence-corpus-production-publication.json')
s=s.replace('evidence/sequence-corpus-production-dev-1701.zip','evidence/csr-runtime-production-dev-1701.zip').replace('sequence-corpus-production-map-v1','csr-runtime-production-map-v1')
s=s.replace('TinyCPU sequencecorpusproduction/software only','TinyCPU explicit CSR production wiring/software only')
with (raw/'seal.py').open('x',encoding='utf-8') as f:f.write(s)
print('prepared canonical seal helper')
