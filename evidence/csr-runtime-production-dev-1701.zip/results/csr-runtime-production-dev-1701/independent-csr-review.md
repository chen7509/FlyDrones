# Independent CSR runtime production source review

Original review: one whole-current-source review against base `49c374c60577350a10a5fc177f05ddf1487c69fc` (HEAD remains that base; changes are in the working tree). Product source was read only. The reviewer ran no tests, project imports, network, native studies, CUDA checks, resource sampling, or production commands. Only these review artifacts were written.

## Strengths

- `model.py:71-81` centralizes strict selection, the legacy empty suffix, and actual layout/label validation. `curriculum_session.py:286-306` rejects invalid selection before data/model construction, retains the default constructor path, and routes selected CSR into the existing compact implementation.
- `curriculum_session.py:316-324` includes the CSR identity suffix before unchanged learning/init identity joins. Backend validation runs before training, evaluation, save, and restore through `_validate_baseline` (`:349-350`).
- `curriculum_session.py:431-459` checks backend/identity/roles/init/baseline and model/Adam payloads before coefficients are copied. Explicit CSR metadata is required; absent metadata remains legacy COO, and contradictory explicit COO labels are rejected.
- `inference_artifact.py:63-136` validates selection, checks checkpoint backend metadata and identity, reconstructs fixed topology from source, and checks its actual layout. Only learned coefficient arrays are accepted and copied (`:137-156`); checkpoint topology cannot replace source buffers.
- `run_curriculum.py:35,110` exposes and routes the explicit backend. `inference.py:160` carries the loader's backend provenance into decision evidence. Existing qualification flags remain false.
- `test_csr_runtime.py` uses actual tiny sparse COO/CSR operations for outputs/raw gradients/SGD updates, actual session train/restore, backend mismatch and drift rejection, and inert CLI parse/main routing. Shared inert fixtures prevent test-body child/native resource effects.

## Issues

Critical: 0. Important: 0. Minor: 0. Total: 0.

No actionable defect found in the requested production backend integration. No bounded executor fix is required by this review.

## Evidence examined

These are executor-recorded results inspected by the reviewer, not checks rerun by the reviewer:

- `csr-red`: 4 missing-API failures; `csr-green`: 4 passed with CSR beta warning.
- `csr-label-red`: 3 actual DID NOT RAISE failures (4 deselected) for coherently rehashed contradictory COO metadata; current restore explicitly rejects these labels.
- `csr-coverage`: 18 passed with CSR beta warning, before final inert CLI-main test.
- `csr-neighbors`: 77 passed, 2 warnings; includes the final CLI-main test. The CSR beta warning and existing weights-only sparse-invariant scan warning remain visible.
- Initial Ruff failures and import cleanup records were inspected. This review does not substitute for final lint/diff/seal checks.

## Declined to judge

- Full MaleCNS execution, GPU/target SDK/Linux runtime closure, memory and latency qualification: expressly excluded; no such execution undertaken.
- Source authentication, hostile coordinated rewriting of hashes/labels/private runtime objects, and historical training proof: outside controlled ordinary backend selection and drift checks.
- Existing compact normalization, neuron dynamics, losses, new learned degrees, flight/source/physics/static admission and consumed runs: unchanged and outside this integration.
- Requiring initialization or validation-baseline proof for all offline legacy-style artifacts: existing loader compatibility deliberately preserves unbound initialization while provenance reports `learning_initialization=null` and `validation_baseline_verified=false`.
- Exposing backend choice in `profile_inference` CLI or other callers: requested CLI surface is `run_curriculum`; offline selection is available through `load_inference_core` API.

## Assessment

Ready to merge: **Yes, for the scoped software integration.** Production selection, default compatibility, backend identity checks, and restore-before-copy ordering are coherent. Evidence supports tiny CPU software integration only, with no full-model runtime qualification implied.

## Original source pins

SHA256, byte counts and line counts were recorded after reading source. The companion JSON preserves the original findings/counts and these pins. Source was held fixed during review.

| File | Bytes | Lines | SHA256 |
| --- | ---: | ---: | --- |
| src/flydrones/connectome_training/model.py | 10669 | 235 | 6c942e48b0ac9d17e22378fff9e63b8539f9cc020ee6463b79ee182afcdad252 |
| src/flydrones/connectome_training/curriculum_session.py | 19682 | 461 | b14933a23c8c7b81ec4ea773b4f606659a6899b96101b570f9d8ff8962cb32fa |
| src/flydrones/connectome_training/inference_artifact.py | 9588 | 198 | 40facf493dee933f84a87a38f1a72b93a188c3eed4887be602a11b0b42ffa569 |
| src/flydrones/connectome_training/inference.py | 8313 | 191 | 0eb1ae9d93361877171760f1a2a8fd76060f215017c10e434f87633450540332 |
| tools/connectome_training/run_curriculum.py | 5418 | 142 | 116aceedea3a446fc1db5efc810df17b2ad807b487f5460b6c22d6d88b65babf |
| tests/connectome_training/test_csr_runtime.py | 7846 | 170 | 80c62e3081a12a61433ed7ee48ad7c9136e7ebdbea21bbf2d675bf31eb3dee66 |
| docs/superpowers/specs/2026-10-16-csr-runtime-production-design.md | 2060 | 9 | bfb8d51bbe5ab2a036dbd3f9c770cea451ad67f556af54826334aceaed8501f8 |
| docs/superpowers/plans/2026-10-16-csr-runtime-production.md | 855 | 7 | 440c921a638cb343155b79fc9748911a94838a5469a9e019fa2e23c681af883e |
| src/flydrones/connectome_training/checkpoint.py | 4775 | 142 | 52ae0c2a4f385c576b70b0c4605c53df01064620e66a5f62306e256b21f98b1f |
| src/flydrones/connectome_training/training_roles.py | 7867 | 180 | 821cd19de06ed572392fddf98100509457969eeb499a3ef5b1dea86daa4bd0bb |
| src/flydrones/connectome_training/trainer.py | 6106 | 148 | ceca199cf37b7340e018c5c8a43cc327c4fa33d349c7977d1fe0b58642de88b6 |
| src/flydrones/connectome_training/curriculum.py | 10762 | 269 | 28e5cc446dc82923e9c2050a3c5b867fdab2d939253c6f7d378e925e1258368d |
| tests/connectome_training/test_learning_roles.py | 13177 | 283 | 459545136510f34112f7ccad56d59ab7f9b426d2f05f59dac11844f4134baaef |
| tests/connectome_training/test_model.py | 7380 | 196 | f7479bf3585b43cb38928679d1dd02ec42d669021b4268c2ef2c27f5258a8662 |
| tests/connectome_training/test_inference_artifact.py | 9563 | 198 | 64ea861c5718ba23a481e34267053590001bb2bb89d21b92bbc0b4d57e306e2e |
| tests/connectome_training/conftest.py | 1260 | 36 | 6a163e598e4011dd4efac9b8c896e5bafda4244112deaf7467125be479844ae1 |
| results/csr-runtime-production-dev-1701/inert_test_plugin.py | 484 | 12 | 9047f51b84c1e7c3dca9f0523950de89e9b1e1179cde8d3afbdcbfbf9f721b38 |
| results/csr-runtime-production-dev-1701/verify.py | 2939 | 24 | 8c4b41dd69f897507a574028071d57172af86a9817c1a6df66c3178ab1de3f0d |
| tools/benchmark/software_process_boundary.py | 1737 | 63 | 1aced69a1cd810728c0bf557cc272a5bd43a94ababc31bb6ba33de791fd139a1 |
