import hashlib,json,subprocess
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent;old=root/'results/sequence-corpus-production-dev-1701'
sha=lambda b:hashlib.sha256(b).hexdigest()
def pin(p):
 b=p.read_bytes();return dict(path=p.relative_to(root).as_posix(),bytes=len(b),sha256=sha(b))
paths=['docs/SEQUENCE_CORPUS_LIFECYCLE_PRODUCTION_REPORT.md','evidence/sequence-corpus-production-publication.json','results/sequence-corpus-production-dev-1701/NEXT_PHASE.md','results/sequence-corpus-production-dev-1701/independent-corpus-review.md','results/sequence-corpus-production-dev-1701/executor-fix-pass.md','docs/superpowers/specs/2026-10-15-sequence-corpus-lifecycle-design.md','docs/superpowers/plans/2026-10-15-sequence-corpus-lifecycle.md','docs/superpowers/specs/2026-09-22-connectome-constrained-realtime-training-design.md','docs/TARGET_BEARING_STATIC_V3_HARNESS_FAILURE_REPORT.md','evidence/flydrones-history-through-initialized-baseline-dev-1701.json','evidence/flydrones-history-through-loader-path-research-dev-1701.json','evidence/flydrones-history-through-admitted-executor-dev-1701.json']
for p in paths:(root/p).read_bytes().decode('utf-8-sig')
names=subprocess.check_output(['git','ls-files','-z','src','tools','tests','configs']).decode().split('\0');rows=[pin(root/n) for n in names if n and (root/n).is_file()]
for name,value in [('product-before.json',rows),('context-readback.json',dict(read=[pin(root/p) for p in paths],scope='Full UTF8 source/history reads;no resources/native'))]:
 with (raw/name).open('xb') as f:f.write(json.dumps(value,indent=2).encode())
s=(old/'verify.py').read_text().replace('sequence-corpus-production-dev-1701','csr-runtime-production-dev-1701').replace("'src/flydrones/connectome_training/sequence_corpus.py'","'src/flydrones/connectome_training/training_roles.py'").replace('tests/connectome_training/test_sequence_corpus.py','tests/connectome_training/test_csr_runtime.py')
with (raw/'verify.py').open('x',encoding='utf-8') as f:f.write(s)
with (raw/'inert_test_plugin.py').open('xb') as f:f.write((old/'inert_test_plugin.py').read_bytes())
print(json.dumps(dict(oldproducts=len(rows),contextpaths=len(paths))))
