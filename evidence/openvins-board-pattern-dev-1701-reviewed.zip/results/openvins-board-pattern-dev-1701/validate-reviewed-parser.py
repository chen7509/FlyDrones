from pathlib import Path
import json
import sys
base=Path(__file__).resolve().parent
sys.path.insert(0,str(base.parents[1]))
from tools.benchmark.audit_openvins_init_feature_trace import parse_static_attempt_outcomes
actual=parse_static_attempt_outcomes((base/'replay-v1/stdout.txt').read_text())
expected=json.loads((base/'completion-audit-v2/summary.json').read_text())['static_attempts']
assert actual==expected and len(actual)==8 and sum(r['success'] for r in actual)==1
with (base/'reviewed-parser-validation.json').open('x') as stream:
    json.dump({'unchanged_original_evidence':True,'static_attempts':actual},stream,indent=2)
