"""Strictly parse this development replay without claiming uninstrumented parity."""

import csv
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.benchmark.audit_openvins_init_feature_trace import (  # noqa: E402
    parse_init_feature_trace,
    summarize_feature_phases,
)

BASE = Path(__file__).parent
OUT = BASE / 'feature-audit-v1'
if OUT.exists():
    raise SystemExit('refusing existing feature audit')
states_path = BASE / 'replay-v1' / 'states.csv'
log_path = BASE / 'replay-v1' / 'stdout.txt'
episode_path = BASE / 'episode-v2' / 'result.json'
with states_path.open(newline='', encoding='utf-8') as stream:
    states = list(csv.DictReader(stream))
episode = json.loads(episode_path.read_text(encoding='utf-8'))
prearm = episode['development_prearm_stationary']
if prearm['status'] != 'completed':
    raise ValueError('incomplete prearm window')
rows = parse_init_feature_trace(log_path.read_text(encoding='utf-8'), states)
phases = summarize_feature_phases(
    rows, prearm['start_sim_ns'] * 1e-9, prearm['end_sim_ns'] * 1e-9,
)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
summary = {
    'schema': 'flydrones-openvins-prearm-board-feature-dev-v1',
    'scope': 'instrumented single offline replay; no same-input uninstrumented parity run',
    'states_sha256': sha(states_path),
    'stdout_sha256': sha(log_path),
    'episode_result_sha256': sha(episode_path),
    'first_initialized_s': rows[-1]['image_s'],
    'last_attempt_s': next(r['image_s'] for r in reversed(rows) if r['attempted']),
    'total_preinitialization_images': len(rows),
    'total_attempts': sum(r['attempted'] for r in rows),
    'phases': phases,
}
OUT.mkdir()
with (OUT / 'frame-trace.csv').open('x', newline='', encoding='utf-8') as stream:
    writer = csv.DictWriter(stream, fieldnames=rows[0])
    writer.writeheader()
    writer.writerows(rows)
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, indent=2))
