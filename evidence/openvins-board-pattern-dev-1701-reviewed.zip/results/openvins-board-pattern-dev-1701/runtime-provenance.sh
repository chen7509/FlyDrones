#!/bin/bash
set -euo pipefail
cd /mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility
stage=results/openvins-board-pattern-dev-1701
test ! -e "$stage/runtime-provenance.txt"
{
 date --iso-8601=seconds
 uname -a
 git -C /home/yuchen7509/PX4-Autopilot rev-parse HEAD
 sha256sum /home/yuchen7509/PX4-Autopilot/build/px4_sitl_default/bin/px4
 git -C /home/yuchen7509/flydrones-upstream/open_vins_vio_init_probe rev-parse HEAD
 sha256sum /home/yuchen7509/flydrones-upstream/open_vins_vio_init_probe/ov_msckf/build/libov_msckf_lib.so
 python3 --version
 pkg-config --modversion opencv4
 gz sim --versions
} > "$stage/runtime-provenance.txt" 2>&1
