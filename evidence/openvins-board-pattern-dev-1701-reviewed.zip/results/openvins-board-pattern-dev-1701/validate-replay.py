from pathlib import Path
from PIL import Image, ImageChops
import base64
import io
import json
import re
import subprocess

base=Path(__file__).resolve().parent
page=(base/'camera-replay.html').read_text(encoding='utf-8')
script=page.split('<script>',1)[1].split('</script>',1)[0]
syntax=subprocess.run(['node','--check'],input=script,text=True,encoding='utf-8',capture_output=True,check=True)
frames=json.loads(re.search(r'const frames=(\[.*?\]);const slider=',script).group(1))
raw=json.loads((base/'episode-v2/rgb-capture-manifest.json').read_text())['frames']
assert len(frames)==len(raw)==455
for frame,source in zip(frames,raw):
    assert frame['ns']==source['frame_ns']
    shown=Image.open(io.BytesIO(base64.b64decode(frame['png']))).convert('RGB')
    original=Image.open(base/'episode-v2'/source['path']).convert('RGB')
    assert ImageChops.difference(shown,original).getbbox() is None
with (base/'replay-validation.json').open('x') as stream:
    json.dump({'node_syntax_exit':syntax.returncode,'raw_pixels_identical_frames':len(frames),
               'scope':'static syntax and pixel fidelity checks; browser interaction not automated'},stream,indent=2)
