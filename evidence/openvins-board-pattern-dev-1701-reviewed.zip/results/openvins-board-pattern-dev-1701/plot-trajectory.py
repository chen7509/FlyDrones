import csv
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

base = Path(__file__).resolve().parent
result = json.loads((base/'episode-v2/result.json').read_text())
audit = json.loads((base/'trajectory-v1.json').read_text())
truth = np.array([r['position'] for r in result['path']])
with (base/'replay-v1/states.csv').open() as stream:
    rows = [r for r in csv.DictReader(stream) if r['initialized']=='1'
            and audit['truth_overlap_first_s'] <= float(r['state_timestamp_s']) <= audit['truth_overlap_last_s']]
vio = np.array([[float(r[k]) for k in ('px','py','pz')] for r in rows])
vio = vio @ np.array(audit['alignment_rotation_row_major']) + np.array(audit['alignment_translation_m'])
fig, ax = plt.subplots(figsize=(8,4.5), constrained_layout=True)
ax.plot(truth[:,0],truth[:,1],label='Gazebo truth (scoring only)',color='#145ea8')
ax.plot(vio[:,0],vio[:,1],label='Offline VIO (rigid aligned, no scale)',color='#df8425',linestyle='--')
ax.scatter(*truth[-1,:2],color='red',marker='x',s=100,label='Collision with tree_0')
ax.scatter(*truth[0,:2],color='green',s=45,label='Scored flight start')
ax.set(xlabel='World x (m)',ylabel='World y (m)',title='Artificial development scene: flight failed (collision)')
ax.text(.02,.96,'124 matched frames; ATE RMSE 0.162 m\nOffline VIO only; not an EKF2 closed-loop result',transform=ax.transAxes,va='top',fontsize=9)
ax.axis('equal'); ax.grid(alpha=.25); ax.legend(loc='lower left',fontsize=8)
target=base/'trajectory.png'
assert not target.exists()
fig.savefig(target,dpi=150)
