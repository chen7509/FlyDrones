#!/bin/bash
set -euo pipefail
cd /mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/results/openvins-board-pattern-dev-1701
test ! -e fast-screen
g++ fast-screen.cpp -o fast-screen $(pkg-config --cflags --libs opencv4)
for label in baseline variant; do
  test ! -e "probe-$label-v1/fast20.csv"
  ./fast-screen "probe-$label-v1/frame.ppm" > "probe-$label-v1/fast20.csv" 2> "probe-$label-v1/fast-version.txt"
done
