#!/bin/bash
set -euo pipefail
base=/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/results/openvins-board-pattern-dev-1701
upstream=/home/yuchen7509/flydrones-upstream/open_vins_vio_init_probe
test ! -e "$base/upstream-source-hashes.txt"
for name in VioManager.h VioManager.cpp VioManagerHelper.cpp; do
  cmp "$upstream/ov_msckf/src/core/$name" "$base/upstream-source/$name"
done
sha256sum "$base/upstream-source/"* > "$base/upstream-source-hashes.txt"
git -C "$upstream" diff > "$base/upstream-local.patch"
printf '%s\n' 'No root LICENSE file present in local upstream checkout. GPL-3.0-or-later notices retained in copied source headers. Earlier save script stopped after copying these sources; no source was altered.' > "$base/upstream-license-note.txt"
