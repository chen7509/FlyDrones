#!/bin/bash
set -euo pipefail
cd /mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility
stage=results/openvins-board-pattern-dev-1701
for label in baseline variant; do
  target="$stage/probe-$label-v1"
  test ! -e "$target/run.log"
  python3 tools/benchmark/probe_camera_frames.py --world "$target/world.sdf" --output "$target/frame.json" --image-output "$target/frame.ppm" > "$target/run.log" 2>&1
done
