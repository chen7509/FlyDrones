import csv
import hashlib
import json
import sys
from pathlib import Path
import numpy as np
from pyulog import ULog

base = Path(__file__).resolve().parent
root = base.parents[1]
sys.path[:0] = [str(root), str(root / 'src')]
from tools.benchmark.audit_openvins_init_feature_trace import parse_init_feature_trace, parse_static_attempt_outcomes
from tools.benchmark.audit_openvins_imu_init import score_ekf_init_velocity, compare_imu_rows
from tools.benchmark.audit_prearm_static import assess_prearm_windows
from flydrones.benchmark.rgb_capture import verify_rgb_manifest
from flydrones.benchmark.camera_info_capture import verify_camera_info_capture
from flydrones.benchmark.ulog_capture import verify_episode_ulog_evidence

out = base / 'completion-audit-v2'
assert not out.exists()
episode = base / 'episode-v2'
result = json.loads((episode / 'result.json').read_text())
verify_episode_ulog_evidence(episode, result)
rgb = verify_rgb_manifest(episode)
verify_camera_info_capture(episode)
log = (base / 'replay-v1/stdout.txt').read_text()
with (base / 'replay-v1/states.csv').open() as stream:
    states = list(csv.DictReader(stream))
trace = parse_init_feature_trace(log, states)
attempts = parse_static_attempt_outcomes(log)
internal_s = next(r['image_s'] for r in attempts if r['success'])
assert trace[-1]['image_s'] >= internal_s
ulog_path = episode / result['px4_ulogs'][0]['path']
ulog = ULog(str(ulog_path))
local = ulog.get_dataset('vehicle_local_position').data
imu = ulog.get_dataset('sensor_combined').data
with (base / 'input-v1/imu.csv').open() as stream:
    imu_rows = list(csv.DictReader(stream))
imu_match = compare_imu_rows(imu, imu_rows)
first_public_s = trace[-1]['image_s']
prearm_summary, windows = assess_prearm_windows(result, [r['frame_ns'] for r in rgb['frames']],
                                               [int(t) for t in imu['timestamp']], local, first_public_s)
try:
    internal_rows, velocity = score_ekf_init_velocity(local, internal_s - 2, internal_s)
    windows['internal'] = internal_rows
except ValueError as exc:
    velocity = {'status': 'unverified', 'reason': str(exc)}
image_window = [r for r in rgb['frames'] if round((internal_s-2)*1e9) <= r['frame_ns'] <= round(internal_s*1e9)]
prearm = result['development_prearm_stationary']
prearm_images = [r for r in rgb['frames'] if prearm['start_sim_ns'] <= r['frame_ns'] <= prearm['end_sim_ns']]
def unique_images(rows):
    return len({hashlib.sha256((episode / r['path']).read_bytes()).hexdigest() for r in rows})
times = np.array([r['decision_wall_s'] for r in result['decisions']])
summary = {'scope': 'one artificial development fixture; offline VIO, no EKF2 external vision fusion',
           'static_attempts': attempts, 'successful_internal_attempt_image_s': internal_s,
           'first_public_initialized_row_s': first_public_s,
           'internal_before_prearm_end': internal_s <= prearm['end_sim_ns']*1e-9,
           'public_before_prearm_end': first_public_s <= prearm['end_sim_ns']*1e-9,
           'internal_window_ekf2_velocity': velocity, 'imu_export_exact_match': imu_match,
           'internal_image_window': {'count': len(image_window), 'unique_sha256': unique_images(image_window)},
           'prearm_images': {'count': len(prearm_images), 'unique_sha256': unique_images(prearm_images)},
           'public_flag_window_and_prearm_audit': prearm_summary,
           'controller': {'status': result['status'], 'decision_count': len(times),
                          'decision_median_s': float(np.median(times)), 'decision_p95_s': float(np.quantile(times,.95)),
                          'wall_s': result['wall_s'], 'final_sim_s': result['path'][-1]['sim_ns']*1e-9,
                          'rough_rtf_including_pauses': result['path'][-1]['sim_ns']*1e-9/result['wall_s']},
           'source_sha256': {str(p.relative_to(base)): hashlib.sha256(p.read_bytes()).hexdigest() for p in
                             [episode/'result.json', ulog_path, base/'replay-v1/states.csv', base/'replay-v1/stdout.txt']}}
out.mkdir()
for name, rows in windows.items():
    with (out / (name+'-velocity.csv')).open('x') as stream:
        writer = csv.DictWriter(stream, fieldnames=rows[0])
        writer.writeheader(); writer.writerows(rows)
with (out / 'summary.json').open('x') as stream:
    json.dump(summary, stream, indent=2)
print(json.dumps(summary, indent=2))
