import hashlib
import json
import zipfile
from pathlib import Path

stage = Path(__file__).resolve().parent
root = stage.parents[1]
archive = root / 'evidence/openvins-board-pattern-dev-1701-reviewed.zip'
index_path = archive.with_suffix('.sha256.json')
assert not archive.exists() and not index_path.exists()
omissions = ['processes-before-capture-v2.txt', 'processes-after-capture-v2.txt']
extras = ['docs/OPENVINS_BOARD_PATTERN_REPORT.md',
          'docs/superpowers/specs/2026-10-05-openvins-board-pattern-design.md',
          'docs/superpowers/plans/2026-10-05-openvins-board-pattern.md',
          'tools/benchmark/make_prearm_pattern_fixture.py', 'tools/benchmark/run_episode.py',
          'tools/benchmark/audit_openvins_init_feature_trace.py',
          'tools/benchmark/openvins_init_feature_trace.patch',
          'tests/benchmark/test_prearm_pattern_fixture.py', 'tests/benchmark/test_static_init_outcomes.py',
          'evidence/openvins-board-pattern-dev-1701.sha256.json']
files = sorted(p for p in stage.rglob('*') if p.is_file() and p.name not in omissions and '__pycache__' not in p.parts)
files += [root / p for p in extras]
assert len(files) == len(set(files)) and not any(p.is_symlink() for p in files)
sha = lambda data: hashlib.sha256(data).hexdigest()
entries = {p.relative_to(root).as_posix(): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in files}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in files:
        z.write(p, p.relative_to(root).as_posix())
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == set(entries) and len(z.namelist()) == len(entries)
    for name, entry in entries.items():
        payload = z.read(name)
        assert len(payload) == entry['bytes'] and sha(payload) == entry['sha256']
index = {'schema': 'flydrones-sealed-development-evidence-v1', 'archive': archive.relative_to(root).as_posix(),
         'archive_bytes': archive.stat().st_size, 'archive_sha256': sha(archive.read_bytes()),
         'member_count': len(entries), 'members': entries,
         'local_only': {name: {'sha256': sha((stage/name).read_bytes()), 'reason': 'Full host process inventory; relevant scoped evidence included, unrelated process details retained locally.'} for name in omissions}}
with index_path.open('x') as stream:
    json.dump(index, stream, indent=2)
print(json.dumps({k:v for k,v in index.items() if k not in ('members','local_only')}, indent=2))
