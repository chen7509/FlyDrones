from pathlib import Path
import hashlib
import json
import shutil

root = Path(__file__).resolve().parents[2]
source = root.parent / 'prearm-target'
expected = {
 'data/malecns_full.npz': 'b6be8b3dd901e2e0893303c04058a110d6e0fb9922a69022b26514efcf06100c',
 'results/fly-training/connectome-distillation-v2/readout_candidate.json': 'dac766e36a2ff93415599fc1aa0e509ae61e6e3b5c83fdbff568e53fe868541e',
}
for name, digest in expected.items():
    data = (source / name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == digest
    target = root / name
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert hashlib.sha256(target.read_bytes()).hexdigest() == digest
    else:
        with target.open('xb') as stream:
            stream.write(data)
for name in ('configs/forest-trained-v2.yaml', 'configs/fly_ego_benchmark.yaml',
             'assets/gazebo/models/OakD-Benchmark/model.sdf', 'assets/gazebo/models/x500_benchmark/model.sdf'):
    assert (root / name).read_bytes() == (source / name).read_bytes()
    expected[name] = hashlib.sha256((root / name).read_bytes()).hexdigest()
with (Path(__file__).parent / 'dependencies.json').open('x') as stream:
    json.dump(expected, stream, indent=2)
