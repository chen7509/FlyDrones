from pathlib import Path
from PIL import Image
import base64
import io
import json

base=Path(__file__).resolve().parent
episode=base/'episode-v2'
manifest=json.loads((episode/'rgb-capture-manifest.json').read_text())
frames=[]
for item in manifest['frames']:
    data=io.BytesIO()
    Image.open(episode/item['path']).save(data,format='PNG')
    frames.append({'ns':item['frame_ns'],'png':base64.b64encode(data.getvalue()).decode()})
plot=base64.b64encode((base/'trajectory.png').read_bytes()).decode()
page='''<!doctype html><html lang="zh"><meta charset="utf-8"><title>单机开发回放：碰撞失败</title>
<style>body{font:16px system-ui;max-width:1000px;margin:30px auto;background:#f5f6f8;color:#172334}button{padding:8px 18px}input{width:70%}#camera{width:480px;image-rendering:pixelated;background:black}.plot{width:100%}p{line-height:1.7}</style>
<h1>单机开发回放：碰撞失败</h1><p>人工纹理开发场景 · 原始 Gazebo RGB 的无损 PNG 展示 · 完整果蝇控制/PX4 执行 · 离线 VIO，尚未送入 EKF2。播放速度是查看速度，不是仿真实时性能。</p>
<button id="play">播放</button> <input id="slider" type="range" min="0" value="0"> <span id="time"></span><p id="phase"></p><img id="camera" alt="实际采集的相机帧"><img class="plot" src="data:image/png;base64,__PLOT__" alt="失败飞行轨迹与离线 VIO 评分">
<script>const frames=__FRAMES__;const slider=document.getElementById('slider');slider.max=frames.length-1;
let timer=null;function show(){const i=Number(slider.value),t=frames[i].ns/1e9;document.getElementById('camera').src='data:image/png;base64,'+frames[i].png;document.getElementById('time').textContent=t.toFixed(3)+' 秒 · 帧 '+(i+1)+'/'+frames.length;document.getElementById('phase').textContent=t<15.68?'启动/采集阶段':t<=19.70?'预解锁静止窗口':t<33?'解锁、起飞与控制器预热阶段':'任务评分阶段；最终与树碰撞';}slider.oninput=show;document.getElementById('play').onclick=()=>{if(timer){clearInterval(timer);timer=null;return;}timer=setInterval(()=>{if(Number(slider.value)>=frames.length-1){clearInterval(timer);timer=null;return;}slider.value=Number(slider.value)+1;show();},100);};show();</script></html>'''
page=page.replace('__PLOT__',plot).replace('__FRAMES__',json.dumps(frames,separators=(',',':')))
with (base/'camera-replay.html').open('x',encoding='utf-8') as stream:
    stream.write(page)
print(f'{len(frames)} frames, {len(page.encode())} bytes')
