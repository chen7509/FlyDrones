#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/features2d.hpp>
#include <iostream>
int main(int argc, char** argv) {
  if(argc != 2) return 2;
  auto rgb = cv::imread(argv[1], cv::IMREAD_COLOR);
  if(rgb.empty()) return 3;
  cv::Mat gray;
  cv::cvtColor(rgb, gray, cv::COLOR_BGR2GRAY);
  std::vector<cv::KeyPoint> points;
  cv::FAST(gray, points, 20, true);
  std::cerr << "OpenCV " << CV_VERSION << '\n';
  std::cout << "x,y,response,interior\n";
  for(auto p : points) std::cout << p.pt.x << ',' << p.pt.y << ',' << p.response << ','
    << (p.pt.x >= 10 && p.pt.x < gray.cols-10 && p.pt.y >= 10 && p.pt.y < gray.rows-10) << '\n';
}
