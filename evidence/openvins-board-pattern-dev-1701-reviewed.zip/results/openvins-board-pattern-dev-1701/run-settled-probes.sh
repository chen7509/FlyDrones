#!/bin/bash
set -euo pipefail
cd /mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility
stage=results/openvins-board-pattern-dev-1701
for label in baseline variant; do
  target="$stage/probe-$label-v2"
  mkdir "$target"
  cp "$stage/probe-$label-v1/world.sdf" "$target/world.sdf"
  cp "$stage/probe-$label-v1/"*.png "$target/"
  python3 tools/benchmark/probe_camera_frames.py --world "$target/world.sdf" --output "$target/frame.json" --image-output "$target/frame.ppm" --min-image-ns 200000000 > "$target/run.log" 2>&1
  "$stage/fast-screen" "$target/frame.ppm" > "$target/fast20.csv" 2> "$target/fast-version.txt"
done
