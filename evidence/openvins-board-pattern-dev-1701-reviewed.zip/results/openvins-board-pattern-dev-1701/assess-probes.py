import csv
import json
import sys
from pathlib import Path

base = Path(__file__).resolve().parent
version = sys.argv[1] if len(sys.argv) > 1 else 'v1'
records = {}
for label in ('baseline', 'variant'):
    folder = base / ('probe-' + label + '-' + version)
    frame = json.loads((folder / 'frame.json').read_text())
    with (folder / 'fast20.csv').open() as stream:
        rows = list(csv.DictReader(stream))
    records[label] = {'frame': frame, 'fast_total': len(rows), 'fast_interior': sum(int(p['interior']) for p in rows)}
fields = ['camera_link_world_at_image', 'camera_model_sdf_sha256', 'vehicle_model_sdf_sha256', 'px4_base_sdf_sha256']
matched = all(records['baseline']['frame'][f] == records['variant']['frame'][f] for f in fields)
changed = records['baseline']['frame']['first_image']['ppm_sha256'] != records['variant']['frame']['first_image']['ppm_sha256']
result = {'scope': 'static rendering screen only; not VIO validation', 'opencv': (folder / 'fast-version.txt').read_text().strip(),
          'records': records, 'pose_models_matched': matched, 'image_changed': changed,
          'gate_passed': matched and changed and records['variant']['fast_interior'] >= 15}
with (base / ('static-screen-' + version + '.json')).open('x') as stream:
    json.dump(result, stream, indent=2)
print(json.dumps({k: v for k, v in result.items() if k != 'records'}))
print({k: (v['fast_total'], v['fast_interior']) for k, v in records.items()})
