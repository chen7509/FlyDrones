from pathlib import Path
import hashlib
import json
import shutil

base = Path(__file__).resolve().parent
previous = base.parents[2] / 'prearm-target/results/openvins-prearm-board-dev-1701'
source = previous / 'dependencies-v1'
manifest = json.loads((source / 'manifest.json').read_text())
target = base / 'dependencies-v1'
target.mkdir(exist_ok=False)
for name, expected in manifest['copied_files'].items():
    data = (source / name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == expected
    output = target / name
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('xb') as stream:
        stream.write(data)
shutil.copyfile(source / 'manifest.json', target / 'source-manifest.json')
for name in ('analyze_feature_trace_v1.py', 'audit_internal_init_velocity.py'):
    text = (previous / name).read_text(encoding='utf-8').replace('episode-run-v3', 'episode-v2')
    with (base / name).open('x', encoding='utf-8') as stream:
        stream.write(text)
