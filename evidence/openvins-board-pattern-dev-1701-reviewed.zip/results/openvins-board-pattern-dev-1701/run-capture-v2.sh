#!/bin/bash
set -uo pipefail
cd /mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility
stage=results/openvins-board-pattern-dev-1701
test ! -e "$stage/episode-v2" || exit 2
test ! -e "$stage/capture-v2.log" || exit 2
ps -eo pid,comm,args > "$stage/processes-before-capture-v2.txt"
/usr/bin/time -v -o "$stage/capture-v2-resources.txt" python3 tools/benchmark/run_episode.py --controller fly_raw --world-json "$stage/fixture-v1/world.json" --world-sdf "$stage/fixture-v1/world.sdf" --output "$stage/episode-v2" --record-rgb --record-camera-info --development-prearm-stationary-s 4 --development-texture-dir "$stage/fixture-v1" > "$stage/capture-v2.log" 2>&1
status=$?
printf '%s\n' "$status" > "$stage/capture-v2-exit.txt"
ps -eo pid,comm,args > "$stage/processes-after-capture-v2.txt"
exit "$status"
