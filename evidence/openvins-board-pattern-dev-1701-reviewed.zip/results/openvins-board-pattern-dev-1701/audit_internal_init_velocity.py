"""Score EKF2 velocity at OpenVINS's internal ready/initialization frame."""

import csv
import hashlib
import json
import sys
from pathlib import Path

from pyulog import ULog

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.benchmark.audit_openvins_imu_init import score_ekf_init_velocity  # noqa: E402

BASE = Path(__file__).parent
OUT = BASE / 'internal-init-audit-v1'
if OUT.exists():
    raise SystemExit('refusing existing internal initialization audit')
with (BASE / 'feature-audit-v1' / 'frame-trace.csv').open(newline='') as stream:
    rows = list(csv.DictReader(stream))
ready = [row for row in rows if row['stage'] == 'ready']
if len(ready) != 1:
    raise ValueError('expected exactly one initialization-ready frame')
internal_s = float(ready[0]['image_s'])
stdout = (BASE / 'replay-v1' / 'stdout.txt').read_text(encoding='utf-8')
if 'USING STATIC INITIALIZER METHOD!' not in stdout or 'successful initialization in' not in stdout:
    raise ValueError('missing upstream static initialization success event')
episode = BASE / 'episode-v2'
result = json.loads((episode / 'result.json').read_text())
ulog = episode / result['px4_ulogs'][0]['path']
local = ULog(str(ulog)).get_dataset('vehicle_local_position').data
velocity_rows, scored = score_ekf_init_velocity(local, internal_s - 2., internal_s)
summary = {
    'schema': 'flydrones-openvins-internal-init-velocity-v1',
    'internal_static_init_frame_s': internal_s,
    'first_initialized_runner_row_s': float(json.loads((BASE / 'feature-audit-v1' / 'summary.json').read_text())['first_initialized_s']),
    'velocity_reference': 'PX4 EKF2 fusion, not independent physical truth',
    'velocity_window_start_s': internal_s - 2.,
    'velocity_window_end_s': internal_s,
    'score': {**{k: v for k, v in scored.items() if k != 'speed_at_first_initialized_sample_m_s'},
              'speed_at_internal_init_frame_m_s': scored['speed_at_first_initialized_sample_m_s']},
    'source_sha256': {
        'ulog': hashlib.sha256(ulog.read_bytes()).hexdigest(),
        'feature_trace': hashlib.sha256((BASE / 'feature-audit-v1' / 'frame-trace.csv').read_bytes()).hexdigest(),
        'upstream_stdout': hashlib.sha256((BASE / 'replay-v1' / 'stdout.txt').read_bytes()).hexdigest(),
    },
}
OUT.mkdir()
with (OUT / 'velocity.csv').open('x', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=velocity_rows[0])
    writer.writeheader()
    writer.writerows(velocity_rows)
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
