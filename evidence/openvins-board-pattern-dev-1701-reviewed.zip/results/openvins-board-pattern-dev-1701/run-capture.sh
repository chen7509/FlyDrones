#!/bin/bash
set -uo pipefail
cd /mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility
stage=results/openvins-board-pattern-dev-1701
test ! -e "$stage/episode-v1" || exit 2
/usr/bin/time -v -o "$stage/capture-resources.txt" /home/yuchen7509/fly-ego-benchmark/venv/bin/python tools/benchmark/run_episode.py --controller fly_raw --world-json "$stage/fixture-v1/world.json" --world-sdf "$stage/fixture-v1/world.sdf" --output "$stage/episode-v1" --record-rgb --record-camera-info --development-prearm-stationary-s 4 --development-texture-dir "$stage/fixture-v1" > "$stage/capture.log" 2>&1
status=$?
printf '%s\n' "$status" > "$stage/capture-exit.txt"
exit "$status"
