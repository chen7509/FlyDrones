from pathlib import Path
import copy
import json
import shutil
import xml.etree.ElementTree as ET

base = Path(__file__).resolve().parent
previous = base.parents[2] / 'prearm-target/results/openvins-prearm-board-dev-1701'
vehicle_world = ET.parse(previous / 'episode-run-v3/world.sdf').getroot().find('world')
vehicles = [x for x in vehicle_world.findall('include') if x.findtext('name') == 'x500_benchmark_8']
assert len(vehicles) == 1
for label, source in [('baseline', previous / 'fixture-v2'), ('variant', base / 'fixture-v1')]:
    dest = base / ('probe-' + label + '-v1')
    dest.mkdir(exist_ok=False)
    tree = ET.parse(source / 'world.sdf')
    world = tree.getroot().find('world')
    assert not world.findall('include')
    world.append(copy.deepcopy(vehicles[0]))
    ET.indent(tree)
    tree.write(dest / 'world.sdf', encoding='utf-8', xml_declaration=True)
    for name in ['ground_albedo.png', 'obstacle_albedo.png', 'board_albedo.png']:
        if (source / name).exists():
            shutil.copyfile(source / name, dest / name)
print(json.dumps({'vehicle': ET.tostring(vehicles[0], encoding='unicode')}))
