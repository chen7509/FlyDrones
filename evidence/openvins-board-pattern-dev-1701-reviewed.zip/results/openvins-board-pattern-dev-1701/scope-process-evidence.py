from pathlib import Path
import hashlib
import json

base=Path(__file__).resolve().parent
out={}
for name in ['processes-before-capture-v2.txt','processes-after-capture-v2.txt']:
    data=(base/name).read_bytes()
    lines=data.decode().splitlines()
    relevant=[line for line in lines if any(token in line.lower() for token in
              ['px4','gazebo','gz sim','offline_probe','probe_camera','run_episode','run-capture'])]
    out[name]={'raw_sha256':hashlib.sha256(data).hexdigest(),'relevant_lines':relevant,
               'note':'Full inventory remains local; unrelated processes omitted from published evidence.'}
with (base/'scoped-process-evidence.json').open('x') as stream:
    json.dump(out,stream,indent=2)
