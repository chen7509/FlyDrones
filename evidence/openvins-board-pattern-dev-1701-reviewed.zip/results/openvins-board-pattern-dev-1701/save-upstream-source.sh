#!/bin/bash
set -euo pipefail
base=/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/results/openvins-board-pattern-dev-1701
upstream=/home/yuchen7509/flydrones-upstream/open_vins_vio_init_probe
mkdir "$base/upstream-source"
for name in VioManager.h VioManager.cpp VioManagerHelper.cpp; do
  cp "$upstream/ov_msckf/src/core/$name" "$base/upstream-source/$name"
done
cp "$upstream/LICENSE" "$base/upstream-source/LICENSE"
sha256sum "$base/upstream-source/"* > "$base/upstream-source-hashes.txt"
git -C "$upstream" diff > "$base/upstream-local.patch"
