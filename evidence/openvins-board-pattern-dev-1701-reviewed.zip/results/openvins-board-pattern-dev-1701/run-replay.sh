#!/bin/bash
set -uo pipefail
cd /mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility
stage=results/openvins-board-pattern-dev-1701
test ! -e "$stage/replay-v1" || exit 2
mkdir "$stage/replay-v1" || exit 2
export LD_LIBRARY_PATH=/home/yuchen7509/flydrones-upstream/open_vins_vio_init_probe/ov_msckf/build
/usr/bin/time -v -o "$stage/replay-v1/resources.txt" "$stage/dependencies-v1/offline_probe" "$stage/dependencies-v1/config-v2/estimator_config.yaml" "$stage/input-v1" "$stage/episode-v2" "$stage/replay-v1/states.csv" > "$stage/replay-v1/stdout.txt" 2> "$stage/replay-v1/stderr.txt"
status=$?
printf '%s\n' "$status" > "$stage/replay-v1/exit-code.txt"
exit "$status"
