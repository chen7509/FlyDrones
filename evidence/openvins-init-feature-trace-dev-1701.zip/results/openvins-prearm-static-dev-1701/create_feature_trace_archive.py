"""Seal one offline initialization trace without touching prior evidence."""

import hashlib
import json
import zipfile
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


root = Path(__file__).resolve().parents[2]
episode = root / 'results/openvins-prearm-static-dev-1701'
trace = episode / 'feature-trace-v1'
archive = root / 'evidence/openvins-init-feature-trace-dev-1701.zip'
index = archive.with_suffix('.index.json')
if archive.exists() or index.exists() or (trace / 'manifest.json').exists():
    raise SystemExit('trace seal already exists; refusing overwrite')

dependencies = {
    name: sha(root / relative) for name, relative in {
        'input_manifest': 'results/openvins-prearm-static-dev-1701/input-v1/manifest.json',
        'runner': 'results/openvins-offline-1701/runner-v3/offline_probe',
        'config': 'results/openvins-texture-dev/config-v2/estimator_config.yaml',
        'episode_result': 'results/openvins-prearm-static-dev-1701/episode-run/result.json',
        'upstream_patch': 'tools/benchmark/openvins_init_feature_trace.patch',
        'parser': 'tools/benchmark/audit_openvins_init_feature_trace.py',
    }.items()
}
manifest = {
    'schema': 'flydrones-openvins-init-feature-evidence-v1',
    'upstream': 'rpng/open_vins@69488123ed9362dd44b6f28e7f4680abbff1442b',
    'license': 'GPL-3.0',
    'library_sha256': '532ae57a6a952a0137cc1de291bc47ad556d419c7524fbb23b7a90c00addab5b',
    'compiler': 'g++ (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0',
    'opencv': '4.6.0',
    'baseline_states_sha256': 'e69af3be567e4f80345bf7e079130f55de5127246824bc46103658ea55fe1e9b',
    'dependencies_sha256': dependencies,
    'trace_files_sha256': {
        str(path.relative_to(trace)).replace('\\', '/'): sha(path)
        for path in sorted(trace.rglob('*')) if path.is_file()
    },
}
(trace / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
with archive.open('xb') as stream, zipfile.ZipFile(stream, 'w', zipfile.ZIP_DEFLATED) as zipped:
    for path in sorted(trace.rglob('*')):
        if path.is_file():
            zipped.write(path, str(path.relative_to(root)).replace('\\', '/'))
    zipped.write(Path(__file__), str(Path(__file__).relative_to(root)).replace('\\', '/'))
with zipfile.ZipFile(archive) as zipped:
    if zipped.testzip() is not None:
        raise RuntimeError('archive CRC failure')
index.write_text(json.dumps({
    'schema': 'flydrones-evidence-archive-v1',
    'archive_sha256': sha(archive),
    'archive_size': archive.stat().st_size,
    'members': len(zipped.namelist()),
}, indent=2) + '\n', encoding='utf-8')
print(index.read_text(encoding='utf-8'))
