"""Retain one synthetic joined audit. No physical/native/network execution."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

from tests.benchmark import live_wire_motion_fixture, live_wire_source_fixture  # noqa: F401
from tests.benchmark.live_wire_joined_fixture import DAEMON, add_joined_sources, build_joined_wire_physics, read_joined_fixture
from tests.benchmark.test_live_wire_camera_info import fixture as camera_fixture  # noqa: F401
from tools.benchmark import audit_live_wire_study as audit
from tools.benchmark.audit_live_wire_workload import audit_source_native_records


def digest(data):
    return hashlib.sha256(data).hexdigest()


def loaded_sources(root):
    found = {}
    for module in tuple(sys.modules.values()):
        name = getattr(module, "__file__", None)
        if not name:
            continue
        path = Path(name).resolve()
        if path.suffix == ".py" and path.is_relative_to(root):
            found[path.relative_to(root).as_posix()] = path.read_bytes()
    return found


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--producer", required=True)
    args = parser.parse_args()
    root = Path.cwd().resolve()
    output = root / "results/live-wire-study-audit-dev-1701/initialized-motion-v1"
    output.mkdir()
    before = loaded_sources(root)
    before[Path(__file__).resolve().relative_to(root).as_posix()] = Path(__file__).read_bytes()
    for name, data in before.items():
        selected = output / "source-before" / name
        selected.parent.mkdir(parents=True, exist_ok=True)
        selected.write_bytes(data)
    (output / "source-before.json").write_text(json.dumps({k: digest(v) for k, v in before.items()}, indent=2))
    capture = output / "capture"
    generated = build_joined_wire_physics(capture)
    add_joined_sources(generated, initialized_at_ns=1_200_000_000)
    del generated
    e = read_joined_fixture(capture)
    checks = dict(
        protocol=audit.audit_wire_protocol_records(records=e["records"], clock=e["clock"],
                                                  clock_attempts=e["clock_attempts"], context=e["context"]),
        interval=audit.audit_wire_interval_records(e["records"], e["context"]),
        listener=audit.audit_owned_listener_records(records=e["records"], context=e["context"], daemon_path=DAEMON),
        physical=audit.audit_physical_coverage_records(**e["physical"]),
        source=audit_source_native_records(**e["source"]),
        camera=audit.audit_camera_info_records(**e["camera"]),
        health=audit.audit_health_coverage_records(**e["health"]),
        source_health=audit.audit_source_health_records(**e["source_health"]),
        fast=audit.audit_fast_coverage_records(**e["fast"]),
        motion=audit.audit_motion_records(**e["motion"]),
        anchor=audit.audit_anchor_records(**e["anchor"]),
        gauge=audit.audit_gauge_records(**e["gauge"]),
    )
    for result in checks.values():
        assert result["live_qualified"] is False and result["fusion_qualified"] is False
    after = {name: digest((root / name).read_bytes()) for name in before}
    assert after == {k: digest(v) for k, v in before.items()}, "producer drift"
    late = {k: digest(v) for k, v in loaded_sources(root).items() if k not in before}
    result = dict(
        producer=args.producer,
        checks=checks,
        consumed_files=e["consumed_files"],
        source_after=after,
        late_loaded_repository_sources=late,
        synthetic_provenance=e["provenance"],
        complete_runtime_freeze_qualified=False,
        whole_study_qualified=False,
        native_estimator_run=False,
        physical_execution_qualified=False,
        live_qualified=False,
        fusion_qualified=False,
    )
    (output / "audit.json").write_text(json.dumps(result, allow_nan=False, indent=2))
    print(json.dumps(dict(checks=list(checks), consumed_files=len(e["consumed_files"]),
                          copied_sources=len(before), late_loaded_sources=late, live_qualified=False)))


if __name__ == "__main__":
    main()
