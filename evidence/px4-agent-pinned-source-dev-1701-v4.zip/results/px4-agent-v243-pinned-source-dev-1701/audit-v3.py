"""Compare the prepared Agent tree with a separate Git archive of the fixed commit."""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
GIT_ENV = {**os.environ, "GIT_NO_REPLACE_OBJECTS": "1"}
SOURCE = HERE / "source-v3"
UPSTREAM = HERE.parent / "px4-agent-v243-source-dev-1701/upstream"
PINS = {
    b"set(_fastcdr_tag 2.2.x)": b"set(_fastcdr_tag 757d5e422253568c487ad97c22e44680fc1ddbaf)",
    b"set(_fastdds_tag 2.14.x)": b"set(_fastdds_tag 575d045b55c16be1074ccd9eebf95e3e4274fe61)",
    b"set(_foonathan_memory_tag v0.7-3)": b"set(_foonathan_memory_tag 0f0775770fd1c506fa9c5ad566bd6ba59659db66)",
    b"set(_spdlog_tag v1.9.2)": b"set(_spdlog_tag eb3220622e73a4889eee355ffa37972b3cac3df5)",
    b"set(UAGENT_P2P_CLIENT_TAG v2.4.3 CACHE STRING": (
        b"set(UAGENT_P2P_CLIENT_TAG d44dc3fa0c488376e34d26ed92853f1c66dcb670 CACHE STRING"
    ),
}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    profile_raw = (SOURCE / "source-profile.json").read_bytes()
    profile = json.loads(profile_raw)
    assert profile["agent_commit"] == "73622810d984349b80bbac0ef55fc0b694d62222"
    assert profile["agent_tree"] == "30de05fce045d2cc40c3b911f4dc5085b24f1ab4"
    assert profile["file_count"] == 213
    assert profile["agent_binary_built_or_run"] is False
    assert profile["dependency_commits_verified_locally"] is False
    assert profile["px4_agent_interoperability_verified"] is False
    names = subprocess.check_output(
        ["git", "-C", str(UPSTREAM), "ls-tree", "-r", "-z", "--name-only", "HEAD"], env=GIT_ENV
    ).decode("utf-8").strip("\0").split("\0")
    assert len(names) == 213 and set(names) == set(profile["files"])
    changed = []
    for name in names:
        original = subprocess.check_output(
            ["git", "-C", str(UPSTREAM), "show", f"HEAD:{name}"], env=GIT_ENV
        )
        expected = original
        if name == "CMakeLists.txt":
            for old, new in PINS.items():
                assert expected.count(old) == 1
                expected = expected.replace(old, new)
        actual = (SOURCE / name).read_bytes()
        assert actual == expected, name
        assert profile["files"][name] == sha(actual), name
        if actual != original:
            changed.append(name)
    assert changed == ["CMakeLists.txt"]
    assert {p.relative_to(SOURCE).as_posix() for p in SOURCE.rglob("*") if p.is_file()} == (
        set(profile["files"]) | {"source-profile.json"}
    )
    print(json.dumps({
        "schema": "flydrones.pinned_xrce_agent_source_audit.v1",
        "reference_kind": "git_show_raw_blob",
        "source_profile_sha256": sha(profile_raw),
        "source_file_count": len(names),
        "changed_from_git": changed,
        "dependency_commit_objects_verified_locally": False,
        "agent_binary_built_or_run": False,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
