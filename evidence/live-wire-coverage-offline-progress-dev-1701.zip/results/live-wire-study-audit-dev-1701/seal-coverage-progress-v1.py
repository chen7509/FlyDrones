"""Exclusive interim evidence archive; no raw-input duplication or live claim."""
import hashlib
import json
import zipfile
from pathlib import Path

root = Path('results/live-wire-study-audit-dev-1701')
target = Path('evidence/live-wire-coverage-offline-progress-dev-1701.zip')
paths = [
    Path(name) for name in [
        'tools/benchmark/audit_live_wire_coverage.py',
        'tools/benchmark/audit_live_wire_study.py',
        'tools/benchmark/openvins_online_probe.cpp',
        'tools/benchmark/openvins_fast_probe.h',
        'tools/benchmark/build_openvins_ekf2_fast_run_evidence.py',
        'tools/benchmark/openvins_ekf2_fast_contract.py',
        'tools/benchmark/openvins_health_contract.py',
        'tools/benchmark/openvins_online_shadow.py',
        'tools/benchmark/native_reference_probe.py',
        'tools/benchmark/physics_substep_trace.py',
        'tools/benchmark/disarmed_motion_probe.py',
        'tools/benchmark/capture_wire_lifecycle.py',
        'tests/benchmark/test_live_wire_physics_fast_audit.py',
        'tests/benchmark/test_live_wire_health_audit.py',
        'tests/benchmark/test_live_wire_study_entry.py',
        'docs/LIVE_WIRE_RAW_EVIDENCE_MAP.md',
        'docs/LIVE_WIRE_STUDY_PREPARATION_REPORT.md',
        'docs/superpowers/plans/2026-10-08-live-wire-study.md',
        'docs/superpowers/specs/2026-10-08-live-wire-study-design.md',
        '.superpowers/sdd/2026-10-08-live-wire-study/progress.md',
    ]
]
paths += [root/name for name in [
    'physics-fast-red-v1.txt', 'physics-fast-green-v1.txt',
    'coverage-entry-red-v1.txt', 'coverage-entry-green-v1.txt',
    'health-replay-red-v1.txt', 'coverage-health-green-v2.txt',
    'health-entry-red-v1.txt', 'coverage-ruff-first.txt',
    'coverage-health-regression-v1.txt', 'coverage-health-regression-v2.txt',
    'reference-terminal-wall-red-v1.txt', 'coverage-final-regression-v1.txt',
    'coverage-final-ruff.txt', 'coverage-final-diff.txt',
    'check-coverage-fixed-v1.py', 'fixed-coverage-v1.json', 'fixed-coverage-console-v1.txt',
    'retain-fixed-coverage-producer.py', 'fixed-coverage-producer-reconstructed.py',
    'fixed-coverage-producer-provenance.json', 'seal-coverage-progress-v1.py',
]]
members = {str(path).replace('\\', '/'): path.read_bytes() for path in paths}
if len(members) != len(paths):
    raise ValueError('duplicate evidence member')
manifest = dict(producer_commit='9145ea9', scope='partial offline coverage integration; Task2/3 unfinished',
    live_qualified=False, fusion_qualified=False, remote_published=False,
    members={name:dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) for name,data in members.items()})
members['manifest.json'] = json.dumps(manifest, indent=2, sort_keys=True).encode()
with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name, data in members.items():
        archive.writestr(name, data)
with zipfile.ZipFile(target) as archive:
    if archive.testzip() is not None or len(archive.namelist()) != len(members):
        raise ValueError('archive integrity failed')
    for name, data in members.items():
        if archive.read(name) != data:
            raise ValueError('member mismatch: '+name)
record = dict(path=str(target), members=len(members), bytes=target.stat().st_size,
              sha256=hashlib.sha256(target.read_bytes()).hexdigest(), crc_and_all_members_verified=True)
with (root/'coverage-progress-seal-v1.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record, indent=2))
