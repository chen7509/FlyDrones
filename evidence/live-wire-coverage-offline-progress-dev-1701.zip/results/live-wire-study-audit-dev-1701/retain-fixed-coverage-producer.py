"""Explicit post-run reconstruction, checked against the recorded producer hash."""
import hashlib
import json
from pathlib import Path

root = Path('results/live-wire-study-audit-dev-1701')
report = json.loads((root/'fixed-coverage-v1.json').read_text())
entry = next(value for key, value in report['files'].items() if key.replace('\\', '/').endswith('/audit_live_wire_coverage.py'))
current = Path('tools/benchmark/audit_live_wire_coverage.py').read_bytes()
added = b'''    _shape(terminal["last_attempt"], ("phase", "ns_repr", "wall_ns"), "last reference attempt")
    _integer(
        terminal["last_attempt"]["wall_ns"],
        observations[-1]["journal_return_ns"],
        reference[-1]["wall_ns"],
        "last reference attempt wall time",
    )
'''
if current.count(added) != 1:
    raise ValueError('unexpected producer diff')
prior = current.replace(added, b'', 1)
digest = hashlib.sha256(prior).hexdigest()
if digest != entry['sha256']:
    raise ValueError('reconstructed producer hash mismatch')
with (root/'fixed-coverage-producer-reconstructed.py').open('xb') as stream:
    stream.write(prior)
with (root/'fixed-coverage-producer-provenance.json').open('x') as stream:
    json.dump(dict(sha256=digest, bytes=len(prior), matches_recorded_pre_post_hash=True,
        reconstructed_after_run=True, pre_run_copy=False,
        difference='subsequent final reference-attempt wall-time guard only'), stream, indent=2)
print(digest)
