"""Read old development evidence once; never launch physics or an estimator."""
import hashlib
import json
from pathlib import Path

from tools.benchmark.audit_live_wire_study import (
    StudyEvidenceReader,
    audit_fast_coverage_records,
    audit_health_coverage_records,
)

root = Path('results/openvins-health-physical-dev-1701-v2/development-seed-27201/capture-v1')
out = Path('results/live-wire-study-audit-dev-1701/fixed-coverage-v1.json')
if out.exists():
    raise FileExistsError(out)
reader = StudyEvidenceReader()
sources = ['tools/benchmark/audit_live_wire_coverage.py', 'tools/benchmark/audit_live_wire_study.py',
           'tools/benchmark/openvins_health_contract.py', 'tools/benchmark/openvins_online_shadow.py',
           'tools/benchmark/build_openvins_ekf2_fast_run_evidence.py',
           'tools/benchmark/openvins_ekf2_fast_contract.py']
for name in sources:
    reader.raw(Path(name))
states = reader.lines(root/'shadow/states.jsonl')
health = audit_health_coverage_records(
    states=states, records=reader.lines(root/'shadow/health-evidence.jsonl'),
    terminal=reader.document(root/'shadow/health-result.json'),
    shadow_last=reader.document(root/'shadow/shadow-input-result.json')['health_last'],
    session_id='online-native-' + str(reader.document(root/'shadow/native-session.json')['pid']),
    profile_name='px4-d6f12ad-gate-floor-v1')
try:
    audit_fast_coverage_records(records=reader.lines(root/'shadow/fast.jsonl'),
        acknowledgements=reader.lines(root/'shadow/native-acks.jsonl'), end_sim_ns=25_000_000_000)
except ValueError as exc:
    refusal = str(exc)
    if refusal != 'incomplete/current aligned fast target grid':
        raise
else:
    raise AssertionError('legacy 1ms-origin producer must not pass current 20ms-aligned grid')
reader.finish()
result = dict(health=health, legacy_fast_expected_refusal=refusal,
    files=reader.files, inputs_and_producer_stable=True,
    estimator_executed=False, simulator_executed=False,
    physical_clock_join_tested=False, live_qualified=False, fusion_qualified=False,
    harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
with out.open('x') as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
print(json.dumps({k:v for k,v in result.items() if k != 'files'}, indent=2))
