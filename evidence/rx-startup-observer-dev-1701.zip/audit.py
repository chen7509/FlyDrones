"""Read-only exact-byte audit of the one observer, no socket replay."""
import hashlib
import json
import struct
from pathlib import Path

base = Path(__file__).parent
run = base/'study-v1'
def read(name):
    return json.loads((run/name).read_text())
before, after, frozen = read('inputs-before.json'), read('inputs-after.json'), read('frozen-inputs-after.json')
assert before == after == frozen
for name, digest in before.items():
    assert hashlib.sha256((run/'inputs'/name).read_bytes()).hexdigest() == digest
dispatch, completion, profile = read('dispatch.json'), read('completion.json'), read('profile.json')
assert hashlib.sha256((run/'profile.json').read_bytes()).hexdigest() == dispatch['profile_sha256']
assert completion['profile_stable'] and completion['selected_inputs_stable']
assert not completion['cache_directory_created'] and '-I' in dispatch['command'] and '-B' in dispatch['command']
result = read('capture-v1/result.json')
assert result['status'] == 'observed' and result['errors'] == [] and result['profile_post_verified']
assert result['production_parser_used'] is False
assert len(result['packets']) == profile['count'] == 8
events = [json.loads(line) for line in (run/'capture-v1/packets.jsonl').read_text().splitlines()]
assert len(events) == 32
timestamps, starts, queue_lower, holds, timing = [], [], [], [], []
for i, row in enumerate(result['packets']):
    assert row['index'] == i and row['send_returned'] and row['recv_returned'] and row['flags'] == 0
    payload = f"FLYD_RX_STARTUP_V1:{result['nonce']}:{i}".encode()
    assert row['payload_hex'] == row['received_payload_hex'] == payload.hex() and row['sent_bytes'] == len(payload) == 53
    assert row['received_peer'] == result['sender_identity']['local']
    packet_events = events[i*4:(i+1)*4]
    assert [x['phase'] for x in packet_events] == ['send_attempt', 'send_return', 'recv_return', 'observed']
    assert packet_events[-1] == row and all(x['index'] == i and x['payload_hex'] == payload.hex() for x in packet_events)
    assert len(row['ancillary_raw']) == 1
    control = row['ancillary_raw'][0]
    assert control['level'] == 1 and control['type'] == 65
    raw = bytes.fromhex(control['data_hex'])
    assert len(raw) == 48
    sec, nsec, *other = struct.unpack('<6q', raw)
    assert sec > 0 and 0 <= nsec < 1_000_000_000 and other == [0,0,0,0]
    stamp = sec*1_000_000_000+nsec
    assert row['metadata'] == {'timestamp_ns': stamp, 'reason': None}
    assert row['send_start_realtime_ns'] <= stamp <= row['recv_start_realtime_ns'] <= row['recv_return_realtime_ns']
    assert row['send_receive_bracket_valid'] and row['generated_before_read'] and row['timestamp_order_valid']
    hold = row['recv_start_monotonic_ns']-row['send_return_monotonic_ns']
    assert hold >= profile['hold_ns']
    assert row['recv_return_monotonic_ns']-row['recv_start_monotonic_ns'] < profile['poll_ns']
    starts.append(row['send_start_monotonic_ns'])
    holds.append(hold)
    timestamps.append(stamp)
    queue_lower.append(row['recv_start_realtime_ns']-stamp)
    assert queue_lower[-1] == row['realtime_queue_lower_ns']
    timing.append({'index': i, 'hold_observation_ns': hold, 'realtime_queue_lower_ns': queue_lower[-1],
                   'timestamp_minus_pre_send_realtime_ns': stamp-row['send_start_realtime_ns'],
                   'raw_ts0_ns': stamp})
gaps = [b-a for a,b in zip(starts, starts[1:])]
assert all(x >= profile['gap_ns'] for x in gaps) and all(b>=a for a,b in zip(timestamps,timestamps[1:]))
assert result['production_would_refuse_at'] is None and result['metadata_present_indices'] == list(range(8))
for name in ('arrival_qualified', 'clock_qualified', 'source_authenticated', 'fusion_qualified', 'training_eligible'):
    assert result[name] is False
assert len(result['owned_close']) == 2
assert all(x['fileno_after'] == -1 and x['fstat_errno'] == 9 and x['close_error'] is None for x in result['owned_close'])
assert len(result['module_origins']) == 10
for name, path in result['module_origins'].items():
    assert Path(path).as_posix().endswith('/study-v1/inputs/'+name)
supervisor = read('supervisor.json')
journal = [json.loads(x) for x in (run/'supervisor-events.jsonl').read_text().splitlines()]
cleanup = supervisor['cleanup']
assert journal == cleanup['events'] == completion['cleanup']['events']
assert supervisor['worker_exit'] == completion['exit_code'] == 0 and supervisor['errors'] == []
assert cleanup['group_absent'] and cleanup['no_executing_members'] and cleanup['graceful_group_cleanup_verified']
assert not cleanup['sigkill_dispatched'] and not cleanup['all_descendant_cleanup_qualified']
owner = cleanup['owner']
assert owner['pid'] == owner['pgrp'] == owner['session'] == completion['child_pid']
record = {'status': 'complete_observation_only', 'source_commit': dispatch['source_commit'],
          'input_count':len(before), 'frozen_module_origins':len(result['module_origins']),
          'raw_packet_events':len(events), 'packets':8, 'present_indices':list(range(8)), 'missing_indices':[],
          'first_packet_timestamp_present':True, 'all_timestamps_before_read_observed':True,
          'minimum_actual_inter_send_ns':min(gaps), 'minimum_observed_hold_ns':min(holds),
          'queue_lower_ns_range':[min(queue_lower),max(queue_lower)], 'per_packet':timing,
          'first_attempt_to_last_recv_ns':result['packets'][-1]['recv_return_monotonic_ns']-result['packets'][0]['attempt_monotonic_ns'],
          'dispatcher_elapsed_ns':completion['elapsed_wall_ns'], 'FD_close_verified':True,
          'owned_group_owner':owner, 'group_absent':True, 'no_executing_members':True,
          'supervisor_signal_events':sum(x['event'].startswith('signal_') for x in journal),
          'supervisor_journal_matches_memory':True, 'all_descendant_cleanup_qualified':False,
          'profile_sha256':dispatch['profile_sha256'], 'prior_failure_reclassified':False,
          'global_cold_state_proven':False, 'runtime_causality_proven':False,
          'source_clock_arrival_fusion_training_qualified':False, 'observer_repeated':False}
with (base/'audit-v1.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record, indent=2))
