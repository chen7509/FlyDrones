"""One observer-only frozen copy; reuses owned-group supervisor."""
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.benchmark import observe_kernel_rx_startup as study  # noqa: E402
from tools.benchmark.owned_group_evidence import GroupEvidence, finish_owned_worker  # noqa: E402

OUT = Path(__file__).parent / 'study-v1'
def write(name, value):
    with (OUT/name).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
def sha(path):
    return hashlib.sha256(study.read_static(path)).hexdigest()

study.check_module_origins()
OUT.mkdir(exist_ok=False)
inputs = OUT/'inputs'
selected = [*study.SOURCES, study.prior.ABI_PATH, study.prior.PROBE_PATH,
            'tests/benchmark/test_rx_startup_observer.py',
            'docs/superpowers/specs/2026-10-12-rx-startup-observer-design.md',
            'docs/superpowers/plans/2026-10-12-rx-startup-observer.md']
before = {name: sha(ROOT/name) for name in selected}
for name in selected:
    target = inputs/name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT/name, target)
    assert sha(target) == before[name]
write('inputs-before.json', before)
profile = {**study.CONDITIONS, 'sources': {name: before[name] for name in study.SOURCES},
           'abi_sha256': study.prior.ABI_SHA, 'probe_sha256': study.prior.PROBE_SHA}
write('profile.json', profile)
path = OUT/'profile.json'
digest = sha(path)
study.validate_profile(path.read_bytes(), digest, inputs)
cache = OUT/'uncreated-cache-prefix'
assert not cache.exists()
command = ['/usr/bin/timeout', '--kill-after=2s', '20s', '/usr/bin/python3', '-I', '-B', '-X',
           'pycache_prefix='+str(cache), str(inputs/study.SOURCES[0]), '--profile', str(path),
           '--profile-sha256', digest, '--output', str(OUT/'capture-v1')]
env = {'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C'}
write('dispatch.json', {'command': command, 'environment': env, 'profile_sha256': digest,
                       'realtime_ns': time.time_ns(), 'python': sys.version, 'kernel': platform.release(),
                       'dispatcher_pid': os.getpid(), 'dispatcher_sha256': sha(Path(__file__)),
                       'source_commit': (Path(__file__).parent/'source-commit.txt').read_text().strip(),
                       'fresh_cache_prefix': str(cache), 'frozen_entry': True,
                       'runtime_closure_qualified': False, 'scope': 'eight opaque own loopback packets only'})
started = time.monotonic_ns()
with (OUT/'stdout.txt').open('xb') as stdout, (OUT/'stderr.txt').open('xb') as stderr, \
        (OUT/'supervisor-events.jsonl').open('x') as events:
    child = subprocess.Popen(command, cwd=OUT, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
    evidence = GroupEvidence(child, events)
    supervisor = finish_owned_worker(child, evidence, 25)
    code = supervisor['worker_exit']
write('supervisor.json', supervisor)
after = {name: sha(ROOT/name) for name in selected}
copied = {name: sha(inputs/name) for name in selected}
write('inputs-after.json', after)
write('frozen-inputs-after.json', copied)
write('completion.json', {'exit_code': code, 'child_pid': child.pid,
                         'elapsed_wall_ns': time.monotonic_ns()-started,
                         'supervisor_status': supervisor['status'], 'supervisor_errors': supervisor['errors'],
                         'cleanup': supervisor['cleanup'], 'selected_inputs_stable': before==after==copied,
                         'profile_stable': digest==sha(path), 'cache_directory_created': cache.exists(),
                         'runtime_closure_qualified': False, 'all_descendant_cleanup_qualified': False})
if (code != 0 or supervisor['status'] != 'worker_exited' or supervisor['errors']
        or not supervisor['cleanup']['graceful_group_cleanup_verified'] or before != after
        or copied != before or digest != sha(path)):
    raise RuntimeError('single observer attempt failed; no retry')
print(json.dumps({'worker_exit': code, 'cleanup': supervisor['cleanup']['graceful_group_cleanup_verified'],
                  'sources': len(before)}))
