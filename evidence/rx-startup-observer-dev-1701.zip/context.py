"""Read-only interfaces; no timestamp or tracing options changed."""
import hashlib
import json
import os
import platform
from pathlib import Path

record = {'kernel': platform.release(), 'global_cold_state_proven': False,
          'installed_source_equivalence': False, 'runtime_causality_proven': False, 'observations': []}
for name in ['/proc/sys/net/core/netdev_tstamp_prequeue',
             '/sys/kernel/debug/tracing/available_filter_functions',
             '/sys/kernel/tracing/available_filter_functions']:
    item = {'path': name, 'readable': os.access(name, os.R_OK)}
    try:
        with Path(name).open('rb') as stream:
            raw = stream.read(512*1024+1)
        if len(raw) > 512*1024:
            raise ValueError('read-only trace-context bound')
        item.update(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
        text = raw.decode('ascii')
        item['selected'] = ([line for line in text.splitlines() if 'netstamp' in line]
                            if 'functions' in name else text)
    except (OSError, ValueError, UnicodeError) as error:
        item['error'] = repr(error)
    record['observations'].append(item)
with (Path(__file__).parent / 'context-v1.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record, indent=2))
