import hashlib
import json
import urllib.request
from pathlib import Path

base = Path(__file__).parent
out = base / 'sources-v1'
out.mkdir(exist_ok=False)
record = {'fixed_version': 'Linux v6.6', 'license': 'GPL2-family; UAPI syscall exception',
          'python': 'existing Python3.12 PSF; socket.recvmsg, monotonic_ns and time_ns',
          'maintenance': 'fixed-source/current API lookup; no support or installed-equivalence claim',
          'choice': 'bounded per-socket raw observer; reject warm/drop-first/parser unlatch/kernel tuning',
          'resource': 'eight own loopback packets, no new dependencies/compile/physical stack',
          'qualification': False, 'observations': [],
          'initial_readonly_tooling_failures': ['PowerShell expansion broke first shell loop; no write performed',
              'one-shot Path.exists capability inventory aborted on PermissionError; per-path context now records it'],
          'urls': ['https://www.kernel.org/doc/html/v6.6/networking/timestamping.html']}
for name, url in [
    ('dev.c', 'https://raw.githubusercontent.com/torvalds/linux/v6.6/net/core/dev.c'),
    ('loopback.c', 'https://raw.githubusercontent.com/torvalds/linux/v6.6/drivers/net/loopback.c'),
    ('timestamping.rst', 'https://raw.githubusercontent.com/torvalds/linux/v6.6/Documentation/networking/timestamping.rst')]:
    item = {'url': url, 'name': name}
    try:
        with urllib.request.urlopen(url, timeout=15) as response:
            raw = response.read(1_000_001)
        if len(raw) > 1_000_000:
            raise ValueError('fixed-source read bound')
        (out / name).write_bytes(raw)
        item.update(status='downloaded', bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    except Exception as error:
        item.update(status='failed', error=repr(error))
    record['observations'].append(item)
with (base / 'research.json').open('x', encoding='utf-8') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record, indent=2))
