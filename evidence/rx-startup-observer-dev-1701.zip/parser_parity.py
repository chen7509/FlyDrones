"""Saved bytes + historical realtime projection, not live socket recovery."""
import hashlib
import json
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root))
from tools.benchmark.kernel_rx_timestamping import KernelRXTimestamping  # noqa: E402

base = Path(__file__).parent
run = base/'study-v1'
raw_result = (run/'capture-v1/result.json').read_bytes()
assert hashlib.sha256(raw_result).hexdigest() == '7ee745a10ec2b13c68928943c7de38911aba765a3c861828b360e871383d0b0d'
result = json.loads(raw_result)
before = json.loads((run/'inputs-before.json').read_text())
abi = run/'inputs/results/kernel-rx-timestamping-dev-1701/capability-completion-v1/abi.json'
data = abi.read_bytes()
for name in ['tools/benchmark/kernel_rx_timestamping.py', 'tools/benchmark/kernel_datagram_arrival.py']:
    assert hashlib.sha256((root/name).read_bytes()).hexdigest() == before[name]
    assert hashlib.sha256((run/'inputs'/name).read_bytes()).hexdigest() == before[name]
clock = [None]
parser = KernelRXTimestamping(data, hashlib.sha256(data).hexdigest(), realtime_ns=lambda:clock[0])
rows = []
for row in result['packets']:
    clock[0] = row['recv_return_realtime_ns']
    ancillary = [(x['level'],x['type'],bytes.fromhex(x['data_hex'])) for x in row['ancillary_raw']]
    stamp = parser.parse(ancillary, row['flags'], parser.realtime())
    assert stamp == row['metadata']['timestamp_ns']
    rows.append({'index':row['index'], 'raw_kernel_timestamp_ns':stamp})
record = {'status':'offline_parity', 'samples':len(rows), 'rows':rows,
          'input_result_sha256':hashlib.sha256(raw_result).hexdigest(),
          'realtime_basis':'retained post-return-journal observations, virtual replay only',
          'socket_bound':False, 'production_receiver_recovered':False,
          'source_arrival_clock_fusion_training_qualified':False}
with (base/'parser-parity-v2.json').open('x') as stream:
    json.dump(record,stream,indent=2)
print(json.dumps(record,indent=2))
