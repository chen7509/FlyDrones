import hashlib
import json
import shutil
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
base = Path(__file__).parent
execution = json.loads((base/'final-v1/execution.json').read_text())
assert execution['source_unchanged'] and all(x['exit_code']==0 for x in execution['commands'])
for name,digest in execution['source_after'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
    target = base/'final-source'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(root/name,target)
for name in ['docs/RX_STARTUP_OBSERVER_REPORT.md',
             'docs/superpowers/specs/2026-10-12-rx-startup-observer-design.md',
             'docs/superpowers/plans/2026-10-12-rx-startup-observer.md']:
    target = base/'documents'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(root/name,target)
audit = json.loads((base/'audit-v1.json').read_text())
assert audit['packets']==8 and audit['present_indices']==list(range(8)) and not audit['observer_repeated']
assert not audit['source_clock_arrival_fusion_training_qualified']
references = {'evidence/generated-rx-queue-study-dev-1701.zip':'f4fe0c92902a4f2dedce0c6cf2c77a227d840f3fd3d65e8168ad33c21b10d6d9',
              'evidence/kernel-rx-timestamping-dev-1701.zip':'a6465dfc0a74a65031c5847208706b6dd3c316410e8087249714924e4e90b537',
              'evidence/benchmark-publication-safety-dev-1701.zip':'1403370fed70c3507e46978a8c9a586769e68d834a40afa4825f67f76a9697f1'}
for name,digest in references.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
with (base/'prior-stage-references.json').open('x') as stream:
    json.dump({'archives':references,'modified':False,'rerun':False},stream,indent=2)
files = sorted(p for p in base.rglob('*') if p.is_file() and p.suffix!='.pyc'
               and p.name not in ['seal.json','pr65-before.json'])
members = {p.relative_to(base).as_posix():{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
                                         'bytes':p.stat().st_size} for p in files}
archive = root/'evidence/rx-startup-observer-dev-1701.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as contents:
    for path in files:
        assert not path.is_symlink()
        contents.write(path,path.relative_to(base).as_posix())
    contents.writestr('member-hashes.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as contents:
    assert contents.testzip() is None
    assert set(contents.namelist())==set(members)|{'member-hashes.json'}
    for name,entry in members.items():
        raw=contents.read(name)
        assert len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256']
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
with archive.with_suffix('.sha256').open('x',encoding='ascii') as stream:
    stream.write(digest+'  '+archive.name+'\n')
record={'sha256':digest,'members':len(members)+1,'bytes':archive.stat().st_size,
        'all_member_hashes_and_crc_verified':True,'observed_packets':8,'affected_passed':167,
        'source_clock_arrival_fusion_training_qualified':False}
with (base/'seal.json').open('x') as stream:
    json.dump(record,stream,indent=2)
print(json.dumps(record,indent=2))
