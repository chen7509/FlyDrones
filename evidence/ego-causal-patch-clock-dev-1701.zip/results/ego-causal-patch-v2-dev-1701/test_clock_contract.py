"""Static candidate gate pending a real Humble ROS build and parity run."""

from pathlib import Path

STAGE = Path(__file__).resolve().parent


def test_map_completion_records_node_clock_after_map_mutation() -> None:
    source = (STAGE / "overlay/grid_map.cpp").read_text(encoding="utf-8")
    callback = source.split("void GridMap::updateOccupancyCallback()", 1)[1].split(
        "void GridMap::depthPoseCallback", 1)[0]
    assert callback.index("clearAndInflateLocalMap();") < callback.index(
        '"map_apply_node_ns"')
    assert '"map_apply_node_ns", fly_ego_diag::decimal(node_->now().nanoseconds())' in callback


def test_successful_plan_records_node_clock_after_publish() -> None:
    source = (STAGE / "overlay/ego_replan_fsm.cpp").read_text(encoding="utf-8")
    callback = source.split("bool EGOReplanFSM::callReboundReplan", 1)[1]
    assert callback.index("bspline_pub_->publish(bspline);") < callback.index(
        '"plan_publish_node_ns"')
    assert '"plan_publish_node_ns", fly_ego_diag::decimal(node_->now().nanoseconds())' in callback


def test_writer_adds_positive_steady_clock_to_every_event() -> None:
    source = (STAGE / "overlay/causal_trace.cpp").read_text(encoding="utf-8")
    assert "event_steady_ns" in source
    assert "std::chrono::steady_clock::now()" in source
