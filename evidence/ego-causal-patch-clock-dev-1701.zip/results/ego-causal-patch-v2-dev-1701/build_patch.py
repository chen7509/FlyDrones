"""Produce a byte-pinned, development-only EGO diagnostic patch."""

import difflib
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).resolve().parent
OUT = ROOT / "tools/benchmark/ego_causal_readonly_v2.patch"

FILES = {
    "plan_env.CMakeLists.txt": (
        "src/planner/plan_env/CMakeLists.txt", "d44d0b461078f8cdca2b9f9ce9c45b141e88be62"),
    "plan_env.package.xml": (
        "src/planner/plan_env/package.xml", "c9894c7effb98e272157d48c8bb2982831a5ef3c"),
    "grid_map.h": (
        "src/planner/plan_env/include/plan_env/grid_map.h", "cd238a41db291c0e70e19d4cd9a34ed6031fd74e"),
    "grid_map.cpp": (
        "src/planner/plan_env/src/grid_map.cpp", "0714c57e976fcefcad7fd058c842c12fd2955aec"),
    "plan_manage.CMakeLists.txt": (
        "src/planner/plan_manage/CMakeLists.txt", "f90cbfd089fbf104dffff6172607ae0fd8bc35e3"),
    "ego_replan_fsm.h": (
        "src/planner/plan_manage/include/ego_planner/ego_replan_fsm.h",
        "ed914627d3722474c8d9e884a9ace0384b426035"),
    "ego_replan_fsm.cpp": (
        "src/planner/plan_manage/src/ego_replan_fsm.cpp", "78d5eee7e504fa3425e71404e40d207a3bb9011b"),
    "traj_server.cpp": (
        "src/planner/plan_manage/src/traj_server.cpp", "a32026d49de945c502b372e39301078eea58fbeb"),
}
NEW_FILES = {
    "causal_trace.h": "src/planner/plan_env/include/plan_env/causal_trace.h",
    "causal_trace.cpp": "src/planner/plan_env/src/causal_trace.cpp",
}


def git_blob_sha1(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def main() -> None:
    patch_chunks = []
    manifest = {"upstream_commit": "23a8d5a191711dd65633df689bd00f55d4dea8f9",
                "predecessor_patch_sha256":
                "cb09eb97ede4d79a90b2ddef5ed8e6448a7ec67b11f037c18d8d490bbbd9f5b6",
                "files": {}, "patched_ros_build_verified": False,
                "node_clock_sim_time_verified": False,
                "trajectory_numerical_parity_verified": False,
                "teacher_qualified": False}
    for name, (path, expected_blob) in FILES.items():
        before_bytes = (STAGE / "upstream" / name).read_bytes()
        after_bytes = (STAGE / "overlay" / name).read_bytes()
        if git_blob_sha1(before_bytes) != expected_blob:
            raise ValueError(f"upstream blob changed: {path}")
        if before_bytes != after_bytes:
            before_path = (STAGE / "upstream" / name).as_posix().replace("C:/", "/mnt/c/")
            after_path = (STAGE / "overlay" / name).as_posix().replace("C:/", "/mnt/c/")
            result = subprocess.run(
                ["wsl", "--exec", "bash", "-lc",
                 f"cd /tmp && git diff --no-index -- '{before_path}' '{after_path}'"],
                capture_output=True, check=False)
            if result.returncode != 1:
                raise ValueError(f"expected one-file diff for {path}: {result.returncode}")
            chunk = result.stdout.decode("utf-8")
            chunk = chunk.replace(before_path.removeprefix("/"), path)
            chunk = chunk.replace(after_path.removeprefix("/"), path)
            patch_chunks.append(chunk)
        manifest["files"][path] = {
            "before_git_blob_sha1": expected_blob,
            "before_sha256": hashlib.sha256(before_bytes).hexdigest(),
            "after_sha256": hashlib.sha256(after_bytes).hexdigest(),
        }
    for name, path in NEW_FILES.items():
        new_bytes = (STAGE / "overlay" / name).read_bytes()
        patch_chunks.extend(difflib.unified_diff([], new_bytes.decode("utf-8").splitlines(
            keepends=True), fromfile="/dev/null", tofile=f"b/{path}", n=4))
        manifest["files"][path] = {"before_git_blob_sha1": None,
                                    "after_sha256": hashlib.sha256(new_bytes).hexdigest()}
    patch = "".join(patch_chunks)
    if not patch:
        raise ValueError("patch missing")
    OUT.write_text(patch, encoding="utf-8", newline="\n")
    manifest["patch_sha256"] = hashlib.sha256(OUT.read_bytes()).hexdigest()
    (STAGE / "patch-manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"files": len(manifest["files"]), "patch_sha256": manifest["patch_sha256"],
                      "patched_ros_build_verified": False}, sort_keys=True))


if __name__ == "__main__":
    main()
