"""Seal static, uncompiled EGO diagnostic clock candidate v2."""

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).resolve().parent
OUT = ROOT / "evidence/ego-causal-patch-clock-dev-1701.zip"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    assert not OUT.exists(), "sealed evidence cannot be overwritten"
    pinned = json.loads((STAGE / "patch-manifest.json").read_text(encoding="utf-8"))
    patch = ROOT / "tools/benchmark/ego_causal_readonly_v2.patch"
    assert sha256(patch.read_bytes()) == pinned["patch_sha256"]
    assert pinned["predecessor_patch_sha256"] == sha256(
        (ROOT / "tools/benchmark/ego_causal_readonly.patch").read_bytes())
    assert pinned["patched_ros_build_verified"] is False
    assert pinned["node_clock_sim_time_verified"] is False
    assert pinned["trajectory_numerical_parity_verified"] is False
    assert pinned["teacher_qualified"] is False
    paths = [
        patch,
        ROOT / "docs/EGO_CAUSAL_PATCH_CLOCK_REPORT.md",
        ROOT / "docs/superpowers/specs/2026-10-10-ego-causal-provenance-design.md",
        ROOT / "docs/superpowers/plans/2026-10-10-ego-causal-provenance.md",
        STAGE / "patch-manifest.json",
        STAGE / "build_patch.py",
        STAGE / "verify_patch_apply.sh",
        STAGE / "static-apply.txt",
        STAGE / "test_clock_contract.py",
        STAGE / "static-tests.txt",
        STAGE / "causal_trace_core_test.cpp",
        STAGE / "shared_client.cpp",
        STAGE / "writer_a.cpp",
        STAGE / "writer_b.cpp",
        STAGE / "run_native_tests.sh",
        Path(__file__),
    ]
    paths += sorted(path for folder in ("upstream", "overlay") for path in
                    (STAGE / folder).iterdir() if path.is_file())
    assert len(paths) == len(set(paths))
    members = {}
    for path in paths:
        assert path.is_file(), path
        data = path.read_bytes()
        members[path.relative_to(ROOT).as_posix()] = {
            "sha256": sha256(data), "size": len(data)}
    manifest = {
        "schema": 1, "stage": "ego-causal-clock-v2-static-only",
        "members": members, "native_writer_verified": False,
        "patched_ros_build_verified": False,
        "node_clock_sim_time_verified": False,
        "trajectory_numerical_parity_verified": False,
        "teacher_qualified": False,
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(OUT, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in paths:
            archive.write(path, path.relative_to(ROOT).as_posix())
        archive.writestr("manifest.json", json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    with zipfile.ZipFile(OUT) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == set(members) | {"manifest.json"}
        for name, identity in members.items():
            data = archive.read(name)
            assert len(data) == identity["size"] and sha256(data) == identity["sha256"]
    print(json.dumps({"members": len(members) + 1, "sha256": sha256(OUT.read_bytes()),
                      "path": str(OUT)}, sort_keys=True))


if __name__ == "__main__":
    main()
