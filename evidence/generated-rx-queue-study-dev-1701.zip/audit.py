"""Audit fixed failed RX study; never repeats a socket trial."""
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).parent
STUDY = BASE / "study-v1"


def read(name):
    return json.loads((STUDY / name).read_text())


before, after, frozen = read("inputs-before.json"), read("inputs-after.json"), read("frozen-inputs-after.json")
assert before == after == frozen
for name, digest in before.items():
    assert hashlib.sha256((STUDY / "inputs" / name).read_bytes()).hexdigest() == digest
dispatch, completion = read("dispatch.json"), read("completion.json")
assert hashlib.sha256((STUDY / "study-profile.json").read_bytes()).hexdigest() == dispatch["profile_sha256"]
assert completion["profile_stable"] and completion["selected_inputs_stable"]
assert not completion["cache_directory_created"]
assert "-I" in dispatch["command"] and "-B" in dispatch["command"]
result = read("capture-v1/result.json")
assert result["status"] == "failed" and completion["exit_code"] == 1
assert result["profile_post_verified"]
sent, events = result["normal"]["sent"], result["normal"]["events"]
assert len(sent) == 3 and all(item["send_returned"] and item["bytes"] == 55 for item in sent)
returns = [event for event in events if event["kind"] == "receive_return"]
assert len(returns) == 1 and returns[0]["data_hex"] == sent[0]["payload_hex"]
assert returns[0]["flags"] == 0 and returns[0]["data_length"] == 55
assert returns[0]["ancillary_count"] == 0 and returns[0]["ancillary_raw"] == []
assert result["normal"]["receiver_evidence"]["datagram_returns"] == 1
assert result["normal"]["received"] == []  # parser refused before an accepted packet could return
assert not result["option_drift"]["executed"] and not result["option_drift"]["refused"]
assert len(result["owned_close"]) == 2 and {item["fd"] for item in result["owned_close"]} == {3, 4}
assert all(item["fileno_after"] == -1 and item["fstat_errno"] == 9 and not item["close_error"]
           for item in result["owned_close"])
for name, actual in result["module_origins"].items():
    assert Path(actual).as_posix().endswith("/study-v1/inputs/" + name)
supervisor = read("supervisor.json")
journal = [json.loads(line) for line in (STUDY / "supervisor-events.jsonl").read_text().splitlines()]
cleanup = supervisor["cleanup"]
assert journal == cleanup["events"] == completion["cleanup"]["events"]
assert len(journal) == 7 and not any(event["event"].startswith("signal_") for event in journal)
assert supervisor["status"] == "worker_exited" and supervisor["worker_exit"] == 1 and not supervisor["errors"]
assert cleanup["group_absent"] and cleanup["no_executing_members"] and cleanup["graceful_group_cleanup_verified"]
assert not cleanup["sigkill_dispatched"] and not cleanup["all_descendant_cleanup_qualified"]
owner = cleanup["owner"]
assert owner["pid"] == owner["pgrp"] == owner["session"] == completion["child_pid"]
assert owner["start_ticks"] > 0
for flag in ("source_authenticated", "kernel_receive_instant_qualified", "clock_mapping_qualified",
             "fusion_qualified", "training_eligible", "px4_ros_physics_or_training_started"):
    assert result[flag] is False
audit = {"actual_trial_status": "failed", "scope": "generated RX owned loopback only",
         "source_hashes_verified": len(before), "actual_frozen_module_origins": len(result["module_origins"]),
         "sent_payloads": 3, "actual_recvmsg_returns": 1, "accepted_packets": 0,
         "first_actual_payload_exact": True, "ancillary_count": 0,
         "unconsumed_sent_payloads_at_close": 2, "option_drift_executed": False,
         "delay_ns": result["normal"]["delay_end_ns"] - result["normal"]["delay_start_ns"],
         "worker_elapsed_wall_ns": result["elapsed_wall_ns"], "dispatch_elapsed_wall_ns": completion["elapsed_wall_ns"],
         "profile_sha256": dispatch["profile_sha256"], "owned_FD_close_verified": True,
         "owned_group_owner": owner, "group_absent": True, "no_executing_members": True,
         "supervisor_signal_events": 0, "supervisor_disk_memory_events_equal": True,
         "all_descendant_cleanup_qualified": False, "arrival_source_clock_fusion_training_qualified": False,
         "native_causality_proven": False, "trial_repeated": False}
with (BASE / "audit-v1.json").open("x") as stream:
    json.dump(audit, stream, indent=2)
print(json.dumps(audit, indent=2))
