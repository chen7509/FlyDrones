"""Read-only installed config availability, never probes network readiness."""
import gzip
import hashlib
import json
import platform
from pathlib import Path

OUT = Path(__file__).parent / "kernel-context-v1.json"
record = {"kernel": platform.release(), "config_available": False,
          "runtime_causality_proven": False, "network_or_probe_started": False, "observations": []}
for path in [Path("/proc/config.gz"), Path("/boot/config-" + platform.release())]:
    try:
        raw = path.read_bytes()
        if len(raw) > 4_000_000:
            raise ValueError("kernel config exceeds read-only bound")
        text = (gzip.decompress(raw) if path.suffix == ".gz" else raw).decode()
        if len(text) > 4_000_000:
            raise ValueError("kernel config exceeds decode bound")
        selected = [line for line in text.splitlines() if "CONFIG_JUMP_LABEL" in line or "CONFIG_NET_TIMESTAMP" in line]
        record["observations"].append({"path": str(path), "sha256": hashlib.sha256(raw).hexdigest(), "selected": selected})
        record["config_available"] = True
        break
    except (OSError, ValueError) as exc:
        record["observations"].append({"path": str(path), "error": type(exc).__name__ + ": " + str(exc)})
with OUT.open("x") as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record))
