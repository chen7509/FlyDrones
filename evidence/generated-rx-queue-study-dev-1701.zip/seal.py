import hashlib
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).parent
verified = json.loads((BASE / "final-v1/execution.json").read_text())
assert verified["selected_source_unchanged"] and all(item["exit_code"] == 0 for item in verified["commands"])
for name, expected in verified["source_after"].items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected
audit = json.loads((BASE / "audit-v1.json").read_text())
assert audit["actual_trial_status"] == "failed" and not audit["arrival_source_clock_fusion_training_qualified"]
assert audit["source_hashes_verified"] == 16 and audit["actual_frozen_module_origins"] == 9
assert audit["ancillary_count"] == 0 and not audit["option_drift_executed"]
for name in ["docs/GENERATED_RX_QUEUE_STUDY_REPORT.md",
             "docs/superpowers/specs/2026-10-12-rx-generated-queue-study-design.md",
             "docs/superpowers/plans/2026-10-12-rx-generated-queue-study.md"]:
    target = BASE / "documents" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / name, target)
references = {}
for name, expected in [
    ("evidence/kernel-datagram-arrival-dev-1701.zip", "e2f6e7a2052a15f78aad6a6d15faaee0fa459880504752744543cd4c1f378325"),
    ("evidence/kernel-rx-timestamping-dev-1701.zip", "a6465dfc0a74a65031c5847208706b6dd3c316410e8087249714924e4e90b537")]:
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected
    references[name] = {"sha256": expected, "rerun": False, "reference_only": True}
with (BASE / "prior-stage-references.json").open("x") as stream:
    json.dump(references, stream, indent=2)
files = sorted(path for path in BASE.rglob("*") if path.is_file() and path.suffix != ".pyc")
members = {str(path.relative_to(BASE)).replace("\\", "/"): {
    "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size} for path in files}
target = ROOT / "evidence/generated-rx-queue-study-dev-1701.zip"
with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED) as archive:
    for path in files:
        archive.write(path, str(path.relative_to(BASE)).replace("\\", "/"))
    archive.writestr("member-hashes.json", json.dumps(members, indent=2))
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(members) | {"member-hashes.json"}
    for name, expected in members.items():
        raw = archive.read(name)
        assert hashlib.sha256(raw).hexdigest() == expected["sha256"] and len(raw) == expected["bytes"]
digest = hashlib.sha256(target.read_bytes()).hexdigest()
with target.with_suffix(".sha256").open("x", encoding="ascii") as stream:
    stream.write(digest + "  " + target.name + "\n")
record = {"sha256": digest, "members": len(members) + 1, "bytes": target.stat().st_size,
          "all_member_hashes_and_crc_verified": True, "trial_status": "failed",
          "original_owned_group_cleanup_qualified": True,
          "arrival_source_clock_fusion_training_qualified": False}
with (BASE / "seal.json").open("x") as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record, indent=2))
