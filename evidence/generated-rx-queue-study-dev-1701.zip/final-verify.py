import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).parent
OUT = BASE / "final-v1"
OUT.mkdir()
sources = ["tools/benchmark/probe_kernel_rx_timestamping.py", "tests/benchmark/test_generated_rx_queue_study.py", "tests/fixtures/kernel_timestampns/rx-generated-x86_64.json","tools/benchmark/kernel_rx_timestamping.py", "tools/benchmark/kernel_rx_timestamping_abi.c", "tests/benchmark/test_kernel_rx_timestamping.py","tools/benchmark/kernel_datagram_arrival.py", "tools/benchmark/kernel_timestamp_abi.c",
           "tools/benchmark/openvins_datagram_receive.py", "tools/benchmark/probe_kernel_datagram_arrival.py",
           "tools/benchmark/owned_daemon_connection.py",
           "tests/benchmark/test_kernel_datagram_arrival.py", "tests/benchmark/test_kernel_arrival_study_profile.py",
           "tests/fixtures/kernel_timestampns/new-abi-x86_64.json"]


def hashes():
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in sources}


before = hashes()
for name in sources:
    target = OUT / "sources" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / name, target)
    assert hashlib.sha256(target.read_bytes()).hexdigest() == before[name]
env = {**os.environ, "PYTHONPATH": str(ROOT / "src") + os.pathsep + str(ROOT)}
tests = ["tests/benchmark/" + name for name in ["test_generated_rx_queue_study.py","test_kernel_rx_timestamping.py","test_kernel_datagram_arrival.py", "test_kernel_arrival_study_profile.py",
         "test_openvins_datagram_receive.py", "test_openvins_segmented_receive.py", "test_openvins_segmented_journal.py",
         "test_openvins_observed_wire_session.py", "test_openvins_receiver_parity.py"]]
commands = [[sys.executable, "-m", "pytest", *tests, "-q"],
            [sys.executable, "-m", "ruff", "check", *[name for name in sources if name.endswith(".py")]],
            ["git", "diff", "--check"]]
observations = []
for index, command in enumerate(commands):
    result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, timeout=60)
    (OUT / f"command-{index}.stdout").write_bytes(result.stdout)
    (OUT / f"command-{index}.stderr").write_bytes(result.stderr)
    observations.append({"argv": command, "exit_code": result.returncode})
after = hashes()
record = {"commands": observations, "source_before": before, "source_after": after,
          "selected_source_unchanged": before == after, "full_repository_tests_run": False,
          "actual_socket_or_estimator_rerun": False}
with (OUT / "execution.json").open("x") as stream:
    json.dump(record, stream, indent=2)
if before != after or any(row["exit_code"] for row in observations):
    raise RuntimeError("final verification refused")
print((OUT / "command-0.stdout").read_text())
