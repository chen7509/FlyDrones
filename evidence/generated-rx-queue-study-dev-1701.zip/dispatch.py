"""One frozen-copy owned loopback trial; no build or source process."""
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import tools.benchmark.probe_kernel_rx_timestamping as study  # noqa: E402
from tools.benchmark.owned_group_evidence import GroupEvidence, finish_owned_worker  # noqa: E402

OUT = Path(__file__).parent / "study-v1"


def write(name, value):
    with (OUT / name).open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


def sha(path):
    return hashlib.sha256(study.read_static(path)).hexdigest()


study.check_module_origins()
OUT.mkdir()
inputs = OUT / "inputs"
selected = [*study.SOURCES, study.ABI_PATH, study.PROBE_PATH,
            "tests/benchmark/test_generated_rx_queue_study.py",
            "tests/fixtures/kernel_timestampns/rx-generated-x86_64.json",
            "docs/superpowers/specs/2026-10-12-rx-generated-queue-study-design.md",
            "docs/superpowers/plans/2026-10-12-rx-generated-queue-study.md"]
before = {name: sha(ROOT / name) for name in selected}
for name in selected:
    target = inputs / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / name, target)
    assert sha(target) == before[name]
write("inputs-before.json", before)
profile = {**study.CONDITIONS, "sources": {name: before[name] for name in study.SOURCES},
           "abi_sha256": study.ABI_SHA, "probe_sha256": study.PROBE_SHA}
write("study-profile.json", profile)
path = OUT / "study-profile.json"
digest = sha(path)
study.validate_profile(path.read_bytes(), digest, inputs)
cache = OUT / "uncreated-cache-prefix"
assert not cache.exists()
command = ["/usr/bin/timeout", "--kill-after=2s", "20s", "/usr/bin/python3", "-I", "-B", "-X",
           "pycache_prefix=" + str(cache), str(inputs / study.SOURCES[0]), "--profile", str(path),
           "--profile-sha256", digest, "--output", str(OUT / "capture-v1")]
env = {"PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C"}
write("dispatch.json", {"command": command, "environment": env, "profile_sha256": digest,
                        "realtime_ns": time.time_ns(), "python": sys.version, "kernel": platform.release(),
                        "dispatcher_pid": os.getpid(), "dispatcher_sha256": sha(Path(__file__)),
                        "fresh_cache_prefix": str(cache), "frozen_entry": True,
                        "runtime_closure_qualified": False, "resource_scope": "small owned opaque local UDP only"})
started = time.monotonic_ns()
with (OUT / "stdout.txt").open("xb") as stdout, (OUT / "stderr.txt").open("xb") as stderr, \
        (OUT / "supervisor-events.jsonl").open("x") as events:
    child = subprocess.Popen(command, cwd=OUT, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
    evidence = GroupEvidence(child, events)
    supervisor = finish_owned_worker(child, evidence, 25)
    code = supervisor["worker_exit"]
write("supervisor.json", supervisor)
after = {name: sha(ROOT / name) for name in selected}
copied = {name: sha(inputs / name) for name in selected}
write("inputs-after.json", after)
write("frozen-inputs-after.json", copied)
write("completion.json", {"exit_code": code, "child_pid": child.pid,
                          "elapsed_wall_ns": time.monotonic_ns() - started,
                          "supervisor_status": supervisor["status"],
                          "supervisor_errors": supervisor["errors"],
                          "cleanup": supervisor["cleanup"],
                          "selected_inputs_stable": before == after == copied,
                          "profile_stable": digest == sha(path), "cache_directory_created": cache.exists(),
                          "full_runtime_closure_qualified": False, "all_descendant_cleanup_qualified": False})
if (code != 0 or supervisor["status"] != "worker_exited" or supervisor["errors"]
        or not supervisor["cleanup"]["graceful_group_cleanup_verified"]
        or before != after or copied != before or digest != sha(path)):
    raise RuntimeError("single generated RX attempt failed; no retry")
print((OUT / "stdout.txt").read_text())
