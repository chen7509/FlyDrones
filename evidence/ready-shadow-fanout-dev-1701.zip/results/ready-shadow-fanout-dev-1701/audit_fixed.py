import json,hashlib,zipfile
from pathlib import Path
b=Path(__file__).resolve().parent; root=b.parents[1]; p=b/'fixed-v1'
r=json.loads((p/'result.json').read_text()); records=[json.loads(x) for x in (p/'source-fanout.jsonl').read_text().splitlines()]
assert r['source_rows']==r['fanout']['committed']==7028 and r['fanout']['failure'] is None and r['fanout']['skipped']==0
assert len(records)==14056 and r['estimator_run'] is False and r['online_latency_measured'] is False
archive=root/'evidence/native-reference-probe-dev-1701.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==r['archive_sha256']
with zipfile.ZipFile(archive) as z:
 for ref in r['consumed_members']:
  data=z.read(ref['member']);assert len(data)==ref['bytes'] and hashlib.sha256(data).hexdigest()==ref['sha256']
 source=[json.loads(x) for x in z.read('results/native-reference-probe-dev-1701/capture-v1/events.jsonl').splitlines()]
 for i,row in enumerate(source):
  expected=hashlib.sha256(json.dumps(dict(row,source_sequence=i),sort_keys=True,allow_nan=False).encode()).hexdigest()
  intent,terminal=records[2*i:2*i+2]
  assert intent['event']=='source_intent' and terminal['event']=='source_delivery'
  assert intent['source_sequence']==terminal['source_sequence']==i
  assert intent['source_sha256']==terminal['source_sha256']==expected
  assert terminal['dispositions']=={'shadow':'returned','readiness':'returned'}
  assert terminal['consumers']['shadow']['returned_ns']<=terminal['consumers']['readiness']['start_ns']<=terminal['end_ns']
packets=[json.loads(x) for x in (p/'packet-sink.jsonl').read_text().splitlines()]
assert len(packets)==6501 and [x['sequence'] for x in packets]==list(range(6501))
assert r['shadow']['delivered']==6501 and r['shadow']['inputs_accepted']==6753 and r['shadow']['failure'] is None
assert len(r['shadow']['pending'])==1 and r['shadow']['pending'][0]['reason']=='later_imu_missing'
out=dict(source_rows=7028,receipt_rows=14056,source_identity_verified=True,all_consumed_member_hashes_verified=True,recording_only_packets=6501,source_archive_sha256=r['archive_sha256'],estimator_run=False,online_latency_measured=False,fusion_eligible=False)
with (b/'fixed-audit.json').open('x') as f:json.dump(out,f,indent=2)
print(json.dumps(out))
