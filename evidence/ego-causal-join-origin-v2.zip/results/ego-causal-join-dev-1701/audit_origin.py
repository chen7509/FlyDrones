"""Bound the first-plan versus replan start-state finding to fixed upstream bytes."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
UPSTREAM = ROOT / "results/ego-causal-provenance-dev-1701"
SOURCE = UPSTREAM / "source/ego_replan_fsm.cpp"
MANIFEST = UPSTREAM / "source-manifest.json"
OUT = Path(__file__).with_name("origin-source-audit.json")


def main() -> None:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    data = SOURCE.read_bytes()
    if hashlib.sha256(data).hexdigest() != manifest["files"]["ego_replan_fsm.cpp"]["sha256"]:
        raise ValueError("fixed FSM source changed")
    lines = data.decode("utf-8").splitlines()
    first = "\n".join(lines[642:645])
    replan = "\n".join(lines[671:674])
    for phrase in ("start_pt_ = odom_pos_", "start_vel_ = odom_vel_", "start_acc_.setZero()"):
        if phrase not in first:
            raise ValueError("first-plan origin anchor changed")
    for phrase in ("start_pt_ = info->position_traj_", "start_vel_ = info->velocity_traj_",
                   "start_acc_ = info->acceleration_traj_"):
        if phrase not in replan:
            raise ValueError("replan origin anchor changed")
    result = {
        "source_commit": manifest["commit"],
        "source_sha256": manifest["files"]["ego_replan_fsm.cpp"]["sha256"],
        "first_plan_lines": [643, 645],
        "replan_lines": [672, 674],
        "first_plan_start_state_origin": "odometry",
        "replan_start_state_origin": "previous_trajectory",
        "runtime_instrumentation_verified": False,
        "teacher_qualified": False,
    }
    OUT.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
