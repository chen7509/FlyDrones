"""Seal the replan-start-state correction without replacing v1 evidence."""

import hashlib
import json
import zipfile
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
STAGE = "results/ego-causal-join-dev-1701"
OUT = ROOT / "evidence/ego-causal-join-origin-v2.zip"
PRIOR_SHA256 = "0c6135f969587787973d8ae98a2f82c506338cb958c1607018a29c55377ce706"
FILES = [
    "src/flydrones/benchmark/ego_causal_join.py",
    "tests/benchmark/test_ego_causal_join.py",
    "docs/EGO_CAUSAL_JOIN_CONTRACT_REPORT.md",
    "docs/superpowers/specs/2026-10-10-ego-causal-provenance-design.md",
    "docs/superpowers/plans/2026-10-10-ego-causal-provenance.md",
    *[f"{STAGE}/{name}" for name in (
        "audit_origin.py", "origin-source-audit.json", "origin-audit-output.txt",
        "red-start-origin.txt", "green-start-origin.txt", "adjacent-tests-v2.txt",
        "ruff-v2.txt", "diff-v2.txt", "seal_v2.py")],
]


def main() -> None:
    if OUT.exists():
        raise FileExistsError(OUT)
    prior = ROOT / "evidence/ego-causal-join-dev-1701.zip"
    if hashlib.sha256(prior.read_bytes()).hexdigest() != PRIOR_SHA256:
        raise ValueError("v1 evidence changed")
    entries = {}
    with zipfile.ZipFile(OUT, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for relative in FILES:
            data = (ROOT / relative).read_bytes()
            archive.writestr(relative, data)
            entries[relative] = {
                "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
                "crc32": format(zlib.crc32(data) & 0xFFFFFFFF, "08x"),
            }
        archive.writestr("MANIFEST.json", json.dumps({
            "prior_archive_sha256": PRIOR_SHA256, "members": entries,
        }, indent=2, sort_keys=True))
    with zipfile.ZipFile(OUT) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == set(FILES) | {"MANIFEST.json"}
        for relative, expected in entries.items():
            data = archive.read(relative)
            assert len(data) == expected["bytes"]
            assert hashlib.sha256(data).hexdigest() == expected["sha256"]
            assert format(zlib.crc32(data) & 0xFFFFFFFF, "08x") == expected["crc32"]
    print(json.dumps({"zip": str(OUT), "members": len(entries) + 1,
                      "sha256": hashlib.sha256(OUT.read_bytes()).hexdigest()}, sort_keys=True))


if __name__ == "__main__":
    main()
