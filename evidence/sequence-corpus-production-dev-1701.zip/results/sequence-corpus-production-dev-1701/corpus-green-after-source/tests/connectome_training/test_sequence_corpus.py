import gc
import weakref

import pytest
from test_learning_roles import config as _base_config
from test_learning_roles import inert_backends as _base_inert
from test_learning_roles import session

from flydrones.connectome_training import curriculum_session as sessions
from flydrones.connectome_training.dataset import write_sequence
from flydrones.connectome_training.trainer import train_epoch

config = _base_config
inert_backends = _base_inert


def files(config,tmp_path):
    for index in range(3):
        write_sequence(tmp_path/str(index),sessions._synthetic_sequence(config.stages[0],'train',1101+index))
    return tmp_path


def test_actual_directory_catalog_retains_no_decoded_sequence(config,tmp_path,monkeypatch):
    folder=files(config,tmp_path)
    original=sessions.load_sequence
    refs=[]
    def observed(path):
        value=original(path)
        refs.append(weakref.ref(value))
        return value
    monkeypatch.setattr(sessions,'load_sequence',observed)
    corpus=sessions._sequence_directories((str(folder),))
    gc.collect()
    assert len(refs)==3
    assert not any(r() is not None for r in refs)
    assert not isinstance(corpus,list)


def test_rehearsal_is_reiterable_without_materializing_all_sequences(config,monkeypatch):
    current=session(config,'shared-dynamics-v1')
    refs=[]
    class Corpus:
        frame_count=24
        def __iter__(self):
            for i in range(3):
                value=sessions._synthetic_sequence(config.stages[0],'train',1101+i)
                refs.append(weakref.ref(value))
                yield value
                del value
    current.datasets[config.stages[0].id]=(Corpus(),current.datasets[config.stages[0].id][1])
    counts=[]
    def train(model,sequences,*a,**k):
        count=0
        for sequence in sequences:
            assert sum(r() is not None for r in refs)<=1
            assert len(sequence.frames)==8
            count+=1
            del sequence
        counts.append(count)
        return {'total':1}
    monkeypatch.setattr(sessions,'train_epoch',train)
    result=current.train_batch(config.stages[0],1101)
    assert counts==[3]*config.stages[0].epochs_per_batch
    assert result['environment_steps']==24*config.stages[0].epochs_per_batch


def test_actual_trainer_releases_sequence_before_requesting_next(config):
    current=session(config,'shared-dynamics-v1')
    refs=[]
    def stream():
        for index in range(2):
            gc.collect()
            assert not any(r() is not None for r in refs)
            value=sessions._synthetic_sequence(config.stages[0],'train',1101+index)
            refs.append(weakref.ref(value))
            yield value
            del value
    train_epoch(current.model,stream(),current.optimizer,current.truncate_steps)
