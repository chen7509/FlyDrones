import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path.cwd();RAW=Path(__file__).resolve().parent
SOURCES=['src/flydrones/connectome_training/sequence_corpus.py','src/flydrones/connectome_training/curriculum_session.py','src/flydrones/connectome_training/inference_artifact.py','src/flydrones/connectome_training/inference.py','tools/connectome_training/run_curriculum.py','src/flydrones/connectome_training/model.py','src/flydrones/connectome_training/trainer.py','src/flydrones/connectome_training/checkpoint.py','src/flydrones/connectome_training/features.py','src/flydrones/connectome_training/dataset.py','src/flydrones/connectome_training/curriculum.py','tests/connectome_training/test_sequence_corpus.py','tests/connectome_training/test_inference_artifact.py','tests/connectome_training/test_inference.py','tests/connectome_training/test_curriculum_state.py','tests/connectome_training/test_curriculum.py','tests/connectome_training/conftest.py','tools/benchmark/software_process_boundary.py',Path(__file__).relative_to(ROOT).as_posix()]
SOURCES.append('results/sequence-corpus-production-dev-1701/inert_test_plugin.py')
SOURCES.append('tests/connectome_training/test_learning_roles.py')
def pins(label):
 rows=[]
 for name in SOURCES:
  p=ROOT/name
  if not p.exists():rows.append(dict(path=name,absent=True));continue
  b=p.read_bytes();rows.append(dict(path=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()));dest=RAW/(label+'-source')/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 return rows
def save(n,v):
 with (RAW/n).open('xb') as f:f.write(json.dumps(v,indent=2).encode())
label=sys.argv[1];args=sys.argv[2:];env=dict(os.environ);env['PYTHONPATH']=str(ROOT/'src')+os.pathsep+str(ROOT)
start=dict(argv=args,cwd=str(ROOT),source_before=pins(label),recorder_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),environment={k:env.get(k) for k in ('PYTHONPATH','PATH','PYTHONHOME','VIRTUAL_ENV')},started_monotonic_ns=time.monotonic_ns(),scope='tinyCPU software only;new tests inert process/CUDA sampling;no fullMaleCNS/targetSDK/resource snapshot')
save(label+'-start.json',start)
try:p=subprocess.run(args,cwd=ROOT,env=env,capture_output=True,timeout=120);out,err,code,exception=p.stdout,p.stderr,p.returncode,None
except subprocess.TimeoutExpired as exc:out,err,code,exception=exc.stdout or b'',exc.stderr or b'',None,repr(exc)
for ext,b in [('stdout',out),('stderr',err)]:
 with (RAW/(label+'.'+ext)).open('xb') as f:f.write(b)
save(label+'.json',dict(**start,exit=code,exception=exception,ended_monotonic_ns=time.monotonic_ns(),source_after=pins(label+'-after'),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest()))
print(json.dumps(dict(label=label,exit=code,exception=exception,stdout=out.decode(errors='replace')[-13000:],stderr=err.decode(errors='replace')[-3000:])));sys.exit(0 if code==0 else 1)
