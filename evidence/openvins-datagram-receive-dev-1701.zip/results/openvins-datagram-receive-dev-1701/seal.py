"""Exclusive archive and verification; does not execute network or child code."""
import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[2]
study = Path(__file__).resolve().parent
archive = root / 'evidence/openvins-datagram-receive-dev-1701.zip'
paths = [p for p in study.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
paths += [root / p for p in (
    'tools/benchmark/openvins_datagram_receive.py',
    'tools/benchmark/owned_daemon_connection.py',
    'tests/benchmark/test_openvins_datagram_receive.py',
    'docs/OPENVINS_DATAGRAM_RECEIVE_REPORT.md',
    'docs/superpowers/specs/2026-10-08-datagram-receive-boundary-design.md',
    'docs/superpowers/plans/2026-10-08-datagram-receive-boundary.md',
)]
payload = {p.relative_to(root).as_posix(): p.read_bytes() for p in sorted(set(paths))}
manifest = {name: {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)} for name, raw in payload.items()}
payload['payload-manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, raw in payload.items():
        z.writestr(name, raw)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(set(z.namelist())) == len(manifest) + 1
    for name, expected in manifest.items():
        raw = z.read(name)
        assert len(raw) == expected['bytes']
        assert hashlib.sha256(raw).hexdigest() == expected['sha256']
metadata = {'archive': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'members': len(payload), 'bytes': archive.stat().st_size, 'crc': True, 'member_hashes': True}
with (study / 'seal-result.json').open('x') as f:
    json.dump(metadata, f, indent=2)
print(json.dumps(metadata))
