import hashlib
import json
from pathlib import Path
import urllib.request

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent / 'sources'
out.mkdir(exist_ok=False)
urls = {
    'socket-v3.12.3.rst': 'https://raw.githubusercontent.com/python/cpython/v3.12.3/Doc/library/socket.rst',
    'LICENSE-v3.12.3': 'https://raw.githubusercontent.com/python/cpython/v3.12.3/LICENSE',
    'cpython-metadata.json': 'https://api.github.com/repos/python/cpython',
}
rows = []
for name, url in urls.items():
    record = {'name': name, 'url': url}
    try:
        request = urllib.request.Request(url, headers={'User-Agent': 'FlyDrones-readonly-research'})
        with urllib.request.urlopen(request, timeout=25) as response:
            raw = response.read(2_000_001)
        if len(raw) > 2_000_000:
            raise ValueError('source size limit')
        (out / name).write_bytes(raw)
        record.update(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    except Exception as exc:
        record['error'] = type(exc).__name__ + ': ' + str(exc)
    rows.append(record)
for name in ('mavlink_main.cpp', 'mavlink_receiver.cpp'):
    source = root / 'results/openvins-timesync-channel-dev-1701/upstream/src/modules/mavlink' / name
    raw = source.read_bytes()
    (out / name).write_bytes(raw)
    rows.append({'name': name, 'reused_source': str(source), 'pin': 'd6f12ad1c4f70ad3230afd7d86e971421e02fef4',
                 'url': 'https://github.com/PX4/PX4-Autopilot/blob/d6f12ad1c4f70ad3230afd7d86e971421e02fef4/src/modules/mavlink/' + name,
                 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                 'basis': 'previously retained upstream bytes, not a fresh installed equality check'})
with (out / 'manifest.json').open('x') as f:
    json.dump(rows, f, indent=2)
print(json.dumps(rows, indent=2))
