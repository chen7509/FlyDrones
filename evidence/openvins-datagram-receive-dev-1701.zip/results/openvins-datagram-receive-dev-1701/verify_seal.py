import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[2]
study = Path(__file__).resolve().parent
meta = json.loads((study / 'seal-result.json').read_text())
archive = Path(meta['archive'])
assert hashlib.sha256(archive.read_bytes()).hexdigest() == meta['sha256']
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    manifest = json.loads(z.read('payload-manifest.json'))
    assert len(z.namelist()) == len(set(z.namelist())) == len(manifest) + 1 == meta['members']
    for name, item in manifest.items():
        raw = z.read(name)
        assert hashlib.sha256(raw).hexdigest() == item['sha256'] and len(raw) == item['bytes']
    prefix = 'results/openvins-datagram-receive-dev-1701/'
    assert b'1 failed, 3235 passed, 5 skipped, 2 warnings' in z.read(prefix + 'full-pytest.txt')
    assert b'3236 passed, 5 skipped, 2 warnings' in z.read(prefix + 'full-pytest-confirmation.txt')
    assert b'41 passed' in z.read(prefix + 'targeted-final.txt')
    assert b'2 failed, 39 deselected' in z.read(prefix + 'review-nonblocking-red.txt')
    sources = json.loads(z.read(prefix + 'sources/manifest.json'))
    for item in sources:
        assert 'error' not in item
        assert hashlib.sha256(z.read(prefix + 'sources/' + item['name'])).hexdigest() == item['sha256']
previous = root / 'evidence/openvins-wire-bootstrap-dev-1701.zip'
assert hashlib.sha256(previous.read_bytes()).hexdigest() == 'a2a1e266044a1ff7ea5f6de5aadd6f8df683bebe828a23756a22a52611d5f8d6'
print('Archive/member hashes/CRC,41 targeted, failed first regression,3236-pass confirmation, sources and unchanged predecessor verified')
