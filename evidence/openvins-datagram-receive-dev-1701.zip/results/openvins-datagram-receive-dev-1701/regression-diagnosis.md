# Full-regression failure boundary

First full run:1failed3235passed5skipped2warnings,226.98s. Existing test_bound_resource_graph::test_real_byte_runner_limits_and_preserves_output failed while running an ordinary Python child that writes one0xff byte. bounded_run observed its original5s timeout and refused; timeout was not relaxed. No failure occurred in the new41test datagram suite.

The runner and test have zero diff from2dd89da. Git blob IDs observed are b22f58950f4cf7075896a4f3a21eadf062c30f68 (runner) and f39e32205c1c78c1e352bd045842c975b0db01eb (test). Relevant processes were absent before isolated diagnosis. One isolated invocation of the exact failed test passed in1.57s, including its byte preservation, overflow and timeout cases. This does not prove the cause of the initial delay; scheduling/startup delay is only a hypothesis. No code or timeout adjustment was made to that test.

A separately retained full confirmation run follows this targeted diagnosis to determine whether the complete current suite can pass. It must not overwrite the failed first run or claim an established root-cause fix. This is a bounded follow-up to an observed failure, not an unbounded retry-until-green loop. If confirmation fails, preserve it and stop qualification pending diagnosis.
