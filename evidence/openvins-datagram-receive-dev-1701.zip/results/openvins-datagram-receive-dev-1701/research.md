# Datagram source/API choice

Purpose: preserve actual recvmsg return shape and times without asserting live sender identity or simulation-clock observation. The code never creates/closes/binds/connects/sends a socket. All current tests use injected Python objects.

| Candidate | Version/license/maintenance | Interface/resources | Decision/cost |
|---|---|---|---|
| CPython socket recvmsg | installed WSL3.12.3, PSF; fixed3.12.3 API source plus fresh GitHub metadata when available | four-part datagram return; one <=4096-byte call per poll; 8192 bounded ordinary log entries | adopt; minimal stdlib adaptation, no installation; fake tests do not prove kernel behavior |
| recvfrom | same stdlib | lacks recvmsg flags | reject for this boundary because truncated input must be explicitly rejected |
| New pymavlink connection/factory | existing2.4.49 and retained generator/generated-output licenses; prior maintenance observation reused | combines connection setup/parser/send | reject here: existing pinned byte codec remains separate, lifecycle/network setup not authorized |
| Pinned PX4 | d6f12ad BSD3; prior metadata reused, not asserted latest | INADDR_ANY bind; initial source-address learning | no PX4 modification; future isolation/owned session gates remain required |

Official references inspected2026-10-08:
- https://docs.python.org/3.12/library/socket.html#socket.socket.recvmsg — current rolling3.12.15 page, not installed patch equality. Fixed3.12.3 doc source saved separately.
- https://man7.org/linux/man-pages/man7/udp.7.html — unreliable/reordered datagrams, one packet per receive, truncation flag; empty datagrams are possible. Page identifies man-pages6.19, not a kernel-version proof.
- https://man7.org/linux/man-pages/man7/unix.7.html — AF_UNIX credentials must not be generalized to IPv4 UDP.
- retained fixed PX4 mavlink_main.cpp:init_udp and mavlink_receiver.cpp UDP branch: learning an initial address does not authenticate every later datagram's process.

The selected narrow profile accepts no ancillary controls or message flags. It does not claim kernel timestamp support, GRO decoding, producer PID authentication or cryptographic provenance. Userspace monotonic observation after recvmsg is an observation boundary, not exact kernel arrival or latency. Callback owner guard must be supplied by future integration and remains outside the tests' evidence scope. No derived simulation timestamp is manufactured from ts1.

No new VIO/learning numerical algorithm; existing paper basis unchanged. OS/API primary sources are the relevant reference for this transport boundary. Source-copy/download manifest records actual hashes and any errors. Metadata observation is current only if fetch succeeds; no unverifiable claim of active maintenance.
