import hashlib
import json
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
ARCHIVE = ROOT / "evidence/openvins-motion-intent-visual-diagnosis-dev-1701.zip"
SEAL = ROOT / "results/estimator-physical-refusal-diagnosis-dev-1701/motion-intent-visual-evidence-seal.json"
PREFIX = "openvins-motion-intent-visual-diagnosis-dev-1701/"
MEMBERS = [
    "evidence/heartbeat-commit-order-physical-vio-diagnosis-dev-1701.zip",
    "docs/ESTIMATOR_PHYSICAL_REFUSAL_DIAGNOSIS_REPORT.md",
    "docs/superpowers/specs/2026-10-07-openvins-motion-intent-and-visual-starvation-design.md",
    "docs/superpowers/plans/2026-10-07-openvins-motion-intent-and-visual-starvation.md",
    "tools/benchmark/motion_intent_gate.py",
    "tools/benchmark/diagnose_visual_feature_starvation.py",
    "tests/benchmark/test_motion_intent_gate.py",
    "tests/benchmark/test_diagnose_visual_feature_starvation.py",
    "results/estimator-physical-refusal-diagnosis-dev-1701/motion-intent-visual-research.md",
    "results/estimator-physical-refusal-diagnosis-dev-1701/physical-run-v11-visual-feature-starvation-diagnosis.json",
    "results/estimator-physical-refusal-diagnosis-dev-1701/physical-run-v11-visual-feature-starvation-diagnosis-console.txt",
    "results/estimator-physical-refusal-diagnosis-dev-1701/physical-run-v11-visual-feature-starvation-diagnosis-v2.json",
    "results/estimator-physical-refusal-diagnosis-dev-1701/physical-run-v11-visual-feature-starvation-diagnosis-v2-console.txt",
    "results/estimator-physical-refusal-diagnosis-dev-1701/motion-intent-visual-full-tests.txt",
    "results/estimator-physical-refusal-diagnosis-dev-1701/motion-intent-visual-ruff.txt",
    "results/estimator-physical-refusal-diagnosis-dev-1701/seal_motion_intent_visual.py",
]


def digest(data):
    return hashlib.sha256(data).hexdigest()


records = []
for relative in MEMBERS:
    path = ROOT / relative
    data = path.read_bytes()
    records.append({"path": relative, "bytes": len(data), "sha256": digest(data)})

manifest = {
    "schema": "openvins-motion-intent-visual-diagnosis-evidence-v1",
    "physical_capture_rerun": False,
    "openvins_replayed": False,
    "prior_archive": records[0],
    "members": records,
}
encoded = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
if ARCHIVE.exists():
    raise FileExistsError(ARCHIVE)
with zipfile.ZipFile(ARCHIVE, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for record in records:
        archive.write(ROOT / record["path"], PREFIX + record["path"])
    archive.writestr(PREFIX + "manifest.json", encoded)

with zipfile.ZipFile(ARCHIVE) as archive:
    if archive.testzip() is not None:
        raise RuntimeError("ZIP CRC failure")
    names = archive.namelist()
    if len(names) != len(set(names)) or len(names) != len(records) + 1:
        raise RuntimeError("ZIP member identity failure")
    loaded = json.loads(archive.read(PREFIX + "manifest.json"))
    for record in loaded["members"]:
        data = archive.read(PREFIX + record["path"])
        if len(data) != record["bytes"] or digest(data) != record["sha256"]:
            raise RuntimeError("manifest member verification failure")

seal = {
    "path": str(ARCHIVE.relative_to(ROOT)).replace("\\", "/"),
    "members": len(records) + 1,
    "bytes": ARCHIVE.stat().st_size,
    "sha256": digest(ARCHIVE.read_bytes()),
    "crc_verified": True,
    "manifest_members_verified": len(records),
}
SEAL.write_text(json.dumps(seal, indent=2) + "\n", encoding="utf8")
print(json.dumps(seal, indent=2))
