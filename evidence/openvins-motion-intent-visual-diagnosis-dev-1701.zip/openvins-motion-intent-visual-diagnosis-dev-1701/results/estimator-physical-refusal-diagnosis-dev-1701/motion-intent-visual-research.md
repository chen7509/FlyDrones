# Motion-intent and visual-starvation research record

Read-only research on 2026-10-07. No dependency installation, estimator rebuild,
fixed-input replay or physics run occurred.

- Pinned OpenVINS source: `rpng/open_vins` commit
  `69488123ed9362dd44b6f28e7f4680abbff1442b`, GPL-3.0. Existing frozen
  snapshots under `results/openvins-motion-readiness-dev-1701/next-diagnosis-sources`
  were used for byte-stable implementation inspection. Recorded repository
  metadata says non-archived and last pushed 2025-11-30; it does not establish
  an active 2026 release cadence.
- Official `VioManager.cpp` source:
  https://github.com/rpng/open_vins/blob/master/ov_msckf/src/core/VioManager.cpp
  confirms beginning-only ZUPT is skipped after `has_moved_since_zupt`, while
  the normal path sets that flag after successful regular propagation.
- Official `UpdaterZeroVelocity` API:
  https://docs.openvins.com/classov__msckf_1_1UpdaterZeroVelocity.html and
  derivation: https://docs.openvins.com/update-zerovelocity.html describe a
  stationary zero-velocity update. The pinned source snapshot, rather than
  current master, controls the diagnosed disparity override behavior.
- OpenVINS project and ICRA 2020 paper references:
  https://github.com/rpng/open_vins and
  https://pgeneva.com/downloads/papers/Geneva2020ICRA.pdf. They establish the
  estimator architecture and upstream interfaces, not a guarantee that a
  command-intent latch will fix this capture.

Adopted: a truth-free Python evidence gate around an already safety-authorized
nonzero motion command, followed later by a narrow GPL-linked adapter message.
It preserves static initialization and uses the existing protected movement
flag instead of changing ZUPT thresholds. Runtime cost is one bounded command
and acknowledgement per estimator session. Integration cost is moderate
because the existing native transport is single-owner and must acknowledge the
latch before actuation.

Rejected for this stage: globally disabling ZUPT, lowering disparity or
feature thresholds, noise sweeps, scene/texture changes, truth-derived motion
detection, or replacing OpenVINS. Each changes the sealed experiment or can
hide the diagnosed mechanism without proving causality.

The fixed-frame diagnostic uses only NumPy/SciPy already present in the test
environment. Its Harris/translation proxy is deliberately not presented as
the OpenVINS KLT/grid/RANSAC implementation. The next diagnostic requires
read-only instrumentation of the pinned native tracker/update path and a new
fixed-input replay plan before any rebuild or replay.
