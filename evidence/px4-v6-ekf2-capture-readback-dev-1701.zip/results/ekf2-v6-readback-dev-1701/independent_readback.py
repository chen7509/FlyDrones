"""Independent raw-ULog check of the decisive PX4 heading/source observation."""

import hashlib
import json
import tempfile
import zipfile
from bisect import bisect_right
from pathlib import Path

from pyulog import ULog


root = Path(__file__).resolve().parents[2]
source = root / "evidence/depth-physical-v5-v6-dev-1701.zip"
expected_archive = "30d968bbc295699f4a71f8b3b552e6eeaef829221f824a1795d666a22d2b7db6"
expected_ulog = "24a5f46b1bb8213b138bdd62b787e91579e8c48fb588d740c10dd716aaef4d05"
prefix = "results/depth-physical-development-preflight-dev-1701/study-v6/capture-v1/"
if hashlib.sha256(source.read_bytes()).hexdigest() != expected_archive:
    raise ValueError("archive mismatch")
with zipfile.ZipFile(source) as archive:
    frames = json.loads(archive.read(prefix + "rgb-capture-manifest.json"))["frames"]
    raw = archive.read(prefix + "px4-ulog/log/2026-10-09/22_20_27.ulg")
if hashlib.sha256(raw).hexdigest() != expected_ulog:
    raise ValueError("ULog mismatch")
with tempfile.TemporaryDirectory(prefix="flydrones-v6-ekf2-check-") as temporary:
    file = Path(temporary) / "source.ulg"
    file.write_bytes(raw)
    ulog = ULog(str(file))
    local = ulog.get_dataset("vehicle_local_position").data
    flags = ulog.get_dataset("estimator_status_flags").data
    local_times = list(local["timestamp"])
    flag_times = list(flags["timestamp"])
    heading_good = []
    source_for_good = []
    local_missing = 0
    for frame in frames:
        frame_us = frame["frame_ns"] // 1000
        position_index = bisect_right(local_times, frame_us) - 1
        if position_index < 0:
            local_missing += 1
            continue
        if local["heading_good_for_control"][position_index] == 1:
            heading_good.append(frame["frame_ns"])
            flag_index = bisect_right(flag_times, frame_us) - 1
            source_for_good.append(None if flag_index < 0 else {
                "cs_gnss_pos": int(flags["cs_gnss_pos"][flag_index]),
                "cs_ev_pos": int(flags["cs_ev_pos"][flag_index]),
            })

result = {
    "schema": "flydrones-v6-ekf2-direct-readback-v1",
    "archive_sha256": expected_archive,
    "ulog_sha256": expected_ulog,
    "rgb_frame_count": len(frames),
    "local_position_missing_count": local_missing,
    "heading_good_frame_ns": heading_good,
    "source_flags_at_heading_good": source_for_good,
}
target = Path(__file__).resolve().parent / "independent.json"
if target.exists():
    raise FileExistsError(target)
target.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
print(json.dumps(result, sort_keys=True))
