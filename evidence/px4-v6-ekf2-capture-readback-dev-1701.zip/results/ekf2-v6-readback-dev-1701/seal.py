"""Seal the v6 read-back without copying the already sealed physical ULog."""

import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


root = Path(__file__).resolve().parents[2]
target = root / "evidence/px4-v6-ekf2-capture-readback-dev-1701.zip"
members = [
    "results/ekf2-v6-readback-dev-1701/audit.py",
    "results/ekf2-v6-readback-dev-1701/audit.json",
    "results/ekf2-v6-readback-dev-1701/independent_readback.py",
    "results/ekf2-v6-readback-dev-1701/independent.json",
    "results/ekf2-v6-readback-dev-1701/preflight.json",
    "results/ekf2-v6-readback-dev-1701/seal.py",
    "src/flydrones/benchmark/ekf2_shadow.py",
    "docs/PX4_V6_EKF2_CAPTURE_READBACK_REPORT.md",
]
contents = {name: (root / name).read_bytes() for name in members}
manifest = {
    "schema": "flydrones-v6-ekf2-readback-archive-v1",
    "original_physical_archive_sha256": "30d968bbc295699f4a71f8b3b552e6eeaef829221f824a1795d666a22d2b7db6",
    "original_ulog_sha256": "24a5f46b1bb8213b138bdd62b787e91579e8c48fb588d740c10dd716aaef4d05",
    "members": {
        name: {"bytes": len(blob), "sha256": hashlib.sha256(blob).hexdigest()}
        for name, blob in sorted(contents.items())
    },
}
manifest_blob = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
target.parent.mkdir(exist_ok=True)
with ZipFile(target, "w", ZIP_DEFLATED) as archive:
    for name, blob in sorted(contents.items()):
        archive.writestr(name, blob)
    archive.writestr("archive-manifest.json", manifest_blob)
with ZipFile(target) as archive:
    assert set(archive.namelist()) == set(contents) | {"archive-manifest.json"}
    assert json.loads(archive.read("archive-manifest.json")) == manifest
    for name, entry in manifest["members"].items():
        blob = archive.read(name)
        assert len(blob) == entry["bytes"]
        assert hashlib.sha256(blob).hexdigest() == entry["sha256"]
print(target)
print("sha256", hashlib.sha256(target.read_bytes()).hexdigest())
print("members", len(contents) + 1)
