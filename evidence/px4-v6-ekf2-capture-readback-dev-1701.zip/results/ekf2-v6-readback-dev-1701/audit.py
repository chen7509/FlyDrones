"""Read-only EKF2 alignment of one already-sealed v6 physical development capture."""

import hashlib
import json
import sys
import tempfile
import zipfile
from pathlib import Path

from pyulog import ULog


root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root / "src"))
from flydrones.benchmark.ekf2_shadow import (  # noqa: E402
    audit_shadow_frames,
    audit_state_sample_times,
)

archive_path = root / "evidence/depth-physical-v5-v6-dev-1701.zip"
output_path = Path(__file__).resolve().parent / "audit.json"
expected_archive = "30d968bbc295699f4a71f8b3b552e6eeaef829221f824a1795d666a22d2b7db6"
expected_ulog = "24a5f46b1bb8213b138bdd62b787e91579e8c48fb588d740c10dd716aaef4d05"
prefix = "results/depth-physical-development-preflight-dev-1701/study-v6/capture-v1/"
rgb_name = prefix + "rgb-capture-manifest.json"
ulog_manifest_name = prefix + "px4-ulog-manifest.json"
topics_needed = (
    "vehicle_local_position", "vehicle_attitude", "estimator_status", "estimator_status_flags"
)

if output_path.exists():
    raise FileExistsError(output_path)
archive_hash = hashlib.sha256(archive_path.read_bytes()).hexdigest()
if archive_hash != expected_archive:
    raise ValueError("physical evidence archive differs from sealed v6")
with zipfile.ZipFile(archive_path) as archive:
    if len(archive.namelist()) != len(set(archive.namelist())):
        raise ValueError("duplicate archive member")
    rgb_manifest = json.loads(archive.read(rgb_name))
    ulog_manifest = json.loads(archive.read(ulog_manifest_name))
    if rgb_manifest.get("schema") != "flydrones-rgb-capture-v1":
        raise ValueError("RGB manifest schema changed")
    frames = rgb_manifest.get("frames")
    if not isinstance(frames, list) or len(frames) != 251:
        raise ValueError("RGB frame count changed")
    frame_ns = []
    for frame in frames:
        t = frame.get("frame_ns")
        name = frame.get("path")
        if (type(t) is not int or t < 0 or (frame_ns and t <= frame_ns[-1])
                or type(name) is not str or not name.startswith("rgb-frames/")
                or ".." in Path(name).parts):
            raise ValueError("invalid RGB frame identity or time")
        if hashlib.sha256(archive.read(prefix + name)).hexdigest() != frame.get("sha256"):
            raise ValueError("RGB frame differs from manifest")
        frame_ns.append(t)
    if (ulog_manifest.get("schema") != "flydrones-px4-ulog-capture-v1"
            or not isinstance(ulog_manifest.get("logs"), list)
            or len(ulog_manifest["logs"]) != 1):
        raise ValueError("ULog manifest invalid")
    entry = ulog_manifest["logs"][0]
    relative = entry.get("path")
    if (type(relative) is not str or not relative.startswith("px4-ulog/")
            or ".." in Path(relative).parts):
        raise ValueError("ULog path invalid")
    ulog_bytes = archive.read(prefix + relative)
    if (len(ulog_bytes) != entry.get("bytes")
            or hashlib.sha256(ulog_bytes).hexdigest() != expected_ulog
            or entry.get("sha256") != expected_ulog):
        raise ValueError("ULog differs from sealed physical evidence")

with tempfile.TemporaryDirectory(prefix="flydrones-v6-ekf2-readback-") as temporary:
    path = Path(temporary) / "source.ulg"
    path.write_bytes(ulog_bytes)
    parsed = ULog(str(path))
    topics = {name: parsed.get_dataset(name).data for name in topics_needed}
    shadow = audit_shadow_frames(frame_ns, topics)
    sample_times = audit_state_sample_times(frame_ns, topics)

result = {
    "schema": "flydrones-v6-ekf2-readback-v1",
    "archive_sha256": archive_hash,
    "ulog_sha256": expected_ulog,
    "rgb_frame_count": len(frame_ns),
    "shadow": shadow,
    "sample_times": sample_times,
    "calibration_verified": False,
    "teacher_observed": False,
    "clock_epoch_qualified": False,
    "eligible_for_student_capture": False,
}
output_path.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
print(json.dumps({
    "rgb_frames": len(frame_ns),
    "shadow_counts": shadow["counts"],
    "sample_timing_usable": sample_times["sample_timing_usable_count"],
    "output": str(output_path),
}, sort_keys=True))
