from pathlib import Path
import json
p=Path('/home/yuchen7509/PX4-Autopilot/build/px4_sitl_default/compile_commands.json')
rows=json.loads(p.read_text());selected=[r for r in rows if r['file'].endswith('/drv_hrt.cpp') or r['file'].endswith('/GZBridge.cpp') or r['file'].endswith('/mavlink_main.cpp')]
assert len(selected)==3
out=[dict(file=r['file'],command=r.get('command'),arguments=r.get('arguments'),lockstep_define='-DENABLE_LOCKSTEP_SCHEDULER' in r.get('command',' '.join(r.get('arguments',[])))) for r in selected]
(Path(__file__).parent/'installed-clock-compile-commands.json').write_text(json.dumps(out,indent=2));print(json.dumps([dict(file=r['file'],lockstep_define=r['lockstep_define']) for r in out]))
