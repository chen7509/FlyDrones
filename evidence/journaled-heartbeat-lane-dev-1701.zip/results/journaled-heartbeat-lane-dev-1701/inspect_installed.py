from pathlib import Path
import json,hashlib,subprocess
out=Path(__file__).resolve().parent;px4=Path('/home/yuchen7509/PX4-Autopilot')
rows=[]
for name in ['platforms/posix/src/px4/common/drv_hrt.cpp','src/modules/simulation/gz_bridge/GZBridge.cpp','src/modules/mavlink/mavlink_main.cpp','src/modules/mavlink/mavlink_stream.cpp']:
 data=(px4/name).read_bytes();pin=(out/'sources'/Path(name).name).read_bytes();rows.append(dict(path=name,sha256=hashlib.sha256(data).hexdigest(),matches_pinned_snapshot=data==pin))
build=px4/'build/px4_sitl_default'
for name in ['build.ninja','compile_commands.json']:
 p=build/name
 if p.exists():
  data=p.read_bytes();rows.append(dict(path=str(p),sha256=hashlib.sha256(data).hexdigest(),lockstep_define_present=b'-DENABLE_LOCKSTEP_SCHEDULER' in data))
rows.append(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=px4,text=True).strip(),status=subprocess.check_output(['git','status','--short'],cwd=px4,text=True)))
(out/'installed-clock-source.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows))
