"""Fetch read-only source at existing pinned commit; never loads target code."""
import hashlib
import json
import time
import urllib.request
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent
pin='ef321e23c20eebc6d6fb4044425c00e6df27b05f'
old=root/'results/zero-needed-python-entry-research-dev-1701/upstream/bminor__glibc'
dest=raw/'upstream/bminor__glibc';dest.mkdir(parents=True,exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def save(p,b):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(b)
tree=json.loads((old/'official-tree.json').read_bytes());assert tree['truncated'] is False and len(tree['tree'])==20266
table={r['path']:r for r in tree['tree']}
for name in ['official-tree.json','official-commit.json','official-ref.json']:
    save(dest/name,(old/name).read_bytes())
retained=['elf/dl-load.c','elf/dl-deps.c','elf/rtld.c','elf/ldd.bash.in','COPYING','COPYING.LIB']
fresh=['elf/dl-object.c','stdlib/canonicalize.c','sysdeps/posix/dl-fileid.h','sysdeps/unix/sysv/linux/dl-origin.c']
recipe=dict(pin=pin,files=fresh,method='HTTPS raw source data only; no target machine commands or production imports',per_response_limit=1048576,network_timeout_seconds=10,license='retained COPYING/COPYING.LIB plus full file notices; no distro-build/transitive-license certification')
save(raw/'source-fetch-recipe.json',json.dumps(recipe,indent=2).encode())
rows=[]
for name in retained+fresh:
    meta=table[name];start=time.monotonic_ns()
    url=f'https://raw.githubusercontent.com/bminor/glibc/{pin}/{name}'
    if name in retained:b=(old/name).read_bytes();kind='retained current bytes re-audited'
    else:
        request=urllib.request.Request(url,headers={'User-Agent':'FlyDrones-pinned-source-research'})
        with urllib.request.urlopen(request,timeout=10) as response:
            b=response.read(1048577)
            assert len(b)<=1048576 and response.status==200
        kind='new necessary pinned primary source'
    assert len(b)==meta['size'] and blob(b)==meta['sha'],name
    save(dest/name,b)
    rows.append(dict(path=name,url=url,bytes=len(b),git_blob=blob(b),sha256=sha(b),source_kind=kind,local_elapsed_ns=time.monotonic_ns()-start))
save(raw/'primary-source-audit.json',json.dumps(dict(pin=pin,tree_sha=tree['sha'],tree_members=20266,truncated=False,files=rows,scope='primary source/Git-byte relation, not distro build or historical loader filesystem identity'),indent=2).encode())
print('10 full source/license files: 6 retained +4 necessary new, pinned Gitblob/size/SHA verified')
