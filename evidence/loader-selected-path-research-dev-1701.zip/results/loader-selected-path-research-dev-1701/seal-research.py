"""Seal research/source/data only; no target program or tests."""
import hashlib
import json
import zipfile
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent
name='loader-selected-path-research-dev-1701'
archive=root/'evidence'/f'{name}.zip';mapping=root/'evidence'/f'{name}.sha256.json'
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes().decode('utf-8-sig'))
def write(p,v):
    with p.open('xb') as f:f.write(json.dumps(v,ensure_ascii=False,indent=2).encode())
assert not archive.exists() and not mapping.exists()
private=raw/'initial-resource-private.json';v=load(private)
rows=v['windows']+v['wsl'];needles={r['argv_sha256'].encode() for r in rows if r.get('argv_sha256') and r['argv_sha256']!=sha(b'')}
explicit=['docs/TARGET_BEARING_LOADER_SELECTED_PATH_RESEARCH_REPORT.md','docs/superpowers/specs/2026-10-15-loader-selected-path-production-design.md','docs/superpowers/plans/2026-10-15-loader-selected-path-production.md','docs/superpowers/plans/2026-10-15-static-harness-containment-and-v3-failure.md','docs/superpowers/specs/2026-10-15-static-harness-containment-and-v3-failure-design.md','docs/TARGET_BEARING_STATIC_V3_HARNESS_FAILURE_REPORT.md','evidence/static-v3-harness-failure-publication.json','evidence/flydrones-history-through-admitted-executor-dev-1701.json','tools/benchmark/native_entry_context_v3.py','tools/benchmark/declared_runtime_snapshot.py','tools/benchmark/software_process_boundary.py','tests/benchmark/conftest.py']
files={root/p for p in explicit}|{p for p in raw.rglob('*') if p.is_file() and p!=private and '__pycache__' not in p.parts and p.suffix not in ['.pyc','.pyo']}
members=[]
for p in sorted(files):
    b=p.read_bytes();path=p.relative_to(root).as_posix()
    assert not any(n in b for n in needles),path
    if p.suffix=='.json':
        try:stack=[json.loads(b.decode('utf-8-sig'))]
        except (ValueError,UnicodeError):stack=[]
        while stack:
            x=stack.pop()
            if isinstance(x,dict):
                if {'pid','name','argv_sha256'}<=x.keys():
                    assert not any(all(x.get(k)==r.get(k) for k in ['pid','name','argv_sha256']) for r in rows),path
                stack.extend(x.values())
            elif isinstance(x,list):stack.extend(x)
    members.append(dict(path=path,bytes=len(b),sha256=sha(b)))
write(mapping,dict(schema='loader-path-research-exact-member-map-v1',scope='research/design only; original native failures and all qualifications unchanged',members=members,private_excluded=dict(path=private.relative_to(root).as_posix(),bytes=private.stat().st_size,sha256=sha(private.read_bytes())),nonempty_private_argv_hashes=len(needles),private_compound_matches=0))
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for r in members:z.write(root/r['path'],r['path'])
    z.write(mapping,mapping.relative_to(root).as_posix())
receipt=dict(archive=archive.relative_to(root).as_posix(),sha256=sha(archive.read_bytes()),bytes=archive.stat().st_size,members=len(members)+1,mapped_members=len(members),manifest_sha256=sha(mapping.read_bytes()),nonempty_private_argv_hashes=len(needles),preseal_exact_set=[r['path'] for r in members],scope='prepublication research/design; new production all pending, all qualification/readiness false')
write(raw/'seal-receipt.json',receipt)
print({k:v for k,v in receipt.items() if k!='preseal_exact_set'})
