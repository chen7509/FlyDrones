"""Whole retained product/archive comparison, after research only."""
import hashlib
import json
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_bytes().decode('utf-8-sig'))
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def write(name,obj):
    with (raw/name).open('xb') as f:f.write(json.dumps(obj,indent=2).encode())
before=load(raw/'product-before.json')
for row in before['members']:
    assert (root/row['path']).stat().st_size==row['bytes'] and sha(root/row['path'])==row['sha256'],row['path']
write('product-after.json',dict(scope='POST research exact unchanged tracked src/tools/tests/configs; no native attestation',members=before['members'],all_current_match=True))
prior=load(root/'results/static-v3-coordinator-dev-1701/historical-archives-postfailure.json')['members']
seal=load(root/'results/static-v3-coordinator-dev-1701/seal-receipt.json')
rows=prior+[dict(path=seal['archive'],bytes=seal['bytes'],sha256=seal['sha256'])]
assert len(rows)==288 and sum(r['bytes'] for r in rows)==822394659
assert {p.relative_to(root).as_posix() for p in (root/'evidence').glob('*.zip')}=={r['path'] for r in rows}
for row in rows:
    assert (root/row['path']).stat().st_size==row['bytes'] and sha(root/row['path'])==row['sha256'],row['path']
write('historical-archives-postresearch.json',dict(count=288,bytes=822394659,scope='POSTresearch preservation only, no retroactive attempt prepin',members=rows))
write('research-scope-facts.json',dict(skills=['using-superpowers','systematic-debugging','brainstorming','writing-plans','requesting-code-review'],method='source/data investigation and independent architectural spec/plan; standing autonomous authorization supersedes per-step approval handoffs; quiet heartbeat suppresses routine skill announcements',goal_status_read='blocked',goal_changed=False,product_files_unchanged=len(before['members']),tests_run=0,target_commands_run=0,new_v4_study_claim_scope_created=False,all_qualification_flags_false=True,runtime_graph_frozen=False,physical_dispatch_ready=False,original_v3_failure_and_observer_correction_preserved=True))
print('product files',len(before['members']),'unchanged; 288 historical ZIPs 822394659B unchanged')
