"""Retained JSON/ZIP comparison only; do not import any bill/parser module."""
import hashlib
import json
import re
import zipfile
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent
archive=root/'evidence/static-v3-harness-failure-dev-1701.zip'
def sha(b):return hashlib.sha256(b).hexdigest()
assert sha(archive.read_bytes())=='9368f59c76e9fde2833b693321d2f91896e8ff6d7dc5387679296135c64df7b5'
dest=raw/'retained-v3';dest.mkdir(exist_ok=False)
folder='results/target-bearing-runtime-freeze-v3-dev-1701/frozen-study-v3/sdk'
paths=[f'{folder}/entry-dependencies/entry-bill.json',f'{folder}/python-context.json']
paths += [f'{folder}/entry-dependencies/query-{i:04}.json' for i in range(1,65)]
paths += ['results/static-v3-coordinator-dev-1701/'+n for n in ['FIXTURE_SCOPE_CORRECTION.json','escaped-attempt-actual-summary.json','escaped-attempt-folder-clarification.json','escaped-attempt-source-postsnapshot.json']]
rows=[]
with zipfile.ZipFile(archive) as z:
    for path in paths:
        b=z.read(path);assert b==(root/path).read_bytes(),path
        out=dest/Path(path).name
        with out.open('xb') as f:f.write(b)
        rows.append(dict(source=path,copy=out.relative_to(root).as_posix(),bytes=len(b),sha256=sha(b)))
bill=json.loads((dest/'entry-bill.json').read_bytes())
queries=[json.loads((dest/f'query-{i:04}.json').read_bytes()) for i in range(1,65)]
assert bill['queries']==queries and not bill['complete']
q=queries[-1];assert q['exit']==0 and q['stderr_hex']==''
stdout=bytes.fromhex(q['stdout_hex']);assert sha(stdout)=='3c7b13ef1519ac873dfbf048afadfc12cf262941dfdd2747e2b4330e150d2fef'
selected=[m.group(1) for line in stdout.decode().splitlines() if (m:=re.fullmatch(r'\s*(?:\S+ => )?(/.+?) \(0x[0-9a-fA-F]+\)',line))]
dotdot=[p for p in selected if '..' in p.split('/')]
assert len(dotdot)==3
out=dict(scope='Retained text extraction, not a producer/validator/native replay or path identity measurement',canonical_archive_sha256=sha(archive.read_bytes()),copied_members=rows,query_count=64,all_embedded_queries_match_raw=True,entry_rows=len(bill['entries']),candidate_inputs=len(bill['inputs']['candidates']) if 'inputs' in bill else None,last_query_exit=0,last_query_stdout_sha256=sha(stdout),printed_absolute_file_paths=selected,printed_paths_containing_dotdot=dotdot,actual_target_path_resolution_observed=False,source_runtime_closure_qualified=False)
with (raw/'retained-trace-audit.json').open('xb') as f:f.write(json.dumps(out,indent=2).encode())
print(dict(copied=len(rows),queries=64,entries=len(bill['entries']),printed_file_paths=len(selected),dotdot_paths=len(dotdot)))
