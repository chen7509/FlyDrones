# Independent loader-selected-path research/design review

Verdict: changes requested. Initial findings: Critical0 / Important1 / Minor1. This is a research/design verdict only. It is not product implementation approval, a native dispatch decision, archive-seal approval, or source/runtime qualification.

## Important I1 — Define the before-import boundary on direct preparation routes

At production-plan line49, Task3 exposes `prepare_v4(ticket)` and requires a validated ticket before real preparation effects. The spec line43 puts before-project/JSON/SDK validation in the distinct bootstrap and says a generic preparation CLI cannot bypass it. A direct `python -m ...prepare_calibration_capture_v4` or ordinary import nevertheless executes module top-level code before a callable ticket check. No explicit inert top-level contract, direct-route pre-import guard, or direct import/CLI before-effect test is specified. Implementation can meet the listed callable/SDK tests while performing serializer/project/SDK imports before authorization through another route.

Specify that the preparation and effectful study top levels remain inert before primitive authorization, and define how direct CLI/import refuses or stays inert before JSON/project/SDK imports, output, or child/query effects. Bind the validated primitive launch authorization to the later callable without accepting a caller-made truthy dict. Add direct-route before-import/effect tests with inert protocols. This is a design/coverage gap, not a claim that nonexistent v4 implementation already executed anything.

## Minor M1 — Candidate count is lost in the retained audit

`retained-trace-audit.json:429` has `candidate_inputs:null`. Its helper line31 reads the absent `bill.inputs.candidates` schema; this retained bill instead has `input_candidates` with145 members. The report count145 is correct. Preserve the original helper/audit, add a correction from the retained actual field and join it to the same bill/query/archive hashes; no producer replay is needed.

## Independent evidence

All ten pinned source/license files independently match local size, SHA256, recomputed Git blob and the retained untruncated20266-member tree (`c4dee33796321547167f05c82b550f7cded262b1`). The reviewed upstream blocks support ordinary `$ORIGIN` copying, separate secure trusted normalization, open-path spelling, shared-object origin spelling, trace l_name, POSIX descriptor dev/inode and component/symlink/directory semantics. They do not certify the installed distribution build or target filesystem traversal.

All70 selected copied members match current retained files and canonical failure ZIP members by size/SHA256. The ZIP hash is `9368f59c76e9fde2833b693321d2f91896e8ff6d7dc5387679296135c64df7b5`. All64 embedded queries equal their raw JSONs; bill has145 candidate inputs,463 files and complete=false. All807 product-before member hashes/sizes match current bytes. Archive CRC/exact-set/publication sealing remains a separate later boundary.

Only local file/source/JSON/ZIP reads and hashing were used. No tests, selected imports, WSL, process/resource/permission/network probes, target metadata/consumer or native reruns occurred. No product/docs/raw actuals were changed. Only this additive review pair was written.

v3 remains CONSUMED_FAILED_UNADMITTED_HARNESS_ESCAPE, escaped closure UNKNOWN, every qualification/readiness false; all production remains pending.