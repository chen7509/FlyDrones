import hashlib
import json
import subprocess
from pathlib import Path

root=Path.cwd();raw=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,b):
    with (raw/name).open('xb') as f:f.write(b)
parents=[]
for p in [root,*root.parents]:
    if (p/'AGENTS.md').is_file():parents.append(dict(path=str(p/'AGENTS.md'),text=(p/'AGENTS.md').read_text(encoding='utf-8')))
write('ancestor-instructions.json',json.dumps(parents,indent=2).encode())
history=root/'evidence/flydrones-history-through-admitted-executor-dev-1701.json'
h=history.read_bytes();assert len(h)==89359 and sha(h)=='c88840b6f58dea4e7e4931683c4993b4fc3b8eb55887807994b6381ef6c2b989'
parsed=json.loads(h.decode('utf-8-sig'))
write('history-read.json',json.dumps(dict(path=str(history.relative_to(root)),bytes=len(h),sha256=sha(h),keys=list(parsed),scope='full JSON read; all original historical/safety facts preserved'),indent=2).encode())
p=subprocess.run(['git','ls-files','-z','src','tools','tests','configs'],capture_output=True,timeout=15);assert p.returncode==0
files=[x.decode() for x in p.stdout.split(b'\0') if x]
write('product-before.json',json.dumps(dict(scope='tracked src/tools/tests/configs bytes; not native execution attestation',members=[dict(path=x,bytes=(root/x).stat().st_size,sha256=sha((root/x).read_bytes())) for x in files]),indent=2).encode())
original=root/'results/static-v3-coordinator-dev-1701/initial-readonly.py'
write('initial-readonly.py',original.read_bytes())
p=subprocess.run(['python',str(raw/'initial-readonly.py')],capture_output=True,timeout=65)
write('initial-readonly.stdout',p.stdout);write('initial-readonly.stderr',p.stderr)
write('initial-readonly-return.json',json.dumps(dict(argv=['python',str(raw/'initial-readonly.py')],exit=p.returncode,helper_sha256=sha(original.read_bytes()),scope='single initial readonly snapshot only; no dispatch admission'),indent=2).encode())
assert p.returncode==0,p.stderr
print(p.stdout.decode(errors='replace'))
