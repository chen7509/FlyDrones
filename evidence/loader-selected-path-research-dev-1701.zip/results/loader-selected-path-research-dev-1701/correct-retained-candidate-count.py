"""Additive research metadata correction; no rawquery/producer replay."""
import hashlib
import json
from pathlib import Path
raw=Path(__file__).resolve().parent
original=raw/'retained-trace-audit.json'
bill=raw/'retained-v3/entry-bill.json'
data=json.loads(bill.read_bytes());count=len(data['input_candidates'])
assert count==145 and json.loads(original.read_bytes())['candidate_inputs'] is None
out=dict(schema='research-candidate-count-correction-v1',superseded_file='retained-trace-audit.json',superseded_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),superseded_field='candidate_inputs=null',cause='research helper read nonexistent bill.inputs.candidates instead of bill.input_candidates',correct_declared_candidate_inputs=count,bill_sha256=hashlib.sha256(bill.read_bytes()).hexdigest(),original_helper_and_output_unchanged=True,no_new_native_or_query=True,scope='research metadata only; does not fill empty candidate result rows/final closure')
with (raw/'retained-trace-audit-correction.json').open('xb') as f:f.write(json.dumps(out,indent=2).encode())
print('Additive research candidate count145; original null field/helper retained')
