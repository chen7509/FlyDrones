"""Build and verify a non-overwriting indexed development evidence archive."""

from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "evidence/openvins-track-geometry-dev-1701-reviewed.zip"
INDEX = OUT.with_suffix(".sha256.json")
BASE = ROOT / "results/openvins-track-geometry"


def digest(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


files = [
    "results/openvins-track-geometry/archive_evidence.py",
    "results/openvins-track-geometry/REPRODUCE.md",
    "results/openvins-track-geometry/instrument_tracks.py",
    "results/openvins-track-geometry/instrumentation.patch",
    "results/openvins-track-geometry/replay-v1/stderr.txt",
    "results/openvins-track-geometry/replay-v1/stdout.txt",
    "results/openvins-track-geometry/replay-v1/states.csv",
    "results/openvins-track-geometry/replay-v1/resources.txt",
    "results/openvins-track-geometry/replay-v1/exit-code.txt",
    "results/openvins-track-geometry/audit-v3/attempts.csv",
    "results/openvins-track-geometry/audit-v3/summary.json",
    "results/openvins-texture-dev/openvins-run-v2/states.csv",
    "results/openvins-texture-dev/config-v2/estimator_config.yaml",
    "results/openvins-texture-dev/config-v2/kalibr_imucam_chain.yaml",
    "results/openvins-texture-dev/input-v1/manifest.json",
    "results/openvins-offline-1701/runner-v3/offline_probe.cpp",
    "tools/benchmark/audit_openvins_track_geometry.py",
    "tests/benchmark/test_openvins_track_geometry.py",
    "docs/OPENVINS_TRACK_GEOMETRY_REPORT.md",
    "docs/superpowers/specs/2026-10-03-openvins-track-geometry-audit.md",
    "docs/superpowers/plans/2026-10-03-openvins-track-geometry-audit.md",
    "results/openvins-track-geometry/metadata.json",
]


def main() -> None:
    if OUT.exists() or INDEX.exists():
        raise SystemExit("evidence output already exists; preserve prior evidence")
    metadata = {
        "schema": "flydrones-openvins-track-geometry-metadata-v1",
        "scope": "logging-only upstream GPL-3.0 replay; PX4 EKF2 offline reference only",
        "upstream_openvins_commit": "69488123ed9362dd44b6f28e7f4680abbff1442b",
        "px4_ulog_ver_sw": "d6f12ad1c4f70ad3230afd7d86e971421e02fef4",
        "pyulog_version": "1.2.4",
        "diagnostic_library_sha256": "fde6832972e8c67826a1690ae378ffe120399eeecfee8f4aa9253f28a3f7f102",
        "diagnostic_library_bytes": 292681952,
        "diagnostic_library_in_archive": False,
        "prior_textured_evidence_sha256": digest(
            ROOT / "evidence/openvins-texture-dev-1701.zip"),
        "prior_rejection_evidence_sha256": digest(
            ROOT / "evidence/openvins-vio-rejection-dev-1701.zip"),
        "px4_ulog_sha256": digest(ROOT / (
            "results/openvins-texture-dev/episode-v1/px4-ulog/log/2026-10-03/01_28_24.ulg")),
        "px4_ulog_in_archive": False,
        "runner_binary_sha256": digest(ROOT / "results/openvins-offline-1701/runner-v3/offline_probe"),
        "runner_binary_in_archive": False,
        "build_command": "cmake --build ov_msckf/build --target ov_msckf_lib -j2",
        "replay_input_count": {"rgb": 604, "px4_ulog_imu": 15107},
        "replay_exit_code": 0,
    }
    (BASE / "metadata.json").write_text(
        json.dumps(metadata, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    entries = {}
    with zipfile.ZipFile(OUT, "x", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for name in files:
            path = ROOT / name
            data = path.read_bytes()
            archive.writestr(name, data)
            entries[name] = {"sha256": hashlib.sha256(data).hexdigest(),
                             "bytes": len(data)}
    with zipfile.ZipFile(OUT) as archive:
        if set(archive.namelist()) != set(files):
            raise RuntimeError("ZIP member names differ from manifest")
        for name in files:
            data = archive.read(name)
            if hashlib.sha256(data).hexdigest() != entries[name]["sha256"]:
                raise RuntimeError(f"ZIP digest mismatch: {name}")
            if len(data) != entries[name]["bytes"]:
                raise RuntimeError(f"ZIP byte count mismatch: {name}")
    index = {"schema": "flydrones-archive-index-v1", "archive_sha256": digest(OUT),
             "archive_bytes": OUT.stat().st_size, "files": entries}
    INDEX.write_text(json.dumps(index, indent=2, sort_keys=True) + "\n",
                     encoding="utf-8")
    print(json.dumps({"archive": str(OUT), "sha256": digest(OUT),
                      "file_count": len(entries), "bytes": OUT.stat().st_size}, indent=2))


if __name__ == "__main__":
    main()
