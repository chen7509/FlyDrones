"""Validate the real upstream reply from synthetic development observations."""

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from flydrones.benchmark.ego import validate_reference  # noqa: E402


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


attempts = {
    name: HERE / f"synthetic-bridge-probe-{name}.txt" for name in ("v2", "v3", "v4")
}
attempts["v1"] = HERE / "synthetic-bridge-probe.txt"
logs = {name: path.read_text(encoding="utf-8") for name, path in attempts.items()}
assert "ModuleNotFoundError: No module named 'quadrotor_msgs'" in logs["v1"]
assert "ConnectionError: bridge closed before full response" in logs["v2"]
assert "The 'x' field must be of type 'float'" in logs["v3"]
assert "CLIENT_EXIT=0" in logs["v4"]
assert "DOCKER_EXIT=0" not in logs["v4"]  # host summary was not appended to file
assert "plan_success=1" in logs["v4"]
reply_lines = [json.loads(line) for line in logs["v4"].splitlines() if line.startswith("{")]
assert reply_lines[0] == {"reset": {"status": "ready"}}
assert reply_lines[1]["index"] == 0
assert reply_lines[1]["sim_ns"] == 1_000_000_000
reply = reply_lines[1]["response"]
assert validate_reference(
    reply, observation_sim_ns=1_000_000_000, max_age_ns=100_000_000
) == reply

result = {
    "upstream_reference_received": True,
    "adapter_reference_validation_passed": True,
    "input_profile": "synthetic-static-depth-10m-v1",
    "px4_gazebo_or_vio_used": False,
    "physical_or_fair_comparison_qualified": False,
    "fixture_sha256": sha256(HERE / "synthetic_client.py"),
    "attempts": {name: sha256(path) for name, path in attempts.items()},
    "reference": reply,
}
with (HERE / "synthetic-validation.json").open("x", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
    stream.write("\n")
print(json.dumps(result, sort_keys=True, allow_nan=False))
