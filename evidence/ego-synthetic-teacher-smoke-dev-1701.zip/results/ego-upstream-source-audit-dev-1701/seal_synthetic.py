"""Seal all synthetic EGO teacher smoke attempts and the final validation."""

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
ARCHIVE = ROOT / "evidence/ego-synthetic-teacher-smoke-dev-1701.zip"
FILES = (
    ROOT / "docs/EGO_SYNTHETIC_TEACHER_SMOKE_REPORT.md",
    HERE / "synthetic_client.py",
    HERE / "synthetic-bridge-probe.txt",
    HERE / "synthetic-bridge-probe-v2.txt",
    HERE / "synthetic-bridge-probe-v3.txt",
    HERE / "synthetic-bridge-probe-v4.txt",
    HERE / "validate-synthetic-first-failure.txt",
    HERE / "validate_synthetic.py",
    HERE / "synthetic-validation.json",
    HERE / "seal_synthetic.py",
)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


entries = {}
for path in FILES:
    content = path.read_bytes()
    entries[path.relative_to(ROOT).as_posix()] = {
        "bytes": len(content),
        "sha256": digest(content),
    }
manifest = json.dumps({"members": entries}, indent=2).encode("utf-8") + b"\n"
ARCHIVE.parent.mkdir(exist_ok=True)
with ARCHIVE.open("xb") as target:
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in FILES:
            archive.write(path, path.relative_to(ROOT).as_posix())
        archive.writestr("manifest.json", manifest)

with zipfile.ZipFile(ARCHIVE) as archive:
    assert archive.testzip() is None
    sealed = json.loads(archive.read("manifest.json"))
    assert sealed["members"] == entries
    for name, metadata in entries.items():
        payload = archive.read(name)
        assert len(payload) == metadata["bytes"]
        assert digest(payload) == metadata["sha256"]

print(json.dumps({"archive": str(ARCHIVE), "bytes": ARCHIVE.stat().st_size,
                  "sha256": digest(ARCHIVE.read_bytes()),
                  "members": len(entries) + 1}, sort_keys=True))
