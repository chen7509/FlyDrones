"""Development-only synthetic ROS bridge smoke input; never benchmark data."""

import base64
import json
import socket
import struct

DEPTH = base64.b64encode(struct.pack("<f", 10.0) * (120 * 160)).decode("ascii")


def exchange(connection: socket.socket, payload: dict) -> dict:
    data = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    connection.sendall(struct.pack("!I", len(data)) + data)
    size = struct.unpack("!I", read_exact(connection, 4))[0]
    if not 0 < size < 1_000_000:
        raise ValueError("unexpected bridge response size")
    return json.loads(read_exact(connection, size))


def read_exact(connection: socket.socket, size: int) -> bytes:
    output = bytearray()
    while len(output) < size:
        chunk = connection.recv(size - len(output))
        if not chunk:
            raise ConnectionError("bridge closed before full response")
        output.extend(chunk)
    return bytes(output)


with socket.create_connection(("127.0.0.1", 46200), timeout=5) as connection:
    connection.settimeout(10)
    response = exchange(connection, {"type": "reset", "seed": 1701})
    if response != {"status": "ready"}:
        raise ValueError(f"unexpected reset response: {response!r}")
    print(json.dumps({"reset": response}, sort_keys=True), flush=True)
    for index in range(12):
        sim_ns = 1_000_000_000 + index * 100_000_000
        observation = {
            "sim_ns": sim_ns,
            "frame_ns": sim_ns,
            "rgb": "",
            "depth_m": {"shape": [120, 160], "data": DEPTH},
            "camera_pose": [0.0, 0.0, 1.5, 0.0, 0.0, 0.0, 1.0],
            "position": [0.0, 0.0, 1.5],
            "velocity": [0.0, 0.0, 0.0],
            "yaw": 0.0,
            "yaw_rate": 0.0,
            "goal": [8.0, 0.0, 1.5],
        }
        response = exchange(connection, observation)
        record = {"index": index, "sim_ns": sim_ns, "response": response}
        print(json.dumps(record, sort_keys=True, allow_nan=False), flush=True)
        if "position_ref" in response:
            break
    else:
        print(json.dumps({"trajectory_generated": False}), flush=True)
        raise SystemExit(2)
