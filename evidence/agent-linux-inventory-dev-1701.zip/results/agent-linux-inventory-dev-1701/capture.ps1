$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$probes = [ordered]@{
    os = 'cat /etc/os-release; uname -r'
    toolchain = 'cmake --version; ninja --version; g++ --version; git --version'
    packages = 'dpkg-query -W libasio-dev libtinyxml2-dev libssl-dev libboost-dev libfastcdr-dev libfastrtps-dev libfoonathan-memory-dev libspdlog-dev cmake ninja-build g++'
    agent = 'command -v MicroXRCEAgent; command -v micro_ros_agent; command -v colcon'
    cmake_packages = 'find /usr /usr/local /opt -maxdepth 5 -type f \( -iname "*fastcdr*config*.cmake" -o -iname "*fastrtps*config*.cmake" -o -iname "*fastdds*config*.cmake" -o -iname "*asio*config*.cmake" -o -iname "*tinyxml2*config*.cmake" \) -print 2>/dev/null'
    libraries = 'ldconfig -p | grep -Ei "fastcdr|fastrtps|tinyxml|ssl|crypto|foonathan|spdlog"'
    memory = 'free -h'
}
$runs = @()
foreach ($name in $probes.Keys) {
    $command = $probes[$name]
    $started = (Get-Date).ToUniversalTime().ToString('o')
    $output = & wsl.exe -d Ubuntu -- bash -lc $command 2>&1
    $code = $LASTEXITCODE
    $record = [ordered]@{
        name = $name
        utc = $started
        command = "wsl.exe -d Ubuntu -- bash -lc '$command'"
        exit_code = $code
        output = @($output | ForEach-Object { [string]$_ })
    }
    $runs += $record
}
$hostMemory = Get-CimInstance Win32_OperatingSystem
$manifest = [ordered]@{
    schema = 'agent-linux-inventory-v1'
    utc_completed = (Get-Date).ToUniversalTime().ToString('o')
    host_free_physical_kib = [int64]$hostMemory.FreePhysicalMemory
    host_total_physical_kib = [int64]$hostMemory.TotalVisibleMemorySize
    wsl_distribution = 'Ubuntu'
    probes = $runs
}
$manifest | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $here 'inventory.json') -Encoding utf8
