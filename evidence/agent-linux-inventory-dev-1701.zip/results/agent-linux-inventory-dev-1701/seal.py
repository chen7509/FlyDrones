"""Seal the read-only Ubuntu Agent inventory with a per-member SHA-256 manifest."""

import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


root = Path(__file__).resolve().parents[2]
evidence_dir = Path(__file__).resolve().parent
target = root / "evidence/agent-linux-inventory-dev-1701.zip"
members = [
    "results/agent-linux-inventory-dev-1701/capture.ps1",
    "results/agent-linux-inventory-dev-1701/inventory.json",
    "results/agent-linux-inventory-dev-1701/host-preflight.json",
    "results/agent-linux-inventory-dev-1701/independent_readback.py",
    "results/agent-linux-inventory-dev-1701/seal.py",
    "results/fastdds-gitlink-objects-dev-1701/build-sources/agent-SuperBuild.cmake",
    "results/fastdds-gitlink-objects-dev-1701/build-sources/fastdds-CMakeLists.txt",
    "results/fastdds-gitlink-objects-dev-1701/build-sources/fastdds-eprosima_libraries.cmake",
    "docs/superpowers/specs/2026-10-10-agent-linux-inventory-design.md",
    "docs/superpowers/plans/2026-10-10-agent-linux-inventory.md",
    "docs/AGENT_LINUX_INVENTORY_REPORT.md",
]
contents = {name: (root / name).read_bytes() for name in members}
manifest = {
    "schema": "agent-linux-inventory-archive-v1",
    "members": {
        name: {"bytes": len(blob), "sha256": hashlib.sha256(blob).hexdigest()}
        for name, blob in sorted(contents.items())
    },
}
manifest_blob = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
target.parent.mkdir(exist_ok=True)
with ZipFile(target, "w", ZIP_DEFLATED) as archive:
    for name, blob in sorted(contents.items()):
        archive.writestr(name, blob)
    archive.writestr("archive-manifest.json", manifest_blob)
with ZipFile(target) as archive:
    assert set(archive.namelist()) == set(contents) | {"archive-manifest.json"}
    restored = json.loads(archive.read("archive-manifest.json"))
    assert restored == manifest
    for name, entry in manifest["members"].items():
        blob = archive.read(name)
        assert len(blob) == entry["bytes"]
        assert hashlib.sha256(blob).hexdigest() == entry["sha256"]
        assert archive.getinfo(name).CRC is not None
print(target)
print("sha256", hashlib.sha256(target.read_bytes()).hexdigest())
print("members", len(members) + 1)
