"""Read the sealed inventory without invoking WSL or the capture script."""

import json
from pathlib import Path


root = Path(__file__).resolve().parents[2]
evidence = Path(__file__).resolve().parent
inventory = json.loads((evidence / "inventory.json").read_text(encoding="utf-8-sig"))
host = json.loads((evidence / "host-preflight.json").read_text(encoding="utf-8-sig"))
probes = {p["name"]: p for p in inventory["probes"]}


def lines(name: str) -> str:
    return "\n".join(probes[name]["output"])


assert inventory["schema"] == "agent-linux-inventory-v1"
assert len(probes) == 7
assert probes["toolchain"]["exit_code"] == 0
assert "cmake version 3.28.3" in lines("toolchain")
assert "1.11.1" in lines("toolchain")
assert "Ubuntu 24.04.4 LTS" in lines("os")
packages = lines("packages")
for needle in (
    "libboost-dev:amd64\t1.83.0.1ubuntu2",
    "libssl-dev:amd64\t3.0.13-0ubuntu3.16",
    "libtinyxml2-dev:amd64\t10.0.0+dfsg-2",
    "no packages found matching libasio-dev",
    "no packages found matching libfastcdr-dev",
    "no packages found matching libfastrtps-dev",
    "no packages found matching libfoonathan-memory-dev",
    "no packages found matching libspdlog-dev",
):
    assert needle in packages, needle
assert probes["packages"]["exit_code"] == 1
assert probes["agent"]["exit_code"] == 1
assert "tinyxml2-config.cmake" in lines("cmake_packages")
assert "libtinyxml2.so" in lines("libraries")
assert inventory["host_free_physical_kib"] < 1024 * 1024
assert host["free_physical_kib"] < 1024 * 1024
assert not host["matching_processes"]
assert not host["running_containers"]

source = (root / "results/fastdds-gitlink-objects-dev-1701/build-sources/fastdds-eprosima_libraries.cmake").read_text(
    encoding="utf-8"
)
assert 'option(THIRDPARTY_UPDATE "Activate the auto update of internal thirdparties" ON)' in source
assert 'if(NOT (THIRDPARTY_${package} STREQUAL "FORCE"))' in source
assert 'if((THIRDPARTY_${package} STREQUAL "FORCE")' in source
report = (root / "docs/AGENT_LINUX_INVENTORY_REPORT.md").read_text(encoding="utf-8")
assert "not a CMake selection result" in report
assert "Docker image was not started" in report
assert "0.873 RTF" in report

print("inventory and report read-back passed: 7 probes, package candidates, selection limits, memory gate")
