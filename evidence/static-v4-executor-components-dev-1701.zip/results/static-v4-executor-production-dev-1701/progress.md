# SDD ledger - plan: docs/superpowers/plans/2026-10-15-loader-selected-path-production.md
Task4 inline/TDD at566140c1. Goal blocked read-only;Task1..3softwarecomplete,Task5pending. No consumed code execution.
Ruling: preserve all evidence and quiet heartbeat;existing worktree/personal publication authorized.
Ruling: distinct primitive canonical codec and standalone identity/bootstrap body;onlyos/sys/builtin time on Linux, external decoding. Exact fixed receipts,not callertruthiness. SDK APIs retain samePID/nonce;future actual admission remains pending.

Initial recorder rewrite helper failed beforewrite(substring),so first18missinginterface/1guardpass run recorded prior15declaredsourcepaths,not newtest/primitive file pins;no backfill. Laterrecorder8declaredincludescurrentcode/test/self. Initial resourcehelper exposed one classified competitor row in toolconsole and retained initial-public/stdout;both are now LOCAL_UNPUBLISHED excluded alongsidefullprivateinventory. Additive publicderivative hascounter/hash/sizeonly;originalbytesunchanged. No newtarget/native action or gate refresh.
