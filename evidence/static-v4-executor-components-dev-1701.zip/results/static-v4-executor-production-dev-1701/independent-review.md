# Independent review — partial Task4 static-v4 components

Review result: **C0 / I4 / M0**. This is one fresh source-only review of the five new files and their Task3 API joins at the supplied baseline. The findings concern concrete implementations already present, with production execution still hard-denied. They are not claims that Task4 is complete or that absent reviewed recipe/package/license coverage is itself an implementation regression.

## Scope and evidence limits

Read the current loader-selected-path production design/plan, component report, prior Task3 NEXT_PHASE, all five new files, and the relevant Task3 preparation/study/pipeline boundaries. No tests, project imports, target/Linux/SDK/process/control/permission/native commands or observations were executed. Existing reported 54-pass/Ruff results are supplied historical evidence, not independently rerun evidence.

The exact reviewed recipe, publication receipt and remaining I/O/control integration remain pending; Task4/5 checkboxes are unchecked. The public observer/bootstrap/coordinator pending refusals are present. Source-only creation of the literal coordinator is not an actual attempt. No new actual firstfacts, claim, SDK-start, scope or study is asserted. All qualifications/readiness stay false. No private process identities or inventory content are reproduced here.

## I1 — Scope reads always apply regular receipt length semantics to virtual files

**Locations:** tools/benchmark/static_v4_bootstrap.py:598-608 and :901-902, :925; the copied reader also appears in tools/benchmark/static_v4_identity.py:598-608.

actual_scope() reads /proc/self/cgroup and the cgroup limit files using read_bytes(). That helper requires the number of bytes read to equal fstat().st_size. Procfs cgroup content reports a zero file size despite nonempty content; cgroup control files also do not expose ordinary on-disk payload lengths. Consequently, valid current scope facts are rejected as "receipt changed" before the SDK-start marker can be established. Removing the pending guard alone would consume a claimed attempt and then deterministically refuse at the first scope read, independent of the recipe's completeness.

Keep strict size/identity checking for ordinary retained receipt files, and use a separate bounded primitive reader for the literal procfs/cgroup facts that validates the supported virtual-file protocol without treating st_size as content length.

**Suggested inert regression:** an explicit fake descriptor backend reports regular mode and size=0, yields a nonempty unified cgroup record, then EOF; a second case reports a virtual control-file size larger than its numeric payload. Exercise actual scope-reading logic with inert manager/query facts and require successful parsing plus the same hard content cap. Separately retain ordinary receipt mutation/short-read refusal. No real procfs, target, SDK or child is needed.

## I2 — Windows child timeout bypasses the promised kill escalation

**Location:** tools/benchmark/static_v4_executor.py:351-364, particularly :359-362.

Popen.wait(timeout=5) raises subprocess.TimeoutExpired, not the built-in TimeoutError caught here. If an owned launcher remains alive after terminate(), cleanup exits on that exception before reaching the kill iteration. The matching-scope release may subsequently fail or have no bootstrap receipt, leaving the owned Popen without the bounded terminate/kill/wait lifecycle the component promises. The finally block preserves an earlier primary error, but that does not finish owned child cleanup.

Catch the actual subprocess timeout exception and continue to the bounded kill/wait stage; preserve any earlier error and escaped-closure UNKNOWN.

**Suggested inert regression:** pass cleanup() a fake Popen whose first wait raises subprocess.TimeoutExpired and whose second wait returns. Assert terminate, wait, kill, wait order without creating a child. Add a second case where both waits expire and confirm an explicit final unavailable-wait outcome after both attempts. The current coordinator tests replace cleanup itself, so they cannot catch this mismatch.

## I3 — First coordinator postverification prevents the later Task3 finished audit

**Locations:** tools/benchmark/static_v4_identity.py:787-889, especially :845-846 and :868-869; copied in static_v4_bootstrap.py at the same lines. Join: tools/benchmark/static_v4_executor.py:389-398; tools/benchmark/calibration_capture_pipeline_v4.py:502-506 and :568-582.

NativeWindowsBackend.postverify() calls revalidate_finished_study(), which exclusively creates post-request.frame and postidentity-command.json and runs the one postidentity observer. After that returns, the coordinator deliberately records CHILD_ZERO_STATIC_AUDIT_PENDING. The existing Task3 Windows verify path then calls that same receiver before its full finished transport/graph audit. The receiver tries to create post-request.frame again and raises FileExistsError before Task3 can audit a valid completed study. Deleting the files or rerunning the observer would violate the once-only evidence lifecycle.

Separate the one-time postidentity acquisition from later validation of its retained exact request/response/child receipts, or invoke the complete Task3 finished audit during the single receiver acquisition and provide a read-only repeatable verifier. Preserve all first observation bytes and refuse changed study/index/source/request joins.

**Suggested inert regression:** model a successful coordinator postverify followed by the public Task3 Windows verify join using fake finished files and an explicit inert observer backend. The second audit must consume retained receipts, perform no second observation/output creation, and reach Task3 semantic auditing. Changed retained receipts or study/index bytes must refuse. Do not use native commands or delete/recreate once files to make the regression pass.

## I4 — Completion can retain a nonfailure state after cleanup/release fails

**Location:** tools/benchmark/static_v4_executor.py:67-90, particularly :71-82 before :84.

The main try sets state=CHILD_ZERO_STATIC_AUDIT_PENDING after a zero child and successful postverify. If cleanup() or release() then raises as the first error, finally assigns primary but never changes state or adds its error. completion is persisted with the earlier nonfailure state and without the failure that is immediately raised to the caller. A failed fresh scope observation/matching release therefore has no truthful terminal failure in the canonical completion record. This is a lifecycle evidence defect even though the state never claims qualification or physical readiness.

Before persisting completion, reflect any primary cleanup/release failure in the terminal state and error while retaining child_exit, consumption and any successful partial release facts. Preserve earlier errors and secondary notes. A completion writer failure also needs an explicitly retained durability limitation via the planned independent fallback rather than a success assertion.

**Suggested inert regression:** extend the existing inert coordinator lifecycle with separate cleanup-first-error and release-first-error cases. Capture a snapshot of the completion argument and assert FAILED, the correct primary error, child_exit=0 and consumed=true; make cleanup/release plus completion writer fail together to verify the original error remains primary. No real launch/control action is needed.

## Pending work distinguished from defects

No finding is raised merely because reviewed-recipe.frame/publication is absent, full current native/package/license/source/input coverage is pending, low-level integration is unfinished, or production refuses to dispatch. Those are explicitly disclosed pending features and prevent native approval. The findings above are contradictions within implemented reader, cleanup, receiver join and terminal-record behavior, so they should be addressed during the single authorized executor fix pass before any later completion/review/seal decision. This report grants no native dispatch, attempt retry, qualification, physical readiness or publication authority.
