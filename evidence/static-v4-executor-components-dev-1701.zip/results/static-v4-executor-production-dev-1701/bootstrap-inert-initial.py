"""Primitive SDK admission entry; no project/JSON/SDK import before validation."""
import sys
if 'time' not in sys.builtin_module_names:
    raise RuntimeError('builtin time required')
import os
import time


if __name__=='__main__':
    raise SystemExit('standalone bootstrap requires complete fixed coordinator protocol')
