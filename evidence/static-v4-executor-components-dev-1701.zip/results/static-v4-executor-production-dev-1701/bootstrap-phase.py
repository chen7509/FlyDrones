import hashlib,json,subprocess
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent
def save(name,b):
    with (raw/name).open('xb') as f:f.write(b)
def sha(b):return hashlib.sha256(b).hexdigest()
names=['docs/TARGET_BEARING_STUDY_V4_PRODUCTION_REPORT.md','docs/TARGET_BEARING_STATIC_V3_HARNESS_FAILURE_REPORT.md',
 'docs/superpowers/plans/2026-10-15-loader-selected-path-production.md','docs/superpowers/specs/2026-10-15-loader-selected-path-production-design.md',
 'results/study-v4-production-dev-1701/NEXT_PHASE.md','evidence/study-v4-production-publication.json',
 'evidence/flydrones-history-through-admitted-executor-dev-1701.json','evidence/flydrones-history-through-loader-path-research-dev-1701.json']
rows=[]
for name in names:
    b=(root/name).read_bytes();b.decode('utf8')
    if name.endswith('.json'):json.loads(b)
    rows.append(dict(path=name,bytes=len(b),sha256=sha(b),full_read=True))
save('preflight-read.json',json.dumps(rows,indent=2).encode())
files=subprocess.check_output(['git','ls-files','-z','src','tools','tests','configs']).split(b'\0')
save('product-before.json',json.dumps([dict(path=x.decode(),bytes=len(b:=(root/x.decode()).read_bytes()),sha256=sha(b)) for x in files if x],indent=2).encode())
save('initial-readonly.py',(root/'results/study-v4-production-dev-1701/initial-readonly.py').read_bytes())
p=subprocess.run(['python',str(raw/'initial-readonly.py')],capture_output=True,timeout=65)
save('initial-readonly.stdout',p.stdout);save('initial-readonly.stderr',p.stderr);assert p.returncode==0
print(p.stdout.decode())
save('progress.md',b'# SDD ledger - plan: docs/superpowers/plans/2026-10-15-loader-selected-path-production.md\nTask4 inline/TDD at566140c1. Goal blocked read-only;Task1..3softwarecomplete,Task5pending. No consumed code execution.\nRuling: preserve all evidence and quiet heartbeat;existing worktree/personal publication authorized.\nRuling: distinct primitive canonical codec and standalone identity/bootstrap body;onlyos/sys/builtin time on Linux, external decoding. Exact fixed receipts,not callertruthiness. SDK APIs retain samePID/nonce;future actual admission remains pending.\n')
