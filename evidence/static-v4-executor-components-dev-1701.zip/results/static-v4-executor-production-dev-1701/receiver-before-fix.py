def revalidate_finished_study(path, sha, *, require_absent=True):
    """Windows-only real receipt receiver; no caller-provided identity grant."""
    from tools.benchmark.static_v4_executor import OUT, ROOT, native_path, production_boundary

    production_boundary()
    import hashlib
    import json
    from pathlib import Path

    def payload(p, limit=FRAME_CAP):
        with Path(p).open("rb") as stream:
            data = stream.read(limit + 1)
        require(len(data) <= limit, "finished metadata byte bound")
        return data

    def digest(b):
        return hashlib.sha256(b).hexdigest()

    require(Path(path).absolute() == OUT / "frozen-study-v4/study.json", "literal finished study required")
    require(
        not require_absent or not (ROOT / "results/target-bearing-physical-capture-dev-1701").exists(),
        "physical fixed attempt already exists",
    )
    recipe = decode_primitive(payload(OUT / "recipe.frame"))
    pre = decode_identity(payload(OUT / "preidentity.frame"))
    claim = decode_primitive(payload(OUT / "claim.frame"))
    child = decode_primitive(payload(OUT / "child-exit.frame"))
    require(recipe["source_root"] == native_path(ROOT), "native source root differs from literal host project")
    study_bytes = payload(path)
    require(digest(study_bytes) == sha, "actual finished study bytes differ")
    folder = OUT / "frozen-study-v4"
    index_bytes = payload(folder / "finished-artifact-index.json")
    index = json.loads(index_bytes)
    binding = json.loads(payload(folder / "runtime-binding-v4.json"))
    preparation = json.loads(payload(folder / "preparation.json"))
    bill = json.loads(payload(folder / "sdk/entry-dependencies/entry-bill.json"))
    members = [r["source"] for r in index["files"]] + binding["baseline"]["files"] + preparation["pre"]["files"]
    selected = (
        {r["requested"] for r in pre["files_before"]}
        | {r["requested"] for r in members}
        | {r["requested"] for r in bill["files"]}
    )
    selected.update(
        {
            native_path(folder / "study.json"),
            native_path(folder / "finished-artifact-index.json"),
            native_path(folder / "sdk-complete.json"),
        }
    )
    require(len(selected) <= 8192, "finished native pin membership bound")
    revised = dict(recipe, files=sorted(selected))
    request = dict(
        schema="static-post-request-v4",
        recipe=revised,
        initial_recipe_sha256=digest(encode_primitive(recipe)),
        study_sha256=sha,
        index_sha256=digest(index_bytes),
    )
    with (OUT / "post-request.frame").open("xb") as stream:
        stream.write(encode_primitive(request))
    import subprocess

    result = subprocess.run(
        [
            "wsl",
            "-d",
            "Ubuntu",
            "--",
            "/usr/bin/timeout",
            "--signal=TERM",
            "--kill-after=5s",
            "30s",
            "/usr/bin/python3",
            "-S",
            native_path(ROOT / "tools/benchmark/static_v4_identity.py"),
            "--observe-fixed-post",
        ],
        cwd=ROOT,
        capture_output=True,
        timeout=45,
    )
    with (OUT / "postidentity-command.json").open("x", encoding="utf8") as stream:
        json.dump(dict(exit=result.returncode, stdout_hex=result.stdout.hex(), stderr_hex=result.stderr.hex()), stream)
    require(result.returncode == 0, "actual primitive postidentity failed")
    post = decode_identity(payload(OUT / "postidentity.frame"))
    require(
        post["recipe_sha256"] == digest(encode_primitive(revised)) and {r["requested"] for r in post["files_before"]} == selected,
        "exact postrequest membership differs",
    )
    validated = audit_finished_native_receipts(recipe, pre, post, claim, child)
    # Full current host source bytes must still match independently sampled
    # native pre/post pins. No Windows hash replaces those Linux observations.
    from tools.benchmark.static_v4_executor import NativeWindowsBackend

    require(NativeWindowsBackend.sources(None) == recipe["source_sha256"], "current source changed after native receipts")
    return dict(
        schema="validated-static-prepost-receipts-v4",
        files=validated["files"],
        source_root=recipe["source_root"],
        study_sha256=sha,
        index_sha256=digest(index_bytes),
        sdk_exit=child["exit"],
    )
