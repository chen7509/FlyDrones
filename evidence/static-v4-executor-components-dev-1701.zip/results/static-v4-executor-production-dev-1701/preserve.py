import hashlib,json
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def save(name,v):
    with (raw/name).open('x',encoding='utf8') as f:json.dump(v,f,indent=2)
prior=json.loads((root/'results/study-v4-production-dev-1701/historical-archives-postsoftware.json').read_bytes())['members']
prior.append(dict(path='evidence/study-v4-production-dev-1701.zip',bytes=23633448,sha256='7235982e96c088d43641f20d8add3d2092d3ceb35472de8a17a00b92d484ad9d'))
assert len(prior)==292 and {r['path'] for r in prior}=={p.relative_to(root).as_posix() for p in (root/'evidence').glob('*.zip')}
for row in prior:
    digest=hashlib.sha256();size=0
    with (root/row['path']).open('rb') as f:
        while block:=f.read(1048576):size+=len(block);digest.update(block)
    assert size==row['bytes'] and digest.hexdigest()==row['sha256'],row['path']
save('historical-archives-postsoftware.json',dict(members=prior,count=len(prior),bytes=sum(r['bytes'] for r in prior),scope='POSTsoftware preservation;not native prepin'))
before=json.loads((raw/'product-before.json').read_bytes())
for row in before:assert sha((root/row['path']).read_bytes())==row['sha256'],row['path']
save('product-preservation-postsoftware.json',dict(count=len(before),all_old_product_byte_same=True))
parent=root/'results/target-bearing-runtime-freeze-v4-dev-1701'
members=sorted(p.relative_to(parent).as_posix() for p in parent.rglob('*') if p.is_file())
assert members==['run-static-preparation-v4.py'],members
assert not (root/'results/target-bearing-physical-capture-dev-1701').exists()
save('software-source-only-state.json',dict(v4_parent_exists=True,only_members=members,claim_firstfacts_marker_study_absent=True,
 actual_scope_or_sdk_command=False,v4_attempt_consumed=False,physical_attempt_absent=True,scope='source-only observation;not admission/escaped-process proof'))
print(json.dumps(dict(old_zip_count=len(prior),old_zip_bytes=sum(r['bytes'] for r in prior),old_product_count=len(before),all_old_byte_same=True,new_parent_source_only=True)))
