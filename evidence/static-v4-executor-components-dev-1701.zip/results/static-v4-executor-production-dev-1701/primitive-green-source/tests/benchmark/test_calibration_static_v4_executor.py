"""Inert production executor and primitive receipt behavior; never dispatch."""
import importlib
import builtins
import sys
from pathlib import Path
import pytest

ROOT=Path(__file__).resolve().parents[2]


def test_default_guard_is_installed_before_new_executor_body():
    import subprocess
    assert subprocess.Popen._execute_child.__name__=='denied'


@pytest.mark.parametrize('value',[None,False,True,0,-42,'字符串',b'\x00raw',[1,'two'],{'schema':'inert','values':[None,True,5]}])
def test_primitive_codec_exact_roundtrip(value):
    p=importlib.import_module('tools.benchmark.static_v4_identity')
    assert p.decode_primitive(p.encode_primitive(value))==value


@pytest.mark.parametrize('data',[b'',b'v4bad',b'V4F1i00;',b'V4F1nextra',b'V4F1d2:s1:ai1;s1:ai2;',b'V4F1l99999999:'])
def test_primitive_decoder_denies_malformed_duplicate_or_partial(data):
    p=importlib.import_module('tools.benchmark.static_v4_identity')
    with pytest.raises(ValueError):p.decode_primitive(data)


def test_primitive_hash_matches_independent_host_hash():
    import hashlib
    p=importlib.import_module('tools.benchmark.static_v4_identity')
    for data in (b'',b'abc',b'x'*64,b'x'*4097):
        assert p.sha256(data)==hashlib.sha256(data).hexdigest()


@pytest.mark.parametrize('name',['static_v4_identity','static_v4_bootstrap'])
def test_primitive_module_import_and_main_are_inert_before_commands(name,monkeypatch):
    source=(ROOT/'tools/benchmark'/(name+'.py')).read_bytes()
    original=builtins.__import__;calls=[]
    def restricted(module,*args,**kwargs):
        if module in ('sys','os','time'):return original(module,*args,**kwargs)
        calls.append(module);raise AssertionError('nonprimitive import')
    def deny(*a,**k):raise AssertionError('unexpected IO')
    for main in (False,True):
        namespace=dict(__name__='__main__' if main else 'inert',__file__=str(ROOT/'tools/benchmark'/(name+'.py')))
        with monkeypatch.context() as patch:
            patch.setattr(builtins,'open',deny);patch.setattr(builtins,'__import__',restricted)
            if main:
                with pytest.raises(SystemExit):exec(compile(source,name,'exec'),namespace)
            else:exec(compile(source,name,'exec'),namespace)
    assert not calls
