from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent
source=(root/'tools/benchmark/static_v4_identity.py').read_text(encoding='utf8').split("if __name__=='__main__':")[0]
body=r'''

# This standalone file carries identical audited primitive definitions rather
# than importing a project module before admission. Generated source is pinned.

def actual_scope(recipe):
    require(os.getuid()>=0,'actual ownUID required')
    unit=recipe['unit'];require(unit=='fly-calibration-prepare-'+recipe['nonce'][:24]+'.scope','nonce-bound unit required')
    group=read_bytes('/proc/self/cgroup',65536).decode().strip().splitlines()
    require(len(group)==1 and group[0].startswith('0::'),'unified own cgroup required')
    cg=group[0][3:];require(cg.endswith('/'+unit) and '..' not in cg.split('/'),'own exact unit cgroup required')
    env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','XDG_RUNTIME_DIR':'/run/user/'+str(os.getuid())}
    row=query(['/usr/bin/systemctl','--user','show',unit,'--property=InvocationID','--property=ControlGroup'],env)
    require(row['exit']==0 and row['error'] is None and row['cleanup']['waited'] and row['reader_complete'] and not bytes.fromhex(row['stderr_hex']),'current user-manager scope query failed')
    props={}
    for line in bytes.fromhex(row['stdout_hex']).decode().splitlines():
        key,value=line.split('=',1);require(key not in props,'duplicate scope property');props[key]=value
    require(set(props)=={'InvocationID','ControlGroup'} and props['ControlGroup']==cg and len(props['InvocationID'])==32 and all(c in '0123456789abcdef' for c in props['InvocationID']),'actual current scope properties differ')
    limits={key:read_bytes('/sys/fs/cgroup'+cg+'/'+key,4096).decode().strip() for key in recipe['static_limits']}
    return dict(uid=os.getuid(),pid=os.getpid(),unit=unit,InvocationID=props['InvocationID'],ControlGroup=cg,limits=limits,query=row)


def production_recipe(recipe):
    root=source_root()
    required={'schema','source_root','nonce','unit','source_sha256','files','versions','sdk_environment','static_limits'}
    require(set(recipe)==required and recipe['schema']=='static-recipe-v4' and recipe['source_root']==root and os.getcwd()==root,'literal complete production recipe required')
    require(type(recipe['nonce']) is str and len(recipe['nonce'])==64 and all(c in '0123456789abcdef' for c in recipe['nonce']),'recipe nonce invalid')
    require(recipe['static_limits']=={'memory.max':'536870912','memory.swap.max':'0','cpu.max':'100000 100000','pids.max':'64'},'static limits changed')
    expected_env={'HOME':'/home/yuchen7509','PATH':'/usr/bin:/bin','LANG':'C.UTF-8','PYTHONPATH':root+'/src:'+root,
                  'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'}
    require(recipe['sdk_environment']==expected_env,'SDK invocation environment differs')
    actual=[]
    for part in ('src/flydrones','tools/benchmark','tools/connectome'):
        for directory,dirs,files in os.walk(root+'/'+part):
            dirs[:]=[d for d in dirs if d!='__pycache__']
            actual.extend((directory+'/'+f)[len(root)+1:] for f in files if f.endswith('.py'))
    actual.append('results/target-bearing-runtime-freeze-v4-dev-1701/run-static-preparation-v4.py')
    require(set(recipe['source_sha256'])==set(actual),'full current source membership differs')
    require(len(recipe['files'])==len(set(recipe['files'])) and len(recipe['files'])<=8192,'complete bounded input membership required')
    required_paths={root+'/'+name for name in actual}|{'/usr/bin/sha256sum','/usr/bin/python3','/usr/bin/ldd','/usr/bin/readelf','/lib64/ld-linux-x86-64.so.2'}
    require(required_paths<=set(recipe['files']),'required native/code inputs absent')
    require(recipe['versions'] and all(type(a) is list and a and a[0] in recipe['files'] for a in recipe['versions']),'pinned native version argv required')
    return recipe


def current_receipts():
    observer_boundary();fixed=fixed_paths()
    recipe=production_recipe(decode_primitive(read_bytes(fixed['recipe'])))
    pre=decode_primitive(read_bytes(fixed['pre']));claim=decode_primitive(read_bytes(fixed['claim']))
    scope=actual_scope(recipe)
    return fixed,recipe,pre,claim,scope


def revalidate_sdk_reference(ticket):
    fixed,recipe,pre,claim,scope=current_receipts()
    marker=decode_primitive(read_bytes(fixed['marker']))
    now=time.monotonic_ns()
    require(type(marker.get('started_monotonic_ns')) is int and 0<=now-marker['started_monotonic_ns']<=180_000_000_000,'SDK start age invalid')
    result=validate_sdk_ticket(ticket,actual_scope=scope,recipe=recipe,preidentity=pre,claim=claim,marker=marker,now=marker['started_monotonic_ns'])
    # Full fresh Linux byte evidence at each preparation/publication boundary.
    current=[file_pin(path) for path in recipe['files']]
    require(current==pre['files_before'],'current input/source/tool bytes differ from native preidentity')
    return result


def enter_sdk():
    fixed,recipe,pre,claim,scope=current_receipts()
    audit_preidentity(pre,recipe=recipe,now=time.monotonic_ns())
    require([file_pin(path) for path in recipe['files']]==pre['files_before'],'SDK preimport current pin differs')
    require(scope['limits']==recipe['static_limits'],'actual scope limits differ before SDK')
    # Current scope observations are facts, not coordinator guesses.
    write_exclusive(fixed['parent']+'/bootstrap-scope-before.frame',scope)
    marker=dict(schema='static-sdk-start-v4',pid=os.getpid(),uid=os.getuid(),nonce=recipe['nonce'],InvocationID=scope['InvocationID'],
                ControlGroup=scope['ControlGroup'],claim_sha256=sha256(encode_primitive(claim)),started_monotonic_ns=time.monotonic_ns())
    write_exclusive(fixed['marker'],marker)
    ticket=dict(schema='static-sdk-ticket-reference-v4',nonce=recipe['nonce'],unit=recipe['unit'],InvocationID=scope['InvocationID'],
                ControlGroup=scope['ControlGroup'],claim_sha256=marker['claim_sha256'],recipe_sha256=sha256(encode_primitive(recipe)),
                preidentity_sha256=sha256(encode_primitive(pre)),sdk_start_sha256=sha256(encode_primitive(marker)))
    revalidate_sdk_reference(ticket)
    # No project import above this point. Install this actual standalone module
    # under the literal API name expected by inert prepare/study entry modules.
    sys.modules['tools.benchmark.static_v4_bootstrap']=sys.modules[__name__]
    sys.path[:0]=[fixed['root']+'/src',fixed['root']]
    from tools.benchmark.prepare_calibration_capture_v4 import prepare_v4
    return prepare_v4(ticket)


if __name__=='__main__':
    if sys.argv[1:]!=['--admitted-once'] or sys.platform!='linux' or 'pytest' in sys.modules or 'PYTEST_CURRENT_TEST' in os.environ:
        raise SystemExit('standalone bootstrap denied before receipt IO')
    enter_sdk()
'''
target=root/'tools/benchmark/static_v4_bootstrap.py'
with (raw/'bootstrap-before-sync.py').open('xb') as f:f.write(target.read_bytes())
target.write_text(source+body,encoding='utf8')
print('standalone bootstrap source materialized;not executed')
