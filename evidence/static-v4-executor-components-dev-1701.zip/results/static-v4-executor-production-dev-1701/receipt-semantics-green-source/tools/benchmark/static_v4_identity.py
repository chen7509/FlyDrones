"""Standalone primitive identity framing; native observation has an explicit gate."""
import sys
if 'time' not in sys.builtin_module_names:
    raise RuntimeError('builtin time required')
import os
import time

CAP=2*1024**2
FRAME_CAP=16*1024**2


def encode_primitive(value):
    def part(v,depth):
        if depth>32:raise ValueError('primitive depth bound')
        if v is None:return b'n'
        if type(v) is bool:return b't' if v else b'f'
        if type(v) is int:return b'i'+str(v).encode('ascii')+b';'
        if type(v) in (bytes,str):
            data=v.encode('utf8') if type(v) is str else v
            return (b's' if type(v) is str else b'x')+str(len(data)).encode('ascii')+b':'+data
        if type(v) is list:return b'l'+str(len(v)).encode('ascii')+b':'+b''.join(part(x,depth+1) for x in v)
        if type(v) is dict and all(type(k) is str for k in v):
            return b'd'+str(len(v)).encode('ascii')+b':'+b''.join(part(k,depth+1)+part(v[k],depth+1) for k in sorted(v))
        raise ValueError('unsupported primitive type')
    result=b'V4F1'+part(value,0)
    if len(result)>FRAME_CAP:raise ValueError('primitive frame bound')
    return result


def decode_primitive(data):
    if type(data) is not bytes or not data.startswith(b'V4F1') or len(data)>FRAME_CAP:
        raise ValueError('primitive frame required')
    at=4;events=0
    def number(delimiter,signed=False):
        nonlocal at
        end=data.find(delimiter,at)
        if end<0 or end-at>20:raise ValueError('bounded primitive integer required')
        token=data[at:end];at=end+1
        try:value=int(token)
        except ValueError:raise ValueError('primitive integer invalid') from None
        if str(value).encode('ascii')!=token or not signed and value<0:raise ValueError('canonical integer required')
        return value
    def item(depth):
        nonlocal at,events
        events+=1
        if at>=len(data) or depth>32 or events>262144:raise ValueError('primitive partial/depth/event bound')
        tag=data[at:at+1];at+=1
        if tag==b'n':return None
        if tag in (b't',b'f'):return tag==b't'
        if tag==b'i':return number(b';',True)
        if tag in (b's',b'x'):
            size=number(b':')
            if at+size>len(data):raise ValueError('partial primitive bytes')
            result=data[at:at+size];at+=size
            try:return result.decode('utf8') if tag==b's' else result
            except UnicodeError:raise ValueError('primitive UTF8 invalid') from None
        if tag in (b'l',b'd'):
            size=number(b':')
            if size>65536:raise ValueError('primitive container bound')
            if tag==b'l':return [item(depth+1) for _ in range(size)]
            result={};previous=None
            for _ in range(size):
                key=item(depth+1)
                if type(key) is not str or previous is not None and key<=previous:raise ValueError('primitive duplicate/order/key')
                previous=key;result[key]=item(depth+1)
            return result
        raise ValueError('primitive tag invalid')
    result=item(0)
    if at!=len(data):raise ValueError('primitive trailing bytes')
    return result


def sha256(data):
    """SHA256 using integers only; bootstrap imports no crypto extension."""
    constants=(0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
        0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
        0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
        0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
        0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
        0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
        0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
        0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2)
    state=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]
    padded=data+b'\x80'+b'\0'*((55-len(data))%64)+(len(data)*8).to_bytes(8,'big')
    def rotate(v,n):return ((v>>n)|(v<<(32-n)))&0xffffffff
    for offset in range(0,len(padded),64):
        w=[int.from_bytes(padded[offset+i:offset+i+4],'big') for i in range(0,64,4)]
        for i in range(16,64):
            a,b=w[i-15],w[i-2]
            w.append((w[i-16]+(rotate(a,7)^rotate(a,18)^(a>>3))+w[i-7]+(rotate(b,17)^rotate(b,19)^(b>>10)))&0xffffffff)
        a,b,c,d,e,f,g,h=state
        for k,v in zip(constants,w):
            t=(h+(rotate(e,6)^rotate(e,11)^rotate(e,25))+((e&f)^((~e)&g))+k+v)&0xffffffff
            u=((rotate(a,2)^rotate(a,13)^rotate(a,22))+((a&b)^(a&c)^(b&c)))&0xffffffff
            a,b,c,d,e,f,g,h=(t+u)&0xffffffff,a,b,c,(d+t)&0xffffffff,e,f,g
        state=[(x+y)&0xffffffff for x,y in zip(state,(a,b,c,d,e,f,g,h))]
    return ''.join('%08x'%v for v in state)


def utc():return time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())


def require(value,message):
    if not value:raise ValueError(message)


def strict_path(path):
    require(type(path) is str and path.startswith('/') and not path.startswith('//') and
            1<=len(path.encode('utf8'))<=4095 and '..' not in path.split('/') and
            not any(ord(c)<32 or 127<=ord(c)<=159 for c in path),'strict absolute declared path required')
    return path


def audit_preidentity(value,*,recipe,phase='pre',now=None):
    require(type(value) is dict and set(value)=={'schema','phase','nonce','recipe_sha256','source_root','source_sha256',
            'files_before','files_after','versions','error','started_monotonic_ns','ended_monotonic_ns','uid'},'exact identity schema required')
    require(value['schema']=='static-identity-v4' and value['phase']==phase and value['error'] is None,'complete successful identity required')
    require(value['nonce']==recipe['nonce'] and value['recipe_sha256']==sha256(encode_primitive(recipe)) and
            value['source_root']==recipe['source_root'] and value['source_sha256']==recipe['source_sha256'],'identity source/recipe joins differ')
    start,end=value['started_monotonic_ns'],value['ended_monotonic_ns']
    require(type(start) is int and type(end) is int and 0<=start<=end,'identity monotonic interval invalid')
    if now is not None:require(type(now) is int and 0<=now-end<=60_000_000_000,'identity stale or future')
    require(value['files_before']==value['files_after'],'global file pre/post differs')
    files=value['files_before'];known={r['requested']:r for r in files}
    require(len(known)==len(files) and set(known)==set(recipe['files']),'exact identity member set differs')
    for path,row in known.items():
        strict_path(path)
        require(set(row)=={'requested','resolved','links','identity','path_identity','bytes','sha256'},'full native pin required')
        require(type(row['bytes']) is int and row['bytes']>=0 and row['identity']==row['path_identity'] and
                row['identity']['size']==row['bytes'] and row['identity']['mode']&0o170000==0o100000,'native descriptor pin differs')
    for name,expected in recipe['source_sha256'].items():
        require(known[recipe['source_root']+'/'+name]['sha256']==expected,'current source SHA differs')
    require(len(value['versions'])==len(recipe['versions']),'version query membership differs')
    for q,expected in zip(value['versions'],recipe['versions']):
        require(q['argv']==expected and q['environment']=={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8'} and
                q['exit']==0 and q['error'] is None and q['reader_complete'] is True and q['cleanup']['waited'] is True and
                bytes.fromhex(q['stdout_hex']).strip() and not bytes.fromhex(q['stderr_hex']), 'version query incomplete/different')
    return value


def validate_sdk_ticket(ticket,*,actual_scope,recipe,preidentity,claim,marker,now):
    require(type(ticket) is dict and set(ticket)=={'schema','nonce','unit','InvocationID','ControlGroup',
            'claim_sha256','recipe_sha256','preidentity_sha256','sdk_start_sha256'},'exact untrusted ticket reference required')
    audit_preidentity(preidentity,recipe=recipe,now=now)
    require(type(marker) is dict and set(marker)=={'schema','pid','uid','nonce','InvocationID','ControlGroup','claim_sha256'},'original SDK-start marker required')
    require(set(claim)=={'schema','nonce','unit','recipe_sha256','preidentity_sha256','source_root'} and
            claim['schema']=='static-claim-v4' and claim['source_root']==recipe['source_root'],'literal claim differs')
    require(ticket['schema']=='static-sdk-ticket-reference-v4' and marker['schema']=='static-sdk-start-v4','SDK reference schema differs')
    for key in ('nonce','claim_sha256','recipe_sha256','preidentity_sha256','sdk_start_sha256'):
        require(type(ticket[key]) is str and len(ticket[key])==64 and all(c in '0123456789abcdef' for c in ticket[key]),'SDK reference digest invalid')
    require(ticket['nonce']==claim['nonce']==recipe['nonce']==marker['nonce'] and
            ticket['unit']==claim['unit']==recipe['unit']==actual_scope['unit'],'SDK nonce/unit differs')
    require(ticket['claim_sha256']==marker['claim_sha256']==sha256(encode_primitive(claim)) and
            ticket['recipe_sha256']==claim['recipe_sha256']==sha256(encode_primitive(recipe)) and
            ticket['preidentity_sha256']==claim['preidentity_sha256']==sha256(encode_primitive(preidentity)) and
            ticket['sdk_start_sha256']==sha256(encode_primitive(marker)),'actual receipt bytes/digests differ')
    require(actual_scope['uid']==preidentity['uid']==marker['uid'] and actual_scope['pid']==marker['pid'] and
            type(marker['pid']) is int and marker['pid']>0,'current own UID/SDK PID differs')
    require(ticket['InvocationID']==actual_scope['InvocationID']==marker['InvocationID'] and
            ticket['ControlGroup']==actual_scope['ControlGroup']==marker['ControlGroup'] and
            actual_scope['ControlGroup'].endswith('/'+ticket['unit']) and
            actual_scope['limits']==recipe['static_limits'],'current own invocation/group/limits differ')
    return dict(schema='revalidated-static-sdk-context-v4',sdk_pid=marker['pid'],ticket=ticket)


def retain_observation(body,emit):
    primary=None;result=None
    try:result=body(emit)
    except BaseException as exc:primary=exc
    try:emit(dict(terminal=True,error=repr(primary) if primary else None))
    except BaseException as exc:
        if primary is None:primary=exc
        else:primary.add_note('final writer secondary: '+repr(exc))
    if primary is not None:raise primary
    return result


if __name__=='__main__':
    raise SystemExit('direct identity CLI denied;coordinator primitive command contract required')
