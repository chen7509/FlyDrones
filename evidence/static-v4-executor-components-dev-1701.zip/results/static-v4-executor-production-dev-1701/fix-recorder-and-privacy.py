import hashlib,json
from pathlib import Path
raw=Path(__file__).resolve().parent
p=raw/'verify.py';before=p.read_bytes()
with (raw/'verify-initial-declared-prior-phase.py').open('xb') as f:f.write(before)
s=before.decode('utf8');start=s.index('files=');end=s.index('\ndef pins',start)
names=['tools/benchmark/static_v4_identity.py','tools/benchmark/static_v4_bootstrap.py','tools/benchmark/static_v4_executor.py',
 'results/target-bearing-runtime-freeze-v4-dev-1701/run-static-preparation-v4.py','tools/benchmark/software_process_boundary.py','tests/benchmark/conftest.py',
 'tests/benchmark/test_calibration_static_v4_executor.py','results/static-v4-executor-production-dev-1701/verify.py']
p.write_text(s[:start]+'files='+repr(names)+'\n'+s[end:],encoding='utf8')
private=json.loads((raw/'initial-resource-private.json').read_bytes())
public={k:private[k] for k in ('windows_available','wsl_available','docker_exit')}
public.update(classified_competitor_count=len(private['blocked']),docker_running_empty=private['docker_exit']==0 and private['docker_running']=='',
 initial_snapshot_only=True,dispatch_admission=False,original1GiB=private['windows_available']>=1073741824 and private['wsl_available']>=1073741824)
excluded=[]
for name in ('initial-resource-private.json','initial-resource-public.json','initial-readonly.stdout'):
    b=(raw/name).read_bytes();excluded.append(dict(path=(raw/name).relative_to(Path.cwd()).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
public['local_unpublished']=excluded
with (raw/'initial-resource-derived.json').open('x',encoding='utf8') as f:json.dump(public,f,indent=2)
with (raw/'progress.md').open('a',encoding='utf8') as f:f.write('\nInitial recorder rewrite helper failed beforewrite(substring),so first18missinginterface/1guardpass run recorded prior15declaredsourcepaths,not newtest/primitive file pins;no backfill. Laterrecorder8declaredincludescurrentcode/test/self. Initial resourcehelper exposed one classified competitor row in toolconsole and retained initial-public/stdout;both are now LOCAL_UNPUBLISHED excluded alongsidefullprivateinventory. Additive publicderivative hascounter/hash/sizeonly;originalbytesunchanged. No newtarget/native action or gate refresh.\n')
print(json.dumps({k:v for k,v in public.items() if k!='local_unpublished'}))
