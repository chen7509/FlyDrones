import hashlib
import json
import zipfile
from pathlib import Path

root=Path.cwd();raw=Path(__file__).resolve().parent
name='static-v4-executor-components-dev-1701'
archive=root/'evidence'/f'{name}.zip';mapping=root/'evidence'/f'{name}.sha256.json'
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,v):
    with p.open('xb') as stream:stream.write(json.dumps(v,ensure_ascii=False,indent=2).encode())
privacy=json.loads((raw/'initial-resource-derived.json').read_bytes())['local_unpublished']
excluded={root/r['path'] for r in privacy}
for row in privacy:
    b=(root/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
inventory=json.loads((raw/'initial-resource-private.json').read_bytes())
rows=inventory['windows']+inventory['wsl']
needles={r['argv_sha256'].encode() for r in rows if r.get('argv_sha256') not in (None,sha(b''))}
explicit=['tools/benchmark/static_v4_identity.py','tools/benchmark/static_v4_bootstrap.py','tools/benchmark/static_v4_executor.py',
 'results/target-bearing-runtime-freeze-v4-dev-1701/run-static-preparation-v4.py','tests/benchmark/test_calibration_static_v4_executor.py',
 'tools/benchmark/software_process_boundary.py','tests/benchmark/conftest.py','tools/benchmark/prepare_calibration_capture_v4.py',
 'tools/benchmark/calibration_capture_study_v4.py','tools/benchmark/calibration_capture_pipeline_v4.py',
 'docs/TARGET_BEARING_STATIC_V4_EXECUTOR_COMPONENT_REPORT.md','docs/TARGET_BEARING_STUDY_V4_PRODUCTION_REPORT.md',
 'docs/TARGET_BEARING_STATIC_V3_HARNESS_FAILURE_REPORT.md','docs/superpowers/plans/2026-10-15-loader-selected-path-production.md',
 'docs/superpowers/specs/2026-10-15-loader-selected-path-production-design.md',
 'evidence/flydrones-history-through-admitted-executor-dev-1701.json','evidence/flydrones-history-through-loader-path-research-dev-1701.json',
 'evidence/study-v4-production-publication.json']
files={root/p for p in explicit}|{p for p in raw.rglob('*') if p.is_file() and p not in excluded and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo')}
members=[];json_count=0
for p in sorted(files):
    b=p.read_bytes();path=p.relative_to(root).as_posix()
    assert not any(n in b for n in needles),path
    if p.suffix=='.json':
        try:stack=[json.loads(b.decode('utf-8-sig'))];json_count+=1
        except (ValueError,UnicodeError):stack=[]
        while stack:
            value=stack.pop()
            if isinstance(value,dict):
                if {'pid','name','argv_sha256'}<=value.keys():
                    assert not any(all(value.get(k)==r.get(k) for k in ('pid','name','argv_sha256')) for r in rows),path
                stack.extend(value.values())
            elif isinstance(value,list):stack.extend(value)
    members.append(dict(path=path,bytes=len(b),sha256=sha(b)))
save(mapping,dict(schema='static-v4-executor-components-exact-map-v1',members=members,private_excluded=privacy,
 nonempty_private_argv_hashes=len(needles),private_triples=len(rows),json_scanned=json_count,
 scope='Partial Task4 components only;all3 Task4/fullTask5 unchecked;pending production refusals;no native admission'))
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for row in members:z.write(root/row['path'],row['path'])
    z.write(mapping,mapping.relative_to(root).as_posix())
receipt=dict(archive=archive.relative_to(root).as_posix(),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),
 members=len(members)+1,mapped_members=len(members),uncompressed_bytes=sum(r['bytes'] for r in members),manifest_sha256=sha(mapping.read_bytes()),
 preseal_exact_set=[r['path'] for r in members],scope='partial software publication checkboxpending;Task4/5pending;postseal helpers/receipt/audits/publication/PR/automation outside')
save(raw/'seal-receipt.json',receipt)
print(json.dumps({k:v for k,v in receipt.items() if k!='preseal_exact_set'}))
