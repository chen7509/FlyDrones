"""One executor fix pass. Source transforms only; no native entry execution."""
from pathlib import Path

root = Path.cwd()
identity = root / 'tools/benchmark/static_v4_identity.py'
text = identity.read_text(encoding='utf8')
start = text.index('def revalidate_finished_study(')
end = text.index('\n\nif __name__ == "__main__":', start)
old = text[start:end]
with (Path(__file__).parent/'receiver-before-fix.py').open('x',encoding='utf8') as stream:
    stream.write(old)
body = old[old.index('    from tools.benchmark.static_v4_executor'):]
begin = body[:body.index('    with (OUT / "post-request.frame")')]
acquire = body[body.index('    with (OUT / "post-request.frame")'):body.index('    post = decode_identity')]
validate = body[body.index('    post = decode_identity'):]
def indent(value): return ''.join('    '+line if line.strip() else line for line in value.splitlines(keepends=True))
new = '''def acquire_finished_receipts(backend):
    request = backend.request()
    backend.acquire(request)
    return backend.validate(request)


def validate_retained_finished_receipts(backend):
    request = backend.request()
    return backend.validate(request)


def acquire_finished_study(path, sha, *, require_absent=True):
    return acquire_finished_receipts(NativeFinishedReceiver(path, sha, require_absent))


def revalidate_finished_study(path, sha, *, require_absent=True):
    """Repeatable read-only validation; never rerun a retained observation."""
    return validate_retained_finished_receipts(NativeFinishedReceiver(path, sha, require_absent))


class NativeFinishedReceiver:
    def __init__(self, path, sha, require_absent):
        self.path, self.sha, self.require_absent = path, sha, require_absent

    def request(self):
        path, sha, require_absent = self.path, self.sha, self.require_absent
'''
new += indent(begin)
new += '''        self.context = (OUT, ROOT, native_path, json, payload, digest, recipe, pre, claim, child, revised, selected, index_bytes)
        return request

    def acquire(self, request):
        OUT, ROOT, native_path, json, payload, digest, recipe, pre, claim, child, revised, selected, index_bytes = self.context
'''
new += indent(acquire)
new += '''
    def validate(self, request):
        OUT, ROOT, native_path, json, payload, digest, recipe, pre, claim, child, revised, selected, index_bytes = self.context
        sha = self.sha
        retained = decode_primitive(payload(OUT / "post-request.frame"))
        require(retained == request, "retained postrequest changed")
        command = json.loads(payload(OUT / "postidentity-command.json"))
        require(type(command) is dict and set(command) == {"exit", "stdout_hex", "stderr_hex"}
                and type(command["exit"]) is int and command["exit"] == 0
                and command["stderr_hex"] == "", "retained postidentity command failed")
        require(type(command["stdout_hex"]) is str and len(bytes.fromhex(command["stdout_hex"])) <= CAP,
                "retained postidentity output bound")
'''
new += indent(validate)
identity.write_text(text[:start]+new+text[end:],encoding='utf8',newline='\n')
bootstrap = root/'tools/benchmark/static_v4_bootstrap.py'
previous = bootstrap.read_text(encoding='utf8')
prefix = identity.read_text(encoding='utf8').split('\n\nif __name__ == "__main__":',1)[0]
tail = previous[previous.index('\n\ndef actual_scope('):]
tail = tail.replace('group = read_bytes("/proc/self/cgroup", 65536)', 'group = read_virtual_bytes("/proc/self/cgroup", 65536)')
tail = tail.replace('key: read_bytes("/sys/fs/cgroup"', 'key: read_virtual_bytes("/sys/fs/cgroup"')
bootstrap.write_text(prefix+tail,encoding='utf8',newline='\n')
