"""Pin all inputs, outputs, library, and the runner's actual link target."""

import hashlib
import json
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).parent
SOURCE = Path("C:/Users/yuche/.codex/worktrees/FlyDrones/prearm-target/results/openvins-prearm-board-dev-1701")
UPSTREAM = "/home/yuchen7509/flydrones-upstream/open_vins_interior_candidates_probe"
OUT = STAGE / "provenance.json"


def digest(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


if OUT.exists() or (STAGE / "runner-ldd.txt").exists():
    raise SystemExit("refusing existing provenance/linker evidence")
runner = SOURCE / "dependencies-v1/offline_probe"
command = (f"LD_LIBRARY_PATH={UPSTREAM}/ov_msckf/build "
           f"ldd {runner.as_posix().replace('C:/', '/mnt/c/')}")
process = subprocess.run(["wsl", "-e", "bash", "-lc", command], capture_output=True, check=False)
if process.returncode:
    raise SystemExit(f"ldd failed: {process.stderr.decode(errors='replace')}")
(STAGE / "runner-ldd.txt").write_bytes(process.stdout)
library_path = f"{UPSTREAM}/ov_msckf/build/libov_msckf_lib.so"
if "libov_msckf_lib.so => " + library_path not in process.stdout.decode():
    raise SystemExit("runner did not load the new isolated library")

prior = json.loads((ROOT / "results/openvins-detection-pruning-dev-1701/provenance.json").read_text())
files = {
    "new_logging_patch": ROOT / "tools/benchmark/openvins_interior_candidates.patch",
    "applied_upstream_diff": STAGE / "upstream-applied.patch",
    "prior_evidence_index": ROOT / "evidence/openvins-detection-pruning-dev-1701.sha256.json",
    "offline_runner": runner,
    "estimator_config": SOURCE / "dependencies-v1/config-v2/estimator_config.yaml",
    "source_input_manifest": SOURCE / "input-v1/manifest.json",
    "source_imu_csv": SOURCE / "input-v1/imu.csv",
    "source_frames_csv": SOURCE / "input-v1/frames.csv",
    "new_replay_states": STAGE / "replay-v1/states.csv",
    "new_replay_stdout": STAGE / "replay-v1/stdout.txt",
    "new_replay_stderr": STAGE / "replay-v1/stderr.txt",
    "new_audit_summary": STAGE / "audit-v3/summary.json",
    "new_audit_frames": STAGE / "audit-v3/frames.csv",
    "new_audit_candidates": STAGE / "audit-v3/candidates.csv",
    "new_audit_new": STAGE / "audit-v3/new.csv",
}
hashes = {name: digest(path) for name, path in files.items()}
for name in ("offline_runner", "estimator_config", "source_input_manifest", "source_imu_csv", "source_frames_csv"):
    if hashes[name] != prior["sha256"][name]:
        raise SystemExit(f"source changed: {name}")
if hashes["new_replay_states"] != prior["sha256"]["new_replay_states"]:
    raise SystemExit("instrumented estimator states changed")
head = (STAGE / "upstream-head.txt").read_text().strip()
if head != "69488123ed9362dd44b6f28e7f4680abbff1442b":
    raise SystemExit("upstream HEAD changed")
if (STAGE / "upstream-diff-check.txt").read_bytes():
    raise SystemExit("upstream diff check failed")
data = {
    "schema": "flydrones-openvins-interior-candidates-provenance-v1",
    "upstream": "rpng/open_vins@" + head,
    "upstream_license": "GPL-3.0",
    "compiler": prior["compiler"],
    "opencv": prior["opencv"],
    "new_library_sha256": (STAGE / "library-sha256.txt").read_text().split()[0],
    "new_library_bytes": int((STAGE / "library-bytes.txt").read_text().strip()),
    "library_archived": False,
    "prior_pr": "https://github.com/chen7509/FlyDrones/pull/28",
    "prior_evidence_zip_sha256": json.loads(files["prior_evidence_index"].read_text())["archive_sha256"],
    "sha256": hashes,
}
OUT.write_text(json.dumps(data, indent=2) + "\n")
print(json.dumps(data, indent=2))
