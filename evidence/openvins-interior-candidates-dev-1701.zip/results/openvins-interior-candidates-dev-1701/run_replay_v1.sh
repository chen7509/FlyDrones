#!/usr/bin/env bash
set -u

OUT=/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/results/openvins-interior-candidates-dev-1701/replay-v1
SOURCE=/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/prearm-target/results/openvins-prearm-board-dev-1701
RUNNER="$SOURCE/dependencies-v1/offline_probe"
CONFIG="$SOURCE/dependencies-v1/config-v2/estimator_config.yaml"
if [ -e "$OUT" ]; then
  echo "refusing existing replay output" >&2
  exit 2
fi
mkdir "$OUT" || exit 2
export LD_LIBRARY_PATH=/home/yuchen7509/flydrones-upstream/open_vins_interior_candidates_probe/ov_msckf/build

/usr/bin/time -v -o "$OUT/resources.txt" \
  "$RUNNER" "$CONFIG" "$SOURCE/input-v1" "$SOURCE/episode-run-v3" \
  "$OUT/states.csv" > "$OUT/stdout.txt" 2> "$OUT/stderr.txt"
status=$?
printf '%s\n' "$status" > "$OUT/exit-code.txt"
exit "$status"
