#!/usr/bin/env bash
set -euo pipefail

UPSTREAM=/home/yuchen7509/flydrones-upstream/open_vins_interior_candidates_probe
ROOT=/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility
STAGE="$ROOT/results/openvins-interior-candidates-dev-1701"
test "$(git -C "$UPSTREAM" rev-parse HEAD)" = 69488123ed9362dd44b6f28e7f4680abbff1442b
for name in openvins_init_feature_trace openvins_track_eligibility openvins_track_lifetime openvins_detection_pruning; do
  git -C "$UPSTREAM" apply --check "$ROOT/tools/benchmark/$name.patch"
  git -C "$UPSTREAM" apply "$ROOT/tools/benchmark/$name.patch"
done
python3 "$STAGE/instrument_candidates.py" "$UPSTREAM/ov_core/src/track/TrackKLT.cpp" \
  "$ROOT/tools/benchmark/openvins_interior_candidates.patch"
git -C "$UPSTREAM" diff --check > "$STAGE/upstream-diff-check.txt"
git -C "$UPSTREAM" diff --binary HEAD > "$STAGE/upstream-applied.patch"
cmake -S "$UPSTREAM/ov_msckf" -B "$UPSTREAM/ov_msckf/build" -DCMAKE_BUILD_TYPE=Release \
  > "$STAGE/configure.log" 2>&1
printf '0\n' > "$STAGE/configure.exitcode"
cmake --build "$UPSTREAM/ov_msckf/build" --target ov_msckf_lib -j2 \
  > "$STAGE/build.log" 2>&1
printf '0\n' > "$STAGE/build.exitcode"
sha256sum "$UPSTREAM/ov_msckf/build/libov_msckf_lib.so" > "$STAGE/library-sha256.txt"
stat -c %s "$UPSTREAM/ov_msckf/build/libov_msckf_lib.so" > "$STAGE/library-bytes.txt"
git -C "$UPSTREAM" rev-parse HEAD > "$STAGE/upstream-head.txt"
git -C "$UPSTREAM" status --short > "$STAGE/upstream-status.txt"
echo "isolated library built"
