"""Add only selected/candidate diagnostic prints to an isolated TrackKLT.cpp."""

import difflib
import sys
from pathlib import Path


source = Path(sys.argv[1])
patch = Path(sys.argv[2])
if patch.exists():
    raise SystemExit("refusing existing patch")
before = source.read_text()
start = before.index("void TrackKLT::perform_detection_monocular(")
end = before.index("void TrackKLT::perform_detection_stereo(", start)
body = before[start:end]
candidate_call = (
    "  Grider_GRID::perform_griding(img0pyr.at(0), mask0_updated, valid_locs, "
    "pts0_ext, num_features, grid_x, grid_y, threshold, true);\n"
)
new_id_call = "    ids0.push_back(temp);\n"
if body.count(candidate_call) != 1 or body.count(new_id_call) != 1:
    raise SystemExit("pinned source anchors changed")
body = body.replace(candidate_call, candidate_call + (
    "  for (const auto &candidate : pts0_ext)\n"
    '    PRINT_INFO("FD_CANDIDATE x=%.3f y=%.3f\\n", candidate.pt.x, candidate.pt.y);\n'
))
body = body.replace(new_id_call, new_id_call + (
    '    PRINT_INFO("FD_NEW id=%zu x=%.3f y=%.3f\\n", temp, pts0_new.at(i).x, pts0_new.at(i).y);\n'
))
after = before[:start] + body + before[end:]
diff = "".join(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True),
                                    fromfile="a/ov_core/src/track/TrackKLT.cpp",
                                    tofile="b/ov_core/src/track/TrackKLT.cpp"))
if not diff:
    raise SystemExit("no diagnostic diff")
source.write_text(after)
patch.write_text(diff)
print("candidate logging patch bytes", patch.stat().st_size)
