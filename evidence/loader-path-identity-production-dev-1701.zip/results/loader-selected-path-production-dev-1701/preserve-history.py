import hashlib
import json
import tomllib
from pathlib import Path

root=Path.cwd();raw=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def write(path,b):
    with path.open('xb') as f:f.write(b)
source=Path('C:/Users/yuche/.codex/automations/flydrones/automation.toml')
data=source.read_bytes();config=tomllib.loads(data.decode('utf-8-sig'));prompt=config['prompt']
assert len(prompt)==62676 and sha(prompt.encode())=='d412a51263d462c02e8959bee4ec881fb4943b80d72b82346a3293f6834ceaa1'
history=dict(schema='flydrones-full-heartbeat-history-v2',scope='Exact full scheduler prompt through loader-selected path research. Older pending statements do not supersede latest consumed facts. No goal/constraint dropped.',
             source_toml_sha256=sha(data),source_toml_bytes=len(data),prompt=prompt,prompt_characters=len(prompt),prompt_utf8_sha256=sha(prompt.encode()),
             original_history=dict(path='evidence/flydrones-history-through-admitted-executor-dev-1701.json',bytes=89359,sha256='c88840b6f58dea4e7e4931683c4993b4fc3b8eb55887807994b6381ef6c2b989'),
             preserved_settings={k:v for k,v in config.items() if k!='prompt'})
target=root/'evidence/flydrones-history-through-loader-path-research-dev-1701.json'
b=json.dumps(history,ensure_ascii=False,indent=2).encode();write(target,b)
assert json.loads(target.read_bytes())['prompt']==prompt
write(raw/'history-externalization-exact.json',json.dumps(dict(path=str(target.relative_to(root)),bytes=len(b),sha256=sha(b),source_toml_sha256=sha(data),prompt_characters=len(prompt),prompt_utf8_sha256=sha(prompt.encode()),exact_readback=True,reason='next substantial update exceeds64000 character limit; old original history unchanged'),indent=2).encode())
print(json.dumps(dict(bytes=len(b),sha256=sha(b),settings=list(history['preserved_settings']))))
