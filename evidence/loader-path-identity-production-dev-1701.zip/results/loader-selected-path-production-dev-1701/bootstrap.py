import hashlib
import json
import subprocess
from pathlib import Path

root = Path.cwd()
raw = Path(__file__).resolve().parent
def sha(b): return hashlib.sha256(b).hexdigest()
def write(name, b):
    with (raw / name).open('xb') as f: f.write(b)
files = subprocess.check_output(['git', 'ls-files', '-z', 'src', 'tools', 'tests', 'configs']).split(b'\0')
write('product-before.json', json.dumps([dict(path=x.decode(), bytes=len(b := (root / x.decode()).read_bytes()), sha256=sha(b)) for x in files if x], indent=2).encode())
write('ancestor-instructions.json', json.dumps([dict(path=str(p / 'AGENTS.md'), text=(p / 'AGENTS.md').read_text(encoding='utf-8-sig')) for p in [root, *root.parents] if (p / 'AGENTS.md').is_file()], indent=2).encode())
old = root / 'evidence/flydrones-history-through-admitted-executor-dev-1701.json'
assert len(old.read_bytes()) == 89359 and sha(old.read_bytes()) == 'c88840b6f58dea4e7e4931683c4993b4fc3b8eb55887807994b6381ef6c2b989'
json.loads(old.read_text(encoding='utf-8-sig'))
write('history-read.json', json.dumps(dict(path=str(old), sha256=sha(old.read_bytes()), full_json_read=True)).encode())
for name in ['run-static-preparation-v4.py', 'frozen-study-v4', 'claim.json', 'attempt.json']:
    assert not (root / 'results/target-bearing-runtime-freeze-v4-dev-1701' / name).exists()
assert not (root / 'results/target-bearing-physical-capture-dev-1701').exists()
write('initial-readonly.py', (root / 'results/loader-selected-path-research-dev-1701/initial-readonly.py').read_bytes())
p = subprocess.run(['python', str(raw / 'initial-readonly.py')], capture_output=True, timeout=65)
write('initial-readonly.stdout', p.stdout); write('initial-readonly.stderr', p.stderr)
write('initial-readonly-return.json', json.dumps(dict(exit=p.returncode, helper_sha256=sha((raw / 'initial-readonly.py').read_bytes()), purpose='one initial readonly resource snapshot, not admission')).encode())
assert p.returncode == 0, p.stderr
print(p.stdout.decode())
