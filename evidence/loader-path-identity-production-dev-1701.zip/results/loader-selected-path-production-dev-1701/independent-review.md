# Fresh independent read-only Task1 review

Reviewer /root/review_loader_path_identity_v4, fresh context, gpt-6-astra/high. Read current Task1 source/spec/plan/tests/ledger/report, no test/native/consumed execution or modifications. Initial assessment changes requested, C0/I3/M1, not native approval.

I1 native_loader_paths_v4.py original review lines172/123/185/198: impossible env keys/values including NUL/equals/empty and control-bearing SONAME/VDSO names accepted despite strict evidence claim. Validate native/encoding constraints in both query/version and trace names.

I2 original line333: anonymous postwalk buffers lost partial changed-link/missing-component evidence on failure. Attach buffers before traversal and test retention.

I3 tests original line217: events fixture actually exceeds8192-byte target, fails at4095-byte path limit. Use valid short multiple link targets, assert event bound4096 and exact-limit success.

M1 original line412: auditor accepts missing UTC fields. Require presence/integer types, do not require wallclock ordering.

Strengths: ordered symlink-before-parent traversal; ENOTDIR distinction; preserved original open; descriptor regularity/ownership64KiB/hash/byte checks; repeated full observations/canonical match; primary close error distinction; retained complete query/version/artifact/token/baseline joins; narrowly scoped guard. Docs honest about Windows protocol and consumed failure.

Declined: actual Linux/loader/nativequery/SDK/dispatch; pending Task2alias/context/bill and Task3..5 integration/qualification; independent fresh test/lint/historicalprocessabsence (reviewer read61pass1skip, ran none); cold dependency import effects beyond explicit already-imported module-body trap. These remain unverified/pending, not waived requirements or positive evidence.

Original narrative references pre-fix source preserved by recorder pre-review and review-red snapshots. Executor independently verifies fixes with real software RED/GREEN; this review does not declare final C0 or approve future dispatch.
