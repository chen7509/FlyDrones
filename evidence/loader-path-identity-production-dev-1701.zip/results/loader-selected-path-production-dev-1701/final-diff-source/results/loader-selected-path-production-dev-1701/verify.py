import datetime
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

root=Path.cwd(); raw=Path(__file__).resolve().parent
label=sys.argv[1]; cmd=sys.argv[2:]
files=['tools/benchmark/software_process_boundary.py','tests/benchmark/conftest.py','tools/benchmark/native_loader_paths_v4.py','tests/benchmark/test_native_loader_paths_v4.py',str(Path(__file__).relative_to(root))]
def pins():
    return [dict(path=x,sha256=hashlib.sha256((root/x).read_bytes()).hexdigest(),bytes=(root/x).stat().st_size) for x in files if (root/x).exists()]
def write(name,b):
    with (raw/name).open('xb') as f:f.write(b)
snapshot=raw/(label+'-source');snapshot.mkdir()
before=pins()
for row in before:
    target=snapshot/row['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((root/row['path']).read_bytes())
env=os.environ.copy();env['PYTHONPATH']=str(root)+os.pathsep+str(root/'src')
if cmd[1:3]==['-m','pytest']:cmd+=['--basetemp',str(raw/(label+'-fixtures'))]
record=dict(argv=cmd,cwd=str(root),child_environment={k:env.get(k) for k in ['PYTHONPATH','PATH','VIRTUAL_ENV','PYTHONHOME']},before=before,utc_start=datetime.datetime.now(datetime.UTC).isoformat(),monotonic_start_ns=time.monotonic_ns())
write(label+'-start.json',json.dumps(record,indent=2).encode())
p=subprocess.run(cmd,env=env,capture_output=True,timeout=120)
record.update(exit=p.returncode,utc_end=datetime.datetime.now(datetime.UTC).isoformat(),monotonic_end_ns=time.monotonic_ns(),after=pins())
write(label+'.stdout',p.stdout);write(label+'.stderr',p.stderr);write(label+'.json',json.dumps(record,indent=2).encode())
print(json.dumps(dict(label=label,exit=p.returncode,stdout=p.stdout.decode(errors='replace')[-7000:],stderr=p.stderr.decode(errors='replace')[-1000:])))
