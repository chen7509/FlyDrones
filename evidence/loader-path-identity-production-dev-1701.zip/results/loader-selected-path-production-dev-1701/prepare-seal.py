import hashlib
import json
import subprocess
from pathlib import Path

root=Path.cwd();raw=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes().decode('utf-8-sig'))
def write(p,value):
    with p.open('xb') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2).encode())
before=load(raw/'product-before.json');changed=[]
for row in before:
    p=root/row['path'];b=p.read_bytes()
    if sha(b)!=row['sha256']:changed.append(dict(path=row['path'],before=row,after=dict(bytes=len(b),sha256=sha(b))))
assert [x['path'] for x in changed]==['tools/benchmark/software_process_boundary.py']
write(raw/'product-after.json',dict(before_count=len(before),changed=changed,new_product_paths=['tools/benchmark/native_loader_paths_v4.py','tests/benchmark/test_native_loader_paths_v4.py'],all_other_consumed_product_bytes_same=True))
expected=load(root/'results/loader-selected-path-research-dev-1701/historical-archives-postresearch.json')['members']
expected.append(dict(path='evidence/loader-selected-path-research-dev-1701.zip',bytes=1376904,sha256='58e21898abd5de662fe17e1aba2a1c803551ff38ad2ceefcc458306997ae9a0b'))
assert len(expected)==289
assert {p.relative_to(root).as_posix() for p in (root/'evidence').glob('*.zip')}=={x['path'] for x in expected}
for row in expected:
    p=root/row['path'];d=hashlib.sha256();size=0
    with p.open('rb') as f:
        while b:=f.read(1024*1024):d.update(b);size+=len(b)
    assert size==row['bytes'] and d.hexdigest()==row['sha256'],row['path']
write(raw/'historical-archives-postsoftware.json',dict(count=len(expected),bytes=sum(x['bytes'] for x in expected),members=expected,scope='POSTsoftware historical preservation audit, never retroactive prepin'))
plan=root/'docs/superpowers/plans/2026-10-15-loader-selected-path-production.md';b=plan.read_bytes()
start=b.index(b'## Task1');end=b.index(b'## Task2');section=b[start:end]
assert section.count(b'- [ ]')==3
section=section.replace(b'- [ ]',b'- [x]',2)
plan.write_bytes(b[:start]+section+b[end:])
write(raw/'preseal-plan-state.json',dict(task1_done=2,task1_review_seal_publication_pending=1,later_production_pending=13,qualification=False))
assert not (root/'results/target-bearing-runtime-freeze-v4-dev-1701').exists()
assert not (root/'results/target-bearing-physical-capture-dev-1701').exists()
write(raw/'absence-software.json',dict(v4_fixed_parent_absent=True,physical_fixed_attempt_absent=True,scope='read-only software phase absence, not admission or future attempt authority'))
print('807 prior product files joined, one guard modified/two new modules;289 historical ZIP SHA exact;Task1 first2 boxes software done;no native attempt')
