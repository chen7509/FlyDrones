"""Seal this offline increment only; never overwrite an earlier evidence ZIP."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
output = root / "evidence/live-wire-interval-failure-offline-progress-dev-1701.zip"
files = [
    "tools/benchmark/audit_live_wire_study.py",
    "tests/benchmark/test_live_wire_interval_audit.py",
    "tests/benchmark/test_live_wire_failure_audit.py",
    "tests/benchmark/test_live_wire_protocol_audit.py",
    "docs/LIVE_WIRE_RAW_EVIDENCE_MAP.md",
    "docs/LIVE_WIRE_STUDY_PREPARATION_REPORT.md",
    ".superpowers/sdd/2026-10-08-live-wire-study/progress.md",
    "results/live-wire-study-audit-dev-1701/seal-interval-failure-v1.py",
]
files += ["results/live-wire-study-audit-dev-1701/" + name for name in (
    "interval-response-red-v1.txt", "interval-response-green-v1.txt",
    "failure-chain-green-v1.txt", "interval-failure-regression-v1.txt",
    "interval-entry-regression-v1.txt", "interval-failure-ruff-v1.txt",
)]
payloads = {name: (root / name).read_bytes() for name in files}
manifest = dict(
    schema="offline-interval-failure-evidence-v1",
    producer_commit=subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(),
    live_qualified=False, fusion_qualified=False, full_study_qualified=False,
    scope="Synthetic socket/owner/clock fixtures; actual production classes and pinned codec. No live run.",
    members={name: dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()) for name, raw in payloads.items()},
)
with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED) as archive:
    for name, raw in payloads.items():
        archive.writestr(name, raw)
    archive.writestr("MANIFEST.json", json.dumps(manifest, indent=2).encode())
with zipfile.ZipFile(output) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(payloads) + 1
    for name, expected in manifest["members"].items():
        raw = archive.read(name)
        assert len(raw) == expected["bytes"]
        assert hashlib.sha256(raw).hexdigest() == expected["sha256"]
        assert (root / name).read_bytes() == payloads[name]
print(json.dumps(dict(path=str(output), members=len(payloads)+1, bytes=output.stat().st_size,
                     sha256=hashlib.sha256(output.read_bytes()).hexdigest(), crc_and_members_verified=True)))
