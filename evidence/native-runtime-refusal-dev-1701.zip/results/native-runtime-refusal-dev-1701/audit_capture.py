import collections,hashlib,json
from pathlib import Path
from pyulog import ULog

b=Path(__file__).resolve().parent;c=b/'capture-v1'
def read(n):return json.loads((c/n).read_text())
def rows(n):return [json.loads(x) for x in (c/n).read_text().splitlines()]
r=read('result.json');f=r['runtime_refusal'];t=f['trigger'];n=r['native_reference'];m=r['motion'];s=read('supervisor.json');ex=json.loads((b/'exit.json').read_text())
assert r['status']=='capture_failed' and not r['estimator_run'] and not r['eligible_for_px4_fusion']
assert r['reference_fault_profile']=='native-pre-epoch-v1' and f['failure'] is None and not f['close_errors']
assert f['exception']=="RuntimeError('native pre sequence')" and n['native']['failed'] and not n['native']['pending']
assert t['submitted_ns']==t['actual_ns']+1000000 and t['actual_ns']<t['anchor_ns']
assert f['blocked_after_trigger']==1 and f['blocked_first_ns']==f['blocked_last_ns']==r['end_sim_ns']==t['actual_ns']+1000000
assert n['pre_count']==n['post_count']==t['actual_ns']//1000000-1
assert n['native']['last_ns']==t['actual_ns']-1000000 and not n['complete']
assert all(m[k]==0 for k in ['active_steps','support_steps','recorded_commands','absolute_impulse_ns','signed_impulse_ns'])
assert m['last_attempt'] is None and not (c/'motion-force.jsonl').read_bytes() and not m['close_errors']
assert s['status']=='worker_exited' and s['worker_exit']==ex['exit']==2 and s['timeout_s']==90
assert r['px4_exit_code']==0 and ex['unchanged'] and ex['resources']==[]
assert len(r['errors'])==4 and r['errors'][0]=="native reference: RuntimeError('native pre sequence')"
assert 'capture callback/writer failure' in r['errors'][1]
assert r['errors'][2:]==["motion fixture: ValueError('incomplete supported fixture')",'physics trace: incomplete terminal physics trace']
events=rows('events.jsonl');counts=dict(collections.Counter(e['kind'] for e in events))
hb=[e for e in events if e['kind']=='heartbeat'];assert hb and all(e['system_id']==9 and e['base_mode']<128 for e in hb)
anchor=read('readiness-anchor.json');assert anchor['anchor_ns']==t['anchor_ns'] and anchor['selected_sim_ns']+200000000==t['anchor_ns']
for proof in [anchor['proof'],t['proof']]:
 assert set(proof['records'])=={'imu','rgb','info','heartbeat'}
 for kind,e in proof['records'].items():
  assert 0<=proof['checked_wall_ns']-e['arrival_monotonic_ns']<=2000000000
  assert e['arrival_monotonic_ns']<=e['recorded_monotonic_ns']<=e['journal_ack_monotonic_ns']<=proof['checked_wall_ns']
  assert any(all(row.get(k)==v for k,v in e.items() if k!='journal_ack_monotonic_ns') for row in events)
  if 'payload_path' in e:assert hashlib.sha256((c/e['payload_path']).read_bytes()).hexdigest()==e['payload_sha256']
j=rows('native-runtime-refusal.jsonl');assert [x['event'] for x in j]==['trigger_intent','native_exception']
assert j[0]['actual_ns']==t['actual_ns'] and j[1]['native_after']==n['native'] and j[0]['wall_ns']<j[1]['wall_ns']
refs=rows('native-reference.jsonl');assert len(refs)==n['post_count']
assert all(e['pre_ns']==e['post_ns']==(i+1)*1000000 and e['canary_overwritten'] for i,e in enumerate(refs))
assert len(rows('physics-substeps.jsonl'))==2*n['post_count']
ulogs=[]
for meta in r['px4_ulogs']:
 p=c/meta['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==meta['sha256']
 states=ULog(str(p)).get_dataset('vehicle_status').data['arming_state']
 assert len(states)>0 and set(int(x) for x in states)=={1}
 ulogs.append(dict(meta,arming_records=len(states),arming_values=[1]))
assert ulogs
out=dict(scope='one prospective native-pre-epoch-v1 actual refusal path only',refusal_cleanup_expectations_pass=True,capture_status_retained=r['status'],actual_ns=t['actual_ns'],submitted_ns=t['submitted_ns'],anchor_ns=t['anchor_ns'],ready_selected_ns=anchor['selected_sim_ns'],end_sim_ns=r['end_sim_ns'],blocked_after_trigger=f['blocked_after_trigger'],counts=counts,native_successful_cycles=len(refs),force_calls=0,px4_exit_code=0,ulogs=ulogs,hashes_unchanged=True,remaining_processes=ex['resources'],estimator_run=False,eligible_for_px4_fusion=False,normal_capture_complete=False)
with (b/'audit.json').open('x') as stream:json.dump(out,stream,indent=2)
print(json.dumps(out))
