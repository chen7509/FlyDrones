from pathlib import Path
b=Path(__file__).resolve().parent;root=b.parents[1]
s=(root/'results/native-reference-probe-dev-1701/run_capture.py').read_text()
s=s.replace("out / 'production-build/build.json'", "root / 'results/native-reference-probe-dev-1701/production-build/build.json'")
s=s.replace("name='supported-ready-native-reference-v1'", "name='native-pre-epoch-v1', expected_capture_status='capture_failed', sim_deadline_ns=8000000000, wall_budget_s=60, supervisor_s=90")
s=s.replace("'--reference-sha256', build_reference['binary_sha256']]", "'--reference-sha256', build_reference['binary_sha256'], '--reference-fault-profile', 'native-pre-epoch-v1']")
with (b/'run_capture.py').open('x') as f:f.write(s)
