from pathlib import Path
import json,re,subprocess
b=Path(__file__).resolve().parent;root=b.parents[1]
log=(b/'regression-final.txt').read_text(encoding='utf-8-sig')
assert re.search(r'915 passed, 2 warnings in [\d.]+s',log),log[-500:]
report=root/'docs/NATIVE_RUNTIME_REFUSAL_REPORT.md'
s=report.read_text(encoding='utf-8').replace('Initial full regression909 passed; final regression/publication are recorded at closure.','Initial full regression909 passed; final regression915 passed with two existing loader warnings. Changed Ruff passes; whole-repository Ruff retains50 errors in32 unchanged files (evidence/publication checks), not a whole-repository lint pass.')
report.write_text(s,encoding='utf-8')
p=root/'docs/superpowers/plans/2026-10-06-native-runtime-refusal.md';s=p.read_text(encoding='utf-8').replace('- [ ]','- [x]');s+='\nThe bounded implementation/audit stage is closed. The original all-descendant no-SIGKILL requirement remains unqualified and is carried into the next supervisor evidence stage. Publication follows verified sealing.\n';p.write_text(s,encoding='utf-8')
p=root/'.superpowers/sdd/2026-10-06-native-runtime-refusal/progress.md';s=p.read_text(encoding='utf-8').replace('final regression pending','final regression915pass,2existingwarnings; changedRuffpass,wholeRuff50errors32unchangedfiles');p.write_text(s,encoding='utf-8')
r=subprocess.run(['wsl','-d','Ubuntu','--cd','/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility','python3','-c','from tools.benchmark.capture_disarmed_sensors import active_resources; print(active_resources())'],capture_output=True)
assert r.returncode==0 and r.stdout.strip()==b'[]',r.stdout
with (b/'final-resources.json').open('x') as f:json.dump(dict(exit=r.returncode,filtered_resources=[],stderr=r.stderr.decode('utf-8',errors='replace'),scope='filtered scanner only; supervisor signal outcomes remain unknown'),f,indent=2)
print('915 tests confirmed; report and final filtered resources recorded')
