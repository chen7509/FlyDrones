import hashlib,json,urllib.request
from pathlib import Path
b=Path(__file__).resolve().parent;d=b/'next-sources';d.mkdir(exist_ok=False)
urls={'os.html':'https://docs.python.org/3.12/library/os.html','subprocess.html':'https://docs.python.org/3.12/library/subprocess.html','kill2.html':'https://man7.org/linux/man-pages/man2/kill.2.html','python-metadata.json':'https://api.github.com/repos/python/cpython','LICENSE':'https://raw.githubusercontent.com/python/cpython/v3.12.3/LICENSE','subprocess-v3.12.3.py':'https://raw.githubusercontent.com/python/cpython/v3.12.3/Lib/subprocess.py'}
rows=[]
for n,u in urls.items():
 data=urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'FlyDrones-evidence'}),timeout=30).read();(d/n).write_bytes(data);rows.append(dict(name=n,url=u,sha256=hashlib.sha256(data).hexdigest()))
(d/'manifest.json').write_text(json.dumps(rows,indent=2));print(len(rows))
