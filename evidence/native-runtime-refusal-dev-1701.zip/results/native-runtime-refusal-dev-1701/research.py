import hashlib,json,urllib.request
from pathlib import Path
b=Path(__file__).resolve().parent;d=b/'sources';d.mkdir(exist_ok=False)
r='446a44335a45b704b4d36dabcc5508ee34eeb3d8'
urls={'binding.cc':f'https://raw.githubusercontent.com/gazebosim/gz-sim/{r}/python/src/gz/sim/TestFixture.cc','wrap_functions.hh':f'https://raw.githubusercontent.com/gazebosim/gz-sim/{r}/python/src/gz/sim/wrap_functions.hh','TestFixture.cc':f'https://raw.githubusercontent.com/gazebosim/gz-sim/{r}/src/TestFixture.cc','exceptions.rst':'https://raw.githubusercontent.com/pybind/pybind11/v2.11.1/docs/advanced/exceptions.rst','pybind-LICENSE':'https://raw.githubusercontent.com/pybind/pybind11/v2.11.1/LICENSE','gz-metadata.json':'https://api.github.com/repos/gazebosim/gz-sim','pybind-metadata.json':'https://api.github.com/repos/pybind/pybind11','OpenVINS-ICRA2020.pdf':'https://pgeneva.com/downloads/papers/Geneva2020ICRA.pdf'}
rows=[]
for n,u in urls.items():
 data=urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'FlyDrones-evidence'}),timeout=30).read();(d/n).write_bytes(data);rows.append(dict(name=n,url=u,sha256=hashlib.sha256(data).hexdigest()))
(d/'manifest.json').write_text(json.dumps(rows,indent=2));print(len(rows))
