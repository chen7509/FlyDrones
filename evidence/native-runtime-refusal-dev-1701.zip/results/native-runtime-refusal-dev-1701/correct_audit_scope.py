import hashlib,json
from pathlib import Path
b=Path(__file__).resolve().parent
v1=json.loads((b/'audit.json').read_text())
v2=dict(v1)
v2.pop('refusal_cleanup_expectations_pass')
v2.update(actual_native_refusal_and_owned_px4_exit_checks_pass=True,all_descendant_cleanup_qualified=False,supervisor_signal_outcomes='not_recorded_unknown',scope='scope correction only; no capture or estimator rerun',source_audit_sha256=hashlib.sha256((b/'audit.json').read_bytes()).hexdigest(),reason='Existing supervisor does not journal group signal outcomes. Owned PX4 exit0 and filtered resource scan alone do not establish no descendant SIGKILL.')
with (b/'audit-v2.json').open('x') as f:json.dump(v2,f,indent=2)
print(json.dumps(v2))
