from pathlib import Path
b=Path(__file__).resolve().parent;root=b.parents[1]
s=(root/'results/native-reference-probe-dev-1701/seal_evidence.py').read_text()
start=s.index('files = ');end=s.index('\nfor name in files:',start)
files=['tools/benchmark/native_runtime_refusal.py','tools/benchmark/native_reference_probe.py','tools/benchmark/capture_disarmed_sensors.py','tools/benchmark/disarmed_sensor_provenance.py','tests/benchmark/test_native_runtime_refusal.py','docs/NATIVE_RUNTIME_REFUSAL_REPORT.md','docs/superpowers/specs/2026-10-06-native-runtime-refusal.md','docs/superpowers/plans/2026-10-06-native-runtime-refusal.md','.superpowers/sdd/2026-10-06-native-runtime-refusal/progress.md']
s=s[:start]+'files = '+repr(files)+s[end:]
s=s.replace('8a734d7..e28fcc3','7a2271d..dc23e19').replace('e28fcc3..HEAD','dc23e19..HEAD').replace('evidence/native-reference-probe-dev-1701.zip','evidence/native-runtime-refusal-dev-1701.zip')
with (b/'seal_evidence.py').open('x') as f:f.write(s)
