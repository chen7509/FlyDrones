"""Read-only comparison of the sealed v7 declarations with current files."""

import hashlib
import json
import os
import sys
from collections import Counter
from pathlib import Path

root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root))
from tools.benchmark.declared_runtime_snapshot import file_record  # noqa: E402

study = root / "results/live-wire-study-dev-1701/study-v7"
manifest_path = study / "study-manifest.json"
manifest = json.loads(manifest_path.read_text())
binding = json.loads((study / "runtime-binding-v3.json").read_text())
selection = json.loads((study / "startup-diagnostic-selection.json").read_text())


def compare(role, expected):
    path = expected["requested"]
    try:
        actual = file_record(path)
    except (OSError, ValueError) as error:
        return {"role": role, "path": path, "status": "unreadable", "error": str(error)}
    changed = [key for key in expected if expected[key] != actual.get(key)]
    if not changed:
        return None
    return {
        "role": role,
        "path": path,
        "status": "drifted",
        "changed_fields": changed,
        "expected_sha256": expected["sha256"],
        "actual_sha256": actual["sha256"],
        "expected_bytes": expected["bytes"],
        "actual_bytes": actual["bytes"],
    }


differences = []
for role, row in manifest["files"].items():
    result = compare("study:" + role, row)
    if result:
        differences.append(result)
for row in binding["baseline"]["files"]:
    result = compare("baseline:" + row["role"], {key: val for key, val in row.items() if key != "role"})
    if result:
        differences.append(result)

output_names = {**manifest["outputs"], "activation": str(study / "activation-request.json")}
presence = {name: os.path.lexists(path) for name, path in output_names.items()}
result = {
    "schema": "flydrones-v7-current-drift-audit-v1",
    "manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
    "manifest_hash_selected": hashlib.sha256(manifest_path.read_bytes()).hexdigest() == selection["study_manifest_sha256"],
    "study_file_count": len(manifest["files"]),
    "baseline_file_count": len(binding["baseline"]["files"]),
    "difference_count": len(differences),
    "difference_roles": dict(Counter(row["role"] for row in differences)),
    "differences": differences,
    "output_presence": presence,
    "valid_for_execution": False,
    "physical_dispatched": False,
}
out = Path(__file__).resolve().parent / "drift-audit.json"
if out.exists():
    raise FileExistsError(out)
out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
print(json.dumps({key: value for key, value in result.items() if key != "differences"}, sort_keys=True))
