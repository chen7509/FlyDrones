"""Read-only current-state validation of the already prepared v7 study."""

import hashlib
import json
import os
import sys
from pathlib import Path


root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root))
from tools.benchmark.execute_live_wire_startup_diagnostic import (  # noqa: E402
    _read_selected_declaration,
    validate_diagnostic,
)
from tools.benchmark.execute_openvins_health_physical_run import (  # noqa: E402
    prepare_live_wire_execution,
)

study = root / "results/live-wire-study-dev-1701/study-v7"
selected = json.loads((study / "startup-diagnostic-selection.json").read_text())
manifest = study / "study-manifest.json"
diagnostic = study / "startup-diagnostic-declaration.json"
expected_study = selected["study_manifest_sha256"]
expected_diagnostic = selected["diagnostic_declaration_sha256"]
if hashlib.sha256(manifest.read_bytes()).hexdigest() != expected_study:
    raise ValueError("v7 study manifest changed")
declaration = _read_selected_declaration(diagnostic, expected_diagnostic)
plan = prepare_live_wire_execution(manifest)
observer = root / "tools/benchmark/observe_px4_startup.py"
runner = root / "tools/benchmark/live_wire_startup_runner.py"
validated = validate_diagnostic(
    declaration,
    plan,
    hashlib.sha256(observer.read_bytes()).hexdigest(),
    hashlib.sha256(runner.read_bytes()).hexdigest(),
)
if expected_study != plan["study_manifest"]["sha256"]:
    raise ValueError("v7 selected manifest differs from plan")
activation = study / "activation-request.json"
outputs = {
    **plan["outputs"],
    "activation": str(activation),
    "startup_observation": validated["observation_path"],
    "startup_summary": validated["summary_path"],
}
presence = {key: os.path.lexists(path) for key, path in outputs.items()}
if any(presence.values()):
    raise ValueError("v7 already has activation or output; inspect existing run instead")
result = {
    "schema": "flydrones-v7-current-readonly-preflight-v1",
    "selected_study_sha256": expected_study,
    "selected_diagnostic_sha256": expected_diagnostic,
    "study_binding_valid_now": True,
    "diagnostic_binding_valid_now": True,
    "output_presence": presence,
    "physical_dispatched": False,
    "qualification_granted": False,
}
out = Path(__file__).resolve().parent / "result.json"
if out.exists():
    raise FileExistsError(out)
out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
print(json.dumps(result, sort_keys=True))
