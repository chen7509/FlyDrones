"""Seal the synthetic EGO diagnostic reconciler stage without prior artifacts."""

from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
members = [
    "src/flydrones/benchmark/ego_diagnostic_reconcile.py",
    "tests/benchmark/test_ego_diagnostic_reconcile.py",
    "docs/EGO_DIAGNOSTIC_RECONCILE_REPORT.md",
    "docs/superpowers/specs/2026-10-10-ego-causal-provenance-design.md",
    "docs/superpowers/plans/2026-10-10-ego-causal-provenance.md",
    "tools/benchmark/ego_causal_readonly_v2.patch",
    "results/ego-diagnostic-reconcile-dev-1701/targeted-tests.txt",
    "results/ego-diagnostic-reconcile-dev-1701/ruff.txt",
    "results/ego-diagnostic-reconcile-dev-1701/diff-check.txt",
    "results/ego-diagnostic-reconcile-dev-1701/seal.py",
]
out = root / "evidence/ego-diagnostic-reconcile-dev-1701.zip"
manifest = {
    "stage": "synthetic_offline_candidate_only",
    "runtime_source_verified": False,
    "teacher_qualified": False,
    "members": {},
}
with zipfile.ZipFile(out, "x", compression=zipfile.ZIP_DEFLATED) as archive:
    for name in members:
        payload = (root / name).read_bytes()
        archive.writestr(name, payload)
        manifest["members"][name] = {
            "sha256": hashlib.sha256(payload).hexdigest(),
            "size": len(payload),
        }
    archive.writestr("manifest.json", json.dumps(manifest, sort_keys=True, indent=2) + "\n")
with zipfile.ZipFile(out) as archive:
    if archive.testzip() is not None:
        raise RuntimeError("ZIP CRC failure")
    for name, item in manifest["members"].items():
        if hashlib.sha256(archive.read(name)).hexdigest() != item["sha256"]:
            raise RuntimeError(f"ZIP member mismatch: {name}")
print(out)
print(hashlib.sha256(out.read_bytes()).hexdigest())
print(len(members) + 1)
