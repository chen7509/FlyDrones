"""Add reason logging to the already stage-instrumented upstream checkout."""

import sys
from pathlib import Path


source = Path(sys.argv[1]) / "ov_core/src/feat/FeatureInitializer.cpp"
text = source.read_text()


def replace_once(old: str, new: str) -> None:
    global text
    if text.count(old) != 1:
        raise RuntimeError(f"expected one insertion point: {old[:60]}")
    text = text.replace(old, new)


replace_once('#include "FeatureInitializer.h"',
             '#include "FeatureInitializer.h"\n#include <cstdio>')
replace_once(
    '      std::isnan(p_f.norm())) {\n    return false;',
    '      std::isnan(p_f.norm())) {\n'
    '    std::fprintf(stderr, "FD_TRI_REJECT cond=%.9g max_cond=%.9g depth=%.9g min_dist=%.9g max_dist=%.9g nan=%d\\n",\n'
    '                 condA, _options.max_cond_number, p_f(2, 0), _options.min_dist, _options.max_dist,\n'
    '                 (int)std::isnan(p_f.norm()));\n'
    '    return false;',
)
replace_once(
    '      (feat->p_FinA.norm() / base_line_max) > _options.max_baseline || std::isnan(feat->p_FinA.norm())) {\n    return false;',
    '      (feat->p_FinA.norm() / base_line_max) > _options.max_baseline || std::isnan(feat->p_FinA.norm())) {\n'
    '    std::fprintf(stderr, "FD_REFINE_REJECT depth=%.9g min_dist=%.9g max_dist=%.9g baseline=%.9g ratio=%.9g max_ratio=%.9g nan=%d\\n",\n'
    '                 feat->p_FinA(2), _options.min_dist, _options.max_dist, base_line_max,\n'
    '                 feat->p_FinA.norm() / base_line_max, _options.max_baseline,\n'
    '                 (int)std::isnan(feat->p_FinA.norm()));\n'
    '    return false;',
)
source.write_text(text)
