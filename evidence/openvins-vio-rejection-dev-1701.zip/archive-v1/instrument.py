"""Diagnostic-only counters for the pinned, isolated OpenVINS checkout.

This alters logging only, not estimator conditions or configuration. Preserve
the resulting git diff and both diagnostic and original output for comparison.
"""

import sys
from pathlib import Path


def replace_once(path: Path, old: str, new: str) -> None:
    text = path.read_text()
    if text.count(old) != 1:
        raise RuntimeError(f"expected exactly one insertion point in {path}: {old[:60]}")
    path.write_text(text.replace(old, new))


root = Path(sys.argv[1])
manager = root / "ov_msckf/src/core/VioManager.cpp"
updater = root / "ov_msckf/src/update/UpdaterMSCKF.cpp"

replace_once(manager, '#include "VioManager.h"', '#include "VioManager.h"\n#include <cstdio>')
replace_once(
    manager,
    '  updaterMSCKF->update(state, featsup_MSCKF);',
    '  std::fprintf(stderr, "FD_VIO_STAGE t=%.9f lost=%zu marg=%zu maxtracks=%zu candidate=%zu\\n",\n'
    '               message.timestamp, feats_lost.size(), feats_marg.size(),\n'
    '               feats_maxtracks.size(), featsup_MSCKF.size());\n'
    '  updaterMSCKF->update(state, featsup_MSCKF);',
)
replace_once(updater, '#include "UpdaterMSCKF.h"', '#include "UpdaterMSCKF.h"\n#include <cstdio>')
replace_once(
    updater,
    '  if (feature_vec.empty())\n    return;',
    '  const size_t fd_input = feature_vec.size();\n'
    '  if (feature_vec.empty()) {\n'
    '    std::fprintf(stderr, "FD_MSCKF_STAGE t=%.9f input=0 clean=0 tri=0 chi2=0 tri_fail=0 refine_fail=0 chi2_fail=0\\n", state->_timestamp);\n'
    '    return;\n'
    '  }',
)
replace_once(
    updater,
    '  rT1 = boost::posix_time::microsec_clock::local_time();',
    '  const size_t fd_after_clean = feature_vec.size();\n'
    '  rT1 = boost::posix_time::microsec_clock::local_time();',
)
replace_once(
    updater,
    '  auto it1 = feature_vec.begin();\n  while (it1 != feature_vec.end()) {',
    '  size_t fd_tri_fail = 0, fd_refine_fail = 0;\n'
    '  auto it1 = feature_vec.begin();\n  while (it1 != feature_vec.end()) {',
)
replace_once(
    updater,
    '    if (!success_tri || !success_refine) {\n      (*it1)->to_delete = true;',
    '    if (!success_tri || !success_refine) {\n'
    '      fd_tri_fail += !success_tri;\n'
    '      fd_refine_fail += success_tri && !success_refine;\n'
    '      (*it1)->to_delete = true;',
)
replace_once(
    updater,
    '  rT2 = boost::posix_time::microsec_clock::local_time();',
    '  const size_t fd_after_tri = feature_vec.size();\n'
    '  rT2 = boost::posix_time::microsec_clock::local_time();',
)
replace_once(
    updater,
    '  auto it2 = feature_vec.begin();\n  while (it2 != feature_vec.end()) {',
    '  size_t fd_chi2_fail = 0;\n'
    '  auto it2 = feature_vec.begin();\n  while (it2 != feature_vec.end()) {',
)
replace_once(
    updater,
    '    if (chi2 > _options.chi2_multipler * chi2_check) {\n      (*it2)->to_delete = true;',
    '    if (chi2 > _options.chi2_multipler * chi2_check) {\n'
    '      fd_chi2_fail++;\n'
    '      (*it2)->to_delete = true;',
)
replace_once(
    updater,
    '  rT3 = boost::posix_time::microsec_clock::local_time();',
    '  std::fprintf(stderr, "FD_MSCKF_STAGE t=%.9f input=%zu clean=%zu tri=%zu chi2=%zu tri_fail=%zu refine_fail=%zu chi2_fail=%zu\\n",\n'
    '               state->_timestamp, fd_input, fd_after_clean, fd_after_tri, feature_vec.size(),\n'
    '               fd_tri_fail, fd_refine_fail, fd_chi2_fail);\n'
    '  rT3 = boost::posix_time::microsec_clock::local_time();',
)
