# Reproduce the OpenVINS rejection trace

Base source: rpng/open_vins `69488123ed9362dd44b6f28e7f4680abbff1442b`
(GPL-3.0). Apply `instrumentation-v2.patch` to a separate clean checkout.
The patch adds diagnostic `fprintf` calls only; it changes no branch conditions,
measurements, calibration, or estimator settings. Build on Ubuntu/WSL2:

```sh
cmake -S /path/to/open_vins/ov_msckf -B /path/to/open_vins/ov_msckf/build \
  -DENABLE_ROS=OFF -DCMAKE_BUILD_TYPE=Release
cmake --build /path/to/open_vins/ov_msckf/build -j2
LD_LIBRARY_PATH=/path/to/open_vins/ov_msckf/build \
  /path/to/offline_probe \
  /path/to/config-v2/estimator_config.yaml \
  /path/to/input-v1 /path/to/episode-v1 /new/path/states.csv \
  >stdout.txt 2>stderr.txt
```

The `offline_probe` runner, config, input, and episode are preserved in the
two preceding evidence bundles `openvins-offline-1701.zip` and
`openvins-texture-dev-1701.zip`. Their SHA-256 references are in `metadata.json`.
The original and diagnostic state CSV SHA-256 are identical:
`f0f1966527c80bc49a5d219053a3e9c282aeb04eab7439dccd0fe3d265f8740f`.
The diagnostic shared objects were deliberately omitted from this compact ZIP;
their hashes and sizes are in `metadata.json`. Rebuild from the pinned upstream
commit and included patch. `CMakeCache.txt` records local build options.
