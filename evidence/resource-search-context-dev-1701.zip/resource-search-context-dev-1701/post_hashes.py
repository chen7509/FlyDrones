import json,hashlib
from pathlib import Path
r=Path(__file__).resolve().parent
before=json.loads((r/'build-v1/build-hashes.json').read_text())
after=[dict(path=row['path'],sha256=hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()) for row in before]
assert before==after
(r/'query-post-hashes.json').write_text(json.dumps(after,indent=2))
print(len(after),'source/binary/dependency hashes unchanged')
