# Next dependency: actual learned-core inference

Read-only findings on 2026-10-09; no adapter implemented or full model loaded.

- `benchmark/fly.py` uses Brain/LIFNetwork, retina/input encoder and motor
  decoder. It has no learned-core checkpoint loader. Its historical timing is
  a different runtime from `ConnectomeConstrainedCore`.
- `connectome_training/model.py:forward_step` computes a dense neuron state
  update with sparse signed normalized topology, sigmoid recurrence and tanh
  readout. It is a differentiable rate-based core, not the original stochastic
  spiking LIF dynamics. Keep this distinction explicit even with full topology.
- `features.py:_frame_features` already defines 12 training features; reuse the
  exact function through a public API rather than fake TeacherTarget objects.
  Student features must not read labels or `camera_pose` truth.
- `sequence_tensors` labels are ENU velocity and yaw rate in SI units; do not
  invent another body-frame conversion or silently rescale tanh outputs. Future
  offline adapter should retain raw output and separately bounded intent under
  the existing declared safety envelope. It cannot bypass safety/PX4.
- `ConnectomeCurriculumSession.save_checkpoint` saves only four named learned
  parameters, with topology, feature/neuron mapping and dataset identities.
  Inference must validate exact names/shapes/dtype/finiteness and copy parameters
  only; it must not let a checkpoint overwrite fixed topology buffers.
- Legacy Stage B smoke checkpoint is a different format of model state and has
  topology `41056f1a9c164332139f0266409bc56dcd09b315e38712a7ddfaa6fc37a79d4a`.
  Full initialization topology is
  `ac7e555e8889285d819fe540027ed5460804feaf924a79e4431a945c63699746`.
  Do not relabel the smoke artifact as a learned complete model.
- Reuse `load_parameter_set` and `load_checkpoint(weights_only=True)`; avoid
  optimizer construction/restoration or restoring global RNG for inference.
  Pin complete source/model/mapping identity before loading checkpoints. An
  initialization-only profile must say untrained, even if model size is full.
- State must be causal and per-session, with explicit reset and refusal after
  invalid time/source/shape/nonfinite state or output. Test state continuity and
  reset against direct core calls, using tiny topology fixtures labeled tiny.
- CPU synchronous inference first. No claim of GPU timing, full model speedup,
  real corpus training, live input provenance or flight readiness from fixtures.

Official PyTorch documents read:
https://docs.pytorch.org/docs/2.14/generated/torch.autograd.grad_mode.inference_mode.html
https://docs.pytorch.org/docs/2.14/notes/serialization.html
`inference_mode` is thread-local and does not itself set evaluation mode; use
both explicit model.eval and inference context. Restricted checkpoint loading
does not prove semantic identity or protect against all malformed tensor data.
Before implementation, record installed version/source/license and maintenance
metadata, finish the independent spec/plan, and verify the exact checkpoint
metadata contract. No new training or flight activation is authorized by this
research note.
