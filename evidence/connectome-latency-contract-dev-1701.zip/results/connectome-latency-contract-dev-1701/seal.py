"""Retain this bounded offline correction; never replaces old evidence."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path(__file__).resolve().parents[2]
result = Path(__file__).resolve().parent
archive = root / "evidence/connectome-latency-contract-dev-1701.zip"
files = [
    "src/flydrones/connectome_training/profiling.py",
    "tools/connectome_training/profile_baseline.py",
    "tests/connectome_training/test_profiling.py",
    "tests/connectome_training/test_profile_baseline.py",
    "docs/CONNECTOME_LATENCY_CONTRACT_REPORT.md",
    "configs/connectome_training_v1.yaml",
    "results/connectome-training/stage-a/baseline_profile.json",
    "results/connectome-training/stage-b/full-initialization/manifest.json",
    "results/connectome-training/stage-b/smoke_report.json",
    "docs/CONNECTOME_TRAINING.md",
]
files += [str(path.relative_to(root)).replace("\\", "/")
          for path in sorted(result.iterdir()) if path.is_file()]
baseline = root / files[6]
expected = "40b9765ba77ad9efd6d87e926831824e969ab876b4ffe9dc02f2c407169a6534"
assert hashlib.sha256(baseline.read_bytes()).hexdigest() == expected
manifest = {
    "scope": "offline measurement contract; no new full-model run, training or physics",
    "source_commit": subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(),
    "copies": "post-verification snapshots, not runtime pre/post attestation",
    "files": [],
}
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as bundle:
    for name in files:
        data = (root / name).read_bytes()
        bundle.writestr(name, data)
        manifest["files"].append({"path": name, "bytes": len(data),
                                  "sha256": hashlib.sha256(data).hexdigest()})
    bundle.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    for entry in manifest["files"]:
        data = bundle.read(entry["path"])
        assert len(data) == entry["bytes"]
        assert hashlib.sha256(data).hexdigest() == entry["sha256"]
print(json.dumps({"archive": str(archive), "members": len(files) + 1,
                  "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
                  "baseline_unchanged": True}))
