"""Refuse a pinned offline Agent build before Docker launch when resources are low."""

from __future__ import annotations

import ctypes
import json
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
IMAGE = "sha256:a4dae62b38bc01a01d084be7b68db83ec804fef7673604e1a9c986a4baa88a6a"
SOURCE = "/tmp/flydrones-agent-offline-1701-v4/agent-src/cmake/SuperBuild.cmake"
SOURCE_SHA256 = "9621355850e1095dcd2983a7c3573010453ec4b816350c205bdb32ebf6aaf640"
HOST_MIN_BYTES = 2 * 1024**3


class MemoryStatus(ctypes.Structure):
    _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]


def run(args: list[str]) -> dict:
    result = subprocess.run(args, capture_output=True, text=True, errors="replace", timeout=15)
    return {"args": args, "returncode": result.returncode,
            "stdout": result.stdout, "stderr": result.stderr}


def main() -> None:
    memory = MemoryStatus()
    memory.dwLength = ctypes.sizeof(memory)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(memory)):
        raise OSError("Windows physical memory query failed")
    docker_ps = run(["docker", "ps", "--format", "{{.Names}}"])
    image = run(["docker", "image", "inspect", IMAGE, "--format", "{{.Id}}"])
    source = run(["wsl", "-d", "Ubuntu", "--", "sha256sum", SOURCE])
    no_competition = docker_ps["returncode"] == 0 and not docker_ps["stdout"].strip()
    source_match = (source["returncode"] == 0
                    and source["stdout"].split()[:2] == [SOURCE_SHA256, SOURCE])
    image_match = image["returncode"] == 0 and image["stdout"].strip() == IMAGE
    eligible = (memory.ullAvailPhys >= HOST_MIN_BYTES and no_competition
                and source_match and image_match)
    record = {"schema": "flydrones.agent_humble_rebuild_preflight.v1",
              "observed_unix_ns": time.time_ns(), "host_total_bytes": memory.ullTotalPhys,
              "host_available_bytes": memory.ullAvailPhys,
              "host_min_bytes": HOST_MIN_BYTES, "docker_ps": docker_ps,
              "pinned_image": image, "pinned_source": source,
              "no_competition": no_competition,
              "source_match": source_match, "image_match": image_match,
              "status": "ready_not_launched" if eligible else "preflight_refused",
              "container_started": False, "build_started": False,
              "dds_discovery_verified": False, "px4_source_authenticated": False}
    path = ROOT / "preflight.json"
    if path.exists():
        raise FileExistsError("preflight evidence already exists")
    path.write_text(json.dumps(record, indent=2), encoding="utf-8")
    print(json.dumps({"status": record["status"],
                      "host_available_bytes": record["host_available_bytes"],
                      "source_match": source_match, "image_match": image_match,
                      "container_started": False}))


if __name__ == "__main__":
    main()
