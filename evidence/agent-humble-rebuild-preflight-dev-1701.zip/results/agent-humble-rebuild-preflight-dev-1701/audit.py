"""Audit the recorded resource refusal; no build or DDS qualification is inferred."""

from __future__ import annotations

import json
from pathlib import Path

root = Path(__file__).resolve().parent
record = json.loads((root / "preflight.json").read_text(encoding="utf-8"))
assert record["schema"] == "flydrones.agent_humble_rebuild_preflight.v1"
assert record["host_min_bytes"] == 2 * 1024**3
assert 0 < record["host_available_bytes"] < record["host_min_bytes"]
assert record["no_competition"] is True
assert record["docker_ps"]["returncode"] == 0
assert not record["docker_ps"]["stdout"].strip()
assert record["source_match"] is True
assert record["pinned_source"]["returncode"] == 0
assert record["pinned_source"]["stdout"].split()[:2] == [
    "9621355850e1095dcd2983a7c3573010453ec4b816350c205bdb32ebf6aaf640",
    "/tmp/flydrones-agent-offline-1701-v4/agent-src/cmake/SuperBuild.cmake",
]
assert record["image_match"] is True
assert record["pinned_image"]["returncode"] == 0
assert record["pinned_image"]["stdout"].strip() == (
    "sha256:a4dae62b38bc01a01d084be7b68db83ec804fef7673604e1a9c986a4baa88a6a")
assert record["status"] == "preflight_refused"
assert record["container_started"] is record["build_started"] is False
assert record["dds_discovery_verified"] is record["px4_source_authenticated"] is False
audit = {"schema": "flydrones.agent_humble_rebuild_preflight_audit.v1",
         "resource_refusal_verified": True, "source_and_image_pinned": True,
         "container_started": False, "build_started": False,
         "dds_discovery_verified": False, "px4_source_authenticated": False}
(root / "audit.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
print(json.dumps(audit))
