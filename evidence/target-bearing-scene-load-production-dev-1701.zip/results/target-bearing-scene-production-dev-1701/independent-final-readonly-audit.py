"""Independent standard-library audit of already retained v3; imports no producer."""
import hashlib
import json
import math
from pathlib import Path

study = Path(__file__).resolve().parent
root = study.parents[1]
scene = study / 'actual-scene-v3'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
norm = lambda v: math.sqrt(sum(x*x for x in v))
add = lambda a,b: [x+y for x,y in zip(a,b)]
sub = lambda a,b: [x-y for x,y in zip(a,b)]
mv = lambda a,v: [sum(x*y for x,y in zip(row,v)) for row in a]
transpose = lambda a: list(map(list, zip(*a)))
mm = lambda a,b: [[sum(a[i][k]*b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
cross = lambda a,b: [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]

def rotate(rpy):
    r,p,y = rpy
    c,s,C,S,d,e = math.cos(r),math.sin(r),math.cos(p),math.sin(p),math.cos(y),math.sin(y)
    return [[d*C,d*S*s-e*c,d*S*c+e*s],[e*C,e*S*s+d*c,e*S*c-d*s],[-S,C*s,C*c]]

record = json.loads((scene/'scene-load.json').read_text())
geometry = record['geometry']
manifest = json.loads((scene/'manifest.json').read_text())['files']
issues = []
for name,member in manifest.items():
    path = scene/name
    if path.stat().st_size != member['bytes'] or sha(path) != member['sha256']:
        issues.append('manifest mismatch: '+name)
actual_members = {p.relative_to(scene).as_posix() for p in scene.rglob('*') if p.is_file()} - {'manifest.json'}
if actual_members != set(manifest): issues.append('manifest member-set mismatch')
for name,member in record['source_bill'].items():
    if sha(scene/name) != member['sha256'] or (scene/name).stat().st_size != member['bytes']:
        issues.append('source bill mismatch: '+name)
old = study/'actual-scene-v2'
for name in record['source_bill']:
    if sha(scene/name) != sha(old/name): issues.append('model resource differs from v2: '+name)
for path in (old/'models/kalibr_aprilgrid_3x3').rglob('*'):
    if path.is_file() and sha(path) != sha(scene/'models/kalibr_aprilgrid_3x3'/path.relative_to(old/'models/kalibr_aprilgrid_3x3')):
        issues.append('sealed target differs: '+path.name)

links = geometry['links']
mass = sum(link['mass'] for link in links.values())
com = [sum(link['mass']*link['com'][a] for link in links.values())/mass for a in range(3)]
inertia = [[0.]*3 for _ in range(3)]
for link in links.values():
    delta = sub(link['com'],com)
    square = sum(x*x for x in delta)
    for a in range(3):
        for b in range(3):
            inertia[a][b] += link['inertia'][a][b]+link['mass']*((square if a==b else 0)-delta[a]*delta[b])
layout = json.loads((scene/'models/kalibr_aprilgrid_3x3/layout.json').read_text())
identities = record['design']['corner_identity']
corners = [tag['corners_target_m'][j] for tag in layout['tags'] for j in range(4)]
expected_ids = [dict(tag_id=tag['id'],layout_corner_index=j) for tag in layout['tags'] for j in range(4)]
if identities != expected_ids: issues.append('corner identity mismatch')
target_pose = record['design']['target_pose_world']
target_R = rotate(target_pose[3:])
world_corners = [add(mv(target_R,v),target_pose[:3]) for v in corners]
model_pos = geometry['model_pose_world'][:3]
camera_pos = geometry['camera_pose_model'][:3]
vertices = geometry['collision_vertices_model']
focal = 80/math.tan(1.274/2)
maximum_errors = dict(program=0.,force=0.,torque=0.,projection_pixels=0.,depth=0.,ground=0.,gap=0.,per_link_force=0.,sum_per_link_force=0.,support_moment_about_com=0.)
statistics = dict(rows=0,startup_cropped=0,max_force=0.,max_torque=0.,max_speed=0.,max_omega=0.,max_translation=0.,max_tilt=0.,min_active_depth=math.inf,max_active_depth=-math.inf,min_active_pixel_margin=math.inf,min_active_ground=math.inf,min_target_gap=math.inf)
target_center_x = target_pose[0]
for index,line in enumerate((scene/'requested-load-and-projection.jsonl').open()):
    row = json.loads(line)
    t = index/1000
    if row['relative_s'] != t: issues.append('row time mismatch '+str(index))
    statistics['rows'] += 1
    u = min(t/2,1)
    position = [0.,0.,.4*(10*u**3-15*u**4+6*u**5)]
    velocity = [0.,0.,.2*(30*u**2-60*u**3+30*u**4)]
    acceleration = [0.,0.,.1*(60*u-180*u**2+120*u**3)]
    rpy,omega,alpha = [0.]*3,[0.]*3,[0.]*3
    for axis_segment in range(6):
        u = (t-(2+2*axis_segment))/2
        if 0 <= u <= 1:
            q = 64*u**3*(1-u)**3
            dq = 192*u*u*(1-u)*(1-u)*(1-2*u)
            ddq = 384*u*(1-u)*(1-5*u+5*u*u)
            axis = axis_segment%3
            a = math.radians(8) if axis_segment<3 else .01
            if axis_segment<3:
                rpy[axis],omega[axis],alpha[axis] = a*q,a*dq/2,a*ddq/4
            else:
                position[axis]+=a*q;velocity[axis]+=a*dq/2;acceleration[axis]+=a*ddq/4
    R = rotate(rpy)
    world_inertia = mm(mm(R,inertia),transpose(R))
    torque = add(mv(world_inertia,alpha),cross(omega,mv(world_inertia,omega)))
    force = [mass*(acceleration[a]+(9.81 if a==2 else 0)) for a in range(3)]
    for name,expected in [('translation_m',position),('velocity_m_s',velocity),('rotation_rpy_rad',rpy),('omega_world_rad_s',omega)]:
        maximum_errors['program'] = max(maximum_errors['program'],max(abs(x-y) for x,y in zip(row[name],expected)))
    for key,expected,name in [('force',force,'force_world_n'),('torque',torque,'torque_world_nm')]:
        maximum_errors[key] = max(maximum_errors[key],max(abs(x-y) for x,y in zip(row[name],expected)))
    if set(row['per_link_force_world_n']) != set(links): issues.append('per-link set '+str(index))
    forces = row['per_link_force_world_n']
    summed = [sum(v[a] for v in forces.values()) for a in range(3)]
    maximum_errors['sum_per_link_force'] = max(maximum_errors['sum_per_link_force'],norm(sub(summed,row['force_world_n'])))
    moment = [0.]*3
    for name,link in links.items():
        expected = [force[a]*link['mass']/mass for a in range(3)]
        maximum_errors['per_link_force'] = max(maximum_errors['per_link_force'],norm(sub(forces[name],expected)))
        moment = add(moment,cross(mv(R,sub(link['com'],com)),forces[name]))
    maximum_errors['support_moment_about_com'] = max(maximum_errors['support_moment_about_com'],norm(moment))
    camera_world = add(add(add(model_pos,com),position),mv(R,sub(camera_pos,com)))
    local = [mv(transpose(R),sub(v,camera_world)) for v in world_corners]
    uv = [[80-focal*v[1]/v[0],60-focal*v[2]/v[0]] for v in local]
    depths = [v[0] for v in local]
    predicted_vertices = [add(add(add(model_pos,com),position),mv(R,sub(v,com))) for v in vertices]
    ground = min(v[2] for v in predicted_vertices)
    gap = target_center_x-max(v[0] for v in predicted_vertices)
    for key,actual,expected in [('depth',row['corner_depth_m'],depths),('projection_pixels',sum(row['corner_pixels'],[]),sum(uv,[]))]:
        maximum_errors[key] = max(maximum_errors[key],max(abs(x-y) for x,y in zip(actual,expected)))
    maximum_errors['ground'] = max(maximum_errors['ground'],abs(row['ground_clearance_m']-ground))
    maximum_errors['gap'] = max(maximum_errors['gap'],abs(row['target_plane_gap_m']-gap))
    count = sum(.2<=v[0]<=19.1 and 0<=pixel[0]<=160 and 0<=pixel[1]<=120 for v,pixel in zip(local,uv))
    if count != row['visible_corner_count']: issues.append('visibility '+str(index))
    for key,name in [('max_force','force_world_n'),('max_torque','torque_world_nm'),('max_speed','velocity_m_s'),('max_omega','omega_world_rad_s'),('max_translation','translation_m')]:
        statistics[key] = max(statistics[key],norm(row[name]))
    statistics['max_tilt'] = max(statistics['max_tilt'],abs(rpy[0]),abs(rpy[1]))
    statistics['min_target_gap'] = min(statistics['min_target_gap'],gap)
    if t<2 and count<36: statistics['startup_cropped'] += 1
    if 2<=t<=14:
        if count!=36: issues.append('active cropped '+str(index))
        statistics['min_active_depth'] = min(statistics['min_active_depth'],min(depths))
        statistics['max_active_depth'] = max(statistics['max_active_depth'],max(depths))
        statistics['min_active_pixel_margin'] = min(statistics['min_active_pixel_margin'],min(min(u,160-u,v,120-v) for u,v in uv))
        statistics['min_active_ground'] = min(statistics['min_active_ground'],ground)
if statistics['rows'] != 25001: issues.append('wrong row count')
if max(maximum_errors.values())>1e-10: issues.append('independent arithmetic mismatch')
spectral = max(inertia[1][1],(inertia[0][0]+inertia[2][2]+math.sqrt((inertia[0][0]-inertia[2][2])**2+4*inertia[0][2]**2))/2)
angular = math.radians(8)*3.5/2
radius = max(norm(sub(v,com)) for v in vertices)
camera_lever = norm(sub(camera_pos,com))
target_distance = max(norm(sub(v,add(model_pos,com))) for v in world_corners)
point_speed = .4+angular*(camera_lever+target_distance+.41)
depth_lower = statistics['min_active_depth']-point_speed*.001
bounds = dict(pixel_margin=statistics['min_active_pixel_margin'],pixel_variation_upper=focal*point_speed*(1/depth_lower+(target_distance+.41+camera_lever)/depth_lower**2)*.001,depth_lower_m=depth_lower,ground_lower_m=statistics['min_active_ground']-(.4+angular*radius)*.001,target_gap_lower_m=statistics['min_target_gap']-(.4+angular*radius)*.001,torque_upper_nm=spectral*(math.radians(8)*6+angular**2),force_upper_n=mass*(9.81+.578+.06),angular_speed_upper_rad_s=angular,speed_upper_m_s=.4,displacement_upper_m=.41,tilt_upper_rad=math.radians(8))
bound_error = max(abs(value-record['design']['audit']['requested_between_steps_bounds'][key]) for key,value in bounds.items())
if bound_error>1e-10: issues.append('interval-bound mismatch')
result = dict(schema='independent-target-bearing-source-review-v1',base_head='127903e115bbe4353a4e5ab7c11953ca9be13f16',review_scope='retained static v3 only; no physics/render/native consumer/new materialization',counts=dict(C=0,I=0,M=0),identities={name:sha(root/name) for name in ['tools/benchmark/calibration_capture_scene.py','tests/benchmark/test_calibration_capture_scene.py']},output_identities={name:sha(scene/name) for name in ['manifest.json','scene-load.json','world.sdf','requested-load-and-projection.jsonl']},manifest_members=len(manifest),source_bill_members=len(record['source_bill']),source_bill_bytes=sum(v['bytes'] for v in record['source_bill'].values()),issues=issues,aggregate=dict(mass_kg=mass,com_model_m=com,inertia=inertia),nominal_initial_ground_m=min(v[2]+model_pos[2] for v in vertices),target_pose_world=target_pose,maximum_recomputation_errors=maximum_errors,statistics=statistics,requested_interval_bounds=bounds,interval_bound_error=bound_error,qualification=record['qualification'],runtime_graph_frozen=record['runtime_graph_frozen'],physical_dispatch_ready=record['physical_dispatch_ready'])
with (study/'independent-code-review-final.json').open('x',encoding='utf8') as stream:
    json.dump(result,stream,indent=2,allow_nan=False)
print(json.dumps(result,indent=2,allow_nan=False))
assert not issues,issues
