import hashlib
import json
from pathlib import Path

out = Path(__file__).parent
summary = {}
for version in (1, 2, 3):
    stage = out / f'actual-scene-v{version}'
    paths = [p for p in stage.rglob('*') if p.is_file()]
    summary[f'v{version}'] = dict(files=len(paths), bytes=sum(p.stat().st_size for p in paths),
                                hashes={p.relative_to(stage).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                                        for p in paths if p.name in ('scene-load.json', 'manifest.json', 'world.sdf', 'failure.json')})
archives = {}
root = out.parent.parent
for path in sorted((root / 'evidence').glob('*.zip')):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024**2), b''):
            h.update(chunk)
    archives[path.name] = dict(bytes=path.stat().st_size, sha256=h.hexdigest())
with (out / 'historical-archives.json').open('x') as stream:
    json.dump(archives, stream, indent=2)
with (out / 'bill-summary.json').open('x') as stream:
    json.dump(summary, stream, indent=2)
print(json.dumps(summary, indent=2))
print('oldarchives', len(archives), sum(p['bytes'] for p in archives.values()))
