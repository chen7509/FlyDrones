import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[2]
out = Path(__file__).parent

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024**2), b''):
            h.update(block)
    return h.hexdigest()

old = json.loads((out / 'historical-archives.json').read_text())
changes = [name for name, row in old.items() if digest(root / 'evidence' / name) != row['sha256']]
assert not changes, changes
with (out / 'historical-archives-final.json').open('x') as stream:
    json.dump(dict(count=len(old), bytes=sum(r['bytes'] for r in old.values()), changed=changes), stream, indent=2)
names = ['tools/benchmark/calibration_capture_scene.py', 'tests/benchmark/test_calibration_capture_scene.py',
         'docs/TARGET_BEARING_SCENE_LOAD_PRODUCTION_REPORT.md',
         'docs/superpowers/specs/2026-10-15-target-bearing-scene-load.md',
         'docs/superpowers/specs/2026-10-15-target-bearing-measurement-capture.md',
         'docs/superpowers/plans/2026-10-15-target-bearing-measurement-capture.md']
files = [root / name for name in names] + sorted(p for p in out.rglob('*') if p.is_file()
            and '__pycache__' not in p.parts and p.name not in ('seal-result.json',))
manifest = dict(schema='target-bearing-scene-production-evidence-v1',
                status='source-stage-implemented-software-only-full-runtime-freeze-pending',
                actual_v3_producer_sha256='104261ca43c4531f5519bf5ac4cbf90785cbb22b9ae110c24574b6748f625eef',
                current_guarded_producer_sha256=digest(root / names[0]),
                current_guard_not_replayed_through_materialization=True,
                members=[dict(path=p.relative_to(root).as_posix(), size=p.stat().st_size, sha256=digest(p)) for p in files])
archive = root / 'evidence/target-bearing-scene-load-production-dev-1701.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
    for p in files:
        z.write(p, p.relative_to(root).as_posix())
    z.writestr('MANIFEST.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in manifest['members']:
        with z.open(row['path']) as packed, (root / row['path']).open('rb') as current:
            h, count = hashlib.sha256(), 0
            for block in iter(lambda: packed.read(1024**2), b''):
                assert block == current.read(len(block)), row['path']
                h.update(block)
                count += len(block)
            assert not current.read(1)
            assert count == row['size'] and h.hexdigest() == row['sha256']
result = dict(path=archive.relative_to(root).as_posix(), sha256=digest(archive), bytes=archive.stat().st_size,
              members=len(files)+1, mapped=len(files), crc_size_sha_currentbyte_errors=0,
              historical_changed=changes, source_stage_only=True)
(out / 'seal-result.json').write_text(json.dumps(result, indent=2), encoding='utf8')
print(json.dumps(result, indent=2))
