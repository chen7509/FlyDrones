"""Separate corrected source-stage trial; the failed v1 output stays intact."""
import hashlib
import json
import os
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[2]
os.chdir(root)
sys.path[:0] = [str(root), str(root / 'src')]
import sdformat14
import numpy
from tools.benchmark.calibration_capture_scene import materialize

out = Path(__file__).parent
pre = dict(sdformat_path=sdformat14.__file__, sdformat_sha256=hashlib.sha256(Path(sdformat14.__file__).read_bytes()).hexdigest(),
           numpy_version=numpy.__version__, python=sys.version, argv=sys.argv, environment=dict(OPENBLAS_NUM_THREADS=os.environ.get('OPENBLAS_NUM_THREADS')))
with (out / 'native-precommand-v2.json').open('x') as stream:
    json.dump(pre, stream, indent=2)
record = materialize(out / 'actual-scene-v2',
                     target=root / 'results/aprilgrid-production-research-dev-1701/actual-target-v2',
                     model_roots=[root / 'assets/gazebo/models', Path.home() / 'PX4-Autopilot/Tools/simulation/gz/models'],
                     template=root / 'results/openvins-board-pattern-dev-1701/episode-v2/world.sdf')
print(json.dumps(record['geometry'], indent=2))
print(json.dumps(record['design'], indent=2))
