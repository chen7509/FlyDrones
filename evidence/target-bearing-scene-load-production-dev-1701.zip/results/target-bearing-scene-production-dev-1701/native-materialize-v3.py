"""New corrected nominal-contact study; v1 failure and v2 candidate retained."""
import hashlib
import json
import os
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[2]
os.chdir(root)
sys.path[:0] = [str(root), str(root / 'src')]
import sdformat14 as sdf
import numpy
from tools.benchmark.calibration_capture_scene import materialize

out = Path(__file__).parent
pre = dict(sdformat_path=sdf.__file__, sdformat_sha256=hashlib.sha256(Path(sdf.__file__).read_bytes()).hexdigest(),
           numpy_version=numpy.__version__, python=sys.version, argv=sys.argv, environment=dict(OPENBLAS_NUM_THREADS=os.environ.get('OPENBLAS_NUM_THREADS')))
with (out / 'native-precommand-v3.json').open('x') as stream:
    json.dump(pre, stream, indent=2)
px4 = Path.home() / 'PX4-Autopilot'
with (out / 'PX4-LICENSE').open('xb') as stream:
    stream.write((px4 / 'LICENSE').read_bytes())
stage = out / 'actual-scene-v3'
record = materialize(stage,
                     target=root / 'results/aprilgrid-production-research-dev-1701/actual-target-v2',
                     model_roots=[root / 'assets/gazebo/models', px4 / 'Tools/simulation/gz/models'],
                     template=root / 'results/openvins-board-pattern-dev-1701/episode-v2/world.sdf')
config = sdf.ParserConfig()
config.add_uri_path('model://', str(stage / 'models'))
config.set_find_callback(lambda uri: str(stage / 'models' / uri) if uri == 'x500' else '')
parsed = sdf.Root()
parsed.load(str(stage / 'world.sdf'), config)
world = parsed.world_by_index(0)
world.validate_graphs()
target = world.model_by_name('kalibr_aprilgrid_3x3')
target.validate_graphs()
pose = target.semantic_pose().resolve()
pose_values = [pose.x(), pose.y(), pose.z(), pose.rot().roll(), pose.rot().pitch(), pose.rot().yaw()]
assert target.static() and target.link_count() == 1
assert numpy.allclose(pose_values, record['design']['target_pose_world'])
assert world.model_count() == 3
check = dict(native_final_world_accepted=True, target_pose_world=pose_values,
             models=[world.model_by_index(i).name() for i in range(world.model_count())],
             renderer_tested=False, physics_tested=False, qualification=record['qualification'])
with (out / 'native-final-world-v3.json').open('x') as stream:
    json.dump(check, stream, indent=2)
print(json.dumps(dict(geometry={k:record['geometry'][k] for k in ('mass_kg', 'com_model_m', 'inertia_com_model_kg_m2', 'model_pose_world', 'camera_pose_model', 'initial_placement')},
                      design=record['design'], final_world=check), indent=2))
