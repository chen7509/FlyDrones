import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parents[2]
out = pathlib.Path(__file__).parent
name = sys.argv[1]
trial = out / name
trial.mkdir(exist_ok=False)
source = ['tools/benchmark/calibration_capture_scene.py', 'tests/benchmark/test_calibration_capture_scene.py']
records = {}
for path in source:
    blob = (root / path).read_bytes()
    destination = trial / 'source' / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(blob)
    records[path] = hashlib.sha256(blob).hexdigest()
argv = sys.argv[2:]
record = dict(argv=argv, cwd=str(root), start_utc=datetime.datetime.now(datetime.UTC).isoformat(),
              env={k: os.environ.get(k) for k in ('PYTHONUTF8', 'PYTHONPATH', 'OPENBLAS_NUM_THREADS')},
              source_before_sha256=records)
(trial / 'command.json').write_text(json.dumps(record, indent=2), encoding='utf8')
with (trial / 'stdout.bin').open('xb') as stdout, (trial / 'stderr.bin').open('xb') as stderr:
    done = subprocess.run(argv, cwd=root, stdout=stdout, stderr=stderr)
record.update(exit=done.returncode, end_utc=datetime.datetime.now(datetime.UTC).isoformat(),
              source_after_sha256={p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in source})
(trial / 'completion.json').write_text(json.dumps(record, indent=2), encoding='utf8')
print(json.dumps(record, indent=2))
print((trial / 'stdout.bin').read_text(encoding='utf8', errors='replace')[-4000:])
print((trial / 'stderr.bin').read_text(encoding='utf8', errors='replace')[-4000:])
raise SystemExit(done.returncode)
