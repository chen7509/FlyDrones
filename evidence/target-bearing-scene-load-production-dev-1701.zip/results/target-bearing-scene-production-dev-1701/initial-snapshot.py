import json
import pathlib
from tools.benchmark.run_openvins_dataset_consumer import admission
facts = admission()
with (pathlib.Path(__file__).parent / 'initial-readonly.json').open('x') as stream:
    json.dump(facts, stream, indent=2)
print(json.dumps({k: facts[k] for k in ('windows_available', 'blocked_processes', 'docker_exit', 'admitted')}))
print('WSL available:', facts['wsl']['available'])
