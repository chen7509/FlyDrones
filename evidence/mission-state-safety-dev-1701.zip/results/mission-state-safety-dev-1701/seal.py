import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

root = Path.cwd()
study = root / 'results/mission-state-safety-dev-1701'
exits = json.loads((study / 'final-verification-exits.json').read_text(encoding='utf-8-sig'))
assert all(value == 0 for value in exits.values())
assert '87 passed' in (study / 'final-green.txt').read_text(encoding='utf-8-sig')
assert '21 failed' in (study / 'red.txt').read_text(encoding='utf-8-sig')
assert '4 failed' in (study / 'review-red.txt').read_text(encoding='utf-8-sig')
assert '1 failed' in (study / 'peer-overflow-red.txt').read_text(encoding='utf-8-sig')
files = {p.relative_to(root).as_posix(): p.read_bytes() for p in study.iterdir()
         if p.is_file() and p.name not in {'seal.json', 'pr65-before.json', 'pr65-body.md'}}
for rel in [
    'src/flydrones/mission_agent.py', 'src/flydrones/mission_contract.py',
    'src/flydrones/task_consensus.py', 'src/flydrones/task_udp.py', 'src/flydrones/peer_udp.py',
    'tests/test_mission_agent.py', 'tests/test_mission_contract.py',
    'tests/test_task_consensus.py', 'tests/test_task_udp.py',
    'docs/MISSION_STATE_SAFETY_REPORT.md',
    'docs/superpowers/plans/2026-10-14-mission-state-safety.md',
]:
    files[rel] = (root / rel).read_bytes()
manifest = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
            for name, data in sorted(files.items())}
archive = root / 'evidence/mission-state-safety-dev-1701.zip'
with ZipFile(archive, 'x', ZIP_DEFLATED) as z:
    for name, data in sorted(files.items()):
        z.writestr(name, data)
    z.writestr('manifest.json', json.dumps(manifest, indent=2))
with ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(set(z.namelist()))
    for name, entry in manifest.items():
        data = z.read(name)
        assert len(data) == entry['bytes']
        assert hashlib.sha256(data).hexdigest() == entry['sha256']
        assert data == (root / name).read_bytes()
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
archive.with_suffix('.sha256').open('x').write(digest + '  ' + archive.name + '\n')
record = {'sha256': digest, 'members': len(manifest) + 1, 'bytes': archive.stat().st_size,
          'crc_member_hash_verified': True, 'tests_passed': 87, 'full_model_trained': False,
          'live_source_authenticated': False, 'physical_recovery_verified': False}
(study / 'seal.json').open('x').write(json.dumps(record, indent=2))
print(json.dumps(record))
