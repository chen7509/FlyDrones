# One bounded executor pass

Original review C0/I2/M2 and15 original byte pins remain immutable. All four findings resolved; no second whole source/native/delivery review or deferred source Minor.

## I1

fixed: Receiver callbacks and lane lock snapshot precede concrete source/native selection revalidation, then final clock/freshness with no later callbacks. Point-in-time, not atomic with OS send.

Cost: bounded source/test work in this pass

## I2

fixed: Register native cleanup immediately after create_client returns, before capture session/ShadowInput/causal installation. Existing journal retains primary and cleanup errors.

Cost: bounded source/test work in this pass

## M1

fixed: Public session evidence derives attempted/full/short/no-return counts from retained actual outcomes; v2 check states explicit lifecycle policy. No-return is unknown, not absence of effect. Full send return never proves receipt/fusion.

Cost: bounded source/test work in this pass

## M2

fixed: Add exact native_offset_reset_v2/CMakeLists.txt to prospective v2 runtime input closure; recorder-v2 already declared it before review. No binary attestation.

Cost: bounded source/test work in this pass

## D1

accepted scope boundary; no grant: Retain uncompiled/unrun status. Do not configure, compile, probe or rerun any old consumed native target. Future exact source/build/ABI/offset/reset admission remains required.

Cost: Requires a separately admitted exact source/tool/library closure and a new eligible target run; not an extra software review or old rerun.

## D2

accepted scope boundary; no grant: Retain receiver-only disabled-EV transport and all fusion/receipt/readiness flags false. Actual EKF2 experiments require future eligible disarmed run; no PARAM_SET/ARM is added.

Cost: Requires future eligible owned disarmed receiver/ULog experiments and separately gated fusion/mission evidence.

## D3

accepted scope boundary; no grant: No optional null-injection hardening added: no reachable null-state/reset API was established in this route. Native child loss remains fail-closed. This is an unproven arbitrary mutation scope, not deferred source Minor.

Cost: A defensive null/identity-first guard would be a small source hardening change; proving all upstream mutation/reset behavior requires native evidence under D1.

## D4

accepted scope boundary; no grant: Nonce/PID/profile/offset echo and source stability are explicitly correlation only. Future exact binary/build receipt is required; software tests cannot supply it.

Cost: Requires an independently admitted binary/source/build receipt; cannot be established by repeating Python protocol tests.

## D5

accepted scope boundary; no grant: No calibration/noise/accuracy/RTF/general quality-reset grant. Preserve original sensor, timing, safety/resource/once gates and native terminal-reset policy; no synthetic health/covariance.

Cost: Requires new measured calibration, native timing and owned sensor/estimator evidence; no budget/sensor/gate relaxation.

