"""Prospective offset/native-lifecycle/receiver integration; injected OS only."""

import os
import socket
import subprocess
from types import SimpleNamespace

import numpy as np
import pytest


@pytest.fixture(autouse=True)
def inert(monkeypatch):
    def denied(*args, **kwargs):
        raise AssertionError("native process/network forbidden in software tests")
    monkeypatch.setattr(socket,"socket",denied)
    monkeypatch.setattr(subprocess,"Popen",denied)
    monkeypatch.setattr(os,"system",denied)


@pytest.mark.parametrize("offset,boundary",[(7_000_000,108_000_000),(-7_000_000,96_000_000)])
def test_offset_causal_release_uses_shifted_imu_boundary_without_relabeling_image(offset,boundary):
    from tools.benchmark.offset_reset_native_source import OffsetCausalInput
    obj=OffsetCausalInput(session_id="native-session",clock_id="clock",offset_ns=offset)
    obj._pending={'rgb':{100_000_000:({'arrival_monotonic_ns':1},0)},
                  'info':{100_000_000:({'arrival_monotonic_ns':2,'camera_info':{}},1)}}
    obj._imu_first=4_000_000
    obj._imu_latest=100_000_000+offset
    assert obj._release()==[]
    obj._imu_latest=boundary
    value=obj._release()[0]
    assert value['sample_ns']==100_000_000
    assert value['imu_lookup_ns']==100_000_000+offset
    assert value['imu_boundary_ns']==boundary


@pytest.mark.parametrize("fault",['native_pid','native_session','camera_imu_offset_ns','reset_total'])
def test_native_lifecycle_actual_fields_cannot_change_or_resume(fault):
    from tools.benchmark.offset_reset_native_source import NativeLifecycleBinding
    process=SimpleNamespace(pid=42,poll=lambda:None)
    binding=NativeLifecycleBinding(process,'a'*64,7_000_000)
    row=dict(native_profile='offset-reset-v2',native_pid=42,native_session='a'*64,
             camera_imu_offset_ns=7_000_000,reset_total=0,reset_counter=0,native_lifecycle_known=True)
    assert binding.accept(row)==0
    row[fault]='b'*64 if fault=='native_session' else row[fault]+1
    with pytest.raises(ValueError):binding.accept(row)
    with pytest.raises(ValueError,match='latched'):binding.accept({})


def test_disarmed_odometry_encodes_current_native_sample_and_unknown_quality():
    from tools.benchmark.disarmed_odometry_receiver import DisarmedOdometryReceiver
    from tools.benchmark.openvins_timesync_wire import PinnedCodec
    from tools.benchmark.openvins_ekf2_disarmed_preflight import RemoteMonotonicClock
    state=dict(sample_ns=120_000_000,reset_counter=0,reset_total=0,native_profile='offset-reset-v2',
               native_state13=[0.,0.,0.,1.,1.,2.,3.,4.,5.,6.,0.,0.,.5],native_covariance12=np.eye(12).tolist(),
               native_session='a'*64,native_pid=42,quality=None)
    source=SimpleNamespace(wire_snapshot=lambda sim:state)
    receiver=DisarmedOdometryReceiver(source)
    clock=RemoteMonotonicClock('wire',sim_origin_ns=0,remote_origin_ns=1_000_000)
    receiver.response_ns=100
    raw=receiver.odometry(PinnedCodec(),clock,13,101,120_000_000,disarmed=True)
    row=PinnedCodec().decode_datagram(raw)[0]
    assert row['type']=='ODOMETRY'
    fields=row['fields']
    assert fields['time_usec']==121000
    assert fields['quality']==0 and fields['reset_counter']==0
    assert fields['frame_id']==20 and fields['child_frame_id']==12
    assert fields['z']==-3. and fields['vx']==4.
    assert receiver.odometry(PinnedCodec(),clock,14,102,120_000_000,disarmed=True) is None
