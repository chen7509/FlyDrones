"""Prospective offset/native-lifecycle/receiver integration; injected OS only."""

import os
import socket
import subprocess
from types import SimpleNamespace

import numpy as np
import pytest


@pytest.fixture(autouse=True)
def inert(monkeypatch):
    def denied(*args, **kwargs):
        raise AssertionError("native process/network forbidden in software tests")
    monkeypatch.setattr(socket,"socket",denied)
    monkeypatch.setattr(subprocess,"Popen",denied)
    monkeypatch.setattr(os,"system",denied)


@pytest.mark.parametrize("offset,boundary",[(7_000_000,108_000_000),(-7_000_000,96_000_000)])
def test_offset_causal_release_uses_shifted_imu_boundary_without_relabeling_image(offset,boundary):
    from tools.benchmark.offset_reset_native_source import OffsetCausalInput
    obj=OffsetCausalInput(session_id="native-session",clock_id="clock",offset_ns=offset)
    obj._pending={'rgb':{100_000_000:({'arrival_monotonic_ns':1},0)},
                  'info':{100_000_000:({'arrival_monotonic_ns':2,'camera_info':{}},1)}}
    obj._imu_first=4_000_000
    obj._imu_latest=100_000_000+offset
    assert obj._release()==[]
    obj._imu_latest=boundary
    value=obj._release()[0]
    assert value['sample_ns']==100_000_000
    assert value['imu_lookup_ns']==100_000_000+offset
    assert value['imu_boundary_ns']==boundary


@pytest.mark.parametrize("fault",['native_pid','native_session','camera_imu_offset_ns','reset_total'])
def test_native_lifecycle_actual_fields_cannot_change_or_resume(fault):
    from tools.benchmark.offset_reset_native_source import NativeLifecycleBinding
    process=SimpleNamespace(pid=42,poll=lambda:None)
    binding=NativeLifecycleBinding(process,'a'*64,7_000_000)
    row=dict(native_profile='offset-reset-v2',native_pid=42,native_session='a'*64,
             camera_imu_offset_ns=7_000_000,reset_total=0,reset_counter=0,native_lifecycle_known=True)
    assert binding.accept(row)==0
    row[fault]='b'*64 if fault=='native_session' else row[fault]+1
    with pytest.raises(ValueError):binding.accept(row)
    with pytest.raises(ValueError,match='latched'):binding.accept({})


def test_disarmed_odometry_encodes_current_native_sample_and_unknown_quality():
    from tools.benchmark.disarmed_odometry_receiver import DisarmedOdometryReceiver
    from tools.benchmark.openvins_timesync_wire import PinnedCodec
    from tools.benchmark.openvins_ekf2_disarmed_preflight import RemoteMonotonicClock
    state=dict(sample_ns=120_000_000,reset_counter=0,reset_total=0,native_profile='offset-reset-v2',
               native_state13=[0.,0.,0.,1.,1.,2.,3.,4.,5.,6.,0.,0.,.5],native_covariance12=np.eye(12).tolist(),
               native_session='a'*64,native_pid=42,quality=None)
    source=SimpleNamespace(wire_snapshot=lambda sim:state)
    receiver=DisarmedOdometryReceiver(source)
    clock=RemoteMonotonicClock('wire',sim_origin_ns=0,remote_origin_ns=1_000_000)
    receiver.response_ns=100
    raw=receiver.odometry(PinnedCodec(),clock,13,101,120_000_000,disarmed=True)
    row=PinnedCodec().decode_datagram(raw)[0]
    assert row['type']=='ODOMETRY'
    fields=row['fields']
    assert fields['time_usec']==121000
    assert fields['quality']==0 and fields['reset_counter']==0
    assert fields['frame_id']==20 and fields['child_frame_id']==12
    assert fields['z']==-3. and fields['vx']==4.
    assert receiver.odometry(PinnedCodec(),clock,14,102,120_000_000,disarmed=True) is None


def selected_args(tmp_path):
    from tools.benchmark.capture_disarmed_sensors import parse_capture_args
    return parse_capture_args(['--output',str(tmp_path/'capture'),'--shadow-binary',str(tmp_path/'native-v2'),
        '--shadow-config',str(tmp_path/'estimator_config.yaml'),'--online-estimate-feed',
        '--managed-source-config',str(tmp_path/'managed.json'),'--managed-source-sha256','a'*64,
        '--execution-contract',str(tmp_path/'execution.json'),'--runtime-binding',str(tmp_path/'binding.json'),
        '--wire-config',str(tmp_path/'wire.json'),'--source-fanout-profile','ready-shadow-heartbeat-estimator-v1',
        '--reference-module',str(tmp_path/'reference.py'),'--reference-sha256','b'*64,
        '--motion-profile','supported-ready-v1','--physics-trace-profile','substep-ready-v1',
        '--native-estimate-profile','offset-reset-v2','--disarmed-odometry'])


def artifact_offset(tmp_path, offset=7_000_000):
    import hashlib,json
    from tests.benchmark.test_managed_capture_source import calibration
    from flydrones.benchmark.kalibr_camera_consumption import KalibrCameraArtifact,RAW_IMU_CONTRACT
    _,rig,_=calibration(tmp_path)
    camera=json.loads((tmp_path/'camchain.yaml').read_bytes())
    camera['cam0']['timeshift_cam_imu']=offset/1e9
    raw=json.dumps(camera).encode();(tmp_path/'camchain.yaml').write_bytes(raw)
    doc=json.loads((tmp_path/'artifact.json').read_bytes());doc['camchain']['sha256']=hashlib.sha256(raw).hexdigest()
    raw=json.dumps(doc).encode();(tmp_path/'artifact.json').write_bytes(raw)
    return KalibrCameraArtifact.load(tmp_path/'artifact.json',hashlib.sha256(raw).hexdigest(),rig,imu_contract=RAW_IMU_CONTRACT)


def test_actual_capture_factory_selects_v2_command_nonce_offset_and_worker_flags(tmp_path,monkeypatch):
    from tools.benchmark import managed_capture_source as managed
    from tools.benchmark import offset_reset_native_source as native
    from tools.benchmark.capture_disarmed_sensors import make_capture_native_client
    from tools.benchmark.capture_contract import worker_options
    artifact=artifact_offset(tmp_path)
    calls=[]
    monkeypatch.setattr(managed,'load_managed_configuration',lambda *args,**kwargs:(artifact,()))
    def init(self,command,output,*,source,**kwargs):
        calls.append((command,source))
        self.managed_source=source
    monkeypatch.setattr(native.OffsetResetNativeClient,'__init__',init)
    args=selected_args(tmp_path)
    client=make_capture_native_client(args,tmp_path,on_first_ack=None)
    assert type(client) is native.OffsetResetNativeClient
    assert len(calls[0][0])==6 and calls[0][0][-1]=='7000000'
    assert calls[0][0][-2]==client.managed_source.native_session and len(calls[0][0][-2])==64
    flags=worker_options(args)
    assert '--disarmed-odometry' in flags and flags[flags.index('--native-estimate-profile')+1]=='offset-reset-v2'


def test_actual_observed_poll_sends_odometry_on_same_sequence_and_retains_return(monkeypatch):
    from tools.benchmark.openvins_observed_wire_session import ObservedWireSession
    from tools.benchmark.disarmed_odometry_receiver import DisarmedOdometryReceiver
    from tools.benchmark.openvins_timesync_wire import PinnedCodec
    from tools.benchmark.openvins_ekf2_disarmed_preflight import RemoteMonotonicClock
    state=dict(sample_ns=120_000_000,reset_counter=0,reset_total=0,native_profile='offset-reset-v2',
               native_state13=[0.,0.,0.,1.,1.,2.,3.,4.,5.,6.,0.,0.,.5],native_covariance12=np.eye(12).tolist(),
               native_session='a'*64,native_pid=42,quality=None)
    source=SimpleNamespace(wire_snapshot=lambda sim:state)
    observer=DisarmedOdometryReceiver(source);observer.request_ns=100;observer.response_ns=101
    owner=object.__new__(ObservedWireSession)
    owner._estimate_receiver=observer;owner._maintenance=object();owner._estimate_events=[]
    codec=PinnedCodec()
    wire=SimpleNamespace(_codec=codec,_sequence=32,_peer=('127.0.0.1',14588),_last_unarmed=100)
    owner._core=SimpleNamespace(_wire=wire,_owned=SimpleNamespace(check=lambda **kwargs:None))
    owner._remote=RemoteMonotonicClock('wire',sim_origin_ns=0,remote_origin_ns=1_000_000)
    owner._lane=SimpleNamespace(snapshot=lambda now:SimpleNamespace(observation=SimpleNamespace(sim_ns=120_000_000)))
    owner._operation=lambda action,commit:action();owner._context=lambda:None;owner._clock=lambda:102
    owner._forward=lambda *args:None
    sent=[]
    def send(raw,peer,selected):
        sent.append((raw,peer,selected))
        return len(raw)
    owner._send_odometry=send
    owner.poll_estimate_receiver()
    assert len(sent)==1 and wire._sequence==33
    assert codec.decode_datagram(sent[0][0])[0]['type']=='ODOMETRY'
    assert observer.send_events[-1]['bytes_returned']==len(sent[0][0])
    owner.poll_estimate_receiver()
    assert len(sent)==1


def test_actual_v2_client_consumes_native_echo_offset_and_reset_from_real_fast_file(tmp_path,monkeypatch):
    import json,time
    from tools.benchmark import managed_capture_source as managed
    from tools.benchmark import openvins_online_shadow as shadow
    from tools.benchmark.capture_disarmed_sensors import make_capture_native_client
    artifact=artifact_offset(tmp_path)
    monkeypatch.setattr(managed,'load_managed_configuration',lambda *args,**kwargs:(artifact,()))
    def init(self,command,output,**kwargs):
        self.process=SimpleNamespace(pid=42,poll=lambda:None)
        self.timeout_s,self.sequence,self.failed=2.,0,None
        self.output=output
        self.echo=dict(native_profile='offset-reset-v2',native_pid=42,native_session=command[-2],
                       camera_imu_offset_ns=int(command[-1]),reset_total=0,reset_counter=0,native_lifecycle_known=True)
        (output/'fast.jsonl').write_bytes(b'')
    def send(self,action,pixels=None):
        ack=dict(sequence=self.sequence,sample_ns=action['sample_ns'],start_ns=105,end_ns=125,
                 acknowledged_ns=time.monotonic_ns(),**self.echo)
        self.sequence+=1
        if action['kind']=='camera':
            ack.update(internal_initialized=True,public_initialized=True,state_time_s=.012,
                       imu_state=[0.,0.,0.,1.,10.,20.,30.,0.,0.,0.,0.,0.,0.,0.,0.,0.])
        if action['sample_ns']==24_000_000:
            row=dict(target_ns=20_000_000,last_camera_ns=12_000_000,available_imu_ns=24_000_000,
                     trigger_sequence=6,native_begin_ns=110,native_end_ns=120,filter_time_s=.012,
                     propagation_wall_s=.0001,camera_imu_offset_s=.007,internal_initialized=True,
                     public_initialized=True,success=True,filter_unchanged=True,fusion_eligible=False,
                     quality=None,state13=[0.,0.,0.,1.,11.,22.,33.,1.,2.,3.,0.,0.,.5],
                     covariance12=np.eye(12).tolist(),**self.echo)
            with (self.output/'fast.jsonl').open('ab') as f:f.write((json.dumps(row)+'\n').encode())
        return ack
    monkeypatch.setattr(shadow.NativeClient,'__init__',init)
    monkeypatch.setattr(shadow.NativeClient,'send',send)
    monkeypatch.setattr(shadow.NativeClient,'finish',lambda self:dict(exit=0,failure=self.failed))
    client=make_capture_native_client(selected_args(tmp_path),tmp_path,on_first_ack=None)
    try:
        for ns in (4,8,12,16,20):client.send(dict(kind='imu',sample_ns=ns*1_000_000))
        client.send(dict(kind='camera',sample_ns=12_000_000),b'pixels')
        client.send(dict(kind='imu',sample_ns=24_000_000))
        state=client.managed_source.wire_snapshot(20_000_000)
        assert state['reset_counter']==0 and state['native_state13'][4:7]==[11.,22.,33.]
        client.managed_source.validate_wire_selection(state)
        client.echo['reset_total']=1
        with pytest.raises(ValueError,match='reset'):
            client.send(dict(kind='imu',sample_ns=28_000_000))
        with pytest.raises(ValueError,match='latched'):
            client.managed_source.wire_snapshot(28_000_000)
    finally:client.finish()


@pytest.mark.parametrize('fault',['heartbeat','ev','receipt','source'])
def test_actual_send_boundary_stops_stale_or_failed_odometry_before_socket(fault):
    from tools.benchmark.openvins_observed_wire_session import ObservedWireSession
    from tools.benchmark.openvins_ekf2_disarmed_preflight import RemoteMonotonicClock
    owner=object.__new__(ObservedWireSession)
    now=3_000_000_000
    source=SimpleNamespace(validate_wire_selection=lambda state:None,_failure=None,lifecycle=SimpleNamespace(failure=None))
    owner._estimate_receiver=SimpleNamespace(source=source,response_ns=now)
    owner._estimate_sending_state=None
    owner._receiver=SimpleNamespace(check=lambda:None)
    owner._core=SimpleNamespace(_wire=SimpleNamespace(_last_unarmed=now))
    owner._open=lambda:None
    owner._backend=SimpleNamespace(clock=lambda:now)
    owner._remote=RemoteMonotonicClock('wire',sim_origin_ns=0,remote_origin_ns=1_000_000)
    owner._signature=('wire',0,1_000_000)
    owner._lane=SimpleNamespace(session_id='wire',progress=dict(session_id='wire',failure=None,
        latest_callback_ns=now,pending_callback_ns=None))
    owner._complete=owner._transitioning=owner._closed=owner._closing=False
    owner._failure=owner._selection=None;owner._maintenance=object();owner._last_now=now;owner._start=0
    owner._deadline=300_000_000_000;owner._flags=64
    sent=[];owner._sock=SimpleNamespace(sendto=lambda *args:sent.append(args))
    state=dict(receipt_ns=now)
    if fault=='heartbeat':owner._core._wire._last_unarmed=now-2_000_000_000
    if fault=='ev':owner._estimate_receiver.response_ns=now-2_000_000_000
    if fault=='receipt':state['receipt_ns']=now-100_000_001
    if fault=='source':source._failure='native reset'
    with pytest.raises(ValueError):owner._send_odometry(b'packet',('127.0.0.1',14588),state)
    assert sent==[]
