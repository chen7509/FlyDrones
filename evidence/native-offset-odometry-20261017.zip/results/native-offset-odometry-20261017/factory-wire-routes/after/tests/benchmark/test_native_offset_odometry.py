"""Prospective offset/native-lifecycle/receiver integration; injected OS only."""

import os
import socket
import subprocess
from types import SimpleNamespace

import numpy as np
import pytest


@pytest.fixture(autouse=True)
def inert(monkeypatch):
    def denied(*args, **kwargs):
        raise AssertionError("native process/network forbidden in software tests")
    monkeypatch.setattr(socket,"socket",denied)
    monkeypatch.setattr(subprocess,"Popen",denied)
    monkeypatch.setattr(os,"system",denied)


@pytest.mark.parametrize("offset,boundary",[(7_000_000,108_000_000),(-7_000_000,96_000_000)])
def test_offset_causal_release_uses_shifted_imu_boundary_without_relabeling_image(offset,boundary):
    from tools.benchmark.offset_reset_native_source import OffsetCausalInput
    obj=OffsetCausalInput(session_id="native-session",clock_id="clock",offset_ns=offset)
    obj._pending={'rgb':{100_000_000:({'arrival_monotonic_ns':1},0)},
                  'info':{100_000_000:({'arrival_monotonic_ns':2,'camera_info':{}},1)}}
    obj._imu_first=4_000_000
    obj._imu_latest=100_000_000+offset
    assert obj._release()==[]
    obj._imu_latest=boundary
    value=obj._release()[0]
    assert value['sample_ns']==100_000_000
    assert value['imu_lookup_ns']==100_000_000+offset
    assert value['imu_boundary_ns']==boundary


@pytest.mark.parametrize("fault",['native_pid','native_session','camera_imu_offset_ns','reset_total'])
def test_native_lifecycle_actual_fields_cannot_change_or_resume(fault):
    from tools.benchmark.offset_reset_native_source import NativeLifecycleBinding
    process=SimpleNamespace(pid=42,poll=lambda:None)
    binding=NativeLifecycleBinding(process,'a'*64,7_000_000)
    row=dict(native_profile='offset-reset-v2',native_pid=42,native_session='a'*64,
             camera_imu_offset_ns=7_000_000,reset_total=0,reset_counter=0,native_lifecycle_known=True)
    assert binding.accept(row)==0
    row[fault]='b'*64 if fault=='native_session' else row[fault]+1
    with pytest.raises(ValueError):binding.accept(row)
    with pytest.raises(ValueError,match='latched'):binding.accept({})


def test_disarmed_odometry_encodes_current_native_sample_and_unknown_quality():
    from tools.benchmark.disarmed_odometry_receiver import DisarmedOdometryReceiver
    from tools.benchmark.openvins_timesync_wire import PinnedCodec
    from tools.benchmark.openvins_ekf2_disarmed_preflight import RemoteMonotonicClock
    state=dict(sample_ns=120_000_000,reset_counter=0,reset_total=0,native_profile='offset-reset-v2',
               native_state13=[0.,0.,0.,1.,1.,2.,3.,4.,5.,6.,0.,0.,.5],native_covariance12=np.eye(12).tolist(),
               native_session='a'*64,native_pid=42,quality=None)
    source=SimpleNamespace(wire_snapshot=lambda sim:state)
    receiver=DisarmedOdometryReceiver(source)
    clock=RemoteMonotonicClock('wire',sim_origin_ns=0,remote_origin_ns=1_000_000)
    receiver.response_ns=100
    raw=receiver.odometry(PinnedCodec(),clock,13,101,120_000_000,disarmed=True)
    row=PinnedCodec().decode_datagram(raw)[0]
    assert row['type']=='ODOMETRY'
    fields=row['fields']
    assert fields['time_usec']==121000
    assert fields['quality']==0 and fields['reset_counter']==0
    assert fields['frame_id']==20 and fields['child_frame_id']==12
    assert fields['z']==-3. and fields['vx']==4.
    assert receiver.odometry(PinnedCodec(),clock,14,102,120_000_000,disarmed=True) is None


def selected_args(tmp_path):
    from tools.benchmark.capture_disarmed_sensors import parse_capture_args
    return parse_capture_args(['--output',str(tmp_path/'capture'),'--shadow-binary',str(tmp_path/'native-v2'),
        '--shadow-config',str(tmp_path/'estimator_config.yaml'),'--online-estimate-feed',
        '--managed-source-config',str(tmp_path/'managed.json'),'--managed-source-sha256','a'*64,
        '--execution-contract',str(tmp_path/'execution.json'),'--runtime-binding',str(tmp_path/'binding.json'),
        '--wire-config',str(tmp_path/'wire.json'),'--source-fanout-profile','ready-shadow-heartbeat-estimator-v1',
        '--reference-module',str(tmp_path/'reference.py'),'--reference-sha256','b'*64,
        '--motion-profile','supported-ready-v1','--physics-trace-profile','substep-ready-v1',
        '--native-estimate-profile','offset-reset-v2','--disarmed-odometry'])


def artifact_offset(tmp_path, offset=7_000_000):
    import hashlib,json
    from tests.benchmark.test_managed_capture_source import calibration
    from flydrones.benchmark.kalibr_camera_consumption import KalibrCameraArtifact,RAW_IMU_CONTRACT
    _,rig,_=calibration(tmp_path)
    camera=json.loads((tmp_path/'camchain.yaml').read_bytes())
    camera['cam0']['timeshift_cam_imu']=offset/1e9
    raw=json.dumps(camera).encode();(tmp_path/'camchain.yaml').write_bytes(raw)
    doc=json.loads((tmp_path/'artifact.json').read_bytes());doc['camchain']['sha256']=hashlib.sha256(raw).hexdigest()
    raw=json.dumps(doc).encode();(tmp_path/'artifact.json').write_bytes(raw)
    return KalibrCameraArtifact.load(tmp_path/'artifact.json',hashlib.sha256(raw).hexdigest(),rig,imu_contract=RAW_IMU_CONTRACT)


def test_actual_capture_factory_selects_v2_command_nonce_offset_and_worker_flags(tmp_path,monkeypatch):
    from tools.benchmark import managed_capture_source as managed
    from tools.benchmark import offset_reset_native_source as native
    from tools.benchmark.capture_disarmed_sensors import make_capture_native_client
    from tools.benchmark.capture_contract import worker_options
    artifact=artifact_offset(tmp_path)
    calls=[]
    monkeypatch.setattr(managed,'load_managed_configuration',lambda *args,**kwargs:(artifact,()))
    def init(self,command,output,*,source,**kwargs):
        calls.append((command,source))
        self.managed_source=source
    monkeypatch.setattr(native.OffsetResetNativeClient,'__init__',init)
    args=selected_args(tmp_path)
    client=make_capture_native_client(args,tmp_path,on_first_ack=None)
    assert type(client) is native.OffsetResetNativeClient
    assert len(calls[0][0])==6 and calls[0][0][-1]=='7000000'
    assert calls[0][0][-2]==client.managed_source.native_session and len(calls[0][0][-2])==64
    flags=worker_options(args)
    assert '--disarmed-odometry' in flags and flags[flags.index('--native-estimate-profile')+1]=='offset-reset-v2'


def test_actual_observed_poll_sends_odometry_on_same_sequence_and_retains_return(monkeypatch):
    from tools.benchmark.openvins_observed_wire_session import ObservedWireSession
    from tools.benchmark.disarmed_odometry_receiver import DisarmedOdometryReceiver
    from tools.benchmark.openvins_timesync_wire import PinnedCodec
    from tools.benchmark.openvins_ekf2_disarmed_preflight import RemoteMonotonicClock
    state=dict(sample_ns=120_000_000,reset_counter=0,reset_total=0,native_profile='offset-reset-v2',
               native_state13=[0.,0.,0.,1.,1.,2.,3.,4.,5.,6.,0.,0.,.5],native_covariance12=np.eye(12).tolist(),
               native_session='a'*64,native_pid=42,quality=None)
    source=SimpleNamespace(wire_snapshot=lambda sim:state)
    observer=DisarmedOdometryReceiver(source);observer.request_ns=100;observer.response_ns=101
    owner=object.__new__(ObservedWireSession)
    owner._estimate_receiver=observer;owner._maintenance=object();owner._estimate_events=[]
    codec=PinnedCodec()
    wire=SimpleNamespace(_codec=codec,_sequence=32,_peer=('127.0.0.1',14588),_last_unarmed=100)
    owner._core=SimpleNamespace(_wire=wire,_owned=SimpleNamespace(check=lambda **kwargs:None))
    owner._remote=RemoteMonotonicClock('wire',sim_origin_ns=0,remote_origin_ns=1_000_000)
    owner._lane=SimpleNamespace(snapshot=lambda now:SimpleNamespace(observation=SimpleNamespace(sim_ns=120_000_000)))
    owner._operation=lambda action,commit:action();owner._context=lambda:None;owner._clock=lambda:102
    owner._forward=lambda *args:None
    sent=[]
    def send(raw,peer,selected):
        sent.append((raw,peer,selected))
        return len(raw)
    owner._send_odometry=send
    owner.poll_estimate_receiver()
    assert len(sent)==1 and wire._sequence==33
    assert codec.decode_datagram(sent[0][0])[0]['type']=='ODOMETRY'
    assert observer.send_events[-1]['bytes_returned']==len(sent[0][0])
    owner.poll_estimate_receiver()
    assert len(sent)==1
