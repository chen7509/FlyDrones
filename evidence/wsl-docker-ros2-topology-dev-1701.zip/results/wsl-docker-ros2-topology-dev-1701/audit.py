"""Recheck the sealed UDP observation; it never grants DDS or flight qualification."""

from __future__ import annotations

import json
from pathlib import Path


root = Path(__file__).resolve().parent
record = json.loads((root / "probe-result.json").read_text(encoding="utf-8"))
assert record["schema"] == "flydrones.wsl_docker_udp_topology.v1"
assert record["port"] == 18889
assert record["pre_docker"]["returncode"] == 0
assert not record["pre_docker"]["stdout"].strip()
assert len(record["cases"]) == 2
loopback, interface = record["cases"]
for case in (loopback, interface):
    assert case["listener_ready"] == "READY"
    assert case["listener_exit"] == case["sender"]["returncode"] == 0
    assert case["owned_container_after"]["returncode"] == 0
    assert not case["owned_container_after"]["stdout"].strip()
    assert case["sender"]["stdout"].strip() == str(len(bytes.fromhex(case["expected_payload_hex"])))
assert loopback["label"] == "loopback"
assert loopback["bind"] == loopback["destination"] == "127.0.0.1"
assert loopback["listener_tail"].strip() == "TIMEOUT"
assert interface["label"] == "wsl-interface"
assert interface["bind"] == "0.0.0.0"
assert interface["destination"] in record["wsl_address"]["stdout"].split()
assert interface["listener_tail"].startswith("RECEIVED " + interface["expected_payload_hex"] + " ")
assert record["port_after"]["returncode"] == 0
assert ":18889" not in record["port_after"]["stdout"]
assert all(record[key] is False for key in (
    "dds_discovery_verified", "xrce_session_verified", "px4_source_authenticated",
    "fusion_qualified",
))
audit = {"schema": "flydrones.wsl_docker_udp_topology_audit.v1",
         "loopback_delivery": False, "routed_datagram_delivery": True,
         "owned_container_released": True, "listener_port_released": True,
         "dds_discovery_verified": False, "xrce_session_verified": False,
         "px4_source_authenticated": False, "fusion_qualified": False}
(root / "audit.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
print(json.dumps(audit))
