"""Bounded UDP namespace diagnostic. Never starts PX4, Agent, ROS 2 or a simulator."""

from __future__ import annotations

import json
import subprocess
import time
import uuid
from pathlib import Path


IMAGE = "sha256:a4dae62b38bc01a01d084be7b68db83ec804fef7673604e1a9c986a4baa88a6a"
PORT = 18889
HERE = Path(__file__).resolve().parent
LISTENER = (
    "import socket,sys; "
    "s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); "
    "s.bind((sys.argv[1],int(sys.argv[2]))); s.settimeout(8); "
    "print('READY',flush=True); "
    "\ntry:\n data,peer=s.recvfrom(256); print('RECEIVED '+data.hex()+' '+peer[0],flush=True)"
    "\nexcept socket.timeout: print('TIMEOUT',flush=True)"
    "\nfinally: s.close()"
)


def command(args: list[str], timeout: int = 15) -> dict:
    result = subprocess.run(args, capture_output=True, text=True, errors="replace", timeout=timeout)
    return {"args": args, "returncode": result.returncode,
            "stdout": result.stdout, "stderr": result.stderr}


def probe(label: str, bind: str, destination: str) -> dict:
    name = "flydrones-topology-" + uuid.uuid4().hex[:12]
    payload = ("flydrones-" + label).encode("ascii")
    listener_args = ["wsl", "-d", "Ubuntu", "--", "python3", "-u", "-c", LISTENER,
                     bind, str(PORT)]
    listener = subprocess.Popen(listener_args, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, text=True, errors="replace")
    sender = None
    first = None
    tail = ""
    listener_error = ""
    try:
        first = listener.stdout.readline().strip()
        if first != "READY":
            raise RuntimeError("listener not ready: " + repr(first))
        sender_args = ["docker", "run", "--rm", "--name", name,
                       "--network", "host", "--memory", "128m", "--memory-swap", "128m",
                       "--pids-limit", "32", IMAGE, "python3", "-c",
                       "import socket,sys; s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); "
                       "print(s.sendto(bytes.fromhex(sys.argv[2]),(sys.argv[1],18889)))",
                       destination, payload.hex()]
        sender = command(sender_args, timeout=20)
        tail, listener_error = listener.communicate(timeout=15)
    finally:
        if listener.poll() is None:
            listener.terminate()
            try:
                listener.wait(timeout=3)
            except subprocess.TimeoutExpired:
                listener.kill()
                listener.wait(timeout=3)
        # This exact UUID-named container is owned by this probe. If a timeout left it
        # behind, remove only that container; never touch another task's resources.
        remaining = command(["docker", "ps", "-a", "--filter", "name=^/" + name + "$",
                             "--format", "{{.ID}}"], timeout=10)
        if remaining["stdout"].strip():
            command(["docker", "rm", "-f", name], timeout=10)
    return {"label": label, "bind": bind, "destination": destination,
            "listener_args": listener_args, "listener_ready": first,
            "listener_tail": tail, "listener_stderr": listener_error,
            "listener_exit": listener.returncode, "sender": sender,
            "owned_container_after": command(["docker", "ps", "-a", "--filter",
                                             "name=^/" + name + "$", "--format", "{{.ID}}"]),
            "expected_payload_hex": payload.hex()}


def main() -> None:
    checked = command(["docker", "ps", "--format", "{{.Names}}"], timeout=10)
    if checked["returncode"] != 0 or checked["stdout"].strip():
        raise RuntimeError("existing Docker container or Docker query error")
    address = command(["wsl", "-d", "Ubuntu", "--", "hostname", "-I"], timeout=10)
    if address["returncode"] != 0:
        raise RuntimeError("WSL address unavailable")
    candidates = address["stdout"].split()
    wsl_ip = next((item for item in candidates if item.startswith("172.")
                   and item.count(".") == 3), None)
    if wsl_ip is None:
        raise RuntimeError("no explicit WSL interface address")
    started = time.time_ns()
    cases = [probe("loopback", "127.0.0.1", "127.0.0.1"),
             probe("wsl-interface", "0.0.0.0", wsl_ip)]
    sockets = command(["wsl", "-d", "Ubuntu", "--", "ss", "-ulnp",
                       "sport", "=", ":18889"], timeout=10)
    result = {"schema": "flydrones.wsl_docker_udp_topology.v1", "started_unix_ns": started,
              "ended_unix_ns": time.time_ns(), "image": IMAGE, "port": PORT,
              "pre_docker": checked, "wsl_address": address, "cases": cases,
              "port_after": sockets, "dds_discovery_verified": False,
              "xrce_session_verified": False, "px4_source_authenticated": False,
              "fusion_qualified": False}
    (HERE / "probe-result.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({"loopback_received": "RECEIVED" in cases[0]["listener_tail"],
                      "wsl_interface_received": "RECEIVED" in cases[1]["listener_tail"],
                      "result": str(HERE / "probe-result.json")}))


if __name__ == "__main__":
    main()
