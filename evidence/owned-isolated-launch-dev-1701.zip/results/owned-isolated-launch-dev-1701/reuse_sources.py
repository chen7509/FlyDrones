"""Retain relevant already sealed primary references, no repeated inventory."""
import hashlib
import json
import zipfile
from pathlib import Path

out = Path(__file__).resolve().parent
root = out.parents[1]
selected = {
    'openvins-timesync-channel-dev-1701': [
        'unshare-v2.39.3.c', 'unshare.html', 'network_namespaces.html',
        'namespace-references.json', 'versions.json', 'util-linux-copyright.txt',
        'iproute2-copyright.txt', 'util-linux-metadata.json',
    ],
    'owned-group-evidence-dev-1701': ['sources/subprocess-v3.12.3.py', 'sources/subprocess-v3.12.3.rst'],
}
records = []
for stem, paths in selected.items():
    archive = root / f'evidence/{stem}.zip'
    recorded = json.loads((root / f'evidence/{stem}-manifest.json').read_text())
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    assert digest == recorded['sha256']
    with zipfile.ZipFile(archive) as z:
        for name in paths:
            member = f'results/{stem}/{name}'
            blob = z.read(member)
            target = out / 'reused' / stem / name
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream:
                stream.write(blob)
            records.append(dict(archive=str(archive.relative_to(root)), archive_sha256=digest,
                                member=member, sha256=hashlib.sha256(blob).hexdigest()))
with (out / 'reused-source-provenance.json').open('x') as stream:
    json.dump(records, stream, indent=2)
print(len(records))
