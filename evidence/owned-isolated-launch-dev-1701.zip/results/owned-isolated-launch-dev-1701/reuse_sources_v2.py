"""Resume source extraction after missing legacy external manifest; no overwrite."""
import hashlib
import json
import zipfile
from pathlib import Path

out = Path(__file__).resolve().parent
root = out.parents[1]
specifications = [
    ('openvins-timesync-channel-dev-1701', 'ccf0ee01e398476c335cb2dbab723168777613177dff326a2a6c953ca9c5f78a',
     ['unshare-v2.39.3.c', 'unshare.html', 'network_namespaces.html', 'namespace-references.json',
      'versions.json', 'util-linux-copyright.txt', 'iproute2-copyright.txt', 'util-linux-metadata.json']),
    ('owned-group-evidence-dev-1701', '7ab0c9f5cbc70e3a168c5ffb3c973099a0f51bd3e5135247428a37f8eaca00dd',
     ['sources/subprocess-v3.12.3.py', 'sources/subprocess-v3.12.3.rst']),
]
assert specifications[1][1] in (root / 'docs/OWNED_GROUP_EVIDENCE_REPORT.md').read_text(encoding='utf-8')
records = []
for stem, expected, names in specifications:
    archive = root / f'evidence/{stem}.zip'
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == expected
    with zipfile.ZipFile(archive) as z:
        for name in names:
            member = f'results/{stem}/{name}'
            blob = z.read(member)
            target = out / 'reused' / stem / name
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists():
                assert target.read_bytes() == blob
            else:
                with target.open('xb') as stream:
                    stream.write(blob)
            records.append(dict(archive=archive.relative_to(root).as_posix(), archive_sha256=expected,
                                member=member, sha256=hashlib.sha256(blob).hexdigest()))
with (out / 'reused-source-provenance.json').open('x') as stream:
    json.dump(dict(prior_assembly_failure='v1 expected a nonexistent legacy external manifest; '
                   'eight channel sources retained; report-pinned archive SHA used for legacy source',
                   sources=records), stream, indent=2)
print(len(records))
