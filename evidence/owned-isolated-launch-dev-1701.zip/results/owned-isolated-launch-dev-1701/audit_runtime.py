"""Offline audit of the single retained four-case run; no rerun or launch."""
import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

out = Path(__file__).resolve().parent
root = out.parents[1]
source = root / 'tests/benchmark/check_isolated_namespace.py'
spec = importlib.util.spec_from_file_location('isolated_harness', source)
harness = importlib.util.module_from_spec(spec)
spec.loader.exec_module(harness)
run = out / 'runtime-v1'
freeze = json.loads((run / 'prospective.json').read_text())
after = json.loads((run / 'post-files.json').read_text())
assert freeze['baseline']['files'] == after['files']
cases = []
for mode in ['normal', 'exit7', 'timeout']:
    result = json.loads((run / mode / 'launch-result.json').read_text())
    gate = json.loads((run / mode / 'worker/gate.json').read_text())
    marker = json.loads((run / f'{mode}-command.json').read_text())
    assert harness.audit_child_marker(marker, gate['identity'], freeze['environment']) is True
    supervisor = result['supervisor']
    journal = [json.loads(line) for line in (run / mode / 'worker.supervisor-events.jsonl').read_text().splitlines()]
    assert journal == supervisor['cleanup']['events']
    assert supervisor['cleanup']['group_absent'] and supervisor['cleanup']['no_executing_members']
    assert result['isolated_launch_qualified'] is (mode == 'normal')
    assert supervisor['cleanup']['sigkill_dispatched'] is (mode == 'timeout')
    assert not result['physical_network_qualified'] and not result['fusion_qualified']
    cases.append(dict(case=mode, marker_verified=True, supervisor_journal_matches=True,
                      isolated_launch_qualified=result['isolated_launch_qualified'],
                      sigkill=supervisor['cleanup']['sigkill_dispatched']))
direct = json.loads((run / 'direct/supervisor.json').read_text())
assert direct['worker_exit'] == 2 and not (run / 'direct-command.json').exists()
assert direct['cleanup']['group_absent'] and direct['cleanup']['no_executing_members']
assert [json.loads(line) for line in (run / 'direct.supervisor-events.jsonl').read_text().splitlines()] == direct['cleanup']['events']
# Preserve exact prior producer harness as a post-run Git export, never call it
# a contemporaneous runtime copy. Its hash must match the predeclared inventory.
blob = subprocess.run(['git', 'show', '7121080:tests/benchmark/check_isolated_namespace.py'],
                      cwd=root, capture_output=True, check=True).stdout
selected = [x for x in freeze['baseline']['files'] if x['role'] == 'command-inputs']
assert len(selected) == 1 and hashlib.sha256(blob).hexdigest() == selected[0]['sha256']
with (out / 'producer-harness.py').open('xb') as f:
    f.write(blob)
record = dict(cases=cases, direct_worker_refused=True, snapshot_records_match=True,
              producer_harness_export='post-run Git export hash matched to pre/post inventory',
              physical_network_qualified=False, fusion_qualified=False)
with (out / 'runtime-audit.json').open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps(record))
