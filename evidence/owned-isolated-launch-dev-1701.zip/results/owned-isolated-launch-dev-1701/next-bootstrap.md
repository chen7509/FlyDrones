# Next: composed cold first-status bootstrap, offline first

Wrapper ordinary-process proof is complete, not real PX4/Gazebo compatibility.
Read current isolated_namespace and capture's explicit cwd/environment/resource
binding. Compose the cwd/source/runtime proof; namespace worker UID0 maps to host
UID1000 and filesystem UNIX sockets remain shared. Do not infer PX4 epoch from a
namespace ID or set every channel's status instance to0.

Design the one-reply bootstrap against pinned startup/receiver/PublicationMulti
sources already sealed: fresh owned PX4 identity and command socket, explicit API
endpoint, no other internal responders; first reserved reply while subsequent
replies withheld; establish the first corresponding status and its uORB instance;
then strict listener decoder + serial observer. No stale listener latest value,
no invented wire nonce, no generation claim from listener consumption ordinal.
Do not repeat old whole-source inventory or ordinary four-case process harness.

Reuse reversible interval transaction with explicit ACK/query adapter constraints;
loss/ambiguity/partial read/bad exit/identity drift must refuse and preserve restore
outcome. Include actual stdbuf runtime choice from the listener research. Existing
500accepted/8sreadiness/25stotal/2swatchdogs stay unchanged. No true authority flags
from simulated responses or labels. Future inability to meet wall deadline is a
platform limit, not fruit-fly learning failure.

All current authorization is offline/ordinary fixtures. No real PX4/Gazebo launch,
MAVLink/ODOMETRY publication, real parameter/rate change, EKF2 fusion, arming or
training/scaling. Once concrete corrected preflight is reviewed, live Task5 remains
the existing separate authorization gate. Continue independent original-goal
work if a real gate needs external input; don't turn launch infrastructure into
the final project objective.
