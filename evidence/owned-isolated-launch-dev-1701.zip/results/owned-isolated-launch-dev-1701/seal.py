"""Seal this completed offline boundary without changing historical evidence."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
ARCHIVE = ROOT / 'evidence/owned-isolated-launch-dev-1701.zip'
OUT = ARCHIVE.with_name('owned-isolated-launch-dev-1701-manifest.json')
sha = lambda data: hashlib.sha256(data).hexdigest()
previous = ROOT / 'evidence/openvins-timesync-channel-dev-1701.zip'
assert sha(previous.read_bytes()) == 'ccf0ee01e398476c335cb2dbab723168777613177dff326a2a6c953ca9c5f78a'
assert not ARCHIVE.exists() and not OUT.exists()
files = sorted(p for p in BASE.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
files += [ROOT / p for p in (
    'tools/benchmark/isolated_namespace.py',
    'tests/benchmark/test_isolated_namespace.py',
    'tests/benchmark/check_isolated_namespace.py',
    'tests/benchmark/test_isolated_namespace_harness.py',
    'docs/OWNED_ISOLATED_LAUNCH_REPORT.md',
    'docs/superpowers/specs/2026-10-08-owned-isolated-launch-design.md',
    'docs/superpowers/plans/2026-10-08-owned-isolated-launch.md',
    '.superpowers/sdd/2026-10-08-owned-isolated-launch/progress.md',
)]
payload = {p.relative_to(ROOT).as_posix(): p.read_bytes() for p in files}
assert len(payload) == len(files)
manifest = {'schema': 'evidence-members-v1', 'members': [
    {'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(payload.items())],
    'runtime_producer': '7121080d93f3615d98e11aff93f649c8aa54d9ec',
    'final_harness_assertions_added_after_run': True,
    'physical_network_qualified': False, 'fusion_qualified': False}
with zipfile.ZipFile(ARCHIVE, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for name, data in payload.items():
        z.writestr(name, data)
    z.writestr('member-manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(ARCHIVE) as z:
    assert z.testzip() is None
    for item in manifest['members']:
        data = z.read(item['path'])
        assert len(data) == item['bytes'] and sha(data) == item['sha256']
    count = len(z.namelist())
result = dict(archive=ARCHIVE.relative_to(ROOT).as_posix(), sha256=sha(ARCHIVE.read_bytes()),
              members=count, bytes=ARCHIVE.stat().st_size, crc_verified=True,
              member_hashes_verified=True, previous_channel_archive_unchanged=True)
with OUT.open('x', encoding='utf-8') as f:
    json.dump(result, f, indent=2)
    f.write('\n')
print(json.dumps(result))
