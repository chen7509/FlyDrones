# SDD ledger — plan: docs/superpowers/plans/2026-10-08-owned-isolated-launch.md
Previous goal turn made progress7a2ccbd; current parent tracked clean/resources empty.
Spec/plan committedb2cb4f4, inline preapproved. Initial38 tests failed for missing
module (not behavior RED). Implementation7121080,38GREEN then2 actual contract
assertion RED +1missing read_bound_envelope API ->41GREEN; terminal label-only
false qualification1assertion RED ->fixed. Expanded45 wrapper tests.
One prospective4case ordinary WSL harness producer7121080: normal2.201s,
exit72.238s; timeout7.528s overall with4s supervisor then actualSIGKILL; direct
hostworkerrefusal. All originalgroups absent/noexec. No PX4/Gazebo/estimator/
MAVLink. Source/dependencyprepost match. Timeoutworkerpost absent, parentpost and
supervisorcapture_failed retained. Independent review no blockingissue; suspected
IPv6 omission withdrawn after installed read-only ipall confirmedbothfamilies.
One Minor marker assertions added,9 newGREENchecks; offline originalmarkers and
all4supervisorjournals verified without rerun. Actualruntimeproducerharness exported
fromGit afterrun and hashmatched pre/post, not called contemporaneouscopy.
Ruling: inheritedcwd outside narrow namespace proof; state limitation explicitly,
require integration with existingcapturecwd binding before any live gate. Nohostile
process/escapeddescendant/runtimeclosure claim. Fullpytest session62628 completed:
2494 passed,3 skipped,2 existing warnings in328.22s,exit0. Focused147passed2skip.
Final changed Ruff/diff checks passed. No selected physical/test processes remain
in the final read-only WSL scan. Report and prospective plan now reflect scope;
archive/personal publication are the remaining stage closeout actions.
