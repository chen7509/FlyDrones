"""Copy the existing vehicle world into matched original/textured render probes."""

from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

base = Path(__file__).resolve().parent
source = base.parent / "fly-ego-camera-info-preflight/1701/fly_raw/world.sdf"
textured = base / "fixture-v1/world.sdf"
for label, path in (("original", source), ("textured", textured)):
    destination = base / f"probe-{label}-v2"
    if destination.exists():
        raise FileExistsError(destination)
    tree = ET.parse(path)
    world = tree.getroot().find("world")
    vehicles = [item for item in world.findall("include")
                if item.findtext("name") == "x500_benchmark_8"]
    if len(vehicles) != 1:
        raise ValueError("source must already contain exactly one benchmark vehicle")
    destination.mkdir()
    shutil.copyfile(path, destination / "world.sdf")
    if label == "textured":
        for asset in ("ground_albedo.png", "obstacle_albedo.png"):
            shutil.copyfile(base / "fixture-v1" / asset, destination / asset)
