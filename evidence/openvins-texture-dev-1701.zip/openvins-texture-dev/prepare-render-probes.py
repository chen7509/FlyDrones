"""Make original and textured camera-only render probes at an identical pose."""

from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

base = Path(__file__).resolve().parent
source = base.parent / "fly-ego-camera-info-preflight/1701/fly_raw/world.sdf"
textured = base / "fixture-v1/world.sdf"
for label, path in (("original", source), ("textured", textured)):
    destination = base / f"probe-{label}"
    if destination.exists():
        raise FileExistsError(destination)
    destination.mkdir()
    tree = ET.parse(path)
    world = tree.getroot().find("world")
    if world is None:
        raise ValueError("world missing")
    vehicle = ET.SubElement(world, "include")
    ET.SubElement(vehicle, "uri").text = "model://x500_benchmark"
    ET.SubElement(vehicle, "name").text = "x500_benchmark_8"
    ET.SubElement(vehicle, "pose").text = "-8 0 .24 0 0 0"
    ET.indent(tree)
    tree.write(destination / "world.sdf", encoding="utf-8", xml_declaration=True)
    if label == "textured":
        for asset in ("ground_albedo.png", "obstacle_albedo.png"):
            shutil.copyfile(base / "fixture-v1" / asset, destination / asset)
