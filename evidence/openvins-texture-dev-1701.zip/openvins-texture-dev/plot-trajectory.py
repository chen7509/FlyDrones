"""Plot development VIO and scoring truth after fixed-scale rigid alignment."""

import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

base = Path(__file__).resolve().parent
rows = list(csv.DictReader((base / "openvins-run-v2/states.csv").open()))
rows = [row for row in rows if row["initialized"] == "1"]
time = np.array([float(row["state_timestamp_s"]) for row in rows])
position = np.array([[float(row[key]) for key in ("px", "py", "pz")] for row in rows])
truth_path = json.loads((base / "episode-v1/result.json").read_text())["path"]
truth_time = np.array([row["sim_ns"] * 1e-9 for row in truth_path])
truth_position = np.array([row["position"] for row in truth_path])
valid = (time >= truth_time[0]) & (time <= truth_time[-1])
time = time[valid]
position = position[valid]
truth = np.column_stack([np.interp(time, truth_time, truth_position[:, axis]) for axis in range(3)])
audit = json.loads((base / "openvins-run-v2/trajectory-audit.json").read_text())
rotation = np.array(audit["alignment_rotation_row_major"])
translation = np.array(audit["alignment_translation_m"])
aligned = position @ rotation + translation
error = np.linalg.norm(aligned - truth, axis=1)
fig, axes = plt.subplots(1, 3, figsize=(13, 4))
axes[0].plot(truth[:, 0], truth[:, 1], label="Gazebo scoring truth")
axes[0].plot(aligned[:, 0], aligned[:, 1], label="OpenVINS, rigid aligned")
axes[0].set(xlabel="x (m)", ylabel="y (m)", title="XY trajectory")
axes[0].axis("equal")
axes[0].legend()
axes[1].plot(time, truth[:, 2], label="truth z")
axes[1].plot(time, aligned[:, 2], label="OpenVINS z")
axes[1].set(xlabel="simulation time (s)", ylabel="z (m)", title="Altitude")
axes[1].legend()
axes[2].plot(time, error)
axes[2].set(xlabel="simulation time (s)", ylabel="position error (m)", title="Rigid-aligned ATE")
fig.suptitle("Development fixture only; Gazebo truth was never estimator input")
fig.tight_layout()
fig.savefig(base / "openvins-run-v2/trajectory-comparison.png", dpi=160)
