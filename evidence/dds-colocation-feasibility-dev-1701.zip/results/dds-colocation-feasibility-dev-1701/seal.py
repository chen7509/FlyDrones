"""Seal only the named reverse-route and ABI evidence; refuse overwrite."""

from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
folder = Path(__file__).resolve().parent
archive = root / "evidence/dds-colocation-feasibility-dev-1701.zip"
members = [
    "docs/superpowers/specs/2026-10-12-dds-colocation-feasibility-design.md",
    "docs/superpowers/plans/2026-10-12-dds-colocation-feasibility.md",
    "docs/DDS_COLOCATION_FEASIBILITY_REPORT.md",
    "results/dds-colocation-feasibility-dev-1701/probe.py",
    "results/dds-colocation-feasibility-dev-1701/probe-result.json",
    "results/dds-colocation-feasibility-dev-1701/audit.py",
    "results/dds-colocation-feasibility-dev-1701/audit.json",
    "results/dds-colocation-feasibility-dev-1701/seal.py",
]
manifest_path = folder / "manifest.json"
if archive.exists() or manifest_path.exists():
    raise SystemExit("evidence already exists; refuse overwrite")
manifest = {name: {"size": len((root / name).read_bytes()),
                   "sha256": hashlib.sha256((root / name).read_bytes()).hexdigest()}
            for name in members}
manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED) as bundle:
    for name in [*members, "results/dds-colocation-feasibility-dev-1701/manifest.json"]:
        bundle.write(root / name, name)
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    assert set(bundle.namelist()) == set(members) | {
        "results/dds-colocation-feasibility-dev-1701/manifest.json"}
    for name, item in manifest.items():
        payload = bundle.read(name)
        assert len(payload) == item["size"]
        assert hashlib.sha256(payload).hexdigest() == item["sha256"]
print(json.dumps({"archive": str(archive), "members": len(members) + 1,
                  "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}))
