"""Bounded WSL-to-Docker UDP and fixed Agent ABI diagnostic; no PX4 or DDS."""

from __future__ import annotations

import hashlib
import json
import re
import subprocess
import time
import uuid
from pathlib import Path

HERE = Path(__file__).resolve().parent
IMAGE = "sha256:a4dae62b38bc01a01d084be7b68db83ec804fef7673604e1a9c986a4baa88a6a"
AGENT_ROOT = "/tmp/flydrones-agent-offline-1701-v4/runtime-bundle-verify"
PORT = 18890
LISTENER = (
    "import socket; s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); "
    "s.bind(('0.0.0.0',18890)); s.settimeout(8); print('READY',flush=True); "
    "\ntry:\n data,peer=s.recvfrom(256); print('RECEIVED '+data.hex()+' '+peer[0],flush=True)"
    "\nexcept socket.timeout: print('TIMEOUT',flush=True)"
    "\nfinally: s.close()"
)


def run(args: list[str], timeout: int = 20) -> dict:
    result = subprocess.run(args, capture_output=True, text=True, errors="replace", timeout=timeout)
    return {"args": args, "returncode": result.returncode,
            "stdout": result.stdout, "stderr": result.stderr}


def probe(label: str, destination: str, *, published: bool) -> dict:
    name = "flydrones-colocation-" + uuid.uuid4().hex[:12]
    payload = ("flydrones-" + label).encode("ascii")
    docker_args = ["docker", "run", "--rm", "--name", name, "--memory", "128m",
                   "--memory-swap", "128m", "--pids-limit", "32"]
    if published:
        docker_args += ["-p", "18890:18890/udp"]
    else:
        docker_args += ["--network", "host"]
    docker_args += [IMAGE, "python3", "-u", "-c", LISTENER]
    listener = subprocess.Popen(docker_args, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                text=True, errors="replace")
    ready = listener.stdout.readline().strip()
    sender = None
    tail = ""
    listener_error = ""
    try:
        if ready != "READY":
            raise RuntimeError("Docker listener did not become ready: " + repr(ready))
        sender = run(["wsl", "-d", "Ubuntu", "--", "python3", "-c",
                      "import socket,sys; s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); "
                      "print(s.sendto(bytes.fromhex(sys.argv[2]),(sys.argv[1],18890)))",
                      destination, payload.hex()], timeout=10)
        tail, listener_error = listener.communicate(timeout=12)
    finally:
        if listener.poll() is None:
            listener.terminate()
            try:
                listener.wait(timeout=3)
            except subprocess.TimeoutExpired:
                listener.kill()
                listener.wait(timeout=3)
        remaining = run(["docker", "ps", "-a", "--filter", "name=^/" + name + "$",
                         "--format", "{{.ID}}"], timeout=10)
        if remaining["stdout"].strip():
            run(["docker", "rm", "-f", name], timeout=10)
    return {"label": label, "destination": destination, "published": published,
            "listener_command": docker_args, "listener_ready": ready,
            "listener_tail": tail, "listener_stderr": listener_error,
            "listener_exit": listener.returncode, "sender": sender,
            "expected_payload_hex": payload.hex(),
            "owned_container_after": run(["docker", "ps", "-a", "--filter",
                                           "name=^/" + name + "$", "--format", "{{.ID}}"])}


def abi_file(relative: str) -> dict:
    path = AGENT_ROOT + "/" + relative
    digest = run(["wsl", "-d", "Ubuntu", "--", "sha256sum", path], timeout=10)
    symbols = run(["wsl", "-d", "Ubuntu", "--", "readelf", "--version-info", path],
                  timeout=10)
    versions = sorted({tuple(int(x) for x in raw.split("."))
                       for raw in re.findall(r"GLIBC_([0-9.]+)", symbols["stdout"])})
    return {"path": path, "sha256sum": digest, "readelf": symbols,
            "max_glibc": ".".join(str(x) for x in versions[-1]) if versions else None}


def main() -> None:
    pre = run(["docker", "ps", "--format", "{{.Names}}"], timeout=10)
    if pre["returncode"] != 0 or pre["stdout"].strip():
        raise RuntimeError("Docker query error or existing container")
    wsl_route = run(["wsl", "-d", "Ubuntu", "--", "ip", "route"], timeout=10)
    match = re.search(r"^default via (\d+\.\d+\.\d+\.\d+)",
                      wsl_route["stdout"], re.MULTILINE)
    if wsl_route["returncode"] != 0 or match is None:
        raise RuntimeError("WSL gateway unavailable")
    gateway = match.group(1)
    docker_host = run(["docker", "run", "--rm", "--name", "flydrones-host-ip-observation",
                       "--network", "host", "--memory", "128m", "--memory-swap", "128m",
                       "--pids-limit", "32", IMAGE, "python3", "-c",
                       "import socket; print(socket.gethostbyname(socket.gethostname()))"], timeout=20)
    if docker_host["returncode"] != 0 or not re.fullmatch(
        r"\d+\.\d+\.\d+\.\d+", docker_host["stdout"].strip()
    ):
        raise RuntimeError("Docker host address unavailable")
    started = time.time_ns()
    cases = [probe("host-gateway", gateway, published=False),
             probe("host-interface", docker_host["stdout"].strip(), published=False),
             probe("published-port", gateway, published=True)]
    abi = {relative: abi_file(relative) for relative in (
        "bin/MicroXRCEAgent", "lib/libfastrtps.so.2.14.7",
        "lib/libmicroxrcedds_agent.so.2.4.3")}
    image_libc = run(["docker", "run", "--rm", "--name", "flydrones-image-libc-observation",
                      "--network", "none", "--memory", "128m", "--memory-swap", "128m",
                      "--pids-limit", "32", IMAGE, "getconf", "GNU_LIBC_VERSION"], timeout=20)
    result = {"schema": "flydrones.dds_colocation_feasibility.v1",
              "started_unix_ns": started, "ended_unix_ns": time.time_ns(),
              "image": IMAGE, "port": PORT, "pre_docker": pre, "wsl_route": wsl_route,
              "docker_host": docker_host, "cases": cases, "agent_abi": abi,
              "image_libc": image_libc,
              "post_docker": run(["docker", "ps", "-a", "--filter",
                                  "name=flydrones-colocation-", "--format", "{{.Names}}"]),
              "dds_discovery_verified": False, "xrce_session_verified": False,
              "px4_source_authenticated": False, "fusion_qualified": False}
    output = HERE / "probe-result.json"
    output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({"delivered": ["RECEIVED" in c["listener_tail"] for c in cases],
                      "image_libc": image_libc["stdout"].strip(),
                      "output": str(output),
                      "sha256": hashlib.sha256(output.read_bytes()).hexdigest()}))


if __name__ == "__main__":
    main()
