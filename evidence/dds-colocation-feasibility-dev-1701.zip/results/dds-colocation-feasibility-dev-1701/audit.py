"""Independent fail-closed audit of the non-DDS route and ABI observations."""

from __future__ import annotations

import json
import re
from pathlib import Path

root = Path(__file__).resolve().parent
record = json.loads((root / "probe-result.json").read_text(encoding="utf-8"))
assert record["schema"] == "flydrones.dds_colocation_feasibility.v1"
assert record["port"] == 18890
assert record["pre_docker"]["returncode"] == 0
assert not record["pre_docker"]["stdout"].strip()
assert record["wsl_route"]["returncode"] == 0
assert record["docker_host"]["returncode"] == 0
assert record["post_docker"]["returncode"] == 0
assert not record["post_docker"]["stdout"].strip()
assert len(record["cases"]) == 3
gateway, host, published = record["cases"]
assert [case["label"] for case in record["cases"]] == [
    "host-gateway", "host-interface", "published-port"]
assert [case["published"] for case in record["cases"]] == [False, False, True]
assert gateway["destination"] == published["destination"]
assert host["destination"] == record["docker_host"]["stdout"].strip()
for case in record["cases"]:
    assert case["listener_ready"] == "READY"
    assert case["listener_exit"] == 0
    assert case["sender"]["returncode"] == 0
    assert case["sender"]["stdout"].strip() == str(
        len(bytes.fromhex(case["expected_payload_hex"])))
    assert case["owned_container_after"]["returncode"] == 0
    assert not case["owned_container_after"]["stdout"].strip()
assert gateway["listener_tail"].strip() == "TIMEOUT"
assert host["listener_tail"].strip() == "TIMEOUT"
assert published["listener_tail"].startswith(
    "RECEIVED " + published["expected_payload_hex"] + " ")
assert record["image_libc"]["returncode"] == 0
assert record["image_libc"]["stdout"].strip() == "glibc 2.35"
abi = record["agent_abi"]
assert abi["bin/MicroXRCEAgent"]["max_glibc"] == "2.34"
assert abi["lib/libfastrtps.so.2.14.7"]["max_glibc"] == "2.38"
assert abi["lib/libmicroxrcedds_agent.so.2.4.3"]["max_glibc"] == "2.38"
for item in abi.values():
    assert item["sha256sum"]["returncode"] == 0
    assert item["readelf"]["returncode"] == 0
    versions = sorted({tuple(int(x) for x in raw.split("."))
                       for raw in re.findall(r"GLIBC_([0-9.]+)", item["readelf"]["stdout"])})
    assert item["max_glibc"] == ".".join(str(x) for x in versions[-1])
    assert re.fullmatch(r"[0-9a-f]{64}", item["sha256sum"]["stdout"].split()[0])
    assert item["sha256sum"]["stdout"].split()[1] == item["path"]
assert abi["bin/MicroXRCEAgent"]["sha256sum"]["stdout"].split()[0] == (
    "ded56cf545394670effaf112c642d62e8dd0e7145e53a6c9b0593014b721fcfe")
assert all(record[key] is False for key in (
    "dds_discovery_verified", "xrce_session_verified", "px4_source_authenticated",
    "fusion_qualified"))
result = {"schema": "flydrones.dds_colocation_feasibility_audit.v1",
          "host_gateway_delivery": False, "host_interface_delivery": False,
          "published_port_delivery": True, "agent_bundle_usable_unchanged_in_image": False,
          "owned_containers_released": True, "dds_discovery_verified": False,
          "xrce_session_verified": False, "px4_source_authenticated": False,
          "fusion_qualified": False}
(root / "audit.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result))
