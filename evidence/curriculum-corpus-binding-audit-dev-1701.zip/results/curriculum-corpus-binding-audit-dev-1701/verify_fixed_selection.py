"""Recheck retained synthetic inputs through the real YAML/loader boundary."""
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT)]

import yaml

from flydrones.connectome_training.curriculum_config import load_curriculum_config
from flydrones.connectome_training.curriculum_session import _full_components

HERE = Path(__file__).resolve().parent


def main():
    audit = json.loads((HERE / 'audit.json').read_text())
    for row in audit['fixture_records']:
        assert hashlib.sha256((ROOT / row['path']).read_bytes()).hexdigest() == row['sha256']
    raw = yaml.safe_load((ROOT / 'configs/connectome_curriculum_v1.yaml').read_text())
    for stage in raw['stages']:
        for split, seed_field, path_field in (
            ('train', 'train_seeds', 'train_paths'), ('val', 'validation_seeds', 'validation_paths'),
        ):
            stage[path_field] = [str(HERE / 'synthetic-fixtures' / stage['id'] / split / str(seed))
                                 for seed in stage[seed_field]] * 3
    config_file = HERE / 'synthetic-duplicate-selection.yaml'
    with config_file.open('x', encoding='utf-8') as stream:
        yaml.safe_dump(raw, stream)
    config = load_curriculum_config(config_file, 'desktop')
    assert config.digest != audit['current_config_digest']
    missing = HERE / 'deliberately-absent-full-model.npz'
    assert not missing.exists()
    try:
        _full_components(config, missing, HERE / 'deliberately-absent-parameters')
    except ValueError as exc:
        assert str(exc).startswith('duplicate sequence directory:'), str(exc)
        rejection = str(exc)
    else:
        raise AssertionError('duplicate selection did not refuse')
    for row in audit['fixture_records']:
        assert hashlib.sha256((ROOT / row['path']).read_bytes()).hexdigest() == row['sha256']
    result = {'schema': 'curriculum-selection-rejection-v1', 'valid_yaml_config_digest': config.digest,
              'config_sha256': hashlib.sha256(config_file.read_bytes()).hexdigest(),
              'rejection': rejection, 'fixtures_unchanged': True, 'model_loaded': False,
              'training_run': False, 'physical_run': False, 'v2_corpus_qualified': False,
              'production_sha256': hashlib.sha256((ROOT / 'src/flydrones/connectome_training/curriculum_session.py').read_bytes()).hexdigest()}
    with (HERE / 'fixed-selection.json').open('x', encoding='utf-8') as stream:
        json.dump(result, stream, indent=2); stream.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
