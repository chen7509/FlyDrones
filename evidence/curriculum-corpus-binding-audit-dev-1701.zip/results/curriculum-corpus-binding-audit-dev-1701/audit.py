"""Synthetic loader diagnostic only; no model, training, simulator or teacher run."""
import hashlib
import json
import sys
from dataclasses import fields, replace
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT)]

import numpy as np

from flydrones.connectome_training import curriculum_session as session
from flydrones.connectome_training.corpus_config import load_corpus_config
from flydrones.connectome_training.curriculum_config import load_curriculum_config
from flydrones.connectome_training.dataset import (
    SequenceFrame, SequenceProvenance, TeacherTarget, TrainingSequence, write_sequence,
)

HERE = Path(__file__).resolve().parent


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def record(path):
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw), 'sha256': digest(raw)}


def actual_loader(config, label):
    """Call production loading; stop naturally at its absent model-file check."""
    captured = {}
    missing = HERE / 'deliberately-absent-full-model.npz'
    assert not missing.exists()

    def trace(frame, event, arg):
        if frame.f_code is not session._full_components.__code__:
            return None
        if event == 'exception':
            data = frame.f_locals.get('datasets', {})
            captured['accepted_stage_counts'] = {
                stage: {'train': len(pair[0]), 'val': len(pair[1])} for stage, pair in data.items()
            }
        return trace

    previous = sys.gettrace()
    assert previous is None
    sys.settrace(trace)
    try:
        session._full_components(config, missing, HERE / 'deliberately-absent-parameters')
    except FileNotFoundError as exc:
        assert str(exc) == f'connectome source does not exist: {missing}', str(exc)
        captured['terminal_error'] = str(exc)
    finally:
        sys.settrace(previous)
    assert len(captured['accepted_stage_counts']) == 6
    captured.update(case=label, model_loaded=False, training_run=False,
                    physical_run=False, dataset_qualified=False)
    return captured


def main():
    assert not (HERE / 'audit.json').exists()
    selected = [
        'configs/connectome_curriculum_v1.yaml', 'configs/connectome_corpus_v2.yaml',
        'evidence/fly-ego-formal-seed-manifest-2026-09-22.json',
        'src/flydrones/connectome_training/curriculum_session.py',
        'src/flydrones/connectome_training/curriculum_config.py',
        'src/flydrones/connectome_training/corpus_config.py',
        'src/flydrones/connectome_training/dataset.py',
        'src/flydrones/connectome_training/governance.py',
        'src/flydrones/connectome_training/recorder.py',
    ]
    before = [record(ROOT / p) for p in selected] + [record(Path(__file__))]
    cfg = load_curriculum_config(ROOT / selected[0], 'desktop')
    corpus = load_corpus_config(ROOT / selected[1], formal_manifest=ROOT / selected[2])
    mapping = []
    stages = []
    manifests = []
    for stage in cfg.stages:
        paths = {}
        for split, seeds, legacy in (
            ('train', stage.train_seeds, stage.train_paths),
            ('val', stage.validation_seeds, stage.validation_paths),
        ):
            mapping.append({'stage': stage.id, 'split': split,
                            'configured_legacy_paths': list(legacy),
                            'all_within_declared_v2_root': all((ROOT / p).resolve().is_relative_to(corpus.output_root) for p in legacy)})
            paths[split] = []
            for seed in seeds:
                unique = f'{stage.id}:{split}:{seed}'
                provenance = SequenceProvenance(split, seed, 'unverified-synthetic-teacher',
                                               digest(unique.encode()), 'b' * 64,
                                               'synthetic-loader-diagnostic-only')
                frame = SequenceFrame(1_000_000, 1_000_000, np.zeros((2, 2, 3), np.uint8),
                                      np.ones((2, 2), np.float32), np.zeros(3, np.float32),
                                      np.zeros(3, np.float32), 0., 0., np.ones(3, np.float32))
                target = TeacherTarget(np.zeros(3, np.float32), 0., np.zeros((1, 3), np.float32),
                                       1., True, np.ones(1, np.bool_))
                destination = HERE / 'synthetic-fixtures' / stage.id / split / str(seed)
                write_sequence(destination, TrainingSequence(provenance, [frame], [target]))
                manifests.extend([record(destination / 'manifest.json'), record(destination / 'samples.npz')])
                paths[split].append(str(destination))
        stages.append(replace(stage, train_paths=tuple(paths['train']), validation_paths=tuple(paths['val'])))
    synthetic_config = replace(cfg, stages=tuple(stages))
    # This replaced object is a diagnostic input, NOT a new valid curriculum identity.
    incomplete = actual_loader(synthetic_config, 'one-sequence-per-world-18-not-54')
    repeated = replace(synthetic_config, stages=tuple(
        replace(stage, train_paths=stage.train_paths * 3, validation_paths=stage.validation_paths * 3)
        for stage in synthetic_config.stages
    ))
    duplicates = actual_loader(repeated, 'same-eighteen-files-selected-three-times')
    assert sum(c['train'] + c['val'] for c in incomplete['accepted_stage_counts'].values()) == 18
    assert sum(c['train'] + c['val'] for c in duplicates['accepted_stage_counts'].values()) == 54
    assert len({r['sha256'] for r in manifests if r['path'].endswith('manifest.json')}) == 18
    after = [record(ROOT / p) for p in selected] + [record(Path(__file__))]
    assert before == after
    result = {'schema': 'curriculum-corpus-binding-diagnostic-v1',
              'current_config_digest': cfg.digest, 'declared_corpus_digest': corpus.digest,
              'declared_jobs': len(corpus.jobs()), 'path_mapping': mapping,
              'provenance_fields': [field.name for field in fields(SequenceProvenance)],
              'cases': [incomplete, duplicates], 'input_records': before, 'fixture_records': manifests,
              'selected_sources_unchanged': True, 'fixtures_are_synthetic': True,
              'dataclass_replacement_is_not_a_new_config_identity': True,
              'teacher_executed': False, 'model_loaded': False, 'training_run': False,
              'physical_run': False, 'dataset_qualified': False, 'fusion_eligible': False,
              'claim_scope': 'legacy v1 loader behavior is insufficient to qualify the planned v2 corpus; not a v2 collector run'}
    with (HERE / 'audit.json').open('x', encoding='utf-8') as f:
        json.dump(result, f, indent=2); f.write('\n')
    print(json.dumps({k: result[k] for k in ('declared_jobs', 'cases', 'selected_sources_unchanged', 'claim_scope')}))


if __name__ == '__main__':
    main()
