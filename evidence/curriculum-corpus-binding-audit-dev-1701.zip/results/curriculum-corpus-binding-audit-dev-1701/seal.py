"""Archive retained diagnosis and fix evidence; no execution of learning/runtime."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=ROOT).strip()
    audit = json.loads((HERE / 'audit.json').read_text())
    name = 'src/flydrones/connectome_training/curriculum_session.py'
    original = next(r for r in audit['input_records'] if r['path'] == name)
    blob = subprocess.check_output(['git', 'show', '5ac5b94:' + name], cwd=ROOT)
    candidates = [blob, blob.replace(b'\r\n', b'\n').replace(b'\n', b'\r\n')]
    restored = next(raw for raw in candidates if sha(raw) == original['sha256'])
    with (HERE / 'pre-fix-curriculum-session.py').open('xb') as f:
        f.write(restored)
    paths = {p for p in HERE.rglob('*') if p.is_file()}
    paths.update(ROOT / p for p in (
        name, 'tests/connectome_training/test_curriculum_sequence_selection.py',
        'docs/CURRICULUM_CORPUS_BINDING_AUDIT_REPORT.md',
        'configs/connectome_curriculum_v1.yaml', 'configs/connectome_corpus_v2.yaml',
    ))
    payload = {p.relative_to(ROOT).as_posix(): p.read_bytes() for p in sorted(paths)}
    manifest = {'schema': 'curriculum-selection-evidence-v1', 'base': '5ac5b94',
                'fix_commit': '64c804f', 'historical_source_recovery':
                'git 5ac5b94 blob with recorded working-tree newline conversion; exact prior audit hash matched, not a pre-run source copy',
                'model_loaded': False, 'training_campaign': False, 'physical_run': False,
                'v2_corpus_qualified': False,
                'members': [{'path': n, 'bytes': len(b), 'sha256': sha(b)} for n, b in payload.items()]}
    encoded = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    path = ROOT / 'evidence/curriculum-corpus-binding-audit-dev-1701.zip'
    with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, raw in payload.items():
            archive.writestr(name, raw)
        archive.writestr('MANIFEST.json', encoded)
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist()) == len(payload) + 1
        for name, raw in payload.items():
            assert archive.read(name) == raw == (ROOT / name).read_bytes(), name
    summary = {'sha256': sha(path.read_bytes()), 'bytes': path.stat().st_size,
               'members': len(payload) + 1, 'crc_and_members_verified': True}
    with path.with_suffix('.manifest.json').open('x', encoding='utf-8') as f:
        json.dump({'summary': summary, 'manifest': manifest}, f, indent=2); f.write('\n')
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
