"""Independently verify both Agent-only attempts and seal selected evidence."""

import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
first = root / 'results/agent-owned-listener-dev-1701'
second = root / 'results/agent-owned-listener-dev-1701-v2'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_attempt(directory):
    result = json.loads((directory / 'result.json').read_text())
    events = [json.loads(line) for line in (directory / 'group-events.jsonl').read_text().splitlines()]
    assert events == result['cleanup']['events']
    assert result['bundle_sha256'] == '4a5a104380bd320f87a3e1df1db4007287a4be4102d8ac511187ce69dd55596b'
    assert result['agent_sha256'] == 'ded56cf545394670effaf112c642d62e8dd0e7145e53a6c9b0593014b721fcfe'
    assert result['pid'] == result['cleanup']['owner']['pid']
    assert result['cleanup']['group_absent'] and result['cleanup']['no_executing_members']
    assert result['cleanup']['graceful_group_cleanup_verified']
    assert not result['cleanup']['sigkill_dispatched']
    assert result['no_listener_after'] and not (directory / 'listener-after-ss.txt').read_text().strip()
    assert f'pid={result["pid"]},' in (directory / 'listener-ss.txt').read_text()
    assert 'running' in (directory / 'agent.stdout').read_text()
    return result


v1, v2 = read_attempt(first), read_attempt(second)
assert v1['status'] == 'failed' and not v1['listener_owned']
assert v1['errors'] == ["ValueError('invalid UDP listener row')"]
assert v2['status'] == 'agent_only_passed' and v2['listener_owned']
assert v2['listener_row'] == (second / 'listener-ss.txt').read_text().strip()
assert not v2['errors']
assert not v2['px4_started'] and not v2['xrce_client_authenticated']
assert not v2['typed_dds_provenance'] and not v2['fusion_qualified']

paths = [
    'tools/benchmark/agent_owned_listener.py',
    'tests/benchmark/test_agent_owned_listener.py',
    'docs/AGENT_OWNED_LISTENER_REPORT.md',
    'docs/superpowers/specs/2026-10-12-agent-owned-listener-design.md',
    'docs/superpowers/plans/2026-10-12-agent-owned-listener.md',
    'results/agent-owned-listener-dev-1701-seal.py',
]
for directory in (first, second):
    paths.extend(str(file.relative_to(root)).replace('\\', '/') for file in directory.iterdir() if file.is_file())
paths = sorted(set(paths))
manifest = {
    'schema': 'agent-owned-listener-evidence-v1',
    'attempts': {'first': 'failed_parser', 'second': 'agent_only_passed'},
    'px4_dds_or_fusion_qualified': False,
    'members': {path: {'sha256': digest((root / path).read_bytes()), 'bytes': (root / path).stat().st_size}
                for path in paths},
}
archive_path = root / 'evidence/agent-owned-listener-dev-1701.zip'
with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in paths:
        archive.write(root / path, path)
    archive.writestr('manifest.json', json.dumps(manifest, indent=2, sort_keys=True))
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for path, record in manifest['members'].items():
        data = archive.read(path)
        assert digest(data) == record['sha256'] and len(data) == record['bytes']
print(json.dumps({'archive': str(archive_path), 'sha256': digest(archive_path.read_bytes()),
                  'members': len(paths) + 1, 'v1': v1['status'], 'v2': v2['status']}))
