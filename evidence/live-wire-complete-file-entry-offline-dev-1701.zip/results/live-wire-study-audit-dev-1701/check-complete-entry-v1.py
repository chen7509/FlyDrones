"""Retain one complete synthetic file audit; no execution authority."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

from tests.benchmark.live_wire_complete_fixture import build_complete_fixture
from tools.benchmark import (  # noqa: F401 -- load selected audit code before copying it
    audit_live_wire_coverage,
    audit_live_wire_resources,
    audit_live_wire_runtime,
    audit_live_wire_safety,
    audit_live_wire_ulog,
    audit_live_wire_workload,
    native_supervisor_integration,
)
from tools.benchmark.audit_live_wire_study import audit_live_wire_study


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def sources(root):
    values = {}
    for module in tuple(sys.modules.values()):
        name = getattr(module, "__file__", None)
        if name:
            path = Path(name).resolve()
            if path.suffix == ".py" and path.is_relative_to(root):
                values[path.relative_to(root).as_posix()] = path.read_bytes()
    return values


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--producer", required=True)
    args = parser.parse_args()
    root = Path.cwd().resolve()
    output = root / "results/live-wire-study-audit-dev-1701/complete-file-entry-v1"
    output.mkdir()
    before = sources(root)
    for name, raw in before.items():
        target = output / "source-before" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    (output / "source-before.json").write_text(json.dumps({k:sha(v) for k,v in before.items()}, indent=2))
    package = output / "synthetic-package"
    package.mkdir()
    manifest, capture = build_complete_fixture(package)
    result = audit_live_wire_study(manifest)
    assert result["refusals"] == [], result["refusals"]
    assert len(result["checks"]) == 21
    assert not any(result[k] for k in ("record_chain_qualified", "live_qualified", "fusion_qualified"))
    assert not (package / "audit.json").exists(), "read-only auditor wrote its declared output"
    after = {name:sha((root/name).read_bytes()) for name in before}
    assert after == {k:sha(v) for k,v in before.items()}, "producer drift"
    late = {k:sha(v) for k,v in sources(root).items() if k not in before}
    result.update(producer=args.producer, synthetic_package=str(package), source_after=after,
                  late_loaded_repository_sources=late, complete_runtime_freeze_qualified=False)
    (output / "audit.json").write_text(json.dumps(result, allow_nan=False, indent=2))
    print(json.dumps(dict(stages=list(result["checks"]), consumed_files=len(result["consumed_files"]),
                          copied_sources=len(before), late_loaded_sources=late,
                          record_chain_qualified=False, physical_execution_qualified=False,
                          live_qualified=False, fusion_qualified=False)))


if __name__ == "__main__":
    main()
