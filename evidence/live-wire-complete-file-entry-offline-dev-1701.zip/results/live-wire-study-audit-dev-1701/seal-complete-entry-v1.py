"""Seal the completed synthetic audit without repeating its execution."""
import hashlib
import json
import zipfile
from pathlib import Path


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


base = Path('results/live-wire-study-audit-dev-1701')
retained = base / 'complete-file-entry-v1'
audit = json.loads((retained / 'audit.json').read_text())
assert not audit['refusals'] and len(audit['checks']) == 21
assert audit['producer'] == '79b4500'
assert not any(audit[k] for k in ('record_chain_qualified', 'live_qualified', 'fusion_qualified'))
late_dir = retained / 'source-post-load-only'
late_dir.mkdir()
for name, expected in audit['late_loaded_repository_sources'].items():
    raw = Path(name).read_bytes()
    assert sha(raw) == expected
    target = late_dir / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write(raw)
files = sorted(p for p in retained.rglob('*') if p.is_file())
files += [base / name for name in (
    'check-complete-entry-v1.py', 'seal-complete-entry-v1.py',
    'complete-entry-red-v1.txt', 'complete-entry-green-v1.txt',
    'complete-entry-windows-regression-v1.txt', 'complete-entry-wsl-regression-v1.txt',
    'complete-entry-retained-v1.txt', 'complete-entry-publication-ruff.txt',
    'complete-entry-publication-diff.txt',
)]
files += [Path(name) for name in (
    'docs/LIVE_WIRE_STUDY_PREPARATION_REPORT.md', 'docs/LIVE_WIRE_RAW_EVIDENCE_MAP.md',
    'docs/superpowers/specs/2026-10-08-live-wire-study-design.md',
    'docs/superpowers/plans/2026-10-08-live-wire-study.md',
    '.superpowers/sdd/2026-10-08-live-wire-study/progress.md',
)]
assert len(files) == len(set(files))
blobs = {p.as_posix(): p.read_bytes() for p in files}
rows = [dict(path=p, bytes=len(raw), sha256=sha(raw)) for p, raw in blobs.items()]
manifest = dict(
    schema='offline-wire-complete-entry-evidence-v1', producer_commit='79b4500',
    scope='synthetic full file-entry audit; no physical or native execution',
    source_boundary='76 loaded sources copied before/checked after; 3 lazy sources copied post-load only',
    complete_runtime_freeze_qualified=False, record_chain_qualified=False,
    physical_execution_qualified=False, live_qualified=False, fusion_qualified=False,
    whole_package_review_complete=False, members=rows,
)
out = Path('evidence/live-wire-complete-file-entry-offline-dev-1701.zip')
with zipfile.ZipFile(out, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name, raw in blobs.items():
        archive.writestr(name, raw)
    archive.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(out) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(rows) + 1
    for row in rows:
        raw = archive.read(row['path'])
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
summary = dict(path=str(out), members=len(rows) + 1, bytes=out.stat().st_size,
               sha256=sha(out.read_bytes()), crc_verified=True, member_hashes_verified=True)
with (base / 'complete-entry-seal-v1.json').open('x') as stream:
    json.dump(summary, stream, indent=2)
print(json.dumps(summary))
