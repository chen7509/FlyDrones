import json
import re
import subprocess
from pathlib import Path

out=Path(__file__).resolve().parent
root=out.parents[1]
seal=json.loads((root/'evidence/openvins-owned-bootstrap-dev-1701-manifest.json').read_text())
body=json.loads((out/'pr-before.json').read_text(encoding='utf-8-sig'))['body'].replace('\r\n','\n')
marker='## Startup gate remains open'
addition='''Owned listener/bootstrap composition now joins the actual private socket adapter to the cold state machine. One frozen ordinary-process case completed the empty/first/latest-replay/500 modeled-sample chain across three same-owner connections in2.280928s;5 negative cases refused. All6 children exited0 without signals, selected hashes were stable, disk journals matched memory. This is synthetic fixture throughput, not live PX4 convergence or transmitted MAVLink evidence. One reviewed final2s-deadline gap was fixed after2 behavioral REDs. Report: `docs/OPENVINS_OWNED_BOOTSTRAP_REPORT.md`.

'''
assert marker in body
body=body.replace(marker,addition+marker)
pattern=r'Latest full regression \(owned read-only listener transport\):.*?(?=\n\nIndependent review found delayed refusal)'
replacement='''Latest full regression (owned listener/bootstrap composition): **3193 passed, 3 skipped, 2 existing warnings**, exit0. Focused adjacent suite **130 passed**; changed Ruff/diff passed, no full-repository lint claim. Independent read-only code/harness review found a final-frame deadline gap;2 exact2s counterexamples failed then passed. A separate test-edit typo was exposed by Ruff and a precise refusal-reason assertion before correction; the earlier broad-assertion pass is not treated as coverage. Six frozen local cases retained all outcomes, exact command/control evidence, cleanup and stable selected hashes. The source-copy audit distinguishes one harness CRLF working-tree file from its LF Git blob; exact selected bytes remain preserved. No actual PX4/MAVLink/ODOMETRY or physical study was run; pytest retains its existing temporary CLI smoke fixtures.'''
body,n=re.subn(pattern,replacement,body,flags=re.S)
assert n==1
body=body.replace('Latest archive:','Preceding archive:',1)
record=(f'\n- `docs/OPENVINS_OWNED_BOOTSTRAP_REPORT.md`\n\nLatest archive: `{seal["archive"]}`, '
        f'SHA256 `{seal["sha256"]}`, {seal["members"]} members, CRC/member hashes verified. '
        'Kernel fixture producer1cd6e93. Network/live/fusion qualification remains false.\n')
body=body.replace('## Reports and evidence\n','## Reports and evidence\n'+record)
with (out/'pr-body.txt').open('x',encoding='utf-8',newline='\n') as f:f.write(body)
subprocess.run(['gh','pr','edit','65','--repo','chen7509/FlyDrones','--body-file',str(out/'pr-body.txt')],check=True)
raw=subprocess.check_output(['gh','pr','view','65','--repo','chen7509/FlyDrones','--json','body,headRefOid,isDraft'],text=True,encoding='utf-8')
with (out/'pr-after.json').open('x',encoding='utf-8',newline='\n') as f:f.write(raw)
actual=json.loads(raw)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert actual['headRefOid']==head and actual['isDraft'] is True
assert actual['body'].replace('\r\n','\n')==body
print('PR65 exact normalized body/draft/head verified: '+head)
