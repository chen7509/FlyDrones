import hashlib
import json
import re
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
sha=lambda data:hashlib.sha256(data).hexdigest()
archive=ROOT/'evidence/openvins-owned-bootstrap-dev-1701.zip'
external=archive.with_name('openvins-owned-bootstrap-dev-1701-manifest.json')
assert not archive.exists() and not external.exists()
assert (OUT/'full-tests-exit.txt').read_text().strip()=='0'
assert re.search(r'3193 passed, 3 skipped, 2 warnings in',(OUT/'full-tests.txt').read_text())
assert sha((ROOT/'evidence/openvins-listener-transport-dev-1701.zip').read_bytes())=='7d18602bf93f31e0f3412114790db5e336aa8dfa0221d45f861bd9d44a3c7b0e'
matrix=json.loads((OUT/'kernel-v1/summary.json').read_text())
assert matrix['complete'] and matrix['files_stable'] and len(matrix['results'])==6
assert sum(r['evidence']['transport_bootstrap_complete'] for r in matrix['results'])==1
for case in matrix['results']:
    proof=case['evidence']
    assert not any(proof[k] for k in ('network_authorized','fusion_qualified','live_convergence_qualified'))
    assert case['harness_error'] is None and case['cleanup']['exit']==0 and case['cleanup']['signals']==[]
    folder=OUT/'kernel-v1'/case['case']
    server=json.loads((folder/'server.json').read_text())
    assert all(server['eof']) and server['error'] is None
    assert [json.loads(line) for line in (folder/'journal.jsonl').read_text().splitlines()]==proof['events']
    if case['case']=='normal500':
        assert proof['modeled_accepted_samples']==500 and len(proof['transports'])==3
        assert all(t['transport_complete'] for t in proof['transports'])
pros=json.loads((OUT/'kernel-v1/prospective.json').read_text())
assert pros['files']==json.loads((OUT/'kernel-v1/post-hashes.json').read_text())
for row in json.loads((OUT/'source-copy-provenance.json').read_text())['members']:
    assert sha((OUT/'selected-source-copy'/row['path']).read_bytes())==row['recorded_sha']
paths=sorted(p for p in OUT.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
paths += [ROOT/p for p in (
    'tools/benchmark/openvins_owned_bootstrap.py',
    'tests/benchmark/test_openvins_owned_bootstrap.py','tests/benchmark/check_openvins_owned_bootstrap.py',
    'docs/OPENVINS_OWNED_BOOTSTRAP_REPORT.md',
    'docs/superpowers/specs/2026-10-08-owned-bootstrap-composition-design.md',
    'docs/superpowers/plans/2026-10-08-owned-bootstrap-composition.md',
    '.superpowers/sdd/2026-10-08-owned-bootstrap-composition/progress.md')]
payload={p.relative_to(ROOT).as_posix():p.read_bytes() for p in paths}
assert len(paths)==len(payload)
manifest=dict(schema='evidence-members-v1',producer='1cd6e93',
    members=[dict(path=name,bytes=len(data),sha256=sha(data)) for name,data in sorted(payload.items())],
    physical_network_qualified=False,fusion_qualified=False,
    scope='owned ordinary socket plus modeled cold bootstrap; no actual PX4/MAVLink')
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in payload.items():z.writestr(name,data)
    z.writestr('member-manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for member in manifest['members']:
        data=z.read(member['path'])
        assert len(data)==member['bytes'] and sha(data)==member['sha256']
    count=len(z.namelist())
result=dict(archive=archive.relative_to(ROOT).as_posix(),sha256=sha(archive.read_bytes()),
    bytes=archive.stat().st_size,members=count,crc_verified=True,member_hashes_verified=True,
    historical_archive_unchanged=True)
with external.open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
print(json.dumps(result))
