import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
import zipfile

import numpy as np

root=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(root),str(root/'src')]
from tools.benchmark.audit_inertial_consistency import audit_imu_delivery, audit_inertial_window

base=Path(__file__).resolve().parent
archive=root/'evidence/openvins-motion-readiness-dev-1701.zip'
archive_sha=hashlib.sha256(archive.read_bytes()).hexdigest()
assert archive_sha=='87a1eb39053ba72b84136908ae800799db7dc54b7fe81a64b20f5f4bd8e617b6'
prefix='results/openvins-motion-readiness-dev-1701/capture-v1/'
consumed={}
with zipfile.ZipFile(archive) as z:
    manifest=json.loads(z.read('SHA256-MANIFEST.json'))
    def read(name):
        key=prefix+name
        data=z.read(key);sha=hashlib.sha256(data).hexdigest()
        assert sha==manifest[key]['sha256'] and len(data)==manifest[key]['bytes']
        consumed[key]=manifest[key]
        return data
    def rows(name): return [json.loads(line) for line in read(name).splitlines()]
    raw=rows('events.jsonl'); requests=rows('shadow/native-requests.jsonl');acks=rows('shadow/native-acks.jsonl')
    truth=rows('motion-ground-truth.jsonl');states=rows('shadow/states.jsonl')
    gravity=[float(v) for v in ET.fromstring(read('world.sdf')).findtext('world/gravity').split()]
delivery=audit_imu_delivery(raw,requests,acks)
windows=[]
for start,end in [(4900000000,5000000000),(5000000000,5100000000),(5100000000,5200000000),
                  (5200000000,5300000000),(5000000000,6600000000),(8000000000,9000000000)]:
    windows.append(audit_inertial_window(raw,truth,start,end,gravity=gravity))
state_map={s['sample_ns']:s for s in states}
native=[]
for w in windows:
    a,b=state_map[w['start_ns']],state_map[w['end_ns']]
    delta=np.array(b['imu_state'][7:10])-np.array(a['imu_state'][7:10])
    native.append(dict(start_ns=w['start_ns'],end_ns=w['end_ns'],estimated_delta_velocity_native_m_s=delta.tolist(),
                       estimated_delta_velocity_norm_m_s=float(np.linalg.norm(delta)),
                       public_start=a['public_initialized'],public_end=b['public_initialized'],
                       last_regular_update_end_s=b['last_regular_update_s'],
                       scope='stored native state difference; no claim of aligned world components'))
report=dict(archive_sha256=archive_sha,consumed_members=consumed,gravity_world=gravity,
            delivery=delivery,windows=windows,native_state_differences=native,
            tool_sha256=hashlib.sha256((root/'tools/benchmark/audit_inertial_consistency.py').read_bytes()).hexdigest(),
            new_estimator_or_physics_run=False,root_cause_proven=False,fusion_eligible=False)
with (base/'audit.json').open('x') as f:json.dump(report,f,indent=2)
print(json.dumps(dict(delivery=delivery,windows=windows,native=native),indent=2))
