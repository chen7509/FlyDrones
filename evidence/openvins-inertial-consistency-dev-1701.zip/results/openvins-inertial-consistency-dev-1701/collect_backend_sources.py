import hashlib
import json
from pathlib import Path
import urllib.request

dest=Path(__file__).resolve().parent/'backend-sources'
dest.mkdir(exist_ok=False)
manifest=[]
def fetch(name,url):
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'FlyDrones-diagnosis'}),timeout=30) as r:data=r.read()
    with (dest/name).open('xb') as f:f.write(data)
    manifest.append(dict(file=name,url=url,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
    return data
for label,repo,tag,files in [
    ('gzphysics','gazebosim/gz-physics','gz-physics7_7.8.0',['dartsim/src/KinematicsFeatures.cc','dartsim/src/SimulationFeatures.cc','LICENSE']),
    ('dart','dartsim/dart','v6.13.2',['dart/simulation/World.cpp','dart/dynamics/Skeleton.cpp','dart/dynamics/Frame.cpp','LICENSE'])]:
    try:
        fetch(label+'-metadata.json','https://api.github.com/repos/'+repo)
        info=json.loads(fetch(label+'-tag.json',f'https://api.github.com/repos/{repo}/git/ref/tags/{tag}'))
        obj=info['object']
        if obj['type']=='tag':obj=json.loads(fetch(label+'-tag-object.json',obj['url']))['object']
        assert obj['type']=='commit'
        sha=obj['sha']
        for name in files:
            try:fetch(label+'-'+name.replace('/','__'),f'https://raw.githubusercontent.com/{repo}/{sha}/{name}')
            except Exception as e:manifest.append(dict(file=name,error=repr(e)))
    except Exception as e:manifest.append(dict(repo=repo,error=repr(e)))
with (dest/'manifest.json').open('x') as f:json.dump(manifest,f,indent=2)
print(json.dumps(manifest,indent=2))
