import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

root=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(root),str(root/'src')]
from tools.benchmark.audit_inertial_consistency import audit_imu_delivery

out=Path(__file__).resolve().parent
original=json.loads((out/'audit.json').read_text())
source=subprocess.check_output(['git','show','fcf6b8f:tools/benchmark/audit_inertial_consistency.py'],cwd=root)
assert hashlib.sha256(source).hexdigest()==original['tool_sha256']
with (out/'audit-source-before-review.py').open('xb') as f:f.write(source)
archive=root/'evidence/openvins-motion-readiness-dev-1701.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==original['archive_sha256']
prefix='results/openvins-motion-readiness-dev-1701/capture-v1/'
with zipfile.ZipFile(archive) as z:
    def rows(name):
        data=z.read(prefix+name)
        assert hashlib.sha256(data).hexdigest()==original['consumed_members'][prefix+name]['sha256']
        return [json.loads(line) for line in data.splitlines()]
    result=audit_imu_delivery(rows('events.jsonl'),rows('shadow/native-requests.jsonl'),rows('shadow/native-acks.jsonl'))
assert result==original['delivery']
final=dict(delivery=result,numerical_integration_rerun=False,new_estimator_run=False,
           final_tool_sha256=hashlib.sha256((root/'tools/benchmark/audit_inertial_consistency.py').read_bytes()).hexdigest(),
           original_audit_sha256=hashlib.sha256((out/'audit.json').read_bytes()).hexdigest())
with (out/'final-delivery-check.json').open('x') as f:json.dump(final,f,indent=2)
print(json.dumps(final,indent=2))
