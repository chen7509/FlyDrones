import hashlib,json,subprocess
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent
def digest(p):
 b=p.read_bytes();return dict(path=p.relative_to(root).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
names=subprocess.check_output(['git','ls-files','-z','src','tools','tests','configs']).decode().split('\0');rows=[digest(root/n) for n in names if n and (root/n).is_file()]
with (raw/'product-before.json').open('xb') as f:f.write(json.dumps(rows,indent=2).encode())
paths=['ROADMAP.md','docs/WINDOWED_TRAINING_BACKWARD_PRODUCTION_REPORT.md','evidence/windowed-training-production-publication.json','results/windowed-training-production-dev-1701/NEXT_PHASE.md','results/windowed-training-production-dev-1701/independent-window-review.md','results/windowed-training-production-dev-1701/executor-fix-pass.md','docs/superpowers/specs/2026-10-15-windowed-training-backward-design.md','docs/superpowers/plans/2026-10-15-windowed-training-backward.md','docs/superpowers/specs/2026-09-22-connectome-constrained-realtime-training-design.md','docs/superpowers/specs/2026-09-22-resumable-connectome-curriculum-binding.md','docs/TARGET_BEARING_STATIC_V3_HARNESS_FAILURE_REPORT.md','evidence/flydrones-history-through-loader-path-research-dev-1701.json','evidence/flydrones-history-through-admitted-executor-dev-1701.json']
for p in paths:(root/p).read_bytes().decode('utf-8-sig')
with (raw/'context-readback.json').open('xb') as f:f.write(json.dumps(dict(read=[digest(root/p) for p in paths],old_product_files=len(rows),scope='Windows data/source only;no resource snapshot;initial wrong train_curriculum.py path and escaped inline template command ParserError retained in conversation,not experimental/native failure'),indent=2).encode())
print(json.dumps(dict(old_product_files=len(rows),read_paths=len(paths))))
