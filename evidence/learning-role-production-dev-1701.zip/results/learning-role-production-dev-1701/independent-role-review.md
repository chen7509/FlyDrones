# Independent learning-role source review

Verdict: request changes. Critical: 0; Important: 1; Minor: 1.

Base HEAD: `ac1954e99b943b3d46a899cbacbc52a1d2fda97b`.

This is the one independent whole-source review of the supplied role-production implementation and its design/plan. Method: File/source reads and read-only git diff. No project imports, tests, product edits, target/native/Linux/resource/network actions. Only these review artifacts were written.

## I-01: Validate the live learning setup before restoring (Important, P2)

Location: `src/flydrones/connectome_training/curriculum_session.py:390-411`.

restore_checkpoint validates model values and role metadata, but never calls validate_learning_setup. That validator is the only code which checks requires_grad and live Adam parameter object membership/order.

Trigger: Create a sensory-readout-v1 session, reorder or replace the two live optimizer parameter objects (or turn a frozen parameter's requires_grad on), then restore a valid checkpoint for that same role.

Impact: The restore can return successfully with a setup that violates its declared role contract. Reordered live objects can receive optimizer moments in the wrong role positions. Training/save eventually reject the setup, but only after restore has already copied model values and loaded optimizer state. The spec explicitly requires actual flags and optimizer membership/order checks at checkpoint boundaries.

Requested change: Call validate_learning_setup before any restore mutation and verify the setup after loading staged optimizer state. Add a focused restore-boundary regression proving drift rejection before model/optimizer mutation.

Evidence limit: Static control-flow review only; no reproduction or test executed by reviewer.

## M-01: Preflight serialized Adam state before committing model values (Minor, P3)

Location: `src/flydrones/connectome_training/curriculum_session.py:406-412`.

All model parameters are copied before optimizer.load_state_dict is called; load_checkpoint checks only the payload envelope, metadata, and file digest, while validate_learning_state checks only model_state.

Trigger: A freshly rehashed checkpoint has valid role metadata/model_state but malformed optimizer groups (for example, wrong group parameter count).

Impact: The optimizer load rejects only after the active model values have been replaced. More subtle moment/order corruption has no role-specific validation. This is inherited restore robustness behavior, rather than a demonstrated frozen-value or cross-role bypass, so it is recorded as Minor.

Requested change: Validate/stage the role-ordered serialized Adam groups and moment tensor shapes/finiteness before committing model values, or make failed restores transactional. Preserve the canonical active-name order when binding serialized optimizer slots.

Evidence limit: Static ordering review only; no reproduction or test executed by reviewer.

## Paths assessed as consistent with the design

- All three fixed profile memberships are correct; configuration precedes Adam creation and Adam receives the selected live Parameter objects in canonical active-name order.
- Default new curriculum preserves prior four-parameter update participation and deliberately changes curriculum model identity.
- Cross-role metadata and source-derived frozen payload validation occur before model weight copies in curriculum and explicit inference.
- Explicit inference derives its role/frozen baseline from the actual source/parameter construction instead of accepting checkpoint-supplied frozen hashes; it retains unqualified training/flight provenance and freezes all parameters.
- Legacy no-profile checkpoints retain their original base identity path and are labeled legacy-unspecified. Initialization-only inference has no learned role.
- CLI argparse fixed choices reject an invalid learning profile before restart/output/session effects. No topology, data, loss, window algorithm, or curriculum gate changes were found in the reviewed diff.

## Scope observations

- Whole active initialization identity is not promised by this spec: it explicitly binds frozen initial identities only. shared-dynamics-v1 therefore has no frozen coefficient hashes; changing active initialization can retain model_identity and change the newly computed initial_losses on resume. This inherited baseline limitation is not a blocker for this scoped role-participation task, and must not be described as a full-baseline or fairness guarantee.
- Role metadata and hashes are controlled procedure/data joins, not source authentication or proof of historical parameter participation. Coherently relabeling an entire checkpoint into another mathematically compatible role cannot prove which producer procedure actually ran; this is outside the stated hostile-Python/source-authentication scope.
- The current tests exercise fresh file SHA after frozen value tampering; the source checks also appear to refuse a coherently rewritten frozen-role digest because the expected contract is derived independently. Adding that exact metadata-tamper regression would strengthen evidence but is not an additional correctness finding.
- No dynamic verification, complete MaleCNS run, native run, or measured learning/fairness/source/flight qualification was performed by this review.

## Exact reviewed bytes

- `src/flydrones/connectome_training/training_roles.py`: `1f608508380dc77f79efaa78709865eaa077f0aed427fb773475b835fcef4459`
- `src/flydrones/connectome_training/curriculum_session.py`: `f012f85abd3b4759402698b01533f01818865f431e9ccc60c33c878efa3e04a8`
- `src/flydrones/connectome_training/inference_artifact.py`: `2e492d82af38a851ff61f0e3ede1699a7edfc8b3022817a839d49f272ea2157e`
- `src/flydrones/connectome_training/inference.py`: `33602e080de79d230df29183917dc0ee3fbbf079725788a2f0dcea6de12da69e`
- `tools/connectome_training/run_curriculum.py`: `ec13554007bbd2ab7e5c6336c4d5db238b1959a8c6943d08e2c91fd97d62ac96`
- `tests/connectome_training/test_learning_roles.py`: `2935194d0bc74662e0cbb405cf658e3279828ab459ece88f535fc8448f222a0d`
- `docs/superpowers/specs/2026-10-15-connectome-learning-roles-design.md`: `24672cdb38683da47cc861833549e309a53711f5e76b1eaa3e463c92a02044db`
- `docs/superpowers/plans/2026-10-15-connectome-learning-roles.md`: `0d57b388309421541bdd8a4c72920b6473ff197b167ed1d6b8d1b2a27e5a7faf`
- `src/flydrones/connectome_training/checkpoint.py`: `52ae0c2a4f385c576b70b0c4605c53df01064620e66a5f62306e256b21f98b1f`
- `src/flydrones/connectome_training/model.py`: `81b2c4cfbc947d239794b3d3b8ed1e1c3f4d473cec2c82a6ad5e15561f63265c`
- `src/flydrones/connectome_training/parameters.py`: `5c0c7e7c1f21103b0c338d2e74022667235517c8aa91e14bfc4079528e31cb83`
- `src/flydrones/connectome_training/curriculum.py`: `28e5cc446dc82923e9c2050a3c5b867fdab2d939253c6f7d378e925e1258368d`
- `src/flydrones/connectome_training/trainer.py`: `6c90c2bc7796bc06c848f01f0ab00e424e6c77f69f209900dbef709e43e42820`
- `results/learning-role-production-dev-1701/roles-red-source/src/flydrones/connectome_training/curriculum_session.py`: `493816d42d6e74ed90d9e2da7aa618a806e7717203d4cb152592043370cc3cdf`

Original baseline source snapshots were read under `results/learning-role-production-dev-1701/roles-red-source`; the production diff was compared read-only. This original report is immutable. A subsequent bounded executor fix pass is not a second independent whole-source review.

