"""Actual parameter participation for controlled connectome learning ablations."""
from __future__ import annotations

import json
from hashlib import sha256

import torch

PARAMETER_ORDER = ('raw_input_gain', 'type_bias_mv', 'raw_tau_m', 'readout')
DEFAULT_LEARNING_PROFILE = 'shared-dynamics-v1'
ROLE_PROFILES = {
    'descending-only-v1': ('readout',),
    'sensory-readout-v1': ('raw_input_gain', 'readout'),
    DEFAULT_LEARNING_PROFILE: PARAMETER_ORDER,
}


def learning_parameters(profile: str) -> tuple[str, ...]:
    if type(profile) is not str or profile not in ROLE_PROFILES:
        raise ValueError('unsupported learning profile')
    return ROLE_PROFILES[profile]


def _tensor_digest(value: torch.Tensor) -> str:
    header = json.dumps({'shape': list(value.shape), 'dtype': str(value.dtype)}, sort_keys=True).encode()
    data = value.detach().cpu().contiguous().view(torch.uint8).numpy().tobytes()
    return sha256(header + b'\0' + data).hexdigest()


def _named(model):
    named = dict(model.named_parameters())
    if tuple(named) != PARAMETER_ORDER:
        raise ValueError('learning parameter membership/order does not match core')
    if any(value.requires_grad for value in model.buffers()):
        raise ValueError('learning cannot optimize fixed topology buffers')
    if any(value.layout != torch.strided or not torch.isfinite(value).all() for value in named.values()):
        raise ValueError('learning parameters must be finite strided tensors')
    return named


def _record(model, profile):
    active = learning_parameters(profile)
    named = _named(model)
    frozen = [name for name in named if name not in active]
    return dict(schema='connectome-learning-roles-v1', profile=profile, trainable=list(active), frozen=frozen,
                frozen_initial_sha256={name: _tensor_digest(named[name]) for name in frozen})


def configure_learning_roles(model, profile: str) -> dict:
    contract = _record(model, profile)
    for name, parameter in model.named_parameters():
        parameter.requires_grad_(name in contract['trainable'])
        parameter.grad = None
    return contract


def learning_identity_suffix(contract: dict) -> str:
    learning_parameters(contract['profile'])
    digest = sha256(json.dumps(contract, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()
    return f":learning={contract['profile']}:{digest}"


def validate_learning_state(model, state: dict, contract: dict) -> None:
    if _record(model, contract['profile']) != contract:
        raise ValueError('learning frozen initialization contract changed')
    named = _named(model)
    if not isinstance(state, dict) or set(state) != set(named):
        raise ValueError('learning state parameter membership mismatch')
    for name, parameter in named.items():
        value = state[name]
        if (not isinstance(value, torch.Tensor) or value.layout != torch.strided
                or value.shape != parameter.shape or value.dtype != parameter.dtype
                or not torch.isfinite(value).all()):
            raise ValueError(f'learning parameter state invalid: {name}')
        if name in contract['frozen'] and _tensor_digest(value) != contract['frozen_initial_sha256'][name]:
            raise ValueError(f'frozen learning parameter changed: {name}')


def validate_learning_setup(model, optimizer, contract: dict) -> None:
    named = _named(model)
    validate_learning_state(model, named, contract)
    if any(p.requires_grad != (name in contract['trainable']) for name, p in named.items()):
        raise ValueError('learning parameter gradient flags changed')
    expected = [id(named[name]) for name in contract['trainable']]
    actual = [id(p) for group in optimizer.param_groups for p in group['params']]
    if actual != expected:
        raise ValueError('optimizer learning parameter membership/order changed')
