import hashlib,json
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes().decode('utf-8-sig'))
def save(n,v):
 with (raw/n).open('xb') as f:f.write(json.dumps(v,indent=2).encode())
archives=load(raw/'historical-archives-postsoftware.json');assert archives['count']==296 and archives['bytes']==878584611
for row in archives['members']:
 h=hashlib.sha256();n=0
 with (root/row['path']).open('rb') as f:
  while block:=f.read(1048576):h.update(block);n+=len(block)
 assert n==row['bytes'] and h.hexdigest()==row['sha256']
products=load(raw/'product-preservation-postsoftware.json');before=load(raw/'product-before.json')
expected=set(products['changed']);assert len(before)==products['count']==822 and len(expected)==4
assert {r['path'] for r in before if sha((root/r['path']).read_bytes())!=r['sha256']}==expected
prior=load(root/'results/windowed-training-production-dev-1701/refused-attempt-preservation.json');parent=root/'results/target-bearing-runtime-freeze-v4-dev-1701'
for row in prior['private_excluded']:
 b=(root/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
assert set(p.name for p in parent.iterdir())=={'run-static-preparation-v4.py','firstfacts.json','completion.json',*[Path(r['path']).name for r in prior['private_excluded']]}
assert load(parent/'completion.json')['state']=='REFUSED_UNCONSUMED' and not load(parent/'completion.json')['consumed']
sources=load(root/'results/static-v4-attempt-dev-1701/preflight.json')['sources'];assert len(sources)==382 and sources==load(root/'results/static-v4-attempt-dev-1701/cli-completion.json')['source_after']
names={r['path'] for r in sources};evolved=[]
for row in sources:
 assert sha((root/'results/static-v4-attempt-dev-1701/source-before'/row['path']).read_bytes())==row['sha256']
 if sha((root/row['path']).read_bytes())!=row['sha256']:evolved.append(row['path'])
assert set(evolved)==(expected&names)|{'src/flydrones/connectome_training/dataset.py','src/flydrones/connectome_training/trainer.py'}
release=root/'evidence/static-v4-executor-completion-release.frame';assert sha(release.read_bytes())=='f7ce10ba80d5554aadd16dd29b8bb1ae8aea8e811ce0bd2d5a9b01cf711f72cc'
for row in prior['histories']:assert sha((root/row['path']).read_bytes())==row['sha256']
save('refused-attempt-preservation.json',dict(state='REFUSED_UNCONSUMED',parent_exact_six_files=True,private_excluded=prior['private_excluded'],source382_snapshots_unchanged=True,current_source_evolved=evolved,role_phase_modified_outside_original382=sorted(expected-names),new_source='src/flydrones/connectome_training/training_roles.py',release_sha256=sha(release.read_bytes()),release_stale=True,physical_absent=not (root/'results/target-bearing-physical-capture-dev-1701').exists(),resource_poll=False,target_native_action=False,histories=prior['histories'],prior_helper_failure='preserve.py wrote archive/product ledgers then incorrectly assumed every role edit belonged to original382. Original outputs retained; additive v2 validates actual membership, no missing prepins fabricated.'))
pr=load(root/'results/windowed-training-production-dev-1701/publication-readback.stdout');assert pr['headRefOid']=='ac1954e99b943b3d46a899cbacbc52a1d2fda97b' and pr['isDraft']
with (raw/'previous-pr-body.md').open('xb') as f:f.write(pr['body'].encode())
save('previous-pr-body.json',dict(head=pr['headRefOid'],bytes=len(pr['body'].encode()),characters=len(pr['body']),sha256=sha(pr['body'].encode()),full_prior_history=load(root/'evidence/windowed-training-production-publication.json')['prior_PR_full_history']))
print(json.dumps(dict(evolved=evolved,outside_original382=sorted(expected-names),previous_PR_characters=len(pr['body']))))
