from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent
s=(root/'results/windowed-training-production-dev-1701/seal.py').read_text()
s=s.replace('windowed-training-production-dev-1701.zip','learning-role-production-dev-1701.zip').replace('windowed-training-production-map-v1','learning-role-production-map-v1').replace('TinyCPU backwardproduction/software only','TinyCPU learning-roleproduction/software only')
s=s.replace("'docs/WINDOWED_TRAINING_BACKWARD_PRODUCTION_REPORT.md'","'docs/CONNECTOME_LEARNING_ROLES_PRODUCTION_REPORT.md'")
s=s.replace('2026-10-15-windowed-training-backward','2026-10-15-connectome-learning-roles')
s=s.replace("'evidence/static-v4-refusal-linear-sequence-publication.json'","'evidence/windowed-training-production-publication.json'")
s=s.replace("'src/flydrones/connectome_training/trainer.py',","'src/flydrones/connectome_training/training_roles.py','src/flydrones/connectome_training/inference.py','src/flydrones/connectome_training/inference_artifact.py','src/flydrones/connectome_training/checkpoint.py','tools/connectome_training/run_curriculum.py','src/flydrones/connectome_training/trainer.py',",1)
s=s.replace("'tests/connectome_training/test_windowed_training.py',","'tests/connectome_training/test_learning_roles.py','tests/connectome_training/test_inference.py','tests/connectome_training/test_inference_artifact.py','tests/connectome_training/test_curriculum_state.py','tests/connectome_training/test_windowed_training.py',",1)
s=s.replace("explicit=[","explicit=['results/learning-role-production-dev-1701-verify-bootstrap.py',",1)
with (raw/'seal.py').open('x',encoding='utf-8') as f:f.write(s)
print('prepared exact current software seal helper')
