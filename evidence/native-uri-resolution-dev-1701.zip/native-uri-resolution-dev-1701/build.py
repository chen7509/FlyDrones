import hashlib,json,shlex,subprocess,shutil
from pathlib import Path
out=Path(__file__).resolve().parent;root=out.parents[1]
def run(args,name):
 p=subprocess.run(args,capture_output=True,text=True,timeout=90)
 (out/(name+'.json')).write_text(json.dumps(dict(args=args,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr),indent=2))
 if p.returncode:raise RuntimeError(name)
 return p.stdout
source=root/'tools/benchmark/native/resource_resolver.cc';binary=out/'resource_resolver'
(out/'source-before.cc').write_bytes(source.read_bytes())
tools=[]
for name in ('g++','pkg-config'):
 p=Path(shutil.which(name));tools.append(dict(name=name,path=str(p),resolved=str(p.resolve()),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(out/'tools-before.json').write_text(json.dumps(tools,indent=2))
flags=shlex.split(run(['pkg-config','--cflags','--libs','gz-sim8','gz-common5-graphics','sdformat14'],'flags'))
run(['g++','--version'],'compiler')
run(['pkg-config','--modversion','gz-sim8','gz-common5-graphics','sdformat14'],'versions')
run(['g++','-std=c++17','-Wall','-Wextra',str(source),'-o',str(binary),*flags],'compile')
ldd=run(['ldd',str(binary)],'ldd')
paths={str(source),str(binary)}
for line in ldd.splitlines():
 for word in line.split():
  if word.startswith('/') and Path(word).is_file():paths.add(word)
(out/'build-hashes.json').write_text(json.dumps([dict(path=p,sha256=hashlib.sha256(Path(p).read_bytes()).hexdigest()) for p in sorted(paths)],indent=2))
run(['python3',str(root/'tests/native/run_uri_resolver_checks.py'),str(binary)],'uri-green')
run(['python3',str(root/'tests/native/run_resource_resolver_checks.py'),str(binary)],'native-regression')
print('URI and prior native checks passed')
