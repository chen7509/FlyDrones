import hashlib,json,os,subprocess,sys,zipfile
from pathlib import Path
p=Path(__file__).resolve().parent;root=p.parents[1];sys.path.insert(0,str(root))
from tools.benchmark.capture_disarmed_sensors import active_resources
from tools.benchmark.declared_runtime_snapshot import snapshot
assert active_resources()==[]
archive=root/'evidence/selected-resource-graph-dev-1701.zip'
expected='af3308d916dcbf0f79d5667eb43e27b80c52ee92f767fd5d17f33e61357462e1'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==expected
with zipfile.ZipFile(archive) as z:
 member='selected-resource-graph-dev-1701/fixed-v2/fixed-discovery.json'
 raw=z.read(member);d=json.loads(raw)
 snap=json.loads(z.read('selected-resource-graph-dev-1701/fixed-v2/discovery-snapshot-pre.json'))
known={x['resolved']:x for x in snap['files']}
edges=[e for e in d['edges'] if e['kind'] in ('texture','mesh','include','collada-image')]
assert len(edges)==25
used=set()
for edge in edges:
 for path in (edge['source'],edge['candidate']):
  source=Path(path);key=str(source.resolve());expected_hash=known[key]['sha256']
  assert hashlib.sha256(source.read_bytes()).hexdigest()==expected_hash,(path,'old member drift')
  used.add(str(source))
 if edge['kind']=='include':
  config=Path(edge['candidate']).parent/'model.config'
  assert hashlib.sha256(config.read_bytes()).hexdigest()==known[str(config.resolve())]['sha256']
  used.add(str(config))
binary=p/'resource_resolver'
for row in json.loads((p/'build-hashes.json').read_text()):used.add(row['path'])
used.update([str(p/'evaluate_frozen_edges.py'),str(root/'tools/benchmark/native/resource_resolver.cc')])
inventory={'actual-query-inputs':sorted(used)}
before=snapshot(inventory)
(p/'query-pre.json').write_text(json.dumps(before,indent=2))
env=dict(os.environ)
for k,v in d['environment'].items():
 if v is None:env.pop(k,None)
 else:env[k]=v
# Explicit research context, not reconstructed historical simulation environment.
env['SDF_PATH']='';env['GZ_FILE_PATH']='';env.pop('GZ_MESH_FORCE_ASSIMP',None)
results=[]
for edge in edges:
 kind={'mesh':'mesh-path'}.get(edge['kind'],edge['kind'])
 args=[str(binary),'uri',kind,edge['source'],edge['text'].strip()]
 q=subprocess.run(args,cwd=root,env=env,capture_output=True,text=True,timeout=10)
 try:record=json.loads(q.stdout)
 except ValueError:record=None
 results.append(dict(edge=edge,args=args,returncode=q.returncode,stdout=q.stdout,stderr=q.stderr,result=record,
  same_as_prior_candidate=q.returncode==0 and record is not None and Path(record['selected'])==Path(edge['candidate']).resolve()))
after=snapshot(inventory)
(p/'query-post.json').write_text(json.dumps(after,indent=2))
summary=dict(producer=sys.argv[1],archive_sha256=expected,member=member,member_sha256=hashlib.sha256(raw).hexdigest(),
 supplied_context='explicit current research env/cwd, not PR48 historical runtime environment',cwd=str(root),
 env={k:env.get(k) for k in ('GZ_SIM_RESOURCE_PATH','SDF_PATH','GZ_FILE_PATH','HOME','GZ_HOMEDIR','GZ_MESH_FORCE_ASSIMP')},
 results=results,successful_queries=sum(q['returncode']==0 for q in results),matching_candidates=sum(q['same_as_prior_candidate'] for q in results),
 input_files_stable=before['files']==after['files'],ambiguity_qualified=False,resource_graph_qualified=False,
 runtime_closure_qualified=False,physical_run=False,estimator_run=False,resources=active_resources())
(p/'fixed-edge-results.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({k:summary[k] for k in ('producer','successful_queries','matching_candidates','input_files_stable','resources')}))
