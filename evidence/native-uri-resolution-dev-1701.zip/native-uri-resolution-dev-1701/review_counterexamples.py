import json,os,subprocess,sys,tempfile
from pathlib import Path
binary=Path(sys.argv[1]).resolve(strict=True);cases=[]
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp);source=p/'world.sdf';source.write_text('<sdf/>')
 (p/'http:example.invalid').write_bytes(b'local file hiding invalid scheme')
 (p/'texture.png').write_bytes(b'x')
 for kind in ('include','texture','collada-image'):
  q=subprocess.run([str(binary),'uri',kind,str(source),'http:example.invalid'],cwd=p,capture_output=True,text=True,timeout=10)
  cases.append(dict(kind=kind,returncode=q.returncode,stdout=q.stdout,stderr=q.stderr,passed=q.returncode!=0))
 q=subprocess.run([str(binary),'uri','collada-image',str(source),'texture.png'],cwd=p,env=dict(os.environ,GZ_MESH_FORCE_ASSIMP='false'),capture_output=True,text=True,timeout=10)
 cases.append(dict(kind='assimp-false',returncode=q.returncode,stdout=q.stdout,stderr=q.stderr,passed=q.returncode==0))
print(json.dumps(dict(cases=cases,passed=sum(c['passed'] for c in cases),failed=sum(not c['passed'] for c in cases)),indent=2))
sys.exit(0 if all(c['passed'] for c in cases) else 1)
