import csv
import json
from pathlib import Path

from pyulog import ULog

from tools.benchmark.audit_openvins_imu_init import score_ekf_init_velocity

root = Path(__file__).resolve().parent
result = json.loads((root / "episode-v1/result.json").read_text(encoding="utf-8"))
ulog = root / "episode-v1" / result["px4_ulogs"][0]["path"]
rows, summary = score_ekf_init_velocity(
    ULog(str(ulog)).get_dataset("vehicle_local_position").data, 24.2, 26.2)
out = root / "replay-v1"
with (out / "init_velocity_window.csv").open("x", newline="", encoding="utf-8") as stream:
    writer = csv.DictWriter(stream, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)
with (out / "init_velocity_summary.json").open("x", encoding="utf-8") as stream:
    json.dump(summary, stream, indent=2, sort_keys=True)
    stream.write("\n")
print(json.dumps(summary, indent=2))
