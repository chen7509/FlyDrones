import csv
import hashlib
import json
import re
from pathlib import Path

root = Path(__file__).resolve().parent
replay = root / "replay-v1"
states = list(csv.DictReader((replay / "states.csv").open(newline="", encoding="utf-8")))
initialized = [r for r in states if r["initialized"] == "1"]
stdout = (replay / "stdout.txt").read_text(encoding="utf-8", errors="replace")
stderr = (replay / "stderr.txt").read_text(encoding="utf-8", errors="replace")
msckf = [int(v) for v in re.findall(r"MSCKF update \((\d+) feats\)", stdout)]
slam = [int(v) for v in re.findall(r"SLAM update \((\d+) feats\)", stdout)]
stage = [dict((k, float(v) if k == "t" else int(v))
              for k, v in re.findall(r"(t|input|clean|tri|chi2|tri_fail|refine_fail|chi2_fail)=([\d.]+)", line))
         for line in stderr.splitlines() if "FD_MSCKF_STAGE" in line]
assert len(initialized) == len(msckf) == len(slam) == len(stage)
assert all(abs(float(r["state_timestamp_s"]) - entry["t"]) < 1e-6
           for r, entry in zip(initialized, stage, strict=True))
phases = {}
for name, left, right in (("before_prelude", 0, 29),
                          ("during_prelude", 29, 33),
                          ("after_prelude", 33, float("inf"))):
    chosen = [i for i, row in enumerate(initialized)
              if left <= float(row["state_timestamp_s"]) < right]
    phases[name] = {
        "image_count": len(chosen),
        "msckf_nonzero_frames": sum(msckf[i] > 0 for i in chosen),
        "msckf_feature_total": sum(msckf[i] for i in chosen),
        "slam_nonzero_frames": sum(slam[i] > 0 for i in chosen),
        "max_slam_count": max((slam[i] for i in chosen), default=0),
        "candidate_attempts": sum(stage[i]["input"] for i in chosen),
        "clean_attempts": sum(stage[i]["clean"] for i in chosen),
        "tri_success_attempts": sum(stage[i]["tri"] for i in chosen),
        "chi2_accept_attempts": sum(stage[i]["chi2"] for i in chosen),
    }
result = {
    "schema": "flydrones-stationary-prelude-replay-phase-summary-v1",
    "note": "diagnostic counts of feature-window attempts, not distinct tracked features",
    "source_sha256": {name: hashlib.sha256((replay / name).read_bytes()).hexdigest()
                      for name in ("states.csv", "stdout.txt", "stderr.txt")},
    "first_initialized_s": float(initialized[0]["state_timestamp_s"]),
    "phases": phases,
}
path = replay / "phase-summary.json"
with path.open("x", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write("\n")
print(json.dumps(result, indent=2))
