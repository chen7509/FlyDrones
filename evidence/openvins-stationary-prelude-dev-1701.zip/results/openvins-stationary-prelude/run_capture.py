"""Run exactly one stationary-prelude development PX4/Gazebo episode."""

import json
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[2]
output = root / "results/openvins-stationary-prelude/episode-v1"
if not output.is_dir() or (output / "stdout.txt").exists() or (output / "result.json").exists():
    raise SystemExit("capture output missing or already attempted; refuse duplicate run")
command = [
    "/usr/bin/time", "-v", "-o", str(output / "resources.txt"),
    sys.executable, str(root / "tools/benchmark/run_episode.py"),
    "--controller", "fly_raw",
    "--world-json", str(root / "results/openvins-texture-dev/fixture-v1/world.json"),
    "--world-sdf", str(root / "results/openvins-texture-dev/fixture-v1/world.sdf"),
    "--output", str(output), "--record-rgb", "--record-camera-info",
    "--development-hover-prelude-s", "4.0",
]
(output / "capture-command.json").write_text(json.dumps(command, indent=2) + "\n")
with (output / "stdout.txt").open("x") as stdout, (output / "stderr.txt").open("x") as stderr:
    result = subprocess.run(command, cwd=root, stdout=stdout, stderr=stderr, check=False)
(output / "exit-code.txt").write_text(f"{result.returncode}\n")
raise SystemExit(result.returncode)
