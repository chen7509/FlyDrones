The first combined disarmed supported-motion OpenVINS capture stops at6.417s when readiness expires: a new heartbeat arrived48ms earlier but was still awaiting journal/fan-out commit. Preserve the partial native output, fresh physics reference, raw sensor/ULog records and recorded group cleanup; do not classify this as VIO accuracy or flight success.

Adds tested fixed-gauge offline metrics using the actual16-value camera state. The prospective pre-anchor origin was unavailable, so accuracy remains indeterminate. Review also found missing runtime freeze coverage and incorrect timeout metadata; these are explicitly retained as historical evidence gaps, not backfilled. One physical run only, no estimator tuning or safety-threshold change.

Validation: targeted105passed, final full regression recorded in report. Changed-file Ruff passes; whole-tree52errors in33unchanged baseline files. Draft stacked onPR47; no ODOMETRY, arming, EKF2 or training.
