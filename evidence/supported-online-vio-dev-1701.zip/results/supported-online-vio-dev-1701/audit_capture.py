import json, hashlib, sys
from pathlib import Path
from collections import Counter
import numpy as np
from scipy.spatial.transform import Rotation
from pyulog import ULog
base=Path(__file__).resolve().parent;root=base.parents[1];sys.path[:0]=[str(root),str(root/'src')]
from tools.benchmark.disarmed_sensor_provenance import audit_event_records
from tools.benchmark.ready_shadow_fanout import digest
from tools.benchmark.physics_substep_trace import _state, phase_closures
from tools.benchmark.openvins_online_shadow import validate_ack
p=base/'capture-v1'
read=lambda n:[json.loads(x) for x in (p/n).read_text().splitlines()]
r=json.loads((p/'result.json').read_text());exitdata=json.loads((base/'exit.json').read_text())
assert r['status']=='capture_failed' and r['estimator_run'] and r['eligible_for_px4_fusion'] is False
assert exitdata['exit']==2 and exitdata['unchanged'] and exitdata['resources']==[]
before=json.loads((base/'producer-before/manifest.json').read_text());after=json.loads((base/'producer-after/manifest.json').read_text());assert before==after
for directory in ['producer-before','producer-after']:
 for n,item in enumerate(before):
  copy=base/directory/(str(n)+'-'+Path(item['path']).name)
  if copy.exists(): assert hashlib.sha256(copy.read_bytes()).hexdigest()==item['sha256']
events=read('events.jsonl');assert [e['source_sequence'] for e in events]==list(range(len(events)))
counts=audit_event_records([{k:v for k,v in e.items() if k!='source_sequence'} for e in events],required_kinds={'imu','rgb','info','depth','heartbeat'})
receipts=read('source-fanout.jsonl');deliveries=[x for x in receipts if x['event']=='source_delivery'];refusals=[x for x in receipts if x['event']=='source_refusal']
for receipt in receipts:
 i=int(receipt['sequence_repr']);assert receipt['source_sha256']==digest(events[i])
 if receipt.get('payload_sha256'):
  ev=events[i]
  payload=(p/ev['payload_path']).read_bytes() if ev['kind']=='info' else (p/'rgb-frames'/f"{ev['sample_ns']}.ppm").read_bytes().split(b'\n',3)[3]
  assert hashlib.sha256(payload).hexdigest()==receipt['payload_sha256']
committed=[x for x in deliveries if 'failure' not in x]
assert len(committed)==r['source_fanout']['committed']==1801
assert [x['source_sequence'] for x in committed]==list(range(1801))
assert len(deliveries)==1802 and len(refusals)==5
for x in committed:
 assert x['begin_ns']<=x['consumers']['shadow']['start_ns']<=x['consumers']['shadow']['returned_ns']<=x['consumers']['readiness']['start_ns']<=x['consumers']['readiness']['returned_ns']<=x['end_ns']
 assert x['dispositions']==dict(shadow='returned',readiness='returned')
fresh=read('native-reference.jsonl');old=read('physics-substeps.jsonl');commands=read('motion-force.jsonl')
assert len(fresh)==6416 and len(old)==12833
for i,x in enumerate(fresh,1):
 assert x['pre_ns']==x['post_ns']==i*1000000 and x['canary_overwritten'] is True
 assert x['truth_for_abort_audit_only'] and x['eligible_for_px4_fusion'] is False
 _state(x)
for i,x in enumerate(old):assert x['phase']==['pre','post'][i%2] and x['sim_ns']==(i//2+1)*1000000
schedule=json.loads((p/'readiness-anchor.json').read_text());anchor=schedule['anchor_ns'];assert anchor==1622000000==schedule['selected_sim_ns']+200000000
assert [x['sim_ns'] for x in commands]==list(range(anchor,6417000000,1000000))
assert all(x['call_returned'] and len(x['per_link'])==6 and all(l['call_returned'] for l in x['per_link']) for x in commands)
assert sum(bool(x['force_world_n'][1]) for x in commands)==1600
assert sum(x['force_world_n'][1] for x in commands)==0
states=read('shadow/states.jsonl');acks=read('shadow/native-acks.jsonl');requests=read('shadow/native-requests.jsonl');fast=read('shadow/fast.jsonl')
assert len(acks)==len(requests)==1667 and len(states)==65
for i,(req,ack) in enumerate(zip(requests,acks)):
 assert req['sequence']==ack['sequence']==i
 validate_ack(ack,sequence=i,kind=ack['kind'],dispatch_ns=ack['dispatch_ns'],acknowledged_ns=ack['acknowledged_ns'])
 assert ack['fusion_eligible'] is False and ack['quality'] is None and ack['reset_counter'] is None
bytime={x['post_ns']:x for x in fresh};matched=[];last=0
for x in states:
 if not x['internal_initialized']:continue
 ns=round(x['state_time_s']*1e9);assert abs(ns-x['state_time_s']*1e9)<=1 and ns>=last and ns<=x['sample_ns'];last=ns
 assert ns in bytime
 matched.append((x,ns,bytime[ns]))
origins=[x for x in matched if anchor-200000000<=x[1]<anchor]
assert not origins
# Exploratory norm-only diagnostic from first internal state; never substitutes missing prospective origin.
start,ts,truth0=matched[0];pn0=np.array(start['imu_state'][4:7]);pt0=np.array(truth0['position'])
lower=[]
for x,ns,t in matched:
 bound=abs(np.linalg.norm(np.array(x['imu_state'][4:7])-pn0)-np.linalg.norm(np.array(t['position'])-pt0))
 lower.append(dict(sample_ns=x['sample_ns'],state_ns=ns,public=x['public_initialized'],norm_difference_m=float(bound)))
(base/'exploratory-displacement.json').write_text(json.dumps(lower,indent=2))
raw_windows=[]
derived=[dict(x,phase='post',sim_ns=x['post_ns'],available=True) for x in fresh]
for name,begin,end in [('lateral_first100ms',anchor+3000000000,anchor+3100000000),('lateral_full',anchor+3000000000,anchor+4600000000)]:
 raw=[x for x in events if x['kind']=='imu' and begin<=x['sample_ns']<=end]
 times=np.array([x['sample_ns'] for x in raw]);assert np.all(np.diff(times)==4000000)
 acceleration=np.array([Rotation.from_quat(bytime[x['sample_ns']]['quaternion_xyzw']).apply(x['accel_flu'])+[0,0,-9.81] for x in raw])
 dv=np.array(bytime[int(times[-1])]['velocity_world'])-bytime[int(times[0])]['velocity_world']
 err=float(np.linalg.norm(np.sum((acceleration[1:]+acceleration[:-1])*.5*np.diff(times)[:,None]*1e-9,axis=0)-dv))
 raw_windows.append(dict(name=name,start_ns=int(times[0]),end_ns=int(times[-1]),error_m_s=err,child=phase_closures(derived,begin,end)))
assert raw_windows[0]['error_m_s']<.02 and raw_windows[1]['error_m_s']<.05
ulogs=[]
for m in r['px4_ulogs']:
 path=p/m['path'];assert hashlib.sha256(path.read_bytes()).hexdigest()==m['sha256']
 arming=ULog(str(path)).get_dataset('vehicle_status').data['arming_state'];assert len(arming) and np.all(arming==1)
 ulogs.append(dict(m,arming_records=len(arming),arming_values=[1]))
supervisor=json.loads((p/'supervisor.json').read_text());journal=[json.loads(x) for x in (base/'capture-v1.supervisor-events.jsonl').read_text().splitlines()]
assert journal==supervisor['cleanup']['events'];cleanup=supervisor['cleanup']
assert cleanup['no_executing_members'] and cleanup['group_absent'] and not cleanup['sigkill_dispatched'] and not cleanup['errors']
assert not any(x['event'].startswith('signal') for x in journal)
check=r['readiness']['clock_high_water_ns'];latest=r['readiness']['records'];ages={k:check-v['arrival_monotonic_ns'] for k,v in latest.items()}
assert ages['heartbeat']>2000000000 and all(v<2000000000 for k,v in ages.items() if k!='heartbeat')
new_hb=[x for x in events if x['kind']=='heartbeat'][-1];assert new_hb['arrival_monotonic_ns']<check<new_hb['recorded_monotonic_ns']
public=[x for x in states if x['public_initialized']];internal=[x for x in states if x['internal_initialized']]
cameraacks=[x for x in acks if x['kind']=='C'];rgb={x['sample_ns']:x for x in events if x['kind']=='rgb'}
latencies=[(x['end_ns']-rgb[x['sample_ns']]['arrival_monotonic_ns'])/1e6 for x in cameraacks]
out=dict(capture_status=r['status'],end_sim_ns=r['end_sim_ns'],counts=counts,producer_immutable=True,manifest_entries=len(before),
 fresh_cycles=len(fresh),last_force_ns=commands[-1]['sim_ns'],first_rejected_pre_ns=r['motion']['last_ns'],anchor_ns=anchor,
 committed=len(committed),partial_deliveries=1,refusals=len(refusals),native_acks=len(acks),native_images=len(states),
 fast_targets=len(fast),fast_success=sum(x['success'] for x in fast),internal_count=len(internal),public_count=len(public),
 first_internal_sample_ns=internal[0]['sample_ns'],first_public_sample_ns=public[0]['sample_ns'],initializer_reference_s=internal[0]['initializer_time_s'],
 prospective_origin_available=False,accuracy_qualified=False,accuracy_reason='missing pre-anchor internal state and incomplete25s capture',
 exploratory_norm_only=dict(origin_ns=ts,terminal_m=lower[-1]['norm_difference_m'],maximum_m=max(x['norm_difference_m'] for x in lower),not_qualification=True),
 raw_windows=raw_windows,callback_to_native_end_ms_p95=float(np.percentile(latencies,95)),not_full_policy_latency=True,
 readiness_at_failure=dict(check_wall_ns=check,ages_ns=ages,new_heartbeat=new_hb,new_heartbeat_age_ns=check-new_hb['arrival_monotonic_ns']),
 cleanup=cleanup,ulogs=ulogs,eligible_for_px4_fusion=False,quality=None,reset_counter=None,covariance_calibrated=False)
(base/'audit.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items() if k not in ['cleanup','raw_windows','readiness_at_failure']},indent=2))
