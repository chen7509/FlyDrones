import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import zipfile

root = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(root), str(root / 'src')]
from tools.benchmark.capture_disarmed_sensors import active_resources
from tools.benchmark.readiness_anchor import anchored_profile as profile
from tools.benchmark.openvins_online_shadow import validate_frozen_config
from tools.benchmark.native_reference_probe import load_module

out = Path(__file__).resolve().parent
assert active_resources() == []
assert len(sys.argv) == 2 and len(sys.argv[1]) == 40
px4 = Path('/home/yuchen7509/PX4-Autopilot')
paths = list((root / 'tools/benchmark').glob('*.py')) + list((root / 'tools/benchmark').glob('*.cc'))
build_reference = json.loads((root / 'results/native-reference-probe-dev-1701/production-build/build.json').read_text())
assert build_reference['binary_sha256'] == '303b575e29d44bf50850ad03e3d3b865207a225e366418ec5733ed5292cc18ce'
assert hashlib.sha256(Path(build_reference['binary']).read_bytes()).hexdigest() == build_reference['binary_sha256']
paths += [Path(build_reference['binary'])]
paths += list((root / 'src/flydrones/benchmark').glob('*.py'))
paths += list((root / 'assets/gazebo/models').glob('*/model.sdf'))
paths += [px4 / 'Tools/simulation/gz/models/x500_base/model.sdf', px4 / 'build/px4_sitl_default/bin/px4', px4 / 'Tools/simulation/gz/models/x500/model.sdf']
for pattern in ['libgz-physics*.so*', 'libdart*.so*', 'gz-physics-7/engine-plugins/*.so*']:
    paths += list(Path('/usr/lib/x86_64-linux-gnu').glob(pattern))

archive=root/'evidence/openvins-online-shadow-dev-1701.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='8aab46377da3016b9cdc4e595fbaf8316383a3b75cbe5e36505545e0434c30fa'
prior=root/'results/openvins-online-shadow-dev-1701'
config=out/'raw-model-zero-bias-diffusion-v1'
config.mkdir(exist_ok=False)
with zipfile.ZipFile(archive) as z:
    prefix='results/openvins-online-shadow-dev-1701/'
    for name in ['estimator_config.yaml','kalibr_imu_chain.yaml','kalibr_imucam_chain.yaml','freeze.json']:
        data=z.read(prefix+'raw-model-zero-bias-diffusion-v1/'+name)
        assert data==(prior/'raw-model-zero-bias-diffusion-v1'/name).read_bytes()
        (config/name).write_bytes(data)
    assert z.read(prefix+'online_probe')==(prior/'online_probe').read_bytes()
validate_frozen_config(config/'estimator_config.yaml')
module=load_module(Path(build_reference['binary']),build_reference['binary_sha256'])
assert module.API_VERSION == 1 and module.TESTING is False
ldd=subprocess.run(['ldd',str(prior/'online_probe')],capture_output=True,text=True,check=True)
(out/'ldd.txt').write_text(ldd.stdout)
assert 'not found' not in ldd.stdout
libs=[]
for line in ldd.stdout.splitlines():
    for word in line.split():
        if word.startswith('/') and Path(word).is_file(): libs.append(Path(word))
paths += libs + list(config.glob('*')) + [prior/'online_probe']
paths += list((root/'tools/benchmark').glob('*.cpp')) + list((root/'tools/benchmark').glob('*.h'))
paths += [root/'docs/superpowers/specs/2026-10-06-supported-online-vio.md', Path(__file__)]

paths = sorted(set(p.resolve() for p in paths if p.is_file()))
def snapshot(name):
    dest = out / name
    dest.mkdir(exist_ok=False)
    hashes = []
    for n, p in enumerate(paths):
        data = p.read_bytes()
        hashes.append(dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
        if p.suffix in ['.py', '.sdf', '.cc', '.cpp', '.h', '.yaml', '.json', '.md']:
            (dest / (str(n) + '-' + p.name)).write_bytes(data)
    (dest / 'manifest.json').write_text(json.dumps(hashes, indent=2))
    return hashes
packages = subprocess.run(['dpkg-query', '-W', '-f=${Package}\t${Version}\n', '*gz-physics*', '*dart*', '*gz-sim*'], capture_output=True, text=True)
with (out / 'installed-packages.txt').open('x') as f:
    f.write(packages.stdout + packages.stderr)
with (out / 'prospective-profile.json').open('x') as f:
    json.dump(dict(name='supported-ready-shadow-v1', expected_capture_status='completed', sim_deadline_ns=8000000000, wall_budget_s=60, supervisor_s=90, motion=profile(), reference_binary_sha256=build_reference['binary_sha256'], estimator_run=True, performance_comparison=False, frozen_wall_ns=time.time_ns(), producer_commit=sys.argv[1]), f, indent=2)
before = snapshot('producer-before')
command = [sys.executable, str(root / 'tools/benchmark/capture_disarmed_sensors.py'), '--output', str(out / 'capture-v1'), '--motion-profile', 'supported-ready-v1', '--physics-trace-profile', 'substep-ready-v1', '--reference-module', build_reference['binary'], '--reference-sha256', build_reference['binary_sha256'], '--source-fanout-profile', 'ready-shadow-v1', '--shadow-binary', str(prior/'online_probe'), '--shadow-config', str(config/'estimator_config.yaml')]
with (out / 'launch.json').open('x') as f:
    json.dump(dict(command=command, wall_ns=time.time_ns(), resources=active_resources()), f, indent=2)
with (out / 'capture-v1-console.txt').open('x') as log:
    done = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
after = snapshot('producer-after')
result = dict(exit=done.returncode, unchanged=before == after, resources=active_resources(), wall_ns=time.time_ns())
with (out / 'exit.json').open('x') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
