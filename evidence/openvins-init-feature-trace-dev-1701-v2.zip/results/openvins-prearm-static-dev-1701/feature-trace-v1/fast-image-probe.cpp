#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/features2d.hpp>
#include <iostream>

int main(int argc, char** argv) {
  if (argc < 2) return 2;
  for (int i = 1; i < argc; ++i) {
    auto rgb = cv::imread(argv[i], cv::IMREAD_COLOR);
    if (rgb.empty()) return 3;
    cv::Mat gray, equalized;
    cv::cvtColor(rgb, gray, cv::COLOR_BGR2GRAY);
    cv::equalizeHist(gray, equalized);
    std::vector<cv::KeyPoint> raw, eq;
    cv::FAST(gray, raw, 20, true);
    cv::FAST(equalized, eq, 20, true);
    std::cout << argv[i] << " fast20_raw=" << raw.size()
              << " fast20_equalized=" << eq.size() << '\n';
  }
}
