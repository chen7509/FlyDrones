"""Preserve v1 and seal the stricter audited parser alongside the same raw replay."""

import hashlib
import json
import zipfile
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


root = Path(__file__).resolve().parents[2]
trace = root / 'results/openvins-prearm-static-dev-1701/feature-trace-v1'
archive = root / 'evidence/openvins-init-feature-trace-dev-1701-v2.zip'
index = archive.with_suffix('.index.json')
if archive.exists() or index.exists():
    raise SystemExit('reviewed archive exists; refusing overwrite')

parser = root / 'tools/benchmark/audit_openvins_init_feature_trace.py'
tests = root / 'tests/benchmark/test_openvins_init_feature_trace.py'
v1 = root / 'evidence/openvins-init-feature-trace-dev-1701.zip'
manifest = {
    'schema': 'flydrones-openvins-init-feature-evidence-v2',
    'relationship': 'Same single replay as v1; parser rejects malformed diagnostic rows.',
    'archive_v1_sha256': sha(v1.read_bytes()),
    'parser_sha256': sha(parser.read_bytes()),
    'tests_sha256': sha(tests.read_bytes()),
    'trace_files_sha256': {
        str(path.relative_to(trace)).replace('\\', '/'): sha(path.read_bytes())
        for path in sorted(trace.rglob('*')) if path.is_file()
    },
}
manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
with archive.open('xb') as stream, zipfile.ZipFile(stream, 'w', zipfile.ZIP_DEFLATED) as zipped:
    for path in sorted(trace.rglob('*')):
        if path.is_file():
            zipped.write(path, str(path.relative_to(root)).replace('\\', '/'))
    zipped.write(parser, str(parser.relative_to(root)).replace('\\', '/'))
    zipped.write(tests, str(tests.relative_to(root)).replace('\\', '/'))
    zipped.write(Path(__file__), str(Path(__file__).relative_to(root)).replace('\\', '/'))
    zipped.writestr('feature-trace-review-v2.json', manifest_bytes)
with zipfile.ZipFile(archive) as zipped:
    if zipped.testzip() is not None:
        raise RuntimeError('archive CRC failure')
    members = len(zipped.namelist())
index.write_text(json.dumps({
    'schema': 'flydrones-evidence-archive-v1',
    'archive_sha256': sha(archive.read_bytes()),
    'archive_size': archive.stat().st_size,
    'members': members,
}, indent=2) + '\n', encoding='utf-8')
print(index.read_text(encoding='utf-8'))
