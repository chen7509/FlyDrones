# Self-review

- Scope stays design/offline only: no socket, parameter change, simulator, estimator, training, arming or multi-aircraft process was started.
- The design treats the health contract as the only quality/reset authority and calls out the historical ShadowSession mismatch.
- The 15x15 velocity is global; the BODY_FRD Jacobian includes orientation coupling and is explicitly left for RED/GREEN finite-difference verification.
- The review-corrected timing distinguishes the 200 ms continuity interval from the roughly 400 ms active-fusion stop timeout.
- ODOMETRY and TIMESYNC share one remote monotonic clock; lockstep simulation time is not mixed with host wall time.
- EV and IMU reference positions are both bound; a zero lever arm is not assumed without baseline evidence.
- Adapter faults are blocked before transmission; the pinned receiver is not credited with checks it does not perform.
- A 10 Hz public camera stream is not claimed to meet the future 30-50 Hz fusion gate; repeated frames are prohibited.
- Truth remains offline-only. Quality 0/-1 never becomes a network candidate.
- Parameter mutation, receiver injection, EKF2 fusion and closed loop each require a later gate and separate authorization.
- Hardware/HITL/flight calibration and the 0.873 RTF five-camera failure remain open.
