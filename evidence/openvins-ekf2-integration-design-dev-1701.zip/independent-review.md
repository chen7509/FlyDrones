# Independent review

No Critical findings. Four Important findings were corrected before publication:

1. Separated the 200 ms EV continuity/start interval from the roughly 400 ms active-fusion stop timeout in pinned PX4.
2. Added `EKF2_IMU_POS_X/Y/Z` to the future parameter snapshot and required the EV reference point to equal the IMU reference point.
3. Required ODOMETRY and TIMESYNC to share one explicit remote monotonic clock, with a frozen lockstep simulation transform, new clock session after pause/jump/restart, and a pre-study 500-sample convergence budget.
4. Moved duplicate/reorder/bad-covariance rejection explicitly upstream of MAVLink. The pinned receiver is not claimed to reject those malformed inputs; any wire-level diagnostic must retain its actual publication behavior.

The reviewer confirmed the stated JPL/Hamilton direction and `J[v,theta]=[v_BODY_FRD]x` sign are consistent with the pinned OpenVINS error convention.
