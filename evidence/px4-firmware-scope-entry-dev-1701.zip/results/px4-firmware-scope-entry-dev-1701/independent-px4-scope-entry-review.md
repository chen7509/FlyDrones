# Independent PX4 firmware scope entry v2 source review

Reviewed base HEAD: `39e78c19313ce42ece44e1cb891222e6e85a507d`; new v2 files are uncommitted. This is the single whole-source review required by `superpowers:requesting-code-review`, performed by one reviewer in source passes. No second reviewer or subagent was dispatched.

Scope: all eleven exact files in `review-source-map.json`, using the frozen `review-source/` copies and comparing each with live byte count/SHA-256. All eleven matched at the initial check and again before report creation. The JSON companion includes every exact source pin. The full v2 and inherited v1 lifecycle, source auditor, profiles, primitive entry, tests, process boundary, recorder, spec and plan were examined. This review does not execute or import production code.

## Strengths

- Primitive entry imports only os/sys, rejects pytest/invalid Linux interpreter context before reads, fixes cwd/owner/nonroot matching UID and absolute make argv/environment.
- Virtual reads are capped while reading with no-follow/nonblocking/close-on-exec flags, propagate failures, preserve primary read errors when close also fails, and repeat current UID/PID/cgroup/limits before exec.
- Fresh literal nonce unit, current user's systemd subtree, own PID membership and actual memory/swap/CPU/pids limits are checked without claiming pre-make InvocationID authentication.
- Entry SHA256 pins occur before dispatch/output and immediately before launch, and are checked afterward; changed/unknown post bytes prevent main success.
- Original fixed WSL source/result, dual admissions, dual4GiB/15GiB thresholds, no competition, make-j1 and nominal5400 inner/outer settings remain in v2; v1 bytes match the frozen pin.
- Tests use inert OS/read/exec and dispatch protocols under an autouse process boundary; exact recorded stdout/stderr and all17 retained fixture payload pins match.
- Inherited external InvocationID/stop checks remain conservative and report uncertain cleanup and all-descendant proof honestly.

Relevant implementation references: primitive `tools/connectome/px4_firmware_scope_entry_v2.py:10,32,69,99`; v2 command `tools/connectome/run_px4_status_firmware_build_v2.py:281`; pins `:550,572,608,619,731`; final success predicate `:969`; inert test boundary `tests/connectome_training/test_px4_firmware_scope_entry_v2.py:15`.

## Critical (must fix): 0

None identified.

## Important (should fix): 1

### I1: Preserve the original Windows consumption guard across v1 and v2

File: `tools/connectome/run_px4_status_firmware_build_v2.py:551` (also lines 42, 559, 573, 609, 950).

The new dispatcher checks only BUILD_EVIDENCE_DIR ending in -v2. The immutable v1 dispatcher consumes its Windows -v1 directory before attempting WSL mkdir. If that mkdir fails or execution ends after Windows evidence creation, the original WSL result path remains absent. V2 then passes both its own directory check and the WSL checks and can consume another attempt. Retaining status-build-v1 is sufficient for a retained prior launch marker, because both versions create it before Popen, but is insufficient for the explicitly conservative evidence-only consumption case.

Effect: A version change reopens the original one-shot slot after a prior v1 consumption, contrary to the stated original-attempt continuity. No prior native attempt was observed or queried in this review; this is a source-proven reachable case.

Fix: Have v2 recognize the original v1 Windows evidence directory, including an existing path entry or symlink, as consumed before admission probes or new output. Use an original/shared durable consumption guard if multiple versions remain callable; preserve immutable v1 source and historical evidence. Add an inert test with only the original evidence marker present and WSL result absent that proves refusal before any query/output/launch.

## Minor (nice to have): 2

### M1: Apply the stderr read bound before allocating the whole log

File: `tools/connectome/run_px4_status_firmware_build_v2.py:538` (also lines 539, 544, 675).

_recorded_launcher_invocation_id calls path.read_bytes() before checking the 1 MiB cap and before inspecting only the first 4096 bytes. The fallback is used during final cleanup when an active scope has no sampled InvocationID. An arbitrarily large retained compiler stderr file is therefore fully allocated in the Windows parent, outside the WSL scope memory cap.

Effect and grading: This is a latent host memory/cleanup reliability cost. MemoryError is not caught by the enclosing cleanup handler and can skip stop and final evidence persistence. The selected grade reflects that the trigger additionally requires the unbound-ID fallback and a large log; it is not excused as inherited code. It does not establish an observed OOM or an unbounded normal compiler run.

Fix: Read at most 1 MiB plus one byte, or otherwise combine a bounded prefix read with a fail-closed length check, retaining the existing oversize/duplicate refusal policy. Add an inert reader test which rejects attempts at an unbounded read.

### M2: Make host monitoring calls respect the remaining outer deadline

File: `tools/connectome/run_px4_status_firmware_build_v2.py:640` (also lines 424, 635, 636, 656, 666, 745, 751).

The elapsed >= 5400 check runs only at the beginning of a polling iteration. The next _show_build_unit plus up to six sequential _read_cgroup _wsl calls each receive an independent 30-second timeout, followed by a 1/5-second sleep. No remaining-time budget is passed to them. The host monitoring path can consequently exceed the nominal 5400-second outer deadline before it reaches its next check; the added swap/tasks reads increase this polling latency.

Effect and grading: This violates a literal hard outer 5400-second deadline and delays host abort/cleanup. The inner GNU timeout normally continues to bound the compiler separately, so this is graded Minor for the additional host monitoring latency rather than asserted unbounded compiler execution. If the executor treats 5400 as a hard end-to-end host contract rather than a polling threshold plus bounded cleanup, upgrade this finding and fix it before proceeding. The fact that the pattern is inherited does not remove it from review.

Fix: Use a monotonic deadline and pass the remaining budget into each monitoring subprocess; recheck between observations and cap sleeps by remaining time. Keep cleanup with its separately explicit bounded allowance. Add inert clock/process protocols proving no subsequent monitor call or full sleep starts after the deadline.

## Recorded verification and limits

`before-review.stdout` records **40 passed in 0.35s**. Its SHA-256 is `af083c5c02d2745da6738c4295ea6ab65aa49fb76b51e66335d14cee4c3ff315`; the empty stderr hash is `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`. The recorder reports exit 0, no exception and unchanged before/after pins for the reviewed production/test sources. All 17 retained fixture payload byte pins in `before-review-fixtures.json` matched their current files.

These are recorded results, not a reviewer rerun. Tests exercise entry success/refusal, second-snapshot drift, IO failure/oversize/close behavior, byte drift, actual v2 dispatch routing, swap/tasks admission/runtime checks and cold primitive definition/direct-main refusal through inert protocols. They do not currently cover the cross-version consumption case I1 or the bounded-read/deadline conditions M1/M2. No native/resource/process/Docker/WSL/SDK/physics query, test rerun or imported production execution occurred. Only the two newly exclusive review report files were written.

## Declined judgments (one per line; executor must rule on every line)

Each proposed rule below needs an explicit executor accept/adjust/reject decision. These are not silent blanket exclusions. I1, M1 and M2 are assessed findings, not declined judgments.

- D1 — Actual Windows/WSL available RAM, disk space, competitors and current source/admission state. Reason: Resource/process/WSL queries are expressly prohibited in this software-only review; reading collection logic cannot establish current admission. Proposed executor rule: Keep current admission unverified; require the original two fresh native gates before any future authorized attempt. Executor ruling: pending.
- D2 — Current kernel, cgroup controller availability, user permissions and real systemd/Python/make behavior. Reason: No native run or resource query was authorized. Inert files prove software branching, not kernel permission certification. Proposed executor rule: Retain unverified status and fail-closed behavior; do not infer native readiness from this review. Executor ruling: pending.
- D3 — Systemd InvocationID binding before make. Reason: The approved design explicitly binds UID/PID/current cgroup and a nonce unit, while pre-make independent InvocationID authentication is not supplied. Proposed executor rule: Accept this declared limitation only as a software scope boundary; retain external InvocationID observation and owned cleanup as separate requirements. Executor ruling: pending.
- D4 — Hostile Python/FFI, malicious source substitution, races after the final sample, and adversarial mount/path substitution. Reason: The design explicitly excludes adversarial and race authentication; two snapshots and byte pins are observations, not an authenticated execution chain. Proposed executor rule: Preserve that limitation in published claims; a stronger authentication requirement needs a separately specified design. Executor ruling: pending.
- D5 — Complete compiler dependency/source closure and binary provenance. Reason: The source auditor and toolchain snapshot pin selected inputs; the spec explicitly does not claim every future generator, collector, dependency or native closure issue is solved. Proposed executor rule: Keep firmware_compiled_verified and live_source_authenticated false; require independent future closure/binary evidence. Executor ruling: pending.
- D6 — All escaped descendants exited after cleanup. Reason: The inherited cleanup audit explicitly returns all_descendants_proven_exited=false and certifies only the named owned scope. No live process inspection was allowed. Proposed executor rule: Accept only named-scope release evidence; never upgrade it to proof that all descendants exited. Executor ruling: pending.
- D7 — Firmware functionality, simulator/SDK/physics behavior, fusion/calibration/learning/fairness/flight readiness. Reason: No native compiler, simulator, SDK, physics or flight activity belongs to this software review. Proposed executor rule: Keep every qualification false; neither a source approval nor 40 inert tests grants native/flight qualification. Executor ruling: pending.
- D8 — Re-running or repairing the old v4 refusal, consumed-specific studies or historical native observations. Reason: The plan requires those sources and observations to remain unchanged; this review is of the new v2 and inherited runner source, not a new historical execution. Proposed executor rule: Preserve history; do not use this review as permission to rerun or overwrite consumed evidence. Executor ruling: pending.
- D9 — Native time, energy, resource contention and monetary build cost. Reason: Only static command/timeout/read costs can be assessed here; no benchmark or native resource query was permitted. Actual build cost cannot be inferred from the 0.35-second inert suite. Proposed executor rule: Keep actual native costs unknown; retain one job, the original resource gates and attempt budget. M1/M2 remain actionable static cost findings. Executor ruling: pending.
- D10 — Model/provider billing and exact review-token cost. Reason: No billing or per-review token receipt is in the frozen evidence; inventing a monetary figure would be unsupported. Proposed executor rule: Report no numeric review cost; do not treat missing cost evidence as zero cost. Executor ruling: pending.
- D11 — Relocatable checkout/WSL path mapping. Reason: This workflow deliberately pins the current fixed Windows/WSL repository and source/result paths; relocating to a different checkout is not a supported invocation in this plan. Proposed executor rule: Keep this approval restricted to the frozen fixed-path workflow; require a new explicit mapping contract for relocation. Executor ruling: pending.
- D12 — Whole-repository tests, fresh reruns and native integration tests. Reason: The task expressly forbids test reruns and imported production execution. Existing recorded focused tests and their sources were reviewed instead. Proposed executor rule: Use the recorded 40-pass result only for its exact pins; executor must perform only the subsequently authorized bounded fix verification. Executor ruling: pending.
- D13 — Delivery/publication integrity and private/draft PR/automation state. Reason: The plan assigns an independent integrity delivery/publication phase; this reviewer was restricted to source and recorded software evidence. Proposed executor rule: Require the separate delivery/publication audit; this review neither verifies nor authorizes a native attempt by itself. Executor ruling: pending.

## Assessment

**Ready to merge: With fixes.** Fix I1 before proceeding; the executor must explicitly decide M1/M2, including whether literal enforcement of the original hard outer 5400-second budget warrants an Important grade. No finding is dismissed simply because its code was inherited.

This is software-source readiness only. The primitive binds actual current UID/PID/cgroup membership and nonce unit through repeated observations; it does not independently bind systemd InvocationID before make. `build_dispatched` remains launcher-start evidence. There is **no native, firmware/binary, authenticated source, simulator, SDK, physics or flight qualification**, and this review itself grants no future native launch authorization. Existing current-admission, original one-shot protocol, external invocation/cleanup and independent delivery requirements remain necessary.

