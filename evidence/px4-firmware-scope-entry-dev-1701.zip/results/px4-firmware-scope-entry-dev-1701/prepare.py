import hashlib,json,subprocess,tomllib
from pathlib import Path
root=Path.cwd(); raw=root/'results/px4-firmware-scope-entry-dev-1701'; prior=root/'results/training-effort-production-dev-1701'
def pin(p):
 b=p.read_bytes(); return dict(path=p.relative_to(root).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
paths=['docs/TRAINING_EFFORT_PRODUCTION_REPORT.md','evidence/training-effort-production-publication.json','results/training-effort-production-dev-1701/NEXT_PHASE.md','results/training-effort-production-dev-1701/independent-training-effort-final-publication-audit.json','results/training-effort-production-dev-1701/independent-training-effort-review.md','results/training-effort-production-dev-1701/executor-fix-pass.md','docs/superpowers/specs/2026-10-16-training-effort-production-design.md','docs/superpowers/plans/2026-10-16-training-effort-production.md','docs/TARGET_BEARING_STATIC_V3_HARNESS_FAILURE_REPORT.md','docs/STATIC_V4_ADMISSION_AND_SEQUENCE_DECODE_REPORT.md','evidence/flydrones-history-through-initialized-baseline-dev-1701.json','evidence/flydrones-history-through-loader-path-research-dev-1701.json','evidence/flydrones-history-through-admitted-executor-dev-1701.json','evidence/membrane-dynamics-production-retention-correction.json','evidence/role-comparison-production-postseal-progress-correction.json','docs/superpowers/plans/2026-10-12-px4-estimator-status-firmware.md','tools/connectome/run_px4_status_firmware_build.py']
for n in paths:
 s=(root/n).read_text(encoding='utf-8-sig')
 if 'history-through' in n: assert len(json.loads(s)['prompt'])>0
names=subprocess.check_output(['git','ls-files','-z','src','tools','tests','configs']).decode().split('\0')
for n,v in [('product-before.json',[pin(root/n) for n in names if n and (root/n).is_file()]),('context-readback.json',dict(read=[pin(root/n) for n in paths],scope='Full file read; no resources/native; prior summary supplies substantive constraints'))]:
 with (raw/n).open('x') as f:json.dump(v,f,indent=2)
s=(prior/'verify.py').read_text(encoding='utf-8'); a=s.index('SOURCES='); z=s.index('def sha(b):')
sources=['tools/connectome/px4_firmware_scope_entry_v2.py','tools/connectome/run_px4_status_firmware_build_v2.py','tests/connectome_training/test_px4_firmware_scope_entry_v2.py','tools/connectome/run_px4_status_firmware_build.py','src/flydrones/connectome_training/px4_status_firmware.py','configs/px4/estimator-status-firmware-build-profile.json','configs/px4/estimator-status-firmware-profile.json','tests/connectome_training/test_px4_status_firmware_build.py','tools/benchmark/software_process_boundary.py','tests/connectome_training/conftest.py','results/px4-firmware-scope-entry-dev-1701/verify.py']
s=s[:a]+'SOURCES='+repr(sources)+'\n'+s[z:]
a=s.index('SOURCES+='); z=s.index('def save(n,v):');s=s[:a]+s[z:]
s=s.replace('tiny CPU neural software; default inert process/resource/CUDA fixture; no fullMaleCNS/SDK/resources','Inert OS/file firmware entry protocols; process boundary installed; host scientific imports from conftest possible; no resource/WSL/native target')
with (raw/'verify.py').open('x',encoding='utf-8') as f:f.write(s)
with (raw/'progress.md').open('x') as f:f.write('# PX4 firmware scope entry v2 software phase\n\nBASE39e78c19313ce42ece44e1cb891222e6e85a507d. New primitive pre-make scope verification and production v2 route; original firmware slot, original v1 immutable. No native/resource/process/Docker/WSL query or old consumed rerun. Goal blocked read-only. Standing autonomy authorizes inline plan; no step approval.\n')
b=Path('C:/Users/yuche/.codex/automations/flydrones/automation.toml').read_bytes(); (raw/'automation-before.toml').write_bytes(b); prompt=tomllib.loads(b.decode())['prompt'];(raw/'previous-automation-prompt.txt').write_bytes(prompt.encode())
(raw/'previous-pr-body.md').write_bytes((prior/'pr-body.md').read_bytes())
print(json.dumps(dict(products=sum(bool(n) for n in names),context=len(paths),prompt_chars=len(prompt))))
