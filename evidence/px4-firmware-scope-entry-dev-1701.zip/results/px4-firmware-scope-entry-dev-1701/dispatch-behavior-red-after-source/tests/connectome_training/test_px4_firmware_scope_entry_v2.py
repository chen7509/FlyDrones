import importlib
from types import SimpleNamespace

import pytest

from tools.benchmark.software_process_boundary import install

UNIT = "flydrones-px4-status-build-v1-" + "a" * 24 + ".scope"
CG = "/user.slice/user-1000.slice/user@1000.service/app.slice/" + UNIT
ROOT = "/home/yuchen7509/px4-status-worktrees/firmware-v1"


@pytest.fixture(autouse=True)
def inert_children(monkeypatch):
    install(monkeypatch)


def entry():
    return importlib.import_module("tools.connectome.px4_firmware_scope_entry_v2")


def runner():
    return importlib.import_module("tools.connectome.run_px4_status_firmware_build_v2")


class ReachedExec(BaseException):
    pass


def protocol(monkeypatch):
    module = entry()
    events = []
    files = {
        "/proc/self/cgroup": ("0::" + CG + "\n").encode(),
        "/sys/fs/cgroup" + CG + "/memory.max": b"4294967296\n",
        "/sys/fs/cgroup" + CG + "/memory.swap.max": b"0\n",
        "/sys/fs/cgroup" + CG + "/cpu.max": b"100000 100000\n",
        "/sys/fs/cgroup" + CG + "/pids.max": b"256\n",
        "/sys/fs/cgroup" + CG + "/cgroup.procs": b"73\n74\n",
    }
    fds = {}
    def op(path, flags):
        events.append(("open", path, flags))
        fd = len(fds) + 10
        fds[fd] = [files[path], 0]
        return fd
    def read(fd, n):
        data, at = fds[fd]
        part = data[at:at + n]
        fds[fd][1] += len(part)
        return part
    def execute(path, argv, env):
        events.append(("exec", path, argv, env))
        raise ReachedExec
    fake = SimpleNamespace(name="posix", environ={}, O_RDONLY=0, O_CLOEXEC=1, O_NOFOLLOW=2, O_NONBLOCK=4,
        open=op, read=read, close=lambda fd: events.append(("close", fd)),
        getcwd=lambda: ROOT, getuid=lambda: 1000, geteuid=lambda: 1000, getpid=lambda: 73,
        stat=lambda path: SimpleNamespace(st_uid=1000), execve=execute)
    fake_sys = SimpleNamespace(platform="linux", argv=["entry", "--unit", UNIT], modules={},
        flags=SimpleNamespace(isolated=1, no_site=1, dont_write_bytecode=1, optimize=0))
    monkeypatch.setattr(module, "os", fake)
    monkeypatch.setattr(module, "sys", fake_sys)
    return module, fake, fake_sys, files, events


def test_actual_dispatch_command_routes_through_entry_and_declares_zero_swap_tasks():
    module = runner()
    argv = module.build_scope_command()
    assert "--property=MemorySwapMax=0" in argv
    assert "--property=TasksMax=256" in argv
    at = argv.index("/usr/bin/python3")
    assert argv[at:] == ["/usr/bin/python3", "-I", "-S", "-B", module.SCOPE_ENTRY_WSL, "--unit", module.BUILD_SCOPE_UNIT]
    assert "--property=MemoryMax=4G" in argv and "--property=CPUQuota=100%" in argv
    assert "5400s" in argv and argv.index("5400s") < at
    assert "/usr/bin/make" not in argv
    assert module.BUILD_RESULT_PATH == "/home/yuchen7509/px4-status-worktrees/status-build-v1"


def test_valid_actual_scope_protocol_reaches_only_fixed_make_with_clean_environment(monkeypatch):
    module, fake, _, _, events = protocol(monkeypatch)
    fake.environ["LD_PRELOAD"] = "untrusted"
    with pytest.raises(ReachedExec):
        module.enter()
    executed = [e for e in events if e[0] == "exec"]
    assert len(executed) == 1
    _, path, argv, env = executed[0]
    assert path == "/usr/bin/make" and argv == [path, "-j1", "px4_sitl_default"]
    assert env["MAKEFLAGS"] == "-j1" and env["GIT_CONFIG_VALUE_0"] == "never"
    assert "LD_PRELOAD" not in env
    assert sum(e[:2] == ("open", "/proc/self/cgroup") for e in events) == 2


@pytest.mark.parametrize("name,value", [("memory.max", b"max\n"), ("memory.swap.max", b"1\n"),
    ("cpu.max", b"max 100000\n"), ("pids.max", b"max\n"), ("cgroup.procs", b"74\n")])
def test_wrong_actual_scope_limit_or_membership_never_executes(monkeypatch, name, value):
    module, _, _, files, events = protocol(monkeypatch)
    files["/sys/fs/cgroup" + CG + "/" + name] = value
    with pytest.raises((ValueError, RuntimeError)):
        module.enter()
    assert not any(e[0] == "exec" for e in events)


@pytest.mark.parametrize("change", ["pytest", "flags", "cwd", "uid", "owner", "unit", "platform"])
def test_invalid_entry_context_rejected_before_exec(monkeypatch, change):
    module, fake, sy, _, events = protocol(monkeypatch)
    if change == "pytest": sy.modules["pytest"] = object()
    elif change == "flags": sy.flags.isolated = 0
    elif change == "cwd": fake.getcwd = lambda: "/tmp"
    elif change == "uid": fake.geteuid = lambda: 0
    elif change == "owner": fake.stat = lambda path: SimpleNamespace(st_uid=0)
    elif change == "unit": sy.argv[-1] = "other.scope"
    elif change == "platform": sy.platform = "win32"
    with pytest.raises((ValueError, RuntimeError)):
        module.enter()
    assert not any(e[0] == "exec" for e in events)
    if change in ("pytest", "flags", "unit", "platform"):
        assert not events
