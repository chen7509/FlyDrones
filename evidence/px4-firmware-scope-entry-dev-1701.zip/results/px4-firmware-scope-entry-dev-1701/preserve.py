import hashlib,json
from pathlib import Path
root=Path.cwd();raw=root/'results/px4-firmware-scope-entry-dev-1701';prior=root/'results/training-effort-production-dev-1701'
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes().decode('utf-8-sig'))
def save(n,v):
 with (raw/n).open('xb') as f:f.write(json.dumps(v,indent=2).encode())
old=load(prior/'historical-archives-postsoftware.json')['members']+[dict(path='evidence/training-effort-production-dev-1701.zip',bytes=2764703,sha256='58d177c518f870ad3a3af353d5ed1b3d496a7576b64f76da170a7254e7e0c470')]
assert len(old)==304 and {r['path'] for r in old}=={p.relative_to(root).as_posix() for p in (root/'evidence').glob('*.zip')}
for row in old:
 h=hashlib.sha256();n=0
 with (root/row['path']).open('rb') as f:
  while block:=f.read(1048576):h.update(block);n+=len(block)
 assert n==row['bytes'] and h.hexdigest()==row['sha256']
save('historical-archives-postsoftware.json',dict(members=old,count=len(old),bytes=sum(r['bytes'] for r in old),scope='Fullstream POSTsoftware preservation only,not native prepins'))
before=load(raw/'product-before.json');changed=[r['path'] for r in before if sha((root/r['path']).read_bytes())!=r['sha256']];assert not changed
save('product-preservation-postsoftware.json',dict(count=len(before),changed=changed,new_product=['tools/connectome/px4_firmware_scope_entry_v2.py','tools/connectome/run_px4_status_firmware_build_v2.py','tests/connectome_training/test_px4_firmware_scope_entry_v2.py'],all_old_product_byte_same=True,all_consumed_version_sources_byte_same=True))
p=load(prior/'refused-attempt-preservation.json');parent=root/'results/target-bearing-runtime-freeze-v4-dev-1701'
for row in p['private_excluded']:
 b=(root/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
assert set(q.name for q in parent.iterdir())=={'run-static-preparation-v4.py','firstfacts.json','completion.json',*[Path(r['path']).name for r in p['private_excluded']]}
assert load(parent/'completion.json')['state']=='REFUSED_UNCONSUMED' and not load(parent/'completion.json')['consumed']
sources=load(root/'results/static-v4-attempt-dev-1701/preflight.json')['sources'];assert len(sources)==382 and sources==load(root/'results/static-v4-attempt-dev-1701/cli-completion.json')['source_after']
for row in sources:assert sha((root/'results/static-v4-attempt-dev-1701/source-before'/row['path']).read_bytes())==row['sha256']
evolved=[r['path'] for r in sources if sha((root/r['path']).read_bytes())!=r['sha256']];assert evolved==p['current_source_evolved']
assert sha((root/'evidence/static-v4-executor-completion-release.frame').read_bytes())==p['release_sha256']
for row in p['histories']:assert sha((root/row['path']).read_bytes())==row['sha256']
p.update(current_phase_changed_outside_original382=[],current_phase_new_source=['tools/connectome/px4_firmware_scope_entry_v2.py','tools/connectome/run_px4_status_firmware_build_v2.py','tests/connectome_training/test_px4_firmware_scope_entry_v2.py'],current_source_evolved=evolved,scope='Software pre-make scope entry only;original382six evolvedset remains;oldrelease stale;no resource/native actions')
save('refused-attempt-preservation.json',p)
print(json.dumps(dict(old_archives=len(old),archive_bytes=sum(r['bytes'] for r in old),old_products=len(before),changed=changed)))
