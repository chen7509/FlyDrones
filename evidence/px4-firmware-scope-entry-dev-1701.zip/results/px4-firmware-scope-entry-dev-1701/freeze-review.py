import hashlib,json
from pathlib import Path
root=Path.cwd();raw=root/'results/px4-firmware-scope-entry-dev-1701'
names=['tools/connectome/px4_firmware_scope_entry_v2.py','tools/connectome/run_px4_status_firmware_build_v2.py','tests/connectome_training/test_px4_firmware_scope_entry_v2.py','tools/connectome/run_px4_status_firmware_build.py','src/flydrones/connectome_training/px4_status_firmware.py','configs/px4/estimator-status-firmware-build-profile.json','configs/px4/estimator-status-firmware-profile.json','tools/benchmark/software_process_boundary.py','results/px4-firmware-scope-entry-dev-1701/verify.py','docs/superpowers/specs/2026-10-16-px4-firmware-scope-entry-design.md','docs/superpowers/plans/2026-10-16-px4-firmware-scope-entry.md']
rows=[]
for n in names:
 b=(root/n).read_bytes();rows.append(dict(path=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()));p=raw/'review-source'/n;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(b)
with (raw/'review-source-map.json').open('x') as f:json.dump(rows,f,indent=2)
print(json.dumps(dict(pins=len(rows))))
