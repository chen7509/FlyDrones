from pathlib import Path
import hashlib,re
entry=Path('tools/connectome/px4_firmware_scope_entry_v2.py')
p=Path('tools/connectome/run_px4_status_firmware_build_v2.py');s=p.read_text(encoding='utf-8');s=re.sub(r'SCOPE_ENTRY_SHA256 = "[a-f0-9]+"','SCOPE_ENTRY_SHA256 = "'+hashlib.sha256(entry.read_bytes()).hexdigest()+'"',s);p.write_text(s,encoding='utf-8')
