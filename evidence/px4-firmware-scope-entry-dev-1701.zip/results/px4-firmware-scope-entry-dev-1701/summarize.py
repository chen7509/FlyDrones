import hashlib,json
from pathlib import Path
root=Path.cwd();raw=root/'results/px4-firmware-scope-entry-dev-1701';sha=lambda b:hashlib.sha256(b).hexdigest()
review=json.loads((raw/'independent-px4-scope-entry-review.json').read_bytes());print(json.dumps(list(review.keys())))
records=[]
for p in sorted(raw.glob('*-fixtures.json')):
 x=json.loads(p.read_bytes());label=p.name[:-14]; rows=x['retained_payload']; records.append(dict(label=label,regular=sum('sha256' in r for r in rows),bytes=sum(r.get('bytes',0) for r in rows)))
print(json.dumps(dict(inventories=len(records),regular=sum(r['regular'] for r in records),bytes=sum(r['bytes'] for r in records))))
rows=json.loads((raw/'review-source-map.json').read_bytes());delta=[]
for row in rows:
 b=(root/row['path']).read_bytes()
 if sha(b)!=row['sha256']:delta.append(dict(path=row['path'],review_sha256=row['sha256'],final_sha256=sha(b),bytes=len(b)))
assert {r['path'] for r in delta}=={'tools/connectome/run_px4_status_firmware_build_v2.py','tests/connectome_training/test_px4_firmware_scope_entry_v2.py'}
with (raw/'review-fix-delta.json').open('x') as f:json.dump(dict(changed=delta,other_nine_review_files_byte_identical=True,original_review_unchanged=True,scope='One bounded executor fix;not second source review'),f,indent=2)
