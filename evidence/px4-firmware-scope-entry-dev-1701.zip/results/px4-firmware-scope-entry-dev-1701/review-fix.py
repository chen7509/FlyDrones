from pathlib import Path
p=Path('tools/connectome/run_px4_status_firmware_build_v2.py');s=p.read_text(encoding='utf-8')
s=s.replace('BUILD_EVIDENCE_DIR = ROOT / "results/px4-status-firmware-build-dev-1701-v2"','BUILD_EVIDENCE_DIR = ROOT / "results/px4-status-firmware-build-dev-1701-v2"\nLEGACY_BUILD_EVIDENCE_DIR = ROOT / "results/px4-status-firmware-build-dev-1701-v1"')
a=s.index('\ndef _integer_at_least');s=s[:a]+'\ndef _require_unused_build_evidence() -> None:\n    for path in (LEGACY_BUILD_EVIDENCE_DIR, BUILD_EVIDENCE_DIR):\n        if path.exists() or path.is_symlink():\n            raise FileExistsError("original one-shot firmware evidence already consumed")\n\n'+s[a:]
s=s.replace('    collect = collect or collect_admission_facts','    _require_unused_build_evidence()\n    _pin_entry()\n    collect = collect or collect_admission_facts')
s=s.replace('def _show_build_unit() -> dict[str, str]:','def _show_build_unit(*, deadline: float | None = None) -> dict[str, str]:')
s=s.replace('"--property=LoadState,ActiveState,ControlGroup,Result,InvocationID",\n    ).stdout','"--property=LoadState,ActiveState,ControlGroup,Result,InvocationID",\n        deadline=deadline,\n    ).stdout')
s=s.replace('def _read_cgroup(group: str) -> dict:','def _read_cgroup(group: str, *, deadline: float | None = None) -> dict:')
a=s.index('def _read_cgroup(');z=s.index('\ndef _write_exclusive',a);section=s[a:z]
for name in ['cgroup.procs','memory.max','cpu.max','memory.swap.max','pids.max','memory.peak']:
 section=section.replace('root + "/'+name+'")','root + "/'+name+'", deadline=deadline)')
s=s[:a]+section+s[z:]
s=s.replace('    data = path.read_bytes()\n    if len(data) > 1024 * 1024:', '    with path.open("rb") as stream:\n        data = stream.read(1024 * 1024 + 1)\n    if len(data) > 1024 * 1024:')
s=s.replace('    if BUILD_EVIDENCE_DIR.exists():\n        raise FileExistsError("one-shot build evidence directory already exists")','    _require_unused_build_evidence()')
s=s.replace('                process = subprocess.Popen(build_scope_command(), stdout=stdout, stderr=stderr)','                started = time.monotonic()\n                deadline = started + TIMEOUT_SECONDS\n                process = subprocess.Popen(build_scope_command(), stdout=stdout, stderr=stderr)')
s=s.replace('                started = time.monotonic()\n                _write_exclusive', '                _write_exclusive')
s=s.replace('                        state = _show_build_unit()','                        state = _show_build_unit(deadline=deadline)')
s=s.replace('cgroup = _read_cgroup(state["control_group"])','cgroup = _read_cgroup(state["control_group"], deadline=deadline)')
s=s.replace('                        time.sleep(1 if during is None else 5)','                        remaining = deadline - time.monotonic()\n                        if remaining > 0:\n                            time.sleep(min(1 if during is None else 5, remaining))')
s=s.replace('def _wsl(*args: str, check: bool = True) -> subprocess.CompletedProcess[str]:\n    return subprocess.run(', 'def _wsl(*args: str, check: bool = True, deadline: float | None = None) -> subprocess.CompletedProcess[str]:\n    budget = 30 if deadline is None else min(30, deadline - time.monotonic())\n    if budget <= 0:\n        raise subprocess.TimeoutExpired(args, 0)\n    return subprocess.run(')
s=s.replace('        timeout=30,\n    )','        timeout=budget,\n    )')
s=s.replace('    _pin_entry()\n    parser = argparse.ArgumentParser', '    _require_unused_build_evidence()\n    _pin_entry()\n    parser = argparse.ArgumentParser')
p.write_text(s,encoding='utf-8')
p=Path('tests/connectome_training/test_px4_firmware_scope_entry_v2.py');s=p.read_text();s=s.replace('monkeypatch.setattr(module, "BUILD_EVIDENCE_DIR", tmp_path / "evidence")','monkeypatch.setattr(module, "BUILD_EVIDENCE_DIR", tmp_path / "evidence")\n    monkeypatch.setattr(module, "LEGACY_BUILD_EVIDENCE_DIR", tmp_path / "legacy-evidence")');s=s.replace('"_show_build_unit", lambda: next(states)','"_show_build_unit", lambda **kwargs: next(states)');s=s.replace('lambda group: dict(', 'lambda group, **kwargs: dict(');s=s.replace('lambda command, path: SimpleNamespace(stdout=values[path.rsplit("/", 1)[1]])','lambda command, path, **kwargs: SimpleNamespace(stdout=values[path.rsplit("/", 1)[1]])');p.write_text(s,encoding='utf-8')
