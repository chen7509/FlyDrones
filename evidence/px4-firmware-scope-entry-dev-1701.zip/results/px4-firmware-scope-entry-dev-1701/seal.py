import hashlib,json,zipfile,os
from pathlib import Path
root=Path.cwd();root=Path('\\\\?\\'+str(root)) if os.name=='nt' else root;raw=root/'results/px4-firmware-scope-entry-dev-1701'
sha=lambda b:hashlib.sha256(b).hexdigest()
pres=json.loads((raw/'refused-attempt-preservation.json').read_bytes());privacy=pres['private_excluded']
inv=json.loads((root/'results/target-bearing-runtime-freeze-v4-dev-1701/LOCAL_UNPUBLISHED-admission-1.json').read_bytes());rows=inv['windows']+inv['linux']['rows'];triples=[];needles=set()
for r in rows:
 cmd=r.get('cmdline');command=cmd if isinstance(cmd,str) else ' '.join(cmd or []);digest=sha(command.encode())
 triples.append(dict(pid=r['pid'],name=r['name'],argv_sha256=digest,cmdline=cmd))
 if command:needles.add(digest.encode())
explicit=['tools/connectome/px4_firmware_scope_entry_v2.py', 'tools/connectome/run_px4_status_firmware_build_v2.py', 'tests/connectome_training/test_px4_firmware_scope_entry_v2.py', 'tools/connectome/run_px4_status_firmware_build.py', 'tools/benchmark/software_process_boundary.py', 'src/flydrones/connectome_training/px4_status_firmware.py', 'tools/connectome/audit_px4_status_firmware_binary.py', 'configs/px4/estimator-status-firmware-build-profile.json', 'configs/px4/estimator-status-firmware-profile.json', 'configs/px4/estimator-status-dds-candidate.yaml', 'docs/superpowers/plans/2026-10-12-px4-estimator-status-firmware.md', 'docs/PX4_FIRMWARE_SCOPE_ENTRY_PRODUCTION_REPORT.md', 'docs/superpowers/specs/2026-10-16-px4-firmware-scope-entry-design.md', 'docs/superpowers/plans/2026-10-16-px4-firmware-scope-entry.md', 'evidence/flydrones-history-through-initialized-baseline-dev-1701.json', 'evidence/flydrones-history-through-admitted-executor-dev-1701.json', 'evidence/flydrones-history-through-loader-path-research-dev-1701.json', 'evidence/flydrones-pr65-history-through-linear-sequence-dev-1701.md', 'evidence/static-v4-executor-completion-release.frame', 'evidence/membrane-dynamics-production-publication.json', 'evidence/role-comparison-production-publication.json', 'evidence/role-comparison-production-postseal-progress-correction.json', 'evidence/membrane-dynamics-production-retention-correction.json', 'docs/MEMBRANE_DYNAMICS_PRODUCTION_REPORT.md', 'docs/ROLE_COMPARISON_PRODUCTION_REPORT.md', 'docs/FROZEN_INFERENCE_COEFFICIENTS_PRODUCTION_REPORT.md', 'docs/TRAINING_EFFORT_PRODUCTION_REPORT.md', 'evidence/frozen-inference-coefficients-publication.json', 'evidence/training-effort-production-publication.json', 'results/frozen-inference-coefficients-dev-1701/independent-frozen-coefficients-archive-audit.json', 'results/frozen-inference-coefficients-dev-1701/independent-frozen-coefficients-archive-audit-v2.json', 'results/frozen-inference-coefficients-dev-1701/independent-frozen-coefficients-final-publication-audit.json', 'results/px4-firmware-scope-entry-dev-1701/independent-training-effort-archive-audit.json', 'results/px4-firmware-scope-entry-dev-1701/independent-training-effort-archive-audit-v2.json', 'results/px4-firmware-scope-entry-dev-1701/independent-training-effort-final-publication-audit.json', 'results/px4-firmware-scope-entry-dev-1701/NEXT_PHASE.md', 'results/static-v4-attempt-dev-1701/preflight.json', 'results/static-v4-attempt-dev-1701/cli-completion.json', 'results/static-v4-attempt-dev-1701/admission-refusal-audit.json', 'results/target-bearing-runtime-freeze-v4-dev-1701/run-static-preparation-v4.py', 'results/target-bearing-runtime-freeze-v4-dev-1701/firstfacts.json', 'results/target-bearing-runtime-freeze-v4-dev-1701/completion.json']
files={root/p for p in explicit}|{p for p in raw.rglob('*') if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo')}
assert not files&{root/r['path'] for r in privacy}
members=[];scanned=0
symlinks=[dict(path=p.relative_to(root).as_posix(),target=os.readlink(p)) for p in raw.rglob('*') if p.is_symlink()]
for p in sorted(files):
 b=p.read_bytes();path=p.relative_to(root).as_posix();assert not any(n in b for n in needles),path
 try:stack=[json.loads(b.decode('utf-8-sig'))];scanned+=1
 except (ValueError,UnicodeError):stack=[]
 while stack:
  v=stack.pop()
  if isinstance(v,dict):
   for keys in (('pid','name','argv_sha256'),('pid','name','cmdline')):
    if set(keys)<=v.keys():assert not any(all(v.get(k)==r.get(k) for k in keys) for r in triples),path
   stack.extend(v.values())
  elif isinstance(v,list):stack.extend(v)
 members.append(dict(path=path,bytes=len(b),sha256=sha(b)))
archive=root/'evidence/px4-firmware-scope-entry-dev-1701.zip';mapping=archive.with_suffix('.sha256.json')
payload=dict(schema='px4-firmware-scope-entry-map-v1',members=members,private_excluded=privacy,nonempty_private_argv_hashes=len(needles),private_allrow_triples=len(triples),json_scanned=scanned,retained_symlinks=symlinks,scope='Pre-make current process/cgroup software entry;explicit inert OS/file protocols;not actual kernel/make/firmware/source qualification;no resource queries;publicationpending')
with mapping.open('xb') as f:f.write(json.dumps(payload,indent=2).encode())
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for r in members:z.write(root/r['path'],r['path'])
 z.write(mapping,mapping.relative_to(root).as_posix())
receipt=dict(archive=archive.relative_to(root).as_posix(),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),members=len(members)+1,mapped_members=len(members),uncompressed_bytes=sum(r['bytes'] for r in members),manifest_sha256=sha(mapping.read_bytes()),mapped_payload_bytes=sum(r['bytes'] for r in members),manifest_bytes=mapping.stat().st_size,zip_expanded_bytes=sum(r['bytes'] for r in members)+mapping.stat().st_size,preseal_exact_set=[r['path'] for r in members],scope='Plan2done/softwarepublicationpending;postsealreceipt/delivery/stage/publication/PR/automation outside')
with (raw/'seal-receipt.json').open('xb') as f:f.write(json.dumps(receipt,indent=2).encode())
print(json.dumps({k:v for k,v in receipt.items() if k!='preseal_exact_set'}))
