# SDD ledger - plan: docs/superpowers/plans/2026-10-15-target-bearing-entry-dependency-production.md

Task 1: in progress; BASE a71401009b604db97938cd68d7fbf6ffff0dbf91.
Pre-flight: Task1 entry bill -> Task2 v2 study: exact schema, complete candidate/tool/entry/current-file joins required; no conflict. Task2 fixed v2 study -> Task3 static -> Task4 existing single physical attempt: v1 immutable, literal registry routes only, old budgets/once guards unchanged.
Ruling: retain all raw/failed evidence and plan ledger; do not delete skill workspace or old inputs because user preservation instruction overrides scratch cleanup. Existing isolated named worktree reused. Native stages cannot be completed by software fixture tests.

Task1/Task2 software implemented and independently reviewed C0/I0/M0; real native entry/context/SDK/static-v2 and physical stages remain untested. Six behavior checkboxes done, two commit/seal checkboxes pending. Actual v2 scope/study/coordinator absent and unconsumed. Current recipe is prospective; no Linux pre-attestation. All raw/bootstrap/behavior/review failures retained.
