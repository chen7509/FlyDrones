# Independent readonly review — Task 1 / Task 2

Review date: 2026-10-15. Base: `a71401009b604db97938cd68d7fbf6ffff0dbf91`. Scope: current uncommitted entry dependency producer, v2 preparation/study integration, shared study changes, both new tests, retained RED/GREEN evidence, neighboring validators and research/design. Coordinator/report review remains a separate follow-up when their filenames are supplied.

This review executed no tests, SDK/native entry tools, resource queries, compilers, renderer, Agent, PX4 or physical dispatch. Findings below follow directly from source branches and retained artifacts; they are not claimed as newly executed REDs. Only this report and its JSON companion were written. The consumed preparer SHA remains `9113bd1148c9e529de2f0ab1a97b818f86766ba5e44a5d0c94133f0cb8f8c68d`.

## Strengths

- Entry roots and historical candidate leaves are explicitly separated; candidates remain file records and receive trace-based classifications without standalone leaf commands. Requested records survive resolved-path deduplication in the bill.
- The owned process runner bounds each stream, retains timeout output, records local monotonic facts, and labels descendant ownership unknown. All eight qualifications and runtime closure remain false.
- The study profile uses literal v2 paths and an explicit registry without mutating v1 globals. Shared graph preparation audit now checks exact baseline-plus-generated membership and the prepared handoff is compared with current input records.
- Retained evidence identifies its fixture nature. First RED is a missing module/interface failure; version RED is empty version acceptance; joins RED exposes Agent extra-member and missing bill-baseline rejection; tool-order RED shows a changed tool still reached execution. Later targeted results contain 18 passes. Neighbor evidence contains 247 passes / 3 skips and predates the last tool-order fix. None establishes current native ELF acceptance or a v2 freeze.

## Issues

### Critical (C)

None found in reviewed scope.

### Important (I)

1. **I1 — The actual v2 producer always fails the binding validator after a successful bill.** `tools/benchmark/prepare_calibration_capture_v2.py:162` puts the full dependency bill under `runtime:entry-dependency-files`; no code creates `graph:dependencies`. At line 220 it invokes the unchanged `validate_binding`, whose `tools/benchmark/runtime_resource_binding.py:95–97` explicitly requires `graph:resolver`, `graph:source`, and `graph:dependencies` for v4. This is a deterministic interface mismatch, so the once-only attempt would already have copied inputs and executed queries/traces before failing, without reaching the final graph/study. Preserve the existing role contract while assigning freshly traced resolver dependencies before the general deduplicating inventory insertion. Add a software fixture that exercises the real `prepare_v2` inventory and real `validate_binding` rather than replacing that validation. Current v2 tests never invoke `prepare_v2`.

2. **I2 — Audit accepts a self-consistent substitution of fixed dependency tools.** `tools/benchmark/native_entry_dependencies.py:302–305` checks tool key names and joins their records to bill files, then constructs expected commands from those same bill-supplied requested paths. It never compares those paths with the production `tool_paths()` selection at lines 24–25. Therefore a different tool path with its file record, version row, command rows, and baseline adjusted consistently is accepted by these audit branches. Hashing the bill and its producer source does not establish that the recorded tool choices equal the producer's fixed choices. Compare all four tool paths/current records against the explicit production selection, keeping fixture overrides explicit in tests, and add a retained tool-substitution RED. This differs from detecting mutation of the originally selected tool during discovery.

3. **I3 — The bill's Agent loader context is not joined to the selected Agent contract.** `tools/benchmark/calibration_capture_study_v2.py:23–33` joins the bill digest/file baseline and calls `audit_entry_bill(bill, baseline)`, but supplies neither binding/contract entry declarations nor Agent configuration. `tools/benchmark/native_entry_dependencies.py:315,345–352` reconstructs environments from bill-supplied `agent_paths` and `agent_lib`. A bill that removes an Agent path from that list and changes its recorded environment to BASE_ENV, or declares a different lib directory with matching raw rows, remains internally consistent; the audit never compares it with `execution['agent']['configuration']['lib_dir']` and the exact binary/library entry list selected at `prepare_calibration_capture_v2.py:158–161`. Extra `agent_paths` that are never queried are also unchecked by the auditor. Join the exact expected entry/Agent context to the execution contract in v2 audit and reject different/extra/missing paths before reporting trace consistency. Add full v2 join fixtures with the real bill and graph audit; the existing join test replaces both audits and even supplies a non-JSON bill file.

4. **I4 — A failed query journal write replaces the primary failure.** `tools/benchmark/native_entry_dependencies.py:211–216` re-raises the command/pin failure but unconditionally writes its record in `finally`; an OSError there supersedes that exception. The outer handler at lines 276–280 then records the writer OSError as the aggregate error, and a final bill writer failure can supersede that too. For example, a timeout followed by a query write failure raises the writer error instead of the timeout, although the in-memory query still contains timeout facts. Preserve distinct primary and journal-write error latches, attempt the aggregate record without erasing the first error, and raise/report the original cause with persistence failures attached. The current writer test fails a successful first version-record write and checks only that the aggregate error is non-null, so it does not verify combined failure precedence or a failing aggregate writer.

5. **I5 — Failed termination skips the specified owned-child escalation.** In `tools/benchmark/native_entry_dependencies.py:71–85`, `process.terminate()` is inside the same outer try as both waits and kill. If terminate raises, control jumps straight to line 83, so neither the bounded wait nor `process.kill()` is attempted and the owned child can remain alive. This does label the descendant state unknown, but it does not perform the specified terminate/wait/kill/wait sequence on its own Popen. Guard each cleanup action separately, preserve the primary command error, and continue bounded wait/kill attempts where the owned handle remains live. Add a protocol Popen fixture where terminate raises while kill succeeds; the retained real Windows timeout only exercises successful terminate.

6. **I6 — New v2 scope/tool facts omit the required paired clock records.** `tools/benchmark/prepare_calibration_capture_v2.py:267–280` writes only start/end monotonic values, with no local elapsed field or UTC start/end. Its reused scope observer (`prepare_calibration_capture.py:116–145`) writes no timestamps, and the reused package query (`prepare_calibration_capture.py:199–239`, called at v2 line 164) retains no timing facts. New SDK queries use `native_resource_client.py:132–158`, which retains monotonic endpoints but no UTC/elapsed. The authoritative design explicitly requires future tool/scope/supervisor records to retain local monotonic start/end/elapsed alongside UTC, because old cross-host clocks cannot establish nesting/budgets. Add v2-owned wrappers/observers or explicit compatible extensions, preserving the consumed preparer bytes. Coordinator timestamps cannot substitute for missing per-call facts.

### Minor (M)

None separately classified.

## Recommendations

Resolve I1 before any real static admission. Add adversarial software RED/GREEN for I2–I5 and record the current hashes of all changed implementation/test files, including both v2 modules. Existing verification JSONs pin the entry module/test and old preparer but omit current v2 source hashes. Run the necessary final neighboring regression after fixes; do not retrospectively relabel the earlier neighbor result as testing the later source.

## Declined to judge

- Prospective coordinator/report lifecycle and publication behavior: filenames were not yet provided; follow-up review is required.
- Actual ldd/readelf output on installed normal ELF and the expected renderer entry behavior: no permitted current native execution or successful native result exists; research is an explicitly limited inference.
- Runtime mapping, renderer initialization, sensor/source/calibration/flight authority and physical capture: outside this preparation-only deliverable and still unqualified.
- Atomic continuous whole-filesystem/process-memory identity: explicitly excluded by the snapshot/binding design; before/after file pins do not claim it.
- Full transitive licensing/distro build certification and full Kalibr/learning results: explicitly pending separate objectives; observed root/source/package notices do not certify them.

## Assessment

**Ready to merge: No.** The v2 producer currently cannot pass its real binding validator, and the audit does not yet enforce fixed tool/Agent context joins. Failure precedence, owned-child escalation, and v2 clock evidence also require correction before the once-only native attempt; all native/physical qualifications remain false.

## Reviewed source snapshot (raw-byte SHA256)

- `native_entry_dependencies.py`: `66489107d22f5658271a5245630d59394f1c5db200c385757b59286e4598f7db`
- `calibration_capture_study.py`: `fe1bed2ac526e6c487709a615a5978031cda8debb96ded465a2d1928e32de19b`
- `calibration_capture_study_v2.py`: `3eafa09fa9d7d110df70434c0a556491eeaabbd0be40c53a69d67426f2400216`
- `prepare_calibration_capture_v2.py`: `a5cf21451c402939f9722b5d8801682145b4bf1af9e2db0bbc63baf1a175b7d1`
- `test_native_entry_dependencies.py`: `f054f170bdfb9da08f268bba21a1fc5573c5451e07ea971d2aa8816d4b325153`
- `test_calibration_study_v2.py`: `b5ce6c5d0bfe74b5dcec689ed6c0811cec8f45ceab84a1dd713be9a8735f3994`
