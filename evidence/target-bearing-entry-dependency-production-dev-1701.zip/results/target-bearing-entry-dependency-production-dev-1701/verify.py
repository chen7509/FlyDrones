import datetime,hashlib,json,subprocess,sys,os
from pathlib import Path
root=Path.cwd();raw=root/'results/target-bearing-entry-dependency-production-dev-1701'
label=sys.argv[1];argv=sys.argv[2:];assert label and argv
before={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in ['tools/benchmark/native_entry_dependencies.py','tools/benchmark/calibration_capture_study.py','tools/benchmark/calibration_capture_study_v2.py','tools/benchmark/prepare_calibration_capture_v2.py','tests/benchmark/test_native_entry_dependencies.py','tests/benchmark/test_calibration_study_v2.py','tools/benchmark/prepare_calibration_capture.py'] if (root/p).exists()}
test_env=dict(os.environ);test_env.update(PYTHONPATH=str(root/'src')+os.pathsep+str(root),PYTHONUTF8='1')
record={'argv':argv,'start_utc':datetime.datetime.now(datetime.UTC).isoformat(),'source_before':before,'python':sys.version,'executable':sys.executable,'environment':{k:test_env.get(k) for k in ['PYTHONPATH','PYTHONUTF8']}}
with (raw/(label+'.stdout')).open('xb') as out,(raw/(label+'.stderr')).open('xb') as err:
 p=subprocess.run(argv,stdout=out,stderr=err,env=test_env)
record.update(exit=p.returncode,end_utc=datetime.datetime.now(datetime.UTC).isoformat(),source_after={path:hashlib.sha256((root/path).read_bytes()).hexdigest() for path in before})
(raw/(label+'.json')).write_bytes(json.dumps(record,indent=2).encode());print(json.dumps({'label':label,'exit':p.returncode}));print((raw/(label+'.stdout')).read_text(encoding='utf8',errors='replace')[-3500:]);print((raw/(label+'.stderr')).read_text(encoding='utf8',errors='replace')[-1000:])
