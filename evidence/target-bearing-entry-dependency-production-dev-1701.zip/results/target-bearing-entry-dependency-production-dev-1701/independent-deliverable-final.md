# Independent final deliverable review — software-only seal

Date: 2026-10-15. Base: `a71401009b604db97938cd68d7fbf6ffff0dbf91`. This new review preserves `independent-deliverable-review.md/json` and all earlier code reviews. Scope: added alias coverage, final report/recipe identities, software-only checkoffs, public/private boundary and exact retained sealed-neighbor/Ruff/diff records. No reviewer tests/native/SDK/resource queries, Git mutations, coordinator or admission were executed. Only these two new final review files were written.

## Strengths / resolved minor finding

**M1 resolved.** `test_native_entry_dependencies.py:127–155` adds explicit distinct-request/same-resolved protocol coverage. It creates a separate ELF fixture file, uses a clearly labelled file-record resolver substitution, preserves both requested entry identities and a candidate, requires one ldd call and no alias invocation, and rejects mutation of the inherited trace. It tests the real bill producer/auditor's deduplication branches. It does not claim filesystem symlink resolution, installed ELF validity, native execution or Linux evidence. `alias-coverage` records 1 pass / 16 deselected in 0.26s, and the report explicitly says no RED was fabricated for existing behavior.

The updated report retains earlier 258/3 results as history, explains the resolved coverage gap and names the later exact final result. The first prospective recipe remains unchanged. `prospective-static-v2-recipe-final.json` links its SHA and updates the test's working-byte identity, with no production source/input/budget/native pre-pin/admission change. Its six source/test records match current bytes. The four production files remain identical to the final software code sign-off.

`sealed-neighbor.stdout` records **259 passed / 3 skipped in 22.86s**, exit 0. Its exact seven before/after source hashes equal current source; `sealed-ruff` and `sealed-diff` exit 0. The argv, interpreter and PYTHONPATH/PYTHONUTF8 are explicit. The skipped Windows platform/symlink fixtures remain skips; these are host software regressions, not native acceptance. The reviewer read those records and did not rerun them.

The original deliverable review independently byte-checked all45 scene files / 100019062 bytes and all14 Agent files / 41212304 bytes, verified old preparer/source recipe identity, private digest/70112-byte public derivative boundary, and 283-path / 772530105-byte historical-before map totals. Those inputs and limits are unchanged by the alias-test addendum. Actual archive private exclusion/CRC/SHA and after-seal historical digest equality still require the later actual seal review.

The checked-off plan still changes only six software behavior/implementation checkboxes. Both review/seal/commit checkboxes and every Task 3 / Task 4 checkbox remain pending. The report/recipes leave runtime graph frozen and physical ready false, current Linux tool pre-pins null, the concrete once coordinator and fresh Linux/native scope/study pending, and all eight qualifications false. Prospective recipe identities are not actual Linux pre-attestation.

## Issues

**Critical: 0. Important: 0. Minor: 0.** No remaining actionable issue found in this software-only deliverable review. The prior M1 finding remains preserved in its original report and is resolved by the specific added test and retained actual result above.

## Declined to judge

- Actual new ZIP member set/private exclusion, CRC/SHA, historical archives after-seal and publication ledger: not yet produced; inspect the actual sealed artifacts later.
- Onlypersonal publication/commit/PR current head/body: pending and not inspected here.
- App goal/automation state: not queried by this review.
- Concrete Task 3 coordinator/claim/scope and fresh Linux pre-attestation/admission: still pending, outside the software seal.
- Native ELF/renderer/SDK graph, runtime mapping, source/clock/calibration/physical/learning/flight outcomes: unexecuted/unqualified and outside this deliverable.

## Assessment

**Ready for the Task 1 / Task 2 software-only evidence seal: Yes. C0 / I0 / M0.** Resolve the two pending publication checkboxes only after their actual seal/onlypersonal publication steps. Task 3 concrete coordinator/admission/static graph and Task 4 physical remain pending; this software seal provides no native dispatch eligibility or whole-goal completion.

## Exact current source SHA256

- `tools/benchmark/native_entry_dependencies.py`: `38bdb30431abb6d399f0a79c20671c7a7d75ecf444436b7a0d956f08bed988ea`
- `tools/benchmark/calibration_capture_study.py`: `bf8f082cf5fda77a20fe8876c0b83b1f4ae9c329c3ebe992768e7afb75378b11`
- `tools/benchmark/calibration_capture_study_v2.py`: `00cd4c5890a6833af8f3656d8665a2888614f37bcb40dffef534474125202fc2`
- `tools/benchmark/prepare_calibration_capture_v2.py`: `068f52eac326024a72cba0c06bf8fcca2bddc71536c5f279880540afc48cb7c0`
- `tests/benchmark/test_native_entry_dependencies.py`: `586af23b04b3de2aa6d787b57508da2235441fa394519744d55122e84f2329d5`
- `tests/benchmark/test_calibration_study_v2.py`: `2aac0dc006093349166f038b852e21269e4d638d7999e067871d6adaa40146e8`
- unchanged `tools/benchmark/prepare_calibration_capture.py`: `9113bd1148c9e529de2f0ab1a97b818f86766ba5e44a5d0c94133f0cb8f8c68d`

Current report SHA `74f9d94f31fd74a5e310f2e2cdf6e5c010b6bc3fd1f167df93c98bff41382871`; plan SHA `40dd4035cc3a2ece364838c97e09108621dcd4d70c4cb234f06d73437fc92e30`; first recipe SHA `536c831581079319dd0aad326be38a5f8d9c5c34fd0bd223b4801600b3a934d9`; additive final recipe SHA `e7fd97a0fb1620a3f5980ef4c6d000b5e701f5044e177ded73e4ae76ec5e39dc`. Preserved initial deliverable Markdown SHA `9ec3e997b9ac38cc778d9542b6261f776c6221142b1d9ea1cfc64a770edfc9bc`; JSON SHA `3e0f41274cde5b878a6a0ecf8cf5a28ebaab0796444fb36838e40af5e1592e6c`.
