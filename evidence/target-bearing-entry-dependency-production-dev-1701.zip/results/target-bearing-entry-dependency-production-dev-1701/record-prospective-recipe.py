import datetime, hashlib, json, subprocess
from pathlib import Path

root = Path.cwd()
raw = root / 'results/target-bearing-entry-dependency-production-dev-1701'
def digest(path):
    data = path.read_bytes()
    return dict(path=path.relative_to(root).as_posix(), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
def write(name, record):
    with (raw/name).open('xb') as stream:
        stream.write(json.dumps(record, indent=2).encode())

product = [
    'tools/benchmark/native_entry_dependencies.py', 'tools/benchmark/calibration_capture_study.py',
    'tools/benchmark/calibration_capture_study_v2.py', 'tools/benchmark/prepare_calibration_capture_v2.py',
    'tests/benchmark/test_native_entry_dependencies.py', 'tests/benchmark/test_calibration_study_v2.py',
]
scene = root/'results/target-bearing-scene-production-dev-1701/actual-scene-v3'
manifest = scene/'manifest.json'
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == '0a66c427e1d9d7d9de1557d46bfb12a04398e27b467e4acc246240f5d06c6da4'
scene_rows = [digest(manifest)]
for name, expected in json.loads(manifest.read_bytes())['files'].items():
    row=digest(scene/name)
    assert row['bytes']==expected['bytes'] and row['sha256']==expected['sha256']
    scene_rows.append(row)
assert len(scene_rows)==45 and sum(r['bytes'] for r in scene_rows)==100019062
old = root/'results/target-bearing-runtime-freeze-dev-1701/frozen-study-v1'
deployment = json.loads((old/'agent-deployment.json').read_bytes())
agent_rows = []
for member in deployment['members']:
    requested=member['deployed']['requested']
    assert requested.startswith('/mnt/c/')
    local=Path(requested[5].upper()+':/'+requested[7:])
    row=digest(local)
    assert row['sha256']==member['deployed']['sha256'] and row['bytes']==member['deployed']['bytes']
    agent_rows.append(row)
assert len(agent_rows)==14 and sum(r['bytes'] for r in agent_rows)==41212304
old_prepare=root/'tools/benchmark/prepare_calibration_capture.py'
assert digest(old_prepare)['sha256']=='9113bd1148c9e529de2f0ab1a97b818f86766ba5e44a5d0c94133f0cb8f8c68d'
folder=root/'results/target-bearing-runtime-freeze-v2-dev-1701/frozen-study-v2'
physical=root/'results/target-bearing-physical-capture-dev-1701'
assert not folder.exists() and not physical.exists()
def linux(path): return '/mnt/'+str(path)[0].lower()+'/'+str(path)[3:].replace('\\','/')
record=dict(
    schema='prospective-entry-static-v2-recipe-v1', utc=datetime.datetime.now(datetime.UTC).isoformat(),
    base=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),
    status='SOFTWARE_RECIPE_ONLY_NOT_DISPATCHED', product_working_bytes=[digest(root/p) for p in product],
    scene_current_readonly=scene_rows, immutable_v1_agent_current_readonly=agent_rows,
    old_prepare_current=digest(old_prepare), fixed_v2_folder=linux(folder), fixed_physical_folder=linux(physical),
    actual_v2_attempt_consumed=False, actual_physical_attempt_consumed=False,
    command_template=['/usr/bin/time','-v','-o','<exclusive resources file>','/usr/bin/timeout','--signal=TERM','--kill-after=10s','180s','/usr/bin/python3','-m','tools.benchmark.prepare_calibration_capture_v2','--prepare-only','--unit','<fresh own fly-calibration-prepare nonce scope>'],
    sdk_environment={'HOME':'/home/yuchen7509','PATH':'/usr/bin:/bin','LANG':'C.UTF-8','PYTHONPATH':linux(root)+'/src:'+linux(root),'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'},
    manager_control_environment='Own UID verified /run/user/<uid>; separate from SDK/collector environment',
    static_limits=dict(reserve_each_bytes=1073741824,memory_max_bytes=536870912,swap_max_bytes=0,cpu_quota_percent=100,tasks_max=64,scope_seconds=210,inner_seconds=180,kill_after_seconds=10,outer_seconds=240),
    physical_limits=dict(reserve_each_bytes=4294967296,memory_max_bytes=4294967296,swap_max_bytes=0,cpu_quota_percent=100,tasks_max=256,scope_seconds=330,inner_seconds=315,outer_seconds=360,worker_seconds=300),
    mandatory_pending=['New literal once coordinator code/recipe independent review; no generic worker', 'Fresh same-command Linux requested/resolved tool/interpreter/loader/resolver/plugin/package versions and file pins before native calls, verified after', 'Fresh dual1GiB/no competition/successfully empty Docker, exclusive admission record/claim/new scope/study absence', 'Actual entry traces, all candidates and current known OGRE entry coverage, original-byte final graph/material/search/license/source/binding/execution/study joins', 'Only a complete actual new v2 study and fresh dual4GiB can reach original fixed physical attempt'],
    linux_current_tool_prepins=None, new_actual_entry_trace=False, runtime_graph_frozen=False,physical_dispatch_ready=False,
    qualification={k:False for k in ['source','clock','measured_calibration','accuracy','teacher','fusion','training','flight']},
)
write('prospective-static-v2-recipe.json',record)
old_zips=[]
for path in sorted((root/'evidence').glob('*.zip')):
    hasher=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):hasher.update(chunk)
    old_zips.append(dict(path=path.relative_to(root).as_posix(),bytes=path.stat().st_size,sha256=hasher.hexdigest()))
write('historical-archives-before.json',dict(files=old_zips,count=len(old_zips),bytes=sum(r['bytes'] for r in old_zips)))
print(json.dumps(dict(scene_files=len(scene_rows),agent_files=len(agent_rows),historical_zip_count=len(old_zips),historical_zip_bytes=sum(r['bytes'] for r in old_zips),prospective_only=True)))
