import hashlib,json,zipfile
from pathlib import Path
root=Path.cwd(); raw=root/'results/target-bearing-entry-dependency-production-dev-1701'
review=json.loads((raw/'independent-code-final.json').read_text(encoding='utf8'))['effective_assessment']
assert review['ready_to_merge'] is True and review['counts']==dict(critical=0,important=0,minor=0)
for name,sha in review['current_source_sha256'].items():
    if name!='tests/benchmark/test_native_entry_dependencies.py':
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha
current=json.loads((raw/'sealed-neighbor.json').read_bytes())
assert current['exit']==0 and current['source_before']==current['source_after']
for name,sha in current['source_after'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha
deliverable=json.loads((raw/'independent-deliverable-final.json').read_text(encoding='utf8'))
assert deliverable['counts']==dict(critical=0,important=0,minor=0)
before=json.loads((raw/'historical-archives-before.json').read_text())
previous=json.loads((root/'results/target-bearing-loader-context-research-dev-1701/historical-archives-before-seal.json').read_text())
previous.append(dict(path='evidence/target-bearing-loader-context-research-dev-1701.zip',bytes=1433663,sha256='0ca8b5b6739b634e52c3c4edaf136b76f343d1f273ac0d9f147a384f0b7aaf3d'))
assert before['files']==sorted(previous,key=lambda r:r['path'])
assert before['count']==283 and before['bytes']==772530105
for row in before['files']:
    path=root/row['path'];h=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
    assert path.stat().st_size==row['bytes'] and h.hexdigest()==row['sha256']
with (raw/'historical-archives-after-unchanged.json').open('xb') as stream:
    stream.write(json.dumps(dict(count=283,bytes=772530105,all_streamed_sha_equal=True,prior_exact_map_equal=True),indent=2).encode())
excluded={'initial-admission-private.json','archive-seal-receipt.json','independent-archive-review.json','independent-archive-review.md'}
paths=[p for p in raw.rglob('*') if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts and p.suffix!='.pyc']
selected=[
    'tools/benchmark/native_entry_dependencies.py','tools/benchmark/calibration_capture_study.py',
    'tools/benchmark/calibration_capture_study_v2.py','tools/benchmark/prepare_calibration_capture_v2.py',
    'tests/benchmark/test_native_entry_dependencies.py','tests/benchmark/test_calibration_study_v2.py',
    'tools/benchmark/prepare_calibration_capture.py','tools/benchmark/run_calibration_capture.py',
    'tools/benchmark/calibration_capture_scope.py','tools/benchmark/native_resource_client.py',
    'tools/benchmark/runtime_resource_binding.py','tools/benchmark/capture_contract.py',
    'docs/TARGET_BEARING_ENTRY_DEPENDENCY_PRODUCTION_REPORT.md',
    'docs/superpowers/specs/2026-10-15-target-bearing-entry-dependency-production-design.md',
    'docs/superpowers/plans/2026-10-15-target-bearing-entry-dependency-production.md',
    '.superpowers/sdd/2026-10-15-target-bearing-entry-dependency-production/progress.md',
]
paths+= [root/p for p in selected];paths=sorted(set(paths));records=[]
for path in paths:
    data=path.read_bytes();records.append(dict(path=path.relative_to(root).as_posix(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
private=raw/'initial-admission-private.json'
manifest=root/'evidence/target-bearing-entry-dependency-production-dev-1701.sha256.json'
assert not manifest.exists()
manifest.write_bytes(json.dumps(dict(schema='sealed-working-byte-map-v1',scope='Task1/Task2 production software plus protocol fixtures and prospective recipe; no actual v2 native/static/physical attempt',members=records,private_original=dict(path=private.relative_to(root).as_posix(),bytes=private.stat().st_size,sha256=hashlib.sha256(private.read_bytes()).hexdigest(),publication='LOCAL_UNPUBLISHED'),qualification={k:False for k in ['source','clock','measured_calibration','accuracy','teacher','fusion','training','flight']}),indent=2).encode())
target=root/'evidence/target-bearing-entry-dependency-production-dev-1701.zip'
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for path in paths:archive.write(path,path.relative_to(root).as_posix())
    archive.write(manifest,manifest.relative_to(root).as_posix())
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None and len(archive.namelist())==len(records)+1
    for row in records:
        data=archive.read(row['path']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
receipt=dict(path=target.relative_to(root).as_posix(),bytes=target.stat().st_size,members=len(records)+1,mapped_members=len(records),sha256=hashlib.sha256(target.read_bytes()).hexdigest())
with (raw/'archive-seal-receipt.json').open('xb') as stream:stream.write(json.dumps(receipt,indent=2).encode())
print(json.dumps(receipt))
