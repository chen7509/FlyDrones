# Independent deliverable review — software report / prospective recipe

Date: 2026-10-15. Base: `a71401009b604db97938cd68d7fbf6ffff0dbf91`. Scope: newly authored production report, prospective static-v2 recipe, six software plan checkoffs, classified/private admission boundary, historical-before map and retained publication checks. All earlier code reviews remain unchanged. No tests, native/SDK tools, resource queries, Git mutations or actual dispatch were executed by this reviewer; only these deliverable review files were written.

## Strengths / evidence joins

- The report opens with the software-only limit and explicitly keeps runtime graph freeze, physical readiness and all eight qualifications false. Its descriptions distinguish implemented production branches from unexecuted native consumers, preserve real failure history, and do not relabel bootstrap failures or the failed `clocks-green` record as native/pass evidence.
- The recipe is explicitly `SOFTWARE_RECIPE_ONLY_NOT_DISPATCHED`, carries null current Linux tool pre-pins and false entry/graph/physical flags, and lists concrete once-only coordinator review and fresh Linux admission as pending. Its command is a template with exclusive-output/own-scope placeholders, not an executed command or current Linux pre-attestation.
- Current readonly hashing independently verified all **45 scene records / 100019062 bytes** and **14 Agent records / 41212304 bytes** against the recipe. The scene manifest matches the fixed hard SHA, current six product/test hashes match the recipe and final code sign-off, and the consumed old preparer SHA is unchanged. These are file-byte checks, not Linux identity, mapping or loading evidence.
- The historical-before map contains 283 unique archive paths, valid SHA shapes and summed 772530105 bytes, matching its declared totals. Its recording helper streams archives. This review inspected that map/helper and did not independently rehash all 283 archives; after-seal archive preservation belongs to the later seal review.
- The public derivative contains relevant counters, an empty classified competition list, Docker exit/empty result, and private-file digest/size only. Its declared private hash `97a8e8eb4413ad5f457258fbbddbfb9da7a84b434c2034e3f0524c5519fa831e` and 70112 bytes match the local private file. Its scope is one old readonly observation, explicitly not current dispatch admission. No full private inventory is included in this review. Actual exclusion from the not-yet-built canonical ZIP remains a seal-review check.
- `publication-neighbor.stdout` records **258 passed / 3 skipped in 23.38s**, exit 0; `publication-ruff` and `publication-diff` record exit 0. Exact argv/interpreter/PYTHONPATH/PYTHONUTF8 and seven before/after source hashes match the current code sign-off. These remain host software checks, with the Windows platform/symlink skips retained as skips.
- The plan diff changes exactly six implementation/behavior checkbox characters. Its two commit/seal checkboxes and every Task 3 / Task 4 checkbox remain pending. The new report clearly leaves concrete coordinator, Linux pre-pins/admission, actual native graph/study and physical work pending. Both literal actual output folders are absent in the reviewed checkout.

## Issues

### Critical (C)

None.

### Important (I)

None in this software publication description/recipe scope.

### Minor (M)

1. **M1 — Completed checklist names resolved-alias test coverage that is not present.** `docs/superpowers/plans/2026-10-15-target-bearing-entry-dependency-production.md:37` checks off adding `duplicate requested/alias resolved` tests. `tests/benchmark/test_native_entry_dependencies.py:119–125` tests only the same requested path declared twice; the new file has no distinct-request/same-resolved alias test, alias assertion or symlink construction. The three Windows skips belong to neighboring snapshot/mapping fixtures and do not establish entry-producer invocation deduplication. Narrow the completed test wording and retain alias coverage as pending, or add an explicit software alias case and retain its actual result before asserting this coverage. This does not withdraw the reviewed source-correctness sign-off or call for a native probe.

## Declined to judge

- Canonical new ZIP member set/private exclusion, CRC/SHA verification, postseal historical archive equality and publication-only ledger/checkbox changes: sealing has not occurred; review the actual produced archive/receipts later.
- Onlypersonal commit/push/PR head/body identity: explicitly pending, not executed or inspected here.
- Actual app goal/automation state: the report states its existing status, but no app-state query was requested or performed by this review.
- Task 3 coordinator/own-scope/claim and fresh Linux pre-attestation/admission: concrete implementation and actual records remain pending.
- Actual ELF/renderer/SDK graph, mapped runtime, source/clock/calibration/physical/learning/flight outcomes: deliberately outside this software deliverable and unqualified.

## Assessment

**Ready for the software-only evidence seal: Yes, with the minor plan-coverage wording correction. C0 / I0 / M1.** Report and recipe accurately limit software results, retained inputs and historical resource facts, preserve pending once-only native/physical work and private-public separation. Sealing/publishing this software deliverable does not complete Task 3 or justify native/physical admission.

## Exact reviewed artifact SHA256

- report: `a2b7a7504c9eb1a305d3c40463e736b196ea3874bd128c7694fbdc421b69d152`
- checked-off plan: `40dd4035cc3a2ece364838c97e09108621dcd4d70c4cb234f06d73437fc92e30`
- prospective recipe: `536c831581079319dd0aad326be38a5f8d9c5c34fd0bd223b4801600b3a934d9`
- six-byte checkoff record: `e4147deda618202294e984d8463e81c64953d5740e9242573443d29a179fe586`
- classified admission: `d182cac49c23c7e42a30b5b4bc85d6179ebd1e47bd71b3354480c1c1ef2ed593`
- historical-before map: `a088f485903b9c52c23c8afdfd7b6ccdb8d3e8adfdc98e0ed7e0f8f7827f8632`
- preserved final code review Markdown: `2806530e76ff5595c0e1358125f04c84ad880cf54ef4f46e5b5afc6cf63bde76`
- preserved final code review JSON: `845256958fdc6e546b711858201ba660ab664a2edc029b50be3169f63d057c50`
