import hashlib,json,datetime
from pathlib import Path
root=Path.cwd();raw=root/'results/target-bearing-entry-dependency-production-dev-1701'
old=raw/'prospective-static-v2-recipe.json';data=json.loads(old.read_bytes())
data['previous_recipe_sha256']=hashlib.sha256(old.read_bytes()).hexdigest()
data['addendum']='Only test working-byte identity updated after adding resolved-alias protocol coverage. No production source/input/native/prepin/dispatch or resource observation changed.'
data['utc']=datetime.datetime.now(datetime.UTC).isoformat()
for row in data['product_working_bytes']:
    path=root/row['path'];content=path.read_bytes()
    sha=hashlib.sha256(content).hexdigest()
    if row['path']!='tests/benchmark/test_native_entry_dependencies.py':assert sha==row['sha256']
    row.update(bytes=len(content),sha256=sha)
with (raw/'prospective-static-v2-recipe-final.json').open('xb') as stream:stream.write(json.dumps(data,indent=2).encode())
