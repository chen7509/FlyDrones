import json
from pathlib import Path
root=Path.cwd(); raw=root/'results/target-bearing-entry-dependency-production-dev-1701'
plan=root/'docs/superpowers/plans/2026-10-15-target-bearing-entry-dependency-production.md'
data=plan.read_bytes(); old=data
for prefix in [
    b'Write `test_candidate_leaf_is_preserved_without_standalone_invocation`',
    b'Implement entry selection/dedup', b'Add genuine `exit0_notfound`',
    b'Write failing full join fixtures', b'Implement actual SDK selection',
    b'Test declaration/digest/extra-member',
]:
    needle=b'- [ ] '+prefix
    assert data.count(needle)==1
    data=data.replace(needle,b'- [x] '+prefix,1)
plan.write_bytes(data)
(raw/'plan-software-only-checkoff.json').write_bytes(json.dumps({'changed_offsets':[n for n,(a,b) in enumerate(zip(old,data)) if a!=b],'statement':'Only six implementation/behavior checkbox bytes; both commit/seal checkboxes and Task3/4 remain pending'},indent=2).encode())
ledger=root/'.superpowers/sdd/2026-10-15-target-bearing-entry-dependency-production/progress.md'
with ledger.open('ab') as stream:
    stream.write(b'\nTask1/Task2 software implemented and independently reviewed C0/I0/M0; real native entry/context/SDK/static-v2 and physical stages remain untested. Six behavior checkboxes done, two commit/seal checkboxes pending. Actual v2 scope/study/coordinator absent and unconsumed. Current recipe is prospective; no Linux pre-attestation. All raw/bootstrap/behavior/review failures retained.\n')
