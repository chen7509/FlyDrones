import hashlib,json,subprocess
from pathlib import Path
root=Path.cwd();raw=root/'results/target-bearing-entry-dependency-production-dev-1701'
run=json.loads((raw/'publication-neighbor.json').read_bytes())
assert run['exit']==0 and run['source_before']==run['source_after']
assert '258 passed, 3 skipped in 23.38s' in (raw/'publication-neighbor.stdout').read_text()
for name,sha in run['source_after'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha
for name in ['publication-ruff','publication-diff']:
    assert json.loads((raw/(name+'.json')).read_bytes())['exit']==0
recipe=json.loads((raw/'prospective-static-v2-recipe.json').read_bytes())
for row in recipe['product_working_bytes']:
    assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256']
assert not (root/'results/target-bearing-runtime-freeze-v2-dev-1701/frozen-study-v2').exists()
assert not (root/'results/target-bearing-physical-capture-dev-1701').exists()
private=raw/'initial-admission-private.json'
assert private.stat().st_size==70112 and hashlib.sha256(private.read_bytes()).hexdigest()=='97a8e8eb4413ad5f457258fbbddbfb9da7a84b434c2034e3f0524c5519fa831e'
changed=subprocess.check_output(['git','diff','--name-only','HEAD']).decode().splitlines()
assert set(changed)=={'tools/benchmark/calibration_capture_study.py','docs/superpowers/plans/2026-10-15-target-bearing-entry-dependency-production.md'}
assert subprocess.run(['git','diff','--check'],capture_output=True).returncode==0
data=dict(schema='software-current-release-audit-v1',verified_source=run['source_after'],neighbor_exit=0,passed=258,skipped=3,seconds=23.38,ruff_exit=0,diff_exit=0,only_tracked_changes=changed,actual_v2_static_attempt=False,physical_attempt=False,qualification=False,scope='Current working bytes and retained software logs, no native command/source attestation')
with (raw/'current-release-audit.json').open('xb') as stream:stream.write(json.dumps(data,indent=2).encode())
print(json.dumps(dict(passed=258,skipped=3,current_sha_equal=True,no_native_attempt=True)))
