# Independent additive final review — Task 1 / Task 2 software

**Effective final verdict after the additive writer-fallback review below: Ready to merge/seal the Task 1 / Task 2 software deliverable. C0 / I0 / M0.** The earlier snapshot and its I7 remainder are preserved below as history; the final addendum resolves that remainder. Task 3/native admission remains pending.

Date: 2026-10-15. Base: `a71401009b604db97938cd68d7fbf6ffff0dbf91`. Earlier initial/follow-up reports remain unchanged. This review covers the exact corrected software and retained final-review RED/GREEN only; Task 3 coordinator/report, actual scope/static graph and later physical capture remain pending.

The reviewer executed no tests, native/SDK tools, resources, compiler, PX4, Agent, renderer, physical dispatch or Git mutations. Source branches and retained artifacts support this assessment. Only `independent-code-final.md/json` were written.

## Strengths / correction status

Initial I1–I6 remain resolved as detailed in the preserved follow-up. The required graph role, fixed tools, Agent context, entry-bill primary/persistence errors, owned terminate/wait/kill sequence and v2 paired-clock fields remain implemented. The consumed preparer raw SHA remains unchanged.

**I8 resolved.** `calibration_capture_study_v2.py:61–80` now requires sequential wrapper intervals and finite, ordered inner SDK intervals contained in their wrapper. The documented 1 microsecond allowance applies solely to same-host float-seconds/integer-nanoseconds representation. It grants no sensor-clock or cross-host timing authority. The retained genuine RED accepted coherent invented wrapper endpoints; the later software GREEN rejects those endpoints and arithmetic corruption.

**I7 post-pin/primary portion resolved.** `prepare_calibration_capture_v2.py:138–157` creates an independent `owner_row`, preserves the package query failure as primary and adds post-pin failures separately. The retained genuine RED raised the newer post-pin OSError; the later GREEN preserves the partial bytes and query-primary error. The query-write portion remains below.

`final-review-red.stdout` contains the two genuine behavioral failures, distinct from earlier bootstrap failures. `final-review-green.stdout` contains **27 passed in 13.70s**, exit 0, with matching seven-file before/after hashes and explicit PYTHONPATH/PYTHONUTF8. These exact hashes match the reviewed source. The previous 256/3 neighbor result and Ruff results tested the preceding source snapshot; they are not retrospectively presented as checks of these last I7/I8 changes. No artifact establishes installed native ELF/renderer acceptance or an actual v2 freeze. All eight qualifications remain false, and the literal production folder is absent in the reviewed checkout.

## Residual issues

### Critical (C)

None.

### Important (I)

1. **I7 remainder — A package-query journal failure still loses the query row.** `tools/benchmark/prepare_calibration_capture_v2.py:158–166` catches a failure writing `package-owner-query.json` and immediately raises its existing/new primary error. There is no fallback/aggregate carrying `owner_row`; the outer preparation-failure record retains only `repr(exc)` (`prepare_calibration_capture_v2.py:431–434` in this snapshot). Thus an isolated failure of this one manifest write, while parent/fallback writes remain possible, still loses successful or partial argv/output/exit/cleanup facts. The new test exercises failed query plus post-pin failure with a successful writer; it does not exercise this remaining persistence branch. Preserve `owner_row` in a separately attempted fallback/aggregate, or carry it to the enclosing failure record, while keeping the primary cause and noting write failure. A software fixture can fail only the package-query writer and verify the retained row without any native probe. This is the remaining software barrier before a once-only static admission.

### Minor (M)

None separately classified.

## Declined to judge

- Once-only Task 3 coordinator/admission/claim/owned scope/publication/report: not yet supplied, pending independent deliverable review.
- Installed ELF parser/renderer native behavior and current SDK graph: deliberately not executed and still untested.
- Physical mapped closure, measurement/source/clock qualification, Kalibr/full learning/fair baseline and flight: outside Task 1/Task 2 software and still pending.
- Continuous atomic identity, full transitive licensing and distro-build certification: excluded/pending under the authoritative design.

## Assessment

**Ready to merge: With fixes.** I8 and I7's post-pin failure are corrected with genuine software RED/GREEN. One part of I7 remains for package-query persistence; correct it before native admission. Coordinator/report authoring can proceed, but this review does not claim Task 3/physical readiness or whole-goal completion.

## Exact reviewed raw-byte SHA256

- `tools/benchmark/native_entry_dependencies.py`: `38bdb30431abb6d399f0a79c20671c7a7d75ecf444436b7a0d956f08bed988ea`
- `tools/benchmark/calibration_capture_study.py`: `bf8f082cf5fda77a20fe8876c0b83b1f4ae9c329c3ebe992768e7afb75378b11`
- `tools/benchmark/calibration_capture_study_v2.py`: `00cd4c5890a6833af8f3656d8665a2888614f37bcb40dffef534474125202fc2`
- `tools/benchmark/prepare_calibration_capture_v2.py`: `248e8c4693357ec8d04d6cef7ad71ca801ae78332b66e65dcdb969c2a0e2a80b`
- `tests/benchmark/test_native_entry_dependencies.py`: `f2256454572cd3445e2f34d616149708172518e7dd1328d227e5fa5020071399`
- `tests/benchmark/test_calibration_study_v2.py`: `4cf6769d188662337903f0cf2cb55d621fa6207b93b0f04795a41f7ef4f87b5b`
- unchanged `tools/benchmark/prepare_calibration_capture.py`: `9113bd1148c9e529de2f0ab1a97b818f86766ba5e44a5d0c94133f0cb8f8c68d`

Preserved prior-report hashes: initial Markdown `4e2e4c88b774e79dc1286932a856ae9acd06ae9ccfcb6ee082d9c684fab22ddf`; initial JSON `ab84cdb5f5b1e4798ab3476de93ee988777cde82bfaaca183730da1344e8b7e5`; follow-up Markdown `5498768c64afab48cbac1824d48396fd32a6c842632e2b0befdc151011233d10`; follow-up JSON `6d2d4e221d39d82109d909a8119846d13adfec057cba7599288e7833bbbb29ad`.

## Final additive sign-off after the I7 writer fallback

The remaining I7 writer branch is resolved in the latest exact source. `prepare_calibration_capture_v2.py:158–171` now adds the first persistence error to `owner_row`, separately attempts `installed-license-query-failure.json`, and raises the preserved primary cause. If that fallback also fails, it adds an exception note without claiming durability. The saved fallback contains the actual partial query row and first write failure when the independent fallback is available.

`license-writer-red.stdout` retains a genuine behavioral failure: the first writer was deliberately failed and reading the absent fallback raised FileNotFoundError. `license-writer-green.stdout` then records **28 passed in 14.67s**, exit 0. `license-writer-ruff.stdout` records **All checks passed**, exit 0, for the changed producer/test. Both JSONs have before/after hashes matching the seven reviewed source/test/preparer files and explicitly record PYTHONPATH/PYTHONUTF8. The reviewer reran none of these commands.

Latest exact hashes are the same as the preceding snapshot except:

- `tools/benchmark/prepare_calibration_capture_v2.py`: `068f52eac326024a72cba0c06bf8fcca2bddc71536c5f279880540afc48cb7c0`
- `tests/benchmark/test_calibration_study_v2.py`: `2aac0dc006093349166f038b852e21269e4d638d7999e067871d6adaa40146e8`

**Ready to merge/seal: Yes, for Task 1 / Task 2 software only. Residual findings: C0 / I0 / M0.** The reviewed corrections resolve I1–I8. Author and independently review the concrete Task 3 coordinator/report and prospective command recipe next, retaining fresh admission/absence/source gates before any once-only execution. A prospective command/source expectation is not actual Linux pre-attestation; neither this sign-off nor the software tests prove native ELF/renderer acceptance, an SDK freeze, physical capture, source/calibration qualification or whole-goal completion. All eight qualifications remain false. The consumed preparer remains unchanged, and no native/resource/Git mutations were made by this reviewer.
