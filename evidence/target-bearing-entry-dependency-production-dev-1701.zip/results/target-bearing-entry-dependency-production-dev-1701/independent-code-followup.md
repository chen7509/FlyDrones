# Independent readonly follow-up — corrected Task 1 / Task 2

Review date: 2026-10-15. Base: `a71401009b604db97938cd68d7fbf6ffff0dbf91`. Initial `independent-code-review.md/json` are preserved. This follow-up reviews the corrected exact source, tests and retained failure/pass records. It does not include the pending coordinator or publication report and does not claim the whole plan complete.

No tests, native tools/SDK, process/resource queries, compiler, renderer, PX4, Agent or physical dispatch were executed by the reviewer. Readonly source inspection and existing evidence support the findings; the counterexamples below are source-branch reasoning, not executed REDs. Only these two follow-up artifacts were written.

## Resolved initial findings

- **I1 resolved.** Fresh trace-selected dependency paths are assigned to `graph:dependencies` before the general bill-file deduplication (`prepare_calibration_capture_v2.py:299–300`). The producer pipeline fixture now reaches the real `validate_binding`; retained `binding-pipeline-red-v4.stdout` contains the actual missing-role rejection, while the earlier bootstrap/import/NameError failures remain separately preserved. The final green fixture exercises that role gate without pretending its SDK/source stubs are native evidence.
- **I2 resolved.** `audit_entry_bill` compares recorded tool paths with `tool_paths()` at `native_entry_dependencies.py:439–441`. The retained self-consistent tool-substitution RED and corrected test exercise that exact guard.
- **I3 resolved.** `audit_v2_preparation` freshly uses `agent_runtime_record` and compares the exact selected binary/library paths and `lib_dir` at `calibration_capture_study_v2.py:48–52`. The shared study verifier separately reconstructs the actual execution contract, joining that declaration to the selected execution. The Agent-context mismatch RED is preserved.
- **I4 resolved in the entry bill producer.** Query and aggregate writes preserve an existing primary exception using notes, and query records retain `journal_error` (`native_entry_dependencies.py:268–280,376–386`). The retained combined dependency/writer RED and current test check the aggregate primary cause. The new package-query path has a separate residual finding below.
- **I5 resolved.** Terminate is guarded independently before the first bounded wait, timeout-triggered kill, and second bounded wait (`native_entry_dependencies.py:87–108`). The initial fake None-pipe fixture failure is not treated as behavior evidence; `cleanup-behavior-red.stdout` separately shows only `terminate` was called before the fix. The corrected fixture asserts the full action sequence.
- **I6's missing clock fields resolved.** V2 adds a scope-before clock sidecar, an after-scope UTC/monotonic/elapsed record, bounded paired-clock package querying, SDK clock sidecars, and raw-query clock auditing. Raw-hash and final-counter failures preserve an existing primary cause (`prepare_calibration_capture_v2.py:80–115,202,419–451`). The initial scope elapsed RED, raw-hash/primary RED and missing auditor-interface RED remain distinct. The audit still has the narrower interval-join gap below.

## Strengths and retained validation

The corrected implementation retains literal v2 routing, original workload/safety/mapping requirements, fresh candidate file records, immutable Agent deployment reuse, and all eight false qualifications. The consumed preparer has unchanged raw SHA `9113bd1148c9e529de2f0ab1a97b818f86766ba5e44a5d0c94133f0cb8f8c68d`.

`final-neighbor.stdout` records **256 passed / 3 skipped in 31.57s**; `final-ruff.stdout` records **All checks passed**. Their JSON source-before/source-after identities match the exact seven source/test/preparer files listed below, and declare PYTHONPATH/PYTHONUTF8. Earlier three-source/missing environment metadata is not backfilled. `clocks-green.stdout` itself contains 24 passes / 1 NameError failure despite its filename; the corrected fixture and final neighbor run provide the actual later green. The new production folder is absent in the reviewed checkout. No result establishes native ELF/renderer acceptance, an actual SDK freeze, mapped closure, sensor source or physics execution.

## Residual issues

### Critical (C)

None found.

### Important (I)

1. **I7 — The new package-query post-pin/write path can discard the actual bounded call.** `tools/benchmark/prepare_calibration_capture_v2.py:137–138` obtains `_run_tool`'s completed/partial result, then evaluates `file_record(tool['requested'])` and writes `package-owner-query.json` before establishing any primary/persistence guard. If that post-pin read fails, or the manifest write fails after a timeout/nonzero query, the actual argv/pid/partial output/exit/cleanup row is not retained elsewhere. The enclosing preparation failure records only the newer exception; the later license-observation finally is not reached because it begins at line 162. This recreates the evidence-loss condition fixed for dependency calls in I4, now in newly introduced code. Establish the package record immediately after `_run_tool`, preserve the query's existing failure separately from post-pin/persistence failures, and attempt an aggregate/fallback record with the actual query row in `finally`. Add a software fixture for a failed package query plus post-pin/write failure; the producer-pipeline fixture currently replaces `licenses` entirely. This is a software correction before the once-only static attempt, not a reason to run a new native probe.

2. **I8 — SDK paired-clock audit is not joined to the query's own local interval.** `tools/benchmark/calibration_capture_study_v2.py:62–75` verifies sidecar arithmetic, UTC form, command and raw-file digest, but never compares the sidecar's start/end with the retained query's `started_monotonic`/`ended_monotonic`. Both are measured on the same host by the wrapper and `QueryClient`. For example, replacing a clock's start/end/elapsed with coherent `0/0/0` leaves every checked condition true while the raw query may span a nonzero interval. Reversed ordering between successive sidecar intervals is likewise unchecked. Thus the new audit cannot reject internally coherent clock rows that do not cover their actual calls. Require each wrapper interval to enclose its raw query interval and require sequential sidecar ordering, accounting explicitly for float-to-nanosecond representation; retain UTC only as local wall facts and do not infer cross-host nesting. Add a software RED using coherent displaced endpoints, rather than only the current `elapsed += 1` arithmetic corruption. This is the remaining audit barrier to trusting the new per-call clock evidence.

### Minor (M)

None separately classified.

## Declined to judge

- Coordinator first-admission/claim/owned-scope identity/once-only stop and publication behavior: Task 3 source/report not supplied in this review; those remain a concrete separate deliverable.
- Installed normal ELF parser acceptance and renderer entry outcome: still untested by actual production execution, intentionally not run here.
- Windows skipped symlink tests: retained as skips, not relabeled as passes or native alias evidence.
- Full physical/runtime mapped closure, sensor/clock/source qualification, Kalibr and full learning/fair-baseline objectives: explicitly pending outside software preparation.
- Continuous atomic filesystem/memory identity and full transitive license/distro-build certification: explicitly excluded/pending in the design.

## Assessment

**Ready to merge: With fixes.** The original six issues are corrected and the exact software regressions pass, but I7–I8 need small software fixes before a real once-only static attempt. Coordinator/report authoring can proceed as the next concrete deliverable; its admission remains dependent on these fixes, independent review, and the unchanged fresh resource/absence gates. This review does not recommend or authorize additional native probes.

## Exact source snapshot (raw-byte SHA256)

- `tools/benchmark/native_entry_dependencies.py`: `38bdb30431abb6d399f0a79c20671c7a7d75ecf444436b7a0d956f08bed988ea`
- `tools/benchmark/calibration_capture_study.py`: `bf8f082cf5fda77a20fe8876c0b83b1f4ae9c329c3ebe992768e7afb75378b11`
- `tools/benchmark/calibration_capture_study_v2.py`: `a8051abed17d654f5779cffb1dadf2382ad4b34001617b50c2c846325f1bdfd3`
- `tools/benchmark/prepare_calibration_capture_v2.py`: `a5e52e99dcee91c17f2c5ccdcc391146675313b0859fb5e7b59d207feef0f833`
- `tests/benchmark/test_native_entry_dependencies.py`: `ef90123623797d05f3ecb4a39b1d21a4bb02b7f2a21d2db65642d970c1f21a4b`
- `tests/benchmark/test_calibration_study_v2.py`: `a4b33a265f04cf98016bb9657b5750590131d5839aebec89e8d50a81f38ff38a`
- `tools/benchmark/prepare_calibration_capture.py`: `9113bd1148c9e529de2f0ab1a97b818f86766ba5e44a5d0c94133f0cb8f8c68d`
- verification harness `results/target-bearing-entry-dependency-production-dev-1701/verify.py`: `5b1b14c561619540aec7d1adc52dd1563659c12a16800efd945cfad39a3be918`
