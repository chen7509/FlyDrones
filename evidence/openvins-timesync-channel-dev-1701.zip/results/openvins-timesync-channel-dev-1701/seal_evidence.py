"""Seal only this research, using exclusive writes; preserve prior evidence."""
import hashlib
import json
import zipfile
from pathlib import Path

out = Path(__file__).resolve().parent
root = out.parents[1]
archive = root / 'evidence/openvins-timesync-channel-dev-1701.zip'
external = root / 'evidence/openvins-timesync-channel-dev-1701-manifest.json'
sha = lambda blob: hashlib.sha256(blob).hexdigest()
if archive.exists() or external.exists():
    raise FileExistsError('already sealed')
previous = json.loads((root / 'evidence/openvins-timesync-listener-dev-1701-manifest.json').read_text())
assert sha((root / previous['archive']).read_bytes()) == previous['sha256']
selected = [root / 'docs/OPENVINS_TIMESYNC_CHANNEL_REPORT.md',
            root / 'docs/superpowers/plans/2026-10-07-openvins-ekf2-shadow-integration.md',
            root / '.superpowers/sdd/2026-10-07-openvins-ekf2-shadow-integration/progress.md']
selected += [p for p in out.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
members = {p.relative_to(root).as_posix(): p.read_bytes() for p in selected}
manifest = {name: {'sha256': sha(blob), 'bytes': len(blob)} for name, blob in sorted(members.items())}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for name, blob in members.items():
        z.writestr(name, blob)
    z.writestr('member-manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(set(z.namelist())) == len(manifest) + 1
    for name, record in manifest.items():
        blob = z.read(name)
        assert sha(blob) == record['sha256'] and len(blob) == record['bytes']
summary = {'archive': archive.relative_to(root).as_posix(),
           'sha256': sha(archive.read_bytes()), 'members': len(manifest) + 1,
           'bytes': archive.stat().st_size, 'crc_verified': True,
           'member_hashes_verified': True, 'previous_listener_archive_unchanged': True}
with external.open('x') as f:
    json.dump(summary, f, indent=2)
print(json.dumps(summary))
