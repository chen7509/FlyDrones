# Next dependency: owned isolated launch, then first-status bootstrap

Read this stage's report/source findings and existing capture supervisor;
do not repeat the normal namespace fixture or prior status/float experiments.

1. Design one small explicit user+net namespace wrapper for a declared command.
   No host root, external interface, veth, bridge, proxy or inherited network FD.
   Validate inode identities/topology and actual UID mapping before command exec.
   Include selected unshare/ip/Python/runtime libraries in existing binding.
   Keep host filesystem/PX4 command socket ownership separate; no mount changes.
2. Synthetic ordinary-process tests only: creation/setup failure, unchanged net
   namespace, foreign/inherited sockets, wrong topology/mapping, identity drift,
   partial journal, child failure and cleanup. Reuse the owned-group supervisor
   so launch failure cannot silently expand to a competing study. Do not turn
   a one-off successful research script into production code without these tests.
3. Explicitly model bootstrap: actual fresh PX4 lifecycle, chosen API endpoint,
   no other internal responders, one reserved reply before first status read,
   discovered/verified uORB association, then serial decoder+observer. A selected
   peer or source_protocol0 alone is insufficient. Forwarding is outbound, not
   automatic filter cross-update. Missing/extra/prior/ambiguous status refuses.
4. Keep legacy host launch unqualified; no automatic fallback to a host network.
   Namespace fixture did not exercise Gazebo discovery/rendering or UID-sensitive
   paths. Live compatibility/rate remains untested and requires the existing
   separate live-stage authorization, not a renamed probe.

Scope is still corrected offline Task4, not live Task5. No ODOMETRY, real stream
change, EKF2 parameters, arming, new physics, training or scaling. Do not weaken
25s/8s/2s/500accepted requirements. Report a measured host limitation honestly if
future real acceptance is infeasible, and continue other independent authorized
work rather than converting protocol infrastructure into the project goal.
