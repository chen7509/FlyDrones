"""Capture primary API/source references without opening any simulation."""
import datetime
import hashlib
import json
import urllib.request
from pathlib import Path

out = Path(__file__).resolve().parent
queries = {
    'unshare-v2.39.3.c': 'https://raw.githubusercontent.com/util-linux/util-linux/v2.39.3/sys-utils/unshare.c',
    'network_namespaces.html': 'https://man7.org/linux/man-pages/man7/network_namespaces.7.html',
    'unshare.html': 'https://man7.org/linux/man-pages/man1/unshare.1.html',
    'util-linux-metadata.json': 'https://api.github.com/repos/util-linux/util-linux',
    'px4-metadata.json': 'https://api.github.com/repos/PX4/PX4-Autopilot',
}
records = []
for name, url in queries.items():
    record = {'name': name, 'url': url,
              'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    try:
        request = urllib.request.Request(url, headers={'User-Agent': 'FlyDrones-source-research'})
        with urllib.request.urlopen(request, timeout=15) as response:
            blob = response.read()
        with (out / name).open('xb') as f:
            f.write(blob)
        record.update(sha256=hashlib.sha256(blob).hexdigest(), bytes=len(blob))
    except Exception as exc:
        record['error'] = repr(exc)
    records.append(record)
with (out / 'namespace-references.json').open('x') as f:
    json.dump(records, f, indent=2)
print(json.dumps(records, indent=2))
