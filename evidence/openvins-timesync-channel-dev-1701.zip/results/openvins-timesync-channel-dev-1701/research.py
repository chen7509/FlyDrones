"""Read-only fixed source provenance for the bounded channel research."""
import hashlib
import json
import subprocess
import urllib.request
from pathlib import Path

OUT = Path(__file__).resolve().parent
PX4 = Path('/home/yuchen7509/PX4-Autopilot')
PIN = 'd6f12ad1c4f70ad3230afd7d86e971421e02fef4'
PATHS = [
    'ROMFS/px4fmu_common/init.d-posix/px4-rc.mavlink',
    'src/modules/mavlink/mavlink_receiver.cpp',
    'src/modules/mavlink/mavlink_timesync.cpp',
    'src/modules/mavlink/mavlink_timesync.h',
    'src/modules/mavlink/mavlink_main.cpp',
    'src/lib/timesync/Timesync.hpp',
    'platforms/common/uORB/PublicationMulti.hpp',
    'platforms/common/uORB/uORBDeviceMaster.cpp',
]


def save(name, value):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(value)


records = []
for name in PATHS:
    url = f'https://raw.githubusercontent.com/PX4/PX4-Autopilot/{PIN}/{name}'
    installed = (PX4 / name).read_bytes()
    save('installed/' + name, installed)
    try:
        with urllib.request.urlopen(url, timeout=20) as response:
            remote = response.read()
        save('upstream/' + name, remote)
        record = dict(path=name, url=url, equal=installed == remote,
                      installed_sha256=hashlib.sha256(installed).hexdigest(),
                      upstream_sha256=hashlib.sha256(remote).hexdigest())
    except Exception as exc:
        record = dict(path=name, url=url, error=repr(exc))
    records.append(record)
save('sources.json', json.dumps(records, indent=2).encode())
commands = [['uname', '-a'], ['id'], ['unshare', '--version'], ['ip', '-Version'],
            ['dpkg-query', '-W', 'util-linux', 'iproute2', 'libc6', 'python3.12']]
versions = []
for command in commands:
    result = subprocess.run(command, capture_output=True, text=True, timeout=5)
    versions.append(dict(command=command, code=result.returncode,
                         stdout=result.stdout, stderr=result.stderr))
save('versions.json', json.dumps(versions, indent=2).encode())
for package in ['util-linux', 'iproute2']:
    save(package + '-copyright.txt', Path('/usr/share/doc/' + package + '/copyright').read_bytes())
print(json.dumps(records, indent=2))
