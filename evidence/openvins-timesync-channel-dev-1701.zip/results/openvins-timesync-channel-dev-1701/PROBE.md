# Cold-channel feasibility probe (prospective)

Parent: 1287acaf3c2abae5e45e4f2ef20b1596905bb92e. Scope is a research
probe, not a production launcher. User has preapproved offline research; live
PX4/ODOMETRY/parameter/stream mutation remains unauthorized.

Question: can this installed WSL isolate ordinary competing host UDP producers
without patching pinned PX4? Peer address selection is not an ingress ACL in
the fixed receiver. A new companion process is not a cold PX4 filter.

Source review: compare installed startup, receiver, forwarding, Timesync and
PublicationMulti/DeviceMaster against d6f12ad. Inspect per-receiver ownership,
first-publication instance allocation and forwarding direction, without assuming
that one MAVLink channel number equals a uORB instance.

Experiment: one default-user `unshare --user --map-root-user --net` child,
loopback only, no veth, host network/route/firewall edits or root host command.
Parent owns an ephemeral UDP port; child binds the same port in its new namespace.
Send unique non-MAVLink tokens in host and child. Two child peer sockets must both
reach the child receiver, demonstrating that namespace separation is not a peer
ACL inside that namespace. Host token must remain on the host socket. Verify
namespace identities, interface/address/route inventories, uid/gid maps, binary
hashes, finite waits, exit and cleanup. Inherited file descriptors are only pipes;
no host socket is passed into child. No timing result qualifies a PX4 deadline.

Refuse unknown namespace identity, inherited non-loopback interface, failed ip,
unexpected payload/source, timeout, drift or incomplete exit. Preserve failures;
do not auto-retry. A negative capability or isolation result changes the next
design; it does not justify relaxing exclusivity or declaring VIO failure.

Limits: no hostile process/administrator protection, PX4 or Gazebo compatibility,
uORB startup, accepted sample throughput, socket-file/mount isolation or production
supervisor qualification. A future owned study must control its internal peers,
forbid inherited network FDs and record actual identities. File-system UNIX socket
paths remain shared. No live authority is granted by this probe.
