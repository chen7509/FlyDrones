"""Verify retained fixture and selected source evidence, without rerunning it."""
import ast
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
fixture = json.loads((root / 'namespace-probe.json').read_text())
assert fixture['qualification'] is True
assert fixture['before'] == fixture['after']
assert fixture['child_exit'] == fixture['final_child_exit'] == 0
assert 'error' not in fixture and 'emergency_kill' not in fixture
ready = fixture['child_ready']
assert ready == json.loads(fixture['ready_raw'])
assert ready['identity']['net'] != fixture['before']['identity']['net']
assert ready['identity']['user'] != fixture['before']['identity']['user']
assert ready['identity']['uid_map'].split() == ['0', '1000', '1']
assert ready['identity']['gid_map'].split() == ['0', '1000', '1']
assert [v['ifname'] for v in ready['after']['links']] == ['lo']
received = json.loads(fixture['child_stdout'])
assert len(received['received']) == 2 and received['unexpected'] is None
assert received['received'][0]['peer'] != received['received'][1]['peer']
assert fixture['host_unexpected'] is None
assert all(v['payload'] != fixture['host_received']['payload'] for v in received['received'])
assert fixture['before']['hashes'][next(k for k in fixture['before']['hashes']
    if k.endswith('/namespace_probe.py'))] == hashlib.sha256((root / 'namespace_probe.py').read_bytes()).hexdigest()
sources = json.loads((root / 'sources.json').read_text())
assert len(sources) == 8
for source in sources:
    for flavor in ['installed', 'upstream']:
        blob = (root / flavor / source['path']).read_bytes()
        assert hashlib.sha256(blob).hexdigest() == source[flavor + '_sha256']
    assert source['equal'] is True
references = json.loads((root / 'namespace-references.json').read_text())
for item in references:
    assert 'error' not in item
    blob = (root / item['name']).read_bytes()
    assert len(blob) == item['bytes'] and hashlib.sha256(blob).hexdigest() == item['sha256']
for script in root.glob('*.py'):
    ast.parse(script.read_text())
record = {'selected_source_pairs': 8, 'primary_references': len(references),
          'fixture_record_consistent': True, 'producer_script_hash_matches': True,
          'scope': 'retained evidence verification, no new UDP/PX4 execution',
          'production_launcher_qualified': False, 'fusion_qualified': False}
with (root / 'verification.json').open('x') as stream:
    json.dump(record, stream, indent=2)
print(json.dumps(record))
