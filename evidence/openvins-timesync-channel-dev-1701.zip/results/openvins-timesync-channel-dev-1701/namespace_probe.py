"""Throwaway research fixture; never launches PX4 or sends MAVLink bytes."""
import hashlib
import json
import os
import secrets
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path

OUT = Path(__file__).resolve().parent


def command(args):
    r = subprocess.run(args, capture_output=True, text=True, timeout=3, check=True)
    return json.loads(r.stdout)


def identity():
    return {'net': os.readlink('/proc/self/ns/net'),
            'user': os.readlink('/proc/self/ns/user'), 'pid': os.getpid(),
            'uid': os.getuid(), 'gid': os.getgid(),
            'uid_map': Path('/proc/self/uid_map').read_text(),
            'gid_map': Path('/proc/self/gid_map').read_text()}


def topology():
    return {'links': command(['/usr/sbin/ip', '-j', 'link']),
            'addresses': command(['/usr/sbin/ip', '-j', 'address']),
            'routes': command(['/usr/sbin/ip', '-j', 'route', 'show', 'table', 'all'])}


def hashes():
    return {p: hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in
            [str(Path(__file__).resolve()), '/usr/bin/unshare', '/usr/sbin/ip',
             str(Path(sys.executable).resolve())]}


def receive(sock):
    data, peer = sock.recvfrom(1024)
    return {'payload': data.decode('ascii'), 'peer': list(peer)}


def child(port):
    before = topology()
    assert [x['ifname'] for x in before['links']] == ['lo']
    subprocess.run(['/usr/sbin/ip', 'link', 'set', 'lo', 'up'], check=True, timeout=3)
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as receiver:
        receiver.settimeout(1)
        receiver.bind(('127.0.0.1', port))
        print(json.dumps({'identity': identity(), 'before': before, 'after': topology(),
                          'bound': list(receiver.getsockname())}), flush=True)
        request = json.loads(sys.stdin.readline())  # Parent has a whole-child timeout.
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as a, \
                socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as b:
            a.bind(('127.0.0.1', 0))
            b.bind(('127.0.0.1', 0))
            a.sendto(request['a'].encode(), receiver.getsockname())
            first = receive(receiver)
            b.sendto(request['b'].encode(), receiver.getsockname())
            second = receive(receiver)
            assert first['payload'] == request['a'] and second['payload'] == request['b']
            assert first['peer'] != second['peer']
        try:
            extra = receive(receiver)
        except TimeoutError:
            extra = None
        assert extra is None
        print(json.dumps({'received': [first, second], 'unexpected': extra}), flush=True)


def parent():
    import selectors
    baseline = {'identity': identity(), 'topology': topology(), 'hashes': hashes()}
    data = {'before': baseline, 'qualification': False}
    with (OUT / 'namespace-probe.json').open('x') as stream:
        process = None
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as host:
                host.settimeout(1)
                host.bind(('127.0.0.1', 0))
                port = host.getsockname()[1]
                argv = ['/usr/bin/unshare', '--user', '--map-root-user', '--net',
                        sys.executable, '-u', str(Path(__file__).resolve()), '--child', str(port)]
                data['command'] = argv
                process = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                           stderr=subprocess.PIPE, start_new_session=True,
                                           close_fds=True)
                with selectors.DefaultSelector() as selector:
                    selector.register(process.stdout, selectors.EVENT_READ)
                    deadline = time.monotonic() + 5
                    ready_line = b''
                    while not ready_line.endswith(b'\n'):
                        remaining = deadline - time.monotonic()
                        if remaining <= 0 or not selector.select(remaining):
                            raise TimeoutError('child readiness absent/incomplete')
                        chunk = os.read(process.stdout.fileno(), 65536)
                        if not chunk:
                            raise ValueError('child exited before readiness')
                        ready_line += chunk
                        if len(ready_line) > 65536:
                            raise ValueError('oversize child readiness')
                data['ready_raw'] = ready_line.decode()
                ready = json.loads(ready_line)
                data['child_ready'] = ready
                assert ready['identity']['net'] != baseline['identity']['net']
                assert ready['identity']['user'] != baseline['identity']['user']
                assert ready['bound'] == list(host.getsockname())
                token = 'host-' + secrets.token_hex(16)
                host.sendto(token.encode(), host.getsockname())
                got = receive(host)
                data['host_received'] = got
                assert got['payload'] == token
                request = {'a': 'child-A-' + secrets.token_hex(16),
                           'b': 'child-B-' + secrets.token_hex(16)}
                output, errors = process.communicate(json.dumps(request).encode() + b'\n', timeout=5)
                data.update(child_stdout=output.decode(), child_stderr=errors.decode(),
                            child_exit=process.returncode)
                assert process.returncode == 0
                parsed = json.loads(output)
                assert [x['payload'] for x in parsed['received']] == [request['a'], request['b']]
                try:
                    host_extra = receive(host)
                except TimeoutError:
                    host_extra = None
                data['host_unexpected'] = host_extra
                assert host_extra is None
                data['after'] = {'identity': identity(), 'topology': topology(), 'hashes': hashes()}
                assert data['after'] == baseline
                data['qualification'] = True
        except BaseException as exc:
            data['error'] = repr(exc)
            raise
        finally:
            if process is not None and process.poll() is None:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=3)
                data['emergency_kill'] = True
            data['final_child_exit'] = None if process is None else process.returncode
            json.dump(data, stream, indent=2)
    print(json.dumps({'isolated_udp_fixture_pass': data['qualification'],
                      'px4_channel_qualified': False, 'fusion_qualified': False}))


if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == '--child':
        child(int(sys.argv[2]))
    elif len(sys.argv) == 1:
        parent()
    else:
        raise ValueError('unsupported research arguments')
