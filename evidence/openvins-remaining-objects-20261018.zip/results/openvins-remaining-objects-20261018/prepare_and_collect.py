"""Prepare the newly authorized remaining-file selection; one readonly Windows child."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
PRIOR = ['results/native-linux-file-receipts-20261018', 'results/openvins-build-provenance-20261018']


def save(name,value):
    with (OUT/name).open('x',encoding='utf-8') as f:
        json.dump(value,f,indent=2,ensure_ascii=True)


excluded = {}
searched_logs = {}
references = []
for prefix in PRIOR:
    raw = (ROOT/prefix/'current-files.json').read_bytes()
    references.append(dict(path=prefix+'/current-files.json',sha256=hashlib.sha256(raw).hexdigest()))
    for name,row in json.loads(raw).items():
        if row.get('blob'):
            excluded[name] = dict(phase=prefix,blob=row['blob'],bytes=row['bytes'],sha256=row['sha256'])
        if row.get('role') == 'build-log-or-dependency':
            searched_logs[name] = dict(phase=prefix,status=row['status'])
oldout = ROOT/PRIOR[1]
associations = json.loads((oldout/'selection-contract.json').read_bytes())['associations']
remaining = json.loads((oldout/'missing-evidence.json').read_bytes())['unobserved_objects']
objects = [r for r in associations if r['object'] in {v['object'] for v in remaining}]
assert len(objects) == 19 and all(r['object'] not in excluded for r in objects)
source = '/home/yuchen7509/flydrones-upstream/open_vins'
roots = [dict(path=source,policy='project'),
         *[dict(path=source+'/'+name,policy='project') for name in ('ov_core','ov_init','ov_msckf')],
         dict(path='/home/yuchen7509/flydrones-upstream',policy='external-top'),
         dict(path='/tmp',policy='external-top')]
save('selection-contract.json',dict(schema='openvins-remaining-selection-v1',prior_manifest_references=references,
    previously_acquired_paths=excluded,previously_searched_log_paths=searched_logs,
    associations=objects,all_associations=associations,source_root=source,
    build_root=source+'/ov_msckf/build',log_search_roots=roots,
    log_directory_names=['log','logs','build_logs','build-logs','build','CMakeFiles'],
    log_search_max_depth=4,
    log_name_policy='project: build/compile/link/configure/cmake/make/ninja + .log/.out/.err/.txt/.stdout/.stderr/.yaml; external-top: also explicit OpenVINS name; no .git/history/other projects',
    deliberately_not_reprobed=[source+'/ov_msckf/build/libov_msckf_lib.so'],
    limits=dict(file_bytes=67108864,aggregate_payload_bytes=201326592,selected_paths=6000,
        directory_entries=20000,read_seconds=27,parent_wait_seconds=30,terminate_wait_seconds=5,
        kill_wait_seconds=5,outer_seconds=45),
    source_to_existing_library_proven=False,all_qualifications=False))
save('collection-start.json',dict(utc=datetime.datetime.now(datetime.UTC).isoformat(),
    argv=[sys.executable,str(OUT/'collect_remaining_files.py')],cwd=str(ROOT),
    linux_access='Windows standard readonly file I/O only',limits='selection-contract.json',
    env_policy='inherited Windows environment, not a complete captured environment'))
started=time.monotonic()
result=dict(complete=False)
with (OUT/'collection.stdout').open('xb') as stdout,(OUT/'collection.stderr').open('xb') as stderr:
    child=subprocess.Popen([sys.executable,str(OUT/'collect_remaining_files.py')],cwd=ROOT,stdout=stdout,stderr=stderr)
    result['owned_windows_child_pid']=child.pid
    try:
        result['returncode']=child.wait(timeout=30)
        result['complete']=result['returncode']==0
    except subprocess.TimeoutExpired:
        result['parent_timeout']=True
        child.terminate()
        try:
            result['returncode']=child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            child.kill()
            try:
                result['returncode']=child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                result['cleanup_unknown']=True
result['elapsed_seconds']=time.monotonic()-started
save('collection-parent-completion.json',result)
print(json.dumps(result))
