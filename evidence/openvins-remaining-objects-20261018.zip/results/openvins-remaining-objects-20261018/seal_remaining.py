"""Verify and seal only newly retained remaining-object evidence, never Linux files."""
import ast
import hashlib
import json
from pathlib import Path
import zipfile

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
POST=OUT/'postseal'
FILES=['docs/OPENVINS_REMAINING_OBJECTS_PROGRESS.md','docs/superpowers/plans/2026-10-18-openvins-remaining-objects.md']
FILES+=['results/openvins-remaining-objects-20261018/'+n+'.json' for n in (
    'file-bindings','object-static-observations','object-union-bindings','log-search-observations','analysis-summary','missing-evidence')]


def sha(raw):return hashlib.sha256(raw).hexdigest()


s=json.loads((OUT/'analysis-summary.json').read_bytes())
c=json.loads((OUT/'selection-contract.json').read_bytes())
f=json.loads((OUT/'current-files.json').read_bytes())
assert s['status_counts']==dict(observed=10,file_cap=1,aggregate_cap=1)
assert len(f)==12 and set(f).isdisjoint(c['previously_acquired_paths'])
assert s['new_static_rel_x86_64']==10 and not s['object_parse_errors']
assert s['actual_payload_bytes_read']==s['new_observed_payload_bytes']==201271200<201326592
assert s['total_objects_with_retained_bytes']==25 and s['objects_remaining_unknown']==9
assert s['new_log_payloads']==s['new_log_candidates']==0
assert s['searched_directories']==8 and s['stable_search_directories']==7
assert s['unstable_or_failed_search_directories']==['/tmp']
assert not s['acquisition_complete'] and not s['source_to_existing_library_proven']
assert s['current_library_sha256'] is None and s['native_admission'] is False
for name,row in f.items():
    if row['status']=='observed':
        raw=(OUT/row['blob']).read_bytes()
        assert len(raw)==row['bytes']<=67108864 and sha(raw)==row['sha256']
        assert row['before']==row['after']
    elif row['status']=='file_cap':assert row['before']['size']==81028080 and 'blob' not in row
    elif row['status']=='aggregate_cap':assert row['before']['size']==45073752 and 'blob' not in row
for p in OUT.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'),filename=str(p))
with (OUT/'self-check.json').open('x',encoding='utf-8') as stream:
    json.dump(dict(scope='Executor new saved payload/JSON/helperAST only; no old archive/tests/source/native/delivery review.',
        new_files_verified=10,new_objects_static_rel_x86_64=10,prior_path_overlap=0,
        aggregate_read_stopped=True,total_retained_objects=25,objects_unknown=9,
        no_new_log_payload=True,log_search_all_locations_complete=False,
        current_library_sha256=None,source_to_existing_library_proven=False,
        native_commands=False,resource_queries=False,tests_run=False,all_qualifications=False),stream,indent=2)
paths=set(FILES)
for p in OUT.rglob('*'):
    if 'postseal' in p.relative_to(OUT).parts or '__pycache__' in p.parts or p.suffix=='.pyc':continue
    if p.is_file() and not p.is_symlink():paths.add(p.relative_to(ROOT).as_posix())
mapping={}
archive=ROOT/'evidence/openvins-remaining-objects-20261018.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as output:
    for name in sorted(paths):
        raw=(ROOT/name).read_bytes();mapping[name]=dict(bytes=len(raw),sha256=sha(raw))
        entry=zipfile.ZipInfo(name,(2026,10,18,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;entry.external_attr=0o100600<<16
        output.writestr(entry,raw)
    manifest=json.dumps(dict(schema='openvins-remaining-object-evidence-archive-v1',mapping=mapping,
        note='Newly authorized remaining object selection and bounded filtered log search; partial, not old library provenance or native admission.'),sort_keys=True,indent=2).encode()
    output.writestr('manifest.json',manifest)
with zipfile.ZipFile(archive) as source:
    assert source.testzip() is None and len(source.namelist())==len(mapping)+1
    for name,row in mapping.items():assert sha(source.read(name))==row['sha256']
receipt=dict(schema='openvins-remaining-objects-seal-v1',archive=archive.relative_to(ROOT).as_posix(),bytes=archive.stat().st_size,
    sha256=sha(archive.read_bytes()),members=len(mapping)+1,mapped=len(mapping),
    mapped_payload_bytes=sum(r['bytes'] for r in mapping.values()),manifest_bytes=len(manifest),
    whole_expanded_bytes=sum(r['bytes'] for r in mapping.values())+len(manifest),software_files=FILES,
    source_to_existing_library_proven=False,native_admission=False,all_qualifications=False)
with archive.with_suffix('.sha256.json').open('x',encoding='utf-8') as stream:json.dump(dict(**receipt,mapping=mapping),stream,indent=2)
POST.mkdir(exist_ok=False)
with (POST/'seal-receipt.json').open('x',encoding='utf-8') as stream:json.dump(receipt,stream,indent=2)
print(json.dumps({k:v for k,v in receipt.items() if k!='software_files'}))
