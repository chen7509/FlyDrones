"""Saved Windows bytes only; retain unknown build provenance, never load/execute ELF."""
import collections
import hashlib
import json
from pathlib import Path
import posixpath
import struct

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
contract=json.loads((OUT/'selection-contract.json').read_bytes())
files=json.loads((OUT/'current-files.json').read_bytes())
completion=json.loads((OUT/'collection-completion.json').read_bytes())
build=contract['build_root']


def save(name,value):
    with (OUT/name).open('x',encoding='utf-8') as stream:json.dump(value,stream,indent=2,ensure_ascii=True)


def data(row):
    raw=(OUT/row['blob']).read_bytes()
    assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
    return raw


def elf_object(raw, source):
    if raw[:6] != b'\x7fELF\x02\x01' or len(raw) < 64:
        raise ValueError('only complete ELF64 little endian observations supported')
    etype, machine = struct.unpack_from('<HH', raw, 16)
    shoff = struct.unpack_from('<Q', raw, 40)[0]
    entsize, count, namesidx = struct.unpack_from('<HHH', raw, 58)
    if entsize != 64 or count == 0 or namesidx == 65535:
        raise ValueError('unsupported extended section indexing')
    if count > 65534 or shoff+count*64 > len(raw) or namesidx >= count:
        raise ValueError('invalid section table')
    sections = [struct.unpack_from('<IIQQQQIIQQ', raw, shoff+i*64) for i in range(count)]
    ns = sections[namesidx]
    if ns[4]+ns[5] > len(raw):
        raise ValueError('invalid section name bytes')
    names = raw[ns[4]:ns[4]+ns[5]]
    selected = {}
    for s in sections:
        end = names.index(b'\0', s[0])
        name = names[s[0]:end].decode('ascii', errors='backslashreplace')
        if s[1] != 8 and s[4]+s[5] > len(raw):
            raise ValueError('section outside retained object')
        if name in ('.comment', '.debug_line_str', '.debug_str', '.debug_info', '.text', '.symtab'):
            selected[name] = dict(offset=s[4], bytes=s[5], flags=s[2])
    result = dict(elf_class=64, little_endian=True, e_type=etype, machine=machine,
                  section_count=count, selected_sections=selected, executed_or_loaded=False,
                  source_to_object_proven=False, object_to_library_proven=False)
    comment = selected.get('.comment')
    if comment:
        result['comment_strings'] = [x.decode('utf-8', errors='backslashreplace')
            for x in raw[comment['offset']:comment['offset']+comment['bytes']].split(b'\0') if x]
    line = selected.get('.debug_line_str')
    if line and not line['flags'] & 2048:
        text = raw[line['offset']:line['offset']+line['bytes']]
        strings = text.split(b'\0')
        result['debug_line_string_observations'] = dict(
            exact_source_path_present=source.encode() in strings,
            source_basename_present=posixpath.basename(source).encode() in strings,
            build_path_present=build.encode() in strings,
            note='String-table occurrences only; not DWARF DIE/path/relocation attribution or source digest.')
    return result


bindings={};static={}
for name,row in files.items():
    assert name not in contract['previously_acquired_paths']
    assert name in {r['object'] for r in contract['associations']}
    if row['status']=='observed':
        raw=data(row)
        assert row['before']==row['after']
        bindings[name]=dict(**row,native_identity_verified=False,native_admission=False)
        source=next(r['source'] for r in contract['associations'] if r['object']==name)
        try:static[name]=elf_object(raw,source)
        except (ValueError,IndexError,struct.error) as exc:static[name]=dict(parse_error=repr(exc),source_to_object_proven=False)
save('file-bindings.json',dict(schema='openvins-remaining-object-observations-v1',files=bindings,
    all_qualifications=False,source_to_existing_library_proven=False))
save('object-static-observations.json',dict(schema='openvins-remaining-object-static-v1',objects=static,
    note='Static saved-byte ELF/strings observations only; no loading/execution, ABI, historical compiler identity or source-content proof.'))

prior_rows={}
for ref in contract['prior_manifest_references']:
    raw=(ROOT/ref['path']).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==ref['sha256']
    prior_rows.update(json.loads(raw))
union=[]
for item in contract['all_associations']:
    name=item['object'];row=files.get(name)
    entry=dict(source=item['source'],object=name,depfile=item['depfile'],
        source_to_object_proven=False,object_to_library_proven=False,historical_same_build_session_proven=False)
    if row:
        entry['this_collection_status']=row['status']
        entry['this_collection_metadata']=row.get('before')
        if row.get('blob'):
            entry['retained_observation']=dict(phase='results/openvins-remaining-objects-20261018',
                blob=row['blob'],bytes=row['bytes'],sha256=row['sha256'],same_build_time_input_proven=False)
    elif name in contract['previously_acquired_paths']:
        entry['this_collection_status']='excluded_previously_acquired'
        entry['retained_observation']=dict(**contract['previously_acquired_paths'][name],same_build_time_input_proven=False)
    else:entry['this_collection_status']='not_attempted_after_stop'
    d=prior_rows.get(item['depfile'])
    if d and d.get('blob'):
        entry['previous_depfile_observation']=dict(phase='results/openvins-build-provenance-20261018',
            blob=d['blob'],bytes=d['bytes'],sha256=d['sha256'],historical_input_bytes_proven=False)
    union.append(entry)
save('object-union-bindings.json',dict(schema='openvins-multicollection-object-correspondence-v1',units=union,
    association_basis='Prior actual DependInfo and link-name observations; not main build execution or content inputs.',
    atomic_snapshot=False,historical_same_build_session_proven=False,source_to_existing_library_proven=False))

directories=json.loads((OUT/'directory-listings.json').read_bytes())
search=dict(schema='openvins-bounded-log-search-observations-v1',
    search_roots=contract['log_search_roots'],name_policy=contract['log_name_policy'],
    max_depth=contract['log_search_max_depth'],
    directory_observations={n:dict(complete=r['complete'],entries=len(r['entries']),
        selected_logs=r['selected_logs'],before=r.get('before'),after=r.get('after'),error=r.get('error')) for n,r in directories.items()},
    selected_new_log_candidates=completion['selected_log_candidates'],
    previously_acquired_or_searched_skipped=completion['skipped_previously_acquired'],
    no_new_matching_candidate_in_observed_names=not completion['selected_log_candidates'],
    all_original_logs_absent_proven=False,logs_elsewhere_not_searched=True,
    limitations=['Names only for nonmatching entries; no shell history/.git/unrelated project contents read.',
        'Search filter/depth and selected roots are not global absence proof.',
        'Changed directory metadata cannot establish complete stable membership; observations not atomic.',
        'No new build log payload collected; prior configure probe log does not prove main target compile/link.'])
save('log-search-observations.json',search)
unknown=[e for e in union if 'retained_observation' not in e]
summary=dict(schema='openvins-remaining-summary-v1',selected_paths=len(files),
    status_counts=dict(collections.Counter(r['status'] for r in files.values())),
    new_objects_observed=len(bindings),deduplicated_blobs=len({r['sha256'] for r in bindings.values()}),
    new_observed_payload_bytes=sum(r['bytes'] for r in bindings.values()),actual_payload_bytes_read=completion['payload_bytes_read'],
    new_previous_acquired_path_overlap=len(set(files)&set(contract['previously_acquired_paths'])),
    prior_acquired_exclusion_paths=len(contract['previously_acquired_paths']),
    new_static_rel_x86_64=sum(r.get('e_type')==1 and r.get('machine')==62 for r in static.values()),
    object_parse_errors={n:r for n,r in static.items() if 'parse_error' in r},
    total_declared_objects=len(union),total_objects_with_retained_bytes=sum('retained_observation' in e for e in union),
    objects_remaining_unknown=len(unknown),new_log_payloads=0,new_log_candidates=len(completion['selected_log_candidates']),
    searched_directories=len(directories),stable_search_directories=sum(r['complete'] for r in directories.values()),
    unstable_or_failed_search_directories=[n for n,r in directories.items() if not r['complete']],
    acquisition_complete=completion['complete'],stop_reason=completion.get('stop_reason'),
    current_library_sha256=None,source_to_object_proven=False,source_to_existing_library_proven=False,
    native_admission=False,all_qualifications=False,native_commands=False,resource_queries=False,tests_run=False,linux_writes=False)
save('analysis-summary.json',summary)
save('missing-evidence.json',dict(schema='openvins-remaining-missing-evidence-v1',
    unobserved_objects=unknown,per_file_cap_observations={n:r for n,r in files.items() if r['status']=='file_cap'},
    aggregate_cap_observations={n:r for n,r in files.items() if r['status']=='aggregate_cap'},
    current_library_sha256=None,source_to_existing_library_proven=False,
    gaps=['9 of34 objects lack retained bytes: one above64MiB, one aggregate refusal, seven unattempted after stop.',
        'DynamicInitializer.cpp.o observed size81028080B exceeds unchanged67108864B cap. No strip, partial-chunk reassembly or higher-cap retry.',
        'No new main compile/link log found under this filter/roots/depth; /tmp changed during enumeration. Other positions/filenames remain unknown.',
        'Object comments/debug strings/depfile names/link recipe are not authenticated compiler execution, historical source/header bytes or same build-session binding.',
        'Existing291717384B library not stat/open/read again; full currentSHA/ELF/ABI unknown. No source-object-library equality proof.',
        'Windows share metadata is not Linux native identity/permissions/link authentication; collections are non-atomic across different times.',
        'Fresh runtime/sourcebuild/tool/header/library/package/ABI, calibration/noise/input/resource/pidfd/admission requirements remain unmet.']))
print(json.dumps(summary))
