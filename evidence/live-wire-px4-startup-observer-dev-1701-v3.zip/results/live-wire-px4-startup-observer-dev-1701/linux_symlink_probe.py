"""Real POSIX symlink refusal probe, separate from PX4/Gazebo."""

import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from tools.benchmark.observe_px4_startup import observe_px4_startup  # noqa: E402

with tempfile.TemporaryDirectory() as temporary:
    root = Path(temporary)
    link = root / "px4.log"
    link.symlink_to(root / "missing-target.log")
    output = root / "observation.json"
    try:
        observe_px4_startup(link, output, max_wall_ns=40_000_000)
    except ValueError as exc:
        assert "log existed before observer start" in str(exc)
    else:
        raise AssertionError("dangling symlink was accepted")
    evidence = json.loads(output.read_text())
    assert evidence["status"] == "observer_failed"
    assert evidence["markers"]["[mavlink] mode: Onboard"] is None
print("POSIX dangling symlink refused and recorded")
