import hashlib,json,subprocess
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(name,value):
 with (raw/name).open('xb') as f:f.write(json.dumps(value,indent=2).encode())
paths=subprocess.check_output(['git','ls-files','-z','src','tools','tests','configs']).decode().split('\0');rows=[]
for name in paths:
 if name and (root/name).is_file():
  b=(root/name).read_bytes();rows.append(dict(path=name,bytes=len(b),sha256=sha(b)))
save('product-before.json',rows)
read_paths=['ROADMAP.md','docs/STATIC_V4_ADMISSION_AND_SEQUENCE_DECODE_REPORT.md','evidence/static-v4-refusal-linear-sequence-publication.json','results/static-v4-attempt-dev-1701/NEXT_PHASE.md','results/static-v4-attempt-dev-1701/independent-sequence-review.md','results/static-v4-attempt-dev-1701/executor-fix-pass.md','results/static-v4-attempt-dev-1701/software-timeout-retention-gap.json','docs/superpowers/specs/2026-10-15-linear-sequence-decode-design.md','docs/superpowers/plans/2026-10-15-linear-sequence-decode.md','docs/superpowers/specs/2026-10-15-loader-selected-path-production-design.md','docs/superpowers/plans/2026-10-15-loader-selected-path-production.md','docs/TARGET_BEARING_STATIC_V3_HARNESS_FAILURE_REPORT.md','evidence/flydrones-history-through-loader-path-research-dev-1701.json','evidence/flydrones-history-through-admitted-executor-dev-1701.json']
read=[]
for name in read_paths:
 b=(root/name).read_bytes();text=b.decode('utf-8-sig');read.append(dict(path=name,bytes=len(b),sha256=sha(b),characters=len(text)))
save('context-readback.json',dict(head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),read=read,tracked_product_files=len(rows),resource_snapshot=False,scope='Windows data/source only;full historical files decoded, no live target/resources or project import. Initial mistaken docs/ROADMAP.md path error is in conversation, correct root ROADMAP.md read.'))
print(json.dumps(dict(old_product_files=len(rows),read_paths=len(read))))
