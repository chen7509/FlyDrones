import hashlib,json,zipfile
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
pres=json.loads((raw/'refused-attempt-preservation.json').read_bytes());privacy=pres['private_excluded']
inv=json.loads((root/'results/target-bearing-runtime-freeze-v4-dev-1701/LOCAL_UNPUBLISHED-admission-1.json').read_bytes());rows=inv['windows']+inv['linux']['rows'];triples=[];needles=set()
for r in rows:
 cmd=r.get('cmdline');command=cmd if isinstance(cmd,str) else ' '.join(cmd or []);digest=sha(command.encode())
 triples.append(dict(pid=r['pid'],name=r['name'],argv_sha256=digest,cmdline=cmd))
 if command:needles.add(digest.encode())
explicit=['src/flydrones/connectome_training/trainer.py','src/flydrones/connectome_training/model.py','src/flydrones/connectome_training/losses.py','src/flydrones/connectome_training/features.py','src/flydrones/connectome_training/dataset.py','src/flydrones/connectome_training/curriculum.py','src/flydrones/connectome_training/curriculum_session.py','src/flydrones/connectome_training/parameters.py','src/flydrones/connectome_training/__init__.py','tests/connectome_training/test_windowed_training.py','tests/connectome_training/test_trainer.py','tests/connectome_training/test_model.py','tests/connectome_training/test_curriculum.py','tests/connectome_training/conftest.py','tools/benchmark/software_process_boundary.py','docs/WINDOWED_TRAINING_BACKWARD_PRODUCTION_REPORT.md','docs/superpowers/specs/2026-10-15-windowed-training-backward-design.md','docs/superpowers/plans/2026-10-15-windowed-training-backward.md','evidence/flydrones-history-through-admitted-executor-dev-1701.json','evidence/flydrones-history-through-loader-path-research-dev-1701.json','evidence/flydrones-pr65-history-through-linear-sequence-dev-1701.md','evidence/static-v4-executor-completion-release.frame','evidence/static-v4-refusal-linear-sequence-publication.json','results/static-v4-attempt-dev-1701/preflight.json','results/static-v4-attempt-dev-1701/cli-completion.json','results/static-v4-attempt-dev-1701/admission-refusal-audit.json','results/target-bearing-runtime-freeze-v4-dev-1701/run-static-preparation-v4.py','results/target-bearing-runtime-freeze-v4-dev-1701/firstfacts.json','results/target-bearing-runtime-freeze-v4-dev-1701/completion.json']
files={root/p for p in explicit}|{p for p in raw.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo')}
assert not files&{root/r['path'] for r in privacy}
members=[];scanned=0
for p in sorted(files):
 b=p.read_bytes();path=p.relative_to(root).as_posix();assert not any(n in b for n in needles),path
 try:stack=[json.loads(b.decode('utf-8-sig'))];scanned+=1
 except (ValueError,UnicodeError):stack=[]
 while stack:
  v=stack.pop()
  if isinstance(v,dict):
   for keys in (('pid','name','argv_sha256'),('pid','name','cmdline')):
    if set(keys)<=v.keys():assert not any(all(v.get(k)==r.get(k) for k in keys) for r in triples),path
   stack.extend(v.values())
  elif isinstance(v,list):stack.extend(v)
 members.append(dict(path=path,bytes=len(b),sha256=sha(b)))
archive=root/'evidence/windowed-training-production-dev-1701.zip';mapping=archive.with_suffix('.sha256.json')
payload=dict(schema='windowed-training-production-map-v1',members=members,private_excluded=privacy,nonempty_private_argv_hashes=len(needles),private_allrow_triples=len(triples),json_scanned=scanned,scope='TinyCPU backwardproduction/software only;no fullMaleCNS/targetnative/resources;publicationpending')
with mapping.open('xb') as f:f.write(json.dumps(payload,indent=2).encode())
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for r in members:z.write(root/r['path'],r['path'])
 z.write(mapping,mapping.relative_to(root).as_posix())
receipt=dict(archive=archive.relative_to(root).as_posix(),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),members=len(members)+1,mapped_members=len(members),uncompressed_bytes=sum(r['bytes'] for r in members),manifest_sha256=sha(mapping.read_bytes()),preseal_exact_set=[r['path'] for r in members],scope='Plan2done/softwarepublicationpending;postsealreceipt/delivery/stage/publication/PR/automation outside')
with (raw/'seal-receipt.json').open('xb') as f:f.write(json.dumps(receipt,indent=2).encode())
print(json.dumps({k:v for k,v in receipt.items() if k!='preseal_exact_set'}))
