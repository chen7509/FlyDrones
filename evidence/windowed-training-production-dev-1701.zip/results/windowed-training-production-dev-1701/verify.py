import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path.cwd();RAW=Path(__file__).resolve().parent
SOURCES=['src/flydrones/connectome_training/trainer.py','src/flydrones/connectome_training/model.py','src/flydrones/connectome_training/losses.py','src/flydrones/connectome_training/features.py','src/flydrones/connectome_training/dataset.py','tests/connectome_training/test_windowed_training.py','tests/connectome_training/test_trainer.py','tests/connectome_training/conftest.py','tools/benchmark/software_process_boundary.py',str(Path(__file__).relative_to(ROOT)).replace('\\','/')]
def pins(label):
 out=[]
 for p in SOURCES:
  f=ROOT/p
  if not f.exists():out.append(dict(path=p,absent=True));continue
  b=f.read_bytes();out.append(dict(path=p,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()));dest=RAW/(label+'-source')/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 return out
def write(name,obj):
 with (RAW/name).open('xb') as f:f.write(json.dumps(obj,indent=2).encode())
label=sys.argv[1];argv=sys.argv[2:];before=pins(label)
env=dict(os.environ);env['PYTHONPATH']=str(ROOT/'src')+os.pathsep+str(ROOT)
start=dict(argv=argv,cwd=str(ROOT),source_before=before,recorder_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),environment={k:env.get(k) for k in ('PYTHONPATH','PATH','PYTHONHOME','VIRTUAL_ENV')},started_monotonic_ns=time.monotonic_ns(),started_utc=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),scope='Small CPU software only;host NumPy/SciPy/Torch import;no fullMaleCNS/targetSDK/resources/native admission')
write(label+'-start.json',start)
try:
 p=subprocess.run(argv,cwd=ROOT,env=env,capture_output=True,timeout=120);out,err,code=p.stdout,p.stderr,p.returncode;exception=None
except subprocess.TimeoutExpired as exc:
 out,err,code=exc.stdout or b'',exc.stderr or b'',None;exception=repr(exc)
for name,b in [('stdout',out),('stderr',err)]:
 with (RAW/(label+'.'+name)).open('xb') as f:f.write(b)
result=dict(**start,exit=code,exception=exception,ended_monotonic_ns=time.monotonic_ns(),source_after=pins(label+'-after'),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest())
write(label+'.json',result);print(json.dumps(dict(label=label,exit=code,exception=exception,stdout=out.decode(errors='replace')[-9000:],stderr=err.decode(errors='replace')[-3000:])));sys.exit(0 if code==0 else 1)
