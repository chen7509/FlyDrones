# Independent windowed-training source review

Reviewed the current trainer and new tests once against the approved design/plan and original trainer, at base HEAD `65826619be28949707b2f51c81ef3397ebcfedac`.

**Disposition: C=0, I=0, M=2.** No critical or important correctness finding. The two minor findings below improve test strength and explicit reference cleanup.

The method was Windows file reads and static reasoning only. No project imports, tests, target subprocesses, native/Linux/resource/network actions, or product edits were performed. This report is original evidence and must remain unchanged after any executor fix pass.

## Findings

### M1: Record raw gradients before clipping as well

Location: `tests/connectome_training/test_windowed_training.py:55-57`; assertions at 75-77 and 217-219.

The reference clones every parameter gradient only after clipping to 0.6. When clipping is active, a common scaling error in the full gradient vector is largely removed by clipping; matching clipped gradients and SGD updates therefore does not fully establish matching raw backward gradients. Static reasoning found no such scaling error in the current algorithm.

Capture reference gradients before clipping and candidate gradients at entry to the final clip call, and compare every raw gradient in addition to the existing clipped-gradient and update assertions. This is a minor verification gap rather than evidence that the implementation gradients are wrong.

### M2: Release the unused original local total before advancing

Location: `src/flydrones/connectome_training/trainer.py:72`; cleanup at 92.

`_, local = sequence_loss(...)` binds the unused original total to `_`. Cleanup does not delete it, so the prior total and its autograd node references survive while the next prediction window is constructed. This remains bounded to the preceding window. It does **not** demonstrate that its saved activations survive backward: the objective traverses and releases the shared local-loss paths. It does make the explicit old-loss-release promise less precise.

Delete the unused total immediately after obtaining local terms, or include its binding in cleanup before advancing.

## Algorithm assessment

The detached recurrence schedule matches the unchanged full-sequence forward: each chunk has at most `truncate_steps` frames, inherits detached state, and uses the unchanged default `dt_s=0.05`. Parameters remain fixed until the sequence finishes.

Frame losses use local/full frame-count weighting, internal smoothness uses local/full pair-count weighting, and each crossing pair uses the full pair denominator. For a crossing pair a,b, the older objective includes `(a-b.detach())^2`, and the newer includes `(b-a.detach())^2`; this includes both original partial derivatives while reporting the scalar once. Singleton, unit, uneven and oversize positive integer windows follow the intended accounting.

The oldest window is backwarded before requesting a third window; there is no `retain_graph`. The generator retains the neighboring prediction and detached state. The retained previous-last view can keep one prior output storage alive, but this is bounded. No proportional chain of saved activations was identified in the source. Whole feature/target/clearance inputs remain eager.

Public APIs and feature profiles remain. Each successful sequence has one zero-grad, one final clip and one step. Input validation occurs before window backward; later forward/loss exceptions occur before the optimizer step. Such later failures may leave partial gradients, which the next invocation zeros; the specified no-step guarantee holds. Evaluation explicitly uses `torch.no_grad()`.

The tests cover the required small tensor scenarios, actual tiny connectome, saved-tensor holder lifetimes, reset/update behavior and failures, and install the default process guard. This reviewer did not execute those tests. Their saved-object counts cannot establish real complete-model byte peak or latency. No full MaleCNS/source/calibration/fairness/native/SDK/simulator/sensor/physical qualification follows; readiness remains false/pending.

## Exact reviewed bytes

- `src/flydrones/connectome_training/trainer.py`: `4e06e4c7ec4280ecb53af47284b8714f2e6a1a667f254fc124daab9c1179b870`
- `tests/connectome_training/test_windowed_training.py`: `51456afef1145003e75637e628d7bda18c420282a21f4e58db93225a817e402a`
- `src/flydrones/connectome_training/model.py`: `81b2c4cfbc947d239794b3d3b8ed1e1c3f4d473cec2c82a6ad5e15561f63265c`
- `src/flydrones/connectome_training/losses.py`: `d46724e8750efdc8d86afaf164c304485111d09ab461a6ecd53bc390c0789eaa`
- `src/flydrones/connectome_training/features.py`: `6c1881e9ff5a060d9af842f7c60601b62e22576ca16c61baf0545cd9ff6dd6f1`
- `docs/superpowers/specs/2026-10-15-windowed-training-backward-design.md`: `bc110fe982f3c8d708f01c7a8aaaa3fccbbf3a8cc0a44ebe5ba6883c2433a868`
- `docs/superpowers/plans/2026-10-15-windowed-training-backward.md`: `de779a7d0e5ba86f70bb4e9602ae751c516b8ef009f9c6b9fe576f9adec87262`
- `results/windowed-training-production-dev-1701/window-behavior-red-source/src/flydrones/connectome_training/trainer.py`: `3d4e52ff04471bed19219ae6dd3ed400a2dd8ea988a24ad8e4601a8a4843ef77`

The companion JSON contains structured findings and scope. Any later executor fixes require new source hashes; this original report is not a review of those later bytes.
