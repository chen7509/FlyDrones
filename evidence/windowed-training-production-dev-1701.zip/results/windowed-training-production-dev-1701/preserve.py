import hashlib,json
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes().decode('utf-8-sig'))
def save(n,v):
 with (raw/n).open('xb') as f:f.write(json.dumps(v,indent=2).encode())
old=load(root/'results/static-v4-attempt-dev-1701/historical-archives-postsoftware.json')['members']
old.append(dict(path='evidence/static-v4-refusal-linear-sequence-dev-1701.zip',bytes=2495407,sha256='1260d2abdcc507cf36b64235a6b3e63e618c38dc7a3717a6c3b4c74645bf1c35'))
assert len(old)==295 and {r['path'] for r in old}=={p.relative_to(root).as_posix() for p in (root/'evidence').glob('*.zip')}
for row in old:
 h=hashlib.sha256();n=0
 with (root/row['path']).open('rb') as f:
  while block:=f.read(1048576):h.update(block);n+=len(block)
 assert n==row['bytes'] and h.hexdigest()==row['sha256'],row['path']
save('historical-archives-postsoftware.json',dict(members=old,count=len(old),bytes=sum(r['bytes'] for r in old),scope='POSTsoftware preservation,not runtime prepins'))
before=load(raw/'product-before.json');changed=[]
for row in before:
 b=(root/row['path']).read_bytes()
 if sha(b)!=row['sha256']:changed.append(row['path'])
assert changed==['src/flydrones/connectome_training/trainer.py']
save('product-preservation-postsoftware.json',dict(count=len(before),changed=changed,new_product=['tests/connectome_training/test_windowed_training.py'],all_other_old_product_byte_same=True,all_consumed_version_sources_byte_same=True))
prior=load(root/'results/static-v4-attempt-dev-1701/admission-refusal-audit.json');parent=root/'results/target-bearing-runtime-freeze-v4-dev-1701'
for row in prior['private_excluded']:
 b=(root/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
assert set(p.name for p in parent.iterdir())=={'run-static-preparation-v4.py','firstfacts.json','completion.json',*[Path(r['path']).name for r in prior['private_excluded']]}
assert load(parent/'completion.json')['state']=='REFUSED_UNCONSUMED' and not load(parent/'completion.json')['consumed']
sources=load(root/'results/static-v4-attempt-dev-1701/preflight.json')['sources'];evolved=[]
for row in sources:
 snapshot=root/'results/static-v4-attempt-dev-1701/source-before'/row['path'];assert sha(snapshot.read_bytes())==row['sha256']
 if sha((root/row['path']).read_bytes())!=row['sha256']:evolved.append(row['path'])
assert set(evolved)=={'src/flydrones/connectome_training/dataset.py','src/flydrones/connectome_training/trainer.py'}
release=root/'evidence/static-v4-executor-completion-release.frame';assert sha(release.read_bytes())=='f7ce10ba80d5554aadd16dd29b8bb1ae8aea8e811ce0bd2d5a9b01cf711f72cc'
hist=[]
for path,expected in [('evidence/flydrones-history-through-loader-path-research-dev-1701.json','80dfb89ed0e51e639bd6b24b115cbcd3c444b967614e2e8334d55962c262b824'),('evidence/flydrones-history-through-admitted-executor-dev-1701.json','c88840b6f58dea4e7e4931683c4993b4fc3b8eb55887807994b6381ef6c2b989')]:
 b=(root/path).read_bytes();assert sha(b)==expected;hist.append(dict(path=path,bytes=len(b),sha256=expected))
save('refused-attempt-preservation.json',dict(state='REFUSED_UNCONSUMED',parent_exact_six_files=True,private_excluded=prior['private_excluded'],source382_snapshots_unchanged=True,current_source_evolved=evolved,release_sha256=sha(release.read_bytes()),release_stale=True,physical_absent=not (root/'results/target-bearing-physical-capture-dev-1701').exists(),resource_poll=False,native_target_action=False,histories=hist))
prior_pr=load(root/'results/static-v4-attempt-dev-1701/publication-readback.stdout')
assert prior_pr['headRefOid']=='65826619be28949707b2f51c81ef3397ebcfedac' and prior_pr['isDraft']
history=root/'evidence/flydrones-pr65-history-through-linear-sequence-dev-1701.md'
with history.open('xb') as f:f.write(prior_pr['body'].encode())
save('pr-history-externalization.json',dict(path=history.relative_to(root).as_posix(),sha256=sha(history.read_bytes()),bytes=history.stat().st_size,characters=len(prior_pr['body']),scope='Verbatim prior PR body from retained exact readback;new body must fit GitHub65000char limit,not discarded historical evidence;fresh beforepublication joins later'))
print(json.dumps(dict(old_zip_count=len(old),old_zip_bytes=sum(r['bytes'] for r in old),old_product_count=len(before),only_trainer_changed=True,v4_unconsumed_and_stale=True)))
