"""Seal the candidate-map-history stage without modifying earlier evidence."""

import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
stage = Path(__file__).resolve().parent
base = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
diff = subprocess.check_output(
    [
        "git", "diff", "--binary", "--",
        "src/flydrones/benchmark/ego_diagnostic_reconcile.py",
        "tests/benchmark/test_ego_diagnostic_reconcile.py",
        "docs/EGO_APPLIED_MAP_HISTORY_REPORT.md",
        "docs/superpowers/plans/2026-10-10-ego-causal-provenance.md",
    ],
    cwd=root,
)
(stage / "change.diff").write_bytes(diff)
(stage / "observed-verification.json").write_text(
    json.dumps(
        {
            "schema": "flydrones-map-history-verification-observed-v1",
            "base_commit": base,
            "red": [
                "Earlier applied depth digest changed: DID NOT RAISE ValueError",
                "Later plan claimed revision 1 after revision 2 applied: DID NOT RAISE ValueError",
            ],
            "initial_adjacent_run": "12 failed, 70 passed; 11 rosbags dependency import failures and one error-message regression",
            "final_adjacent_run": "138 passed in 1.54s across six EGO test files using sealed rosbags 0.11.5 deps",
            "ruff": "All checks passed for the changed Python files",
            "diff_check": "passed",
            "record_kind": "transcription of observed terminal outputs, not captured raw logs",
        },
        sort_keys=True,
        indent=2,
    ) + "\n",
    encoding="utf-8",
)
included = [
    root / "src/flydrones/benchmark/ego_diagnostic_reconcile.py",
    root / "tests/benchmark/test_ego_diagnostic_reconcile.py",
    root / "docs/EGO_APPLIED_MAP_HISTORY_REPORT.md",
    root / "docs/superpowers/plans/2026-10-10-ego-causal-provenance.md",
    stage / "change.diff",
    stage / "observed-verification.json",
    stage / "seal.py",
]
included.sort(key=lambda p: p.relative_to(root).as_posix())
manifest = {
    "schema": "flydrones-ego-applied-map-history-evidence-v1",
    "base_commit": base,
    "members": [
        {
            "path": p.relative_to(root).as_posix(),
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
            "bytes": p.stat().st_size,
        }
        for p in included
    ],
}
target = root / "evidence/ego-applied-map-history-dev-1701.zip"
with zipfile.ZipFile(target, "x", zipfile.ZIP_DEFLATED) as archive:
    for path in included:
        archive.write(path, path.relative_to(root).as_posix())
    archive.writestr("manifest.json", json.dumps(manifest, sort_keys=True, indent=2) + "\n")
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    for item in manifest["members"]:
        assert hashlib.sha256(archive.read(item["path"])).hexdigest() == item["sha256"]
print(json.dumps({"sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "members": len(included)}))
