import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path("/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility")
sys.path[:0] = [str(ROOT), str(ROOT / "src")]

from tools.benchmark.audit_source_watchdog_retry_preflight import audit
from tools.benchmark.capture_disarmed_sensors import active_resources

EXPECTED_HEAD = "33ed23d1cc08d314b9d6fbdc0fbcad1b6958f6cb"
stage = ROOT / "results/source-watchdog-retry-preflight-dev-1701"
study = ROOT / "results/estimator-physical-refusal-diagnosis-dev-1701/study-v19"
destination = study / "startup-preflight-v1"
dispatch_path = stage / "startup-preflight-dispatch.json"
completion_path = stage / "startup-preflight-completion.json"
output_path = stage / "startup-preflight-output.txt"

head = subprocess.run(
    ["/mnt/c/Program Files/Git/cmd/git.exe", "rev-parse", "HEAD"],
    cwd=ROOT,
    check=True,
    capture_output=True,
    text=True,
).stdout.strip()
manifest = json.loads((study / "study-manifest.json").read_text(encoding="utf-8"))
package_audit = audit(study)
command = list(manifest["command"])
command[command.index("--output") + 1] = destination.as_posix()
command.append("--startup-preflight")

if head != EXPECTED_HEAD:
    raise SystemExit(f"unexpected committed head: {head}")
if destination.exists():
    raise SystemExit(f"refusing existing destination: {destination}")
if any(path.exists() for path in (dispatch_path, completion_path, output_path)):
    raise SystemExit("refusing to overwrite startup-preflight evidence")
if package_audit.get("failures") or package_audit.get("prepare_qualified") is not True:
    raise SystemExit(f"package audit not qualified: {package_audit!r}")
if manifest.get("future_destination") != (study / "capture-v1").as_posix():
    raise SystemExit("physical destination declaration changed")
resources_before = active_resources()
if resources_before:
    raise SystemExit(f"active resources before dispatch: {resources_before!r}")

dispatch = {
    "schema": "source-watchdog-retry-startup-preflight-dispatch-v1",
    "command": command,
    "destination": destination.as_posix(),
    "head": head,
    "resources_before": resources_before,
    "physical_run": False,
    "started_wall_ns": time.time_ns(),
}
with dispatch_path.open("x", encoding="utf-8") as stream:
    json.dump(dispatch, stream, indent=2, sort_keys=True)
    stream.write("\n")
with output_path.open("xb") as stream:
    completed = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, check=False)
resources_after = active_resources()
completion = {
    "schema": "source-watchdog-retry-startup-preflight-completion-v1",
    "returncode": completed.returncode,
    "destination": destination.as_posix(),
    "resources_after": resources_after,
    "ended_wall_ns": time.time_ns(),
    "physical_run": False,
}
with completion_path.open("x", encoding="utf-8") as stream:
    json.dump(completion, stream, indent=2, sort_keys=True)
    stream.write("\n")
print(json.dumps(completion, indent=2, sort_keys=True))
raise SystemExit(completed.returncode)
