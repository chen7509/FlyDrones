import hashlib
import json
from pathlib import Path

ROOT = Path("C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility")
stage = ROOT / "results/source-watchdog-retry-preflight-dev-1701"
study = ROOT / "results/estimator-physical-refusal-diagnosis-dev-1701/study-v19"
destination = study / "startup-preflight-v1"

result_path = destination / "result.json"
supervisor_path = destination / "supervisor.json"
completion_path = stage / "startup-preflight-completion.json"
package_audit_path = stage / "study-v19-audit-v3-after-startup.json"
result = json.loads(result_path.read_text(encoding="utf-8"))
supervisor = json.loads(supervisor_path.read_text(encoding="utf-8"))
completion = json.loads(completion_path.read_text(encoding="utf-8"))
package_audit = json.loads(package_audit_path.read_text(encoding="utf-8"))
cleanup = supervisor.get("cleanup", {})
binding = result.get("runtime_binding", {})
files = {path.relative_to(destination).as_posix() for path in destination.rglob("*") if path.is_file()}
forbidden = {
    "process.log",
    "ulog-manifest.json",
    "events.jsonl",
    "source-fanout.jsonl",
    "native-status.jsonl",
    "motion-profile.jsonl",
    "physics-trace.jsonl",
}
failures = []


def require(value, label):
    if not value:
        failures.append(label)


def path_key(value):
    text = str(value).replace("\\", "/")
    if len(text) > 7 and text.startswith("/mnt/") and text[5].isalpha() and text[6] == "/":
        text = f"{text[5]}:/{text[7:]}"
    return text.casefold()


require(package_audit.get("failures") == [] and package_audit.get("prepare_qualified") is True, "package audit")
require(completion.get("schema") == "source-watchdog-retry-startup-preflight-completion-v1", "completion schema")
require(completion.get("returncode") == 0 and completion.get("physical_run") is False, "completion result")
require(completion.get("resources_after") == [], "completion resources")
require(path_key(completion.get("destination", "")) == path_key(destination), "completion destination")
require(result.get("status") == "capture_completed" and result.get("errors") == [], "capture result")
require(result.get("startup_preflight_only") is True and result.get("startup_preflight_completed") is True, "startup flags")
require(binding.get("phases") == ["postgraph", "bootstrap"], "runtime phases")
require(binding.get("owned_phases") == {"px4": [], "openvins": []}, "owned phases")
require(binding.get("runtime_mapping_coverage_verified") is False, "runtime mapping claim")
require(binding.get("runtime_closure_qualified") is False, "runtime closure claim")
require(result.get("eligible_for_vio_input") is False and result.get("eligible_for_px4_fusion") is False, "input/fusion claims")
for key in ("physical_execution_qualified", "vio_accuracy_qualified", "estimator_health_qualified", "fusion_eligible", "flight_ready"):
    require(result.get(key) is False, "result claim:" + key)
require(supervisor.get("status") == "worker_exited" and supervisor.get("worker_exit") == 0, "supervisor exit")
require(supervisor.get("errors") == [] and supervisor.get("capture_status") == "capture_completed", "supervisor status")
require(cleanup.get("errors") == [] and cleanup.get("no_executing_members") is True, "cleanup executing")
require(cleanup.get("group_absent") is True and cleanup.get("sigkill_dispatched") is False, "cleanup group")
require(cleanup.get("graceful_group_cleanup_verified") is True, "cleanup qualification")
require(not (files & forbidden), "physical artifacts absent")

audit = {
    "schema": "source-watchdog-retry-startup-preflight-audit-v1",
    "failures": failures,
    "startup_preflight_qualified": not failures,
    "result_sha256": hashlib.sha256(result_path.read_bytes()).hexdigest(),
    "supervisor_sha256": hashlib.sha256(supervisor_path.read_bytes()).hexdigest(),
    "file_count": len(files),
    "runtime_phases": binding.get("phases"),
    "owned_phases": binding.get("owned_phases"),
    "all_descendant_cleanup_qualified": False,
    "physical_execution_qualified": False,
    "runtime_mapping_coverage_verified": False,
    "runtime_closure_qualified": False,
    "vio_accuracy_qualified": False,
    "estimator_health_qualified": False,
    "fusion_eligible": False,
    "flight_ready": False,
}
(stage / "startup-preflight-audit.json").write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")
print(json.dumps(audit, indent=2))
raise SystemExit(0 if not failures else 2)
