# Supported heartbeat/gauge integration failures

The retained `dry-v3` and `dry-v4` integration attempts stopped before PX4, Gazebo, OpenVINS, or physics because the declared runtime inventory omitted worker-imported Python modules. Both failures are input-closure evidence only.

The corrected `dry-v5` package passed the preflight audit and reproduced 39 worker-selected inputs with no missing file. Its physical attempt then stopped safely at 10 ms simulation time because the owned OpenVINS process mapped one undeclared lazy dependency:

`/usr/lib/x86_64-linux-gnu/libtbbmalloc.so.2.11` (device `08:30`, inode `238769`)

The OpenVINS executable identity was stable, the declared mappings had no mismatch, and runtime mapping coverage remained false. The attempt produced no accepted native state, no committed fan-out record, no ULog, and no support or lateral force. It therefore provides no VIO-accuracy, training, PX4-dynamics, or fruit-fly-learning result.

PX4 required an internal SIGKILL during child cleanup (`px4_exit_code=-9`). The outer recorded supervisor separately sent no SIGKILL to its original process group, reaped its zombie leader, and observed the group absent afterward. Its scope does not cover escaped descendants. A post-run scan found no remaining relevant process.

Further physical retries are stopped. The next gate is an independent lazy-runtime-mapping closure design and validation stage beginning with the exact TBB allocator mapping above.
