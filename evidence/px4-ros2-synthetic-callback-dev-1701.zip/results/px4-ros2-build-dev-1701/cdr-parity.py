"""Independent decode parity for the fixed synthetic ROS callback journal."""
import hashlib
import json
import math
from pathlib import Path

from px4_msgs.msg import VehicleOdometry
from rclpy.serialization import deserialize_message

ROOT = Path('/workspace')
RUN = ROOT / 'synthetic-v3'
MESSAGE = ROOT / 'install/px4_msgs/share/px4_msgs/msg/VehicleOdometry.msg'
assert hashlib.sha256(MESSAGE.read_bytes()).hexdigest() == (
    'a528b3d0b4c1a9083a71b32c367bad71a900e959efd82b9d03a9eb0e99fe6017'
)
rows = [json.loads(line) for line in (RUN / 'source.jsonl').read_text().splitlines()]
samples = [row for row in rows if row['kind'] == 'sample']
assert len(samples) == 60 and rows[-1]['kind'] == 'finish'
seen = []
for row in samples:
    cdr = bytes.fromhex(row['cdr_hex'])
    assert hashlib.sha256(cdr).hexdigest() == row['cdr_sha256']
    message = deserialize_message(cdr, VehicleOdometry)
    assert message.timestamp == row['px4_publication_us']
    assert message.timestamp_sample == row['px4_sample_us']
    assert message.pose_frame == row['pose_frame']
    assert message.velocity_frame == row['velocity_frame']
    assert message.reset_counter == row['reset_counter']
    assert message.quality == row['quality']
    source_index = (message.timestamp_sample - 1_000_000) // 50_000
    assert message.timestamp_sample == 1_000_000 + source_index * 50_000
    assert math.isclose(message.position[0], 0.01 * source_index, abs_tol=1e-6)
    assert list(message.q) == [1.0, 0.0, 0.0, 0.0]
    assert list(message.velocity) == [0.2, 0.0, 0.0] or math.isclose(
        message.velocity[0], 0.2, abs_tol=1e-6
    )
    seen.append(source_index)
result = {
    'schema': 'flydrones.px4_ros2_synthetic_cdr_parity.v1',
    'run_id': 'px4-ros2-synthetic-1701-v3',
    'sample_count': len(samples),
    'first_publisher_index': seen[0],
    'last_publisher_index': seen[-1],
    'all_rows_generated_type_decode_matched': True,
    'message_sha256': hashlib.sha256(MESSAGE.read_bytes()).hexdigest(),
    'journal_sha256': hashlib.sha256((RUN / 'source.jsonl').read_bytes()).hexdigest(),
    'not_px4': True,
    'not_ekf2': True,
    'eligible_for_live_capture': False,
}
out = RUN / 'cdr-parity.json'
if out.exists():
    raise SystemExit('parity output exists')
out.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, sort_keys=True))
