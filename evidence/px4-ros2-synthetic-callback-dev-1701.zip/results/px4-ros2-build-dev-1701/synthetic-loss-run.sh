#!/usr/bin/env bash
source /opt/ros/humble/setup.bash
source /workspace/install/setup.bash
set -u
export RMW_IMPLEMENTATION=rmw_cyclonedds_cpp
export ROS_DOMAIN_ID=217
export ROS_LOG_DIR=/workspace/synthetic-loss-v1/roslog
mkdir -p "$ROS_LOG_DIR"
/workspace/install/flydrones_px4_ros2_source/lib/flydrones_px4_ros2_source/px4_odometry_source /workspace/synthetic-loss-v1/source.jsonl px4-ros2-synthetic-loss-1701-v1 15 60 > /workspace/synthetic-loss-v1/subscriber.log 2>&1 &
subscriber=$!
sleep 0.7
python3 /workspace/synthetic_loss_pub.py > /workspace/synthetic-loss-v1/publisher.log 2>&1 &
publisher=$!
wait "$subscriber"
subscriber_exit=$?
wait "$publisher"
publisher_exit=$?
printf '%s\n' "$subscriber_exit" > /workspace/synthetic-loss-v1/subscriber.exit
printf '%s\n' "$publisher_exit" > /workspace/synthetic-loss-v1/publisher.exit
if [[ "$subscriber_exit" -ne 0 || "$publisher_exit" -ne 0 ]]; then exit 1; fi
