import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
canonical = root / "src-canonical" / "px4_msgs"
built = root / "src" / "px4_msgs"
canonical_files = {p.relative_to(canonical).as_posix(): p for p in canonical.rglob("*") if p.is_file()}
built_files = {p.relative_to(built).as_posix(): p for p in built.rglob("*") if p.is_file()}
same = []
line_ending_only = []
other = []
for name in sorted(canonical_files.keys() & built_files.keys()):
    expected = canonical_files[name].read_bytes()
    actual = built_files[name].read_bytes()
    if expected == actual:
        same.append(name)
    elif expected.replace(b"\r\n", b"\n") == actual.replace(b"\r\n", b"\n"):
        line_ending_only.append(name)
    else:
        other.append(name)
message = "msg/VehicleOdometry.msg"
result = {
    "schema": "flydrones.px4_ros2_actual_build_source_audit.v1",
    "built_source_root": "src/px4_msgs",
    "canonical_reference_root": "src-canonical/px4_msgs",
    "canonical_count": len(canonical_files),
    "built_count": len(built_files),
    "same_bytes_count": len(same),
    "line_ending_only_count": len(line_ending_only),
    "other_difference_count": len(other),
    "missing_from_built": sorted(canonical_files.keys() - built_files.keys()),
    "extra_in_built": sorted(built_files.keys() - canonical_files.keys()),
    "other_differences": other,
    "vehicle_odometry_canonical_sha256": hashlib.sha256(canonical_files[message].read_bytes()).hexdigest(),
    "vehicle_odometry_built_sha256": hashlib.sha256(built_files[message].read_bytes()).hexdigest(),
    "all_common_files_equal_after_crlf_normalization": not other,
    "actual_built_tree_byte_identical_to_canonical": not line_ending_only and not other and not (canonical_files.keys() ^ built_files.keys()),
}
(root / "actual-build-source-audit.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2, sort_keys=True))
