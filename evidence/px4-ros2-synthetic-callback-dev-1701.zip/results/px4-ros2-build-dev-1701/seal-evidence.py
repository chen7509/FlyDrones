import hashlib
import json
import zipfile
from pathlib import Path

repo = Path(__file__).resolve().parents[2]
study = Path(__file__).resolve().parent
target = repo / "evidence" / "px4-ros2-synthetic-callback-dev-1701.zip"

paths = [
    repo / "docs/PX4_ROS2_SOURCE_JOURNAL_REPORT.md",
    repo / "docs/PX4_ROS2_SYNTHETIC_CALLBACK_REPORT.md",
    repo / "docs/superpowers/plans/2026-10-10-px4-ros2-source-journal.md",
    repo / "tools/connectome/px4_ros2_source/CMakeLists.txt",
    repo / "tools/connectome/px4_ros2_source/package.xml",
    repo / "tools/connectome/px4_ros2_source/px4_odometry_source.cpp",
    repo / "src/flydrones/connectome_training/px4_ros2_source_journal.py",
    repo / "tests/connectome_training/test_px4_ros2_source_journal.py",
]
top_level = [
    "build-profile.json", "build-profile-v2.json", "build-profile-v3.json",
    "build-profile-v4.json", "build-v2.exit", "build-v2.log", "build-v3.exit",
    "build-v3.log", "build-v4.exit", "build-v4.log", "post-audit.json",
    "actual-build-source-audit.json", "audit-build-source.py", "seal-evidence.py",
    "adjacent-tests.txt", "ruff.txt", "diff-check.txt", "cdr-parity.py",
    "px4_msgs-148bdb4-git-archive.tar",
    "synthetic_pub.py", "synthetic_reset_pub.py", "synthetic_loss_pub.py",
    "synthetic-run.sh", "synthetic-run-v2.sh", "synthetic-run-v3.sh",
    "synthetic-reset-run.sh", "synthetic-loss-run.sh",
]
paths += [study / name for name in top_level]
paths += [
    study / "src/px4_msgs/msg/VehicleOdometry.msg",
    study / "src-canonical/px4_msgs/msg/VehicleOdometry.msg",
    study / "build/px4_msgs/CMakeCache.txt",
    study / "install/px4_msgs/share/px4_msgs/msg/VehicleOdometry.msg",
    study / "install/flydrones_px4_ros2_source/lib/flydrones_px4_ros2_source/px4_odometry_source",
]
for run in ("synthetic-v1", "synthetic-v2", "synthetic-v3", "synthetic-reset-v1", "synthetic-loss-v1"):
    paths += [p for p in (study / run).iterdir() if p.is_file()]
paths = sorted(set(paths), key=lambda path: path.relative_to(repo).as_posix())
for path in paths:
    if not path.is_file():
        raise FileNotFoundError(path)
if target.exists():
    raise FileExistsError(target)
hashes = {path.relative_to(repo).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
manifest = {
    "schema": "flydrones.px4_ros2_synthetic_callback_evidence.v1",
    "members": hashes,
    "qualification": {
        "actual_build_source_byte_identical_to_pinned_raw_git_blobs": False,
        "synthetic_typed_ros_callback_verified": True,
        "owned_px4_agent_source_verified": False,
        "live_capture_eligible": False,
    },
}
with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as archive:
    for path in paths:
        archive.write(path, path.relative_to(repo).as_posix())
    archive.writestr("manifest.json", json.dumps(manifest, indent=2, sort_keys=True) + "\n")
with zipfile.ZipFile(target) as archive:
    if archive.testzip() is not None:
        raise AssertionError("CRC failed")
    for member, expected in hashes.items():
        if hashlib.sha256(archive.read(member)).hexdigest() != expected:
            raise AssertionError(member)
print(json.dumps({"path": str(target), "sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "members": len(paths) + 1, "bytes": target.stat().st_size}, indent=2))
