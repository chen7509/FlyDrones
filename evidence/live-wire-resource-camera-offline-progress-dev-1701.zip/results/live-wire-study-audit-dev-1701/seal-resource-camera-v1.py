"""Exclusive archive of this offline increment, not a live-study result."""
import hashlib,json,zipfile
from pathlib import Path
root=Path('results/live-wire-study-audit-dev-1701')
target=Path('evidence/live-wire-resource-camera-offline-progress-dev-1701.zip')
paths=[Path(p) for p in ['tools/benchmark/audit_live_wire_resources.py','tools/benchmark/audit_live_wire_study.py','tools/benchmark/bound_resource_graph.py','tools/benchmark/native_resource_client.py','tools/benchmark/selected_resource_graph.py','tools/benchmark/openvins_causal_input.py','src/flydrones/benchmark/camera_info_capture.py','tests/benchmark/test_live_wire_camera_info.py','tests/benchmark/test_live_wire_resource_graph.py','tests/benchmark/test_live_wire_study_entry.py','tests/benchmark/test_bound_resource_graph.py','docs/LIVE_WIRE_RAW_EVIDENCE_MAP.md','docs/LIVE_WIRE_STUDY_PREPARATION_REPORT.md','docs/superpowers/plans/2026-10-08-live-wire-study.md','docs/superpowers/specs/2026-10-08-live-wire-study-design.md','.superpowers/sdd/2026-10-08-live-wire-study/progress.md']]
paths.extend(p for p in root.iterdir() if p.is_file() and p.name.startswith(('camera-info-','camera-entry-','resource-graph-','resource-entry-','resource-camera-','check-resource-camera-','seal-resource-camera-')))
paths.extend(p for p in (root/'resource-camera-fixed-v1').rglob('*') if p.is_file())
members={str(p).replace('\\','/'):p.read_bytes() for p in paths}
assert len(paths)==len(members)
manifest=dict(producer_commit='972912f',scope='offline graph/camera joins; Task2/3 incomplete',live_qualified=False,fusion_qualified=False,remote_published=False,members={n:dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in members.items()})
members['manifest.json']=json.dumps(manifest,sort_keys=True,indent=2).encode()
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in members.items(): z.writestr(name,data)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and len(z.namelist())==len(members)
    for name,data in members.items(): assert z.read(name)==data
record=dict(path=str(target),members=len(members),bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),crc_and_all_members_verified=True)
with (root/'resource-camera-seal-v1.json').open('x') as f: json.dump(record,f,indent=2)
print(json.dumps(record,indent=2))
