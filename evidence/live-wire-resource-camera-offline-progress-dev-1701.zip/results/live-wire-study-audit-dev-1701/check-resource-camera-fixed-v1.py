"""New raw-message/resource audits on unchanged old development files."""
import hashlib,json,sys
from pathlib import Path
from tools.benchmark.audit_live_wire_study import StudyEvidenceReader
from tools.benchmark.audit_live_wire_resources import audit_camera_info_records,audit_resource_graph_records

out=Path('results/live-wire-study-audit-dev-1701/resource-camera-fixed-v1')
out.mkdir()
reader=StudyEvidenceReader()
producer=out/'producer'
producer.mkdir()
for name in ['audit_live_wire_resources.py','audit_live_wire_study.py','bound_resource_graph.py','native_resource_client.py','selected_resource_graph.py','openvins_causal_input.py']:
    data=reader.raw(Path('tools/benchmark')/name)
    (producer/name).write_bytes(data)
(producer/'camera_info_capture.py').write_bytes(reader.raw(Path('src/flydrones/benchmark/camera_info_capture.py')))
(out/'harness.py').write_bytes(Path(__file__).read_bytes())
import gz.msgs10.camera_info_pb2 as camera
import google.protobuf as protobuf
sdk=[]
for name,path in [('camera_info.proto','/usr/share/gz/gz-msgs10/protos/gz/msgs/camera_info.proto'),('gazebo-copyright','/usr/share/doc/libgz-msgs10-dev/copyright'),('protobuf-copyright','/usr/share/doc/python3-protobuf/copyright')]:
    data=reader.raw(path)
    (producer/name).write_bytes(data)
for name,module in sorted(sys.modules.items()):
    if name.startswith(('gz.msgs10','google.protobuf')) and getattr(module,'__file__',None):
        path=Path(module.__file__)
        if path.is_file():
            data=reader.raw(path)
            sdk.append(dict(module=name,path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
root=Path('results/openvins-health-physical-dev-1701-v2/development-seed-27201/capture-v1')
checks,failures={},[]
try:
    sources=reader.lines(root/'events.jsonl')
    payloads={r['source_sequence']:reader.raw(reader.member(root,r['payload_path'])) for r in sources if r['kind']=='info'}
    checks['camera_info']=audit_camera_info_records(sources=sources,payloads=payloads,manifest=reader.document(root/'camera-info.json'),first_payload=reader.raw(root/'camera-info.pb'))
    pre=reader.document(root/'runtime-binding-pre.json')
    graph=reader.document(root/'resource-graph.json')
    documents={}
    for document in graph['documents']:
        row=next(r for r in pre['files'] if r['requested']==document['source'])
        documents[document['source']]=reader.declared_file({k:v for k,v in row.items() if k!='role'})
    paths=sorted(root.glob('resource-query-*.json'))
    assert [p.name for p in paths]==[f'resource-query-{i:04d}.json' for i in range(len(paths))]
    checks['resource_graph']=audit_resource_graph_records(declaration=pre['declaration'],pre=pre,after_queries=reader.document(root/'runtime-binding-after-queries.json'),graph=graph,context=reader.document(root/'resource-search-context.json'),queries=[reader.document(p) for p in paths],documents=documents)
except Exception as exc:
    failures.append(repr(exc))
finally:
    try: reader.finish()
    except Exception as exc: failures.append('input drift: '+repr(exc))
    result=dict(checks=checks,failures=failures,consumed_files=reader.files,decoder_modules=sdk,protobuf_runtime=protobuf.__version__,simulator_run=False,estimator_run=False,sdk_resolver_executed=False,live_qualified=False,fusion_qualified=False)
    with (out/'audit.json').open('x') as f: json.dump(result,f,indent=2,allow_nan=False)
    print(json.dumps(dict(checks=checks,failures=failures,consumed_files=len(reader.files)),indent=2))
if failures: raise SystemExit(2)
