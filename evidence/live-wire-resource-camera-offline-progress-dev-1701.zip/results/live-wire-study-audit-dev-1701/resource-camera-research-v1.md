# Resource and CameraInfo audit source decisions

Scope: Task2 read-only joins; no new sensor/estimator algorithm, SDK resolution,
physics, transport or training. Existing frozen profiles and thresholds remain.

Selected Gazebo CameraInfo parser: installed python3-gz-msgs10 10.4.0-1~noble,
Apache-2.0 (package copyright and camera_info.proto). Actual Python protobuf
runtime reports4.21.12; Debian package python3-protobuf3.21.12-8.2ubuntu0.3.
Do not conflate these version strings. Installed module path:
/usr/lib/python3/dist-packages/gz/msgs10/camera_info_pb2.py; proto path:
/usr/share/gz/gz-msgs10/protos/gz/msgs/camera_info.proto.
Source declares proto3, header/stamp, width/height, distortion(k1,k2,t1,t2,k3),
intrinsics/projection and rectification_matrix. Header stamp is normalized
sec/nsec. Adopt official decoder plus existing camera_info_fields/raw_profile;
reject unknown fields, invalid nanoseconds, truncated bytes and changed geometry.
Cost:251 bounded protobuf parses; no new dependency or Node/Server/transport.
A handwritten protobuf decoder is rejected due duplicate wire semantics.
Package presence/version is not proof of current upstream maintenance. No new
maintenance-status claim; installed version is fixed for this offline audit.
Calibration remains fixed simulation data, not dynamic/hardware calibration.

Resource selection: reuse native_resource_client.validate_response and the
original bound_resource_graph traversal with injected in-memory input/output.
Original production path retains bounded file read and write_manifest behavior.
QueryClient raw stdout_hex/stderr_hex, arguments, environment/cwd, clocks and
return status are authoritative inputs, not edge summary alone. The existing
fixed SDK source/API research from PR52-54 defines candidate semantics. This
increment does not re-execute SDK or infer current lookup ordering; it must
consume every recorded query and original XML document and reconstruct the
identical graph, retaining all duplicate references and unsupported failures.
Gazebo/Common/SDFormat Apache2 provenance and existing source snapshots unchanged.
Resource images/meshes are dependency identities, not decoded-rendering proof.
Recorded graph and maps cannot prove complete runtime closure; flag staysfalse.
No new paper algorithm adopted; existing OpenVINS/camera model unchanged.
