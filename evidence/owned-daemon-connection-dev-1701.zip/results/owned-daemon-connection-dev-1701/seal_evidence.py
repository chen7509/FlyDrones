import hashlib
import json
import re
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
sha=lambda data:hashlib.sha256(data).hexdigest()
archive=ROOT/'evidence/owned-daemon-connection-dev-1701.zip'
external=archive.with_name('owned-daemon-connection-dev-1701-manifest.json')
assert not archive.exists() and not external.exists()
assert (OUT/'full-tests-exit.txt').read_text().strip()=='0'
assert re.search(r'3125 passed, 3 skipped, 2 warnings in',(OUT/'full-tests.txt').read_text())
assert sha((ROOT/'evidence/openvins-cold-bootstrap-dev-1701.zip').read_bytes())=='bffc4fba2526dd470b0028ae4d02bd99d582841e67686d0e1f94840ce7181dd2'
matrix=json.loads((OUT/'kernel-v1/summary.json').read_text())
assert len(matrix)==5 and sum(x['evidence']['connection_peer_matched'] for x in matrix)==1
for case in matrix:
    assert case['evidence']['network_authorized'] is False and case['evidence']['fusion_qualified'] is False
    assert all(x['exit'] is not None for x in case['cleanup'])
    if case['case']!='owner-exited':
        assert json.loads((OUT/'kernel-v1'/case['case']/'server.json').read_text())==dict(application_bytes='',error=None)
paths=sorted(p for p in OUT.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
paths += [ROOT/p for p in (
    'tools/benchmark/owned_daemon_connection.py','tools/benchmark/owned_group_evidence.py',
    'tests/benchmark/test_owned_daemon_connection.py','tests/benchmark/check_owned_daemon_connection.py',
    'docs/OWNED_DAEMON_CONNECTION_REPORT.md',
    'docs/superpowers/specs/2026-10-08-owned-daemon-connection-design.md',
    'docs/superpowers/plans/2026-10-08-owned-daemon-connection.md',
    '.superpowers/sdd/2026-10-08-owned-daemon-connection/progress.md')]
payload={p.relative_to(ROOT).as_posix():p.read_bytes() for p in paths}
assert len(paths)==len(payload)
manifest=dict(schema='evidence-members-v1',producer='c5846ea',final_hardening='17b15fe',
    members=[dict(path=name,bytes=len(data),sha256=sha(data)) for name,data in sorted(payload.items())],
    physical_network_qualified=False,fusion_qualified=False,
    scope='ordinary same-descriptor AF_UNIX peer checks; no PX4/commands')
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in payload.items():
        z.writestr(name,data)
    z.writestr('member-manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for member in manifest['members']:
        data=z.read(member['path'])
        assert len(data)==member['bytes'] and sha(data)==member['sha256']
    count=len(z.namelist())
result=dict(archive=archive.relative_to(ROOT).as_posix(),sha256=sha(archive.read_bytes()),
    bytes=archive.stat().st_size,members=count,crc_verified=True,member_hashes_verified=True,
    historical_archive_unchanged=True)
with external.open('x',encoding='utf-8') as f:
    json.dump(result,f,indent=2)
print(json.dumps(result))
