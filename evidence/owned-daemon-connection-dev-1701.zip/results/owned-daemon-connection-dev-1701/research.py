import hashlib
import json
import platform
import urllib.request
from pathlib import Path

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
PIN='d6f12ad1c4f70ad3230afd7d86e971421e02fef4'
sha=lambda data:hashlib.sha256(data).hexdigest()
sources=[]
base='platforms/posix/src/px4/common/px4_daemon/'
for name in ('client.cpp','server.cpp','sock_protocol.cpp'):
    relative=base+name
    url=f'https://raw.githubusercontent.com/PX4/PX4-Autopilot/{PIN}/{relative}'
    data=urllib.request.urlopen(url,timeout=20).read()
    with (OUT/name).open('xb') as f:
        f.write(data)
    installed=Path('/home/yuchen7509/PX4-Autopilot')/relative
    assert installed.read_bytes()==data
    sources.append(dict(url=url,sha256=sha(data),installed_equal=True))
result=dict(px4_pin=PIN,px4_license='BSD-3-Clause',sources=sources,
    python=platform.python_version(),python_license='PSF',kernel=platform.release(),
    references=['https://man7.org/linux/man-pages/man7/unix.7.html',
                'https://docs.python.org/3.12/library/socket.html'],
    reference_scope='Read in web tool. Versioned PX4 files retained with hashes; no claim that rolling web pages are pinned source.',
    maintenance='Reuse prior PX4 metadata: nonarchived, observed last push2026-10-07T16:06:37Z; not a new observation.',
    decision='Use installed Python Linux SO_PEERCRED on the exact handed-over connection plus existing proc parser. Reject separate preflight connection/path-only/PID-only qualification.',
    limits='Credentials capture listener identity, not later inherited/transferred FD writers. Runtime dependency and launch provenance remain separate.',
    cost='No installation; one Unix stream socket and bounded proc snapshots per connection; runtime latency measured only in fixture.',
    paper='No new VIO/learning algorithm; this is OS/API/source-backed command transport ownership work.')
with (OUT/'research.json').open('x') as f:
    json.dump(result,f,indent=2)
print('3 pinned PX4 source files match installation; no PX4 launched')
