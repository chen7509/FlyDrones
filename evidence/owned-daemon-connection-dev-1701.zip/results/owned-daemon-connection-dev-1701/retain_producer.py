import hashlib
import json
import subprocess
from pathlib import Path

out=Path(__file__).resolve().parent
root=out.parents[1]
manifest=json.loads((out/'kernel-v1/prospective.json').read_text())
copies=[]
target=out/'producer-source'
target.mkdir(exist_ok=False)
for path in ('tests/benchmark/check_owned_daemon_connection.py',
             'tools/benchmark/owned_daemon_connection.py',
             'tools/benchmark/owned_group_evidence.py'):
    data=subprocess.check_output(['git','show',manifest['producer']+':'+path],cwd=root)
    expected=next(v for k,v in manifest['files'].items() if k.endswith('/'+path))
    assert hashlib.sha256(data).hexdigest()==expected
    destination=target/Path(path).name
    destination.write_bytes(data)
    copies.append(dict(path=path,sha256=expected,bytes=len(data)))
with (out/'producer-retention.json').open('x') as f:
    json.dump(dict(producer=manifest['producer'],files=copies,
        basis='post-run Git exports equal prospective and post-run recorded hashes; not contemporaneous source copies'),f,indent=2)
print('3 producer sources exported from Git and matched to recorded pre/post hashes')
