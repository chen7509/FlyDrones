# Remaining concrete command integration

Same-descriptor ownership is now implemented; do not repeat the5kernel cases or
old namespace/listener probes without a specific changed hypothesis. Latest
failure hardening was synthetic only; kernel-v1 has no raw peer_observations
field, and that field must not be retrospectively invented.

Read pinned client.cpp _send_cmds/_listen and server command handling, not merely
client.h (which mentions a half-close while actual inspected client does not
perform shutdown). Fixed command uses space-separated args plus isatty byte,
response ends in0/retval and requires EOF. Reuse source semantics with a narrow
read-only listener allowlist; do not expose arbitrary commands. The first
snapshot and explicit stream profiles remain different. An adapted Python
reader must be identified as an adapter, not unchanged upstream client code.

Use the exact socket returned by connect_owned_daemon; a separate verification
and reconnection loses the ownership guarantee. Restore deadlines explicitly:
returned timeout is only connect budget, not the stream's complete-frame clock.
Streaming needs bounded partial I/O, retained raw bytes, EOF/trailer/exit proof,
no stdout buffering assumption and immediate bootstrap refusal. Journal may
block; ordinary synthetic process test plus outer owned supervisor must qualify
the deadline behavior. Source/runtime binding remains required before any live
PX4. No ODOMETRY, stream mutation or parameter operation is authorized here.

Next implement/test that transport against an ordinary fixed-protocol fake
server and retained native listener bytes, then compose bootstrap and interval
restoration with a separately designed exclusive MAVLink responder. Preserve
all500accepted/8sreadiness/2sframe/25sphysical gates; no physical study is needed
to test command framing. Passing fixtures is not actual uORB or accepted live
TIMESYNC rate evidence. Full user objective remains open.
