import json
import re
import subprocess
from pathlib import Path

out=Path(__file__).resolve().parent
root=out.parents[1]
seal=json.loads((root/'evidence/owned-daemon-connection-dev-1701-manifest.json').read_text())
body=json.loads((out/'pr-before.json').read_text(encoding='utf-8-sig'))['body'].replace('\r\n','\n')
marker='## Startup gate remains open'
addition='''An owned daemon connection gate now checks SO_PEERCRED on the exact handed-over AF_UNIX descriptor against the registered process PID/start/group/session, effective credentials, executable/cwd identity and namespaces, including rechecks after journaling. An ordinary five-case kernel fixture passed its declared outcomes: matching peer only; wrong owner, inherited parent-created listener, owner exit and journal failure refused. Zero application bytes were sent. This is not a PX4 command adapter or protection against later FD transfer; actual cold lifecycle/transport integration remains unverified. Independent review's connect-plus-close error masking was fixed with two behavioral RED-to-GREEN cases, preserving interrupts. Final peer-observation fields are synthetic-tested only and are not backfilled into the old kernel fixture.

'''
assert marker in body
body=body.replace(marker,addition+marker)
pattern=r'Latest full regression \(offline cold bootstrap\):.*?(?=\n\nIndependent review found delayed refusal)'
replacement='''Latest full regression (owned daemon connection gate): **3125 passed, 3 skipped, 2 existing warnings**, with exit0. Focused adjacent ownership/runtime/bootstrap tests: **116 passed**. Independent read-only review and re-review found no remaining Critical/Important/Minor issues. Changed Ruff and Git whitespace checks passed; no whole-repository lint pass is claimed. The five kernel cases retained selected-file pre/post hashes, zero application-byte observations for live servers and explicit direct-owned-child cleanup. Final cleanup hardening and peer-value retention were not rerun as a new kernel study. Earlier bootstrap/framing results remain in their separate reports and archives.'''
body,n=re.subn(pattern,replacement,body,flags=re.S)
assert n==1
body=body.replace('Latest archive:', 'Preceding archive:',1)
record=(f'\n- `docs/OWNED_DAEMON_CONNECTION_REPORT.md`\n\nLatest archive: `{seal["archive"]}`, '
        f'SHA256 `{seal["sha256"]}`,{seal["members"]} members, CRC/member hashes verified. '
        'Kernel producer c5846ea; final failure hardening17b15fe. No PX4/Gazebo/OpenVINS, MAVLink or command bytes were used.\n')
body=body.replace('## Reports and evidence\n','## Reports and evidence\n'+record)
with (out/'pr-body.txt').open('x',encoding='utf-8',newline='\n') as f:
    f.write(body)
subprocess.run(['gh','pr','edit','65','--repo','chen7509/FlyDrones','--body-file',str(out/'pr-body.txt')],check=True)
raw=subprocess.check_output(['gh','pr','view','65','--repo','chen7509/FlyDrones','--json','body,headRefOid,isDraft'],text=True,encoding='utf-8')
with (out/'pr-after.json').open('x',encoding='utf-8',newline='\n') as f:
    f.write(raw)
actual=json.loads(raw)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert actual['headRefOid']==head and actual['isDraft'] is True
assert actual['body'].replace('\r\n','\n')==body
print('PR65 exact normalized body/draft/head verified: '+head)
