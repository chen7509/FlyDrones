# SDD ledger — plan: docs/superpowers/plans/2026-10-06-declared-launch-environment.md

Setup: existing isolated worktree `track-eligibility`, branch `codex/declared-launch-environment`, base `d15e89e`.

Previous goal turn classification: progress. It changed authoritative state by sealing the failed full-load study, publishing PR58, and proving the next dependency is the missing executable environment contract.

Ruling: the user's standing authorization covers this plan and its bounded non-physical harness. This stage explicitly excludes a new PX4/Gazebo/OpenVINS physical run.

Research basis: installed CPython 3.12.3/PSF; official `subprocess.Popen(env=...)`, CPython source, Linux `execve(2)` and `environ(7)`. The child environment is an explicit `envp`; missing names and present-empty values are distinct. No new dependency is adopted.

Pre-flight interface: Task 1 produces a nullable exact environment map consumed by Tasks 2–4. Task 2 passes only its non-null materialization to the real supervisor spawn. Task 3 independently observes the worker's initial `/proc/self/environ` before resources. Task 4's auditor consumes all three records. Task 5 exercises only a bounded absolute-path Python child.

Task 1: complete. Ten missing-function/signature tests first failed; final capture-contract suite 24 passed. `capture-execution-v2` is opt-in, v1 remains unchanged, and the nullable environment union preserves absent versus present-empty values while rejecting overlap conflicts, malformed names/values, mixed key types, NUL and declarations above 64 KiB.

Task 2: complete. Five missing supervisor transport/evidence tests first failed. The supervisor now records contract path/bytes/SHA, nullable declaration and exact materialization before spawn, passes only the materialized map to Popen, preserves that record on spawn failure, and refuses record I/O or invalid inputs before spawn. Legacy calls omit the new options and retain behavior.

Task 3: complete. Ten missing worker observation tests first failed. The worker parses a strictly terminated, unique UTF-8 `/proc/self/environ`, writes exact observed/declared/materialized evidence before active-resource inspection or generated copies, then refuses a mismatch. Parent integration derives v2 from a validated v3 binding and passes the exact environment plus contract to the supervisor. V2 consumes the already frozen Gazebo lookup path without a second prepend; v1 retains its legacy prepend. Combined contract/supervisor/binding suite: 84 passed before final import-order cleanup.

Task 4: complete. The full-load builder now derives v2 only from the merged validated v3 binding and validates the identical environment when constructing the declared command. A separate auditor requires contract bytes/hash, supervisor declaration/materialization, worker observed initial environment, clean terminal supervisor state, and graceful no-SIGKILL cleanup; it keeps physical/runtime-map/VIO/health/fusion/flight claims false. Initial auditor module collection failed as expected; final combined focused suite 112 passed/1 Windows symlink skip with changed Ruff and diff check passing.

Task 4 prepare wrapper attempt 0: shell redirection failed before the builder because the results parent did not exist. No dry-build directory or runtime process was created; the operator wrapper failure is retained separately.

Task 5 preparation: the bounded harness uses the production supervisor, execution contract, worker `/proc/self/environ` observer, and auditor with one absolute Python child only. The first cross-platform unit run failed because the test hard-coded `/usr/bin/python3` on Windows; production correctly rejected the nonexistent executable. The test now uses `sys.executable` without weakening the production absolute/existing-file check. Final harness unit result: 2 passed; focused Ruff passed. No PX4, Gazebo, OpenVINS, training, or capture process was active before the real harness.

Task 5 real harness: complete. A single bounded WSL child ran through the production supervisor in 8.4 wall seconds with a hostile ambient parent (`PYTHONPATH`, `HTTP_PROXY`, `LD_PRELOAD`) and exact nullable declaration. The worker observed exactly HOME, LANG, LC_ALL, PATH and present-empty SDF_PATH; all three hostile names were absent. Contract SHA is `1343773f57d9e603fbbe47b6ead6ae35a76fdbab4e3cd67a67aa4b862b6d75cb`. Worker exit 0/capture_completed; the owned group had no executing members, was absent after reap, and received no SIGKILL. The auditor found no failures and set only `environment_transport_verified=true`; physical/runtime-map/runtime-closure/VIO/health/fusion/flight claims remain false. No PX4, Gazebo, OpenVINS, training, or capture process remained afterward.

Task 6 verification: full regression 1,241 passed/3 skipped/2 existing warnings in 288.63s with this worktree's `src` explicitly selected; focused suite 90 passed/1 Windows symlink skip; changed-file Ruff and diff check passed. Whole-repository Ruff remains 53 findings in 34 files, equal to base `d15e89e`, so whole-repository lint is not claimed as passing. The report records the narrow qualification and the trajectory/gauge handoff.
