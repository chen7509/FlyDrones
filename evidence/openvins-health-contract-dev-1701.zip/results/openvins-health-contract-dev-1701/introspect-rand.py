try:
    import gz.math7 as m
    print('math7 names', [x for x in dir(m) if 'Rand' in x or 'rand' in x or 'seed' in x.lower()])
    if hasattr(m, 'Rand'):
        print('Rand', [x for x in dir(m.Rand) if 'seed' in x.lower() or 'rand' in x.lower()])
except Exception as e:
    print(type(e).__name__, repr(e))
