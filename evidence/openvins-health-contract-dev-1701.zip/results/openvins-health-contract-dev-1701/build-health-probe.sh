#!/usr/bin/env bash
set -euo pipefail
src=/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/tools/benchmark/openvins_online_probe.cpp
inc=/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/tools/benchmark
root=/home/yuchen7509/flydrones-upstream/open_vins_vio_init_probe
out=/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/results/openvins-health-contract-dev-1701/online_probe-health-v1
/usr/bin/g++ -std=c++17 -O3 -DNDEBUG -Wall -Wuninitialized \
  -I"$inc" -I"$root/ov_msckf/src" -I"$root/ov_core/src" -I"$root/ov_init/src" \
  -isystem /usr/include/eigen3 -isystem /usr/include/opencv4 \
  "$src" -o "$out" -L"$root/ov_msckf/build" -Wl,-rpath,"$root/ov_msckf/build" \
  -lov_msckf_lib $(pkg-config --libs opencv4) \
  -lboost_system -lboost_filesystem -lboost_thread -lboost_date_time -lglog -lgflags
sha256sum "$out"
ldd "$out"
