from gz.sim8 import ServerConfig, TestFixture
print([x for x in dir(ServerConfig) if 'seed' in x.lower() or 'sdf' in x.lower()])
print([x for x in dir(TestFixture) if 'seed' in x.lower() or 'server' in x.lower()])
