"""Cross-check all saved v6 yaw counts and fixed-source predicate."""

import json
from pathlib import Path


here = Path(__file__).resolve().parent
old = json.loads((here / "yaw-source.json").read_text())
new = json.loads((here / "yaw-source-v2.json").read_text())
assert old["schema"].endswith("v1") and new["schema"].endswith("v2")
for key in ("archive_sha256", "ulog_sha256", "topic_samples", "local_flags",
            "estimator_flags", "vehicle_status", "vehicle_land_detected", "heading_good_events"):
    assert old[key] == new[key], key
timeline = new["estimator_flag_timeline"]
assert len(timeline) == new["topic_samples"]["estimator_status_flags"] == 34
for field, counts in new["estimator_flags"].items():
    for value, count in counts.items():
        assert sum(row[field] == int(value) for row in timeline) == count
assert new["vehicle_status"]["arming_state"] == {"1": 51}
assert new["vehicle_land_detected"]["landed"] == {"1": 34}
assert new["estimator_flags"]["cs_mag_aligned_in_flight"] == {"0": 34}
assert new["estimator_flags"]["cs_ev_pos"] == {"0": 34}
assert new["local_flags"]["heading_good_for_control"] == {"0": 3050, "1": 9}
assert new["heading_good_events"][0]["timestamp_us"] == 3_172_000
assert new["heading_good_events"][-1]["timestamp_us"] == 3_236_000
first_mag_heading = next(row for row in timeline if row["cs_mag_hdg"] == 1)
assert first_mag_heading["timestamp_us"] == 3_244_000
assert all(row["cs_mag_aligned_in_flight"] == 0 for row in timeline)
source = (here / "px4-ekf.h").read_text()
assert "bool isYawFinalAlignComplete() const" in source
assert "_control_status.flags.mag_aligned_in_flight" in source
assert "(is_mag_alignment_in_flight_complete || !is_using_mag)" in source
assert "lpos.heading_good_for_control = _ekf.isYawFinalAlignComplete();" in (
    here / "px4-EKF2.cpp"
).read_text()
assert "_control_status.flags.in_air && _control_status.flags.yaw_align" in (
    here / "px4-mag_control.cpp"
).read_text()
print("v6 yaw readback/source cross-check passed: 34 flags, 9 transient heading rows, no EV")
