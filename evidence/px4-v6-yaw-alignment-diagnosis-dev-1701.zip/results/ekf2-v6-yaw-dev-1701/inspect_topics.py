"""Read-only PX4 yaw/arming source fields from the sealed v6 ULog."""

import hashlib
import json
import tempfile
import zipfile
from bisect import bisect_right
from collections import Counter
from pathlib import Path

from pyulog import ULog


root = Path(__file__).resolve().parents[2]
archive_path = root / "evidence/depth-physical-v5-v6-dev-1701.zip"
archive_sha = "30d968bbc295699f4a71f8b3b552e6eeaef829221f824a1795d666a22d2b7db6"
ulog_sha = "24a5f46b1bb8213b138bdd62b787e91579e8c48fb588d740c10dd716aaef4d05"
prefix = "results/depth-physical-development-preflight-dev-1701/study-v6/capture-v1/"
out = Path(__file__).resolve().parent / "yaw-source-v2.json"
if out.exists():
    raise FileExistsError(out)
if hashlib.sha256(archive_path.read_bytes()).hexdigest() != archive_sha:
    raise ValueError("sealed archive identity changed")
with zipfile.ZipFile(archive_path) as archive:
    raw = archive.read(prefix + "px4-ulog/log/2026-10-09/22_20_27.ulg")
if hashlib.sha256(raw).hexdigest() != ulog_sha:
    raise ValueError("sealed ULog identity changed")


def states(data, names):
    result = {}
    for name in names:
        if name not in data:
            result[name] = None
            continue
        counts = Counter(str(int(value)) for value in data[name])
        result[name] = dict(sorted(counts.items()))
    return result


with tempfile.TemporaryDirectory(prefix="flydrones-v6-yaw-") as temporary:
    source = Path(temporary) / "source.ulg"
    source.write_bytes(raw)
    ulog = ULog(str(source))
    available = {item.name for item in ulog.data_list}
    required = {"vehicle_local_position", "estimator_status_flags", "vehicle_status"}
    if not required <= available:
        raise ValueError("required yaw/arming topic missing")
    local = ulog.get_dataset("vehicle_local_position").data
    flags = ulog.get_dataset("estimator_status_flags").data
    status = ulog.get_dataset("vehicle_status").data
    land = ulog.get_dataset("vehicle_land_detected").data if "vehicle_land_detected" in available else None
    for name in ("timestamp", "heading_good_for_control", "dist_bottom_valid", "z"):
        if name not in local:
            raise ValueError("required local-position field missing: " + name)
    for name in ("timestamp", "cs_mag_hdg", "cs_mag_3d", "cs_mag_aligned_in_flight",
                 "cs_yaw_align", "cs_gnss_pos", "cs_ev_pos"):
        if name not in flags:
            raise ValueError("required estimator flag missing: " + name)
    if "arming_state" not in status or "timestamp" not in status:
        raise ValueError("required vehicle-status field missing")
    heading_rows = [int(i) for i, value in enumerate(local["heading_good_for_control"]) if value == 1]
    flag_times = list(flags["timestamp"])
    heading_events = []
    for i in heading_rows:
        t = int(local["timestamp"][i])
        j = bisect_right(flag_times, t) - 1
        heading_events.append({
            "timestamp_us": t,
            "preceding_flag_timestamp_us": None if j < 0 else int(flag_times[j]),
            "cs_mag_hdg": None if j < 0 else int(flags["cs_mag_hdg"][j]),
            "cs_mag_3d": None if j < 0 else int(flags["cs_mag_3d"][j]),
            "cs_mag_aligned_in_flight": None if j < 0 else int(flags["cs_mag_aligned_in_flight"][j]),
            "cs_gnss_pos": None if j < 0 else int(flags["cs_gnss_pos"][j]),
            "cs_ev_pos": None if j < 0 else int(flags["cs_ev_pos"][j]),
        })
    timeline = [{
        "timestamp_us": int(flags["timestamp"][i]),
        "cs_mag_hdg": int(flags["cs_mag_hdg"][i]),
        "cs_mag_3d": int(flags["cs_mag_3d"][i]),
        "cs_mag_aligned_in_flight": int(flags["cs_mag_aligned_in_flight"][i]),
        "cs_yaw_align": int(flags["cs_yaw_align"][i]),
        "cs_gnss_pos": int(flags["cs_gnss_pos"][i]),
        "cs_ev_pos": int(flags["cs_ev_pos"][i]),
    } for i in range(len(flags["timestamp"]))]
    result = {
        "schema": "flydrones-v6-px4-yaw-source-readback-v2",
        "archive_sha256": archive_sha,
        "ulog_sha256": ulog_sha,
        "topic_samples": {
            "vehicle_local_position": len(local["timestamp"]),
            "estimator_status_flags": len(flags["timestamp"]),
            "vehicle_status": len(status["timestamp"]),
            "vehicle_land_detected": None if land is None else len(land["timestamp"]),
        },
        "local_flags": states(local, ("heading_good_for_control", "dist_bottom_valid", "xy_valid", "z_valid")),
        "local_z_ned_m": {"min": float(min(local["z"])), "max": float(max(local["z"]))},
        "estimator_flags": states(flags, ("cs_mag_hdg", "cs_mag_3d", "cs_mag_aligned_in_flight",
                                           "cs_yaw_align", "cs_gnss_pos", "cs_ev_pos")),
        "estimator_flag_timeline": timeline,
        "vehicle_status": states(status, ("arming_state", "nav_state")),
        "vehicle_land_detected": None if land is None else states(land, ("landed", "in_ground_effect")),
        "heading_good_events": heading_events,
        "causal_explanation_qualified": False,
        "visual_fusion_qualified": False,
        "student_capture_qualified": False,
    }
out.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
print(json.dumps({
    "heading_good_rows": len(heading_rows),
    "estimator_flags": result["estimator_flags"],
    "vehicle_status": result["vehicle_status"],
    "vehicle_land_detected": result["vehicle_land_detected"],
}, sort_keys=True))
