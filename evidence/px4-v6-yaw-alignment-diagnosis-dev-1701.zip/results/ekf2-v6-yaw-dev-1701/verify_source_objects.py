"""Verify copied fixed-PX4 source bytes against recorded Git blob IDs."""

import hashlib
import json
import subprocess
from pathlib import Path


here = Path(__file__).resolve().parent
expected = {
    "px4-ekf.h": "5c778ac613c42dfac76edc35b39e80128b068e8f",
    "px4-EKF2.cpp": "f93f59085f9bd10aac312d6afee75d57927a72f7",
    "px4-mag_control.cpp": "d03229f7c2f9ff5e3a162d466843c9a931504780",
}
rows = {}
for name, blob_id in expected.items():
    path = here / name
    actual = subprocess.check_output(["git", "hash-object", str(path)], text=True).strip()
    if actual != blob_id:
        raise ValueError("fixed PX4 blob mismatch: " + name)
    rows[name] = {
        "git_blob_sha1": actual,
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "bytes": path.stat().st_size,
    }
result = {
    "schema": "flydrones-px4-v6-yaw-source-objects-v1",
    "px4_commit": "d6f12ad1c4f70ad3230afd7d86e971421e02fef4",
    "blobs": rows,
}
target = here / "source-hashes.json"
if target.exists():
    raise FileExistsError(target)
target.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
print(json.dumps(result, sort_keys=True))
