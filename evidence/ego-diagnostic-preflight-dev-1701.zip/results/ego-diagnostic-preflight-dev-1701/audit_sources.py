"""Verify additional fixed EGO sources and narrow instrumentation assumptions."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).resolve().parent
SOURCES = {
    "ego_planner_node.cpp": ("src/planner/plan_manage/src/ego_planner_node.cpp",
                             "89ec9a5b577bff2e035305cff2892612ef06b382"),
    "planner_manager.cpp": ("src/planner/plan_manage/src/planner_manager.cpp",
                            "2e420d4d6623cf5b1ebc3180f86e81dd2b85ffa6"),
    "plan_manage.CMakeLists.txt": ("src/planner/plan_manage/CMakeLists.txt",
                                   "f90cbfd089fbf104dffff6172607ae0fd8bc35e3"),
    "plan_env.CMakeLists.txt": ("src/planner/plan_env/CMakeLists.txt",
                                "d44d0b461078f8cdca2b9f9ce9c45b141e88be62"),
    "plan_manage.package.xml": ("src/planner/plan_manage/package.xml",
                                "c3a742f84c7265defd150b62629fbea38d2093bc"),
    "plan_env.package.xml": ("src/planner/plan_env/package.xml",
                             "c9894c7effb98e272157d48c8bb2982831a5ef3c"),
}


def main() -> None:
    prior = ROOT / "evidence/ego-causal-provenance-dev-1701.zip"
    if hashlib.sha256(prior.read_bytes()).hexdigest() != (
            "cb460e46c77cdff13a42a201bff2743384256ece9a687d580ed095e815e0aa14"):
        raise ValueError("prior pinned-source archive changed")
    files = {}
    for name, (upstream_path, expected_sha1) in SOURCES.items():
        data = (STAGE / "source" / name).read_bytes()
        blob = b"blob " + str(len(data)).encode("ascii") + b"\0" + data
        if hashlib.sha1(blob).hexdigest() != expected_sha1:
            raise ValueError(f"pinned source changed: {name}")
        files[name] = {
            "upstream_path": upstream_path, "git_blob_sha1": expected_sha1,
            "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data),
        }
    node = (STAGE / "source/ego_planner_node.cpp").read_text(encoding="utf-8")
    manager = (STAGE / "source/planner_manager.cpp").read_text(encoding="utf-8")
    cmake = (STAGE / "source/plan_env.CMakeLists.txt").read_text(encoding="utf-8")
    grid_map = (ROOT / "results/ego-causal-provenance-dev-1701/source/grid_map.cpp").read_text(
        encoding="utf-8")
    launch = (ROOT / "tools/benchmark/ego.launch.py").read_text(encoding="utf-8")
    anchors = {
        "single_thread_executor": "rclcpp::spin(node);" in node,
        "manager_owns_grid_map": "grid_map_.reset(new GridMap)" in manager,
        "depth_callback_pending_only": "md_.occ_need_update_ = true;" in grid_map,
        "timer_applies_depth": "void GridMap::updateOccupancyCallback()" in grid_map
        and "projectDepthImage();" in grid_map,
        "cloud_callback_can_mutate_map": "void GridMap::cloudCallback" in grid_map
        and "this->resetBuffer(md_.camera_pos_" in grid_map,
        "cloud_currently_remapped": "'/benchmark/ego/never_published_cloud'" in launch,
        "plan_env_has_no_openssl_link": "OpenSSL::Crypto" not in cmake,
    }
    if not all(anchors.values()):
        raise ValueError(f"upstream preflight anchor changed: {anchors}")
    result = {
        "upstream_commit": "23a8d5a191711dd65633df689bd00f55d4dea8f9",
        "prior_audit_sha256": hashlib.sha256(prior.read_bytes()).hexdigest(),
        "files": files, "anchors": anchors, "runtime_diagnostic_verified": False,
        "teacher_qualified": False,
    }
    (STAGE / "source-preflight.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"source_files": len(files), "anchors": len(anchors),
                      "runtime_diagnostic_verified": False}))


if __name__ == "__main__":
    main()
