"""Seal the limited EGO diagnostic preflight without qualifying a teacher."""

import hashlib
import json
import zipfile
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
STAGE = "results/ego-diagnostic-preflight-dev-1701"
OUT = ROOT / "evidence/ego-diagnostic-preflight-dev-1701.zip"
FILES = [
    "docs/EGO_DIAGNOSTIC_PREFLIGHT_REPORT.md",
    ".superpowers/sdd/2026-10-10-ego-causal-provenance/progress.md",
    "tools/benchmark/ego_node.py",
    "tests/benchmark/test_ego_wire_observation.py",
    *[f"{STAGE}/source/{name}" for name in (
        "ego_planner_node.cpp", "planner_manager.cpp",
        "plan_manage.CMakeLists.txt", "plan_env.CMakeLists.txt",
        "plan_manage.package.xml", "plan_env.package.xml",
    )],
    *[f"{STAGE}/{name}" for name in (
        "audit_sources.py", "source-preflight.json", "source-audit-output.txt",
        "session-gate-red.txt", "session-gate-green.txt",
        "session-adjacent-red.txt", "session-adjacent-green.txt",
        "final-tests.txt", "final-tests-v2.txt", "ruff.txt", "diff-check.txt",
        "seal.py",
    )],
]


def main() -> None:
    if OUT.exists():
        raise FileExistsError(OUT)
    entries = {}
    for relative in FILES:
        data = (ROOT / relative).read_bytes()
        entries[relative] = {
            "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
            "crc32": format(zlib.crc32(data) & 0xFFFFFFFF, "08x"),
        }
    with zipfile.ZipFile(OUT, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for relative in FILES:
            archive.write(ROOT / relative, relative)
        archive.writestr("MANIFEST.json", json.dumps(entries, indent=2, sort_keys=True))
    with zipfile.ZipFile(OUT) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == set(FILES) | {"MANIFEST.json"}
        for relative, expected in entries.items():
            data = archive.read(relative)
            assert len(data) == expected["bytes"]
            assert hashlib.sha256(data).hexdigest() == expected["sha256"]
            assert format(zlib.crc32(data) & 0xFFFFFFFF, "08x") == expected["crc32"]
    print(json.dumps({
        "zip": str(OUT), "members": len(FILES) + 1,
        "sha256": hashlib.sha256(OUT.read_bytes()).hexdigest(),
        "teacher_qualified": False,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
