"""Seal the failed physical attempt and subsequent offline repair, exclusively."""
import hashlib
import json
import subprocess
import zipfile
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
STUDY = HERE / 'study-v6'
CAPTURE = STUDY / 'capture-v1'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def doc(path):
    return json.loads(path.read_bytes())


def lines(path):
    return [json.loads(row) for row in path.read_bytes().splitlines() if row.strip()]


def main():
    for name, needle in [('callback-refusal-green-v2.txt', b'\nOK\n'),
                         ('callback-refusal-windows.txt', b'52 passed')]:
        assert needle in (HERE / name).read_bytes().replace(b'\r\n', b'\n'), name
    supervisor = doc(CAPTURE / 'supervisor.json')
    journal = lines(STUDY / 'capture-v1.supervisor-events.jsonl')
    assert journal == supervisor['cleanup']['events']
    events = lines(CAPTURE / 'events.jsonl')
    clock = lines(CAPTURE / 'wire-clock.jsonl')
    wire = lines(CAPTURE / 'wire-segments/segment-0000.jsonl')
    intervals = [r['event']['state'] for r in wire
                 if r['event'].get('kind') == 'interval_state']
    dispatch, completion = doc(STUDY / 'dispatch.json'), doc(STUDY / 'completion.json')
    summary = {
        'producer_commit': '7766bfc6e9cee8cde6c6980d60679cd30b69a819',
        'selected_manifest_sha256': sha((STUDY / 'study-manifest.json').read_bytes()),
        'source_record_counts': dict(Counter(r['kind'] for r in events)),
        'clock_records': len(clock), 'last_clock_sim_ns': clock[-1]['sim_ns'],
        'native_ack_count': len(lines(CAPTURE / 'shadow/native-acks.jsonl')),
        'native_ack_kinds': dict(Counter(r['kind'] for r in lines(CAPTURE / 'shadow/native-acks.jsonl'))),
        'native_reference_count': len(lines(CAPTURE / 'native-reference.jsonl')),
        'force_records': len(lines(CAPTURE / 'motion-force.jsonl')),
        'heartbeat_records': len(lines(CAPTURE / 'heartbeat-observations.jsonl')),
        'ulog_count': len(doc(CAPTURE / 'px4-ulog-manifest.json')['logs']),
        'supervisor_worker_exit': supervisor['worker_exit'],
        'supervisor_journal_matches': True,
        'supervisor_signal_events': [r for r in journal if 'signal' in r['event'] and r['event'] != 'snapshot'],
        'cleanup': {k: supervisor['cleanup'][k] for k in (
            'no_executing_members', 'group_absent', 'sigkill_dispatched',
            'graceful_group_cleanup_verified', 'all_descendant_cleanup_qualified')},
        'interval_last_state': intervals[-1],
        'dispatch_to_completion_wall_s': (completion['ended_wall_ns'] - dispatch['started_wall_ns']) / 1e9,
        'command_returncode': completion['command_returncode'],
        'resources_after': completion['resources_after'],
        'audit_refusals': doc(STUDY / 'audit.json')['refusals'],
        'normal_capture_qualified': False, 'live_qualified': False, 'fusion_qualified': False,
        'repair_retested_in_physics': False,
    }
    with (STUDY / 'failure-summary.json').open('x', encoding='utf-8') as stream:
        json.dump(summary, stream, indent=2)
    paths = {p for p in STUDY.rglob('*') if p.is_file()}
    paths.update(HERE / n for n in (
        'prepare-v6.py', 'prepare-v6-output.txt', 'committed-source-v6.json',
        'activation-context-v6.json', 'callback-refusal-red.txt', 'callback-refusal-red-v2.txt',
        'callback-refusal-red-v3.txt', 'callback-refusal-green.txt',
        'callback-refusal-green-v2.txt', 'callback-refusal-windows.txt', 'callback-review.txt',
        'seal_activation_v6.py'))
    paths.update(HERE / 'study-v5' / n for n in (
        'activation-cli-output.txt', 'execution-identity-diagnosis.json'))
    paths.update(ROOT / n for n in (
        'tools/benchmark/capture_wire_lifecycle.py',
        'tests/benchmark/test_capture_wire_lifecycle.py',
        'docs/LIVE_WIRE_FIRST_ACTIVATION_REPORT.md'))
    payload = {p.relative_to(ROOT).as_posix(): p.read_bytes() for p in sorted(paths)}
    source_copies = []
    for record in doc(STUDY / 'audit-source-dependencies.json')['files']:
        path = record['requested']
        prefix = '/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/'
        assert path.startswith(prefix)
        relative = path[len(prefix):]
        raw = (ROOT / relative).read_bytes()
        basis = 'post-run current bytes matched frozen source digest'
        if sha(raw) != record['sha256']:
            committed = subprocess.check_output(['git', 'show', summary['producer_commit'] + ':' + relative], cwd=ROOT)
            candidates = [committed, committed.replace(b'\r\n', b'\n').replace(b'\n', b'\r\n')]
            raw = next((b for b in candidates if sha(b) == record['sha256']), None)
            assert raw is not None, relative
            basis = 'post-run Git reconstruction with line ending conversion; digest matched, not a pre-run copy'
        payload['producer-source/' + relative] = raw
        source_copies.append(dict(path=relative, basis=basis, sha256=sha(raw)))
    manifest = {
        'schema': 'failed-physical-study-and-offline-repair-evidence-v1',
        'summary': summary, 'source_copies': source_copies,
        'installed_dependencies': 'identities/hashes in v6 declaration, not copies of every library or OS file',
        'members': [dict(path=n, bytes=len(b), sha256=sha(b)) for n, b in payload.items()],
    }
    encoded = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    archive = ROOT / 'evidence/live-wire-first-activation-dev-1701.zip'
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as sealed:
        for name, raw in payload.items():
            sealed.writestr(name, raw)
        sealed.writestr('MANIFEST.json', encoded)
    with zipfile.ZipFile(archive) as sealed:
        assert sealed.testzip() is None
        assert len(sealed.namelist()) == len(payload) + 1
        for name, raw in payload.items():
            assert sealed.read(name) == raw
        assert sealed.read('MANIFEST.json') == encoded
    seal = dict(archive=archive.relative_to(ROOT).as_posix(), sha256=sha(archive.read_bytes()),
                members=len(payload) + 1, bytes=archive.stat().st_size, crc_and_hashes_verified=True)
    with archive.with_suffix('.manifest.json').open('x', encoding='utf-8') as stream:
        json.dump(dict(seal=seal, manifest=manifest), stream, indent=2)
    print(json.dumps(seal))


if __name__ == '__main__':
    main()
