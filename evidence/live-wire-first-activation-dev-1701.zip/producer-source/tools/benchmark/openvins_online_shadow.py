"""Research-only bounded native transport; no network, commands or fusion grant."""

from __future__ import annotations

import copy
import hashlib
import json
import math
import os
import re
import select
import subprocess
import threading
import time
from contextlib import ExitStack

import numpy as np

from tools.benchmark.openvins_causal_input import CausalInput, InputRefusal
from tools.benchmark.openvins_health_contract import CovarianceProfile, OpenVinsHealthContract

MOTION_INTENT_ACTION_FIELDS = {
    "kind",
    "sample_ns",
    "source_arrival_ns",
    "session_id",
    "clock_id",
    "command_sequence",
    "intent_sha256",
}
MOTION_INTENT_NATIVE_ACK_FIELDS = {
    "sequence",
    "kind",
    "sample_ns",
    "receive_ns",
    "start_ns",
    "end_ns",
    "acknowledged_ns",
    "source_arrival_ns",
    "dispatch_ns",
    "intent_sha256",
    "estimator_session_sha256",
    "clock_id_sha256",
    "command_sequence",
    "internal_initialized",
    "has_moved_since_zupt",
    "motion_intent_applied",
    "try_zupt",
    "zupt_only_at_beginning",
    "reset_counter",
    "fusion_eligible",
    "quality",
}
CAMERA_HEALTH_ACK_FIELDS = {
    "sequence",
    "kind",
    "sample_ns",
    "receive_ns",
    "start_ns",
    "end_ns",
    "gray_first",
    "internal_initialized",
    "public_initialized",
    "initializer_time_s",
    "state_time_s",
    "last_regular_update_s",
    "zupt_flag_latched",
    "has_moved_since_zupt",
    "imu_state",
    "imu_covariance15",
    "fusion_eligible",
    "quality",
    "reset_counter",
}
CAMERA_HEALTH_TRANSPORT_FIELDS = {"acknowledged_ns", "source_arrival_ns", "dispatch_ns"}


def _sha256_text(value, name):
    if not isinstance(value, str) or not value or any(character.isspace() for character in value):
        raise ValueError("invalid " + name)
    return hashlib.sha256(value.encode()).hexdigest()


def _sha256_digest(value, name):
    if not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{64}", value):
        raise ValueError("invalid " + name)
    return value


def _integer(value, *, minimum=1):
    if type(value) is not int or not minimum <= value < 2**63:
        raise ValueError("invalid signed clock/sequence")
    return value


def encode_packet(action, *, sequence, dispatch_ns, pixels=None):
    if not isinstance(action, dict):
        raise ValueError("invalid native action")
    _integer(sequence, minimum=0)
    sample = _integer(action["sample_ns"])
    arrival = _integer(action["source_arrival_ns"])
    if _integer(dispatch_ns) < arrival:
        raise ValueError("dispatch precedes arrival")
    prefix = f"{sequence} {sample} {arrival} {dispatch_ns}"
    if action["kind"] == "imu":
        values = list(action["wm"]) + list(action["am"])
        try:
            valid = len(action["wm"]) == len(action["am"]) == 3 and all(
                type(v) in (int, float) and math.isfinite(v) for v in values
            )
        except OverflowError:
            valid = False
        if not valid or pixels is not None:
            raise ValueError("invalid IMU payload")
        packet = (f"I {prefix} " + " ".join(format(v, ".17g") for v in values) + "\n").encode("ascii")
        if len(packet) > 512:
            raise ValueError("oversized header")
        return packet
    if action["kind"] == "motion_intent":
        if set(action) != MOTION_INTENT_ACTION_FIELDS or pixels is not None:
            raise ValueError("invalid motion-intent action schema")
        command_sequence = _integer(action["command_sequence"], minimum=0)
        if command_sequence != 0:
            raise ValueError("invalid motion-intent command sequence")
        intent = _sha256_digest(action["intent_sha256"], "motion-intent hash")
        session = _sha256_text(action["session_id"], "estimator session")
        clock = _sha256_text(action["clock_id"], "clock domain")
        packet = f"M {prefix} {command_sequence} {intent} {session} {clock}\n".encode("ascii")
        if len(packet) > 512:
            raise ValueError("oversized header")
        return packet
    if action["kind"] != "camera" or type(pixels) is not bytes or len(pixels) != 57600:
        raise ValueError("invalid owned RGB bytes")
    return f"C {prefix} 57600\n".encode("ascii") + pixels


def project_motion_intent_ack(row, action):
    """Project one exact native M acknowledgement into MotionIntentGate's schema."""
    if not isinstance(row, dict) or set(row) != MOTION_INTENT_NATIVE_ACK_FIELDS:
        raise ValueError("invalid native motion-intent acknowledgement schema")
    if not isinstance(action, dict) or set(action) != MOTION_INTENT_ACTION_FIELDS:
        raise ValueError("invalid motion-intent action schema")
    expected_session = _sha256_text(action["session_id"], "estimator session")
    expected_clock = _sha256_text(action["clock_id"], "clock domain")
    if (
        row["kind"] != "M"
        or row["sample_ns"] != action["sample_ns"]
        or row["intent_sha256"] != _sha256_digest(action["intent_sha256"], "motion-intent hash")
        or row["estimator_session_sha256"] != expected_session
        or row["clock_id_sha256"] != expected_clock
        or row["command_sequence"] != action["command_sequence"]
        or row["internal_initialized"] is not True
        or row["has_moved_since_zupt"] is not True
        or row["motion_intent_applied"] is not True
        or row["try_zupt"] is not True
        or row["zupt_only_at_beginning"] is not True
        or row["reset_counter"] is not None
        or row["fusion_eligible"] is not False
        or row["quality"] is not None
    ):
        raise ValueError("native motion-intent acknowledgement mismatch")
    return {
        "kind": "M",
        "native_sequence": _integer(row["sequence"], minimum=0),
        "sample_ns": _integer(row["sample_ns"]),
        "intent_sha256": row["intent_sha256"],
        "estimator_session_sha256": row["estimator_session_sha256"],
        "clock_id_sha256": row["clock_id_sha256"],
        "command_sequence": row["command_sequence"],
        "receive_ns": _integer(row["receive_ns"]),
        "start_ns": _integer(row["start_ns"]),
        "end_ns": _integer(row["end_ns"]),
        "acknowledged_ns": _integer(row["acknowledged_ns"]),
        "internal_initialized": True,
        "has_moved_since_zupt": True,
        "motion_intent_applied": True,
        "try_zupt": True,
        "zupt_only_at_beginning": True,
        "reset_counter": None,
    }


def project_camera_health_row(row, *, session_id):
    """Validate one native camera acknowledgement and project health inputs."""
    if not isinstance(row, dict) or set(row) not in (
        CAMERA_HEALTH_ACK_FIELDS,
        CAMERA_HEALTH_ACK_FIELDS | CAMERA_HEALTH_TRANSPORT_FIELDS,
    ):
        raise ValueError("invalid native camera acknowledgement schema")
    if not isinstance(session_id, str) or not session_id.strip() or any(character.isspace() for character in session_id):
        raise ValueError("invalid estimator session identity")
    if (
        row["kind"] != "C"
        or type(row["internal_initialized"]) is not bool
        or type(row["public_initialized"]) is not bool
        or row["public_initialized"] and not row["internal_initialized"]
        or row["fusion_eligible"] is not False
        or row["quality"] is not None
        or row["reset_counter"] is not None
    ):
        raise ValueError("invalid native camera health flags")
    if row["internal_initialized"]:
        covariance = np.asarray(row["imu_covariance15"], dtype=float)
        if covariance.shape != (15, 15) or not np.all(np.isfinite(covariance)):
            raise ValueError("invalid native camera covariance")
        scale = max(1.0, float(np.max(np.abs(covariance))))
        if not np.allclose(covariance, covariance.T, rtol=0, atol=1e-10 * scale):
            raise ValueError("invalid native camera covariance")
        if float(np.linalg.eigvalsh((covariance + covariance.T) * 0.5)[0]) < -1e-12 * scale:
            raise ValueError("invalid native camera covariance")
        covariance_value = covariance.tolist()
    else:
        if row["imu_state"] is not None or row["imu_covariance15"] is not None:
            raise ValueError("uninitialized native camera has state")
        covariance_value = None
    for name in ("sample_ns", "receive_ns", "start_ns", "end_ns"):
        _integer(row[name])
    for name in ("state_time_s", "last_regular_update_s"):
        if type(row[name]) is bool or not isinstance(row[name], (int, float)) or not math.isfinite(row[name]):
            raise ValueError("invalid native camera state time")
    return {
        "kind": "C",
        "session_id": session_id,
        "sample_ns": row["sample_ns"],
        "internal_initialized": row["internal_initialized"],
        "public_initialized": row["public_initialized"],
        "state_time_s": row["state_time_s"],
        "last_regular_update_s": row["last_regular_update_s"],
        "imu_covariance15": covariance_value,
    }


def validate_ack(ack, *, sequence, kind, dispatch_ns, acknowledged_ns):
    if ack.get("sequence") != sequence or ack.get("kind") != kind:
        raise ValueError("native acknowledgement mismatch")
    clocks = [_integer(ack[k]) for k in ["receive_ns", "start_ns", "end_ns"]]
    if not dispatch_ns <= clocks[0] <= clocks[1] <= clocks[2] <= acknowledged_ns:
        raise ValueError("cross-process monotonic clock ordering invalid")
    return ack


def validate_frozen_config(config):
    """This experiment supports exactly one frozen top-level configuration and two calibrations."""
    expected = {"estimator_config.yaml", "kalibr_imu_chain.yaml", "kalibr_imucam_chain.yaml"}
    parent = config.parent.resolve()
    if config.name != "estimator_config.yaml" or config.is_symlink() or config.resolve().parent != parent:
        raise ValueError("selected estimator config is not the frozen entry")
    manifest = json.loads((parent / "freeze.json").read_text())
    hashes = manifest.get("sha256")
    if not isinstance(hashes, dict) or set(hashes) != expected:
        raise ValueError("frozen config requires exact nonempty estimator/calibration set")
    for name, digest in hashes.items():
        file = parent / name
        if file.is_symlink() or file.resolve().parent != parent or hashlib.sha256(file.read_bytes()).hexdigest() != digest:
            raise ValueError("frozen configuration/calibration changed")
    text = config.read_text()
    for key, expected_file in [
        ("relative_config_imu", "kalibr_imu_chain.yaml"),
        ("relative_config_imucam", "kalibr_imucam_chain.yaml"),
    ]:
        lines = re.findall(r"^" + key + r":\s*([^\n]+)$", text, re.M)
        if len(lines) != 1 or lines[0].strip().strip("\"'") != expected_file:
            raise ValueError("estimator references unverified calibration")
    return manifest


def _abort_owned_child(process):
    """Constructor rollback owns this child even before the caller can register cleanup."""
    if process.stdin:
        process.stdin.close()
    if process.poll() is None:
        process.terminate()
    try:
        process.wait(timeout=3)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=3)


class SourceWatchdog:
    """Independent of pending images: missing whole sources are failures."""

    def __init__(self, *, timeout_ns=2_000_000_000, startup_timeout_ns=None):
        self.timeout_ns = _integer(timeout_ns)
        self.startup_timeout_ns = _integer(startup_timeout_ns if startup_timeout_ns is not None else timeout_ns)
        self.started = None
        self.ready_ns = None
        self.last = {}
        self.lock = threading.Lock()

    def start(self, now):
        with self.lock:
            if self.started is not None:
                raise ValueError("source watchdog already started")
            self.started = _integer(now)

    def observe(self, kind, now):
        if kind not in {"imu", "rgb", "info"}:
            return
        with self.lock:
            _integer(now)
            if now <= self.last.get(kind, 0):
                raise ValueError("source arrival clock regressed")
            self.last[kind] = now
            if self.ready_ns is None and set(self.last) == {"imu", "rgb", "info"}:
                newest = max(self.last.values())
                if newest - min(self.last.values()) <= self.timeout_ns:
                    self.ready_ns = newest

    def snapshot(self):
        with self.lock:
            return dict(
                started_ns=self.started,
                ready_ns=self.ready_ns,
                last_arrivals=dict(self.last),
                startup_timeout_ns=self.startup_timeout_ns,
                operational_timeout_ns=self.timeout_ns,
            )

    def check(self, now):
        with self.lock:
            if self.started is None:
                return
            if _integer(now) < self.started:
                raise ValueError("watchdog clock regressed")
            if self.ready_ns is None:
                if now - self.started > self.startup_timeout_ns:
                    missing = [kind for kind in ["imu", "rgb", "info"] if kind not in self.last]
                    stale = [
                        kind
                        for kind in ["imu", "rgb", "info"]
                        if kind in self.last and now - self.last[kind] > self.timeout_ns
                    ]
                    raise TimeoutError("source startup: " + ",".join(missing + stale))
                return
            missing = [k for k in ["imu", "rgb", "info"] if now - self.last.get(k, self.started) > self.timeout_ns]
            if missing:
                raise TimeoutError("source silence: " + ",".join(missing))


class NativeClient:
    """POSIX one-in-flight byte channel with a single wall deadline for write+ack."""

    def __init__(self, command, output, *, timeout_s=2.0, on_first_ack=None):
        if os.name != "posix" or not math.isfinite(timeout_s) or timeout_s <= 0:
            raise ValueError("POSIX bounded transport required")
        self.timeout_s, self.sequence, self.failed = timeout_s, 0, None
        self.on_first_ack = on_first_ack
        self.output, self.buffer, self.closed = output, b"", False
        with ExitStack() as pending:
            self.log = pending.enter_context((output / "native.log").open("xb"))
            self.requests = pending.enter_context((output / "native-requests.jsonl").open("x"))
            self.acks = pending.enter_context((output / "native-acks.jsonl").open("x"))
            self.ack_fd, child_ack = os.pipe()
            pending.callback(os.close, self.ack_fd)
            pending.callback(os.close, child_ack)
            self.process = subprocess.Popen(
                command + [str(child_ack)],
                stdin=subprocess.PIPE,
                stdout=self.log,
                stderr=subprocess.STDOUT,
                pass_fds=(child_ack,),
                bufsize=0,
            )
            pending.callback(_abort_owned_child, self.process)
            os.set_blocking(self.process.stdin.fileno(), False)
            os.set_blocking(self.ack_fd, False)
            with (output / "native-session.json").open("x") as stream:
                json.dump(
                    dict(
                        pid=self.process.pid,
                        command=command,
                        started_monotonic_ns=time.monotonic_ns(),
                        reset_counter=None,
                        quality=None,
                        fusion_eligible=False,
                    ),
                    stream,
                    indent=2,
                )
            pending.pop_all()  # fully constructed: finish() now owns all remaining resources
        os.close(child_ack)

    def send(self, action, pixels=None):
        if self.closed or self.failed:
            raise RuntimeError("native client unavailable")
        dispatch = time.monotonic_ns()
        packet = encode_packet(action, sequence=self.sequence, dispatch_ns=dispatch, pixels=pixels)
        request = dict(
            sequence=self.sequence,
            action=action,
            dispatch_ns=dispatch,
            bytes=len(packet),
            packet_sha256=hashlib.sha256(packet).hexdigest(),
            rgb_sha256=hashlib.sha256(pixels).hexdigest() if pixels is not None else None,
        )
        self.requests.write(json.dumps(request, allow_nan=False) + "\n")
        self.requests.flush()
        deadline, written = time.monotonic() + self.timeout_s, 0
        try:
            while written < len(packet) or b"\n" not in self.buffer:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError("native write/processing acknowledgement deadline")
                reads, writes, _ = select.select(
                    [self.ack_fd], [self.process.stdin] if written < len(packet) else [], [], remaining
                )
                if writes:
                    written += os.write(self.process.stdin.fileno(), packet[written:])
                if reads:
                    data = os.read(self.ack_fd, 8192)
                    if not data:
                        raise RuntimeError("native acknowledgement EOF")
                    self.buffer += data
                    if len(self.buffer) > 8192:
                        raise ValueError("oversized native acknowledgement")
            line, self.buffer = self.buffer.split(b"\n", 1)
            acknowledged = time.monotonic_ns()
            ack = json.loads(line)
            validate_ack(ack, sequence=self.sequence, kind=chr(packet[0]), dispatch_ns=dispatch, acknowledged_ns=acknowledged)
            row = dict(ack, acknowledged_ns=acknowledged, source_arrival_ns=action["source_arrival_ns"], dispatch_ns=dispatch)
            self.acks.write(json.dumps(row, allow_nan=False) + "\n")
            self.acks.flush()
            if self.sequence == 0 and self.on_first_ack is not None:
                self.on_first_ack()
            self.sequence += 1
            return row
        except BaseException as exc:
            self.failed = repr(exc)
            self.acks.write(
                json.dumps(
                    dict(
                        sequence=self.sequence,
                        refusal=self.failed,
                        refused_monotonic_ns=time.monotonic_ns(),
                        bytes_written=written,
                    )
                )
                + "\n"
            )
            self.acks.flush()
            raise

    def send_motion_intent(self, action):
        return project_motion_intent_ack(self.send(action), action)

    def finish(self):
        if self.closed:
            raise RuntimeError("native client already closed")
        self.closed = True
        self.process.stdin.close()
        try:
            if self.failed:
                self.process.terminate()
            self.process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            self.failed = self.failed or "native exit deadline"
            self.process.kill()
            self.process.wait(timeout=3)
        finally:
            os.close(self.ack_fd)
            self.log.close()
            self.requests.close()
            self.acks.close()
        return dict(
            exit=self.process.returncode,
            accepted=self.sequence,
            failure=self.failed,
            fusion_eligible=False,
            quality=None,
            reset_counter=None,
        )


class OnlineHealthEvidence:
    """Journal derived health without altering native acknowledgements."""

    def __init__(self, output, *, session_id, profile=None):
        self.output = output
        self.contract = OpenVinsHealthContract(
            session_id,
            profile=profile if profile is not None else CovarianceProfile(),
        )
        self.records = (output / "health-evidence.jsonl").open("x", encoding="utf8")
        self.closed = False
        self.last = None
        self.session_count = 1

    @staticmethod
    def _healthy_source():
        return {
            "source_healthy": True,
            "native_healthy": True,
            "source_failure": None,
            "native_failure": None,
        }

    def _write(self, record):
        self.records.write(json.dumps(record, allow_nan=False, sort_keys=True) + "\n")
        self.records.flush()

    def observe_camera(self, native_row, source_health=None):
        if self.closed:
            raise RuntimeError("health evidence already closed")
        projected = project_camera_health_row(native_row, session_id=self.contract.session_id)
        health = self.contract.accept_camera(
            projected,
            self._healthy_source() if source_health is None else source_health,
        )
        self.last = copy.deepcopy(health)
        self._write(
            {
                "event": "camera_health",
                "native_sequence": native_row["sequence"],
                "sample_ns": native_row["sample_ns"],
                "projected": projected,
                "health": health,
                "fusion_eligible": False,
            }
        )
        return copy.deepcopy(health)

    def fail(self, reason):
        if self.closed:
            raise RuntimeError("health evidence already closed")
        health = self.contract.fail(reason)
        self.last = copy.deepcopy(health)
        self._write(
            {
                "event": "health_failure",
                "reason": reason,
                "health": health,
                "fusion_eligible": False,
            }
        )
        return copy.deepcopy(health)

    def replace_session(self, new_session_id):
        if self.closed:
            raise RuntimeError("health evidence already closed")
        previous = self.contract.session_id
        self.contract = self.contract.replace_session(new_session_id)
        self.session_count += 1
        transition = {
            "schema": "openvins-health-session-transition-v1",
            "previous_session_id": previous,
            "session_id": self.contract.session_id,
            "quality": 0,
            "reset_total": self.contract.reset_total,
            "reset_counter": self.contract.reset_total % 256,
            "covariance_profile": self.contract.profile.name,
            "covariance_sim_domain_qualified": self.contract.profile.sim_domain_qualified,
            "fusion_eligible": False,
        }
        self.last = copy.deepcopy(transition)
        self._write({"event": "session_replacement", "transition": transition, "fusion_eligible": False})
        return copy.deepcopy(transition)

    def finish(self):
        if self.closed:
            raise RuntimeError("health evidence already closed")
        self.closed = True
        self.records.close()
        result = {
            "schema": "openvins-online-health-result-v1",
            "session_id": self.contract.session_id,
            "session_count": self.session_count,
            "reset_total": self.contract.reset_total,
            "reset_counter": self.contract.reset_total % 256,
            "last_quality": self.last["quality"] if self.last is not None else 0,
            "last_health": self.last,
            "covariance_profile": self.contract.profile.name,
            "covariance_sim_domain_qualified": self.contract.profile.sim_domain_qualified,
            "fusion_eligible": False,
        }
        with (self.output / "health-result.json").open("x", encoding="utf8") as stream:
            json.dump(result, stream, indent=2, sort_keys=True, allow_nan=False)
            stream.write("\n")
        return result


class ShadowInput:
    """Recorder-thread-only adapter. On failure, stop native delivery but retain raw recording."""

    def __init__(self, client, output, *, session_id, now=time.monotonic_ns, health=None):
        self.client, self.output, self.now = client, output, now
        if health is not None and not isinstance(health, OnlineHealthEvidence):
            raise ValueError("invalid online health evidence")
        if health is not None and health.contract.session_id != session_id:
            raise ValueError("health and shadow session mismatch")
        self.health = health
        self.causal = CausalInput(session_id=session_id, clock_id="gazebo-sim+linux-monotonic")
        self.sequence, self.skipped, self.delivered = 0, 0, 0
        self.pixels, self.failure = {}, None
        self.delivery_acks = []
        self.released_unacknowledged = []
        self.failures = (output / "shadow-failures.jsonl").open("x")

    def on_record(self, row, payload):
        self.delivery_acks = []
        kind = row["kind"]
        if kind not in {"imu", "rgb", "info"}:
            return
        if self.failure:
            self.skipped += 1
            return
        keys = {"kind", "sample_ns", "arrival_monotonic_ns", "observed_sim_ns"}
        keys |= {"imu": {"gyro_flu", "accel_flu"}, "rgb": {"width", "height"}, "info": {"camera_info"}}[kind]
        base = {key: row[key] for key in keys}
        input_sequence = self.sequence
        undelivered = []
        attempted = False
        try:
            if kind == "rgb":
                if type(payload) is not bytes or len(payload) != 57600:
                    raise ValueError("invalid RGB bytes")
                if len(self.pixels) >= 8 or row["sample_ns"] in self.pixels:
                    raise ValueError("RGB buffer capacity/duplicate")
                self.pixels[row["sample_ns"]] = payload
            actions = self.causal.accept(
                base, sequence=self.sequence, session_id=self.causal.session_id, clock_id=self.causal.clock_id
            )
            self.sequence += 1
            undelivered = list(actions)
            while undelivered:
                action = undelivered[0]
                attempted = True
                pixels = self.pixels[action["sample_ns"]] if action["kind"] == "camera" else None
                acknowledgement = self.client.send(action, pixels)
                self.delivery_acks.append(copy.deepcopy(acknowledgement))
                if action["kind"] == "camera" and self.health is not None:
                    self.health.observe_camera(acknowledgement)
                self.delivered += 1
                if action["kind"] == "camera":
                    self.pixels.pop(action["sample_ns"])
                undelivered.pop(0)
                attempted = False
            # accept() advances the causal watermark from captured source-arrival clocks.
            # Local recording/native service time is bounded elsewhere and is not source silence.
        except Exception as exc:
            self.failure = repr(exc)
            health_last = self.health.fail("shadow_failure") if self.health is not None else None
            for index, action in enumerate(undelivered):
                pixels = self.pixels.get(action["sample_ns"]) if action["kind"] == "camera" else None
                self.released_unacknowledged.append(
                    dict(
                        action=action,
                        status="delivery_failed" if index == 0 and attempted else "never_attempted",
                        rgb_sha256=hashlib.sha256(pixels).hexdigest() if pixels is not None else None,
                        reason=self.failure,
                        fusion_eligible=False,
                    )
                )
            self.failures.write(
                json.dumps(
                    dict(
                        event=base,
                        input_sequence=input_sequence,
                        released_unacknowledged=self.released_unacknowledged,
                        failure=self.failure,
                        wall_ns=self.now(),
                        input_refusal=exc.disposition if isinstance(exc, InputRefusal) else None,
                        health=health_last,
                    ),
                    allow_nan=False,
                )
                + "\n"
            )
            self.failures.flush()

    def tick_idle(self, wall_monotonic_ns):
        """Advance pending age only at an externally proven empty source FIFO boundary."""
        if self.failure:
            return False
        try:
            self.causal.tick(wall_monotonic_ns)
        except Exception as exc:
            self.failure = repr(exc)
            self.failures.write(
                json.dumps(
                    dict(
                        event={"kind": "source_idle_tick", "wall_monotonic_ns": wall_monotonic_ns},
                        input_sequence=self.sequence,
                        released_unacknowledged=self.released_unacknowledged,
                        failure=self.failure,
                        wall_ns=wall_monotonic_ns,
                        input_refusal=None,
                    ),
                    allow_nan=False,
                )
                + "\n"
            )
            self.failures.flush()
            return False
        return True

    def finish(self):
        result = dict(
            failure=self.failure,
            inputs_accepted=self.sequence,
            delivered=self.delivered,
            skipped_after_failure=self.skipped,
            pending=self.causal.finish(),
            retained_pixel_stamps=list(self.pixels),
            released_unacknowledged=self.released_unacknowledged,
            fusion_eligible=False,
            quality=None,
            reset_counter=None,
            last_delivery_acks=copy.deepcopy(self.delivery_acks),
            health_last=copy.deepcopy(self.health.last) if self.health is not None else None,
        )
        self.failures.close()
        with (self.output / "shadow-input-result.json").open("x") as stream:
            json.dump(result, stream, indent=2)
        return result
