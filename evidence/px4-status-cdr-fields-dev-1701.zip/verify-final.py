import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import zipfile

import flydrones.connectome_training.px4_status_cdr_fields as candidate
import rosbags.typesys as typesys

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent / "final-v1"
out.mkdir()
expected_source = root / "src/flydrones/connectome_training/px4_status_cdr_fields.py"
deps = root / "results/ego-cdr-field-audit-dev-1701/deps"
if Path(candidate.__file__).resolve() != expected_source or not Path(typesys.__file__).resolve().is_relative_to(deps):
    raise RuntimeError("wrong candidate/decoder imports")
if importlib.metadata.version("rosbags") != "0.11.5":
    raise RuntimeError("wrong fixed decoder version")
wheel = root / "results/ego-cdr-field-audit-dev-1701/rosbags-0.11.5-py3-none-any.whl"
decoder_hashes = {}
with zipfile.ZipFile(wheel) as contents:
    for name in contents.namelist():
        if name.startswith("rosbags/") and name.endswith(".py"):
            raw = (deps / name).read_bytes()
            if raw != contents.read(name):
                raise RuntimeError("installed private decoder source differs from wheel")
            decoder_hashes[name] = hashlib.sha256(raw).hexdigest()
files = [
    "src/flydrones/connectome_training/px4_status_cdr_fields.py",
    "src/flydrones/connectome_training/px4_status_source_journal.py",
    "tests/connectome_training/test_px4_status_cdr_fields.py",
    "tests/fixtures/px4_status_transport/EstimatorStatus.d6f12ad.msg",
]
before = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in files}
for name in files:
    target = out / "sources" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root / name, target)
commands = {
    "adjacent": [sys.executable, "-m", "pytest", "-q", "-rs",
                 "tests/connectome_training/test_px4_status_cdr_fields.py",
                 "tests/connectome_training/test_px4_status_source_journal.py",
                 "tests/connectome_training/test_status_journal_synthetic_runner.py",
                 "tests/connectome_training/test_status_journal_evidence_seal.py"],
    "ruff": [sys.executable, "-m", "ruff", "check", files[0], files[2]],
    "diff": ["git", "diff", "--check"],
}
records = []
for name, command in commands.items():
    start = time.monotonic()
    completed = subprocess.run(command, cwd=root, capture_output=True, text=True, timeout=180)
    (out / (name + ".txt")).write_text(completed.stdout + completed.stderr, encoding="utf-8")
    records.append({"name": name, "command": command, "returncode": completed.returncode,
                    "elapsed_wall_s": time.monotonic() - start})
    print(name, completed.returncode, completed.stdout.strip()[-1000:])
after = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in files}
for name, digest in decoder_hashes.items():
    if hashlib.sha256((deps / name).read_bytes()).hexdigest() != digest:
        raise RuntimeError("decoder source changed")
record = {"commands": records, "source_before": before, "source_after": after,
          "source_unchanged": before == after, "decoder_sources_before_after": decoder_hashes,
          "rosbags_wheel_sha256": hashlib.sha256(wheel.read_bytes()).hexdigest(),
          "decoder_version": importlib.metadata.version("rosbags"),
          "decoder_license": importlib.metadata.metadata("rosbags").get("License-Expression"),
          "candidate_origin": candidate.__file__, "decoder_origin": typesys.__file__,
          "python": sys.version, "pythonpath": os.environ.get("PYTHONPATH"),
          "physical_ros_or_training_process_started": False}
(out / "execution.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
if before != after or any(item["returncode"] for item in records):
    raise RuntimeError("final verification failed")
