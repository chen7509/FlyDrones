import hashlib
import json
from pathlib import Path
import shutil
import zipfile

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
verified = json.loads((out / "final-v1/execution.json").read_text())
if not verified["source_unchanged"] or any(item["returncode"] for item in verified["commands"]):
    raise RuntimeError("final checks failed")
for name, digest in verified["source_after"].items():
    if hashlib.sha256((root / name).read_bytes()).hexdigest() != digest:
        raise RuntimeError("final source drift")
audit = json.loads((out / "retained-v2/audit.json").read_text())
archive = root / "evidence/px4-estimator-status-journal-dev-1701.zip"
if hashlib.sha256(archive.read_bytes()).hexdigest() != audit["source_archive_sha256"]:
    raise RuntimeError("old source ZIP drift")
inputs = out / "consumed-inputs"
inputs.mkdir()
with zipfile.ZipFile(archive) as old:
    for name, expected in audit["consumed_members"].items():
        raw = old.read(name)
        if hashlib.sha256(raw).hexdigest() != expected["sha256"] or len(raw) != expected["bytes"]:
            raise RuntimeError("consumed member drift")
        target = inputs / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as handle:
            handle.write(raw)
docs = ["docs/PX4_STATUS_CDR_FIELD_BINDING_REPORT.md",
        "docs/superpowers/specs/2026-10-12-px4-status-cdr-field-binding-design.md",
        "docs/superpowers/plans/2026-10-12-px4-status-cdr-field-binding.md"]
for name in docs:
    target = out / "documents" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root / name, target)
wheel = root / "results/ego-cdr-field-audit-dev-1701/rosbags-0.11.5-py3-none-any.whl"
if hashlib.sha256(wheel.read_bytes()).hexdigest() != verified["rosbags_wheel_sha256"]:
    raise RuntimeError("decoder wheel drift")
shutil.copyfile(wheel, out / wheel.name)
research = {
    "observed_client_date": "2026-10-12", "decoder_version": "0.11.5",
    "decoder_license": "Apache-2.0", "decoder_maintenance": "Pinned existing package; current upstream activity not newly established",
    "px4_commit": "d6f12ad1c4f70ad3230afd7d86e971421e02fef4", "px4_license": "BSD-3-Clause",
    "urls": ["https://ternaris.gitlab.io/rosbags/topics/typesys.html",
             "https://github.com/PX4/PX4-Autopilot/blob/d6f12ad1c4f70ad3230afd7d86e971421e02fef4/msg/EstimatorStatus.msg"],
    "adoption": "Reuse official .msg parser/CDR type store and existing pinned optional package; no hand-built message layout",
    "adaptation_resources": "Bounded offline journal bytes and constant fixed message decode; no source/physics process",
    "capability_observation": "Global Windows/WSL metadata lookup failed; existing private dependency source/wheel worked. These are research observations, not raw RED producer logs.",
    "not_qualified": "Complete Python/OS runtime closure, publisher/clock/upstream loss/calibration/fusion/training/flight",
}
(out / "research.json").write_text(json.dumps(research, indent=2), encoding="utf-8")
members = {}
for path in sorted(out.rglob("*")):
    if not path.is_file() or path.name in ("seal.json", "manifest.json"):
        continue
    if path.is_symlink():
        raise RuntimeError("linked stage evidence")
    members[path.relative_to(out).as_posix()] = path.read_bytes()
manifest = {name: {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)} for name, raw in members.items()}
members["manifest.json"] = json.dumps({"schema": "flydrones.px4_status_cdr_field_binding_evidence.v1",
                                       "members": manifest}, indent=2).encode()
(out / "manifest.json").write_bytes(members["manifest.json"])
target = root / "evidence/px4-status-cdr-fields-dev-1701.zip"
with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED) as archive:
    for name, raw in members.items():
        archive.writestr(name, raw)
with zipfile.ZipFile(target) as archive:
    if archive.testzip() is not None or set(archive.namelist()) != set(members):
        raise RuntimeError("ZIP CRC/member mismatch")
    for name, raw in members.items():
        if archive.read(name) != raw:
            raise RuntimeError("ZIP member bytes mismatch")
digest = hashlib.sha256(target.read_bytes()).hexdigest()
with target.with_suffix(".sha256").open("x", encoding="ascii") as handle:
    handle.write(f"{digest}  {target.name}\n")
record = {"path": str(target), "sha256": digest, "bytes": target.stat().st_size,
          "members": len(members), "all_member_bytes_and_crc_verified": True,
          "final_source_hashes_verified": True}
(out / "seal.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
print(json.dumps(record, indent=2))
