import hashlib
import importlib.metadata
import json
import os
import sys
from pathlib import Path
import zipfile

from flydrones.connectome_training.px4_status_cdr_fields import audit_status_cdr_fields

root = Path(__file__).resolve().parents[2]
if sys.argv[1:] not in ([], ["--final-framing-v2"]):
    raise RuntimeError("unknown fixed audit variant")
out = Path(__file__).resolve().parent / ("retained-v2" if sys.argv[1:] else "retained-v1")
out.mkdir()
archive_path = root / "evidence/px4-estimator-status-journal-dev-1701.zip"
archive_bytes = archive_path.read_bytes()
archive_sha = hashlib.sha256(archive_bytes).hexdigest()
if archive_sha != "6fbefedf287fb6915fd208211d2f0fbd18d825a08e0c0ff30cd6158387cc9a4d":
    raise RuntimeError("retained source archive changed")
definition = (root / "tests/fixtures/px4_status_transport/EstimatorStatus.d6f12ad.msg").read_bytes()
source_hashes = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in (
    "src/flydrones/connectome_training/px4_status_cdr_fields.py",
    "src/flydrones/connectome_training/px4_status_source_journal.py",
)}
records = {}
consumed = {}
prefix = "results/px4-status-journal-synthetic-dev-1701-v2/"
with zipfile.ZipFile(archive_path) as archive:
    manifest = json.loads(archive.read("manifest.json"))["members"]
    def consume(name):
        data = archive.read(name)
        expected = manifest[name]
        digest = hashlib.sha256(data).hexdigest()
        if digest != expected["sha256"] or len(data) != expected["size"]:
            raise RuntimeError("retained consumed member changed")
        consumed[name] = {"sha256": digest, "bytes": len(data)}
        return data

    for case, expected_exit in (("normal", 0), ("fsync_eio", 2), ("close_eio", 2), ("partial_then_eio", 1)):
        raw = consume(prefix + case + "/source.jsonl")
        exit_bytes = consume(prefix + case + "/subscriber.exit")
        if exit_bytes.decode().strip() != str(expected_exit):
            raise RuntimeError("retained owned writer exit changed")
        target = out / (case + ".jsonl")
        with target.open("xb") as stream:
            stream.write(raw)
        try:
            result = audit_status_cdr_fields(target, definition, observed_writer_exit_code=expected_exit)
            if case == "partial_then_eio":
                raise RuntimeError("malformed partial-write record was accepted")
            if result["writer_completed"] is not (case == "normal") or not result["logged_fields_verified"]:
                raise RuntimeError("retained field/completion predicate failed")
            records[case] = result
        except ValueError as exc:
            if case != "partial_then_eio":
                raise
            records[case] = {"refused": True, "reason": str(exc), "observed_writer_exit_code": expected_exit,
                             "logged_fields_verified": False, "training_eligible": False}

for name, digest in source_hashes.items():
    if hashlib.sha256((root / name).read_bytes()).hexdigest() != digest:
        raise RuntimeError("audit source changed")
if hashlib.sha256(archive_path.read_bytes()).hexdigest() != archive_sha:
    raise RuntimeError("retained archive changed during audit")
record = {"source_archive_sha256": archive_sha, "consumed_members": consumed, "cases": records,
          "source_before_after_sha256": source_hashes, "pythonpath": os.environ.get("PYTHONPATH"),
          "rosbags_version": importlib.metadata.version("rosbags"),
          "rosbags_license": importlib.metadata.metadata("rosbags").get("License-Expression"),
          "physical_ros_or_training_process_started": False}
(out / "audit.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
print(json.dumps({name: {key: value for key, value in result.items() if key in (
    "samples", "writer_completed", "logged_fields_verified", "refused", "reason", "training_eligible"
)} for name, result in records.items()}, indent=2))
