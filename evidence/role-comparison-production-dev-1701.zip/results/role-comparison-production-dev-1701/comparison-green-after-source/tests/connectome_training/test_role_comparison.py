import importlib
import json
import weakref
from dataclasses import replace

import pytest
import torch

from flydrones.connectome_training import curriculum_session as sessions
from test_learning_roles import PROFILES, config as _config, inert_backends as _inert
from tools.connectome_training import run_curriculum as cli

config = _config
inert_backends = _inert


def producer():
    return importlib.import_module("flydrones.connectome_training.role_comparison")


def test_actual_three_roles_train_checkpoint_and_release_between_variants(config, tmp_path, monkeypatch):
    module = producer()
    actual = sessions.ConnectomeCurriculumSession
    previous = []
    changed = []
    run = module.run_curriculum

    def build(*args, **kwargs):
        assert all(ref() is None for ref in previous)
        current = actual(*args, **kwargs)
        previous.append(weakref.ref(current))
        return current

    def train(cfg, path, current, **kwargs):
        before = {n: p.detach().clone() for n, p in current.model.named_parameters()}
        state = run(cfg, path, current, **kwargs)
        updated = {n for n, p in current.model.named_parameters() if not torch.equal(before[n], p)}
        assert updated and updated <= PROFILES[current.learning_roles["profile"]]
        changed.append(updated)
        return state

    monkeypatch.setattr(module, "ConnectomeCurriculumSession", build)
    monkeypatch.setattr(module, "run_curriculum", train)
    result = module.run_role_comparison(config, tmp_path / "experiment", max_batches=2, device="cpu", dynamics_format="frozen-drive-exponential-v1")
    assert result["status"] == "FINISHED" and len(changed) == 3
    assert all(ref() is None for ref in previous)
    assert result["training_success_verified"] is False and result["flight_eligible"] is False
    assert [r["learning_profile"] for r in result["variants"]] == list(PROFILES)
    assert len({r["state"]["model_identity"] for r in result["variants"]}) == 3
    for row in result["variants"]:
        root = tmp_path / "experiment" / row["learning_profile"]
        reports = [json.loads(p.read_bytes()) for p in (root / "reports").glob("*.json")]
        assert 1 <= len(reports) <= 2
        assert row["committed_batches"] == len(reports)
        assert row["state"]["global_updates"] == sum(r["train_metrics"]["updates"] for r in reports)
        assert row["state"]["environment_steps"] == sum(r["train_metrics"]["environment_steps"] for r in reports)
        assert (root / row["state"]["latest_checkpoint"] / "manifest.json").is_file()
        assert set(row["final_validation"]) == {s.id for s in config.stages}
    assert json.loads((tmp_path / "experiment/comparison.json").read_bytes()) == result


@pytest.mark.parametrize("field", ["dataset_sha256", "mapping_sha256", "initial_losses", "learning_initialization", "truncate_steps", "loss_weights", "optimizer"])
def test_later_baseline_drift_stops_before_second_training(config, tmp_path, monkeypatch, field):
    module = producer()
    actual = sessions.ConnectomeCurriculumSession
    train = module.run_curriculum
    calls = []

    def build(*args, **kwargs):
        current = actual(*args, **kwargs)
        if kwargs["learning_profile"] == "sensory-readout-v1":
            if field == "initial_losses":
                current.initial_losses = {k: v + 1 for k, v in current.initial_losses.items()}
            elif field == "learning_initialization":
                current.learning_initialization = {"different": True}
            elif field == "loss_weights":
                current.loss_weights = replace(current.loss_weights, imitation=7.0)
            elif field == "optimizer":
                current.optimizer.param_groups[0]["lr"] *= 2
            elif field == "truncate_steps":
                current.truncate_steps += 1
            else:
                setattr(current, field, "changed")
        return current

    def observed(cfg, path, current, **kwargs):
        calls.append(current.learning_roles["profile"])
        return train(cfg, path, current, **kwargs)

    monkeypatch.setattr(module, "ConnectomeCurriculumSession", build)
    monkeypatch.setattr(module, "run_curriculum", observed)
    with pytest.raises(ValueError, match="shared baseline"):
        module.run_role_comparison(config, tmp_path / "experiment", max_batches=1, device="cpu")
    assert calls == ["descending-only-v1"]
    record = json.loads((tmp_path / "experiment/comparison.json").read_bytes())
    assert record["status"] == "ERROR" and record["variants"][-1]["status"] == "ERROR"
    assert not (tmp_path / "experiment/shared-dynamics-v1").exists()


def test_partial_training_failure_preserves_artifacts_and_never_retries(config, tmp_path, monkeypatch):
    module = producer()
    actual = sessions.ConnectomeCurriculumSession.train_batch
    calls = []

    def train(current, *args, **kwargs):
        result = actual(current, *args, **kwargs)
        calls.append(current.learning_roles["profile"])
        if current.learning_roles["profile"] == "sensory-readout-v1":
            raise RuntimeError("after real optimizer updates")
        return result

    monkeypatch.setattr(sessions.ConnectomeCurriculumSession, "train_batch", train)
    path = tmp_path / "experiment"
    with pytest.raises(RuntimeError, match="after real"):
        module.run_role_comparison(config, path, max_batches=1, device="cpu")
    assert calls == ["descending-only-v1", "sensory-readout-v1"]
    record = (path / "comparison.json").read_bytes()
    assert json.loads(record)["status"] == "ERROR"
    monkeypatch.setattr(module, "ConnectomeCurriculumSession", lambda *a, **k: pytest.fail("reused root reached model"))
    with pytest.raises(FileExistsError):
        module.run_role_comparison(config, path, max_batches=1, device="cpu")
    assert (path / "comparison.json").read_bytes() == record


@pytest.mark.parametrize("cap", [None, True, 0, -1, 1.5])
def test_invalid_cap_rejected_before_output_or_session(config, tmp_path, monkeypatch, cap):
    module = producer()
    monkeypatch.setattr(module, "ConnectomeCurriculumSession", lambda *a, **k: pytest.fail("invalid cap reached model"))
    with pytest.raises(ValueError, match="max_batches"):
        module.run_role_comparison(config, tmp_path / "absent", max_batches=cap)
    assert not (tmp_path / "absent").exists()


def test_cli_comparison_rejects_restart_before_any_effect(monkeypatch):
    monkeypatch.setattr("sys.argv", ["run_curriculum", "--compare-learning-roles", "--max-batches", "1", "--restart"])
    monkeypatch.setattr(cli, "_restart", lambda *a: pytest.fail("destructive restart"))
    monkeypatch.setattr(cli, "load_curriculum_config", lambda *a: pytest.fail("configuration effect"))
    with pytest.raises(ValueError, match="restart"):
        cli.main()
