"""Seal this development stage once, retaining all previous failures and raw data."""
import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[2]
stage = Path(__file__).resolve().parent
archive = root / 'evidence/disarmed-sensor-provenance-dev-1701.zip'
paths = [p for p in stage.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
paths += [root / p for p in [
    'docs/DISARMED_SENSOR_PROVENANCE_REPORT.md',
    'docs/superpowers/specs/2026-10-06-disarmed-sensor-provenance-design.md',
    'docs/superpowers/plans/2026-10-06-disarmed-sensor-provenance.md',
    'tools/benchmark/disarmed_sensor_provenance.py', 'tools/benchmark/capture_disarmed_sensors.py',
    'tools/benchmark/audit_disarmed_sensors.py', 'tests/benchmark/test_disarmed_sensor_provenance.py',
    'tests/benchmark/check_disarmed_lifecycle.py',
    '.superpowers/sdd/2026-10-06-disarmed-sensor-provenance/progress.md',
    '.superpowers/sdd/2026-10-06-disarmed-sensor-provenance/task-1-tests.log']]
manifest = {str(p.relative_to(root)).replace('\\', '/'): {'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'bytes': p.stat().st_size}
            for p in sorted(paths)}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as bundle:
    for name in manifest:
        bundle.write(root / name, name)
    bundle.writestr('SHA256-MANIFEST.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    for name, expected in manifest.items():
        assert hashlib.sha256(bundle.read(name)).hexdigest() == expected['sha256']
summary = {'path': str(archive.relative_to(root)), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
           'bytes': archive.stat().st_size, 'members': len(manifest) + 1}
with archive.with_suffix('.seal.json').open('x') as stream:
    json.dump(summary, stream, indent=2)
print(json.dumps(summary, indent=2))
