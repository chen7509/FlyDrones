import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[2]
stage = Path(__file__).resolve().parent
dest = stage / 'producer-v2b-snapshot'
dest.mkdir(exist_ok=False)
paths = [root / p for p in ['tools/benchmark/capture_disarmed_sensors.py', 'tools/benchmark/disarmed_sensor_provenance.py',
    'tools/benchmark/audit_disarmed_sensors.py', 'src/flydrones/benchmark/rgb_capture.py',
    'src/flydrones/benchmark/camera_info_capture.py', 'src/flydrones/benchmark/ulog_capture.py',
    'src/flydrones/benchmark/gateway.py', 'assets/gazebo/models/x500_benchmark/model.sdf',
    'assets/gazebo/models/OakD-Benchmark/model.sdf']]
px4 = Path('/home/yuchen7509/PX4-Autopilot')
paths += [px4 / ('Tools/simulation/gz/models/' + name + '/model.sdf') for name in ['x500', 'x500_base']]
hashes = {}
for i, path in enumerate(paths):
    data = path.read_bytes()
    snapshot = str(i) + '-' + path.name
    with (dest / snapshot).open('xb') as f:
        f.write(data)
    hashes[str(path)] = {'sha256': hashlib.sha256(data).hexdigest(), 'snapshot': snapshot}
with (dest / 'hashes.json').open('x') as f:
    json.dump(hashes, f, indent=2)
with (dest / 'working-diff.patch').open('xb') as f:
    f.write((stage / 'windows-working-diff.patch').read_bytes())
with (stage / 'processes-before-v2.txt').open('x') as f:
    subprocess.run(['ps', '-eo', 'pid,comm,args'], stdout=f, check=True)
with (stage / 'capture-v2.log').open('x') as f:
    run = subprocess.run(['/usr/bin/time', '-v', '-o', str(stage / 'capture-v2-resources.txt'), sys.executable,
        str(root / 'tools/benchmark/capture_disarmed_sensors.py'), '--output', str(stage / 'capture-v2')],
        stdout=f, stderr=subprocess.STDOUT, cwd=root)
with (stage / 'capture-v2-exit.txt').open('x') as f:
    f.write(str(run.returncode))
with (stage / 'processes-after-v2.txt').open('x') as f:
    subprocess.run(['ps', '-eo', 'pid,comm,args'], stdout=f, check=True)
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == value['sha256'] for p, value in hashes.items())
print('capture_v2_exit=' + str(run.returncode))
sys.exit(run.returncode)
