import base64
import hashlib
import json
from pathlib import Path

stage = Path(__file__).resolve().parent
summary = {'repositories': {}, 'snapshot_hashes': {}, 'installed_packages': {
    'libgz-sensors8': '8.2.2-1~noble', 'libgz-sim8': '8.15.0-1~noble', 'libgz-transport13': '13.6.0-1~noble'},
    'px4_commit': 'd6f12ad1c4f70ad3230afd7d86e971421e02fef4',
    'failure_note': 'research.py stopped at HTTPS EOF; agent-repository.json empty after gh EOF; partial artifacts retained'}
for name, repository, meta in [('agent', 'eProsima/Micro-XRCE-DDS-Agent', 'agent-maintenance-v2.json'),
                               ('gazebo', 'gazebosim/gz-sensors', 'gazebo-repository.json')]:
    version = json.loads((stage / (name + '-version.json')).read_text())
    metadata = json.loads((stage / meta).read_text())
    license_data = json.loads((stage / (name + '-license.json')).read_text())
    dest = stage / 'source-snapshots' / (name + '-LICENSE')
    content = base64.b64decode(license_data['content'])
    if dest.exists():
        assert dest.read_bytes() == content  # retained partial output from first attempt
    else:
        with dest.open('xb') as f:
            f.write(content)
    summary['repositories'][repository] = {'sha': version['sha'], 'archived': metadata['archived'],
        'pushed_at': metadata['pushed_at'], 'license': metadata['license'] if isinstance(metadata['license'], str) else metadata['license']['spdx_id'],
        'scope': 'candidate v2.4.3' if name == 'agent' else 'gz-sensors8 maintenance snapshot; not installed package commit'}
for path in sorted((stage / 'source-snapshots').iterdir()):
    summary['snapshot_hashes'][path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
with (stage / 'research-provenance.json').open('x') as f:
    json.dump(summary, f, indent=2)
print(json.dumps(summary['repositories'], indent=2))
