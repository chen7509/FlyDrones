import hashlib
import json
from pathlib import Path
import subprocess
import urllib.request

root = Path('/mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility')
out = root / 'results/disarmed-sensor-provenance-dev-1701'
dest = out / 'source-snapshots'
dest.mkdir(exist_ok=False)
px4 = Path('/home/yuchen7509/PX4-Autopilot')
names = ['src/modules/simulation/gz_bridge/GZBridge.cpp', 'src/modules/uxrce_dds_client/dds_topics.h.em',
         'src/modules/uxrce_dds_client/dds_topics.yaml', 'build/px4_sitl_default/src/modules/uxrce_dds_client/dds_topics.h',
         'build/px4_sitl_default/boardconfig', 'msg/SensorCombined.msg',
         'Tools/simulation/gz/models/x500_base/model.sdf', 'LICENSE', 'build/px4_sitl_default/etc/init.d-posix/rcS']
files = {}
for i, name in enumerate(names):
    data = (px4 / name).read_bytes()
    (dest / (str(i) + '-' + Path(name).name)).write_bytes(data)
    files[name] = hashlib.sha256(data).hexdigest()
result = {'source_hashes': files, 'px4_binary_sha256': hashlib.sha256((px4 / 'build/px4_sitl_default/bin/px4').read_bytes()).hexdigest(),
          'packages': subprocess.check_output(['dpkg-query', '-W', 'libgz-sim8', 'libgz-sensors8', 'libgz-transport13'], text=True),
          'repositories': {}}
for repo, ref in [('eProsima/Micro-XRCE-DDS-Agent', 'v2.4.3'), ('PX4/px4_msgs', 'main'), ('gazebosim/gz-sensors', 'gz-sensors8')]:
    def get(suffix):
        req = urllib.request.Request('https://api.github.com/repos/' + repo + suffix, headers={'User-Agent':'FlyDrones-provenance'})
        return json.load(urllib.request.urlopen(req, timeout=30))
    meta, commit = get(''), get('/commits/' + ref)
    result['repositories'][repo] = {'ref': ref, 'sha':commit['sha'], 'archived': meta['archived'], 'pushed_at':meta['pushed_at'],
                                     'license':meta.get('license')}
    license_meta = get('/license?ref=' + commit['sha'])
    import base64
    (dest / (repo.replace('/', '-') + '-LICENSE')).write_bytes(base64.b64decode(license_meta['content']))
with (out / 'research-provenance.json').open('x') as f: json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
