from pathlib import Path
import textwrap

path = Path('tools/benchmark/capture_disarmed_sensors.py')
text = path.read_text()
text = text.replace('from tools.benchmark.disarmed_sensor_provenance import CaptureWriter', 'from tools.benchmark.disarmed_sensor_provenance import CaptureJournal, CaptureWriter, supervise_worker')
text = text.replace('int(path.name) == os.getpid()', 'int(path.name) in {os.getpid(), os.getppid()}')
text = text.replace('    args = parser.parse_args()\n', '''    parser.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if not args.worker:
        summary = supervise_worker([sys.executable, str(Path(__file__).resolve()), "--worker", "--output", str(args.output.resolve())], args.output.resolve())
        return 0 if summary["status"] == "worker_exited" and summary["worker_exit"] == 0 else 2
''')
start = text.index('    import gz.math7')
finish = text.index('    print(json.dumps', start)
old = text[start:finish]
imports = old[:old.index('    writer = CaptureWriter')]
callbacks = old[old.index('    def submit('):old.index('    try:\n        log =')]
callbacks = callbacks.replace('event["camera_info"] = camera_info_fields(message)', 'event["sample_ns"] = int(message.header.stamp.sec) * 1_000_000_000 + int(message.header.stamp.nsec)\n                event["camera_info"] = camera_info_fields(message)')
callbacks = callbacks.replace('            raise RuntimeError("subscription failed: " + topic)', '            raise RuntimeError("subscription failed: " + topic)\n        journal.cleanup("unsubscribe " + topic, lambda topic=topic: node.unsubscribe(topic), priority=60)')
callbacks = callbacks.replace('    heartbeat_thread.start()', '    heartbeat_thread.start()\n    journal.cleanup("heartbeat", lambda: (stop.set(), heartbeat_thread.join(timeout=3)), priority=40)')
loop = old[old.index('        log ='):old.index('    except Exception as exc:\n        errors.append', old.index('        log ='))]
loop = textwrap.dedent(loop)
loop = loop.replace('start_new_session=True', 'start_new_session=False')
loop = loop.replace('log = (output / "px4.log").open("x")', 'log = (output / "px4.log").open("x")\njournal.cleanup("log close", log.close, priority=70)')
needle = 'with (output / "process.json").open("x") as f:'
loop = loop.replace(needle, '''def stop_px4():
    if process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)
            errors.append("owned PX4 required SIGKILL")
    result["px4_exit_code"] = process.returncode
journal.cleanup("owned PX4", stop_px4, priority=20)
''' + needle)
new = '''    errors = []
    result = {"status": "incomplete", "errors": errors, "eligible_for_vio_input": False,
              "eligible_for_px4_fusion": False, "estimator_run": False, "capture_schema": "disarmed-sensors-v2"}
    clock = {"sim_ns": 0}
    started = time.monotonic()
    with CaptureJournal(output, result) as journal:
        journal.cleanup("ULog collection", lambda: result.update(px4_ulogs=collect_ulogs(runtime, output)), priority=100)
        journal.cleanup("end clocks", lambda: result.update(end_sim_ns=clock["sim_ns"], capture_wall_s=time.monotonic()-started), priority=110)
'''
new += textwrap.indent(imports, '    ')
new += '''        writer = CaptureWriter(output)
        journal.cleanup("writer", lambda: result.update(writer=writer.finish()), priority=80)
        stop = threading.Event()
        node = Node()
        receiver = mavutil.mavlink_connection("udpin:127.0.0.1:14548", source_system=254)
        journal.cleanup("receiver", receiver.close, priority=50)
'''
new += textwrap.indent(callbacks, '    ')
new += textwrap.indent(loop, '        ')
text = text[:start] + new + text[finish:]
text = text.replace('import signal\n', '')
path.write_text(text)
