import hashlib
import json
from pathlib import Path

stage = Path(__file__).resolve().parent
dest = stage / 'next-source-snapshots'
dest.mkdir(exist_ok=False)
ov = Path('/home/yuchen7509/flydrones-upstream/open_vins_vio_init_probe')
sources = [ov / 'ov_msckf/src/ros/ROS1Visualizer.cpp', ov / 'ov_msckf/src/state/Propagator.cpp']
repo = stage.parents[1]
sources += list((repo / 'results/openvins-board-pattern-dev-1701/dependencies-v1/config-v2').glob('*.yaml'))
manifest = {}
for source in sources:
    data = source.read_bytes()
    with (dest / source.name).open('xb') as f:
        f.write(data)
    manifest[str(source)] = hashlib.sha256(data).hexdigest()
with (dest / 'hashes.json').open('x') as f:
    json.dump(manifest, f, indent=2)
