"""Read-only exact timestamp diagnostic; never changes estimator input."""
import hashlib
import json
from pathlib import Path
import numpy as np
from pyulog import ULog

stage = Path(__file__).resolve().parent
capture = stage / 'capture-v1'
result = json.loads((capture / 'result.json').read_text())
data = ULog(str(capture / result['px4_ulogs'][0]['path'])).get_dataset('sensor_combined').data
raw = [json.loads(line) for line in (capture / 'events.jsonl').read_text().splitlines() if json.loads(line)['kind'] == 'imu']
lookup = {r['sample_ns'] // 1000: i for i, r in enumerate(raw)}
pairs = [(j, lookup[int(t)]) for j, t in enumerate(data['timestamp']) if int(t) in lookup and lookup[int(t)] > 0]
summary = {'method': 'exact timestamp only; previous/current trapezoidal mean; no fitting, retiming or calibration changes',
           'total_px4': len(data['timestamp']), 'exact_pairs': len(pairs), 'source_equivalence_qualified': False,
           'sources': {}}
for rawkey, pxkey in [('gyro_frd', 'gyro_rad'), ('accel_frd', 'accelerometer_m_s2')]:
    observed = np.array([[data[f'{pxkey}[{k}]'][j] for k in range(3)] for j, i in pairs])
    predicted = np.array([(np.array(raw[i-1][rawkey]) + np.array(raw[i][rawkey])) / 2 for j, i in pairs])
    delta = observed - predicted
    summary[rawkey] = {'absolute_error_max': float(abs(delta).max()), 'absolute_error_median': float(np.median(abs(delta))),
                       'signed_error_median_xyz': np.median(delta, axis=0).tolist()}
px4 = Path('/home/yuchen7509/PX4-Autopilot')
for relative in ['src/modules/sensors/Integrator.hpp', 'src/modules/sensors/vehicle_imu/VehicleIMU.cpp', 'src/modules/sensors/voted_sensors_update.cpp']:
    content = (px4 / relative).read_bytes()
    with (stage / 'source-snapshots' / Path(relative).name).open('xb') as f:
        f.write(content)
    summary['sources'][relative] = hashlib.sha256(content).hexdigest()
with (stage / 'integration-diagnostic.json').open('x') as f:
    json.dump(summary, f, indent=2)
print(json.dumps(summary, indent=2))
