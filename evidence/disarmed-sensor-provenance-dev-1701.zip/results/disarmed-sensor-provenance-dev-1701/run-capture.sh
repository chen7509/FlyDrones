#!/bin/bash
set -uo pipefail
cd /mnt/c/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility
stage=results/disarmed-sensor-provenance-dev-1701
test ! -e "$stage/capture-v1" || exit 2
test ! -e "$stage/capture-v1.log" || exit 2
ps -eo pid,comm,args > "$stage/processes-before.txt"
/usr/bin/time -v -o "$stage/capture-v1-resources.txt" python3 tools/benchmark/capture_disarmed_sensors.py --output "$stage/capture-v1" > "$stage/capture-v1.log" 2>&1
status=$?
printf '%s\n' "$status" > "$stage/capture-v1-exit.txt"
ps -eo pid,comm,args > "$stage/processes-after.txt"
exit "$status"
