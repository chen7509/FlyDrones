"""Seal this bounded development stage without copying historical evidence."""

import hashlib
import json
import zipfile
import zlib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "evidence/ego-bridge-input-gate-dev-1701.zip"
FILES = [
    "tools/benchmark/ego_wire_observation.py",
    "tools/benchmark/ego_node.py",
    "tests/benchmark/test_ego_wire_observation.py",
    "docs/superpowers/specs/2026-10-10-ego-bridge-input-gate-design.md",
    "docs/superpowers/plans/2026-10-10-ego-bridge-input-gate.md",
    "docs/EGO_BRIDGE_INPUT_GATE_REPORT.md",
    "results/ego-upstream-source-audit-dev-1701/synthetic_client_v2.py",
    "results/ego-bridge-input-gate-dev-1701/red-parser.txt",
    "results/ego-bridge-input-gate-dev-1701/red-bridge.txt",
    "results/ego-bridge-input-gate-dev-1701/red-review.txt",
    "results/ego-bridge-input-gate-dev-1701/adjacent-tests-final.txt",
    "results/ego-bridge-input-gate-dev-1701/ruff-final.txt",
    "results/ego-bridge-input-gate-dev-1701/diff-check.txt",
    "results/ego-bridge-input-gate-dev-1701/review.txt",
    "results/ego-bridge-input-gate-dev-1701/seal.py",
]


def main() -> None:
    entries = {}
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(OUT, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for relative in FILES:
            data = (ROOT / relative).read_bytes()
            archive.writestr(relative, data)
            entries[relative] = {
                "bytes": len(data),
                "sha256": hashlib.sha256(data).hexdigest(),
                "crc32": format(zlib.crc32(data) & 0xFFFFFFFF, "08x"),
            }
        archive.writestr("MANIFEST.json", json.dumps(entries, indent=2, sort_keys=True))
    with zipfile.ZipFile(OUT) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == set(FILES) | {"MANIFEST.json"}
        for relative, expected in entries.items():
            data = archive.read(relative)
            assert hashlib.sha256(data).hexdigest() == expected["sha256"]
            assert len(data) == expected["bytes"]
    print(json.dumps({"zip": str(OUT), "members": len(FILES) + 1,
                      "sha256": hashlib.sha256(OUT.read_bytes()).hexdigest()}, sort_keys=True))


if __name__ == "__main__":
    main()
