"""Future development-only EGO bridge smoke input with full RGB-D wire schema.

Do not treat the resulting reference as PX4/VIO teacher or comparison data.
"""

import base64
import json
import socket
import struct

RGB = base64.b64encode(bytes(120 * 160 * 3)).decode("ascii")
DEPTH = base64.b64encode(struct.pack("<f", 10.0) * (120 * 160)).decode("ascii")


def observation(index: int) -> dict:
    sim_ns = 1_000_000_000 + index * 100_000_000
    return {
        "sim_ns": sim_ns,
        "frame_ns": sim_ns,
        "rgb": {"shape": [120, 160, 3], "data": RGB},
        "depth_m": {"shape": [120, 160], "data": DEPTH},
        "camera_pose": [0.0, 0.0, 1.5, 0.0, 0.0, 0.0, 1.0],
        "position": [0.0, 0.0, 1.5],
        "velocity": [0.0, 0.0, 0.0],
        "yaw": 0.0,
        "yaw_rate": 0.0,
        "goal": [8.0, 0.0, 1.5],
    }


def read_exact(connection: socket.socket, size: int) -> bytes:
    output = bytearray()
    while len(output) < size:
        chunk = connection.recv(size - len(output))
        if not chunk:
            raise ConnectionError("bridge closed before full response")
        output.extend(chunk)
    return bytes(output)


def exchange(connection: socket.socket, payload: dict) -> dict:
    raw = json.dumps(payload, separators=(",", ":"), allow_nan=False).encode()
    connection.sendall(struct.pack("!I", len(raw)) + raw)
    size = struct.unpack("!I", read_exact(connection, 4))[0]
    if not 0 < size < 1_000_000:
        raise ValueError("unexpected bridge response size")
    return json.loads(read_exact(connection, size))


def main() -> None:
    with socket.create_connection(("127.0.0.1", 46200), timeout=5) as connection:
        connection.settimeout(10)
        response = exchange(connection, {"type": "reset", "seed": 1701})
        if response != {"status": "ready"}:
            raise ValueError("unexpected reset response")
        print(json.dumps({"reset": response}, sort_keys=True), flush=True)
        for index in range(12):
            row = observation(index)
            response = exchange(connection, row)
            print(json.dumps({"index": index, "sim_ns": row["sim_ns"],
                              "response": response}, sort_keys=True), flush=True)
            if "position_ref" in response:
                return
        raise RuntimeError("synthetic EGO trajectory not received")


if __name__ == "__main__":
    main()
