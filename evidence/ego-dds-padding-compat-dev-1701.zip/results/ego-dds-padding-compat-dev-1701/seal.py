"""Seal source, real ROS/DDS traces, all failures, and final offline audit."""

import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

repo = Path(__file__).resolve().parents[2]
members = [
    Path("tools/benchmark/ego_cdr_field_audit.py"),
    Path("tools/benchmark/ego_cdr_diagnostic_join.py"),
    Path("tests/benchmark/test_ego_diagnostic_reconcile.py"),
    Path("docs/EGO_DDS_PADDING_COMPAT_REPORT.md"),
    Path("docs/superpowers/plans/2026-10-10-ego-causal-provenance.md"),
    Path("docs/superpowers/specs/2026-10-10-ego-causal-provenance-design.md"),
    Path("results/ego-ros-cdr-runtime-dev-1701/stdout.json"),
]
for directory in (
    "results/ego-patched-build-dev-1701",
    "results/ego-ros-dds-loopback-dev-1701",
    "results/ego-ros-dds-loopback-dev-1701-v2",
    "results/ego-ros-dds-loopback-dev-1701-v3",
    "results/ego-ros-dds-loopback-dev-1701-v4",
    "results/ego-dds-padding-compat-dev-1701",
):
    members += [
        path.relative_to(repo) for path in (repo / directory).rglob("*")
        if path.is_file() and "__pycache__" not in path.parts
    ]
members = sorted(set(members), key=lambda item: item.as_posix())
manifest = {
    "schema": "flydrones-ego-dds-padding-compat-evidence-v1",
    "prior_ros_cdr_runtime_zip_sha256": hashlib.sha256(
        (repo / "evidence/ego-ros-cdr-runtime-dev-1701.zip").read_bytes()).hexdigest(),
    "members": {
        path.as_posix(): {
            "sha256": hashlib.sha256((repo / path).read_bytes()).hexdigest(),
            "bytes": (repo / path).stat().st_size,
        }
        for path in members
    },
}
output = repo / "evidence/ego-dds-padding-compat-dev-1701.zip"
with ZipFile(output, "w", compression=ZIP_DEFLATED) as archive:
    for path in members:
        archive.write(repo / path, path.as_posix())
    archive.writestr("manifest.json", json.dumps(manifest, sort_keys=True, indent=2) + "\n")
with ZipFile(output) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(manifest["members"]) | {"manifest.json"}
    for name, item in manifest["members"].items():
        data = archive.read(name)
        assert len(data) == item["bytes"]
        assert hashlib.sha256(data).hexdigest() == item["sha256"]
print(json.dumps({
    "archive": str(output),
    "sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
    "members": len(manifest["members"]) + 1,
    "bytes": output.stat().st_size,
}, sort_keys=True))
