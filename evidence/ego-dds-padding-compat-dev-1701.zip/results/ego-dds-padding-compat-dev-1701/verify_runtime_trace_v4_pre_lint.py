"""Feed actual retained rclpy/DDS bytes into the strict offline candidate join."""

import base64
import hashlib
import json
import runpy
from pathlib import Path

from tools.benchmark.ego_cdr_diagnostic_join import reconcile_cdr_diagnostics


repo = Path(__file__).resolve().parents[2]
original_path = repo / "results/ego-ros-cdr-runtime-dev-1701/stdout.json"
dds_path = repo / "results/ego-ros-dds-loopback-dev-1701-v4/stdout.json"
original = json.loads(original_path.read_text(encoding="utf-8"))
dds = json.loads(dds_path.read_text(encoding="utf-8"))
assert original["schema"] == "flydrones-ego-ros-cdr-probe-v1"
assert dds["schema"] == "flydrones-ego-ros-dds-loopback-v2"
assert dds["command_zero_alignment_verified"] is True
payloads = {
    kind: base64.b64decode(row["cdr_b64"], validate=True)
    for kind, row in original["messages"].items()
}
payloads["depth"] = base64.b64decode(dds["messages"]["depth"]["cdr_b64"], validate=True)
payloads["position_command"] = base64.b64decode(
    dds["messages"]["position_command"]["cdr_b64"], validate=True
)
canonical_command = base64.b64decode(
    original["messages"]["position_command"]["cdr_b64"], validate=True
)
assert payloads["position_command"] == canonical_command + b"\x00" * 3
assert payloads["depth"] == base64.b64decode(
    original["messages"]["depth"]["cdr_b64"], validate=True
)
assert dds["messages"]["position_command"]["canonical_sha256"] == hashlib.sha256(
    canonical_command).hexdigest()

helpers = runpy.run_path(str(repo / "tests/benchmark/test_ego_diagnostic_reconcile.py"))
output = Path(__file__).resolve().parent / "runtime-v4"
output.mkdir(exist_ok=False)
rows, planner, server = helpers["cdr_bundle"](output, payloads=payloads)
for row in server:
    if row["event"] == "server_command_published":
        row["command_sha256"] = hashlib.sha256(canonical_command).hexdigest()
match = reconcile_cdr_diagnostics(
    rows, planner, server,
    run_id=helpers["RUN"], session_id=helpers["SESSION"],
    verify_payload_fields=True,
)
assert match["command_transport_padding_bytes"] == 3
assert match["command_raw_sha256"] == dds["messages"]["position_command"]["sha256"]
assert match["command_canonical_sha256"] == dds["messages"]["position_command"]["canonical_sha256"]
assert match["identity_match"] is False
assert match["digest_identity_candidate"] is False
assert match["canonical_digest_identity_candidate"] is True
assert match["runtime_source_verified"] is False
assert match["teacher_qualified"] is False
(output / "runtime-verification.json").write_text(json.dumps({
    "schema": "flydrones-ego-dds-padding-runtime-verification-v1",
    "original_rclpy_probe_sha256": hashlib.sha256(original_path.read_bytes()).hexdigest(),
    "dds_difference_probe_sha256": hashlib.sha256(dds_path.read_bytes()).hexdigest(),
    "raw_command_sha256": match["command_raw_sha256"],
    "canonical_command_sha256": match["command_canonical_sha256"],
    "padding_bytes": match["command_transport_padding_bytes"],
    "canonical_digest_identity_candidate": match["canonical_digest_identity_candidate"],
    "byte_exact_digest_identity_candidate": match["digest_identity_candidate"],
    "cdr_payload_fields_verified": match["cdr_payload_fields_verified"],
    "synthetic_planner_server_rows": True,
    "actual_planner_join_verified": False,
    "dds_image_command_loopback_byte_exact": False,
    "runtime_source_verified": False,
    "teacher_qualified": False,
}, sort_keys=True, indent=2) + "\n", encoding="utf-8")
