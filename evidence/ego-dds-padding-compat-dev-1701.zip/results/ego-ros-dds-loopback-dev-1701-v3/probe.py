"""Bounded two-node raw-CDR ROS 2 loopback, without any EGO planner."""

import base64
import hashlib
import json
import struct
import time

import rclpy
from builtin_interfaces.msg import Time
from geometry_msgs.msg import Point, Vector3
from quadrotor_msgs.msg import PositionCommand
from rclpy.executors import SingleThreadedExecutor
from rclpy.qos import QoSProfile, ReliabilityPolicy
from rclpy.serialization import serialize_message
from rclpy.utilities import get_rmw_implementation_identifier
from sensor_msgs.msg import Image
from std_msgs.msg import Header


def digest(data):
    return hashlib.sha256(data).hexdigest()


depth = Image()
depth.header = Header(stamp=Time(sec=0, nanosec=1000), frame_id="camera_optical")
depth.height = depth.width = 1
depth.encoding = "32FC1"
depth.step = 4
depth.data = struct.pack("<f", 1.0)
depth_raw = serialize_message(depth)

command = PositionCommand()
command.header = Header(stamp=Time(sec=0, nanosec=9000), frame_id="world")
command.position = Point(x=0.0, y=0.0, z=1.0)
command.velocity = Vector3()
command.acceleration = Vector3()
command.trajectory_id = 7
command.trajectory_flag = PositionCommand.TRAJECTORY_STATUS_READY
command_raw = serialize_message(command)

rclpy.init()
bridge = rclpy.create_node("fly_probe_bridge")
planner = rclpy.create_node("fly_probe_planner_surrogate")
executor = SingleThreadedExecutor()
executor.add_node(bridge)
executor.add_node(planner)
received = {"depth": [], "command": []}
qos = QoSProfile(depth=10, reliability=ReliabilityPolicy.RELIABLE)
image_pub = bridge.create_publisher(Image, "/fly_probe/depth", qos)
command_pub = planner.create_publisher(PositionCommand, "/fly_probe/command", qos)
planner.create_subscription(Image, "/fly_probe/depth", lambda raw: received["depth"].append(bytes(raw)), qos, raw=True)
bridge.create_subscription(PositionCommand, "/fly_probe/command", lambda raw: received["command"].append(bytes(raw)), qos, raw=True)

deadline = time.monotonic() + 12.0
ready = False
try:
    while time.monotonic() < deadline:
        executor.spin_once(timeout_sec=0.05)
        if image_pub.get_subscription_count() == 1 and command_pub.get_subscription_count() == 1:
            ready = True
            break
    if not ready:
        raise RuntimeError("DDS endpoints did not match before deadline")

    image_pub.publish(depth_raw)
    command_pub.publish(command_raw)
    while time.monotonic() < deadline and (not received["depth"] or not received["command"]):
        executor.spin_once(timeout_sec=0.05)
    if len(received["depth"]) != 1 or len(received["command"]) != 1:
        raise RuntimeError("DDS raw callbacks incomplete or duplicated")
    if received["depth"][0] != depth_raw or received["command"][0] != command_raw:
        def comparison(sent, got):
            return {
                "sent_len": len(sent), "received_len": len(got),
                "sent_sha256": digest(sent), "received_sha256": digest(got),
                "sent_b64": base64.b64encode(sent).decode("ascii"),
                "received_b64": base64.b64encode(got).decode("ascii"),
                "first_different_offset": next(
                    (i for i, (a, b) in enumerate(zip(sent, got)) if a != b),
                    min(len(sent), len(got)),
                ),
            }
        print(json.dumps({
            "schema": "flydrones-ego-ros-dds-difference-v1",
            "depth": comparison(depth_raw, received["depth"][0]),
            "command": comparison(command_raw, received["command"][0]),
            "qualified": False,
        }, sort_keys=True), flush=True)
        raise RuntimeError("DDS raw callback CDR differs from published bytes")
    graph = dict(bridge.get_topic_names_and_types())
    if graph.get("/fly_probe/depth") != ["sensor_msgs/msg/Image"]:
        raise RuntimeError("DDS depth topic type mismatch")
    if graph.get("/fly_probe/command") != ["quadrotor_msgs/msg/PositionCommand"]:
        raise RuntimeError("DDS command topic type mismatch")
    print(json.dumps({
        "schema": "flydrones-ego-ros-dds-loopback-v1",
        "rmw": get_rmw_implementation_identifier(),
        "graph": {key: graph[key] for key in ("/fly_probe/depth", "/fly_probe/command")},
        "endpoint_counts": {
            "depth": image_pub.get_subscription_count(),
            "command": command_pub.get_subscription_count(),
        },
        "messages": {
            "depth": {"cdr_b64": base64.b64encode(received["depth"][0]).decode("ascii"),
                      "bytes": len(depth_raw), "sha256": digest(depth_raw)},
            "position_command": {"cdr_b64": base64.b64encode(received["command"][0]).decode("ascii"),
                                 "bytes": len(command_raw), "sha256": digest(command_raw)},
        },
        "same_process_surrogate": True,
        "ego_planner_used": False,
        "source_authenticated": False,
        "teacher_qualified": False,
    }, sort_keys=True, separators=(",", ":")))
finally:
    executor.remove_node(bridge)
    executor.remove_node(planner)
    bridge.destroy_node()
    planner.destroy_node()
    executor.shutdown()
    rclpy.shutdown()
