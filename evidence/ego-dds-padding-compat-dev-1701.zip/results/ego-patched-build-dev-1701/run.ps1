$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$patch = (Resolve-Path (Join-Path $root '../../tools/benchmark/ego_causal_readonly_v2.patch')).Path
$script = Join-Path $root 'build.sh'
$image = 'sha256:a4dae62b38bc01a01d084be7b68db83ec804fef7673604e1a9c986a4baa88a6a'
$name = 'fly-ego-causal-v2-build-1701'
$available = [double](Get-Counter '\Memory\Available MBytes').CounterSamples[0].CookedValue
$actualImage = (& docker image inspect fly-ego-benchmark:humble --format '{{.Id}}').Trim()
$running = @(& docker ps --format '{{.Names}}')
$owned = @(& docker ps -a --filter "name=^/$name$" --format '{{.Names}}')
$preflight = [ordered]@{
    schema = 'flydrones-ego-causal-v2-build-preflight-v1'
    timestamp_utc = [DateTime]::UtcNow.ToString('o')
    available_windows_mib = $available
    minimum_windows_mib = 2500
    image_id = $actualImage
    expected_image_id = $image
    patch_sha256 = (Get-FileHash -LiteralPath $patch -Algorithm SHA256).Hash.ToLowerInvariant()
    script_sha256 = (Get-FileHash -LiteralPath $script -Algorithm SHA256).Hash.ToLowerInvariant()
    running_containers = $running
    existing_owned_container = $owned
    memory_limit_mib = 1536
    cpu_limit = 1
    internal_timeout_seconds = 1200
}
$preflight | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $root 'preflight.json') -Encoding utf8
if ($available -lt 2500 -or $actualImage -ne $image -or $running.Count -gt 0 -or $owned.Count -gt 0) {
    throw 'Fixed EGO patch build admission refused.'
}
$args = @(
    'run', '--name', $name, '--pull', 'never', '--network', 'none',
    '--memory', '1536m', '--memory-swap', '1536m', '--cpus', '1',
    '--pids-limit', '128', '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges',
    '--mount', "type=bind,source=$patch,target=/patch.diff,readonly",
    '--mount', "type=bind,source=$script,target=/build.sh,readonly",
    '--mount', "type=bind,source=$root,target=/out",
    '--entrypoint', '/bin/bash', $image, '/build.sh'
)
[ordered]@{ executable = 'docker'; argv = $args } | ConvertTo-Json -Depth 5 |
    Set-Content -LiteralPath (Join-Path $root 'command.json') -Encoding utf8
try {
    & docker @args 1> (Join-Path $root 'docker-stdout.txt') 2> (Join-Path $root 'docker-stderr.txt')
    $code = $LASTEXITCODE
    $state = & docker inspect $name --format '{{.State.OOMKilled}} {{.State.ExitCode}}'
    $committed = ''
    if ($code -eq 0 -and $state -eq 'false 0') {
        $committed = (& docker commit --change 'LABEL flydrones.upstream=23a8d5a191711dd65633df689bd00f55d4dea8f9' --change 'LABEL flydrones.patch=ego_causal_readonly_v2.patch' $name 'fly-ego-benchmark:causal-v2').Trim()
    }
    [ordered]@{
        docker_exit_code = $code
        container_state = $state
        committed_image_id = $committed
        available_windows_after_mib = [double](Get-Counter '\Memory\Available MBytes').CounterSamples[0].CookedValue
        timestamp_utc = [DateTime]::UtcNow.ToString('o')
    } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $root 'completion.json') -Encoding utf8
} finally {
    & docker rm $name *> (Join-Path $root 'owned-container-remove.txt')
    $remaining = @(& docker ps -a --filter "name=^/$name$" --format '{{.Names}}')
    [ordered]@{ remaining_owned_container = $remaining; timestamp_utc = [DateTime]::UtcNow.ToString('o') } |
        ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $root 'cleanup.json') -Encoding utf8
}
if ($code -ne 0 -or $state -ne 'false 0' -or $remaining.Count -gt 0 -or -not $committed) {
    throw "Fixed EGO patch build did not qualify: exit=$code state=$state"
}
