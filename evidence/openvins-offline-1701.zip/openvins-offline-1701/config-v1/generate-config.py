"""Freeze one upstream-template OpenVINS mono/IMU smoke-test config.

Research-only GPL-3.0 OpenVINS linkage. This does not configure PX4 or flight.
"""

from pathlib import Path

here = Path(__file__).resolve().parent
config = here / "estimator_config.yaml"
text = config.read_text()
replacements = {
    "use_stereo: true": "use_stereo: false",
    "max_cameras: 2": "max_cameras: 1",
    "calib_cam_extrinsics: true": "calib_cam_extrinsics: false",
    "calib_cam_intrinsics: true": "calib_cam_intrinsics: false",
    "calib_cam_timeoffset: true": "calib_cam_timeoffset: false",
}
for old, new in replacements.items():
    if text.count(old) != 1:
        raise ValueError(f"expected exactly one {old}")
    text = text.replace(old, new)
config.write_text(text)

imu = here / "kalibr_imu_chain.yaml"
text = imu.read_text()
if text.count("update_rate: 200.0") != 1:
    raise ValueError("upstream IMU update rate changed")
imu.write_text(text.replace("update_rate: 200.0", "update_rate: 250.0"))

(here / "kalibr_imucam_chain.yaml").write_text("""%YAML:1.0
cam0:
  T_imu_cam: # R_CtoI and p_CinI from Gazebo static optical probe + PX4 FLU->FRD bridge
    - [0.0, 0.0, 1.0, 0.12]
    - [1.0, 0.0, 0.0, 0.0]
    - [0.0, 1.0, 0.0, -0.002]
    - [0.0, 0.0, 0.0, 1.0]
  cam_overlaps: []
  camera_model: pinhole
  distortion_coeffs: [0.0, 0.0, 0.0, 0.0]
  distortion_model: radtan
  intrinsics: [108.12401050876075, 108.12401050876075, 80.0, 60.0]
  resolution: [160, 120]
  rostopic: /benchmark/rgbd/image
  timeshift_cam_imu: 0.0 # provisional: PX4 dynamic offset is uncalibrated
""")
