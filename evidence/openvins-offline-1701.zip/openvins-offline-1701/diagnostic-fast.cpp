// Research diagnostic: FAST corners under the frozen OpenVINS front-end settings.
#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/features2d.hpp>
int main(int argc, char** argv) {
  if (argc != 3) return 2;
  std::ifstream in(argv[1]);
  if (!in) return 3;
  std::string line;
  std::getline(in, line);
  std::cout << "timestamp_ns,fast20_full,fast10_full\n";
  while (std::getline(in, line)) {
    if (!line.empty() && line.back() == '\r') line.pop_back();
    auto comma = line.find(',');
    if (comma == std::string::npos) return 4;
    cv::Mat image = cv::imread(std::string(argv[2]) + "/" + line.substr(comma + 1), cv::IMREAD_GRAYSCALE);
    if (image.empty()) return 5;
    cv::Mat equalized;
    cv::equalizeHist(image, equalized);
    std::vector<cv::KeyPoint> fast20, fast10;
    cv::FAST(equalized, fast20, 20, true);
    cv::FAST(equalized, fast10, 10, true);
    std::cout << line.substr(0, comma) << ',' << fast20.size() << ',' << fast10.size() << '\n';
  }
}
