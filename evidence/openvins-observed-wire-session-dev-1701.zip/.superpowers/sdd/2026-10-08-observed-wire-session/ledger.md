# SDD ledger — plan: docs/superpowers/plans/2026-10-08-observed-wire-session.md

Task 1 in progress. Base 8128f0dfcf09d4b55e07ad7b404d3df4235122d5; initial composition 038336a.
Prior support counterexamples and WSL real-codec integration failures are preserved in results/openvins-observed-wire-session-dev-1701.
Independent review /root/review_observed_wire_session: two Important findings; no other confirmed Critical/Minor.
Final: fixed stale source/selection after socket profile access — test_profile_check_expiry_refuses_before_send and test_profile_check_expiry_refuses_final_completion assertion RED→GREEN.
Final: fixed shared RemoteMonotonicClock latched fault ignored — test_shared_remote_fault_refuses_before_send assertion RED→GREEN. Public failure accessor is nonmutating; extra coverage checks replacement and nonconsumption.
Review RED: 3 failures/23 tests. Fix pass GREEN: 23 tests OK with actual pinned pymavlink and simulated socket/owner/clock only.
Ruling: use related dependency regressions, retain old full-suite results as historical — developer requires verification appropriate to this change rather than redundant broad runs — residual cost: unrelated integration behavior is not freshly exercised.
Ruling: preserve the stage workspace and historical artifacts — user explicitly prohibits deleting evidence — cost: additional retained files.
Boundary checks observe source state before their last clock read and check ages after profile/lock waits; not an atomic OS send/ownership guarantee. No live network/physics authority granted.

Final regression: Windows115passed/2 codec skips; WSL real codec90OK (including23 composition); changed Ruff and diff-check pass. Production fix a0345624a31a1257faadb80382d1e087a45fd006; report f07a819.
Five predeclared synthetic evidence exports completed with selected source and installed codec hashes stable; no actual sockets, process launch or simulation. Modelled normal500 and four failures retained.
Publication pending seal and remote verification. No deferred minors.
