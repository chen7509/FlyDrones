import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).resolve().parent
ZIP = ROOT / 'evidence/openvins-observed-wire-session-dev-1701.zip'
MANIFEST = ROOT / 'evidence/openvins-observed-wire-session-seal.json'
assert not ZIP.exists() and not MANIFEST.exists()
references = [
    'evidence/openvins-independent-clock-dev-1701.zip',
    'evidence/openvins-datagram-receive-dev-1701.zip',
    'evidence/openvins-wire-bootstrap-dev-1701.zip',
    'results/openvins-timesync-wire-dev-1701/research.md',
    'results/openvins-datagram-receive-dev-1701/sources/socket-v3.12.3.rst',
    'results/openvins-datagram-receive-dev-1701/sources/LICENSE-v3.12.3',
    'results/openvins-datagram-receive-dev-1701/sources/manifest.json',
]
def digest(raw):
    return hashlib.sha256(raw).hexdigest()

with (STAGE / 'source-reference-manifest.json').open('x', encoding='utf-8') as target:
    json.dump({p: dict(bytes=(ROOT / p).stat().st_size, sha256=digest((ROOT / p).read_bytes()))
               for p in references}, target, indent=2)
paths = [p for p in STAGE.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
paths += [ROOT / p for p in references if not p.endswith('.zip')]
paths += list((ROOT / '.superpowers/sdd/2026-10-08-observed-wire-session').glob('*.md'))
paths += [ROOT / p for p in [
    'docs/OPENVINS_OBSERVED_WIRE_SESSION_REPORT.md',
    'docs/superpowers/specs/2026-10-08-observed-wire-session-design.md',
    'docs/superpowers/plans/2026-10-08-observed-wire-session.md',
    'tools/benchmark/openvins_observed_wire_session.py',
    'tools/benchmark/openvins_datagram_receive.py',
    'tools/benchmark/openvins_simulation_clock.py',
    'tools/benchmark/openvins_ekf2_disarmed_preflight.py',
    'tools/benchmark/openvins_wire_bootstrap.py',
    'tools/benchmark/openvins_timesync_wire.py',
    'tools/benchmark/openvins_timesync_observer.py',
    'tools/benchmark/owned_daemon_connection.py',
    'tests/benchmark/test_openvins_observed_wire_session.py',
    'tests/benchmark/test_openvins_datagram_receive.py',
    'tests/benchmark/test_openvins_simulation_clock.py',
    'tests/benchmark/test_openvins_ekf2_disarmed_preflight.py',
    'tests/benchmark/test_openvins_wire_bootstrap.py',
    'tests/benchmark/test_openvins_timesync_wire.py',
    'tests/benchmark/check_openvins_owned_bootstrap.py',
]]
members = {}
with zipfile.ZipFile(ZIP, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(set(paths)):
        name = path.relative_to(ROOT).as_posix()
        raw = path.read_bytes()
        archive.writestr(name, raw)
        members[name] = dict(bytes=len(raw), sha256=digest(raw))
with zipfile.ZipFile(ZIP) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(members)
    for name, expected in members.items():
        assert digest(archive.read(name)) == expected['sha256']
value = dict(archive=ZIP.name, sha256=digest(ZIP.read_bytes()), bytes=ZIP.stat().st_size,
             members=members, production_commit='a0345624a31a1257faadb80382d1e087a45fd006',
             source_copy_basis='current files at sealing; synthetic selected pre/post hashes separately retained',
             network_authorized=False, fusion_qualified=False)
with MANIFEST.open('x', encoding='utf-8') as target:
    json.dump(value, target, indent=2)
print(json.dumps({k: v for k, v in value.items() if k != 'members'}))
print('members', len(members))
