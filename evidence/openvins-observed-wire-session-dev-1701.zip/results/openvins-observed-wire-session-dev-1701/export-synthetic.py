"""Export retained actual-class test evidence; no real sockets or processes."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent / 'synthetic-v1'
OUT.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT))
from tests.benchmark.test_openvins_observed_wire_session import ObservedSessionTests
from pymavlink.dialects.v20 import common

CASES = [
    'test_normal500_real_codec_all_actual_classes',
    'test_profile_check_expiry_refuses_before_send',
    'test_shared_remote_fault_refuses_before_send',
    'test_short_write_retained_without_retry',
    'test_failure_during_send_preserves_actual_count',
]
FILES = [
    'tools/benchmark/openvins_observed_wire_session.py',
    'tools/benchmark/openvins_simulation_clock.py',
    'tools/benchmark/openvins_datagram_receive.py',
    'tools/benchmark/openvins_wire_bootstrap.py',
    'tools/benchmark/openvins_timesync_wire.py',
    'tools/benchmark/openvins_ekf2_disarmed_preflight.py',
    'tests/benchmark/test_openvins_observed_wire_session.py',
    'tests/benchmark/test_openvins_wire_bootstrap.py',
    'tests/benchmark/check_openvins_owned_bootstrap.py',
]

def save(name, value):
    with (OUT / name).open('x', encoding='utf-8') as target:
        json.dump(value, target, indent=2, sort_keys=True)
        target.write('\n')

def hashes():
    paths = {str(p): ROOT / p for p in FILES}
    paths['installed-common.py'] = Path(common.__file__)
    paths['exporter'] = Path(__file__)
    return {key: hashlib.sha256(path.read_bytes()).hexdigest() for key, path in paths.items()}

pre = hashes()
save('predeclared.json', dict(cases=CASES, producer_commit=sys.argv[1], hashes=pre,
                            owner_clock_socket_status='synthetic', real_codec=True,
                            actual_udp=False, actual_px4=False, fusion=False))
results = []
for name in CASES:
    fixture = ObservedSessionTests(name)
    fixture.setUp()
    try:
        getattr(fixture, name)()
        outcome = 'assertions_passed'
    except BaseException as exc:
        outcome = type(exc).__name__ + ': ' + str(exc)
        raise
    finally:
        evidence = dict(outcome=outcome, session=fixture.obj.evidence,
                        forwarded_events=fixture.events,
                        synthetic_send_calls=[dict(hex=raw.hex(), flags=flags, peer=peer)
                                              for raw, flags, peer in fixture.sock.sent])
        save(name + '.json', evidence)
        results.append(dict(case=name, outcome=outcome, sends=len(fixture.sock.sent)))
post = hashes()
save('post.json', dict(hashes=post, stable=pre == post, cases=results))
assert pre == post
print(json.dumps(dict(cases=results, source_and_codec_stable=True)))
