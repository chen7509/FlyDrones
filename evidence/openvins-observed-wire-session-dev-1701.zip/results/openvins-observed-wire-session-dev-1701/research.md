# Reused source and interface research

No new dependency or algorithm. Selected existing interfaces minimize adaptation to a single composition class; runtime cost is existing guards, codec work and bounded logs, not measured here.

| Component | Version/license | Maintenance evidence | Interface / decision |
|---|---|---|---|
| PX4 | d6f12ad1c4f70ad3230afd7d86e971421e02fef4 / BSD3 | reused independent-clock source/metadata, not a new observation | existing pinned HRT/TIMESYNC and listener rules, no launch |
| Python | WSL 3.12.3 / PSF | installed version; reused fixed upstream socket source/docs | recvmsg/sendto MSG_DONTWAIT and return counts; no socket factory |
| pymavlink | 2.4.49, tag 2a500b8acfb507255d02ed8257b6eb132e5b86d7 / generator (L)GPLv3 with generated-output MIT exception; distribution LGPLv3 | reused metadata last push 2026-10-06T23:56:46Z, nonarchived; not refreshed | actual common v20 codec, no handwritten CRC/protocol replacement |
| Gazebo | installed 8.15 / Apache2 | reused independent-clock metadata | callback-shaped clock input only; no server or renderer |

Newly consulted official API references during this stage's design: https://docs.python.org/3.12/library/socket.html#socket.socket.sendto and https://man7.org/linux/man-pages/man2/send.2.html. Rolling docs are not claimed equal to installed version. Fixed 3.12.3 docs are included in the seal. Per-call nonblocking and syscall return do not prove delivery or atomic source health.

No new paper method is implemented. Existing OpenVINS numerical model, calibration assumptions and paper references remain unchanged. Reject new mock protocol, replacement codec, a separate transmit socket, request-derived simulation time and generic process supervision expansion.

The source-reference manifest records exact retained bytes and archive hashes. This is a current read of prior evidence, not new historical pre-run provenance. Five synthetic exported cases record current selected source/codec hashes before and after execution; that is narrower than a whole-runtime dependency closure.
