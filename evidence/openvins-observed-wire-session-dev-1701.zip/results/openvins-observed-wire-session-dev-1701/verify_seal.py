import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[2]
manifest = json.loads((root / 'evidence/openvins-observed-wire-session-seal.json').read_text())
archive = root / 'evidence' / manifest['archive']
assert hashlib.sha256(archive.read_bytes()).hexdigest() == manifest['sha256']
with zipfile.ZipFile(archive) as sealed:
    assert sealed.testzip() is None
    assert set(sealed.namelist()) == set(manifest['members'])
    for name, expected in manifest['members'].items():
        raw = sealed.read(name)
        assert len(raw) == expected['bytes']
        assert hashlib.sha256(raw).hexdigest() == expected['sha256']
    prefix = 'results/openvins-observed-wire-session-dev-1701/'
    post = json.loads(sealed.read(prefix + 'synthetic-v1/post.json'))
    pre = json.loads(sealed.read(prefix + 'synthetic-v1/predeclared.json'))
    assert post['stable'] is True and post['hashes'] == pre['hashes']
    assert [r['case'] for r in post['cases']] == pre['cases']
    assert [r['sends'] for r in post['cases']] == [500, 0, 0, 1, 1]
    for row in post['cases']:
        value = json.loads(sealed.read(prefix + 'synthetic-v1/' + row['case'] + '.json'))
        assert value['outcome'] == row['outcome'] == 'assertions_passed'
        assert len(value['synthetic_send_calls']) == row['sends']
        assert value['session']['fusion_qualified'] is False
        assert value['session']['network_authorized'] is False
print('CRC/member hashes and five synthetic exports verified:', len(manifest['members']))
