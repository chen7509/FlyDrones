"""Exclusive evidence seal; never replace any prior artifact."""
import hashlib
import json
import zipfile
from pathlib import Path

out = Path(__file__).resolve().parent
root = out.parents[1]
sha = lambda b: hashlib.sha256(b).hexdigest()
archive = root / "evidence/openvins-timesync-interval-dev-1701.zip"
external = root / "evidence/openvins-timesync-interval-dev-1701-manifest.json"
if archive.exists() or external.exists():
    raise FileExistsError("seal already exists")
for stem in ("openvins-timesync-observer-dev-1701", "openvins-timesync-startup-design-dev-1701"):
    old = json.loads((root / f"evidence/{stem}-manifest.json").read_text())
    assert sha((root / old["archive"]).read_bytes()) == old["sha256"]
selected = [
    "tools/benchmark/openvins_timesync_interval.py",
    "tests/benchmark/test_openvins_timesync_interval.py",
    "docs/OPENVINS_TIMESYNC_INTERVAL_REPORT.md",
    "docs/superpowers/specs/2026-10-08-timesync-interval-design.md",
    "docs/superpowers/plans/2026-10-08-timesync-interval.md",
    "docs/superpowers/plans/2026-10-07-openvins-ekf2-shadow-integration.md",
    ".superpowers/sdd/2026-10-07-openvins-ekf2-shadow-integration/progress.md",
]
paths = [root / name for name in selected] + [p for p in out.rglob("*") if p.is_file() and "__pycache__" not in p.parts]
members = {str(p.relative_to(root)).replace("\\", "/"): p.read_bytes() for p in paths}
manifest = {name: {"sha256": sha(data), "bytes": len(data)} for name, data in sorted(members.items())}
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as z:
    for name, data in members.items():
        z.writestr(name, data)
    z.writestr("member-manifest.json", json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(set(z.namelist())) == len(manifest) + 1
    for name, record in manifest.items():
        data = z.read(name)
        assert sha(data) == record["sha256"] and len(data) == record["bytes"]
summary = {"archive": str(archive.relative_to(root)).replace("\\", "/"),
           "sha256": sha(archive.read_bytes()), "bytes": archive.stat().st_size,
           "members": len(manifest)+1, "crc_verified": True, "member_hashes_verified": True}
with external.open("x") as f:
    json.dump(summary, f, indent=2)
print(json.dumps(summary))
