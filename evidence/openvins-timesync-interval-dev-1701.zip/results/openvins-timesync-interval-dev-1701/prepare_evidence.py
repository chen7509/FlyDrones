"""Retain source provenance and exact pre-review/native producer without reruns."""
import hashlib
import json
from pathlib import Path

out = Path(__file__).resolve().parent
root = out.parents[1]
sha = lambda b: hashlib.sha256(b).hexdigest()
previous = root / "results/openvins-timesync-startup-design-dev-1701"
manifest = json.loads((previous / "source-manifest.json").read_text())
records = []
for name in ("mavlink_main.cpp", "mavlink_receiver.cpp", "mavlink_stream.cpp", "mavlink_stream.h"):
    original = next(r for r in manifest["entries"] if r["name"] == name)
    data = (out / name).read_bytes()
    assert sha(data) == original["sha256"]
    records.append({**original, "copied_from": str((previous / name).relative_to(root)), "hash_verified": True})
with (out / "source-provenance.json").open("x") as f:
    json.dump({"entries": records, "observations_reused": True,
               "source_observed_utc": manifest["observed_utc"]}, f, indent=2)
for name in ("px4-metadata.json", "pymavlink-metadata.json"):
    with (out / ("reused-" + name)).open("xb") as f:
        f.write((previous / name).read_bytes())
module = root / "tools/benchmark/openvins_timesync_interval.py"
new = '''            # Diagnostics must not call untrusted exception formatting outside
            # a guard: __str__ may itself raise and otherwise skip restoration.
            try:
                message = str(exc)
            except BaseException:
                message = "<unprintable exception>"
            detail = f"{phase}:{type(exc).__name__}:{message}"'''
old = '            detail = f"{phase}:{type(exc).__name__}:{exc}"'
current = module.read_bytes()
assert current.count(new.encode()) == 1
producer = current.replace(new.encode(), old.encode())
native = json.loads((out / "compile.json").read_text())
expected = next(v for k, v in native["before"].items() if k.endswith("openvins_timesync_interval.py"))
assert sha(producer) == expected
with (out / "native-producer-helper.py").open("xb") as f:
    f.write(producer)
with (out / "producer-note.json").open("x") as f:
    json.dump({"native_producer_sha256": expected,
               "reconstructed_after_run_from_final_minus_review_guard": True,
               "not_claimed_runtime_file_copy": True,
               "reconstruction_matches_recorded_before_after_hash": True,
               "final_helper_sha256": sha(current),
               "only_change_after_native_probe": "guard exception __str__ during cleanup"}, f, indent=2)
print("Source provenance and pre-review helper hashes verified")
