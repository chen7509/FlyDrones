# Remaining receiver-startup dependency

Interval transaction is an offline model, not a bounded live transport. Do not
run PX4, change streams/parameters or publish ODOMETRY under this stage.

Read existing installed/fixed listener/Subscription/DeviceNode/main and MAVLink
timesync copies in results/openvins-timesync-observer-dev-1701/installed first.
Avoid repeating SDK inventory, physical studies or normal estimator replays.

The next design must address all of:
1. Cold PX4 epoch and exclusive timesync filter producer/channel. A new companion
   object is not a PX4 filter reset; source_protocol0 is not channel proof.
2. First status publication vs listener's refusal of unpublished topics. No
   assumption that stdout line count is uORB generation, and no dropped initial
   filter samples hidden by resetting the companion counter.
3. Actual listener framing, topic instance and finite/strict integer fields,
   bounded reads, partial lines, errors, EOF, and log/close failure.
4. One in-flight controlled reply and matched status before next reply. A modeled
   configured100Hz does not prove500 accepted exchanges within8s readiness.
5. Abstract interval adapter must implement bounded fresh ACK/query handling on
   an exclusive selected channel, with durable attempted-write/restore evidence.
   MAVLink command/message lacks a local transaction nonce; do not invent one.
6. Compose fail-closed observation, interval restoration and existing owned
   lifecycle guard into the replacement preflight without widening scope into
   generic process governance or changing physical/safety thresholds.

If installed CLI cannot provide needed observability/throughput, compare a small
native observer against a separately named timing study. Neither option is
approved by choosing a convenient timeout or assuming missing publications.
Finish concrete offline adapter/parser tests and reviewed launch declaration
before requesting the separately restricted live stage. Full drone goal stays
active; only this dependency has progressed.
