"""Offline arithmetic and actual in-memory codec; no network/subprocess PX4."""
import hashlib
import importlib.metadata
import json
import shutil
import subprocess
import sys
from pathlib import Path

out = Path(__file__).resolve().parent
root = out.parents[1]
sys.path.insert(0, str(root))
from tools.benchmark.openvins_timesync_interval import restorable_interval
from pymavlink.dialects.v20 import common

sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
compiler = Path(shutil.which("g++")).resolve()
source = out / "interval-expression.cpp"
binary = out / "interval-expression"
if binary.exists():
    raise FileExistsError(binary)
files = [source, Path(__file__), compiler,
         root / "tools/benchmark/openvins_timesync_interval.py", Path(common.__file__),
         out / "mavlink_receiver.cpp", out / "mavlink_main.cpp"]
before = {str(p): sha(p) for p in files}
command = [str(compiler), "-std=c++17", "-O2", "-fno-fast-math", str(source), "-o", str(binary)]
compile_run = subprocess.run(command, capture_output=True, text=True, timeout=30)
with (out / "compile.json").open("x") as f:
    json.dump({"command": command, "returncode": compile_run.returncode,
               "stdout": compile_run.stdout, "stderr": compile_run.stderr,
               "before": before, "compiler_version": subprocess.check_output([str(compiler), "--version"], text=True)}, f, indent=2)
compile_run.check_returncode()
values = list(range(1, 100001)) + [1000000, 16777216, 16777217, 2147483520, 2147483647]
run = subprocess.run([str(binary)], input="\n".join(map(str, values)), capture_output=True, text=True, timeout=10)
run.check_returncode()
with (out / "native-roundtrip.tsv").open("x") as f:
    f.write(run.stdout)
rows = [tuple(map(int, row.split())) for row in run.stdout.splitlines()]
assert [row[0] for row in rows] == values
mismatches = []
accepted = 0
for value, native_ok in rows:
    try:
        restorable_interval(value)
        python_ok = True
    except ValueError:
        python_ok = False
    accepted += python_ok
    if python_ok != bool(native_ok):
        mismatches.append([value, native_ok, python_ok])
wire = []
for value in [10000, 100000, 49, 61, 16777217]:
    encoder = common.MAVLink(None, srcSystem=254, srcComponent=191)
    message = common.MAVLink_command_long_message(9, 1, 511, 0, 111, value, 0, 0, 0, 0, 0)
    payload = message.pack(encoder)
    decoded = common.MAVLink(None).parse_char(payload)
    assert decoded.get_type() == "COMMAND_LONG" and decoded.param1 == 111
    status = common.MAVLink_message_interval_message(111, value).pack(encoder)
    readback = common.MAVLink(None).parse_char(status)
    assert readback.message_id == 111 and readback.interval_us == value
    wire.append({"requested_us": value, "command_decoded_us": decoded.param2,
                 "message_interval_us": readback.interval_us,
                 "command_hex": payload.hex(), "readback_hex": status.hex()})
after = {str(p): sha(p) for p in files}
summary = {"native_cases": len(values), "accepted": accepted, "refused": len(values)-accepted,
           "mismatches": mismatches, "wire_cases": wire,
           "pymavlink": importlib.metadata.version("pymavlink"),
           "source_hashes_stable": before == after, "after": after,
           "binary_sha256": sha(binary), "native_output_sha256": sha(out / "native-roundtrip.tsv"),
           "actual_px4_execution": False, "network_access": False, "live_rate_qualified": False}
with (out / "native-wire-summary.json").open("x") as f:
    json.dump(summary, f, indent=2)
assert before == after and not mismatches
print(json.dumps({k: summary[k] for k in ("native_cases", "accepted", "refused", "mismatches", "pymavlink")}))
