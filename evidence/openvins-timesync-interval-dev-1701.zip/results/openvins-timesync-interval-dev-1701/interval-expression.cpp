// Source-derived float expressions, NOT a PX4 build or stream execution.
#include <cstdint>
#include <iostream>
#include <limits>

int main() {
    long long n;
    while (std::cin >> n) {
        const float interval = static_cast<float>(n); // COMMAND_LONG param2
        const float rate = 1000000.0f / interval; // receiver expression
        const float back = 1000000.0f / rate; // configure_stream expression
        const bool representable = static_cast<double>(interval) == n;
        const bool in_range = back > 0 && static_cast<double>(back) < 2147483648.0;
        const bool exact = representable && in_range && static_cast<int>(back) == n;
        std::cout << n << '\t' << exact << '\n';
    }
}
