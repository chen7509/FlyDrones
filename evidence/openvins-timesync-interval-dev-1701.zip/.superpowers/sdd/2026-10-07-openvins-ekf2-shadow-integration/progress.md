# SDD ledger — plan: docs/superpowers/plans/2026-10-07-openvins-ekf2-shadow-integration.md

Pre-flight: Task 1 → Task 2 — Task 1 produces the pinned geometry and 9x9 covariance transform; Task 2 consumes it inside the transport-neutral health/session state machine. The interface is explicit and preserves `OpenVinsHealthContract` as the sole health authority.

Pre-flight: Task 2 → Task 3 — Task 2 produces either one immutable packet candidate or a structured refusal; Task 3 consumes those records in the existing single-worker file-only fan-out. No network transport is part of either interface.

Pre-flight: Task 3 → Task 4 — Task 3 produces qualified real-source timing/rate/covariance evidence; Task 4 consumes it only as a precondition for a separately bounded PX4 preflight. Camera-rate qualification cannot qualify propagated 30–50 Hz samples.

Pre-flight: Task 4 → Task 5 — Task 4 produces a frozen endpoint, clock, parameter, rollback and ULog contract; Task 5 consumes the exact committed preflight and is the first network/PX4-parameter stage.

Pre-flight: Task 5 → Task 6 — Task 5 proves receiver byte/field/time behavior with EV fusion disabled; Task 6 consumes that exact path for disarmed fusion observation under a separately frozen profile.

Pre-flight: Task 6 → Task 7 — Task 6 produces sustained disarmed fusion and fault-exit evidence; Task 7 consumes PX4 state as the only online state for a single-aircraft safety-supervised closed loop.

Task 1: in progress (BASE 47b404aa32ca674c9b47c4a5ef33e088706c715c)

Task 1: Ruling: the first repository-wide pytest run resolved an unrelated editable FlyDrones installation and failed collection with 69 missing `flydrones.benchmark` imports — rerun with this worktree's absolute `src` first on `PYTHONPATH`, matching the repository's documented full-suite boundary; retain the failed log — if wrong, a cross-worktree package could mask regression results.
Task 1: complete (commits 47b404a..768c4e3, tests: python -B -m pytest -p no:cacheprovider tests/benchmark/test_openvins_ekf2_transform.py tests/benchmark/test_openvins_odometry_contract.py tests/benchmark/test_openvins_health_contract.py -q → 76 passed in 0.80s)
Task 2: complete (commits 768c4e3..5740a74, tests: env PYTHONPATH=C:/Users/yuche/.codex/worktrees/FlyDrones/track-eligibility/src python -B -m pytest -p no:cacheprovider tests/benchmark/test_openvins_ekf2_integration.py tests/benchmark/test_openvins_ekf2_transform.py tests/benchmark/test_openvins_health_contract.py tests/benchmark/test_openvins_odometry_contract.py -q → 100 passed in 1.14s)

Task 3: complete (commits 5740a74..c91973a, tests: full repository suite 1,946 passed, 3 skipped, 2 existing warnings; terminal audit rerun SHA-256 8ebc05e43b093a293ceb8dfedb4fa5e3e41a2cb3380725a0bbb1832b6a0f40af; evidence archive SHA-256 d834874a46f8eedb6c2a0518036aa08dbe26a92ceeeacc8c1a8a9730bb77bdae; network/PX4 parameter access/fusion/flight all false)

Task 4: complete (commits c91973a..d60aad5; targeted tests 21 passed; full repository suite 1,967 passed, 3 skipped, 2 existing warnings; changed Ruff and diff-check passed; terminal audit task4_qualified=true/task5_authorized=false; evidence archive SHA-256 e226c8ec4239804c31c9bdde62c8ee86103994fe097c166641178728a530e8b5, 45 members, CRC verified; network/PX4 parameter access/fusion/arming all false)

Task 4 correction: Ruling: retained rollback qualification is incomplete — a remotely committed write with lost ACK was omitted from rollback and malformed later values stranded prior writes; 11 assertion RED cases reproduced. Correct locally under existing offline authorization, preserve old archive, bind a new preflight; Task 5 network/parameter execution remains pending the separate authorization already requested. BASE d60aad5. No competing resources observed. Current 32 focused tests GREEN; full regression and independent review running.

Task 4 correction: complete. Implementation bc8ab60; original 11 assertion RED -> 32 GREEN. Independent review Important cancellation-between-calls confirmed with 1 RED -> 33 targeted GREEN, then final 1979 passed / 3 skipped / 2 existing warnings. Changed Ruff/diff passed. Review has no remaining blockers. New preflight bound to bc8ab60, terminal audit failures empty; old archive/preflight verified unchanged. Correction ZIP SHA299b64cc757b490711a04cf2fd91ad3295e46fd227372cfbfc4ee3c634c3bc79 (31 members, CRC/member hashes verified). Task5 authorization remains pending; no network/live parameters/physical/fusion/arming. Previous goal turn was concrete progress (Task4 sealing); this turn corrects a verified rollback gap rather than redoing sealed physical evidence.

Task 5 offline preparation: in progress. The preceding user-facing status turn
did not change implementation; this continuation revalidated the active test
handle and review findings, then reproduced and corrected concrete receiver
evidence defects. Added offline byte/field comparator and CLI, with pinned
PX4/pymavlink/pyulog source evidence. Initial 46 targeted and 2025 full tests
passed before review; actual WSL codec cases then reproduced three false passes
on corrupt/incomplete ULogs and two exceptions lacking refusal artifacts.
Raw framing/subscription validation and exception normalization corrected those
five cases; 69 focused tests passed. Follow-up review identified swallowed
internal parser errors despite complete framing; that correction is ongoing.
No Task 5 physical checkbox or authorization changed. No network, parameters,
simulation, estimator or training started. All synthetic faults and historical
physical evidence remain separate and preserved.

Task 5 offline preparation: verified. Follow-up real-parser checks reproduced
seven swallowed internal errors, then all were refused using observed normal
EOF. Recursive-format failure was also reproduced and normalized to a retained
refusal. Final focused suite 71 passed; actual WSL codec harness 14/14 expected
outcomes (one synthetic normal, thirteen refusals); full repository suite 2050
passed / 3 skipped / 2 existing warnings in 348.71s. Changed Ruff/diff checks
passed; independent read-only review has no remaining blocking finding. Real
retained ULog framing passed 68,668 records, with zero receiver samples and an
expected negative result; no new capture. Current Task 5 live publication and
parameter authorization remains absent; no physical checkbox is checked. Seal
this scoped preparation; overall goal, receiver delivery and EKF2 fusion remain
incomplete.

Task 5 offline preparation sealed/pushed: producer 4fdf40c, seal d0f7dd0; evidence ZIP SHA cef59990fda45d563eeeff7bc516d5178d665d451ef803e08f47a3ad77e8f54e (256 members, CRC/member hashes verified). PR65 updated and attached. No live Task5 execution or fusion qualification. Overall goal remains active and incomplete.

Task4 startup reopened2026-10-08: preceding status-answer goal turn was no progress; current continuation produced source-backed startup/observability evidence and corrected authoritative plan/report. Pinned nominal10Hz/500accepted conflicts with25s/8swindow. Seven synthetic budget cases verified;100Hzis candidateonly. Live convergence observer and reversible interval transaction remain missing. Independent review timer wording/late-start assertion issues resolved, v1/v2retained. No production change, networkODOMETRY, liveparameters, physics, training or fusion. Full goal remains active. Next: inspect installed read-only convergence observer capability, then concrete replacement design; no blind normal study.

Serial TIMESYNC observer2026-10-08: previous goal turn was progress044a9ee(source budget correction). Nine installed/fixed PX4 source pairs match. Implemented pure one-pending-reply/status observer with authority alwaysfalse. Review P2 float integer-division error reproduced4RED and fixed;71observer/preflight and142combined checks passed. Native unchanged filter+explicit stubs emitted520 synthetic statuses,519accepted, all matched; separate signed large-boundary C++outputs confirmed. First full suite wrong external install failed70imports; currenttreePYTHONPATH retry2102passed/3skipped/2warnings325.12s. No live listener/network/parameter/stream/physical/estimator run. Next prerequisites: listener bootstrap/framing and cold/exclusivefilteridentity, reversible stream-rate transaction, replacement preflight. Overall goal active.

Observer sealed/published: implementation3c69dbf, planpublication6806423; personal/PR65 updated. ZIP9076ce18cf5126bca6115440a055aa55ed8625d3aa588136c8e01405bee4ccfe,59members, CRC/member hashes reverified. Tracked tree clean. Live gates and full goal remain incomplete.

TIMESYNC interval2026-10-08: preceding status-answer goal turn was no progress.
Current continuation implemented single-use abstract interval apply/body/restore,
strict positive int32 wire/reciprocal restoration, independent ACK/readbacks and
failure preservation. One independent-review Important exception-rendering cleanup
bypass reproduced4assertionRED then fixed/4GREEN rechecked.52new/123focused tests;
full2154passed/3skipped/2existingwarnings329.43s, currenttreePYTHONPATH. Native
source-derived expression100005cases matched Python; five actual pymavlink2.4.49
in-memory cases retained. No actual PX4/stream/parameter/network/physics/estimator
or training. Single helper does not prove live identity/correlation/watchdog,
durability or accepted frequency. Live Task4/5 gates and full goal remain open.
Next: listener bootstrap/framing/cold-exclusivechannel and concrete replacement
preflight. Seal and publish scoped results; don't rerun existing physical cases.
