# Source/API and reuse record

This stage composes existing code, not a new flight/estimation algorithm.
No dependency installation and no fresh simulator/estimator run.

|Component|Pinned or observed version and license|Maintenance basis|Decision and cost|
|---|---|---|---|
|PX4 listener/filter|d6f12ad1c4f70ad3230afd7d86e971421e02fef4, BSD3|reuse prior source/metadata, no new observation|retain exact listener bytes and false live authority; no PX4 process|
|pymavlink codec|2.4.49; retained COPYING distinguishes generator(L)GPLv3 and generated-outputMIT exception|prior stage fresh nonarchived/pushed2026-10-06 metadata reused|reuse installed common SHA a7c6b23d908322134d19cb94b937c1ea6b1f5d5ffa9d1b0ad139174bf8d75809; bounded encode/decode buffers, no network backend|
|Python|installedWSL3.12.3, PSF|installed version/prior source evidence; no assertion latestpackage|selectors/os.read/os.write ordinary Unix pipe API; one direct child percase, no children spawned bychild|
|Project composition|base25f3c63, stage source hashes before/after|local Git commits|reuse actualOwnedBootstrap reservation, strictwire and existing numericalfilter; bounded logs, synchronous proc checks, no numericalfilter rewrite|

Official references read2026-10-08:
- https://docs.python.org/3.12/library/os.html#os.write (rolling3.12.15page): write returns bytes written; no delivery guarantee.
- https://docs.python.org/3.12/library/selectors.html#introduction (rolling3.12.15page): platform support differs; Unix pipes supported. Not a Windows pipe claim.

Retained sources reused: results/openvins-owned-bootstrap-dev-1701/research.json
and owned-group-evidence-dev-1701/sources/subprocess-v3.12.3.py/.rst.
The earlier client/server/sock_protocol source hashes and installed-equality
observation are reused, not recomputed. Current source/fixture inputs will be
snapshotted in the new ordinary matrix before its first child launch.

Adopt coordinator + binarypipe fixture to exercise real encoding/reservation/
child decode/status association. Reject a new filter, success-only mock reserve,
or another index-only child control presented as packet reception. Requests and
RTT/status fields remain synthetic; stdin reply bytes are real ordinary-process
I/O. No actual UDP/source/namespace exclusivity or PX4 filter acceptance follows.

Existing VIO/learning paper basis is unchanged; source/API research is the
relevant dependency here. Further UDP/ACK/clock integration still needs its
specific upstream contracts and staged authorization.
