# Independent review and resolution

Reviewer read `25f3c63..d22e706` without executing or changing code. Three Important/P2, no Critical/Minor.

1. Unlock-before-reply/completion commit: two deterministic release-hook tests failed in review-lock-red.txt. Close-after-final-health test failed separately. State commits now occur under operation lock and state lock after final health; close/refusal use the same state lock. Original send effects remain logged.
2. Inner done bypassed terminal owner and 2s frame deadline: deterministic backend clock advances on inner completion; assertion failed in review-terminal-red.txt. Explicit allow_completed health check now applies the same ownership/frame/global gates before outer commit.
3. Post-case journal/copy/hash assertions could leave complete=true: matrix completion is set only after all case audits, all errors recorded; post hash drift also suppresses completion. review-harness-red.txt contains the hash-drift false-complete assertion failure; three post-cleanup journal/copy/copy-hash cases were added as GREEN coverage, not claimed identical historical RED.

One review fix pass committed f44be5b; no automatic second reviewer. Kernel-v1 actual execution then found JSON tuple/list comparison and /tmp retention gap, diagnosed independently. Two assertion failures in kernel-audit-red.txt now pass. Kernel-v2-prospective.md declares the corrected ordinary fixture experiment; all v1 available artifacts and missing-artifact boundary are retained.

67 WSL tests pass in targeted-final-v2.txt. No tests claim a real PX4 process, UDP or live filter. Reviewer confirmed child byte decoding precedes synthetic status generation.
