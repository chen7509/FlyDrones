"""Exclusive seal of this stage; no child processes or simulator."""
import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[2]
study = Path(__file__).resolve().parent
archive = root / 'evidence/openvins-wire-bootstrap-dev-1701.zip'
paths = [p for p in study.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
paths += [root / p for p in (
    'tools/benchmark/openvins_wire_bootstrap.py',
    'tools/benchmark/openvins_timesync_wire.py',
    'tools/benchmark/openvins_owned_bootstrap.py',
    'tools/benchmark/openvins_listener_transport.py',
    'tools/benchmark/owned_daemon_connection.py',
    'tools/benchmark/owned_group_evidence.py',
    'tools/benchmark/openvins_timesync_bootstrap.py',
    'tools/benchmark/openvins_timesync_listener.py',
    'tools/benchmark/openvins_timesync_observer.py',
    'tools/benchmark/openvins_ekf2_disarmed_preflight.py',
    'tests/benchmark/test_openvins_wire_bootstrap.py',
    'tests/benchmark/check_openvins_wire_bootstrap.py',
    'tests/benchmark/check_openvins_owned_bootstrap.py',
    'tests/benchmark/test_openvins_timesync_wire.py',
    'tests/benchmark/test_openvins_owned_bootstrap.py',
    'docs/OPENVINS_WIRE_BOOTSTRAP_REPORT.md',
    'docs/superpowers/specs/2026-10-08-wire-bootstrap-composition-design.md',
    'docs/superpowers/plans/2026-10-08-wire-bootstrap-composition.md',
)]
payload = {p.relative_to(root).as_posix(): p.read_bytes() for p in sorted(set(paths))}
manifest = {name: {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)} for name, raw in payload.items()}
payload['payload-manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, raw in payload.items():
        z.writestr(name, raw)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(set(z.namelist())) == len(manifest) + 1
    for name, expected in manifest.items():
        raw = z.read(name)
        assert len(raw) == expected['bytes']
        assert hashlib.sha256(raw).hexdigest() == expected['sha256']
metadata = {'archive': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'members': len(payload), 'bytes': archive.stat().st_size, 'crc': True, 'member_hashes': True}
with (study / 'seal-result.json').open('x') as f:
    json.dump(metadata, f, indent=2)
print(json.dumps(metadata))
