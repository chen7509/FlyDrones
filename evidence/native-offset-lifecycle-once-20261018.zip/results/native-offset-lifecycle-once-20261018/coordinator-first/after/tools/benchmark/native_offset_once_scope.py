"""Production scope entry and launcher for the fixed v2 once coordinator; no import-time dispatch."""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

from tools.benchmark.native_offset_build_receipt import write, read_json, produce
from tools.benchmark.native_offset_once import ROOT, verify_request
from tools.benchmark.run_openvins_dataset_consumer import linux, finish_owned_launcher
from tools.benchmark.calibration_capture_scope import manager_environment, cleanup_owned
from tools.benchmark.run_calibration_capture import stop_scope


def wsl(*argv, check=True, timeout=10):
    # Fixed control queries remain on the original bounded 10-second control boundary.
    from tools.benchmark.native_query_process import bounded_run
    result=bounded_run(['wsl','-d','Ubuntu','--',*argv],cwd=ROOT,env=os.environ.copy(),timeout=min(timeout,10))
    if result.output_limit_exceeded or result.collection_errors or (check and result.returncode):
        raise RuntimeError('WSL control query refused')
    return result


def verify_scope(unit, group, limits, properties, stage):
    memory,tasks=(1024**3,'64') if stage=='build' else (4*1024**3,'256')
    if (stage not in ('build','run') or re.fullmatch(r'fly-offset-[0-9a-f]{24}\.scope',unit) is None
            or not group.endswith('/'+unit) or properties.get('ControlGroup')!=group
            or not properties.get('InvocationID') or limits!={'memory.max':str(memory),'memory.swap.max':'0',
                'cpu.max':'100000 100000','pids.max':tasks}):
        raise ValueError('owned once scope identity/limits mismatch')


def run_inside(profile):
    import resource
    output=Path(profile['output']);stage=profile['stage']
    started=time.monotonic(); budget=300 if stage=='build' else 315
    deadline=started+budget
    rows=[line[3:] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::')]
    if len(rows)!=1: raise ValueError('unified owned cgroup unknown')
    group=rows[0];root=Path('/sys/fs/cgroup'+group)
    limits={name:(root/name).read_text().strip() for name in ('memory.max','memory.swap.max','cpu.max','pids.max')}
    props=subprocess.run(['systemctl','--user','show',profile['unit'],'--property=InvocationID','--property=ControlGroup'],
        env=manager_environment(),capture_output=True,text=True,timeout=10,check=True)
    properties=dict(line.split('=',1) for line in props.stdout.splitlines() if '=' in line)
    write(output/'inside-before.json',dict(pid=os.getpid(),cgroup=group,limits=limits,systemd_properties=props.stdout,qualification=False))
    verify_scope(profile['unit'],group,limits,properties,stage)
    checked=verify_request(profile['request'],profile['sha256'],profile['review'],profile['review_sha256'],stage)
    if checked!=profile['verified']: raise ValueError('selected inputs changed at scoped entry')
    request=checked['request'];request=dict(request,source=checked['source'])
    build=Path(request['bindings']['exclusive_build_dir'])
    if stage=='build': build.mkdir(exist_ok=False)
    commands=checked['command'] if stage=='build' else [checked['command']]
    steps=[]; primary=None; result=dict(exit=None,qualification=False,descendants='unknown',errors=[])
    resource.setrlimit(resource.RLIMIT_FSIZE,(64*1024**2,64*1024**2))
    try:
        for index,command in enumerate(commands):
            if time.monotonic()>=deadline: raise TimeoutError('whole stage deadline before command')
            verify_request(profile['request'],profile['sha256'],profile['review'],profile['review_sha256'],stage,require_absent=False)
            name=('configure','build')[index] if stage=='build' else 'capture'
            remaining=deadline-time.monotonic()
            actual=['/usr/bin/time','-v','-o',str(output/(name+'.resources')),
                '/usr/bin/timeout','--signal=TERM','--kill-after=10s',str(max(0.001,remaining))+'s',*command]
            row=dict(name=name,command=command,actual_command=actual,exit=None,cleanup=None,error=None)
            steps.append(row); process=None
            try:
                with (output/(name+'.stdout')).open('xb') as stdout,(output/(name+'.stderr')).open('xb') as stderr:
                    process=subprocess.Popen(actual,cwd=ROOT,env=checked['environment'],stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
                    write(output/(name+'.start.json'),dict(pid=process.pid,command=actual,cgroup=group))
                    row['exit']=process.wait(timeout=max(0.001,deadline-time.monotonic()))
            except BaseException as exc:
                row['error']=repr(exc)
                raise
            finally:
                if process is not None: row['cleanup']=cleanup_owned(process)
                write(output/(name+'.return.json'),row)
            if row['exit']!=0 or row['cleanup'].get('exit')!=0:
                raise RuntimeError(name+' failed; attempt remains consumed')
        verify_request(profile['request'],profile['sha256'],profile['review'],profile['review_sha256'],stage,require_absent=False)
        result['exit']=0
    except BaseException as exc:
        primary=exc; result['errors'].append(repr(exc))
    finally:
        try:
            result['limits_after']={name:(root/name).read_text().strip() for name in limits}
            result['memory_events']=(root/'memory.events').read_text()
            result['memory_peak']=(root/'memory.peak').read_text()
            if result['limits_after']!=limits: raise ValueError('scope limits changed')
            counters=dict(line.split() for line in result['memory_events'].splitlines())
            if any(int(counters.get(k,'0')) for k in ('oom','oom_kill','oom_group_kill')):
                raise ValueError('scope OOM events')
            if time.monotonic()>deadline: raise TimeoutError('terminal work exhausted original stage budget')
            if stage=='build':
                receipt=produce(request,build,steps)
                if not receipt['complete']: raise ValueError('build receipt incomplete; run gate remains closed')
        except BaseException as exc:
            result['errors'].append(repr(exc));result['exit']=2
        if result['errors']: result['exit']=2
        result['elapsed_s']=time.monotonic()-started
        write(output/'inside-completion.json',result)
    if primary is not None and not isinstance(primary,Exception): raise primary
    return result['exit']


def main(argv=None):
    args=sys.argv[1:] if argv is None else argv
    if args and args[0]=='--verify':
        parser=argparse.ArgumentParser()
        parser.add_argument('--verify',required=True)
        for name in ('sha256','review','review-sha256','stage'): parser.add_argument('--'+name,required=True)
        selected=parser.parse_args(args)
        print(json.dumps(verify_request(selected.verify,selected.sha256,selected.review,selected.review_sha256,selected.stage)))
        return 0
    if len(args)!=1: raise ValueError('one owned profile required')
    return run_inside(read_json(args[0]))


if __name__=='__main__':
    raise SystemExit(main())


def verify_remote(request,sha,review,review_sha,stage):
    command=['wsl','-d','Ubuntu','--','/usr/bin/env','-i','HOME=/home/yuchen7509','PATH=/usr/bin:/bin',
        'PYTHONPATH='+linux(ROOT)+'/src:'+linux(ROOT),'/usr/bin/python3','-m','tools.benchmark.native_offset_once_scope',
        '--verify',linux(request),'--sha256',sha,'--review',linux(review),'--review-sha256',review_sha,'--stage',stage]
    # Metadata request output is capped by the selected bounded helper, never a target invocation.
    from tools.benchmark.native_query_process import bounded_run
    result=bounded_run(command,cwd=ROOT,env=os.environ.copy(),timeout=10)
    if result.returncode or result.output_limit_exceeded or result.collection_errors:
        raise RuntimeError('current Linux verification refused: '+result.stderr.hex())
    return json.loads(result.stdout)


def launch_scope(output, study, sha, review, review_sha, stage, verified, unit):
    before = wsl("systemctl", "--user", "show", unit, "--property=LoadState", "--property=ActiveState", check=False, timeout=10)
    write(
        output / "scope-before.json", dict(exit=before.returncode, stdout_hex=before.stdout.hex(), stderr_hex=before.stderr.hex())
    )
    if b"LoadState=not-found" not in before.stdout:
        raise RuntimeError("new scope absent state unknown")
    profile = dict(unit=unit, output=linux(output), request=linux(study), sha256=sha, review=linux(review), review_sha256=review_sha, stage=stage, verified=verified)
    write(output / "scope.json", profile)
    command = [
        "wsl",
        "-d",
        "Ubuntu",
        "--",
        "/usr/bin/systemd-run",
        "--user",
        "--scope",
        "--unit=" + unit.removesuffix(".scope"),
        "--property=MemoryMax=" + str(1024**3 if stage == "build" else 4*1024**3),
        "--property=MemorySwapMax=0",
        "--property=CPUQuota=100%",
        "--property=TasksMax=" + ("64" if stage == "build" else "256"),
        "--property=RuntimeMaxSec=" + ("315" if stage == "build" else "330"),
        "--property=TimeoutStopSec=10s",
        "/usr/bin/env",
        "-i",
        "HOME=/home/yuchen7509",
        "PATH=/usr/bin:/bin",
        "PYTHONPATH=" + linux(ROOT) + "/src:" + linux(ROOT),
        "/usr/bin/python3",
        "-m",
        "tools.benchmark.native_offset_once_scope",
        linux(output / "scope.json"),
    ]
    process = None
    stop_attempted = False
    result = dict(exit=None, owned_group_released=None, escaped_closure="unknown", error=None)

    def stop_if_identified():
        nonlocal stop_attempted
        stop_attempted = True
        identity = output / "inside-before.json"
        if identity.exists():
            stop_scope(output, unit, json.loads(identity.read_text(encoding="utf8")))
        else:
            write(output / "scope-ownership-unknown.json", dict(unit=unit, residual="unknown; no unit stop"))

    def observe_release():
        after = wsl(
            "systemctl", "--user", "show", unit, "--property=LoadState", "--property=ActiveState", check=False, timeout=10
        )
        released = None
        identity = output / "inside-before.json"
        if identity.exists():
            inside = json.loads(identity.read_text(encoding="utf8"))
            group = inside["cgroup"]
            if group.endswith("/" + unit):
                exists = wsl("test", "-d", "/sys/fs/cgroup" + group, check=False, timeout=10)
                released = exists.returncode == 1 and b"LoadState=not-found" in after.stdout
        result.update(
            owned_group_released=released,
            after_exit=after.returncode,
            after_stdout_hex=after.stdout.hex(),
            after_stderr_hex=after.stderr.hex(),
        )

    primary = None
    try:
        with (output / "launcher.stdout").open("xb") as stdout, (output / "launcher.stderr").open("xb") as stderr:
            process = subprocess.Popen(command, stdout=stdout, stderr=stderr)
            write(output / "launcher.json", dict(pid=process.pid, command=command, unit=unit))
            try:
                result["exit"] = process.wait(timeout=330 if stage == "build" else 360)
            except subprocess.TimeoutExpired:
                raise RuntimeError("physical launcher timeout; retained ownership/cleanup evidence") from None
        observe_release()
        if result["owned_group_released"] is not True:
            stop_if_identified()
            observe_release()
    except BaseException as exc:
        primary = exc
        result["error"] = repr(exc)
        raise
    finally:
        if process is not None:
            if primary is not None and not stop_attempted:
                try:
                    stop_if_identified()
                except Exception as exc:
                    result["scope_cleanup_error"] = repr(exc)
            try:
                finish_owned_launcher(output, process)
            except Exception as exc:
                result["launcher_cleanup_error"] = repr(exc)
            if primary is not None:
                try:
                    observe_release()
                except Exception as exc:
                    result["release_observation_error"] = repr(exc)
        try:
            write(output / "launcher-completion.json", result)
        except Exception:
            if primary is None:
                raise
    return result

