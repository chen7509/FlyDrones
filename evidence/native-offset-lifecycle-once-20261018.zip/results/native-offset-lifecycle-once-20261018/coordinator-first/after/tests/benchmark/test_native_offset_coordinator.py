"""Only the new once/receipt lifecycle; process/resource boundaries are inert."""
import hashlib
import json
import os
import socket
import subprocess
from pathlib import Path

import pytest


@pytest.fixture(autouse=True)
def no_native(monkeypatch):
    def denied(*a, **k):
        raise AssertionError('native/network/resource execution forbidden')
    monkeypatch.setattr(subprocess, 'Popen', denied)
    monkeypatch.setattr(socket, 'socket', denied)
    monkeypatch.setattr(os, 'system', denied)


def facts():
    return dict(windows_available=4*1024**3,wsl=dict(available=4*1024**3,processes=[]),
                windows_processes=[],blocked_processes=[],docker_exit=0,docker_running='')


def test_consumed_precedes_dispatch_and_survives_failure(tmp_path):
    from tools.benchmark import native_offset_once as once
    output = tmp_path/'fixed'
    def launch(stage, *a):
        assert (stage/'consumed.json').is_file()
        raise RuntimeError('inert dispatcher failure after boundary')
    args = dict(collect=facts,verify=lambda *a: {'bound':True},launch=launch,attempt=output)
    result = once.execute_once(Path('request'), 'a'*64,Path('review'),'b'*64,'build',**args)
    assert result['consumed'] is True and 'dispatcher failure' in result['error']
    assert (output/'build/completion.json').is_file()
    with pytest.raises(FileExistsError):
        once.execute_once(Path('renamed-request'),'c'*64,Path('review'),'b'*64,'build',**args)


def test_refusal_saved_without_dispatch_and_cannot_repoll(tmp_path):
    from tools.benchmark import native_offset_once as once
    calls=[]
    args=dict(collect=lambda: calls.append('collect') or dict(facts(),windows_available=1),
              verify=lambda *a: calls.append('verify'),launch=lambda *a:calls.append('launch'),attempt=tmp_path/'fixed')
    result=once.execute_once(Path('r'),'a'*64,Path('v'),'b'*64,'build',**args)
    assert result['consumed'] is False and calls==['collect']
    assert (tmp_path/'fixed/build/firstfacts.json').is_file()
    with pytest.raises(FileExistsError):
        once.execute_once(Path('r'),'a'*64,Path('v'),'b'*64,'build',**args)
    assert calls==['collect']


def test_changed_selection_never_dispatches(tmp_path):
    from tools.benchmark import native_offset_once as once
    values=iter([{'source':'a'},{'source':'b'}]); calls=[]
    result=once.execute_once(Path('r'),'a'*64,Path('v'),'b'*64,'run',collect=facts,
        verify=lambda *a:next(values),launch=lambda *a:calls.append('launch'),attempt=tmp_path/'fixed')
    assert result['consumed'] is False and calls==[] and 'changed' in result['error']


def test_override_dependencies_must_be_complete(tmp_path):
    from tools.benchmark import native_offset_once as once
    with pytest.raises(ValueError):
        once.execute_once(Path('r'),'a'*64,Path('v'),'b'*64,'build',collect=facts,attempt=tmp_path)


def fixture_build(tmp_path):
    from tools.benchmark.native_offset_build_receipt import file_pin
    build=tmp_path/'build'; build.mkdir()
    source=tmp_path/'openvins_online_probe_v2.cpp';source.write_text('modeled source')
    compiler=tmp_path/'g++';compiler.write_bytes(b'modeled compiler, never executed')
    header=tmp_path/'header.h';header.write_text('modeled header')
    library=tmp_path/'library.so';library.write_text('modeled library')
    (build/'CMakeFiles/openvins_offset_reset_v2.dir').mkdir(parents=True)
    target=build/'openvins_offset_reset_v2';target.write_bytes(b'\x7fELF'+b'\0'*60)
    (build/'CMakeCache.txt').write_text('CMAKE_BUILD_TYPE:STRING=Release\nCMAKE_CXX_COMPILER:FILEPATH='+str(compiler)+'\n')
    (build/'compile_commands.json').write_text(json.dumps([dict(directory=str(build),file=str(source),
        arguments=[str(compiler),'-std=c++17','-O2','-MD','-c',str(source),'-o','probe.o'])]))
    (build/'CMakeFiles/openvins_offset_reset_v2.dir/probe.o.d').write_text('probe.o: '+str(source)+' '+str(header)+'\n')
    (build/'CMakeFiles/openvins_offset_reset_v2.dir/link.txt').write_text(str(compiler)+' probe.o '+str(library)+' -o openvins_offset_reset_v2\n')
    (build/'cmake-trace.jsonl').write_text(json.dumps(dict(file=str(header),cmd='set',args=[]))+'\n')
    request=dict(bindings=dict(exclusive_build_dir=str(build),pinned_gxx=str(compiler)),
        input_pins={str(p):file_pin(p) for p in (source,compiler,header,library)},source=str(source))
    steps=[dict(name=n,exit=0,command=[n],cleanup=dict(exit=0)) for n in ('configure','build')]
    return request,build,steps,header,target


def test_receipt_keeps_success_separate_from_native_qualification(tmp_path):
    from tools.benchmark.native_offset_build_receipt import produce
    request,build,steps,_,target=fixture_build(tmp_path)
    result=produce(request,build,steps)
    assert result['complete'] is True and result['native_qualified'] is False
    assert result['binary']['sha256']==hashlib.sha256(target.read_bytes()).hexdigest()
    assert (build/'build-receipt.json').is_file()
    assert len(result['depfiles'])==1


@pytest.mark.parametrize('fault',['failed','missing','drift','unknown-header','std','cleanup','trace','link'])
def test_receipt_refuses_partial_or_unbound_build(tmp_path,fault):
    from tools.benchmark.native_offset_build_receipt import produce
    request,build,steps,header,target=fixture_build(tmp_path)
    if fault=='failed': steps[1]['exit']=2
    if fault=='missing': target.unlink()
    if fault=='drift': header.write_text('changed')
    if fault=='unknown-header': request['input_pins'].pop(str(header))
    if fault=='std':
        path=build/'compile_commands.json';path.write_text(path.read_text().replace('c++17','c++14'))
    if fault=='cleanup': steps[1]['cleanup']['exit']=None
    if fault=='trace': (build/'cmake-trace.jsonl').unlink()
    if fault=='link': (build/'CMakeFiles/openvins_offset_reset_v2.dir/link.txt').unlink()
    result=produce(request,build,steps)
    assert result['complete'] is False and result['errors'] and result['native_qualified'] is False
    assert (build/'build-receipt.json').is_file()


def test_fixed_commands_cannot_select_legacy_binary_or_extra_target(tmp_path):
    from tools.benchmark.native_offset_once import build_commands
    b={key:str(tmp_path/key) for key in ('pinned_cmake','deployed_repo','exclusive_build_dir','pinned_gxx','pinned_make',
        'toolchain_file','upstream_source_tree','openvins_library_dir','openvins_library_file','eigen_config_dir',
        'opencv4_config_dir','boost_config_dir','ceres_config_dir')}
    configure,build=build_commands(b)
    assert build==[b['pinned_cmake'],'--build',b['exclusive_build_dir'],'--target','openvins_offset_reset_v2','--parallel','1']
    assert '-DCMAKE_CXX_FLAGS_RELEASE=-O2' in configure and '--trace-format=json-v1' in configure
