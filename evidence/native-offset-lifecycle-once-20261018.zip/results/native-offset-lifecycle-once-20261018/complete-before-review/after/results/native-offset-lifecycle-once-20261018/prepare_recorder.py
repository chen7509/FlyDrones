"""Prospective new-phase recorder declaration; legacy raw stays unchanged."""
from pathlib import Path
root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
source = (root/'results/px4-disarmed-receipts-20261018/record-v2.py').read_text(encoding='utf-8')
paths = (
    'tools/benchmark/offset_reset_native_source.py', 'tools/benchmark/openvins_online_probe_v2.cpp',
    'tools/benchmark/capture_disarmed_sensors.py', 'tools/benchmark/capture_contract.py',
    'tools/benchmark/native_offset_once.py', 'tools/benchmark/native_offset_once_scope.py',
    'tools/benchmark/native_offset_build_receipt.py', 'tools/benchmark/openvins_online_shadow.py',
    'tools/benchmark/runtime_resource_binding.py', 'tools/benchmark/native_offset_reset_v2/CMakeLists.txt',
    'tests/benchmark/test_native_offset_prefeed_once.py', 'tests/benchmark/test_native_offset_coordinator.py',
    'docs/NATIVE_OFFSET_LIFECYCLE_ONCE_PROGRESS.md',
    'docs/superpowers/specs/2026-10-18-native-offset-lifecycle-once.md',
    'docs/superpowers/plans/2026-10-18-native-offset-lifecycle-once.md',
    'results/native-offset-lifecycle-once-20261018/prepare_recorder.py',
    'results/native-offset-lifecycle-once-20261018/record.py',
)
start = source.index('SOURCES = ')
end = source.index('\n\n', start)
source = source[:start] + 'SOURCES = ' + repr(paths) + source[end:]
with (out/'record.py').open('x', encoding='utf-8') as stream: stream.write(source)
