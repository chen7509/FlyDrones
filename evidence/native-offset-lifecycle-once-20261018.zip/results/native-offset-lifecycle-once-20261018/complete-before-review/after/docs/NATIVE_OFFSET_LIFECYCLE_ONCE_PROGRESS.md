# v2 lifecycle software integration

Work in progress on the existing branch. The new prefeed readiness/release is integrated in the production v2 factory; the old NativeClient and old C++ protocol remain unchanged. A new software-only run observed 10 failures (one behavioral bypass and nine missing-interface cases), followed by 10 passing cases in 1.13 seconds. These are modeled process boundaries, not native construction/maps/ABI tests.

The bound coordinator and build receipt producer are being implemented in the same production lifecycle. No configure/compiler/native/resource query or old test has run. All qualification/readiness flags remain false. Original evidence and unknown/consumed attempts are not reopened.
