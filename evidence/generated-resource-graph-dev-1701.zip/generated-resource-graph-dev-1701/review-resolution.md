# Independent review and one fix pass
Reviewer /root/review_generated_resource_graph found no Critical, four Important and one Minor.
Important: bootstrap selfmaps could authorize undeclared graph targets; projector texture could be omitted; capture_output text collection was unbounded and lost invalid-byte evidence; overall graph deadline was checked only during queries.
Minor: baseline failure before self.before produced no post attempt.
Six regression assertions in review-red.txt all failed before fixes. All pass in the subsequent targeted suite. The bounded helper runner also has real child tests for oversized bytes, invalid UTF-8 preservation and timeout. No second review or deferred Minor.
The source-size failure is independent: original 22,399,616-byte DAE exceeds new arbitrary 8MiB cap. Original v1 failure retained. Spec prospectively amends new offline v2 cap to32MiB; no physical/VIO threshold changed.
Graph deadline is cooperative: checks surround source parsing and after binding snapshots/maps, not a claim of interrupting blocked I/O. Owned helper stdout/stderr combined prefix is at most1MiB; overflow refuses and records truncation; cleanup has separate bounded waits. This is not global process-tree governance.
