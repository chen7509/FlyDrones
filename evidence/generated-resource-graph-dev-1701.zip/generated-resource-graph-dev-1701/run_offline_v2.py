import hashlib,json,os,sys,traceback,zipfile
from pathlib import Path
stage=Path(__file__).resolve().parent;root=stage.parents[1];sys.path.insert(0,str(root))
from tools.benchmark.declared_runtime_snapshot import snapshot,write_manifest
from tools.benchmark.native_resource_client import QueryClient,QUERY_ENV_KEYS
from tools.benchmark.runtime_resource_binding import RuntimeBinding,GENERATED_NAMES,ENV_KEYS
out=stage/'offline-generated-world-v2';out.mkdir(exist_ok=False)
archive=root/'evidence/supported-online-vio-dev-1701.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='07a2a247b87ff43304ec4c0fe787640264772ad12c272b354d5a5116cdecaeb2'
old_archive=root/'evidence/selected-resource-graph-dev-1701.zip'
assert hashlib.sha256(old_archive.read_bytes()).hexdigest()=='af3308d916dcbf0f79d5667eb43e27b80c52ee92f767fd5d17f33e61357462e1'
with zipfile.ZipFile(old_archive) as z:
 member='selected-resource-graph-dev-1701/fixed-v2/fixed-discovery.json';data=z.read(member);old=json.loads(data)
 old_member=dict(name=member,sha256=hashlib.sha256(data).hexdigest())
generated={};inputs=[]
with zipfile.ZipFile(archive) as z:
 for name in GENERATED_NAMES:
  target=out/name
  if name=='gz_env.sh':
   original=Path.home()/'PX4-Autopilot/build/px4_sitl_default/rootfs/gz_env.sh';data=original.read_bytes();origin=str(original)
  else:
   origin='results/supported-online-vio-dev-1701/capture-v1/'+name;data=z.read(origin)
  target.write_bytes(data);generated[name]=target
  inputs.append(dict(name=name,origin=origin,sha256=hashlib.sha256(data).hexdigest()))
selected=set()
for edge in old['edges']:
 p=edge.get('candidate')
 if p and '/fixed-v2/' not in p:selected.add(p)
for directory,item in old['selected_models'].items():
 selected.add(item['selected']);selected.add(str(Path(directory)/'model.config'))
for item in old['selected_plugins'].values():selected.add(item['selected'])
selected.add(old['media']['classic_material'])
source=root/'tools/benchmark/native/resource_resolver.cc';binary=stage/'study-build/resource_resolver'
build=json.loads((stage/'study-build/build-hashes.json').read_text())
for row in build:assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
deps={row['path'] for row in build}-{str(source),str(binary)}
selected-=deps|{str(source),str(binary)}
project_files=[root/'tools/benchmark'/name for name in ('native_query_process.py','native_resource_client.py','bound_resource_graph.py','runtime_resource_binding.py','declared_runtime_snapshot.py','selected_resource_graph.py','capture_contract.py')]
inventory={'graph:resolver':[str(binary)],'graph:source':[str(source)],'graph:dependencies':sorted(deps),'declared:resources':sorted(selected),'declared:python':[str(p) for p in project_files]}
base=snapshot(inventory);write_manifest(out/'declared-before-helper.json',base)
env=dict(os.environ)
env['GZ_SIM_RESOURCE_PATH']=str(root/'assets/gazebo/models')+':'+str(Path.home()/'PX4-Autopilot/Tools/simulation/gz/models')+':'
# Fresh explicitly named offline context, not PR48 historical environment.
for name in ('SDF_PATH','GZ_FILE_PATH','GZ_PLUGIN_PATH','GZ_SIM_SYSTEM_PLUGIN_PATH','IGN_PLUGIN_PATH','IGN_FILE_PATH','IGN_GAZEBO_RESOURCE_PATH','IGN_GAZEBO_SYSTEM_PLUGIN_PATH'):
 env[name]=''
env.pop('GZ_MESH_FORCE_ASSIMP',None)
query_env={k:env.get(k) for k in QUERY_ENV_KEYS}
prequery=out/'prospective-query';prequery.mkdir()
context=QueryClient(binary,root,query_env,prequery).query('context')
assert base['files']==snapshot(inventory)['files']
doc=dict(schema='capture-resource-binding-v2',inventory=inventory,baseline=base,
 environment={k:env.get(k) for k in ENV_KEYS},generated={r['name']:r['sha256'] for r in inputs},
 graph=dict(schema='generated-resource-graph-v1',cwd=str(root),environment=query_env,expected_context=context))
write_manifest(out/'binding-declaration.json',doc)
write_manifest(out/'input-provenance.json',dict(producer=sys.argv[1],input_archive=str(archive),input_member_hashes=inputs,selected_declaration_source=old_member,scope='new offline generated-source preflight, no physical capture'))
obj=RuntimeBinding(doc,out)
error=None
try:
 obj.start(generated,env,[binary,source,*project_files])
except Exception as exc:
 error=repr(exc);(out/'error-trace.txt').write_text(traceback.format_exc())
finally:
 result=obj.finish()
summary=dict(study='offline-generated-world-v2',error=error,binding=result,physical_run=False,estimator_run=False,fusion=False,
 status='offline_preflight_pass' if not error and result['local_file_graph_verified'] else 'offline_preflight_refused')
write_manifest(out/'study-result.json',summary)
print(json.dumps(summary))
if error:sys.exit(2)
