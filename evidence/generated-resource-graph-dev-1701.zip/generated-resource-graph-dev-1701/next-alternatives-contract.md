 integration executed and correctly refused, not qualified. v1/v2 failures and next prerequisite are recorded in GENERATED_RESOURCE_GRAPH_REPORT.md. Source cap amendment is in the spec; original8MiB plan retained as history. Publication/evidence completes the stage, not the overall user goal.

Read report final Next paragraph and query0018. Both copies hash3a56ec48eeaaf7774e8d3e8e5e88f6973bfa5652c610974c3eb2dbec6ec85944. No new physics authorized by current graph result.
