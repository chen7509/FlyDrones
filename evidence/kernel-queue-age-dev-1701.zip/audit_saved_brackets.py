"""New retrospective arithmetic only, never a prebind/runtime clock proof."""
import hashlib
import json
import struct
import sys
import zipfile
from io import BytesIO
from pathlib import Path

root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root))
from tools.benchmark.kernel_queue_age import modeled_age,offset_bracket  # noqa: E402

base=Path(__file__).parent
archive=root/'evidence/rx-startup-observer-dev-1701.zip'
raw=archive.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='0674634cc28b935db9c4c86169502aab6f715217552824b825087e43ba3d00cd'
consumed={}
with zipfile.ZipFile(BytesIO(raw)) as contents:
    manifest=json.loads(contents.read('member-hashes.json'))
    def member(name):
        payload=contents.read(name)
        entry=manifest[name]
        assert len(payload)==entry['bytes'] and hashlib.sha256(payload).hexdigest()==entry['sha256']
        consumed[name]=entry
        return payload
    source=member('study-v1/inputs/tools/benchmark/observe_kernel_rx_startup.py')
    assert hashlib.sha256(source).hexdigest()=='3a99e94b3f75e6f957d72e3cfd9d5613300adf762552738cfd3530633ef26177'
    result=json.loads(member('study-v1/capture-v1/result.json'))
    profile=json.loads(member('study-v1/profile.json'))
assert len(result['packets'])==profile['count']==8
rows=[]
interval=None
failure=None
for packet in result['packets']:
    row={'index':packet['index'],'brackets':[],'modeled_age':None,'reason':None}
    try:
        if failure:
            raise ValueError('retrospective model failure latched: '+failure)
        for phase,m0,r,m1 in [
            ('attempt_to_send',packet['attempt_monotonic_ns'],packet['attempt_realtime_ns'],packet['send_start_monotonic_ns']),
            ('read_start_to_return',packet['recv_start_monotonic_ns'],packet['recv_start_realtime_ns'],packet['recv_return_monotonic_ns'])]:
            lo,hi=offset_bracket(m0,r,m1)
            if interval is not None:lo,hi=max(lo,interval[0]),min(hi,interval[1])
            if lo>hi:raise ValueError('observed offset intervals do not intersect')
            interval=lo,hi
            row['brackets'].append({'phase':phase,'monotonic_before_ns':m0,'realtime_ns':r,
                                    'monotonic_after_ns':m1,'offset_intersection_ns':interval})
        control=packet['ancillary_raw'][0]
        assert control['level']==1 and control['type']==65
        sec,ns,*other=struct.unpack('<6q',bytes.fromhex(control['data_hex']))
        assert other==[0,0,0,0] and 0<=ns<1_000_000_000
        stamp=sec*1_000_000_000+ns
        assert stamp==packet['metadata']['timestamp_ns']
        row['modeled_age']=modeled_age(stamp,packet['recv_return_monotonic_ns'],*interval)
    except ValueError as error:
        failure=failure or str(error)
        row['reason']=str(error)
    rows.append(row)
record={'schema':'flydrones.saved_rx_brackets.model.v1','archive_sha256':hashlib.sha256(raw).hexdigest(),
        'consumed_members':consumed,'frame_count':len(rows),'records':rows,
        'causal_model_usable_count':sum(x['modeled_age'] is not None for x in rows),
        'prior_failure_modified':False,'network_or_simulation_started':False,
        'historical_prebind_anchor_proven':False,'runtime_clock_relation_qualified':False,
        'source_authenticated':False,'fusion_qualified':False,'training_eligible':False,
        'basis':'known producer ordering only; wide retrospective intervals include journal/runtime delay; not new live sampler'}
with (base/'saved-bracket-audit-v1.json').open('x') as stream:json.dump(record,stream,indent=2)
upper=[x['modeled_age']['modeled_age_upper_ns'] for x in rows if x['modeled_age']]
print(json.dumps({'frames':len(rows),'causal_model_usable':len(upper),
                  'modeled_age_upper_ns_range':[min(upper),max(upper)] if upper else None,
                  'runtime_clock_relation_qualified':False},indent=2))
