"""Existing real codec + fake transports, no socket/physics job."""
import hashlib
import importlib.metadata
import json
import os
import subprocess
import sys
from pathlib import Path

root=Path(__file__).resolve().parents[2]
out=Path(__file__).parent/'wsl-final-v1'
out.mkdir(exist_ok=False)
names=['tools/benchmark/kernel_queue_age.py','tools/benchmark/openvins_datagram_receive.py',
       'tools/benchmark/openvins_timesync_wire.py',
       'tests/benchmark/test_openvins_timesync_wire.py','tests/benchmark/test_openvins_wire_maintenance.py',
       'tests/benchmark/test_openvins_observed_restoration.py']
def hashes():return {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in names}
before=hashes()
assert importlib.metadata.version('pymavlink')=='2.4.49'
command=[sys.executable,'-B','-m','unittest','tests.benchmark.test_openvins_timesync_wire',
         'tests.benchmark.test_openvins_wire_maintenance','tests.benchmark.test_openvins_observed_restoration','-v']
env={**os.environ,'PYTHONPATH':str(root/'src')+os.pathsep+str(root)}
result=subprocess.run(command,cwd=root,env=env,capture_output=True,timeout=120)
(out/'stdout.txt').write_bytes(result.stdout)
(out/'stderr.txt').write_bytes(result.stderr)
after=hashes()
record={'command':command,'exit_code':result.returncode,'source_before':before,'source_after':after,
        'source_unchanged':before==after,'python':sys.version,'pymavlink':'2.4.49',
        'scope':'real codec and fixture transports only, no actual socket or simulation'}
(out/'execution.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record,indent=2))
if result.returncode or before!=after:raise SystemExit(1)
