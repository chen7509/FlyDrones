import hashlib
import json
import shutil
import zipfile
from pathlib import Path

root=Path(__file__).resolve().parents[2]
base=Path(__file__).parent
execution=json.loads((base/'final-v1/execution.json').read_text())
assert execution['source_unchanged'] and all(x['exit_code']==0 for x in execution['commands'])
wsl=json.loads((base/'wsl-final-v1/execution.json').read_text())
assert wsl['source_unchanged'] and wsl['exit_code']==0
for name,digest in {**execution['source_after'],**wsl['source_after']}.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
    target=base/'final-source'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(root/name,target)
for name in ['docs/KERNEL_QUEUE_AGE_REPORT.md',
             'docs/superpowers/specs/2026-10-12-kernel-queue-age-design.md',
             'docs/superpowers/plans/2026-10-12-kernel-queue-age.md']:
    target=base/'documents'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(root/name,target)
audit=json.loads((base/'saved-bracket-audit-v1.json').read_text())
assert audit['frame_count']==8 and audit['causal_model_usable_count']==8
assert not audit['runtime_clock_relation_qualified'] and not audit['historical_prebind_anchor_proven']
reference=root/'evidence/rx-startup-observer-dev-1701.zip'
assert hashlib.sha256(reference.read_bytes()).hexdigest()==audit['archive_sha256']
files=sorted(p for p in base.rglob('*') if p.is_file() and p.suffix!='.pyc' and p.name not in ['pr65-before.json','seal.json'])
members={p.relative_to(base).as_posix():{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
                                      'bytes':p.stat().st_size} for p in files}
archive=root/'evidence/kernel-queue-age-dev-1701.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as contents:
    for p in files:
        assert not p.is_symlink()
        contents.write(p,p.relative_to(base).as_posix())
    contents.writestr('member-hashes.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as contents:
    assert contents.testzip() is None and set(contents.namelist())==set(members)|{'member-hashes.json'}
    for name,entry in members.items():
        raw=contents.read(name)
        assert len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256']
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
with archive.with_suffix('.sha256').open('x',encoding='ascii') as stream:
    stream.write(digest+'  '+archive.name+'\n')
record={'sha256':digest,'members':len(members)+1,'bytes':archive.stat().st_size,
        'all_member_hashes_and_crc_verified':True,'windows_passed':188,'windows_skipped':3,
        'wsl_codec_fixture_passed':75,'source_clock_network_fusion_training_qualified':False}
with (base/'seal.json').open('x') as stream:json.dump(record,stream,indent=2)
print(json.dumps(record,indent=2))
