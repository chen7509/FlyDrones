import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root=Path(__file__).resolve().parents[2]
out=Path(__file__).parent/'final-v1'
out.mkdir(exist_ok=False)
names=['tools/benchmark/kernel_queue_age.py','tools/benchmark/openvins_datagram_receive.py',
       'tests/benchmark/test_kernel_queue_age.py','tools/benchmark/kernel_rx_timestamping.py']
def hashes():return {name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in names}
before=hashes()
env={**os.environ,'PYTHONPATH':str(root/'src')+os.pathsep+str(root)}
commands=[
    [sys.executable,'-m','pytest','tests/benchmark/test_kernel_queue_age.py',
     'tests/benchmark/test_openvins_datagram_receive.py','tests/benchmark/test_kernel_rx_timestamping.py',
     'tests/benchmark/test_kernel_datagram_arrival.py','tests/benchmark/test_generated_rx_queue_study.py',
     'tests/benchmark/test_kernel_arrival_study_profile.py','tests/benchmark/test_openvins_observed_restoration.py',
     'tests/benchmark/test_openvins_wire_maintenance.py','tests/benchmark/test_openvins_timesync_wire.py',
     'tests/benchmark/test_openvins_segmented_receive.py','-q'],
    [sys.executable,'-m','ruff','check',*names[:3]],['git','diff','--check']]
results=[]
for i,command in enumerate(commands):
    job=subprocess.run(command,cwd=root,env=env,capture_output=True,timeout=120)
    (out/f'command-{i}.stdout').write_bytes(job.stdout)
    (out/f'command-{i}.stderr').write_bytes(job.stderr)
    results.append({'command':command,'exit_code':job.returncode})
after=hashes()
record={'source_before':before,'source_after':after,'source_unchanged':before==after,'commands':results}
(out/'execution.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record,indent=2))
if before!=after or any(x['exit_code'] for x in results):raise SystemExit(1)
