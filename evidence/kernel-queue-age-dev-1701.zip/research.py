import hashlib
import json
import urllib.request
from pathlib import Path

base=Path(__file__).parent
out=base/'sources-v1'
out.mkdir(exist_ok=False)
record={'scope':'read-only clock API/source; no new numerical estimator',
        'versions':['CPython v3.12.3','Linux v6.6','existing KernelRX installed-header ABI'],
        'licenses':['Python PSF','Linux GPL2 family/UAPI exception'],
        'maintenance':'official current3.12 docs; fixed source support/installed patch equivalence unproven',
        'choice':'reuse int clock brackets + exactRX only; reject NS fallback/midpoint/callback-as-generation/TTL increase',
        'resources':'bounded32768anchors/8192assessments; no package/native compile/simulation/model',
        'clock_model_qualified':False,'urls':['https://docs.python.org/3.12/library/time.html',
            'https://man7.org/linux/man-pages/man2/clock_gettime.2.html'], 'sources':[]}
for name,url in [('pytime.c','https://raw.githubusercontent.com/python/cpython/v3.12.3/Python/pytime.c'),
                 ('timekeeping.c','https://raw.githubusercontent.com/torvalds/linux/v6.6/kernel/time/timekeeping.c')]:
    row={'name':name,'url':url}
    try:
        with urllib.request.urlopen(url,timeout=15) as stream:
            raw=stream.read(1_000_001)
        if len(raw)>1_000_000:raise ValueError('source bound')
        (out/name).write_bytes(raw)
        row.update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),status='downloaded')
    except Exception as error:
        row.update(status='failed',error=repr(error))
    record['sources'].append(row)
with (base/'research.json').open('x') as stream:json.dump(record,stream,indent=2)
print(json.dumps(record,indent=2))
