#include "causal_trace.h"

#include <cassert>
#include <cstdlib>
#include <string>

int main()
{
  assert(fly_ego_diag::sha256("abc", 3) ==
         "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
  assert(fly_ego_diag::jsonEscape("a\"b\\c\n") == "a\\\"b\\\\c\\u000a");
  assert(!fly_ego_diag::enabled());
  assert(!fly_ego_diag::emit("noop", {}));
  setenv("FLYD_EGO_TRACE_PATH", "/tmp/fly-ego-diag-test", 1);
  setenv("FLYD_EGO_SESSION_ID", "bad/session", 1);
  assert(!fly_ego_diag::emit("noop", {}));
  setenv("FLYD_EGO_SESSION_ID", "session_1", 1);
  setenv("FLYD_EGO_TRACE_PATH", "/proc/fly-ego-diag-unwritable", 1);
  assert(!fly_ego_diag::emit("io_refusal", {}));
  setenv("FLYD_EGO_TRACE_PATH", "/tmp/fly-ego-diag-test", 1);
  assert(fly_ego_diag::emit("first", {{"image", "a\"b"}}));
  assert(fly_ego_diag::emit("second", {{"revision", "2"}}));
  return 0;
}
