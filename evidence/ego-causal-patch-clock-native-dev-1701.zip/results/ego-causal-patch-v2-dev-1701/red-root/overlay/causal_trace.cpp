// SPDX-License-Identifier: GPL-3.0-only
#include "plan_env/causal_trace.h"

#include <openssl/sha.h>
#include <sys/file.h>
#include <fcntl.h>
#include <unistd.h>

#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <mutex>
#include <sstream>
#include <string>

namespace fly_ego_diag {

bool enabled()
{
  const char *path = std::getenv("FLYD_EGO_TRACE_PATH");
  const char *session = std::getenv("FLYD_EGO_SESSION_ID");
  return path && session && path[0] == '/' && session[0] != '\0';
}

std::string sha256(const void *bytes, size_t length)
{
  unsigned char digest[SHA256_DIGEST_LENGTH];
  SHA256(static_cast<const unsigned char *>(bytes), length, digest);
  std::ostringstream out;
  out << std::hex << std::setfill('0');
  for (unsigned char value : digest)
    out << std::setw(2) << static_cast<unsigned int>(value);
  return out.str();
}

std::string jsonEscape(const std::string &value)
{
  std::ostringstream out;
  for (unsigned char ch : value)
  {
    if (ch == '"' || ch == '\\')
      out << '\\' << ch;
    else if (ch >= 0x20 && ch < 0x7f)
      out << ch;
    else
      out << "\\u00" << std::hex << std::setfill('0') << std::setw(2)
          << static_cast<unsigned int>(ch) << std::dec;
  }
  return out.str();
}

bool emit(const std::string &event,
          const std::vector<std::pair<std::string, std::string>> &fields)
{
  if (!enabled())
    return false;
  const std::string path_prefix(std::getenv("FLYD_EGO_TRACE_PATH"));
  const std::string session_id(std::getenv("FLYD_EGO_SESSION_ID"));
  if (session_id.size() > 64 || path_prefix.size() > 4096 ||
      path_prefix.find('\n') != std::string::npos)
    return false;
  for (unsigned char ch : session_id)
    if (!((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') ||
          (ch >= '0' && ch <= '9') || ch == '_' || ch == '-'))
      return false;
  static std::mutex mutex;
  static uint64_t sequence = 0;
  std::lock_guard<std::mutex> lock(mutex);
  try
  {
    std::ostringstream line;
    line << "{\"schema\":1,\"session\":\"" << jsonEscape(session_id)
         << "\",\"pid\":" << getpid() << ",\"sequence\":" << sequence + 1
         << ",\"event\":\"" << jsonEscape(event) << '"';
    for (const auto &field : fields)
      line << ",\"" << jsonEscape(field.first) << "\":\""
           << jsonEscape(field.second) << '"';
    line << "}\n";
    const std::string data = line.str();
    const std::string path = path_prefix + "." + std::to_string(getpid()) + ".jsonl";
    const int fd = open(path.c_str(), O_WRONLY | O_APPEND | O_CREAT | O_CLOEXEC, 0600);
    if (fd < 0)
      return false;
    bool complete = flock(fd, LOCK_EX) == 0;
    size_t written = 0;
    while (complete && written < data.size())
    {
      const ssize_t count = write(fd, data.data() + written, data.size() - written);
      if (count <= 0)
        complete = false;
      else
        written += static_cast<size_t>(count);
    }
    if (complete)
      ++sequence;
    if (flock(fd, LOCK_UN) != 0)
      complete = false;
    if (close(fd) != 0)
      complete = false;
    return complete;
  }
  catch (...)
  {
    return false;
  }
}

}  // namespace fly_ego_diag
