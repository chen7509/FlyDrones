// SPDX-License-Identifier: GPL-3.0-only
#ifndef FLY_EGO_CAUSAL_TRACE_H
#define FLY_EGO_CAUSAL_TRACE_H

// Development-only, read-only evidence. Missing records never qualify a teacher.
#include <cstddef>
#include <iomanip>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

namespace fly_ego_diag {

bool enabled();
std::string sha256(const void *bytes, size_t length);
std::string jsonEscape(const std::string &value);
bool emit(const std::string &event,
          const std::vector<std::pair<std::string, std::string>> &fields);

template <typename Value>
inline std::string decimal(const Value &value)
{
  std::ostringstream out;
  out << std::setprecision(17) << value;
  return out.str();
}

}  // namespace fly_ego_diag

#endif
