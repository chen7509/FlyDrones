"""Seal the v2 standalone native writer RED/GREEN evidence."""

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).resolve().parent
OUT = ROOT / "evidence/ego-causal-patch-clock-native-dev-1701.zip"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    assert not OUT.exists(), "do not replace sealed evidence"
    patch_manifest = json.loads((STAGE / "patch-manifest.json").read_text(encoding="utf-8"))
    assert patch_manifest["patch_sha256"] == sha256(
        (ROOT / "tools/benchmark/ego_causal_readonly_v2.patch").read_bytes())
    red = (STAGE / "red-native.txt").read_text(encoding="utf-8", errors="replace")
    green = (STAGE / "native-tests.txt").read_text(encoding="utf-8", errors="replace")
    assert "exit_code=7" in red and "exit_code=0" in green
    rows = [json.loads(line) for line in (STAGE / "shared-journal.jsonl").read_text(
        encoding="utf-8").splitlines()]
    assert [row["sequence"] for row in rows] == [1, 2]
    assert len({(row["pid"], row["session"]) for row in rows}) == 1
    assert all(type(row["event_steady_ns"]) is int and row["event_steady_ns"] > 0
               for row in rows)
    assert rows[1]["event_steady_ns"] >= rows[0]["event_steady_ns"]
    paths = [
        ROOT / "docs/EGO_CAUSAL_PATCH_NATIVE_TEST_REPORT.md",
        ROOT / "tools/benchmark/ego_causal_readonly_v2.patch",
        STAGE / "patch-manifest.json",
        STAGE / "red-native.txt",
        STAGE / "native-tests.txt",
        STAGE / "shared-journal.jsonl",
        STAGE / "run_native_tests.sh",
        STAGE / "causal_trace_core_test.cpp",
        STAGE / "shared_client.cpp",
        STAGE / "writer_a.cpp",
        STAGE / "writer_b.cpp",
        STAGE / "libfly_ego_trace.so",
        STAGE / "causal_trace_core_test",
        STAGE / "shared_client",
        STAGE / "writer_a.so",
        STAGE / "writer_b.so",
        STAGE / "red-root/overlay/causal_trace.cpp",
        STAGE / "red-root/overlay/causal_trace.h",
        Path(__file__),
    ]
    members = {}
    for path in paths:
        assert path.is_file(), path
        data = path.read_bytes()
        members[path.relative_to(ROOT).as_posix()] = {
            "sha256": sha256(data), "size": len(data)}
    manifest = {
        "schema": 1, "study": "ego-causal-clock-v2-native-writer-addendum",
        "members": members,
        "predecessor_static_zip_sha256": sha256(
            (ROOT / "evidence/ego-causal-patch-clock-dev-1701.zip").read_bytes()),
        "standalone_native_writer_verified": True,
        "patched_ros_build_verified": False,
        "trajectory_numerical_parity_verified": False,
        "teacher_qualified": False,
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(OUT, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in paths:
            archive.write(path, path.relative_to(ROOT).as_posix())
        archive.writestr("manifest.json", json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    with zipfile.ZipFile(OUT) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == set(members) | {"manifest.json"}
        for name, identity in members.items():
            data = archive.read(name)
            assert len(data) == identity["size"] and sha256(data) == identity["sha256"]
    print(json.dumps({"members": len(members) + 1, "sha256": sha256(OUT.read_bytes()),
                      "path": str(OUT)}, sort_keys=True))


if __name__ == "__main__":
    main()
