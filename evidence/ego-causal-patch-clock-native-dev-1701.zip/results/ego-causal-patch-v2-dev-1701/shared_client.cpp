#include <dlfcn.h>
#include <unistd.h>

#include <cstdlib>
#include <fstream>
#include <iostream>
#include <string>

int main(int argc, char **argv)
{
  if (argc != 3)
    return 2;
  const std::string prefix = "/tmp/fly-ego-shared-trace-" + std::to_string(getpid());
  setenv("FLYD_EGO_TRACE_PATH", prefix.c_str(), 1);
  setenv("FLYD_EGO_SESSION_ID", "single_session", 1);
  void *a = dlopen(argv[1], RTLD_NOW);
  void *b = dlopen(argv[2], RTLD_NOW);
  if (!a || !b)
    return 3;
  auto write_a = reinterpret_cast<bool (*)()>(dlsym(a, "write_a"));
  auto write_b = reinterpret_cast<bool (*)()>(dlsym(b, "write_b"));
  if (!write_a || !write_b || !write_a() || !write_b())
    return 4;
  std::ifstream input(prefix + "." + std::to_string(getpid()) + ".jsonl");
  std::string first, second, extra;
  if (!std::getline(input, first) || !std::getline(input, second) ||
      std::getline(input, extra))
    return 5;
  if (first.find("\"sequence\":1,\"event\":\"module_a\"") == std::string::npos ||
      second.find("\"sequence\":2,\"event\":\"module_b\"") == std::string::npos)
    return 6;
  const std::string marker = "\"event_steady_ns\":";
  const auto first_pos = first.find(marker);
  const auto second_pos = second.find(marker);
  if (first_pos == std::string::npos || second_pos == std::string::npos)
    return 7;
  const auto first_ns = std::stoull(first.substr(first_pos + marker.size()));
  const auto second_ns = std::stoull(second.substr(second_pos + marker.size()));
  if (first_ns == 0 || second_ns < first_ns)
    return 8;
  std::cout << "shared_sequence=1,2 journal=" << prefix << "." << getpid()
            << ".jsonl\n";
  return 0;
}
