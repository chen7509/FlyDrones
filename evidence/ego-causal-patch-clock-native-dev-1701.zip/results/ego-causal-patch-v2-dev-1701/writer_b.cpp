#include "plan_env/causal_trace.h"
extern "C" bool write_b()
{
  return fly_ego_diag::emit("module_b", {{"source", "fsm"}});
}
