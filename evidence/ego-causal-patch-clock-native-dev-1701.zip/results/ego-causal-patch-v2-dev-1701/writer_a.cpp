#include "plan_env/causal_trace.h"
extern "C" bool write_a()
{
  return fly_ego_diag::emit("module_a", {{"source", "map"}});
}
