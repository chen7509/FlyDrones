#!/usr/bin/env bash
set -euo pipefail
root=$1
printf 'compiler=%s\n' "$(g++ -dumpfullversion)"
printf 'openssl=%s\n' "$(pkg-config --modversion openssl)"
g++ -std=c++17 -Wall -Wextra -Werror -I "$root/overlay" \
  "$root/causal_trace_core_test.cpp" "$root/overlay/causal_trace.cpp" \
  -lcrypto -o "$root/causal_trace_core_test"
env -u FLYD_EGO_TRACE_PATH -u FLYD_EGO_SESSION_ID "$root/causal_trace_core_test"
g++ -std=c++17 -Wall -Wextra -Werror -fPIC -shared -I "$root/overlay" \
  "$root/overlay/causal_trace.cpp" -lcrypto -o "$root/libfly_ego_trace.so"
g++ -std=c++17 -Wall -Wextra -Werror -fPIC -shared -I "$root/overlay" \
  "$root/writer_a.cpp" -L "$root" -lfly_ego_trace -o "$root/writer_a.so"
g++ -std=c++17 -Wall -Wextra -Werror -fPIC -shared -I "$root/overlay" \
  "$root/writer_b.cpp" -L "$root" -lfly_ego_trace -o "$root/writer_b.so"
g++ -std=c++17 -Wall -Wextra -Werror "$root/shared_client.cpp" \
  -ldl -o "$root/shared_client"
LD_LIBRARY_PATH="$root" "$root/shared_client" "$root/writer_a.so" "$root/writer_b.so"
sha256sum "$root/libfly_ego_trace.so" "$root/causal_trace_core_test" \
  "$root/shared_client"
