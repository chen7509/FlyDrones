#!/usr/bin/env bash
set -euo pipefail

source_root=$1
stage_root=$2
patch_file=$3
scratch=$(mktemp -d /tmp/fly-ego-causal-patch.XXXXXX)

paths=(
  src/planner/plan_env/CMakeLists.txt
  src/planner/plan_env/package.xml
  src/planner/plan_env/include/plan_env/grid_map.h
  src/planner/plan_env/src/grid_map.cpp
  src/planner/plan_manage/CMakeLists.txt
  src/planner/plan_manage/include/ego_planner/ego_replan_fsm.h
  src/planner/plan_manage/src/ego_replan_fsm.cpp
  src/planner/plan_manage/src/traj_server.cpp
)
names=(
  plan_env.CMakeLists.txt plan_env.package.xml grid_map.h grid_map.cpp
  plan_manage.CMakeLists.txt ego_replan_fsm.h ego_replan_fsm.cpp
  traj_server.cpp
)
for i in "${!paths[@]}"; do
  mkdir -p "$scratch/$(dirname "${paths[$i]}")"
  cp -p "$source_root/${paths[$i]}" "$scratch/${paths[$i]}"
done
git -C "$scratch" apply --check "$patch_file"
git -C "$scratch" apply "$patch_file"
for i in "${!paths[@]}"; do
  cmp "$scratch/${paths[$i]}" "$stage_root/overlay/${names[$i]}"
done
cmp "$scratch/src/planner/plan_env/include/plan_env/causal_trace.h" \
  "$stage_root/overlay/causal_trace.h"
cmp "$scratch/src/planner/plan_env/src/causal_trace.cpp" \
  "$stage_root/overlay/causal_trace.cpp"
printf 'static_patch_applied=1 matched_files=10 scratch=%s\n' "$scratch"
