"""Seal the static EGO patch candidate with exact member digests."""

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).resolve().parent
OUTPUT = ROOT / "evidence/ego-causal-patch-candidate-dev-1701.zip"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    assert not OUTPUT.exists(), "evidence is immutable; use a new versioned name"
    pinned = json.loads((STAGE / "patch-manifest.json").read_text(encoding="utf-8"))
    patch_path = ROOT / "tools/benchmark/ego_causal_readonly.patch"
    assert digest(patch_path.read_bytes()) == pinned["patch_sha256"]
    assert pinned["patched_ros_build_verified"] is False
    assert pinned["trajectory_numerical_parity_verified"] is False
    assert pinned["teacher_qualified"] is False
    shared_rows = [json.loads(line) for line in (STAGE / "shared-journal-v2.jsonl").read_text(
        encoding="utf-8").splitlines()]
    assert [row["sequence"] for row in shared_rows] == [1, 2]
    assert len({(row["pid"], row["session"]) for row in shared_rows}) == 1

    paths = [
        patch_path,
        ROOT / "docs/EGO_CAUSAL_PATCH_CANDIDATE_REPORT.md",
        STAGE / "patch-manifest.json",
        STAGE / "dependency-research.json",
        STAGE / "build_patch.py",
        STAGE / "verify_patch_apply.sh",
        STAGE / "static-apply.txt",
        STAGE / "static-apply-v2.txt",
        STAGE / "native-tests.txt",
        STAGE / "native-tests-v2.txt",
        STAGE / "shared-journal.jsonl",
        STAGE / "shared-journal-v2.jsonl",
        STAGE / "causal_trace_core_test.cpp",
        STAGE / "run_native_tests.sh",
        STAGE / "shared_client.cpp",
        STAGE / "writer_a.cpp",
        STAGE / "writer_b.cpp",
        Path(__file__),
    ]
    paths += sorted(path for folder in ("upstream", "overlay") for path in
                    (STAGE / folder).iterdir() if path.is_file())
    assert len(paths) == len(set(paths))
    members = {}
    for path in paths:
        assert path.is_file(), path
        relative = path.relative_to(ROOT).as_posix()
        data = path.read_bytes()
        members[relative] = {"sha256": digest(data), "size": len(data)}
    manifest = {"schema": 1, "study": "ego-causal-readonly-static-candidate-v1",
                "members": members, "teacher_qualified": False,
                "patched_ros_build_verified": False,
                "trajectory_numerical_parity_verified": False}
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(OUTPUT, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in paths:
            archive.write(path, path.relative_to(ROOT).as_posix())
        archive.writestr("manifest.json", json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    with zipfile.ZipFile(OUTPUT) as archive:
        bad = archive.testzip()
        assert bad is None, bad
        assert set(archive.namelist()) == set(members) | {"manifest.json"}
        for name, info in members.items():
            data = archive.read(name)
            assert len(data) == info["size"] and digest(data) == info["sha256"], name
    print(json.dumps({"path": str(OUTPUT), "sha256": digest(OUTPUT.read_bytes()),
                      "members": len(members) + 1}, sort_keys=True))


if __name__ == "__main__":
    main()
