"""Bind every downloaded source blob to its path in the fixed commit tree."""

import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT / "source-manifest.json").read_text(encoding="utf-8"))
commit_sha = manifest["commit"]
repo = "ZJU-FAST-Lab/ego-planner-swarm"


def api(path: str) -> dict:
    return json.loads(subprocess.check_output(["gh", "api", f"repos/{repo}/{path}"]))


commit = api(f"git/commits/{commit_sha}")
if commit.get("sha") != commit_sha:
    raise ValueError("commit identity mismatch")
tree_sha = commit["tree"]["sha"]
tree = api(f"git/trees/{tree_sha}?recursive=1")
if tree.get("sha") != tree_sha or tree.get("truncated") is not False:
    raise ValueError("upstream tree is incomplete or changed")
by_path = {row["path"]: row for row in tree["tree"]}
files = {}
for name, entry in manifest["files"].items():
    path = entry["upstream_path"]
    row = by_path.get(path)
    if row is None or row.get("type") != "blob" or row.get("sha") != entry["git_blob_sha1"]:
        raise ValueError(f"commit does not bind path to expected blob: {path}")
    files[name] = {"upstream_path": path, "git_blob_sha1": row["sha"]}

result = {"repository": manifest["repository"], "commit": commit_sha,
          "tree_sha1": tree_sha, "tree_truncated": False, "files": files}
(ROOT / "commit-tree-binding.json").write_text(
    json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8",
)
print(json.dumps({"bound_files": len(files), "commit": commit_sha,
                  "tree_sha1": tree_sha}, sort_keys=True))
