"""Verify the pinned source snapshot and its narrow causal-path observations."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT / "source-manifest.json").read_text(encoding="utf-8"))
binding = json.loads((ROOT / "commit-tree-binding.json").read_text(encoding="utf-8"))
if manifest["commit"] != "23a8d5a191711dd65633df689bd00f55d4dea8f9":
    raise ValueError("upstream commit changed")
if (binding["commit"] != manifest["commit"] or binding["tree_truncated"]
        or set(binding["files"]) != set(manifest["files"])):
    raise ValueError("commit tree binding incomplete")
lines = {}
for name, entry in manifest["files"].items():
    if (binding["files"][name]["upstream_path"] != entry["upstream_path"]
            or binding["files"][name]["git_blob_sha1"] != entry["git_blob_sha1"]):
        raise ValueError(f"commit path does not bind blob: {name}")
    data = (ROOT / "source" / name).read_bytes()
    if len(data) != entry["bytes"] or hashlib.sha256(data).hexdigest() != entry["sha256"]:
        raise ValueError(f"source snapshot mismatch: {name}")
    lines[name] = data.decode("utf-8").splitlines()


def span(name: str, first: int, last: int, required: tuple[str, ...]) -> dict:
    selected = lines[name][first - 1:last]
    text = "\n".join(selected)
    if not all(token in text for token in required):
        raise ValueError(f"source anchor mismatch: {name}:{first}-{last}")
    return {"file": name, "first_line": first, "last_line": last,
            "source_sha256": manifest["files"][name]["sha256"]}


odom = span("ego_replan_fsm.cpp", 249, 267,
            ("odometryCallback", "odom_vel_", "have_odom_ = true"))
image = span("grid_map.cpp", 758, 792,
             ("depthPoseCallback", "md_.depth_image_", "md_.occ_need_update_ = true"))
image_odom = span("grid_map.cpp", 1045, 1078,
                  ("depthOdomCallback", "md_.depth_image_", "md_.occ_need_update_ = true"))
map_update = span("grid_map.cpp", 709, 756,
                  ("updateOccupancyCallback", "projectDepthImage()", "md_.occ_need_update_ = false"))
plan = span("ego_replan_fsm.cpp", 783, 830,
            ("callReboundReplan", "bspline.start_time", "bspline.traj_id", "bspline_pub_->publish"))
server = span("traj_server.cpp", 27, 68,
              ("bsplineCallback", "start_time_ = msg->start_time", "traj_id_ = msg->traj_id"))
command = span("traj_server.cpp", 163, 231,
               ("rclcpp::Clock clock(RCL_ROS_TIME)", "cmd.header.stamp = time_now",
                "cmd.trajectory_id = traj_id_", "pos_cmd_pub->publish(cmd)"))
bspline_fields = (ROOT / "source/Bspline.msg").read_text(encoding="utf-8")
command_fields = (ROOT / "source/PositionCommand.msg").read_text(encoding="utf-8")
for field in ("traj_id", "start_time"):
    if field not in bspline_fields:
        raise ValueError("Bspline plan identity missing")
for field in ("trajectory_id", "header"):
    if field not in command_fields:
        raise ValueError("PositionCommand identity missing")
if ("int64 traj_id" not in bspline_fields
        or "int traj_id_;" not in "\n".join(lines["traj_server.cpp"])
        or "uint32 trajectory_id" not in command_fields):
    raise ValueError("trajectory identifier width changed")
if "header.stamp" in "\n".join(lines["ego_replan_fsm.cpp"][248:267]):
    raise ValueError("odometry callback now reads an input stamp")
if "header.stamp" in "\n".join(lines["grid_map.cpp"][757:792]):
    raise ValueError("image callback now reads an input stamp")
if "header.stamp" in "\n".join(lines["grid_map.cpp"][1044:1078]):
    raise ValueError("image/odometry callback now reads an input stamp")
for absent in ("observation_id", "input_sequence", "depth_frame_id", "map_revision"):
    if absent in bspline_fields or absent in command_fields:
        raise ValueError("message now has an input identity; re-audit required")

result = {
    "source_commit": manifest["commit"],
    "source_tree_sha1": binding["tree_sha1"],
    "commit_path_binding_verified": True,
    "read_only_source_path_audit": True,
    "spans": [odom, image, image_odom, map_update, plan, server, command],
    "bspline_has_plan_id": True,
    "position_command_has_plan_id": True,
    "plan_id_types": {"bspline": "int64", "traj_server_storage": "int",
                      "position_command": "uint32"},
    "lossless_plan_id_match_qualified": False,
    "inspected_messages_have_input_identity": False,
    "inspected_odom_callback_reads_input_stamp": False,
    "inspected_image_callback_reads_input_stamp": False,
    "same_observation_causality_proven": False,
    "limits": [
        "Static inspection of pinned relevant paths; not a runtime trace or proof of all code paths",
        "Command trajectory ID does not identify the odometry/image/map state consumed by planning",
        "int64 to int to uint32 trajectory IDs need bounded positive and session-unique runtime checks",
        "No EGO, PX4, Gazebo, training or fair-comparison run was performed",
    ],
}
(ROOT / "causal-path-audit.json").write_text(
    json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8",
)
print(json.dumps({"spans": len(result["spans"]),
                  "same_observation_causality_proven": False}, sort_keys=True))
