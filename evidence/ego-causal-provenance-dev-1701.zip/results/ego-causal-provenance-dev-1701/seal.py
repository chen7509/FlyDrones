"""Seal the fixed, read-only EGO provenance audit and verify every member."""

import hashlib
import json
import zipfile
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "evidence/ego-causal-provenance-dev-1701.zip"
STAGE = "results/ego-causal-provenance-dev-1701"
FILES = [
    "docs/EGO_CAUSAL_PROVENANCE_AUDIT_REPORT.md",
    "docs/superpowers/specs/2026-10-10-ego-causal-provenance-design.md",
    "docs/superpowers/plans/2026-10-10-ego-causal-provenance.md",
    *[f"{STAGE}/source/{name}" for name in (
        "ego_replan_fsm.cpp", "grid_map.cpp", "traj_server.cpp",
        "Bspline.msg", "PositionCommand.msg", "LICENSE")],
    *[f"{STAGE}/{name}" for name in (
        "source-manifest.json", "commit-tree-binding.json", "causal-path-audit.json",
        "license-provenance.json", "upstream-metadata.json", "fetch_pinned_sources.py",
        "verify_commit_tree.py", "audit_snapshot.py", "seal.py", "fetch-output.txt",
        "commit-tree-output.txt", "audit-output-final.txt", "ruff-final.txt",
        "diff-check.txt", "review.txt")],
]


def main() -> None:
    if OUT.exists():
        raise FileExistsError(OUT)
    entries = {}
    with zipfile.ZipFile(OUT, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for relative in FILES:
            data = (ROOT / relative).read_bytes()
            archive.writestr(relative, data)
            entries[relative] = {
                "bytes": len(data),
                "sha256": hashlib.sha256(data).hexdigest(),
                "crc32": format(zlib.crc32(data) & 0xFFFFFFFF, "08x"),
            }
        archive.writestr("MANIFEST.json", json.dumps(entries, indent=2, sort_keys=True))
    with zipfile.ZipFile(OUT) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == set(FILES) | {"MANIFEST.json"}
        for relative, expected in entries.items():
            data = archive.read(relative)
            assert len(data) == expected["bytes"]
            assert hashlib.sha256(data).hexdigest() == expected["sha256"]
            assert format(zlib.crc32(data) & 0xFFFFFFFF, "08x") == expected["crc32"]
    print(json.dumps({"zip": str(OUT), "members": len(entries) + 1,
                      "sha256": hashlib.sha256(OUT.read_bytes()).hexdigest()}, sort_keys=True))


if __name__ == "__main__":
    main()
