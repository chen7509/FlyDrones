"""Read-only, byte-verified source snapshot for the fixed EGO causal audit."""

import base64
import hashlib
import json
import subprocess
from pathlib import Path

COMMIT = "23a8d5a191711dd65633df689bd00f55d4dea8f9"
REPO = "ZJU-FAST-Lab/ego-planner-swarm"
SOURCES = {
    "ego_replan_fsm.cpp": (
        "src/planner/plan_manage/src/ego_replan_fsm.cpp",
        "78d5eee7e504fa3425e71404e40d207a3bb9011b",
        "3d28a838ebd2e3649b2dcc8c8d9ae1208ba5419cdd142fd04775f184c289bacf",
    ),
    "traj_server.cpp": (
        "src/planner/plan_manage/src/traj_server.cpp",
        "a32026d49de945c502b372e39301078eea58fbeb",
        "744779688d7a27358b4031645e6bffce292d121ce871467f545e955866c17132",
    ),
    "grid_map.cpp": (
        "src/planner/plan_env/src/grid_map.cpp",
        "0714c57e976fcefcad7fd058c842c12fd2955aec",
        "b9715e1d24afe14f04273b56d0fb4e7969e4d5ee674bfe8c76520befd8f69d04",
    ),
    "Bspline.msg": (
        "src/planner/traj_utils/msg/Bspline.msg",
        "d6aaff92248f9d2a35fb81582f524f3f4c3bee03", None,
    ),
    "PositionCommand.msg": (
        "src/uav_simulator/Utils/quadrotor_msgs/msg/PositionCommand.msg",
        "a70bccfd91a5bae8b5fd507c13ca793aa07b46d7", None,
    ),
}


def main() -> None:
    root = Path(__file__).resolve().parent
    source_dir = root / "source"
    source_dir.mkdir(exist_ok=False)
    records = {}
    for name, (path, blob_sha, expected_sha256) in SOURCES.items():
        response = json.loads(subprocess.check_output([
            "gh", "api", f"repos/{REPO}/git/blobs/{blob_sha}",
        ]))
        if response.get("sha") != blob_sha or response.get("encoding") != "base64":
            raise ValueError(f"unexpected GitHub blob identity for {path}")
        raw = base64.b64decode(response["content"], validate=False)
        actual_blob_sha = hashlib.sha1(
            f"blob {len(raw)}\0".encode() + raw,
        ).hexdigest()
        sha256 = hashlib.sha256(raw).hexdigest()
        if actual_blob_sha != blob_sha or (expected_sha256 and sha256 != expected_sha256):
            raise ValueError(f"source bytes changed for {path}")
        (source_dir / name).write_bytes(raw)
        records[name] = {
            "upstream_path": path,
            "git_blob_sha1": blob_sha,
            "sha256": sha256,
            "bytes": len(raw),
            "lines": len(raw.decode("utf-8").splitlines()),
        }
    output = {"repository": f"https://github.com/{REPO}", "commit": COMMIT,
              "files": records, "read_only_upstream": True,
              "physical_or_planner_run": False}
    (root / "source-manifest.json").write_text(
        json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8",
    )
    print(json.dumps({"files": len(records), "commit": COMMIT}, sort_keys=True))


if __name__ == "__main__":
    main()
