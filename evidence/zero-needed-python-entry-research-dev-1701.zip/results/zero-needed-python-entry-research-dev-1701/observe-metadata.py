import datetime
import hashlib
import json
import os
import selectors
import subprocess
import sys
import time
from pathlib import Path

out = Path(__file__).resolve().parent
target = '/usr/lib/python3.12/lib-dynload/_json.cpython-312-x86_64-linux-gnu.so'
tool = '/usr/bin/readelf'
expected = {target: 'ca8e35c58f7bc8e27258c4af43651c941413bc6318903621253485b0395758a3', tool: '871be389739ecf9924b052c2fde4d2a2068a54e882201b9c34897337a5a0a130', '/usr/bin/ldd': '752803b8baa217b821bd4566c4fbdaec50c01cb32d2796ec056d22d190d4290f'}
env = {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8'}
def write(name, data):
    with (out / name).open('xb') as f:
        f.write(json.dumps(data, indent=2).encode()); f.flush()
def identity(name):
    p = Path(name); resolved = p.resolve(strict=True); a = p.stat(); b = resolved.read_bytes(); c = p.stat()
    assert a == c
    fields = lambda s: dict(dev=s.st_dev, inode=s.st_ino, mode=s.st_mode, size=s.st_size, mtime_ns=s.st_mtime_ns, ctime_ns=s.st_ctime_ns)
    return dict(requested=name, resolved=str(resolved), requested_lstat=fields(p.lstat()), stat=fields(a), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
def run(name, argv, seconds):
    row = dict(argv=argv, env=env, utc_start=datetime.datetime.now(datetime.UTC).isoformat(), monotonic_start_ns=time.monotonic_ns(), stdout_hex='', stderr_hex='', pid=None, error=None, cap_exceeded=False, timed_out=False)
    p = None; streams = {0:bytearray(), 1:bytearray()}
    try:
        p = subprocess.Popen(argv, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        row['pid'] = p.pid
        sel = selectors.DefaultSelector()
        for index, stream in enumerate([p.stdout, p.stderr]):
            os.set_blocking(stream.fileno(), False); sel.register(stream, selectors.EVENT_READ, index)
        deadline = time.monotonic() + seconds
        while sel.get_map():
            if time.monotonic() >= deadline:
                row['timed_out'] = True; raise TimeoutError('metadata deadline')
            for key, _ in sel.select(min(0.1, max(0, deadline-time.monotonic()))):
                data = os.read(key.fileobj.fileno(), min(65536, 2*1024*1024-len(streams[key.data])+1))
                if not data: sel.unregister(key.fileobj); continue
                remaining = 2*1024*1024-len(streams[key.data])
                streams[key.data].extend(data[:remaining])
                if len(data) > remaining:
                    row['cap_exceeded'] = True; raise RuntimeError('hard stream cap')
        row['exit'] = p.wait(timeout=max(0.001, deadline-time.monotonic()))
    except BaseException as exc:
        row['error'] = repr(exc)
    finally:
        if p is not None:
            if p.poll() is None: p.kill()
            try: row['exit'] = p.wait(timeout=2)
            except Exception as exc: row['cleanup_error'] = repr(exc)
            row['own_popen_exited'] = p.poll() is not None
            for s in [p.stdout, p.stderr]:
                if s: s.close()
        row.update(stdout_hex=streams[0].hex(), stderr_hex=streams[1].hex(), utc_end=datetime.datetime.now(datetime.UTC).isoformat(), monotonic_end_ns=time.monotonic_ns(), escaped_descendants='unknown')
        row['elapsed_ns'] = row['monotonic_end_ns']-row['monotonic_start_ns']
        write(name+'.json', row)
    assert row['error'] is None and row['exit'] == 0
    return row

start = time.monotonic_ns(); before = {}; error = None
try:
    for name in [*expected, sys.executable]:
        before[name] = identity(name)
        if name in expected: assert before[name]['sha256'] == expected[name]
    write('metadata-before.json', dict(files=before, python_version=sys.version, utc=datetime.datetime.now(datetime.UTC).isoformat(), monotonic_ns=start))
    with (out/'installed-ldd-script.txt').open('xb') as f: f.write(Path('/usr/bin/ldd').read_bytes())
    run('readelf-version', [tool, '--version'], 2)
    run('elf-file-facts', [tool, '-W', '-h', '-l', '--dyn-syms', target], 10)
except BaseException as exc:
    error = repr(exc)
finally:
    after = {name:identity(name) for name in before}
    write('metadata-after.json', dict(files=after, equal=after==before, error=error, elapsed_ns=time.monotonic_ns()-start, utc=datetime.datetime.now(datetime.UTC).isoformat(), target_loaded_by_observer=False, no_ldd_executed=True))
assert error is None and after == before
