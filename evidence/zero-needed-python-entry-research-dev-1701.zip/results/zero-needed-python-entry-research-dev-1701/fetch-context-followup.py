import hashlib
import json
import urllib.request
from pathlib import Path

out=Path('results/zero-needed-python-entry-research-dev-1701')
package=out/'upstream/python__cpython'
tree=json.loads((package/'official-tree.json').read_bytes())
commit=json.loads((out/'primary-fetch-python__cpython.json').read_bytes())['commit']
rows=[]
for name in ['Lib/json/__init__.py','Lib/json/decoder.py','Lib/json/encoder.py','Lib/json/scanner.py','Include/internal/pycore_interp_init.h']:
    e=next(x for x in tree['tree'] if x['path']==name)
    url='https://raw.githubusercontent.com/python/cpython/'+commit+'/'+name
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'FlyDrones-context-followup'}),timeout=20) as r:b=r.read(1024*1024)
    blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
    assert len(b)==e['size'] and blob==e['sha']
    p=package/name;p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(b)
    rows.append(dict(path=name,url=url,git_blob=blob,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
with (out/'primary-context-followup.json').open('xb') as f:f.write(json.dumps(rows,indent=2).encode())
print(json.dumps(dict(files=len(rows),commit=commit)))
