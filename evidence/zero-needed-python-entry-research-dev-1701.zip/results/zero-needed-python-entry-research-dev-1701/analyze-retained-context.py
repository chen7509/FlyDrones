import difflib
import hashlib
import json
import re
from pathlib import Path

root=Path.cwd();out=root/'results/zero-needed-python-entry-research-dev-1701'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,d):
    with (out/name).open('xb') as f:f.write(json.dumps(d,indent=2).encode())
cp=out/'upstream/python__cpython';tree=json.loads((cp/'official-tree.json').read_bytes())
rows=[]
for name in ['Lib/json/__init__.py','Lib/json/decoder.py','Lib/json/encoder.py','Lib/json/scanner.py']:
    b=(cp/name).read_bytes();e=next(x for x in tree['tree'] if x['path']==name)
    blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
    assert len(b)==e['size'] and blob==e['sha']
    rows.append(dict(path=name,bytes=len(b),git_blob=blob,sha256=sha(b)))
assert not any(x['path']=='Include/internal/pycore_interp_init.h' for x in tree['tree'])
write('primary-context-followup-retained-audit.json',dict(files=rows,first_helper_failure='StopIteration after four successful source files, fifth requested Include/internal/pycore_interp_init.h absent in complete official tree; tool console only, not native observer failure; no helper or native rerun',unnecessary_missing_header_not_replaced=True))
d=json.loads((out/'elf-file-facts.json').read_bytes());s=bytes.fromhex(d['stdout_hex']).decode()
symbols=[]
for line in s.splitlines():
    fields=line.split()
    if fields and fields[0].endswith(':') and len(fields)>=8 and fields[0][:-1].isdigit():
        symbols.append(dict(index=int(fields[0][:-1]),value=fields[1],size=int(fields[2]),type=fields[3],bind=fields[4],visibility=fields[5],ndx=fields[6],name=fields[7]))
undef=[x for x in symbols if x['ndx']=='UND' and x['bind']!='LOCAL']
strong=[x for x in undef if x['bind']=='GLOBAL'];weak=[x for x in undef if x['bind']=='WEAK']
assert len(symbols)==69 and len(undef)==68 and len(strong)==64 and len(weak)==4
assert all(x['name'].startswith(('Py','_Py')) for x in strong)
before=json.loads((out/'metadata-before.json').read_bytes());after=json.loads((out/'metadata-after.json').read_bytes())
assert before['files']==after['files'] and after['equal'] is True
summary=dict(elf64=True,elf_type='ET_DYN',machine='EM_X86_64',entry_point=0,program_headers=11,PT_DYNAMIC=True,PT_INTERP=False,dynsym_entries_including_local_null=70,named_symbols=symbols,undefined_count=68,strong_undefined_python_api=64,weak_undefined=weak,exported_initializer='PyInit__json',direct_needed_from_retained_call57=[],readelf_exit=d['exit'],tool_file_identity_stable=True,python_version=before['python_version'],target_load_observation='UNKNOWN; json import attempted accelerator; original false flag superseded by OBSERVER_SCOPE_CORRECTION.md',runtime_symbol_resolution_proven=False,measured_calibration=False)
write('elf-context-analysis.json',summary)
source=(out/'upstream/bminor__glibc/elf/ldd.bash.in').read_text()
installed=(out/'installed-ldd-script.txt').read_text()
with (out/'ldd-template-versus-installed.diff').open('xb') as f:f.write(''.join(difflib.unified_diff(source.splitlines(True),installed.splitlines(True),fromfile='upstream-glibc2.39-ldd.bash.in',tofile='installed-matching-call58-ldd-script')).encode())
write('observer-scope-correction.json',dict(supersedes_path='metadata-after.json',supersedes_field='target_loaded_by_observer',original_value=False,corrected_value=None,reason='Linux observer imported stdlib json; pinned CPython json.decoder/scanner/encoder attempt _json accelerator; actual import origin/result/maps not contemporaneously recorded',native_import_attempt_scope_violated=True,actual_target_loaded='UNKNOWN',no_repeat_observer_or_probe=True,metadata_fields_not_promoted_to_runtime_acceptance=True))
print(json.dumps(dict(symbols=len(symbols),undefined=len(undef),strong=len(strong),weak=len(weak),observer_scope_violation=True)))
