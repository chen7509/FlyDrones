import datetime
import hashlib
import json
from pathlib import Path

root=Path.cwd();out=root/'results/zero-needed-python-entry-research-dev-1701'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,d):
    with (out/name).open('xb') as f:f.write(json.dumps(d,indent=2).encode())
sources=json.loads((out/'product-sources-before.json').read_bytes())
for row in sources:
    b=(root/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
write('product-sources-after.json',dict(utc=datetime.datetime.now(datetime.UTC).isoformat(),count=len(sources),all_equal=True,members=sources))
prior=[]
for p in sorted((root/'evidence').glob('*.zip')):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    prior.append(dict(path=p.relative_to(root).as_posix(),bytes=p.stat().st_size,sha256=h.hexdigest()))
assert len(prior)==285
old=json.loads((root/'results/target-bearing-static-v2-executor-dev-1701/historical-archives-before-seal.json').read_bytes())
if isinstance(old,dict):old=old.get('members',old.get('archives',old.get('files')))
assert isinstance(old,list)
current={r['path']:r for r in prior}
for row in old:
    assert row['sha256']==current[row['path']]['sha256'] and row['bytes']==current[row['path']]['bytes']
assert len(old)==284
write('historical-archives-before-seal.json',dict(utc=datetime.datetime.now(datetime.UTC).isoformat(),count=len(prior),bytes=sum(r['bytes'] for r in prior),all284_previous_equal=True,new_static_v2_unchanged=True,scope='POSTresearch audit, not pre-observation attestation',members=prior))
print(json.dumps(dict(source_count=len(sources),old_archives=len(prior),old_bytes=sum(r['bytes'] for r in prior))))
