import hashlib
import json
import zipfile
from pathlib import Path

root=Path.cwd();out=root/'results/zero-needed-python-entry-research-dev-1701'
review=json.loads((out/'independent-research-review.json').read_bytes())
assert review['counts'] in [dict(C=0,I=0,M=0),dict(critical=0,important=0,minor=0)]
sha=lambda b:hashlib.sha256(b).hexdigest()
for row in json.loads((out/'product-sources-before.json').read_bytes()):
    assert sha((root/row['path']).read_bytes())==row['sha256']
assert json.loads((out/'observer-scope-correction.json').read_bytes())['native_import_attempt_scope_violated'] is True
assert json.loads((out/'historical-archives-before-seal.json').read_bytes())['count']==285
excluded={out/'initial-resource-private.json',out/'archive-seal-receipt.json'}
paths=[p for p in out.rglob('*') if p.is_file() and p not in excluded and '__pycache__' not in p.parts and p.suffix!='.pyc']
prefix=root/'results/target-bearing-runtime-freeze-v2-dev-1701/frozen-study-v2/sdk/entry-dependencies'
paths += [prefix/f'query-{i:04d}.json' for i in range(1,59)]
paths += [prefix/'entry-bill.json',root/'results/target-bearing-runtime-freeze-v2-dev-1701/native-freeze-failure.json']
paths += [root/p for p in ['docs/TARGET_BEARING_ZERO_NEEDED_RESEARCH_REPORT.md','docs/TARGET_BEARING_STATIC_V2_ATTEMPT_REPORT.md','docs/superpowers/specs/2026-10-15-zero-needed-python-entry-research-design.md','docs/superpowers/plans/2026-10-15-zero-needed-python-entry-research.md','docs/superpowers/specs/2026-10-15-python-extension-context-production-design.md','docs/superpowers/plans/2026-10-15-python-extension-context-production.md','evidence/target-bearing-static-v2-attempt-publication.json','tools/benchmark/native_entry_dependencies.py','tools/benchmark/prepare_calibration_capture_v2.py','tools/benchmark/calibration_capture_study_v2.py','tools/benchmark/runtime_resource_binding.py','.superpowers/sdd/2026-10-15-zero-needed-python-entry-research/progress.md']]
paths=sorted(set(paths));records=[]
for p in paths:
    b=p.read_bytes();records.append(dict(path=p.relative_to(root).as_posix(),bytes=len(b),sha256=sha(b)))
private=out/'initial-resource-private.json';b=private.read_bytes()
manifest=root/'evidence/zero-needed-python-entry-research-dev-1701.sha256.json'
scope='Primary-source/file-metadata research with explicit JSON accelerator import-attempt scope violation; no production correction or new static/physical/consumer qualification'
with manifest.open('xb') as f:f.write(json.dumps(dict(schema='sealed-working-byte-map-v1',scope=scope,members=records,private_originals=[dict(path=private.relative_to(root).as_posix(),bytes=len(b),sha256=sha(b),policy='LOCAL_UNPUBLISHED')],qualification={k:False for k in ['source','clock','measured_calibration','accuracy','teacher','fusion','training','flight']},observer_import_result='UNKNOWN; original false raw flag superseded',static_v2='CONSUMED_FAILED'),indent=2).encode())
target=root/'evidence/zero-needed-python-entry-research-dev-1701.zip'
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in paths:z.write(p,p.relative_to(root).as_posix())
    z.write(manifest,manifest.relative_to(root).as_posix())
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for r in records:
        b=z.read(r['path']);assert len(b)==r['bytes'] and sha(b)==r['sha256']
receipt=dict(path=target.relative_to(root).as_posix(),bytes=target.stat().st_size,members=len(records)+1,mapped_members=len(records),sha256=sha(target.read_bytes()))
with (out/'archive-seal-receipt.json').open('xb') as f:f.write(json.dumps(receipt,indent=2).encode())
print(json.dumps(receipt))
