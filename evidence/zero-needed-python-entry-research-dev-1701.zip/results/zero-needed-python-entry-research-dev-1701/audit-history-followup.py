import datetime
import hashlib
import json
from pathlib import Path

root=Path.cwd();out=root/'results/zero-needed-python-entry-research-dev-1701'
old=json.loads((root/'results/target-bearing-static-v2-executor-dev-1701/historical-archives-postattempt-before-seal.json').read_bytes())['files']
old.append(dict(path='evidence/target-bearing-static-v2-attempt-dev-1701.zip',bytes=16921423,sha256='62eabad05b888068776d3297be3f67f059e187839e3c0d4075222fbfed7d560d'))
assert len(old)==285
for row in old:
    p=root/row['path'];h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    assert p.stat().st_size==row['bytes'] and h.hexdigest()==row['sha256']
with (out/'historical-archives-before-seal.json').open('xb') as f:
    f.write(json.dumps(dict(utc=datetime.datetime.now(datetime.UTC).isoformat(),count=len(old),bytes=sum(r['bytes'] for r in old),all285_equal=True,scope='POSTresearch audit, not pre-observation attestation',members=old,first_audit_helper='Product-sources-after successfully written; later FileNotFoundError for incorrectly named old historical ledger. Console traceback tool-only. Original helper retained; additive followup uses actual existing postattempt ledger, no native rerun or evidence overwrite.'),indent=2).encode())
print(json.dumps(dict(old_archives=len(old),old_bytes=sum(r['bytes'] for r in old))))
