import datetime
import hashlib
import json
import time
import urllib.request
from pathlib import Path

out = Path('results/zero-needed-python-entry-research-dev-1701')
records = []
def fetch(url):
    start = time.monotonic_ns()
    request = urllib.request.Request(url, headers={'User-Agent': 'FlyDrones-zero-needed-research'})
    with urllib.request.urlopen(request, timeout=20) as r:
        data = r.read(16 * 1024 * 1024 + 1)
    assert len(data) <= 16 * 1024 * 1024
    return data, time.monotonic_ns() - start
def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as f: f.write(data)
packages = [
    ('bminor/glibc', 'glibc-2.39', ['elf/ldd.bash.in', 'elf/rtld.c', 'elf/dl-open.c', 'elf/dl-lookup.c', 'elf/dl-load.c', 'elf/dl-deps.c', 'COPYING', 'COPYING.LIB']),
    ('python/cpython', 'v3.12.3', ['Python/dynload_shlib.c', 'Python/importdl.c', 'Python/import.c', 'Modules/_json.c', 'Modules/Setup.stdlib.in', 'configure.ac', 'LICENSE', 'Include/internal/pycore_import.h', 'Doc/library/sys.rst']),
]
for repo, tag, names in packages:
    row = dict(repo=repo, tag=tag, utc=datetime.datetime.now(datetime.UTC).isoformat(), files=[], calls=[])
    package = out / 'upstream' / repo.replace('/', '__')
    try:
        url = 'https://api.github.com/repos/' + repo + '/git/ref/tags/' + tag
        b, ns = fetch(url); save(package / 'official-ref.json', b)
        row['calls'].append(dict(url=url, elapsed_monotonic_ns=ns))
        obj = json.loads(b)['object']; index = 0
        while obj['type'] == 'tag':
            b, ns = fetch(obj['url']); save(package / f'official-tag-{index}.json', b)
            row['calls'].append(dict(url=obj['url'], elapsed_monotonic_ns=ns))
            obj = json.loads(b)['object']; index += 1
        assert obj['type'] == 'commit'
        b, ns = fetch(obj['url']); save(package / 'official-commit.json', b)
        commit = json.loads(b); row['calls'].append(dict(url=obj['url'], elapsed_monotonic_ns=ns))
        url = 'https://api.github.com/repos/' + repo + '/git/trees/' + commit['tree']['sha'] + '?recursive=1'
        b, ns = fetch(url); save(package / 'official-tree.json', b)
        tree = json.loads(b); assert tree['truncated'] is False
        row.update(commit=obj['sha'], tree=commit['tree']['sha'], tree_entries=len(tree['tree']), truncated=False)
        row['calls'].append(dict(url=url, elapsed_monotonic_ns=ns))
        for name in names:
            e = next(x for x in tree['tree'] if x['path'] == name)
            assert e['type'] == 'blob' and e['mode'] == '100644'
            url = 'https://raw.githubusercontent.com/' + repo + '/' + obj['sha'] + '/' + name
            b, ns = fetch(url)
            blob = hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
            assert blob == e['sha'] and len(b) == e['size']
            save(package / name, b)
            row['files'].append(dict(path=name, url=url, bytes=len(b), git_blob=blob, sha256=hashlib.sha256(b).hexdigest(), elapsed_monotonic_ns=ns))
    except Exception as exc:
        row['error'] = repr(exc)
    records.append(row)
    save(out / ('primary-fetch-' + repo.replace('/', '__') + '.json'), json.dumps(row, indent=2).encode())
print(json.dumps([{k:v for k,v in r.items() if k not in ['files','calls']} for r in records]))
