import datetime
import hashlib
import json
import sys
import zipfile
from pathlib import Path

root = Path.cwd()
sys.path.insert(0, str(root))
from tools.benchmark.run_openvins_dataset_consumer import admission

out = root / 'results/zero-needed-python-entry-research-dev-1701'
def sha(b): return hashlib.sha256(b).hexdigest()
def write(name, value):
    with (out / name).open('xb') as f:
        f.write(json.dumps(value, indent=2).encode())

archive = root / 'evidence/target-bearing-static-v2-attempt-dev-1701.zip'
assert sha(archive.read_bytes()) == '62eabad05b888068776d3297be3f67f059e187839e3c0d4075222fbfed7d560d'
prefix = 'results/target-bearing-runtime-freeze-v2-dev-1701/frozen-study-v2/sdk/entry-dependencies/'
rows = []
with zipfile.ZipFile(archive) as z:
    for i in range(1, 59):
        name = prefix + f'query-{i:04d}.json'
        b = z.read(name)
        assert (root / name).read_bytes() == b
        rows.append(dict(path=name, bytes=len(b), sha256=sha(b)))
    for name in [prefix + 'entry-bill.json', 'results/target-bearing-runtime-freeze-v2-dev-1701/native-freeze-failure.json']:
        b = z.read(name)
        assert (root / name).read_bytes() == b
        rows.append(dict(path=name, bytes=len(b), sha256=sha(b)))
write('retained-failure-byte-audit.json', dict(utc=datetime.datetime.now(datetime.UTC).isoformat(), archive_sha256=sha(archive.read_bytes()), members=rows, all_current_bytes_equal=True, replay=False))
facts = admission()
write('initial-resource-private.json', facts)
b = (out / 'initial-resource-private.json').read_bytes()
write('initial-resource-public.json', dict(utc=datetime.datetime.now(datetime.UTC).isoformat(), raw_sha256=sha(b), raw_bytes=len(b), raw_policy='LOCAL_UNPUBLISHED full unclassified process identities; retain without publishing', windows_available=facts['windows_available'], wsl_available=facts['wsl']['available'], blocked_processes=facts['blocked_processes'], docker_exit=facts['docker_exit'], docker_running=facts['docker_running'], original_2GiB_admitted=facts['admitted'], dispatch=False, observation='one readonly snapshot, not a new resource admission or gate retry'))
sources = []
for base in ['src/flydrones', 'tools/benchmark', 'tools/connectome', 'tests/benchmark']:
    for path in sorted((root / base).rglob('*.py')):
        sources.append(dict(path=path.relative_to(root).as_posix(), bytes=path.stat().st_size, sha256=sha(path.read_bytes())))
write('product-sources-before.json', sources)
ledger = root / '.superpowers/sdd/2026-10-15-zero-needed-python-entry-research'
ledger.mkdir(parents=True, exist_ok=True)
with (ledger / 'progress.md').open('x', encoding='utf-8') as f:
    f.write('# SDD ledger — plan: docs/superpowers/plans/2026-10-15-zero-needed-python-entry-research.md\nBASE 7f1b689284ada9a47bb103cd97002e4e33811a4c\nTask1: complete, all58 retained calls and two failure/bill artifacts byte-joined to canonical ZIP without replay.\nTask2: in progress, upstream primary source/context analysis.\nPre-flight: source research consumes sealed failure; metadata conditional consumes exact matching file/hash. Production fixes and new native attempts excluded.\nRuling: research-only plan has no implementation TDD steps, so no unrelated software/native tests run; preserve consumed programs untouched.\n')
print(json.dumps(dict(retained_members=len(rows), product_sources=len(sources), resource={k:facts[k] for k in ['windows_available', 'blocked_processes', 'docker_exit', 'docker_running']})))
