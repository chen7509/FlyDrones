import datetime
import hashlib
import json
import subprocess
import time
from pathlib import Path

out=Path(__file__).resolve().parent
assert not (out/'metadata-command.json').exists() and not (out/'metadata-before.json').exists()
script=out/'observe-metadata.py'
linux='/mnt/c/'+script.as_posix()[3:]
argv=['wsl','-d','Ubuntu','--','/usr/bin/timeout','--kill-after=2s','13s','/usr/bin/python3',linux]
start=time.monotonic_ns()
record=dict(argv=argv, utc_start=datetime.datetime.now(datetime.UTC).isoformat(), monotonic_start_ns=start, observer_sha256=hashlib.sha256(script.read_bytes()).hexdigest(), scope_sha256=hashlib.sha256((out/'METADATA_SCOPE.md').read_bytes()).hexdigest(), parent_timeout_seconds=30)
with (out/'metadata-command.json').open('xb') as f:f.write(json.dumps(record,indent=2).encode())
error=None;stdout=b'';stderr=b'';exitcode=None
try:
    p=subprocess.run(argv,capture_output=True,timeout=30)
    stdout=p.stdout;stderr=p.stderr;exitcode=p.returncode
except subprocess.TimeoutExpired as exc:
    error=repr(exc);stdout=exc.stdout or b'';stderr=exc.stderr or b''
with (out/'metadata-outer-return.json').open('xb') as f:f.write(json.dumps(dict(exit=exitcode,error=error,stdout_hex=stdout.hex(),stderr_hex=stderr.hex(),elapsed_ns=time.monotonic_ns()-start,utc_end=datetime.datetime.now(datetime.UTC).isoformat(),cross_host_clock_synchronization_proven=False),indent=2).encode())
print(json.dumps(dict(exit=exitcode,error=error,elapsed_ns=time.monotonic_ns()-start)))
raise SystemExit(0 if exitcode==0 and error is None else 1)
