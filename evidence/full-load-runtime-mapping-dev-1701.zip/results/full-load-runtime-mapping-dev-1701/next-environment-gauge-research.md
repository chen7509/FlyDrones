# Next dependency: declared launch environment, then trajectory gauge

The retained `dry-v4/capture-v1` study failed before physics because the v3 binding validated environment values that the declared argv did not establish. A future study must not reuse the `capture-v1` name or rewrite this evidence.

First implement an exact execution-environment contract:

- distinguish absent variables from present empty strings;
- declare every lookup variable consumed by `RuntimeBinding.ENV_KEYS` and the command's Python import context;
- make the supervisor spawn the worker with that exact environment rather than relying on the caller shell;
- record the parent declaration, worker-observed environment, and byte-identical contract before any generated copy, TestFixture, PX4, or OpenVINS construction;
- refuse undeclared additions, missing keys, value drift, duplicate keys, non-string values, inherited `PYTHONPATH`, and environment-log write failures;
- preserve 300/300 limits, 25 s / 1 ms / 250 Hz / 10 Hz 160×120 workload, `ready-shadow-heartbeat-v1`, all readiness/watchdog/safety gates, and no ODOMETRY/arming/EKF2;
- test normal, absent-versus-empty, hostile inherited values, supervisor/worker mismatch, malformed contract, and cleanup paths before one separately named physical attempt.

Do not add environment entries after inspecting a running process. Derive them from the sealed resource graph, capture source, and fixed upstream APIs.

After that gate, freeze the trajectory/gauge contract before another VIO accuracy attempt. Specify before execution:

- startup-unavailable and initialized intervals;
- estimator and reference frames, handedness, pose direction, and time matching;
- origin/gauge selection that does not choose a favorable post-run point;
- reset/session boundaries and failure handling;
- full-run reporting plus public/internal initialization, feature/ZUPT state, latency, raw-integral, and offline truth error evidence.

Gazebo truth remains isolated to external termination and offline scoring. It must not initialize, correct, or enter the VIO payload.
