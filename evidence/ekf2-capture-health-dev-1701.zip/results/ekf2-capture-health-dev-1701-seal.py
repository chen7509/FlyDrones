"""Seal the fail-closed capture gate and retrospective EKF2 health evidence."""

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = ROOT / "evidence/ekf2-capture-health-dev-1701.zip"
FILES = (
    "docs/EKF2_CAPTURE_HEALTH_COMPLETION_REPORT.md",
    "docs/superpowers/specs/2026-10-12-ekf2-capture-health-design.md",
    "docs/superpowers/plans/2026-10-12-ekf2-capture-health.md",
    "src/flydrones/connectome_training/capture_input.py",
    "tests/connectome_training/test_capture_input_gate.py",
    "results/ekf2-cohort-frame-audit-1701.py",
    "results/ekf2-cohort-frame-audit-dev-1701/audit.json",
    "results/ekf2-cohort-frame-audit-dev-1701-v2/audit.json",
    "results/ekf2-cohort-frame-audit-dev-1701-v3/audit.json",
    "results/ekf2-capture-health-dev-1701-red-field.txt",
    "results/ekf2-capture-health-dev-1701-red-behavior.txt",
    "results/ekf2-capture-health-dev-1701-focused-final.txt",
    "results/ekf2-capture-health-dev-1701-full-tests.txt",
    "results/ekf2-capture-health-dev-1701-ruff-final.txt",
    "results/ekf2-capture-health-dev-1701-diff-check.txt",
    "results/ekf2-capture-health-dev-1701-review.txt",
    "results/ekf2-capture-health-dev-1701-seal.py",
)


def main() -> None:
    if ARCHIVE.exists():
        raise FileExistsError("evidence archive already exists")
    missing = [name for name in FILES if not (ROOT / name).is_file()]
    if missing:
        raise FileNotFoundError(f"evidence members missing before seal: {missing}")
    manifest = {
        "schema": "flydrones.ekf2_capture_health_evidence.v1",
        "historical_cohort_zip_sha256":
            "88c11d16ec19b52d590cd07622def74262d33837abf611cbf97bfe84f8d99347",
        "retrospective_clock_epoch_qualified": False,
        "source_authenticated": False,
        "fusion_qualified": False,
        "training_eligible": False,
        "files": {},
    }
    ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ARCHIVE, "x", zipfile.ZIP_DEFLATED) as archive:
        for name in FILES:
            data = (ROOT / name).read_bytes()
            manifest["files"][name] = {
                "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            }
            archive.writestr(name, data)
        archive.writestr("manifest.json", json.dumps(manifest, sort_keys=True, indent=2))
    with zipfile.ZipFile(ARCHIVE) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("ZIP CRC check failed")
        for name, expected in manifest["files"].items():
            data = archive.read(name)
            if (len(data) != expected["bytes"]
                    or hashlib.sha256(data).hexdigest() != expected["sha256"]):
                raise RuntimeError(f"evidence member drift: {name}")
    seal = {
        "archive": str(ARCHIVE),
        "sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
        "member_count": len(FILES) + 1,
        "crc_and_hash_verified": True,
    }
    (Path(__file__).parent / "ekf2-capture-health-dev-1701-seal.json").write_text(
        json.dumps(seal, sort_keys=True, indent=2) + "\n", encoding="utf-8",
    )
    print(json.dumps(seal, sort_keys=True))


if __name__ == "__main__":
    main()
