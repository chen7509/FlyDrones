"""Read-only, non-authorizing frame alignment of the four frozen VIO cohort ULogs."""

import hashlib
import importlib.util
import io
import json
import zipfile
from pathlib import Path

from pyulog import ULog

ROOT = Path(__file__).resolve().parents[1]
COHORT = ROOT / "results/openvins-health-physical-dev-1701-v2"
RUNS = (
    "development-seed-27201", "held-out-seed-27211",
    "held-out-seed-27212", "held-out-seed-27213",
)
OUTPUT = ROOT / "results/ekf2-cohort-frame-audit-dev-1701-v3/audit.json"
SEALED = ROOT / "evidence/openvins-health-contract-dev-1701.zip"
SEALED_SHA256 = "88c11d16ec19b52d590cd07622def74262d33837abf611cbf97bfe84f8d99347"


def _no_duplicate_keys(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError(f"duplicate JSON key: {key}")
        value[key] = item
    return value


def _load_shadow_auditor():
    source = ROOT / "src/flydrones/benchmark/ekf2_shadow.py"
    before = hashlib.sha256(source.read_bytes()).hexdigest()
    spec = importlib.util.spec_from_file_location("fixed_ekf2_shadow", source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if hashlib.sha256(source.read_bytes()).hexdigest() != before:
        raise ValueError("auditor source changed during import")
    return before, module


def main():
    auditor_sha, auditor = _load_shadow_auditor()
    if hashlib.sha256(SEALED.read_bytes()).hexdigest() != SEALED_SHA256:
        raise ValueError("historical cohort ZIP hash mismatch")
    with zipfile.ZipFile(SEALED) as archive:
        if archive.testzip() is not None:
            raise ValueError("historical cohort ZIP CRC failure")
        sealed_manifest = json.loads(
            archive.read("evidence-manifest.json"), object_pairs_hook=_no_duplicate_keys,
        )
        sealed_members = {}
        for member in sealed_manifest["members"]:
            name = member["path"]
            if name in sealed_members:
                raise ValueError("duplicate historical seal member")
            sealed_members[name] = member
    summary = {
        "schema": "flydrones-ekf2-vio-cohort-retrospective-v1",
        "auditor_sha256": auditor_sha,
        "historical_cohort_zip_sha256": SEALED_SHA256,
        "cohort_runs": [],
        "time_epoch_qualified": False,
        "source_authenticated": False,
        "camera_calibration_qualified": False,
        "fusion_qualified": False,
        "training_eligible": False,
    }
    for name in RUNS:
        capture = COHORT / name / "capture-v1"
        def sealed_bytes(path: Path) -> bytes:
            if path.is_symlink() or not path.is_file():
                raise ValueError("historical source path invalid")
            relative = path.relative_to(ROOT).as_posix()
            expected = sealed_members.get(relative)
            if expected is None:
                raise ValueError(f"historical source absent from seal: {relative}")
            data = path.read_bytes()
            if (len(data) != expected["bytes"]
                    or hashlib.sha256(data).hexdigest() != expected["sha256"]):
                raise ValueError(f"historical source hash mismatch: {relative}")
            return data

        manifest_data = sealed_bytes(capture / "px4-ulog-manifest.json")
        manifest = json.loads(manifest_data, object_pairs_hook=_no_duplicate_keys)
        if manifest["schema"] != "flydrones-px4-ulog-capture-v1" or len(manifest["logs"]) != 1:
            raise ValueError("unexpected ULog manifest")
        info = manifest["logs"][0]
        path = capture / info["path"]
        if (path.is_symlink() or not path.is_file()
                or not path.resolve().is_relative_to(capture.resolve())
                or path.stat().st_size != info["bytes"]):
            raise ValueError("ULog path/size invalid")
        ulog_data = sealed_bytes(path)
        before = hashlib.sha256(ulog_data).hexdigest()
        if before != info["sha256"]:
            raise ValueError("ULog hash mismatch")
        # pyulog accepts a readable file object; parse exactly the sealed bytes,
        # even if the path is replaced between the check and parsing.
        log = ULog(io.BytesIO(ulog_data))
        topics = {}
        for dataset in log.data_list:
            if dataset.name in (
                    "vehicle_local_position", "vehicle_attitude", "estimator_status",
                    "estimator_status_flags", "vehicle_status", "vehicle_odometry"):
                if dataset.name in topics or dataset.multi_id != 0:
                    raise ValueError("ambiguous ULog topic")
                topics[dataset.name] = dataset.data
        if hashlib.sha256(path.read_bytes()).hexdigest() != before:
            raise ValueError("ULog changed while read")
        frames = []
        health_file = capture / "shadow/health-evidence.jsonl"
        previous = -1
        health_data = sealed_bytes(health_file)
        for line in health_data.decode("utf-8").splitlines():
            row = json.loads(line, object_pairs_hook=_no_duplicate_keys)
            if row.get("event") != "camera_health" or type(row.get("sample_ns")) is not int:
                raise ValueError("camera health row invalid")
            if row["sample_ns"] <= previous:
                raise ValueError("camera health time regression")
            previous = row["sample_ns"]
            if row["projected"]["public_initialized"] is True:
                frames.append(row["sample_ns"])
        if not frames:
            raise ValueError("no public VIO frames")
        shadow = auditor.audit_shadow_frames(frames, topics)
        sample_time = auditor.audit_state_sample_times(frames, topics)
        local = topics["vehicle_local_position"]
        summary["cohort_runs"].append({
            "run": name,
            "ulog_relative": str(path.relative_to(ROOT)).replace("\\", "/"),
            "ulog_sha256": before,
            "camera_health_sha256": hashlib.sha256(health_data).hexdigest(),
            "public_vio_frames": len(frames),
            "local_position_samples": len(local["timestamp"]),
            "heading_good_for_control_samples": int(sum(local["heading_good_for_control"])),
            "vehicle_odometry_logged": "vehicle_odometry" in topics,
            "shadow": shadow,
            "sample_time": sample_time,
        })
    OUTPUT.parent.mkdir(parents=True, exist_ok=False)
    with OUTPUT.open("x", encoding="utf-8") as stream:
        json.dump(summary, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")
    for row in summary["cohort_runs"]:
        print(row["run"], row["public_vio_frames"],
              row["shadow"]["healthy_estimate_count"],
              row["sample_time"]["sample_timing_usable_count"],
              row["heading_good_for_control_samples"])


if __name__ == "__main__":
    main()
