"""Late imported v4 implementation; no dispatcher, simulator or CLI entry."""
if __name__=='__main__':
    raise SystemExit('direct pipeline entry denied')
import copy
import hashlib
import json
import math
import os
import time
from pathlib import Path

from tools.benchmark import native_entry_context_v4 as entry
from tools.benchmark.capture_contract import _typed_equal, read_declaration
from tools.benchmark.declared_runtime_snapshot import file_record, snapshot, write_manifest

ROOT=Path(__file__).resolve().parents[2]
FOLDER=ROOT/'results/target-bearing-runtime-freeze-v4-dev-1701/frozen-study-v4'
QUALIFICATION=dict(entry.QUALIFICATION)
EVIDENCE_ROLES={'context':'runtime:python-extension-context-v4','baseline':'runtime:entry-byte-witness-v4',
                'table':'graph:loader-selected-paths','transport':'runtime:entry-context-artifacts-v4'}


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def current_pid():return os.getpid()


def capture_entry_evidence(bill,context,output):
    output=Path(output);output.mkdir()
    started=time.monotonic_ns()
    # Fresh descriptor reads, not copying the producer's byte witness.
    files=[entry._file_witness(r['requested']) for r in bill['files']]
    baseline=dict(schema='independent-entry-baseline-v4',files=files,provenance=dict(
        method='independent-owned-descriptor-stream-v4',pid=current_pid(),
        observer_code_sha256=digest(entry.__file__),started_monotonic_ns=started,ended_monotonic_ns=time.monotonic_ns()))
    entry.audit_entry_context_bill_v4(bill,baseline_files=files,python_context=context)
    refs=[q['artifact'] for q in bill['queries']]
    refs += [dict(query_path=bill[k],query_sha256=digest(bill[k])) for k in ('aggregate_path','completion_path')]
    members=[]
    for number,ref in enumerate(refs):
        data=Path(ref['query_path']).read_bytes()
        if hashlib.sha256(data).hexdigest()!=ref['query_sha256']:raise ValueError('transport source bytes changed')
        name=f'artifact-{number:04d}.bin'
        with (output/name).open('xb') as stream:
            if stream.write(data)!=len(data):raise OSError('short transport write')
        members.append(dict(source=ref['query_path'],sha256=ref['query_sha256'],bytes=len(data),member=name))
    transport=dict(schema='entry-artifact-transport-v4',items=members)
    paths={k:output/(k+'.json') for k in EVIDENCE_ROLES}
    write_manifest(paths['context'],context);write_manifest(paths['baseline'],baseline);write_manifest(paths['transport'],transport)
    table=dict(schema='loader-selected-path-table-v4',paths=bill['selected_paths'],
               context_sha256=entry.context_digest(context),baseline_sha256=digest(paths['baseline']),
               transport_sha256=digest(paths['transport']),bill_sha256=digest(bill['aggregate_path']))
    write_manifest(paths['table'],table)
    audit_entry_evidence(paths,bill,context)
    return dict(paths=paths,baseline=baseline,table=table,transport=transport)


def artifact_reader(index_path):
    index_path=Path(index_path);index=read_declaration(index_path)
    if set(index)!={'schema','items'} or index['schema']!='entry-artifact-transport-v4' or type(index['items']) is not list:
        raise ValueError('exact artifact transport required')
    rows={r['source']:r for r in index['items']}
    if len(rows)!=len(index['items']) or len(rows)>1028:raise ValueError('transport duplicate/bound')
    names=set()
    for row in rows.values():
        if (set(row)!={'source','sha256','bytes','member'} or type(row['member']) is not str
            or row['member'] in names or not row['member'].startswith('artifact-')
            or Path(row['member']).name!=row['member'] or '/' in row['member'] or '\\' in row['member']):
            raise ValueError('transport member escapes or duplicates')
        names.add(row['member'])
    def read(ref,limit):
        row=rows.get(ref['query_path'])
        if row is None or row['sha256']!=ref['query_sha256'] or type(row['bytes']) is not int or not 0<=row['bytes']<=limit:
            raise ValueError('exact transported source reference missing/different')
        with (index_path.parent/row['member']).open('rb') as stream:data=stream.read(limit+1)
        if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:raise ValueError('transport bytes differ')
        return data
    return read


def audit_entry_evidence(paths,bill,context):
    if set(paths)!=set(EVIDENCE_ROLES):raise ValueError('exact evidence role set required')
    actual=read_declaration(paths['context'])
    if not _typed_equal(actual,context):raise ValueError('context artifact differs')
    baseline=read_declaration(paths['baseline']);proof=baseline.get('provenance',{})
    if (set(baseline)!={'schema','files','provenance'} or baseline['schema']!='independent-entry-baseline-v4'
        or set(proof)!={'method','pid','observer_code_sha256','started_monotonic_ns','ended_monotonic_ns'}
        or proof['method']!='independent-owned-descriptor-stream-v4' or proof['pid']!=context['pid']
        or proof['observer_code_sha256']!=digest(entry.__file__)
        or any(type(proof[k]) is not int or proof[k]<0 for k in ('started_monotonic_ns','ended_monotonic_ns'))
        or proof['ended_monotonic_ns']<proof['started_monotonic_ns']):
        raise ValueError('independent descriptor observation provenance differs')
    # Exact membership also refuses removed self/canonical files.
    if {r['requested'] for r in baseline['files']}!={r['requested'] for r in bill['files']}:
        raise ValueError('independent canonical/self membership differs')
    reader=artifact_reader(paths['transport'])
    entry.audit_entry_context_bill_v4(bill,baseline_files=baseline['files'],python_context=context,artifact_reader=reader)
    table=read_declaration(paths['table'])
    expected=dict(schema='loader-selected-path-table-v4',paths=bill['selected_paths'],context_sha256=entry.context_digest(context),
                  baseline_sha256=digest(paths['baseline']),transport_sha256=digest(paths['transport']),
                  bill_sha256=hashlib.sha256(entry._bytes(bill)).hexdigest())
    if not _typed_equal(table,expected):raise ValueError('raw alias/table/bill/context joins differ')
    index=read_declaration(paths['transport'])
    expected_sources={q['artifact']['query_path'] for q in bill['queries']}|{bill['aggregate_path'],bill['completion_path']}
    if {r['source'] for r in index['items']}!=expected_sources:raise ValueError('transport extra/missing query/terminal')
    return dict(entry_path_context_consistent=True,context_sha256=entry.context_digest(context),
                loader_selected_paths_sha256=digest(paths['table']),loader_selected_paths_semantic_sha256=entry.context_digest(table),
                independent_baseline_sha256=digest(paths['baseline']),runtime_closure_qualified=False)


def declared_context(binding):
    inventory=binding.get('inventory',{})
    if 'graph:loader-selected-paths' not in inventory:return None
    if binding.get('schema')!='capture-resource-binding-v4' or binding.get('capture_profile')!='target-bearing-raw-v1':
        raise ValueError('v4 context requires explicit raw binding')
    rows={r['requested']:r for r in binding['baseline']['files']}
    selected={}
    for name,role in EVIDENCE_ROLES.items():
        values=inventory.get(role)
        if type(values) is not list or len(values)!=1:raise ValueError('one exact v4 evidence role required')
        actual=file_record(values[0]);old=rows.get(values[0],{})
        if old.get('role')!=role or not _typed_equal(actual,{k:v for k,v in old.items() if k!='role'}):
            raise ValueError('v4 evidence file baseline differs')
        selected[name]=values[0]
    context=read_declaration(selected['context']);entry.validate_python_context(context)
    return dict(schema='bound-python-extension-context-v4',file=file_record(selected['context']),
                context_sha256=entry.context_digest(context),loader_selected_paths_sha256=digest(selected['table']),
                loader_selected_paths_semantic_sha256=entry.context_digest(read_declaration(selected['table'])),evidence=selected)


def audit_python_runtime(expected,raw_maps,phase,*,table=None):
    current=None
    try:
        current=entry.collect_python_context()
        return audit_runtime_context(expected,current,raw_maps,phase,table=table)
    except Exception as exc:
        exc.observed_python_context=current
        raise


def audit_runtime_context(expected,current,raw_maps,phase,*,table=None):
    from tools.benchmark.owned_runtime_maps import _device_parts,parse_maps
    if phase not in ('postimports','postfinalize','postfirststep'):raise ValueError('self SDK phase required')
    entry.validate_python_context(expected);entry.validate_python_context(current)
    if current['pid']!=current_pid():raise ValueError('actual SDK PID differs')
    for key in ('interpreter','implementation','version','version_info','soabi','ext_suffix','dlopen_flags'):
        if not _typed_equal(expected[key],current[key]):raise ValueError('SDK interpreter/ABI/flags differ')
    modules={r['name']:r for r in current['modules']};maps=parse_maps(raw_maps)
    required=[expected['interpreter']]+[r['origin'] for r in expected['modules']]
    for module in expected['modules']:
        if not _typed_equal(module,modules.get(module['name'])):raise ValueError('actual SDK module origin differs')
    if table is None or table.get('schema')!='loader-selected-path-table-v4':raise ValueError('bound loader table required')
    for file in required:
        if not any(row['path']==file['resolved'] and row['inode']==file['identity']['inode']
                   and tuple(int(x,16) for x in row['device'].split(':'))==_device_parts(file['identity']['device']) for row in maps):
            raise ValueError('required SDK canonical/module mapping missing/different')
    # Metadata-selected plugins need not be mapped yet. Validate those actually
    # present, without presenting trace selection as initialization evidence.
    for selected in table['paths']:
        for mapped in maps:
            if mapped['path'] in (selected['canonical_path'],selected['raw_path']):
                identity=selected['fd_before']
                if (mapped['inode']!=identity['inode'] or tuple(int(x,16) for x in mapped['device'].split(':'))!=_device_parts(identity['device'])):
                    raise ValueError('mapped loader alias canonical identity differs')
    return dict(phase=phase,pid=current['pid'],observed_context=current,static_context_pid=expected['pid'],
                context_sha256=entry.context_digest(expected),loader_selected_paths_semantic_sha256=entry.context_digest(table),
                runtime_import_verified=False,symbols_resolved=False,runtime_closure_qualified=False)


def _state(ticket,state):
    if (type(state) is not dict or set(state)!={'schema','sdk_pid','ticket'}
        or state['schema']!='revalidated-static-sdk-context-v4' or state['sdk_pid']!=current_pid()
        or not _typed_equal(state['ticket'],ticket)):
        raise ValueError('same actual SDK PID/revalidated reference required')


def prepare(ticket,state=None):
    from tools.benchmark.prepare_calibration_capture_v4 import _authorize
    actual=_authorize(ticket);_state(ticket,actual)
    if state is not None and not _typed_equal(actual,state):raise ValueError('preparation admission changed')
    return _prepare_sdk(ticket,actual)


def paths(python=None):
    from tools.benchmark import calibration_capture_study as shared
    selected=shared.study_paths(FOLDER)
    selected.update(study_code=ROOT/'tools/benchmark/calibration_capture_study_v4.py',
                    producer_code=ROOT/'tools/benchmark/prepare_calibration_capture_v4.py',pipeline_code=Path(__file__),
                    dependency_code=Path(entry.__file__),paths_code=ROOT/'tools/benchmark/native_loader_paths_v4.py',
                    entry_bill=FOLDER/'sdk/entry-dependencies/entry-bill.json')
    selected.update({name:FOLDER/'sdk/entry-evidence'/(name+'.json') for name in EVIDENCE_ROLES})
    if python is None:python=read_declaration(selected['context'])['interpreter']['requested']
    selected['python']=Path(python)
    return selected


def validate_evidence_binding(binding,bill):
    context_bound=declared_context(binding)
    if context_bound is None:raise ValueError('complete bound v4 path/context evidence required')
    evidence=context_bound['evidence'];context=read_declaration(evidence['context'])
    result=audit_entry_evidence(evidence,bill,context)
    baseline={r['requested']:r for r in binding['baseline']['files']}
    for canonical in bill['files']:
        path=canonical['requested'];row=baseline.get(path,{})
        if not _typed_equal({k:v for k,v in row.items() if k!='role'}, {k:v for k,v in canonical.items() if k!='byte_witness'}):
            raise ValueError('canonical/self current baseline pin missing/different')
    required={r['file']['resolved'] for r in bill['entries']}|{r['canonical_path'] for r in bill['selected_paths']}
    required -= set(binding['inventory'].get('graph:resolver',[]))
    if not required <= set(binding['inventory'].get('graph:dependencies',[])):raise ValueError('canonical/self graph dependency missing')
    # Independently observed descriptor procedure is bound to actual producer
    # code bytes in the same current source baseline, not only a SHA label.
    observer=baseline.get(str(Path(entry.__file__).absolute()),{})
    if observer.get('sha256')!=digest(entry.__file__):raise ValueError('independent witness observer code not in current baseline')
    return result


def validate_binding_v4(binding):
    role='runtime:entry-context-bill-v4';values=binding.get('inventory',{}).get(role)
    if type(values) is not list or len(values)!=1:raise ValueError('exact v4 bill role required')
    actual=file_record(values[0]);rows=[r for r in binding['baseline']['files'] if r['role']==role]
    if len(rows)!=1 or not _typed_equal({k:v for k,v in rows[0].items() if k!='role'},actual):raise ValueError('v4 bill baseline bytes differ')
    return validate_evidence_binding(binding,read_declaration(values[0]))


def audit_preparation(binding,preparation,bill_path,bill):
    from tools.benchmark import calibration_capture_study as shared
    from tools.benchmark.agent_capture_runtime import agent_runtime_record
    fixed=FOLDER/'sdk/entry-dependencies/entry-bill.json'
    if Path(bill_path).absolute()!=fixed or not _typed_equal(read_declaration(bill_path),bill):raise ValueError('literal actual v4 bill path/bytes differ')
    if preparation.get('schema')!='raw-static-sdk-preparation-v4' or preparation.get('entry_bill_sha256')!=digest(bill_path):
        raise ValueError('v4 preparation bill/schema differs')
    result=validate_evidence_binding(binding,bill)
    context=declared_context(binding)
    if (preparation.get('python_context_file_sha256')!=context['file']['sha256']
        or preparation.get('python_context_sha256')!=context['context_sha256'] or not _typed_equal(preparation.get('entry_evidence'),result)):
        raise ValueError('preparation evidence semantic/byte joins differ')
    bill_rows=[r for r in binding['baseline']['files'] if r['role']=='runtime:entry-context-bill-v4']
    if len(bill_rows)!=1 or not _typed_equal({k:v for k,v in bill_rows[0].items() if k!='role'},file_record(bill_path)):
        raise ValueError('bill missing from exact binding baseline')
    projected={k:v for k,v in preparation.items() if k not in {'entry_bill_sha256','python_context_file_sha256','python_context_sha256','query_clocks','entry_evidence','sdk_ticket','sdk_pid'}}
    projected['schema']='raw-static-sdk-preparation-v1'
    graph=shared.audit_preparation_at(binding,projected,FOLDER)
    audit_query_clocks(preparation)
    agent=agent_runtime_record(FOLDER/'agent-runtime.json');config=agent['configuration']
    expected=[p for p in agent['selected_paths'] if p==config['binary'] or Path(p).parent==Path(config['lib_dir'])]
    if bill['agent_paths']!=expected or bill['agent_lib']!=config['lib_dir']:raise ValueError('actual Agent loader subset/context differs')
    if preparation.get('sdk_pid')!=bill['python_context']['pid']:raise ValueError('preparation and bill SDK PID differ')
    return dict(graph,**result)


def verify(path,sha,*,require_absent=True):
    from tools.benchmark import calibration_capture_study as shared
    if Path(path).absolute()!=FOLDER/'study.json':raise ValueError('literal v4 study required')
    return shared._verify_profile_study(path,sha,FOLDER,'target-bearing-frozen-raw-study-v4',paths(),require_absent=require_absent,v4=True)


def publish(ticket,state=None):
    from tools.benchmark.calibration_capture_study_v4 import _authorize
    actual=_authorize(ticket);_state(ticket,actual)
    if state is not None and not _typed_equal(actual,state):raise ValueError('publication admission changed')
    preparation=read_declaration(FOLDER/'preparation.json')
    if preparation.get('sdk_pid')!=current_pid() or not _typed_equal(preparation.get('sdk_ticket'),ticket):
        raise ValueError('publication requires original same SDK PID/nonce/ticket')
    document=dict(schema='target-bearing-frozen-raw-study-v4',files={role:file_record(p) for role,p in paths().items()},qualification=QUALIFICATION)
    target=FOLDER/'study.json';write_manifest(target,document);sha=digest(target)
    checked=verify(target,sha);write_manifest(FOLDER/'freeze-verification.json',checked)
    return dict(study=str(target),sha256=sha,declared_runtime_graph_frozen=True,physical_admitted=False,qualification=QUALIFICATION)


import datetime
import importlib.metadata
import re
import subprocess
import sys
from tools.benchmark.calibration_capture_study import SOURCE,arguments
from tools.benchmark.capture_contract import execution_contract
from tools.benchmark.calibration_capture_study_v4 import publish_study_v4
BASE_ENV=dict(entry.ENV)
CATALOG=ROOT/'results/declared-launch-environment-dev-1701/dry-v1/runtime-binding-v3.json'
AGENT=ROOT/'results/agent-capture-contract-dev-1701/agent-runtime.json'
V1_FOLDER=ROOT/'results/target-bearing-runtime-freeze-dev-1701/frozen-study-v1'
RENDERER='/usr/lib/x86_64-linux-gnu/gz-rendering-8/engine-plugins/libgz-rendering8-ogre2.so.8.2.3'
def _run_tool(argv,env):
    row=entry._run(argv,env,str(ROOT))
    return dict(row,exit=row['returncode'],output_limit_exceeded=row['output_limited'])

def select_entries(catalog, plugins, native, agent_paths, resolver):
    entries = {}
    seen = set()

    def add(role, paths):
        selected = [str(p) for p in paths if str(p) not in seen]
        seen.update(selected)
        if selected:
            entries[role] = list(dict.fromkeys(selected))

    for role, paths in catalog["inventory"].items():
        if (
            role.startswith("runtime-root:")
            and not role.startswith("runtime-root:python")
            and role not in {"runtime-root:openvins", "runtime-root:native-reference"}
        ):
            add(role, paths)
    add("renderer", [RENDERER])
    add("selected-world-model-plugins", plugins)
    add("current-python-native", native)
    add("resolver", [resolver])
    add("agent", agent_paths)
    candidates = list(dict.fromkeys(catalog["inventory"].get("runtime:dependencies", [])))
    return entries, candidates

def reuse_agent_cache(configuration, deployment):
    from tools.benchmark.agent_capture_runtime import AGENT_SHA256, BUNDLE_SHA256, LIBRARY_SHA256

    expected = {"bin/MicroXRCEAgent": AGENT_SHA256, **{"lib/" + name: sha for name, sha in LIBRARY_SHA256.items()}}
    binary, lib = Path(configuration["binary"]), Path(configuration["lib_dir"])
    if (
        configuration["schema"] != "capture-agent-runtime-v1"
        or configuration["port"] != 18888
        or binary.parent != lib.parent / "bin"
    ):
        raise ValueError("Agent cache configuration changed")
    if {p.name for p in lib.iterdir()} != set(LIBRARY_SHA256):
        raise ValueError("Agent cache directory member set changed")
    members = {r["member"]: r["deployed"] for r in deployment["members"]}
    if len(members) != len(deployment["members"]) or set(members) != set(expected):
        raise ValueError("Agent cache member set changed")
    rows = []
    for name, sha in expected.items():
        path = binary if name == "bin/MicroXRCEAgent" else lib / name.removeprefix("lib/")
        row = file_record(path)
        if row["sha256"] != sha or not _typed_equal(row, members[name]):
            raise ValueError("Agent cache pinned file changed")
        rows.append(row)
    bundle = file_record(configuration["bundle"])
    if bundle["sha256"] != BUNDLE_SHA256 or not _typed_equal(bundle, deployment["bundle"]):
        raise ValueError("Agent cache original bundle changed")
    return dict(files=rows, bundle=bundle, extracted=False, executed=False, transitive_license_certified=False)

def timed(operation, output, metadata):
    started = time.monotonic_ns()
    record = dict(
        metadata=metadata, start_monotonic_ns=started, start_utc=datetime.datetime.now(datetime.UTC).isoformat(), error=None
    )
    primary = None
    try:
        return operation()
    except BaseException as exc:
        primary = exc
        record["error"] = repr(exc)
        raise
    finally:
        raw = metadata.get("raw_query_path")
        hash_error = None
        try:
            record["raw_query_sha256"] = (
                hashlib.sha256(Path(raw).read_bytes()).hexdigest() if raw and Path(raw).is_file() else None
            )
        except Exception as exc:
            hash_error = exc
            record.update(raw_query_sha256=None, raw_query_error=repr(exc))
            if primary is not None:
                primary.add_note("SDK raw-record identity failure: " + repr(exc))
            else:
                record["error"] = repr(exc)
        ended = time.monotonic_ns()
        record.update(end_monotonic_ns=ended, elapsed_ns=ended - started, end_utc=datetime.datetime.now(datetime.UTC).isoformat())
        try:
            write_manifest(output, record)
        except Exception as exc:
            if primary is None:
                raise
            primary.add_note("paired-clock persistence failure: " + repr(exc))
        if primary is None and hash_error is not None:
            raise hash_error

class ClockedClient:
    def __init__(self, client, binary):
        self.client, self.binary, self.count = client, binary, 0

    def check_budget(self):
        return self.client.check_budget()

    def query(self, *args):
        number = getattr(self.client, "count", self.count)
        self.count += 1
        raw = self.client.output / f"resource-query-{number:04d}.json"
        clock = self.client.output / f"local-clock-{number:04d}.json"
        return timed(lambda: self.client.query(*args), clock, dict(argv=[str(self.binary), *args], raw_query_path=str(raw)))

def licenses(paths, output):
    selected = sorted({str(Path(p).resolve()) for p in paths if Path(p).is_file() and Path(p).suffix != ".py"})
    tool = file_record("/usr/bin/dpkg-query")
    argv = [tool["requested"], "-S", *selected]
    query = _run_tool(argv, dict(BASE_ENV))
    owner_row = dict(query, tool_before=tool, tool_after=None)
    primary = None
    if (
        query["error"] is not None
        or query["output_limit_exceeded"]
        or query["reader_complete"] is not True
        or type(query["exit"]) is not int
        or query["exit"] not in (0, 1)
    ):
        primary = ValueError("bounded installed license query failed: " + str(query["error"]))
    try:
        owner_row["tool_after"] = file_record(tool["requested"])
        if not _typed_equal(tool, owner_row["tool_after"]):
            raise ValueError("installed license tool changed")
    except Exception as exc:
        owner_row["postpin_error"] = repr(exc)
        if primary is None:
            primary = exc
        else:
            primary.add_note("installed license post-pin failure: " + repr(exc))
    try:
        write_manifest(output / "package-owner-query.json", owner_row)
    except Exception as exc:
        owner_row["persistence_error"] = repr(exc)
        if primary is None:
            primary = exc
        else:
            primary.add_note("installed license query persistence failure: " + repr(exc))
        try:
            write_manifest(output / "installed-license-query-failure.json", owner_row)
        except Exception as fallback:
            primary.add_note("installed license fallback persistence failure: " + repr(fallback))
    if primary is not None:
        raise primary
    owners = set()
    for line in bytes.fromhex(query["stdout_hex"]).decode(errors="strict").splitlines():
        if ": /" in line:
            owners.update(line.split(": /", 1)[0].split(", "))
    notices, packages, distributions = [Path(tool["requested"])], [], []
    record = dict(
        query=query,
        selected_owners=sorted(owners),
        package_notices=packages,
        python_distributions=distributions,
        partially_unowned=query["exit"] == 1,
        transitive_license_certified=False,
    )
    primary = None
    try:
        for owner in sorted(owners):
            notice = Path("/usr/share/doc") / owner.split(":", 1)[0] / "copyright"
            packages.append(dict(owner=owner, copyright=file_record(notice) if notice.is_file() else None))
            if notice.is_file():
                notices.append(notice)
        for package in ("numpy", "scipy", "pyulog", "pymavlink", "protobuf"):
            dist = importlib.metadata.distribution(package)
            files = [
                dist.locate_file(n) for n in dist.files or [] if "license" in str(n).lower() or "copyright" in str(n).lower()
            ]
            files = [p for p in files if p.is_file()]
            notices.extend(files)
            distributions.append(dict(package=package, version=dist.version, notices=[file_record(p) for p in files]))
    except Exception as exc:
        primary = exc
        record["error"] = repr(exc)
        raise
    finally:
        try:
            write_manifest(output / "installed-license-observations.json", record)
        except Exception as exc:
            if primary is None:
                raise
            primary.add_note("license observation persistence failure: " + repr(exc))
    return notices

def required_plugins(scene, client):
    """Discover selected plugins before baseline; final graph queries recheck them."""
    from tools.benchmark.selected_resource_graph import references

    names = set()
    for path in sorted(Path(scene).rglob("*.sdf")):
        for reference in references(path.read_bytes(), "sdf"):
            if reference["kind"] == "plugin":
                names.add(reference["text"])
    return [client.query("plugin", name)["selected"] for name in sorted(names)]

def scope_before(unit, output):
    from tools.benchmark.calibration_capture_scope import manager_environment

    lines = [line[3:] for line in Path("/proc/self/cgroup").read_text().splitlines() if line.startswith("0::")]
    if len(lines) != 1:
        raise ValueError("static preparation cgroup unknown")
    group = lines[0]
    cg = Path("/sys/fs/cgroup" + group)
    limits = {name: (cg / name).read_text().strip() for name in ("memory.max", "memory.swap.max", "cpu.max", "pids.max")}
    props = subprocess.run(
        ["systemctl", "--user", "show", unit, "--property=InvocationID", "--property=ControlGroup"],
        capture_output=True,
        text=True,
        timeout=10,
        check=True,
        env=manager_environment(),
    )
    identities = dict(line.split("=", 1) for line in props.stdout.splitlines() if "=" in line)
    record = dict(pid=os.getpid(), cgroup=group, limits=limits, systemd_properties=props.stdout, qualification=False)
    write_manifest(output / "sdk-inside-before.json", record)
    if (
        re.fullmatch(r"fly-calibration-prepare-[0-9a-f]{24}\.scope", unit) is None
        or not group.endswith("/" + unit)
        or identities.get("ControlGroup") != group
        or not identities.get("InvocationID")
        or limits != {"memory.max": str(512 * 1024**2), "memory.swap.max": "0", "cpu.max": "100000 100000", "pids.max": "64"}
    ):
        raise ValueError("static preparation own scope/limits differ")
    return cg

def _prepare_sdk(ticket,state):
    unit=ticket["unit"]
    from tools.benchmark.prepare_calibration_capture_v4 import _authorize
    _state(ticket,_authorize(ticket))
    from tools.benchmark.bound_resource_graph import build_graph
    from tools.benchmark.calibration_capture_contract import copy_scene, scene_record
    from tools.benchmark.calibration_capture_study_v4 import audit_v4_preparation
    from tools.benchmark.native_resource_client import QUERY_ENV_KEYS, QueryClient
    from tools.benchmark.runtime_resource_binding import ENV_KEYS, validate_binding

    if FOLDER.exists():
        raise FileExistsError("one static raw preparation already exists; no replay")
    parent = FOLDER.parent
    started = time.monotonic_ns()
    start_utc = datetime.datetime.now(datetime.UTC).isoformat()
    cg = timed(lambda: scope_before(unit, parent), parent / "scope-local-clock.json", dict(operation="own-scope-before"))
    FOLDER.mkdir()
    primary = None
    try:
        source = scene_record(SOURCE)
        capture = FOLDER / "capture-input-v1"
        capture.mkdir()
        copy_scene(source, capture)
        wire = dict(
            schema="capture-wire-startup-v2",
            session_id="calibration-measurement-dev-1701",
            sim_origin_ns=0,
            remote_origin_ns=0,
            startup_max_wall_ns=60_000_000_000,
        )
        write_manifest(FOLDER / "wire-config.json", wire)
        old_agent = V1_FOLDER / "agent-runtime.json"
        old_deployment = V1_FOLDER / "agent-deployment.json"
        configuration = json.loads(old_agent.read_text(encoding="utf8"))
        reused = reuse_agent_cache(configuration, json.loads(old_deployment.read_text(encoding="utf8")))
        write_manifest(
            FOLDER / "agent-cache-reuse.json",
            dict(reused, source_configuration=file_record(old_agent), source_deployment=file_record(old_deployment)),
        )
        write_manifest(FOLDER / "agent-runtime.json", configuration)
        args = arguments(FOLDER)
        env = {key: None for key in set(ENV_KEYS) | set(QUERY_ENV_KEYS)}
        env.update(
            HOME="/home/yuchen7509",
            PATH="/usr/bin:/bin",
            LANG="C.UTF-8",
            GZ_SIM_RESOURCE_PATH=str(capture / "models"),
            GZ_SIM_SYSTEM_PLUGIN_PATH="",
            SDF_PATH="",
            GZ_FILE_PATH="",
            GZ_HOMEDIR=str(FOLDER / "gz-home"),
            MESA_SHADER_CACHE_DISABLE="true",
        )
        query_env = {key: env[key] for key in QUERY_ENV_KEYS}
        catalog = json.loads(CATALOG.read_text(encoding="utf8"))
        resolver = Path(catalog["inventory"]["graph:resolver"][0])
        pins = {row["role"]: row for row in catalog["baseline"]["files"] if row["role"] in ("graph:resolver", "graph:source")}
        for role, path in (("graph:resolver", resolver), ("graph:source", ROOT / "tools/benchmark/native/resource_resolver.cc")):
            if file_record(path)["sha256"] != pins[role]["sha256"]:
                raise ValueError("existing SDK resolver/source pin changed")
        sdk = FOLDER / "sdk"
        sdk.mkdir()
        client = ClockedClient(QueryClient(resolver, ROOT, query_env, sdk), resolver)
        context = client.query("context")
        installation = client.query("installation")
        write_manifest(sdk / "installed-context.json", context)
        write_manifest(sdk / "installed-directories.json", installation)
        contract = execution_contract(args, env)
        inventory = {}
        used = set()

        def add(role, paths):
            selected = []
            for value in paths:
                path = str(Path(value).absolute())
                if path not in used:
                    used.add(path)
                    selected.append(path)
            if selected:
                inventory[role] = selected

        add("graph:resolver", [resolver])
        add(
            "graph:source",
            [
                ROOT / "tools/benchmark/native/resource_resolver.cc",
            ],
        )
        # A former catalog supplies only installed native root candidates. All
        # selected bytes/dependencies are freshly observed; no old native runs.
        native = [entry.tool_paths()["python"]]
        modules = []
        for module in tuple(sys.modules.values()):
            name = getattr(module, "__file__", None)
            if name and Path(name).is_file():
                modules.append(str(Path(name).resolve()))
                cached = getattr(module, "__cached__", None)
                if cached and Path(cached).is_file():
                    modules.append(str(Path(cached).resolve()))
                if Path(name).suffix == ".so":
                    native.append(str(Path(name).resolve()))
        for pattern in ("gz/**/*.so", "sdformat14*.so"):
            native.extend(str(p.resolve()) for p in Path("/usr/lib/python3/dist-packages").glob(pattern))
        native.extend(m["origin"]["requested"] for m in entry.collect_python_context()["modules"])
        entries, candidates = select_entries(
            catalog, required_plugins(capture, client), native, contract["agent"]["selected_paths"], str(resolver)
        )
        agent_configuration = contract["agent"]["configuration"]
        loader_paths = [
            p
            for p in contract["agent"]["selected_paths"]
            if p == agent_configuration["binary"] or Path(p).parent == Path(agent_configuration["lib_dir"])
        ]
        python_context = entry.collect_python_context()
        write_manifest(sdk / "python-context.json", python_context)
        bill = entry.discover_entry_context_v4(
            entries, candidates, python_context, loader_paths, agent_configuration["lib_dir"], sdk / "entry-dependencies"
        )
        evidence=capture_entry_evidence(bill,python_context,sdk/'entry-evidence')
        add('graph:dependencies',[r['file']['resolved'] for r in bill['entries']]+[r['canonical_path'] for r in bill['selected_paths']])
        for name,role in EVIDENCE_ROLES.items():add(role,[evidence['paths'][name]])
        add('runtime:entry-context-bill-v4',[sdk/'entry-dependencies/entry-bill.json'])
        add('runtime:entry-context-source-artifacts-v4',sorted((sdk/'entry-dependencies').glob('query-*.json'))+[sdk/'entry-dependencies/entry-bill-terminal.json',sdk/'entry-dependencies/entry-bill-terminal.prepared.json'])
        add('runtime:entry-context-transport-members-v4',sorted((sdk/'entry-evidence').glob('artifact-*.bin')))
        add('runtime:entry-dependency-files',[r['requested'] for r in bill['declared_before']])
        add("runtime:python-modules", modules)
        add("runtime:installed-notices", licenses([path for paths in inventory.values() for path in paths], sdk))
        add("runtime:classic-material", [installation["classic_material"]])
        add(
            "runtime:project-source",
            sorted(
                p
                for scope in (ROOT / "src/flydrones", ROOT / "tools/benchmark", ROOT / "tools/connectome")
                for p in scope.rglob("*.py")
                if "__pycache__" not in p.parts
            ),
        )
        add("runtime:resolver-headers", [ROOT / "tools/benchmark/native/local_candidates.hh"])
        add("runtime:source-scene", [SOURCE / name for name in source["files"]])
        add(
            "runtime:original-models",
            [ROOT / "assets/gazebo/models/x500_benchmark/model.sdf", ROOT / "assets/gazebo/models/OakD-Benchmark/model.sdf"],
        )
        # The collector explicitly requires these original source/profile files.
        add(
            "runtime:px4-selected",
            [
                Path("/home/yuchen7509/PX4-Autopilot") / name
                for name in (
                    "build/px4_sitl_default/rootfs/gz_env.sh",
                    "build/px4_sitl_default/etc/init.d-posix/rcS",
                    "src/modules/simulation/gz_bridge/server.config",
                    "Tools/simulation/gz/models/x500/model.sdf",
                    "Tools/simulation/gz/models/x500_base/model.sdf",
                    "LICENSE",
                )
            ],
        )
        add("runtime:logger", [Path(p) for p in contract["logger_diagnostic"]["source_paths"]])
        add(
            "runtime:configuration",
            [
                FOLDER / "wire-config.json",
                FOLDER / "agent-runtime.json",
                FOLDER / "agent-cache-reuse.json",
                old_agent,
                old_deployment,
                CATALOG,
                AGENT,
                sdk / "entry-dependencies/entry-bill.json",
            ],
        )
        gz_env = Path("/home/yuchen7509/PX4-Autopilot/build/px4_sitl_default/rootfs/gz_env.sh")
        generated = {name: row["sha256"] for name, row in source["files"].items()}
        generated["gz_env.sh"] = file_record(gz_env)["sha256"]
        binding = dict(
            schema="capture-resource-binding-v4",
            capture_profile="target-bearing-raw-v1",
            calibration_scene=source,
            inventory=inventory,
            baseline=snapshot(inventory),
            environment={key: env[key] for key in (*ENV_KEYS, "MESA_SHADER_CACHE_DISABLE")},
            generated=generated,
            graph=dict(schema="generated-resource-graph-v1", cwd=str(ROOT), environment=query_env, expected_context=context),
            runtime_maps=dict(
                self_phases=["postimports", "postfinalize", "postfirststep"],
                owned_roles={"px4": ["ready", "prestop"], "agent": ["ready", "prestop"]},
                max_maps_bytes=8 * 1024**2,
                max_observations=16,
            ),
        )
        validate_binding(binding)
        write_manifest(FOLDER / "runtime-binding-v4.json", binding)
        # The final contract now binds actual context bytes via the newly written
        # binding; the earlier contract supplied only Agent/logger selection.
        contract = execution_contract(args, env)
        contract=execution_contract(args,env)
        write_manifest(FOLDER / "execution-contract.json", contract)
        proof_inventory = dict(inventory)
        for name in source["files"]:
            proof_inventory["generated:" + name] = [str(capture / name)]
        # The copied runtime gz_env bytes have their source record in baseline;
        # the actual runtime-generated path is separately rechecked by worker.
        pre = snapshot(proof_inventory)
        graph_client = ClockedClient(QueryClient(resolver, ROOT, query_env, FOLDER / "graph-queries"), resolver)
        (FOLDER / "graph-queries").mkdir()
        graph_context = graph_client.query("context")
        graph = build_graph(capture / "world.sdf", graph_client, pre["files"], FOLDER / "graph-queries")
        after = snapshot(proof_inventory)
        pre["resource_graph"] = graph
        preparation = dict(
            schema="raw-static-sdk-preparation-v4",
            python_context_file_sha256=file_record(sdk / "python-context.json")["sha256"],
            python_context_sha256=entry.context_digest(python_context),
            entry_bill_sha256=hashlib.sha256((sdk / "entry-dependencies/entry-bill.json").read_bytes()).hexdigest(),
            binding_sha256=hashlib.sha256((FOLDER / "runtime-binding-v4.json").read_bytes()).hexdigest(),
            execution_sha256=hashlib.sha256((FOLDER / "execution-contract.json").read_bytes()).hexdigest(),
            pre=pre,
            after_queries=after,
            graph=graph,
            context=graph_context,
            queries=[json.loads(p.read_text()) for p in sorted((FOLDER / "graph-queries").glob("resource-query-*.json"))],
            documents_hex={row["source"]: Path(row["source"]).read_bytes().hex() for row in graph["documents"]},
            query_clocks=[json.loads(p.read_text()) for p in sorted((FOLDER / "graph-queries").glob("local-clock-*.json"))],
            audit=None,
            entry_evidence=audit_entry_evidence(evidence["paths"],bill,python_context),
            sdk_ticket=dict(ticket),
            sdk_pid=current_pid(),
        )
        from tools.benchmark.audit_live_wire_resources import audit_resource_graph_records

        preparation["audit"] = audit_resource_graph_records(
            declaration=binding,
            pre=pre,
            after_queries=after,
            graph=graph,
            context=graph_context,
            queries=preparation["queries"],
            documents={p: bytes.fromhex(data) for p, data in preparation["documents_hex"].items()},
        )
        audit_v4_preparation(binding, preparation, sdk / "entry-dependencies/entry-bill.json", bill)
        write_manifest(FOLDER / "preparation.json", preparation)
        result = publish_study_v4(ticket)
        write_manifest(parent / "native-freeze-result.json", result)
        return result
    except Exception as exc:
        primary = exc
        try:
            write_manifest(parent / "native-freeze-failure.json", dict(error=repr(exc), folder=str(FOLDER), qualification=False))
        except Exception as writer:
            exc.add_note("native failure persistence error: " + repr(writer))
        raise
    finally:
        ended = time.monotonic_ns()
        record = dict(
            cgroup=str(cg),
            start_monotonic_ns=started,
            end_monotonic_ns=ended,
            elapsed_ns=ended - started,
            start_utc=start_utc,
            end_utc=datetime.datetime.now(datetime.UTC).isoformat(),
            qualification=False,
        )
        counter_error = None
        try:
            record.update(
                limits={
                    name: (cg / name).read_text().strip() for name in ("memory.max", "memory.swap.max", "cpu.max", "pids.max")
                },
                memory_events=(cg / "memory.events").read_text(),
                memory_peak=(cg / "memory.peak").read_text() if (cg / "memory.peak").exists() else None,
            )
        except Exception as exc:
            counter_error = exc
            record["counter_error"] = repr(exc)
            if primary is not None:
                primary.add_note("scope final counter failure: " + repr(exc))
        try:
            write_manifest(parent / "sdk-inside-after.json", record)
        except Exception as exc:
            if primary is None:
                raise
            primary.add_note("scope final persistence failure: " + repr(exc))
        if primary is None and counter_error is not None:
            raise counter_error


def audit_query_clocks(preparation):
    clocks, queries = preparation["query_clocks"], preparation["queries"]
    if type(clocks) is not list or type(queries) is not list or len(clocks) != len(queries):
        raise ValueError("SDK paired-clock membership differs")
    previous_end = None
    for number, (clock, query) in enumerate(zip(clocks, queries, strict=True)):
        raw = FOLDER / "graph-queries" / f"resource-query-{number:04d}.json"
        start, end, elapsed = (clock[k] for k in ("start_monotonic_ns", "end_monotonic_ns", "elapsed_ns"))
        if any(type(v) is not int or v < 0 for v in (start, end, elapsed)) or end - start != elapsed or end < start:
            raise ValueError("SDK paired-clock local interval invalid")
        if previous_end is not None and start < previous_end:
            raise ValueError("SDK paired-clock query order invalid")
        previous_end = end
        inner_start, inner_end = (query[k] for k in ("started_monotonic", "ended_monotonic"))
        if (
            any(type(v) not in (int, float) or not math.isfinite(v) or v < 0 for v in (inner_start, inner_end))
            or inner_end < inner_start
        ):
            raise ValueError("SDK paired-clock raw local interval invalid")
        # QueryClient records this same host's seconds as float, the wrapper as
        # integer nanoseconds. One microsecond only covers representation rounding.
        # It is not a sensor-clock tolerance or a cross-host clock comparison.
        if inner_start * 1_000_000_000 < start - 1000 or inner_end * 1_000_000_000 > end + 1000:
            raise ValueError("SDK paired-clock raw local interval outside wrapper")
        if clock["error"] is not None or "raw_query_error" in clock:
            raise ValueError("SDK paired-clock observation incomplete")
        for name in ("start_utc", "end_utc"):
            if type(clock[name]) is not str or datetime.datetime.fromisoformat(clock[name]).utcoffset() != datetime.timedelta(0):
                raise ValueError("SDK paired-clock UTC fact invalid")
        if (
            clock["metadata"] != dict(argv=query["command"], raw_query_path=str(raw))
            or clock["raw_query_sha256"] != hashlib.sha256(raw.read_bytes()).hexdigest()
            or not _typed_equal(read_declaration(raw), query)
        ):
            raise ValueError("SDK paired-clock raw command/file join differs")
