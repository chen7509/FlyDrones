"""Inert v4 preparation/study/runtime integration, never a target dispatcher."""
import builtins
import importlib
import sys
from pathlib import Path

import pytest

ROOT=Path(__file__).resolve().parents[2]
MODULES=('prepare_calibration_capture_v4','calibration_capture_study_v4')


@pytest.mark.parametrize('name',MODULES)
@pytest.mark.parametrize('main',[False,True])
def test_inert_module_body_before_any_import_or_io(name,main,monkeypatch):
    source=(ROOT/'tools/benchmark'/f'{name}.py').read_text()
    calls=[];original=builtins.__import__
    def trap(module,*args,**kwargs):
        if module=='sys':return sys
        calls.append(module);raise AssertionError('nonprimitive import '+module)
    def no_io(*args,**kwargs):raise AssertionError('unexpected IO')
    namespace=dict(__name__='__main__' if main else 'fixture',__file__=str(ROOT/'tools/benchmark'/f'{name}.py'))
    with monkeypatch.context() as patch:
        patch.setattr(builtins,'open',no_io);patch.setattr(builtins,'__import__',trap)
        if main:
            with pytest.raises(SystemExit):exec(compile(source,namespace['__file__'],'exec'),namespace)
        else:exec(compile(source,namespace['__file__'],'exec'),namespace)
    assert not calls and original is builtins.__import__


@pytest.mark.parametrize('name,function',[('prepare_calibration_capture_v4','prepare_v4'),('calibration_capture_study_v4','publish_study_v4')])
@pytest.mark.parametrize('ticket',[None,{}, {'schema':'static-sdk-ticket-reference-v4','nonce':'a'*64}])
def test_invalid_ticket_refuses_before_deferred_effects(name,function,ticket,monkeypatch):
    module=importlib.import_module('tools.benchmark.'+name)
    def trap(*args,**kwargs):raise AssertionError('deferred effect before admission')
    with monkeypatch.context() as patch:
        patch.setattr(builtins,'open',trap);patch.setattr(builtins,'__import__',trap)
        with pytest.raises(ValueError):getattr(module,function)(ticket)


def test_runtime_v4_api_is_real_and_guard_installed():
    import subprocess
    from tools.benchmark import calibration_capture_study_v4 as study
    assert subprocess.Popen._execute_child.__name__=='denied'
    assert callable(study.audit_v4_preparation) and callable(study.verify_study_v4)


@pytest.fixture
def entry_fixture(tmp_path,monkeypatch):
    # Reuse only the explicit inert fixture, not the prior suite or any v3 code.
    import importlib.util
    spec=importlib.util.spec_from_file_location('inert_entry_fixture',ROOT/'tests/benchmark/test_native_entry_context_v4.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    state=module.setup.__wrapped__(tmp_path,monkeypatch)
    bill=module.produce(state)
    return state,bill


def test_entry_evidence_observes_independent_witness_and_exact_artifacts(entry_fixture,tmp_path,monkeypatch):
    from tools.benchmark import calibration_capture_pipeline_v4 as p
    state,bill=entry_fixture
    monkeypatch.setattr(p,'current_pid',lambda:state.context['pid'])
    evidence=p.capture_entry_evidence(bill,state.context,tmp_path/'evidence')
    assert len(evidence['baseline']['files'])==len(bill['files'])
    assert evidence['baseline']['provenance']['method']=='independent-owned-descriptor-stream-v4'
    assert evidence['table']['paths']==bill['selected_paths']
    assert len(evidence['transport']['items'])==len(bill['queries'])+2
    assert p.audit_entry_evidence(evidence['paths'],bill,state.context)['entry_path_context_consistent']


@pytest.mark.parametrize('mutation',['self','table','context','artifact','baseline','terminal'])
def test_actual_entry_join_rejects_changed_evidence(entry_fixture,tmp_path,mutation,monkeypatch):
    import json
    from tools.benchmark import calibration_capture_pipeline_v4 as p
    state,bill=entry_fixture;monkeypatch.setattr(p,'current_pid',lambda:state.context['pid']);e=p.capture_entry_evidence(bill,state.context,tmp_path/'evidence')
    path=e['paths'][{'self':'baseline','table':'table','context':'context','artifact':'transport','baseline':'baseline','terminal':'transport'}[mutation]]
    value=json.loads(Path(path).read_bytes())
    if mutation=='self':value['files']=value['files'][1:]
    elif mutation=='table':value['paths']=value['paths'][:-1]
    elif mutation=='context':value['dlopen_flags']+=1
    elif mutation=='artifact':value['items'][0]['sha256']='0'*64
    elif mutation=='baseline':value['provenance']['method']='copied-from-bill'
    else:value['items']=[r for r in value['items'] if not r['source'].endswith('entry-bill-terminal.json')]
    Path(path).write_text(json.dumps(value))
    with pytest.raises(ValueError):p.audit_entry_evidence(e['paths'],bill,state.context)


@pytest.mark.parametrize('function',['prepare','publish'])
def test_impl_cannot_bypass_missing_bootstrap(function,monkeypatch):
    from tools.benchmark import calibration_capture_pipeline_v4 as p
    monkeypatch.delitem(sys.modules,'tools.benchmark.static_v4_bootstrap',raising=False)
    with pytest.raises(ValueError):getattr(p,function)({}, {})


def test_runtime_only_requires_actual_modules_and_validates_mapped_aliases(entry_fixture,monkeypatch):
    from tools.benchmark import calibration_capture_pipeline_v4 as p
    state,bill=entry_fixture;monkeypatch.setattr(p,'current_pid',lambda:state.context['pid'])
    def mapping(file):
        i=file['identity'];device=f"{i['device']>>8:02x}:{i['device']&255:02x}"
        return f"1000-2000 r-xp 00000000 {device} {i['inode']} {file['resolved']}\n"
    raw=''.join(mapping(r) for r in [state.context['interpreter'],*[m['origin'] for m in state.context['modules']]])
    result=p.audit_runtime_context(state.context,state.context,raw,'postimports',table=dict(schema='loader-selected-path-table-v4',paths=bill['selected_paths']))
    assert result['pid']==state.context['pid'] and not result['runtime_import_verified']


def test_fixed_v4_verifier_refuses_arbitrary_study_path(tmp_path):
    from tools.benchmark.calibration_capture_study_v4 import verify_study_v4
    with pytest.raises(ValueError):verify_study_v4(tmp_path/'study.json','0'*64)
