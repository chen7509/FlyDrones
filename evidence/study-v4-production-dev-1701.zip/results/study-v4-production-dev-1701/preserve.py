import hashlib,json
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def save(name,v):
    with (raw/name).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2)
old=json.loads((root/'results/entry-context-v4-production-dev-1701/historical-archives-postsoftware.json').read_bytes())['members']
old.append(dict(path='evidence/entry-context-v4-production-dev-1701.zip',bytes=19800282,sha256='9606665a8713c056b85682b37d47e19e0a75dc4f6d96e3fb8d402015e7385b60'))
assert len(old)==291 and {x['path'] for x in old}=={p.relative_to(root).as_posix() for p in (root/'evidence').glob('*.zip')}
for row in old:
    d=hashlib.sha256();size=0
    with (root/row['path']).open('rb') as f:
        while b:=f.read(1048576):d.update(b);size+=len(b)
    assert size==row['bytes'] and d.hexdigest()==row['sha256'],row['path']
save('historical-archives-postsoftware.json',dict(count=len(old),bytes=sum(x['bytes'] for x in old),members=old,scope='POSTsoftware preservation only;not prepin'))
before=json.loads((raw/'product-before.json').read_bytes());changed=[]
for row in before:
    if sha((root/row['path']).read_bytes())!=row['sha256']:changed.append(row['path'])
allowed={'tools/benchmark/native_loader_paths_v4.py','tools/benchmark/native_entry_context_v4.py','tools/benchmark/capture_contract.py','tools/benchmark/runtime_resource_binding.py','tools/benchmark/calibration_capture_study.py','tools/benchmark/bound_resource_graph.py','tools/benchmark/audit_live_wire_resources.py'}
assert set(changed)==allowed,changed
save('product-preservation-postsoftware.json',dict(count=len(before),modified=changed,all_other_old_byte_same=True,scope='seven explicit shared/component integration files;no consumed version-specific product mutated'))
assert not (root/'results/target-bearing-runtime-freeze-v4-dev-1701').exists() and not (root/'results/target-bearing-physical-capture-dev-1701').exists()
save('software-absence.json',dict(v4_fixed_parent_absent=True,physical_fixed_attempt_absent=True,scope='software-phase observation;not admission'))
print('291oldZIP/845182128B unchanged;811oldproduct7allowedchanges;no v4/physical attempt')
