"""Late imported v4 implementation; no dispatcher, simulator or CLI entry."""
import copy
import hashlib
import json
import os
import time
from pathlib import Path

from tools.benchmark import native_entry_context_v4 as entry
from tools.benchmark.capture_contract import _typed_equal, read_declaration
from tools.benchmark.declared_runtime_snapshot import file_record, snapshot, write_manifest

ROOT=Path(__file__).resolve().parents[2]
FOLDER=ROOT/'results/target-bearing-runtime-freeze-v4-dev-1701/frozen-study-v4'
QUALIFICATION=dict(entry.QUALIFICATION)
EVIDENCE_ROLES={'context':'runtime:python-extension-context-v4','baseline':'runtime:entry-byte-witness-v4',
                'table':'graph:loader-selected-paths','transport':'runtime:entry-context-artifacts-v4'}


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def current_pid():return os.getpid()


def capture_entry_evidence(bill,context,output):
    output=Path(output);output.mkdir()
    started=time.monotonic_ns()
    # Fresh descriptor reads, not copying the producer's byte witness.
    files=[entry._file_witness(r['requested']) for r in bill['files']]
    baseline=dict(schema='independent-entry-baseline-v4',files=files,provenance=dict(
        method='independent-owned-descriptor-stream-v4',pid=current_pid(),
        observer_code_sha256=digest(entry.__file__),started_monotonic_ns=started,ended_monotonic_ns=time.monotonic_ns()))
    entry.audit_entry_context_bill_v4(bill,baseline_files=files,python_context=context)
    refs=[q['artifact'] for q in bill['queries']]
    refs += [dict(query_path=bill[k],query_sha256=digest(bill[k])) for k in ('aggregate_path','completion_path')]
    members=[]
    for number,ref in enumerate(refs):
        data=Path(ref['query_path']).read_bytes()
        if hashlib.sha256(data).hexdigest()!=ref['query_sha256']:raise ValueError('transport source bytes changed')
        name=f'artifact-{number:04d}.bin'
        with (output/name).open('xb') as stream:
            if stream.write(data)!=len(data):raise OSError('short transport write')
        members.append(dict(source=ref['query_path'],sha256=ref['query_sha256'],bytes=len(data),member=name))
    transport=dict(schema='entry-artifact-transport-v4',items=members)
    paths={k:output/(k+'.json') for k in EVIDENCE_ROLES}
    write_manifest(paths['context'],context);write_manifest(paths['baseline'],baseline);write_manifest(paths['transport'],transport)
    table=dict(schema='loader-selected-path-table-v4',paths=bill['selected_paths'],
               context_sha256=entry.context_digest(context),baseline_sha256=digest(paths['baseline']),
               transport_sha256=digest(paths['transport']),bill_sha256=digest(bill['aggregate_path']))
    write_manifest(paths['table'],table)
    audit_entry_evidence(paths,bill,context)
    return dict(paths=paths,baseline=baseline,table=table,transport=transport)


def artifact_reader(index_path):
    index_path=Path(index_path);index=read_declaration(index_path)
    if set(index)!={'schema','items'} or index['schema']!='entry-artifact-transport-v4' or type(index['items']) is not list:
        raise ValueError('exact artifact transport required')
    rows={r['source']:r for r in index['items']}
    if len(rows)!=len(index['items']) or len(rows)>1028:raise ValueError('transport duplicate/bound')
    names=set()
    for row in rows.values():
        if (set(row)!={'source','sha256','bytes','member'} or type(row['member']) is not str
            or row['member'] in names or not row['member'].startswith('artifact-')
            or Path(row['member']).name!=row['member'] or '/' in row['member'] or '\\' in row['member']):
            raise ValueError('transport member escapes or duplicates')
        names.add(row['member'])
    def read(ref,limit):
        row=rows.get(ref['query_path'])
        if row is None or row['sha256']!=ref['query_sha256'] or type(row['bytes']) is not int or not 0<=row['bytes']<=limit:
            raise ValueError('exact transported source reference missing/different')
        with (index_path.parent/row['member']).open('rb') as stream:data=stream.read(limit+1)
        if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:raise ValueError('transport bytes differ')
        return data
    return read


def audit_entry_evidence(paths,bill,context):
    if set(paths)!=set(EVIDENCE_ROLES):raise ValueError('exact evidence role set required')
    actual=read_declaration(paths['context'])
    if not _typed_equal(actual,context):raise ValueError('context artifact differs')
    baseline=read_declaration(paths['baseline']);proof=baseline.get('provenance',{})
    if (set(baseline)!={'schema','files','provenance'} or baseline['schema']!='independent-entry-baseline-v4'
        or set(proof)!={'method','pid','observer_code_sha256','started_monotonic_ns','ended_monotonic_ns'}
        or proof['method']!='independent-owned-descriptor-stream-v4' or proof['pid']!=context['pid']
        or proof['observer_code_sha256']!=digest(entry.__file__)
        or any(type(proof[k]) is not int or proof[k]<0 for k in ('started_monotonic_ns','ended_monotonic_ns'))
        or proof['ended_monotonic_ns']<proof['started_monotonic_ns']):
        raise ValueError('independent descriptor observation provenance differs')
    # Exact membership also refuses removed self/canonical files.
    if {r['requested'] for r in baseline['files']}!={r['requested'] for r in bill['files']}:
        raise ValueError('independent canonical/self membership differs')
    reader=artifact_reader(paths['transport'])
    entry.audit_entry_context_bill_v4(bill,baseline_files=baseline['files'],python_context=context,artifact_reader=reader)
    table=read_declaration(paths['table'])
    expected=dict(schema='loader-selected-path-table-v4',paths=bill['selected_paths'],context_sha256=entry.context_digest(context),
                  baseline_sha256=digest(paths['baseline']),transport_sha256=digest(paths['transport']),
                  bill_sha256=hashlib.sha256(entry._bytes(bill)).hexdigest())
    if not _typed_equal(table,expected):raise ValueError('raw alias/table/bill/context joins differ')
    index=read_declaration(paths['transport'])
    expected_sources={q['artifact']['query_path'] for q in bill['queries']}|{bill['aggregate_path'],bill['completion_path']}
    if {r['source'] for r in index['items']}!=expected_sources:raise ValueError('transport extra/missing query/terminal')
    return dict(entry_path_context_consistent=True,context_sha256=entry.context_digest(context),
                loader_selected_paths_sha256=digest(paths['table']),loader_selected_paths_semantic_sha256=entry.context_digest(table),
                independent_baseline_sha256=digest(paths['baseline']),runtime_closure_qualified=False)


def declared_context(binding):
    inventory=binding.get('inventory',{})
    if 'graph:loader-selected-paths' not in inventory:return None
    if binding.get('schema')!='capture-resource-binding-v4' or binding.get('capture_profile')!='target-bearing-raw-v1':
        raise ValueError('v4 context requires explicit raw binding')
    rows={r['requested']:r for r in binding['baseline']['files']}
    selected={}
    for name,role in EVIDENCE_ROLES.items():
        values=inventory.get(role)
        if type(values) is not list or len(values)!=1:raise ValueError('one exact v4 evidence role required')
        actual=file_record(values[0]);old=rows.get(values[0],{})
        if old.get('role')!=role or not _typed_equal(actual,{k:v for k,v in old.items() if k!='role'}):
            raise ValueError('v4 evidence file baseline differs')
        selected[name]=values[0]
    context=read_declaration(selected['context']);entry.validate_python_context(context)
    return dict(schema='bound-python-extension-context-v4',file=file_record(selected['context']),
                context_sha256=entry.context_digest(context),loader_selected_paths_sha256=digest(selected['table']),
                loader_selected_paths_semantic_sha256=entry.context_digest(read_declaration(selected['table'])),evidence=selected)


def audit_python_runtime(expected,raw_maps,phase,*,table=None):
    current=None
    try:
        current=entry.collect_python_context()
        return audit_runtime_context(expected,current,raw_maps,phase,table=table)
    except Exception as exc:
        exc.observed_python_context=current
        raise


def audit_runtime_context(expected,current,raw_maps,phase,*,table=None):
    from tools.benchmark.owned_runtime_maps import _device_parts,parse_maps
    if phase not in ('postimports','postfinalize','postfirststep'):raise ValueError('self SDK phase required')
    entry.validate_python_context(expected);entry.validate_python_context(current)
    if current['pid']!=current_pid():raise ValueError('actual SDK PID differs')
    for key in ('interpreter','implementation','version','version_info','soabi','ext_suffix','dlopen_flags'):
        if not _typed_equal(expected[key],current[key]):raise ValueError('SDK interpreter/ABI/flags differ')
    modules={r['name']:r for r in current['modules']};maps=parse_maps(raw_maps)
    required=[expected['interpreter']]+[r['origin'] for r in expected['modules']]
    for module in expected['modules']:
        if not _typed_equal(module,modules.get(module['name'])):raise ValueError('actual SDK module origin differs')
    if table is None or table.get('schema')!='loader-selected-path-table-v4':raise ValueError('bound loader table required')
    required += [dict(resolved=r['canonical_path'],identity=r['fd_before']) for r in table['paths']]
    for file in required:
        if not any(row['path']==file['resolved'] and row['inode']==file['identity']['inode']
                   and tuple(int(x,16) for x in row['device'].split(':'))==_device_parts(file['identity']['device']) for row in maps):
            raise ValueError('required SDK canonical/module mapping missing/different')
    return dict(phase=phase,pid=current['pid'],observed_context=current,static_context_pid=expected['pid'],
                context_sha256=entry.context_digest(expected),loader_selected_paths_semantic_sha256=entry.context_digest(table),
                runtime_import_verified=False,symbols_resolved=False,runtime_closure_qualified=False)
