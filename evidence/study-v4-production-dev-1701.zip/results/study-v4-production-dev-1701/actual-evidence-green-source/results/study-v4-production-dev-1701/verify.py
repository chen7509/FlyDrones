import datetime
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

root=Path.cwd();raw=Path(__file__).resolve().parent;label=sys.argv[1];cmd=sys.argv[2:]
files=['tools/benchmark/software_process_boundary.py','tests/benchmark/conftest.py','tools/benchmark/native_loader_paths_v4.py','tools/benchmark/native_entry_context_v4.py','tools/benchmark/prepare_calibration_capture_v4.py','tools/benchmark/calibration_capture_study_v4.py','tools/benchmark/calibration_capture_pipeline_v4.py','tools/benchmark/runtime_resource_binding.py','tools/benchmark/capture_contract.py','tools/benchmark/calibration_capture_study.py','tests/benchmark/test_calibration_capture_study_v4.py',str(Path(__file__).relative_to(root))]
def pins():return [dict(path=p,bytes=len(b:=(root/p).read_bytes()),sha256=hashlib.sha256(b).hexdigest()) for p in files if (root/p).exists()]
def save(name,b):
    with (raw/name).open('xb') as f:f.write(b)
snapshot=raw/(label+'-source');snapshot.mkdir();before=pins()
for row in before:
    path=snapshot/row['path'];path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes((root/row['path']).read_bytes())
env=os.environ.copy();env['PYTHONPATH']=str(root)+os.pathsep+str(root/'src')
if cmd[1:3]==['-m','pytest']:cmd+=['--basetemp',str(raw/(label+'-fixtures'))]
r=dict(argv=cmd,cwd=str(root),child_environment={k:env.get(k) for k in ('PYTHONPATH','PATH','VIRTUAL_ENV','PYTHONHOME')},before=before,started_utc=datetime.datetime.now(datetime.UTC).isoformat(),started_monotonic_ns=time.monotonic_ns())
save(label+'-start.json',json.dumps(r,indent=2).encode())
p=subprocess.run(cmd,env=env,capture_output=True,timeout=120)
r.update(exit=p.returncode,ended_utc=datetime.datetime.now(datetime.UTC).isoformat(),ended_monotonic_ns=time.monotonic_ns(),after=pins())
save(label+'.stdout',p.stdout);save(label+'.stderr',p.stderr);save(label+'.json',json.dumps(r,indent=2).encode())
print(json.dumps(dict(label=label,exit=p.returncode,stdout=p.stdout.decode(errors='replace')[-6000:],stderr=p.stderr.decode(errors='replace')[-1000:])))
