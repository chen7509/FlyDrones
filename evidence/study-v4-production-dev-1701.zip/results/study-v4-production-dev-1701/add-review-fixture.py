from pathlib import Path
p=Path('tests/benchmark/test_calibration_capture_study_v4.py')
with p.open('a',encoding='utf8') as f:f.write(r'''


@pytest.fixture
def finished_records(monkeypatch):
    """Finished semantic contract only: explicit bill/graph backends are inert.

    Actual Task2 evidence and original graph replay have separate tests above.
    These native pins are protocol metadata, not actual descriptor observations.
    """
    import copy
    import hashlib
    import json
    from pathlib import PurePosixPath as P
    from types import SimpleNamespace
    from tools.benchmark import calibration_capture_pipeline_v4 as p
    from tools.benchmark import calibration_capture_contract as raw
    from tools.benchmark import audit_live_wire_resources as graph
    from tools.benchmark.agent_capture_runtime import AGENT_SHA256,BUNDLE_SHA256,LIBRARY_SHA256

    def sha(data):return hashlib.sha256(data).hexdigest()
    def pin(path,data=b'protocol',override=None):
        identity=dict(device=1,inode=1,mode=33188,size=len(data),mtime_ns=1,ctime_ns=1)
        return dict(requested=path,resolved=path,links=[],identity=identity,path_identity=dict(identity),
                    bytes=len(data),sha256=override or sha(data))
    root='/fixture/sdk';folder=P(root)/'results/target-bearing-runtime-freeze-v4-dev-1701/frozen-study-v4'
    source=P(root)/'results/target-bearing-scene-production-dev-1701/actual-scene-v3'
    registry=p.native_registry(root,'/usr/bin/python3')
    values={r:b'protocol-source' for r in registry}
    values['logger_topics']=(ROOT/'config/px4/source-diagnostic-v1/logger_topics.txt').read_bytes()
    values['logger_profile']=(ROOT/'config/px4/source-diagnostic-v1/profile.json').read_bytes()
    manifest=dict(files={'scene-load.json':dict(bytes=3,sha256=sha(b'xxx'))})
    values['scene_manifest']=p.entry._bytes(manifest)
    monkeypatch.setattr(raw,'SCENE_MANIFEST_SHA',sha(values['scene_manifest']))
    load=dict(geometry={},design={},qualification=dict(p.QUALIFICATION))
    values['scene_load']=p.entry._bytes(load)
    manifest['files']['scene-load.json']=dict(bytes=len(values['scene_load']),sha256=sha(values['scene_load']))
    values['scene_manifest']=p.entry._bytes(manifest)
    monkeypatch.setattr(raw,'SCENE_MANIFEST_SHA',sha(values['scene_manifest']))
    scene=dict(schema='target-bearing-scene-selection-v1',path=str(source),manifest_sha256=sha(values['scene_manifest']),
               files=dict(manifest['files'],**{'manifest.json':dict(bytes=len(values['scene_manifest']),sha256=sha(values['scene_manifest']))}),**load)
    context=dict(pid=123,interpreter=pin('/usr/bin/python3'))
    values['context']=p.entry._bytes(context)
    agent=dict(schema='capture-agent-runtime-v1',bundle='/cache/bundle',binary='/cache/Agent',lib_dir='/cache/lib',port=18888)
    values['agent']=p.entry._bytes(agent)
    values['wire']=p.entry._bytes(dict(schema='capture-wire-startup-v2',session_id='inert',sim_origin_ns=0,remote_origin_ns=1,startup_max_wall_ns=100))
    baseline=dict(schema='independent-entry-baseline-v4',files=[],provenance=dict(
        method='independent-owned-descriptor-stream-v4',pid=123,observer_code_sha256=sha(values['dependency_code']),
        started_monotonic_ns=1,ended_monotonic_ns=2))
    values['baseline']=p.entry._bytes(baseline)
    bill=dict(files=[],entries=[],selected_paths=[],agent_paths=[agent['binary'],*[str(P(agent['lib_dir'])/n) for n in sorted(LIBRARY_SHA256)]],agent_lib=agent['lib_dir'])
    values['entry_bill']=p.entry._bytes(bill)
    values['transport']=p.entry._bytes(dict(schema='entry-artifact-transport-v4',items=[]))
    table=dict(schema='loader-selected-path-table-v4',paths=[],context_sha256=p.entry.context_digest(context),
               baseline_sha256=sha(values['baseline']),bill_sha256=sha(values['entry_bill']),transport_sha256=sha(values['transport']))
    values['table']=p.entry._bytes(table)
    extra=[pin(agent['bundle'],override=BUNDLE_SHA256),pin(agent['binary'],override=AGENT_SHA256)]
    extra += [pin(str(P(agent['lib_dir'])/n),override=v) for n,v in sorted(LIBRARY_SHA256.items())]
    for name,r in scene['files'].items():
        for prefix in (source,folder/'capture-input-v1'):
            extra.append(pin(str(prefix/name),b'0'*r['bytes'],r['sha256']))
    binding=dict(schema='capture-resource-binding-v4',capture_profile='target-bearing-raw-v1',
                 inventory={role:[registry[name]] for name,role in p.EVIDENCE_ROLES.items()},
                 environment={'PATH':'/usr/bin:/bin'},graph={'environment':{'PATH':'/usr/bin:/bin'}},calibration_scene=scene,
                 baseline=dict(files=[dict(pin(registry['dependency_code'],values['dependency_code']),role='runtime:project-source')]))
    preparation=dict(schema='raw-static-sdk-preparation-v4',sdk_pid=123,sdk_ticket={'inert':'reference'},
                     pre={'files':[]},after_queries={},graph={},context={},queries=[],documents_hex={},audit={'inert':True})
    monkeypatch.setattr(p,'canonical_membership',lambda *_:None)
    monkeypatch.setattr(p.entry,'audit_entry_context_bill_v4',lambda *_,**__:None)
    monkeypatch.setattr(graph,'audit_resource_graph_records',lambda **_: {'inert':True})

    def refresh():
        values['baseline']=p.entry._bytes(baseline)
        table['baseline_sha256']=sha(values['baseline']);values['table']=p.entry._bytes(table)
        # Recompute context reference after the changed table, even for negative cases.
        if 'execution' in values:
            execution=json.loads(values['execution'])
            if 'python_extension_context' in execution:
                execution['python_extension_context']['loader_selected_paths_sha256']=sha(values['table'])
                execution['python_extension_context']['loader_selected_paths_semantic_sha256']=p.entry.context_digest(table)
            values['execution']=p.entry._bytes(execution)
        values['binding']=p.entry._bytes(binding)
        preparation.update(binding_sha256=sha(values['binding']),execution_sha256=sha(values['execution']),entry_bill_sha256=sha(values['entry_bill']))
        values['preparation']=p.entry._bytes(preparation)
        rows={r:dict(role=r,source=pin(path,values[r]),member=r+'.bin') for r,path in registry.items()}
        study=dict(schema='target-bearing-frozen-raw-study-v4',qualification=dict(p.QUALIFICATION),files={r:v['source'] for r,v in rows.items()})
        values['study']=p.entry._bytes(study);studysha=sha(values['study'])
        rows['study']=dict(role='study',source=pin(str(folder/'study.json'),values['study']),member='study.bin')
        native={r['source']['requested']:r['source'] for r in rows.values()}
        native.update({r['requested']:r for r in extra})
        native.update({r['requested']:{k:v for k,v in r.items() if k!='role'} for r in binding['baseline']['files']})
        terminal=p.entry._bytes(dict(study_sha256=studysha,sdk_pid=123,ticket_sha256=p.entry.context_digest(preparation['sdk_ticket']),preparation_sha256=sha(values['preparation'])))
        index=dict(schema='finished-static-artifacts-v4',files=list(rows.values()),sdk_terminal_sha256=sha(terminal))
        identity=dict(schema='validated-static-prepost-receipts-v4',source_root=root,files=list(native.values()),study_sha256=studysha,index_sha256=sha(p.entry._bytes(index)),sdk_exit=0)
        return identity,studysha,index,copy.deepcopy(values),terminal,lambda *_:b''

    rows={r:dict(source=pin(path,values[r])) for r,path in registry.items()}
    native={r['requested']:r for r in extra}
    values['execution']=p.entry._bytes(p.expected_finished_execution(root,binding,values,rows,native))
    return SimpleNamespace(p=p,values=values,registry=registry,baseline=baseline,refresh=refresh)


def test_finished_semantic_contract_accepts_inert_complete_records(finished_records):
    f=finished_records
    assert f.p.audit_finished_records(*f.refresh())['transported_finished_metadata']


@pytest.mark.parametrize('mutation',['remove','extra','path'])
def test_finished_exact_registry_rejects_coordinated_changes(finished_records,mutation):
    f=finished_records
    if mutation=='remove':f.registry.pop('dispatcher')
    elif mutation=='extra':f.registry['other']='/fixture/sdk/other';f.values['other']=b'other'
    else:f.registry['dispatcher']='/fixture/sdk/alternate-dispatcher.py'
    with pytest.raises(ValueError,match='registry'):
        f.p.audit_finished_records(*f.refresh())


@pytest.mark.parametrize('mutation',['owned_ulog_source','record_depth_payload','logger_diagnostic','launch_environment','unexpected'])
def test_finished_exact_execution_rejects_refreshed_semantic_changes(finished_records,mutation):
    import json
    f=finished_records;execution=json.loads(f.values['execution'])
    if mutation=='launch_environment':execution[mutation]['PATH']='/altered'
    elif mutation=='unexpected':execution['unexpected']=True
    else:execution.pop(mutation)
    f.values['execution']=f.p.entry._bytes(execution)
    with pytest.raises(ValueError,match='execution contract'):
        f.p.audit_finished_records(*f.refresh())


@pytest.mark.parametrize('mutation',['absent','method','pid','source','clock'])
def test_finished_independent_provenance_rejects_coordinated_changes(finished_records,mutation):
    f=finished_records
    if mutation=='absent':f.baseline.pop('provenance')
    else:
        key,value={'method':('method','copied-from-bill'),'pid':('pid',456),'source':('observer_code_sha256','0'*64),'clock':('ended_monotonic_ns',0)}[mutation]
        f.baseline['provenance'][key]=value
    with pytest.raises(ValueError,match='provenance'):
        f.p.audit_finished_records(*f.refresh())
''')
