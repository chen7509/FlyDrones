import hashlib,json,subprocess
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def save(name,b):
    with (raw/name).open('xb') as f:f.write(b)
files=subprocess.check_output(['git','ls-files','-z','src','tools','tests','configs']).split(b'\0')
save('product-before.json',json.dumps([dict(path=x.decode(),bytes=len(b:=(root/x.decode()).read_bytes()),sha256=sha(b)) for x in files if x],indent=2).encode())
names=['docs/TARGET_BEARING_ENTRY_CONTEXT_V4_PRODUCTION_REPORT.md','docs/TARGET_BEARING_STATIC_V3_HARNESS_FAILURE_REPORT.md','docs/TARGET_BEARING_LOADER_SELECTED_PATH_RESEARCH_REPORT.md','docs/superpowers/plans/2026-10-15-loader-selected-path-production.md','docs/superpowers/specs/2026-10-15-loader-selected-path-production-design.md','evidence/entry-context-v4-production-publication.json','results/entry-context-v4-production-dev-1701/NEXT_PHASE.md','evidence/flydrones-history-through-admitted-executor-dev-1701.json','evidence/flydrones-history-through-loader-path-research-dev-1701.json']
rows=[]
for n in names:
    b=(root/n).read_bytes();text=b.decode('utf-8-sig')
    if n.endswith('.json'):json.loads(text)
    rows.append(dict(path=n,bytes=len(b),sha256=sha(b),full_bytes_read=True))
save('preflight-read.json',json.dumps(rows,indent=2).encode())
save('initial-readonly.py',(root/'results/entry-context-v4-production-dev-1701/initial-readonly.py').read_bytes())
p=subprocess.run(['python',str(raw/'initial-readonly.py')],capture_output=True,timeout=65)
save('initial-readonly.stdout',p.stdout);save('initial-readonly.stderr',p.stderr);assert p.returncode==0
print(p.stdout.decode())
