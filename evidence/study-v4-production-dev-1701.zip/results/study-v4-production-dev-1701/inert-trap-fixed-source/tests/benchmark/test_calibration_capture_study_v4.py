"""Inert v4 preparation/study/runtime integration, never a target dispatcher."""
import builtins
import importlib
import sys
from pathlib import Path

import pytest

ROOT=Path(__file__).resolve().parents[2]
MODULES=('prepare_calibration_capture_v4','calibration_capture_study_v4')


@pytest.mark.parametrize('name',MODULES)
@pytest.mark.parametrize('main',[False,True])
def test_inert_module_body_before_any_import_or_io(name,main,monkeypatch):
    source=(ROOT/'tools/benchmark'/f'{name}.py').read_text()
    calls=[];original=builtins.__import__
    def trap(module,*args,**kwargs):
        if module=='sys':return sys
        calls.append(module);raise AssertionError('nonprimitive import '+module)
    def no_io(*args,**kwargs):raise AssertionError('unexpected IO')
    namespace=dict(__name__='__main__' if main else 'fixture',__file__=str(ROOT/'tools/benchmark'/f'{name}.py'))
    with monkeypatch.context() as patch:
        patch.setattr(builtins,'open',no_io);patch.setattr(builtins,'__import__',trap)
        if main:
            with pytest.raises(SystemExit):exec(compile(source,namespace['__file__'],'exec'),namespace)
        else:exec(compile(source,namespace['__file__'],'exec'),namespace)
    assert not calls and original is builtins.__import__


@pytest.mark.parametrize('name,function',[('prepare_calibration_capture_v4','prepare_v4'),('calibration_capture_study_v4','publish_study_v4')])
@pytest.mark.parametrize('ticket',[None,{}, {'schema':'static-sdk-ticket-reference-v4','nonce':'a'*64}])
def test_invalid_ticket_refuses_before_deferred_effects(name,function,ticket,monkeypatch):
    module=importlib.import_module('tools.benchmark.'+name)
    def trap(*args,**kwargs):raise AssertionError('deferred effect before admission')
    with monkeypatch.context() as patch:
        patch.setattr(builtins,'open',trap);patch.setattr(builtins,'__import__',trap)
        with pytest.raises(ValueError):getattr(module,function)(ticket)


def test_runtime_v4_api_is_real_and_guard_installed():
    import subprocess
    from tools.benchmark import calibration_capture_study_v4 as study
    assert subprocess.Popen._execute_child.__name__=='denied'
    assert callable(study.audit_v4_preparation) and callable(study.verify_study_v4)
