import ast
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent
old=(root/'results/entry-context-v4-production-dev-1701/seal.py').read_text()
old=old.replace("name='entry-context-v4-production-dev-1701'","name='study-v4-production-dev-1701'")
start=old.index('explicit=');end=old.index('\nfiles=',start)
sources=['tools/benchmark/'+n+'.py' for n in ('native_loader_paths_v4','native_entry_context_v4','prepare_calibration_capture_v4','calibration_capture_study_v4','calibration_capture_pipeline_v4','capture_contract','calibration_capture_contract','runtime_resource_binding','calibration_capture_study','bound_resource_graph','audit_live_wire_resources','software_process_boundary','declared_runtime_snapshot')]
sources += ['tests/benchmark/test_calibration_capture_study_v4.py','tests/benchmark/conftest.py',
 'config/px4/source-diagnostic-v1/logger_topics.txt','config/px4/source-diagnostic-v1/profile.json',
 'docs/TARGET_BEARING_STUDY_V4_PRODUCTION_REPORT.md','docs/superpowers/plans/2026-10-15-loader-selected-path-production.md','docs/superpowers/specs/2026-10-15-loader-selected-path-production-design.md',
 'docs/TARGET_BEARING_ENTRY_CONTEXT_V4_PRODUCTION_REPORT.md','docs/TARGET_BEARING_STATIC_V3_HARNESS_FAILURE_REPORT.md','docs/TARGET_BEARING_LOADER_SELECTED_PATH_RESEARCH_REPORT.md',
 'evidence/flydrones-history-through-admitted-executor-dev-1701.json','evidence/flydrones-history-through-loader-path-research-dev-1701.json','evidence/entry-context-v4-production-publication.json']
old=old[:start]+'explicit='+repr(sources)+old[end:]
old=old.replace('entry-context-v4-production-exact-map-v1','study-v4-production-exact-map-v1').replace('Task2 software only;Task3..5 pending','Task3 software only;Task4/5 pending').replace('Task2 first2software boxesdone,lastpublicationpending;Task3..5pending','Task3 first3software boxesdone,lastpublicationpending;Task4/5pending')
ast.parse(old)
with (raw/'seal.py').open('x',encoding='utf8') as f:f.write(old)
print('new exclusive Task3 seal helper prepared')
