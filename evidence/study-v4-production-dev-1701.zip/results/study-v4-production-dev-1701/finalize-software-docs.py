import ast,hashlib,json
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def save(name,value):
    with (raw/name).open('x',encoding='utf8') as f:json.dump(value,f,indent=2)
before=json.loads((raw/'product-before.json').read_bytes());changed=[]
for row in before:
    if sha((root/row['path']).read_bytes())!=row['sha256']:changed.append(row['path'])
allowed=set(json.loads((raw/'product-preservation-postsoftware.json').read_bytes())['modified'])|{'tools/benchmark/calibration_capture_contract.py'}
assert set(changed)==allowed
save('product-preservation-after-fix-pass.json',dict(count=len(before),modified=changed,all_other_old_byte_same=True,
 scope='POSTfix software;8 explicit shared/component changes;no consumed version-specific product changed',
 prior_record_preserved='product-preservation-postsoftware.json'))
rows=[]
for name in ('prepare_calibration_capture_v4','calibration_capture_study_v4'):
    path=root/'tools/benchmark'/(name+'.py');data=path.read_bytes();tree=ast.parse(data)
    imports=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom))]
    assert len(imports)==1 and isinstance(imports[0],ast.Import) and [x.name for x in imports[0].names]==['sys']
    assert all(isinstance(n,(ast.Expr,ast.Import,ast.FunctionDef,ast.If)) for n in tree.body)
    rows.append(dict(path=path.relative_to(root).as_posix(),sha256=sha(data),top_imports=['sys'],
                     scope='AST module body plus retained inert import/file/process denial tests;not cold interpreter/FFI sandbox'))
save('source-import-audit.json',dict(modules=rows,late_pipeline_has_no_target_import=True,
 direct_pipeline_main_refuses_before_normal_imports=True,actual_sdk_run=False))
assert not (root/'results/target-bearing-runtime-freeze-v4-dev-1701').exists()
assert not (root/'results/target-bearing-physical-capture-dev-1701').exists()
save('final-software-absence.json',dict(v4_fixed_parent_absent=True,physical_fixed_attempt_absent=True,scope='host software observation;not dispatch admission'))
plan=root/'docs/superpowers/plans/2026-10-15-loader-selected-path-production.md'
b=plan.read_bytes();start=b.index(b'## Task3');end=b.index(b'## Task4');section=b[start:end]
assert section.count(b'- [ ]')==4 and b'- [x]' not in section
section=section.replace(b'- [ ]',b'- [x]',3)
plan.write_bytes(b[:start]+section+b[end:])
spec=root/'docs/superpowers/specs/2026-10-15-loader-selected-path-production-design.md'
with spec.open('a',encoding='utf8') as f:f.write('''

## Task3 implementation contract for the pending Task4 receiver

The distinct late helper `calibration_capture_pipeline_v4.py` belongs in the full current project/source recipe pins. The inert entry modules require an already-loaded literal `static_v4_bootstrap.revalidate_sdk_reference(ticket)` returning exactly the revalidated SDK context schema/current PID/original reference, then revalidate before preparation, publication and terminal completion. This API is still absent: no fixture or matching-shaped dict authorizes an actual SDK run.

The future Windows `static_v4_identity.revalidate_finished_study(path, sha, require_absent=...)` returns exactly schema `validated-static-prepost-receipts-v4`, `files`, `source_root`, `study_sha256`, `index_sha256`, `sdk_exit`. The native absolute `source_root` is independently bound by Task4 to the literal recipe/current native project cwd and full source pre/post receipts; it is not accepted as a caller-selected root or a matching-shaped object. Every file pin is the complete native requested/resolved/link/fstat/byte/SHA record from those receipts. Task3 then reconstructs the fixed role/path registry with POSIX semantics, including logger topics/profile bytes, checks the independent descriptor provenance against that native source pin and SDK PID/monotonic interval, reconstructs the entire execution contract, and audits original graph and retained bill/query/terminal bytes. Windows checkout hashes or host Path reinterpretation cannot replace native evidence.

The SDK publishes staged study bytes in its original PID, persists successful final scope facts, then closes/readbacks the SDK terminal and finished-file transport before exclusive terminal publication. The Windows receiver only audits finished output after actual child exit and full identity revalidation. Transported file, graph and inert receipt protocols are software evidence, not SDK admission, actual cross-host atomic/filesystem acceptance or source authentication. Source/physical readiness and all qualification flags stay false until their separate actual gates and audits pass.
''')
note='''# Executor's single review fix pass — Task3 software only

Fresh review is retained unchanged as C0/I4/M0. No second whole-code review was requested. I1 was reproduced through the actual production inventory helper with the observer already loaded:1 genuine role assertion failure; project source now owns the path before generic modules. I2/I3/I4 were reproduced through the finished-record auditor with coordinated byte/digest/native-pin joins refreshed:13 genuine DIDNOTRAISE failures and1 complete acceptance pass. The three registry changes, five execution mutations and five provenance mutations are independently asserted. The finished fixture explicitly replaces only the already separately tested bill/canonical/graph backends with inert protocols; its native pins/scene/Agent are protocol metadata, not real descriptor/SDK/Linux acceptance.

Fixes enforce fixed native role/path membership, reconstruct the complete execution contract from validated bytes/native pins and the binding's actual launch environment, and reuse the independent baseline method/PID/source/monotonic/schema/membership check. Pure shared wire/raw-graph assembly preserves native default validation while portable calls require an explicit raw record provider. Observer SHA comes from the validated native current-source role, never a Windows hash substituted for receipt evidence. A source-root identity field is an explicit still-pending Task4 recipe contract. Focused fix15pass; final51pass43.14s after format/import-order fixes;16 necessary execution neighbors pass1.17s, earlier61graph neighbors and10ordinary/runtime neighbors pass. Final Ruff0/diff0. Additional two denial/ordinary-provider coverage tests passed directly without manufactured RED. Earlier49pass43.98s and all lint/tool/fixture failures are retained.

The original raw recorder/snapshots remain: initial12pins, later14 after explicit graph-helper integration, final15 after pure raw-graph shared helper; per-run recorder SHA/argv/env/exclusive fixtures distinguish them. Formatter runs are recorded mutations. The final51 source pins are stable; the earlier asynchronously launched lint saw the newly appended coverage test and reported its import-order failure, not a native/product behavior failure. A shell Python quoting SyntaxError before writing and an attempted read of a nonexistent logger profile source path were tooling-only, retained in notes; no experiment was repaired or replayed.

No target process, SDK, native observer, ldd/readelf/import/dlopen, renderer, physics, source/calibration consumer or fixed attempt ran. Task4/5 remain entirely pending. Existing consumed/unknown failures remain unchanged. Software fix-pass evidence is not a replacement independent native approval.
'''
with (raw/'executor-fix-pass.md').open('x',encoding='utf8') as f:f.write(note)
report=root/'docs/TARGET_BEARING_STUDY_V4_PRODUCTION_REPORT.md'
with report.open('a',encoding='utf8') as f:f.write('\n\n'+note+'\n\nFinal preservation adds one explicitly shared pure raw-graph assembler file to the prior seven integration changes:811 old product files,8 authorized changes,all others byte-identical. The prior seven-change observation is preserved rather than rewritten.291 historical ZIPs/845182128B were fully streamed unchanged as POSTsoftware preservation, never native prepins. The canonical ZIP/manifest and independent delivery audit are recorded in the publication ledger; its prepublication Task3 final checkbox remains pending until the sole declared publication byte changes. Task4/5 are unchecked. Working/archive and Git-normalized identities are recorded separately.\n')
with (raw/'progress.md').open('a',encoding='utf8') as f:f.write('\n\nSingle review fix pass C0/I4/M0 original retained. Actual inventory1RED plus finished13RED/1pass→15focusedGREEN, final51GREEN/Ruff0/diff0. Added pure raw-graph/wire shared record assembly and explicit raw-only record provider; source_root/native receipt contract is pending Task4. Late test append overlapped earlier lint only; final51 recorded after all source edits. No second whole-code review. See executor-fix-pass.md.\n')
print('docs/first3Task3boxes/AST/preservation written;finalpublicationbox pending;Task4/5pending')
