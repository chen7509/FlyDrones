"""Read source reference as data; never import a consumed producer/parser."""
import ast,hashlib,json
from pathlib import Path
root=Path.cwd();raw=Path(__file__).resolve().parent;target=root/'tools/benchmark/calibration_capture_pipeline_v4.py'
third=root/'tools/benchmark/prepare_calibration_capture_v3.py';first=root/'tools/benchmark/prepare_calibration_capture.py'
a=third.read_text();b=first.read_text()
def select(source,names):
    return '\n\n'.join(ast.get_source_segment(source,n) for n in ast.parse(source).body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names)
helpers=select(a,{'select_entries','reuse_agent_cache','timed','ClockedClient','licenses'})+'\n\n'+select(b,{'required_plugins','scope_before'})
body=select(a,{'prepare_v3'})
body=body.replace('def prepare_v3(unit):','def _prepare_sdk(ticket,state):\n    unit=ticket["unit"]')
body=body.replace('calibration_capture_study_v3','calibration_capture_study_v4').replace('audit_v3_preparation','audit_v4_preparation')
body=body.replace('discover_entry_context(','entry.discover_entry_context_v4(').replace('python_context = collect_python_context()','python_context = entry.collect_python_context()')
body=body.replace('context_digest(','entry.context_digest(').replace('publish_study_v3()','publish_study_v4(ticket)')
body=body.replace('raw-static-sdk-preparation-v3','raw-static-sdk-preparation-v4')
start=body.index('        add("graph:dependencies"');end=body.index('        add("runtime:python-modules"',start)
body=body[:start]+'''        evidence=capture_entry_evidence(bill,python_context,sdk/'entry-evidence')
        add('graph:dependencies',[r['file']['resolved'] for r in bill['entries']]+[r['canonical_path'] for r in bill['selected_paths']])
        for name,role in EVIDENCE_ROLES.items():add(role,[evidence['paths'][name]])
        add('runtime:entry-context-bill-v4',[sdk/'entry-dependencies/entry-bill.json'])
        add('runtime:entry-context-source-artifacts-v4',sorted((sdk/'entry-dependencies').glob('query-*.json'))+[sdk/'entry-dependencies/entry-bill-terminal.json',sdk/'entry-dependencies/entry-bill-terminal.prepared.json'])
        add('runtime:entry-context-transport-members-v4',sorted((sdk/'entry-evidence').glob('artifact-*.bin')))
        add('runtime:entry-dependency-files',[r['requested'] for r in bill['declared_before']])
'''+body[end:]
# Preserve exact requested current-module spellings, not suffix-only authority.
body=body.replace('native = [str(Path("/usr/bin/python3"))]','native = [entry.tool_paths()["python"]]')
body=body.replace('        entries, candidates = select_entries(','        native.extend(m["origin"]["requested"] for m in entry.collect_python_context()["modules"])\n        entries, candidates = select_entries(')
body=body.replace('        write_manifest(FOLDER / "execution-contract.json", contract)','        contract=execution_contract(args,env)\n        write_manifest(FOLDER / "execution-contract.json", contract)')
body=body.replace('            audit=None,','            audit=None,\n            entry_evidence=audit_entry_evidence(evidence["paths"],bill,python_context),\n            sdk_ticket=dict(ticket),\n            sdk_pid=current_pid(),')
body=body.replace('python_context_file_sha256=hashlib.sha256((sdk / "python-context.json").read_bytes()).hexdigest(),','python_context_file_sha256=digest(evidence["paths"]["context"]),')
imports='''
import datetime
import importlib.metadata
import re
import subprocess
import sys
from tools.benchmark.calibration_capture_study import SOURCE,arguments
from tools.benchmark.capture_contract import execution_contract
from tools.benchmark.calibration_capture_study_v4 import publish_study_v4
BASE_ENV=dict(entry.ENV)
CATALOG=ROOT/'results/declared-launch-environment-dev-1701/dry-v1/runtime-binding-v3.json'
AGENT=ROOT/'results/agent-capture-contract-dev-1701/agent-runtime.json'
V1_FOLDER=ROOT/'results/target-bearing-runtime-freeze-dev-1701/frozen-study-v1'
RENDERER='/usr/lib/x86_64-linux-gnu/gz-rendering-8/engine-plugins/libgz-rendering8-ogre2.so.8.2.3'
def _run_tool(argv,env):
    row=entry._run(argv,env,str(ROOT))
    return dict(row,exit=row['returncode'],output_limit_exceeded=row['output_limited'])
'''
with target.open('a',encoding='utf-8') as f:f.write('\n'+imports+'\n'+helpers+'\n\n'+body+'\n')
with (raw/'pipeline-reference-derivation.json').open('x') as f:json.dump(dict(scope='AST source data reuse of generic behavior;no consumed import/execute or source mutation',sources=[dict(path=str(p.relative_to(root)),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in (third,first)],helper_names=['select_entries','reuse_agent_cache','timed','ClockedClient','licenses','required_plugins','scope_before'],actual_native_execution=False),f,indent=2)
print('New v4 late pipeline generated from retained source data plus explicit v4 joins;not executed')
