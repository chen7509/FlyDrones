import ast
import datetime
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
import psutil

root=Path.cwd();sys.path.insert(0,str(root))
from tools.benchmark.run_openvins_dataset_consumer import heavy_process
out=Path(__file__).resolve().parent
code="""import os,sys
mem={k:v for k,v in (line.split(':',1) for line in open('/proc/meminfo').read().splitlines())}
rows=[]
for n in os.listdir('/proc'):
 if not n.isdigit() or int(n) in (os.getpid(),os.getppid()):continue
 try:
  name=open('/proc/'+n+'/comm').read().strip();cmd=open('/proc/'+n+'/cmdline','rb').read().replace(b'\\0',b' ').decode(errors='replace')
  rows.append(dict(pid=int(n),name=name,cmdline=cmd))
 except OSError:pass
print(repr(dict(available=int(mem['MemAvailable'].split()[0])*1024,processes=rows)))
"""
argv=['wsl','-d','Ubuntu','--','/usr/bin/python3','-S','-c',code]
with (out/'initial-readonly-recipe.json').open('xb') as f:f.write(json.dumps(dict(argv=argv,linux_import_audit='-S disables site startup; only explicit imports os/sys, builtin open/repr serializer; no json/pathlib/sdk/selected-target imports, no mapped-closure claim',purpose='one readonly resource/process snapshot only'),indent=2).encode())
p=subprocess.run(argv,capture_output=True,timeout=30);assert p.returncode==0
data=ast.literal_eval(p.stdout.decode());own={os.getpid(),*(x.pid for x in psutil.Process().parents())}
win=[dict(pid=x.pid,**x.info) for x in psutil.process_iter(['name','cmdline']) if x.pid not in own]
blocked=[x for x in data['processes']+win if heavy_process(x)]
docker=subprocess.run(['docker','ps','--no-trunc','--format','{{json .}}'],capture_output=True,timeout=30)
def identity(x):
    c=x['cmdline'] if isinstance(x['cmdline'],str) else ' '.join(x['cmdline'] or [])
    return dict(pid=x['pid'],name=x['name'],argv_sha256=hashlib.sha256(c.encode()).hexdigest())
private=dict(windows_available=psutil.virtual_memory().available,wsl_available=data['available'],windows=[identity(x) for x in win],wsl=[identity(x) for x in data['processes']],blocked=[identity(x) for x in blocked],docker_exit=docker.returncode,docker_running=docker.stdout.decode(),wsl_stderr_hex=p.stderr.hex())
b=json.dumps(private,indent=2).encode()
with (out/'initial-resource-private.json').open('xb') as f:f.write(b)
public={k:private[k] for k in ['windows_available','wsl_available','blocked','docker_exit','docker_running']}
public.update(utc=datetime.datetime.now(datetime.UTC).isoformat(),raw_bytes=len(b),raw_sha256=hashlib.sha256(b).hexdigest(),policy='LOCAL_UNPUBLISHED full unclassified identities retained; public derivative only',dispatch=False,gate_poll=False,original2GiB=private['windows_available']>=2*1024**3 and data['available']>=2*1024**3)
with (out/'initial-resource-public.json').open('xb') as f:f.write(json.dumps(public,indent=2).encode())
print(json.dumps(public))
