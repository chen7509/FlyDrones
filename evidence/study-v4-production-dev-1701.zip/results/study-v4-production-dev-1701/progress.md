# SDD ledger — plan: docs/superpowers/plans/2026-10-15-loader-selected-path-production.md

Task1/2 complete a70179ec; Task3 inline/TDD. Existing isolated branch and blocked goal verified. Initial snapshot once Win1624821760/WSL7045992448/no competition/Dockerempty, not admission, no refresh. Quiet heartbeat and preservation override narration/deletion.

Ruling: inert prepare/study modules require already-loaded fixed bootstrap revalidation before deferred imports. Task4 absent always refuses. Explicit inert receipt protocols are software only; real literal receipt/currentPID/scope/source validation remains Task4, never a truthydict qualification.

Ruling: use a distinct late-imported v4 pipeline helper retaining full SDK/material/include/notices behavior. Read old generic helper source as reference; no consumed prepare/parser module imported/executed. Additional new helper must enter currentcode/recipe pins.

Ruling: explicit artifact-reader parameters transport original query refs/bytes/digests through auditors without global monkeypatch or raw-reference rewriting. Independent baseline witness has its own observation/provenance artifact. Source refs and controlled observation do not authenticate arbitrary Python or hostile filesystem races.

First multi-file apply_patch failed syntax before writing any files; retained as tooling-only, not product RED.


Single review fix pass C0/I4/M0 original retained. Actual inventory1RED plus finished13RED/1pass→15focusedGREEN, final51GREEN/Ruff0/diff0. Added pure raw-graph/wire shared record assembly and explicit raw-only record provider; source_root/native receipt contract is pending Task4. Late test append overlapped earlier lint only; final51 recorded after all source edits. No second whole-code review. See executor-fix-pass.md.
