# Fresh independent Task3 software review

Scope: base a70179ecdbfed8fd28a73dd91db7d020f48767bc plus the current seven tracked modifications and four new source/test files. Read-only inspection of source, diff, design, Task3 plan, production report and progress ledger. No tests, native/SDK/target commands, consumed modules/suites, source/index edits or additional agents were run. This is software review only and supplies no static, physical, source, measurement or readiness approval.

Assessment: **changes required**. Critical: 0. Important: 4. Minor: 0.

## I1 — Actual producer assigns the required observer source the wrong role

Location: tools/benchmark/calibration_capture_pipeline_v4.py:1166-1170; related requirements at 343-347 and deduplication at 1105-1111.

`modules` includes `native_entry_context_v4.__file__`, since that module is already imported and the loop at 1126-1129 includes every loaded module with an existing file. The producer adds those files as `runtime:python-modules` before adding `runtime:project-source`. `add` deduplicates globally, so this observer can never receive `runtime:project-source`. `validate_evidence_binding` explicitly requires that exact role and is reached through `validate_binding(binding)` at 1232. Thus a future otherwise valid admitted execution always fails after doing the preceding queries/copy/work.

The fixture at tests/benchmark/test_calibration_capture_study_v4.py:211-215 manually gives the observer the desired role, so the passing binding tests do not exercise the production ownership policy. Give project source ownership precedence, or derive an explicit unique role policy that both producer and auditor accept. Add an inert regression through the actual inventory assembly with the observer already present in loaded modules; check both its final role and successful actual evidence validation. Do not weaken the current-code byte join.

## I2 — Finished Windows audit does not enforce the fixed study role/path registry

Location: tools/benchmark/calibration_capture_pipeline_v4.py:604-608.

The only role-set requirement compares the transported index with the transported study itself. Unlike `_verify_profile_study` (calibration_capture_study.py:160-170), this path never compares with the fixed v4 role set and fixed native requested paths. Roles such as `collector`, `dispatcher`, `scope`, `study_code`, `producer_code`, `dependency_code`, `pipeline_code`, `paths_code` and `python` are not otherwise consumed as named execution inputs by `audit_finished_records`. Removing one from both index and study, or assigning an alternate valid native source pin to it, therefore bypasses that contract after maintaining the associated byte/digest joins. The general source baseline does not establish the named entry/command role.

Task4's contracted result authenticates retained pre/post file pins, index digest, study digest and child exit. It does not replace this Task3 semantic registry check. Add a pure native-path registry helper independent of current host `Path`, require the exact expected role set, and require each requested role path to match its literal native study/source/interpreter path. Inert retained-record regressions should remove an unused command role, add an extra role, and substitute a command path while keeping the records and hashes internally consistent; all must refuse.

## I3 — Finished Windows audit accepts incomplete/changed execution contracts

Location: tools/benchmark/calibration_capture_pipeline_v4.py:637-667; compare calibration_capture_study.py:131-147.

Portable audit checks eight workload values, a small profile/input subset, seed and selected Agent/wire/context joins. It never reconstructs or equivalently validates the complete fixed execution contract. For example, removing `owned_ulog_source`, `record_depth_payload` or `logger_diagnostic`, or changing `launch_environment`, does not affect any execution check in this function. An internally hash-consistent retained study with those changes can still return success, even though the normal native verifier rejects it through `verify_execution_join` and these source/ULog/environment requirements are explicitly part of Task3.

Retained pre/post pins prove which execution bytes were observed, not that those bytes describe the required workload. Implement a portable exact execution comparison or a complete pure validator preserving the current producer contract, including exact schema/keys, all inputs, lookup environment, raw readiness/profile, logger/source/ULog/depth declarations and prepared-input path. Add independent inert finished-record regressions with the byte/digest/source joins refreshed so the failure is genuinely the missing semantic contract check.

## I4 — Finished Windows audit omits independent baseline provenance validation

Location: tools/benchmark/calibration_capture_pipeline_v4.py:626-628; compare the complete validation at 154-169.

`audit_finished_records` reads only `baseline["files"]` and passes that list to the entry auditor. It never validates `independent-entry-baseline-v4`, the exact provenance field set, independent descriptor method, observing SDK PID, observer source SHA or local monotonic interval. Replacing this artifact with `{"files": bill["files"]}` and refreshing its table/transported-file hash joins therefore passes the independent-baseline part of portable audit. This removes exactly the copied-bill versus independently observed provenance distinction that the native validation was added to enforce.

Extract and reuse the provenance/schema/membership validation as a pure helper. On the finished path, join its observer SHA to the validated native current-source pin rather than hashing a Windows checkout as a substitute for native receipt evidence. Test absent provenance, copied-bill method, wrong PID, wrong source pin and reversed interval through the finished audit. This is a controlled-evidence semantic check; it does not claim cryptographic authentication or protection from arbitrary in-process Python.

## Review boundary and verification observations

The inert entry modules defer project/JSON imports until the literal already-loaded bootstrap API returns, direct-main paths refuse, and the late prepare/publish APIs revalidate before their SDK preparation/publication effects. Missing Task4 bootstrap/identity APIs currently fail closed. Their absence is intentional pending Task4, not a finding here. The post-finally SDK completion ordering is present. Runtime self-context failures latch without advancing completed phases, and owned PX4/Agent observations remain separate. Ordinary execution-contract calls retain the explicit raw-profile guard.

The existing tests use the real Task2 producer with explicit inert fixtures and the report candidly identifies their limitations; no reported native result is inferred from them. However there is no full finished-record acceptance fixture or production inventory ownership regression covering I1-I4. The existing terminal ordering test replaces both work and finish with protocols, which verifies orchestration only. The terminal POSIX-reference test deliberately stubs content auditing, so it does not establish full cross-host bill acceptance. These are coverage limits, not claims that tests were executed during this review or that native behavior is qualified.

One executor fix pass with genuine behavior RED-to-GREEN regressions is needed. No repeat whole review or native dispatch is authorized by this report. Task4 actual bootstrap/identity/coordinator/recipe and Task5 static/physical work remain pending under their original gates; all qualifications remain false.
