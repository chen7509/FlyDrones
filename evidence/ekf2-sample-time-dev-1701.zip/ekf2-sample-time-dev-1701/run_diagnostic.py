"""One fixed development ULog investigation, not a live producer or trainer."""
import hashlib
import io
import json
from pathlib import Path
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
CAP = ROOT / 'results/openvins-health-physical-dev-1701-v2/development-seed-27201/capture-v1'
sys.path.insert(0, str(OUT / 'sources/pyulog-0.9.0-py3-none-any.whl'))
sys.path.insert(0, str(ROOT / 'src'))
from pyulog import ULog
import numpy as np
from flydrones.benchmark.ekf2_shadow import audit_shadow_frames, audit_state_sample_times


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write(name, value):
    with (OUT / name).open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write('\n')


def check_inputs():
    manifest = json.loads((OUT / 'prospective-inputs.json').read_text())
    for item in manifest['items']:
        raw = (ROOT / item['path']).read_bytes()
        assert len(raw) == item['bytes'] and digest(raw) == item['sha256'], item['path']
    return manifest


def main():
    start = time.perf_counter()
    check_inputs()
    archive = ROOT / 'evidence/openvins-health-contract-dev-1701.zip'
    assert digest(archive.read_bytes()) == '88c11d16ec19b52d590cd07622def74262d33837abf611cbf97bfe84f8d99347'
    ulm = json.loads((CAP / 'px4-ulog-manifest.json').read_text())
    assert len(ulm['logs']) == 1
    log = ulm['logs'][0]
    log_path = (CAP / log['path']).resolve()
    assert log_path.is_relative_to(CAP.resolve())
    raw = log_path.read_bytes()
    assert digest(raw) == log['sha256'] and len(raw) == log['bytes']
    with zipfile.ZipFile(archive) as z:
        sealed = z.read(log_path.relative_to(ROOT).as_posix())
    assert raw == sealed
    frames = json.loads((CAP / 'rgb-capture-manifest.json').read_text())['frames']
    for frame in frames:
        image_path = (CAP / frame['path']).resolve()
        assert image_path.is_relative_to(CAP.resolve())
        assert digest(image_path.read_bytes()) == frame['sha256']
    # Only the development run is consumed, and only four non-truth ULog topics.
    names = ['vehicle_local_position', 'vehicle_attitude', 'estimator_status', 'estimator_status_flags']
    ulog = ULog(io.BytesIO(raw), message_name_filter_list=names, disable_str_exceptions=False)
    assert ulog.msg_info_dict['ver_sw'] == 'd6f12ad1c4f70ad3230afd7d86e971421e02fef4'
    topics = {name: ulog.get_dataset(name, multi_instance=0).data for name in names}
    times = [frame['frame_ns'] for frame in frames]
    timing = audit_state_sample_times(times, topics)
    health = audit_shadow_frames(times, topics)
    write('state-sample-time.json', timing)
    write('publication-health-context.json', health)
    # Exact arrays consumed, for independent arithmetic checks without pyulog.
    with (OUT / 'consumed-topics.npz').open('xb') as f:
        np.savez_compressed(f, **{name+'__'+key: value for name, fields in topics.items()
                                 for key, value in fields.items()})
    topic_summary = {}
    for name in names[:2]:
        selected = [r['topics'][name] for r in timing['records'] if r['topics'][name] is not None]
        topic_summary[name] = {}
        for field in ['publication_age_ns', 'sample_age_ns', 'publication_minus_sample_ns']:
            values = np.array([s[field] for s in selected])
            topic_summary[name][field] = {'min': int(values.min()),
                'max': int(values.max()), 'p50': float(np.percentile(values, 50)),
                'p95': float(np.percentile(values, 95))} if len(values) else None
    local = topics['vehicle_local_position']
    state_counts = {key: int(np.count_nonzero(local[key])) for key in
                    ['xy_valid', 'z_valid', 'v_xy_valid', 'v_z_valid', 'heading_good_for_control', 'dead_reckoning']}
    resets = {}
    for name, fields in topics.items():
        for key, values in fields.items():
            if key.endswith('reset_counter'):
                resets[name+'.'+key] = {'first': int(values[0]), 'last': int(values[-1]),
                    'observed_changes': int(np.count_nonzero(np.diff(values.astype(np.int64))))}
    check_inputs()
    write('summary.json', {
        'study': 'ekf2-development-state-time-v1', 'seed': 27201,
        'input_ulog_sha256': digest(raw), 'images_verified': len(frames),
        'ulog_dropouts_ms': [int(d.duration) for d in ulog.dropouts],
        'ulog_instances': [{'name': d.name, 'multi_id': int(d.multi_id)} for d in ulog.data_list],
        'sample_timing_usable_count': timing['sample_timing_usable_count'],
        'publication_only_false_fresh_count': timing['publication_only_false_fresh_count'],
        'topic_timing': topic_summary, 'topic_coverage': timing['topic_coverage'],
        'publication_based_health_counts': health['counts'],
        'publication_based_health_reasons': health['reason_counts'],
        'all_local_position_samples': len(local['timestamp']),
        'all_local_position_flag_nonzero_counts': state_counts,
        'reset_observations': resets,
        'epoch_qualified': False, 'eligible_for_live_capture': False,
        'inputs_rechecked': True, 'parser': 'pyulog 0.9.0 from verified wheel',
        'wall_elapsed_s': time.perf_counter()-start,
        'scope': 'offline development log diagnostic, not receipt/latency/calibration/fusion qualification',
    })
    print((OUT / 'summary.json').read_text())


if __name__ == '__main__':
    main()
