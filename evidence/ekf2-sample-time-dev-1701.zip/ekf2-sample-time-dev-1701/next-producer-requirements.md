# Next trustworthy observation producer requirements

The development27201 diagnosis changes the next action: do not assume that the
passed standalone VIO cohort supplies healthy PX4 state, and do not begin corpus
collection or training merely because the offline Controller adapter exists.

1. Preserve actual sample, publisher and host receipt times independently.
   Pin the simulation/boot/session mapping from evidence. This diagnostic found
   publication=sample in one run, not a guarantee for every deployment. Use a
   causal state available at the observation deadline; no future publication.
2. Acquire primary EKF2 identity and health with the same state session. The old
   v1 audit pairs vehicle outputs with estimator instance0 status; this run
   contains only instance0 in the four selected topics, but future multi-EKF
   runs require selector association rather than assuming instance0 is primary.
3. Keep heading, velocity, position, filter-fault and dead-reckoning rejection.
   Study27201 provides only one healthy camera instant under the old audit, at
   4.0s, and that instant is GNSS-classified. Sparse flags show no EV aiding.
   A source can be deployment-visible GNSS without being VIO; name it exactly.
4. Carry position/velocity/attitude reset counters and deltas. The observed
   heading and quaternion publications straddle 3.992/3.996s; a source must not
   combine frames across reset boundaries implicitly. Any goal-frame rebasing
   needs a separate tested rule. No such correction was implemented here.
5. Derive camera pose from calibrated extrinsics and body origin. Pinned EKF2
   PublishLocalPosition calls its position/velocity the body origin. OpenVINS
   IMU-origin extrinsics and Gazebo model-origin transforms are not interchangeable
   by name. Keep camera calibration unknown until its actual evidence qualifies.
6. Bind source evidence to the sequence and inspected upstream EGO identity;
   reject the current truth-backed NativeGazeboPx4Backend for training. Do not
   manufacture teacher references, fill absent frames or turn this ULog into a
   synthetic passing training corpus. Inspect the actual container when resource
   and execution scope permit; Docker service state alone proves neither
   presence nor absence of the pinned image.

Current producer scope remains offline/design-only. Live wire activation,
ODOMETRY/EKF2 mutation, arming and new training jobs are not authorized by this
diagnostic. Do not change the 2s watchdog, heading gate, physical workload or
VIO thresholds to turn the archived unarmed study into a passing training run.
The existing accepted VIO accuracy and simulation covariance results remain
valid within their own scope; this is a separate PX4-state consumption gap.
