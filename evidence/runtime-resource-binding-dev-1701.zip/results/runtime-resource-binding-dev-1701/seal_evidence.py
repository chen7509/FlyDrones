import hashlib
import json
import shutil
import subprocess
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent
snapshot = base / 'final-source'
snapshot.mkdir(exist_ok=False)
files = ['tools/benchmark/runtime_resource_binding.py','tools/benchmark/capture_contract.py','tools/benchmark/capture_disarmed_sensors.py','tests/benchmark/test_runtime_resource_binding.py','docs/RUNTIME_RESOURCE_BINDING_REPORT.md','docs/superpowers/specs/2026-10-06-runtime-resource-binding.md','docs/superpowers/plans/2026-10-06-runtime-resource-binding.md','.gitignore']
for name in files:
 dest = snapshot / name
 dest.parent.mkdir(parents=True, exist_ok=True)
 shutil.copyfile(root / name, dest)
(base / 'reviewed.diff').write_bytes(subprocess.check_output(['git', 'diff', 'ee42323..54d09e4'], cwd=root))
(base / 'final.diff').write_bytes(subprocess.check_output(['git', 'diff', '54d09e4..HEAD'], cwd=root))
with (base / 'sealed-head.json').open('x') as f:
 json.dump(dict(head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True, cwd=root).strip()), f)
archive = root / 'evidence/runtime-resource-binding-dev-1701.zip'
members = {}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
 for path in sorted(base.rglob('*')):
  if not path.is_file():
   continue
  name = path.relative_to(root).as_posix()
  data = path.read_bytes()
  members[name] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
  z.writestr(name, data)
 z.writestr('SHA256-MANIFEST.json', json.dumps(members, indent=2, sort_keys=True).encode())
with zipfile.ZipFile(archive) as z:
 assert 'results/runtime-resource-binding-dev-1701/fixed-binding-v2/runtime-binding-pre.json' in z.namelist()
 assert z.testzip() is None and len(z.namelist()) == len(members) + 1
 for name, meta in members.items():
  data = z.read(name)
  assert len(data) == meta['bytes'] and hashlib.sha256(data).hexdigest() == meta['sha256']
seal = dict(path=str(archive), members=len(members) + 1, bytes=archive.stat().st_size, sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
with (base / 'seal.json').open('x') as f:
 json.dump(seal, f, indent=2)
print(json.dumps(seal))
