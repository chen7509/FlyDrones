import sdformat14 as s,json
from pathlib import Path
out=Path(__file__).resolve().parent
root=Path(__file__).resolve().parents[2]
px4=Path.home()/'PX4-Autopilot'
c=s.ParserConfig();c.add_uri_path('model://',str(px4/'Tools/simulation/gz/models'));c.add_uri_path('model://',str(root/'assets/gazebo/models'))
calls=[]
def find(name):
 calls.append(name)
 for base in [root/'assets/gazebo/models',px4/'Tools/simulation/gz/models']:
  p=base/name.removeprefix('model://')
  if p.exists():return str(p)
 return ''
c.set_find_callback(find)
r=s.Root();errors=r.load(str(root/'assets/gazebo/models/x500_benchmark/model.sdf'),c)
result=dict(load_doc=s.Root.load.__doc__,load_return=repr(errors),callbacks=calls,model=r.model().name() if r.model() else None,api='installed sdformat14',simulator_started=False)
(out/'sdformat-capability-v2.json').write_text(json.dumps(result,indent=2))
(out/'parsed-model.sdf').write_text(r.to_string())
print(json.dumps(result))
