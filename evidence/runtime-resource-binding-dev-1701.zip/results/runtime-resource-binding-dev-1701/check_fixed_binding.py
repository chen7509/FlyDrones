import sys,json,hashlib,zipfile,subprocess,importlib.util,importlib
from pathlib import Path
root=Path(__file__).resolve().parents[2];sys.path[:0]=[str(root),str(root/'src')]
from tools.benchmark.runtime_resource_binding import RuntimeBinding,ENV_KEYS,GENERATED_NAMES,parse_maps
from tools.benchmark.declared_runtime_snapshot import snapshot,write_manifest,parse_ldd
from tools.benchmark.capture_disarmed_sensors import active_resources
out=Path(__file__).resolve().parent;dest=out/'fixed-binding-v1';dest.mkdir(exist_ok=False)
assert active_resources()==[]
archive=root/'evidence/supported-online-vio-dev-1701.zip';digest=hashlib.sha256(archive.read_bytes()).hexdigest();assert digest=='07a2a247b87ff43304ec4c0fe787640264772ad12c272b354d5a5116cdecaeb2'
generated={};members=[]
with zipfile.ZipFile(archive) as z:
 for name in GENERATED_NAMES:
  path=dest/name
  if name=='gz_env.sh':
   source=Path.home()/'PX4-Autopilot/build/px4_sitl_default/rootfs/gz_env.sh';data=source.read_bytes();origin=str(source)
  else:
   candidates=[n for n in z.namelist() if n.endswith('/capture-v1/'+name)];assert len(candidates)==1
   origin=candidates[0];data=z.read(origin)
  path.write_bytes(data);generated[name]=path;members.append(dict(name=name,source=origin,sha256=hashlib.sha256(data).hexdigest()))
write_manifest(dest/'input-members.json',dict(archive_sha256=digest,members=members,scope='fixed prior files; gz_env is current installed input, not historical evidence'))
spec=importlib.util.find_spec('sdformat14');assert spec and spec.origin
extension=Path(spec.origin)
ldd=subprocess.run(['ldd',str(extension)],capture_output=True,text=True,timeout=15)
write_manifest(dest/'ldd.json',dict(stdout=ldd.stdout,stderr=ldd.stderr,returncode=ldd.returncode))
paths=[extension,root/'tools/benchmark/runtime_resource_binding.py',root/'results/openvins-online-shadow-dev-1701/online_probe']+[Path(p) for p in parse_ldd(ldd.stdout,ldd.returncode)]
paths=list(dict.fromkeys(str(p.absolute()) for p in paths));inventory={'fixed_selected':paths}
import os
env=dict(os.environ)
doc=dict(schema='capture-resource-binding-v1',inventory=inventory,baseline=snapshot(inventory),environment={key:env.get(key) for key in ENV_KEYS},generated={name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in generated.items()})
write_manifest(dest/'binding-declaration.json',doc)
obj=RuntimeBinding(doc,dest);obj.start(generated,env,[extension])
importlib.import_module('sdformat14')  # No Root/TestFixture/Server instance or estimator invocation.
phase=obj.observe('post-sdformat-import');assert phase['observed_files_covered'] is True
normal=obj.finish();write_manifest(dest/'normal-result.json',normal);assert normal['pre_recorded'] and normal['declared_files_stable'] and not normal['errors']
faultdir=dest/'inode-fault';faultdir.mkdir();obj=RuntimeBinding(doc,faultdir);obj.start(generated,env,[extension]);raw=Path('/proc/self/maps').read_text();lines=raw.splitlines();changed=False
for i,line in enumerate(lines):
 fields=line.split(maxsplit=5)
 if len(fields)==6 and fields[5].startswith('/'):
  fields[4]=str(int(fields[4])+1);lines[i]=' '.join(fields);changed=True;break
assert changed
obj.map_reader=lambda:'\n'.join(lines)+'\n'
try:obj.observe('wrong-inode')
except ValueError:pass
else:raise AssertionError('wrong inode accepted')
fault=obj.finish();assert fault['errors'];write_manifest(faultdir/'result.json',fault)
resources=active_resources();assert resources==[]
summary=dict(producer='54d09e4',selected_files=len(paths),normal=normal,wrong_inode_refused=True,resources=resources,simulator_started=False,estimator_started=False,physical_run=False,runtime_closure_qualified=False)
write_manifest(out/'fixed-binding-summary.json',summary);print(json.dumps(summary))
