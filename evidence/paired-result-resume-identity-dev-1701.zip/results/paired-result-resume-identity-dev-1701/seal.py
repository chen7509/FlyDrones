import hashlib,json
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path.cwd()
study=root/'results/paired-result-resume-identity-dev-1701'
v=json.loads((study/'reviewed-verification.json').read_text(encoding='utf-8-sig'))
assert all(v[x]==0 for x in ('exit_code','ruff_exit','diff_exit'))
assert '49 passed in 2.18s' in (study/'reviewed-green.txt').read_text(encoding='utf-8-sig')
assert '12 failed, 6 passed' in (study/'red.txt').read_text(encoding='utf-8-sig')
assert '2 failed' in (study/'corrected-fixture-red.txt').read_text(encoding='utf-8-sig')
assert '2 failed' in (study/'ledger-red.txt').read_text(encoding='utf-8-sig')
artifacts=[p for p in (study/'pytest-reviewed').rglob('*') if p.is_file()]
assert len(artifacts)==175
states=[json.loads(p.read_text(encoding='utf-8')) for p in artifacts if p.name=='batch_state.json']
assert any(s['completed']==s['total']==2 and len(s['records'])==2 and all('returncode' not in r for r in s['records']) for s in states)
assert any(s['completed']==s['total']==2 and [r['status'] for r in s['records']]==['controller_error','collision'] and s['records'][0]['returncode']==2 and 'returncode' not in s['records'][1] for s in states)
old={
'evidence/mission-clock-refusal-dev-1701-v2.zip':'913c0b6b2c6dbb17f6c29d3a66e591edbf3098c35415ac80afc771b0e18f296f',
'evidence/mission-clock-refusal-dev-1701.zip':'16edeb07b102fd8dbb8b7a57c6482e27707f5e55634cef6e77da2a9cfcb35def',
'evidence/mission-state-safety-dev-1701.zip':'b9995fbb09ce57724328885a24cbfa67e530dc7fbf690f1b97b19e19a85d3ea7',
'evidence/curriculum-evaluation-integrity-dev-1701.zip':'edaa6b69cb169e07628d9fddda443673bb340918602e9e4200c4a30a9334bbe3',
'evidence/ego-build-v3-oom-dev-1701.zip':'28400eb8776984a10530e0f6fa5835938c68fa77bc21da306b7340fc3394a3bb',
'evidence/ego-build-whitespace-dev-1701.zip':'de9511745154b703f59235a4194ea626d469833712dac9b2b937fc98512acd17'}
for name,digest in old.items(): assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
files={}
for p in study.rglob('*'):
    assert not p.is_symlink()
    if p.is_file() and p.name not in {'seal.json','pr65-before.json','pr65-body.md','publication-review.json'}:
        files[p.relative_to(root).as_posix()]=p.read_bytes()
for name in [
'src/flydrones/benchmark/runner.py','src/flydrones/benchmark/provenance.py','src/flydrones/benchmark/score.py',
'src/flydrones/benchmark/report.py','src/flydrones/benchmark/ulog_capture.py',
' tools/benchmark/run_batch.py','tools/benchmark/report_results.py','tools/benchmark/audit_archive.py',
'tests/benchmark/test_paired_result_identity.py','tests/benchmark/test_runner.py','tests/benchmark/test_report.py',
'tests/benchmark/test_score.py','tests/benchmark/test_provenance.py','tests/benchmark/test_ulog_capture.py',
'docs/PAIRED_RESULT_RESUME_IDENTITY_REPORT.md','docs/superpowers/plans/2026-10-14-paired-result-resume-identity.md']:
    name=name.strip()
    files[name]=(root/name).read_bytes()
manifest={n:{'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()} for n,d in sorted(files.items())}
archive=root/'evidence/paired-result-resume-identity-dev-1701.zip'
with ZipFile(archive,'x',ZIP_DEFLATED) as z:
    for n,d in sorted(files.items()): z.writestr(n,d)
    z.writestr('manifest.json',json.dumps(manifest,indent=2))
with ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(set(z.namelist()))
    for n,e in manifest.items():
        d=z.read(n)
        assert len(d)==e['bytes'] and hashlib.sha256(d).hexdigest()==e['sha256']
        assert d==(root/n).read_bytes()
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
archive.with_suffix('.sha256').open('x',encoding='utf-8').write(digest+'  '+archive.name+'\n')
record={'sha256':digest,'members':len(manifest)+1,'bytes':archive.stat().st_size,'crc_lengths_hashes_current_bytes':True,'prior_archive_hashes_unchanged':old,'tests_passed':49,'reviewed_artifact_files':175,'complete_model_trained':False,'teacher_qualified':False,'fair_physical_comparison_qualified':False}
(study/'seal.json').open('x',encoding='utf-8').write(json.dumps(record,indent=2))
print(json.dumps(record))
